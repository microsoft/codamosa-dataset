

# Generated at 2022-06-21 11:24:20.341822
# Unit test for function build_type
def test_build_type():
    from decimal import Decimal
    import dataclasses_json
    import typing
    import datetime
    import uuid
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class Nested:
        i: int
        f: float
        s: str = None
        dt: datetime.datetime = None
        b: bool = None
        u: uuid.UUID = None
        c: typing.Optional[Decimal] = None
        l: typing.List[int] = None
        o: typing.Any = None
        notserialized: int = None
        mm_field: str = None
    assert isinstance(build_type(Nested, {}, None, None, None), fields.Nested)
    # TODO: Add unit tests for other types
test_build

# Generated at 2022-06-21 11:24:21.857801
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Testing dumps of class SchemaF
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-21 11:24:31.719956
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MyClass(typing.NamedTuple):
        a: int
        b: str = ''


    @dataclass_json
    @dataclass
    class Foo:
        x: MyClass
        y: int = field(metadata={'marshmallow_field': fields.Raw()})


    schema = FooSchemaF.Schema()

    assert schema.dump(Foo(MyClass(1, '2'), 3)) == {
        'x': {
            'a': 1,
            'b': '2'
        },
        'y': 3
    }


# Generated at 2022-06-21 11:24:35.914552
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        pass

    x: SchemaF[int] = SchemaF()
    x = SchemaF()
    x: SchemaF[Foo[int]] = SchemaF()
    x = SchemaF()
    x = SchemaF[int]()



# Generated at 2022-06-21 11:24:40.825572
# Unit test for constructor of class _IsoField
def test__IsoField():
    test__IsoField = _IsoField()
    test__IsoField._deserialize('2000-01-01T00:00:00', 'attr', {})
    test__IsoField._deserialize(None, 'attr', {}, required=True)


# Generated at 2022-06-21 11:24:49.285988
# Unit test for method dumps of class SchemaF

# Generated at 2022-06-21 11:24:51.688972
# Unit test for function build_schema
def test_build_schema():
    from dataclasses_json.api import _Schema  # noqa
    from .typing_ import Type  # noqa
    # TODO This unit test will fail because of the imports.

    @dataclass
    class A:
        a: typing.List[Type]
        b: int

    assert build_schema(  # type: ignore
        A, object, False, False) == _Schema  # type: ignore



# Generated at 2022-06-21 11:24:54.313808
# Unit test for constructor of class _IsoField
def test__IsoField():
    print("Test _IsoField __init__()")
    field = _IsoField("Test field")
    print("Test _IsoField __init__() finished")


# Generated at 2022-06-21 11:25:03.601960
# Unit test for function build_type
def test_build_type():
    from typing import Mapping
    from dataclasses_json.api import dataclass_json

    @dataclass_json
    class A:
        l: typing.List

    @dataclass_json
    class B:
        d: dict

    @dataclass_json
    class C:
        s: str

    @dataclass_json
    class D:
        u: typing.Union[typing.List, int]

    @dataclass_json
    class E:
        u: typing.Union[typing.List, int, str]

    @dataclass_json
    class O:
        u: typing.Optional[typing.List]

    @dataclass_json
    class F:
        # Unsupported type: typing.Tuple
        u: typing.Tuple

    #@dat

# Generated at 2022-06-21 11:25:13.450871
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from datetime import datetime

    class Simple(Schema):
        dt = fields.DateTime(format='iso')

    print(Simple.loads)
    print(Simple.loads(b"[]", many=True))
    print(Simple.loads(b"[]", many=None))
    print(Simple.loads(b"[]", many=False))
    print(Simple.loads(b'{"dt": "2020-06-08T12:00:00"}'))
    print(Simple.loads(b'["2020-06-08T12:00:00"]', many=True))
    print(Simple.loads(b'["2020-06-08T12:00:00"]', many=False))

# Generated at 2022-06-21 11:25:30.663024
# Unit test for function build_type
def test_build_type():
    # this is needed for the test
    warnings.simplefilter("ignore")
    import datetime
    from typing import Mapping, Tuple

    @dataclass_json
    class Friend:
        name: str
        age: int
        birth_date_time: datetime.datetime
        uuid: UUID

    @dataclass_json
    class Foo:
        name: str
        age: int
        friends: Mapping[str, Friend]
        friends2: Tuple[Friend]
        birth_date_time: datetime.datetime
        uuid: UUID
        enum: MyEnum

    assert type(build_type(str, {}, None, None, None)) == fields.Str
    assert type(build_type(int, {}, None, None, None)) == fields.Int

# Generated at 2022-06-21 11:25:42.641122
# Unit test for function build_type
def test_build_type():
    import uuid
    import datetime
    import enum
    class Person(enum.Enum):
        JOHN = "JOHN"
        JANE = "JANE"
    @dataclass_json
    @dataclass
    class Nested:
        name : str
        uid : typing.Optional[uuid.UUID] = MISSING

    @dataclass_json
    @dataclass
    class User:
        name : str
        age : int
        birth_date : datetime.datetime
        uid : typing.Optional['Nested'] = MISSING
        person : Person
        user_or_name : typing.Union[User, str]

    options = dict(required=False, allow_none=False)
    mixin = dataclass_json.DataClassJsonMixin

# Generated at 2022-06-21 11:25:51.626053
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[int].loads("1", many=False) == 1
    assert SchemaF[int].loads("[1]", many=True) == [1]
    assert SchemaF[int].loads(b'1', many=False) == 1
    assert SchemaF[int].loads(b'[1]', many=True) == [1]
    assert SchemaF[int].loads(bytearray("1", "ascii"), many=False) == 1
    assert SchemaF[int].loads(bytearray("[1]", "ascii"), many=True) == [1]

# Generated at 2022-06-21 11:25:55.689164
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class TestSchema(DataClassJsonMixin):
        test_field: Optional[CatchAllVar]

    assert schema(TestSchema, DataClassJsonMixin, False) == {}



# Generated at 2022-06-21 11:25:59.463826
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    fld = _TimestampField()
    assert fld.deserialize(0) == datetime.utcfromtimestamp(0)
    assert fld.serialize(datetime.utcfromtimestamp(0)) == 0


# Generated at 2022-06-21 11:26:03.557639
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[A]):
        c = fields.Int()

    dump = TestSchema().load
    dump({"c": 5}).c == 5
    dump({"c": 5}, many=True)[0].c == 5



# Generated at 2022-06-21 11:26:10.075606
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    T = typing.TypeVar('T')

    class SchemaFImpl(SchemaF[T]):
        pass

    SchemaFImpl.loads(  # type: ignore[attr-defined] # noqa: F821

    )

# Generated at 2022-06-21 11:26:18.105647
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow as mm
    class MySchema(mm.Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""
        ...

    @post_load
    def make_my_obj(self, data, **kwargs):
        class MyObj:
            def __init__(self, a):
                self.a = a

        return MyObj(**data)

    class A(MyObj):
        def __init__(self, a):
            MyObj.__init__(self, a)

    class B:
        def __init__(self, a):
            self.a = a

    class MySchema2(MySchema[B]):
        a = mm.fields.Str()


# Generated at 2022-06-21 11:26:27.401635
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField(required=False)
    assert field._serialize(datetime.utcnow(), 'a_datetime', None)
    assert field._serialize(None, 'a_datetime', None) is None
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=RuntimeWarning)
        with pytest.raises(ValidationError):
            field._serialize(datetime.utcnow(), 'a_datetime', None, required=True)
    # Test deserializer
    field = _TimestampField(required=False)
    assert field._deserialize(datetime.utcnow().timestamp(), 'a_timestamp', None)
    assert field._deserialize(None, 'a_timestamp', None) is None

# Generated at 2022-06-21 11:26:36.685902
# Unit test for constructor of class SchemaF
def test_SchemaF():
    Data = typing.TypeVar('Data')
    class Foo(typing.Generic[Data]):
        pass

    foos: typing.List[Data] = [Foo()]
    SchemaF[Foo].dump(foos)
    SchemaF[Foo].dump(Foo())
    SchemaF[Foo].dumps(foos)
    SchemaF[Foo].dumps(Foo())
    SchemaF[Foo].load(foos)
    SchemaF[Foo].load(Foo())
    SchemaF[Foo].loads(foos)
    SchemaF[Foo].loads(Foo())


# Generated at 2022-06-21 11:26:57.039970
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    @dataclass_json(encoder=ExtendedEncoder,
                    unknown='EXCLUDE')
    @dataclass
    class FooSchema(SchemaF[Foo]):
        a: int
        b: str

    foo = Foo(a=1, b='b')
    schema = FooSchema()
    assert schema.dump(foo) == {'a': 1, 'b': 'b'}
    assert schema.dumps(foo) == '{"a": 1, "b": "b"}'
    assert schema.dump([foo, foo]) == [{'a': 1, 'b': 'b'}, {'a': 1, 'b': 'b'}]

# Generated at 2022-06-21 11:27:07.730800
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    b = SchemaF[bytes]()
    b.loads = lambda x: typing.cast(bytes, x)
    x = b.dumps(b"abcd")
    assert x == b"abcd"

    from marshmallow import pprint

    def _pprint(x):
        return pprint(x, indent=2)

    a = SchemaF[A]()
    a.loads = lambda x: typing.cast(A, x)
    x = a.dumps(A(a=1, b=2))
    assert _pprint(x) == _pprint({"a": 1, "b": 2})


if sys.version_info >= (3, 7):
    SchemaF_for_test = SchemaF
else:
    SchemaF_for_test = Schema


# Generated at 2022-06-21 11:27:18.795221
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TypeA:
        pass

    class TypeB:
        pass
    class SchemaA(Schema):
        a = fields.Int()
    class SchemaB(Schema):
        b = fields.Int()

    class Foo:
        def __init__(self, a: typing.Union[TypeA, TypeB]):
            self.a = a
    class FooSchema(Schema):
        a = fields.Nested(SchemaA, missing=MISSING, default=MISSING,
                          required=False, allow_none=False)
        b = fields.Nested(SchemaB, missing=MISSING, default=MISSING,
                          required=False, allow_none=False)


# Generated at 2022-06-21 11:27:24.968477
# Unit test for function schema
def test_schema():
    import typing
    import marshmallow
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from . import _create_schema

    @dataclass_json
    @dataclass
    class DataClass:
        @dataclass_json
        @dataclass
        class Nested:
            a: int
        nested: Nested
        d: datetime.datetime = datetime.datetime.utcnow()
        # d8 = datetime.datetime.utcnow()
        e: typing.Optional[str]
        f: typing.List[int]
        g: typing.Dict[str, int]
        h: typing.Callable[..., int]
        i: typing.Union[str, int, None]
        j: typing.Mapping

# Generated at 2022-06-21 11:27:37.392484
# Unit test for function build_type
def test_build_type():
    from typing import Optional
    from marshmallow import Schema, fields, post_load
    from marshmallow_enum import EnumField  # type: ignore
    from enum import IntEnum
    @dataclass_json
    @dataclass
    class MySchema(Schema):
        value: Optional[int] = None

    @dataclass_json
    @dataclass
    class Data:
        myschema: MySchema = None

    opt_int = Optional[int]
    int_enum = IntEnum('temp', {'TEMP1': 1, 'TEMP2': 2})
    opt_int_enum = Optional[int_enum]

    assert build_type(opt_int, {'required': True}, Schema, dc_fields(Data)[0], Data) == fields.Integer()
    assert build_type

# Generated at 2022-06-21 11:27:39.464925
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.deserialize("1")
    field.serialize(datetime.utcnow())


# Generated at 2022-06-21 11:27:50.771348
# Unit test for function schema
def test_schema():
  from dataclasses import dataclass, field
  @dataclass
  class D:
    a: typing.List[str]
    b: typing.Dict[str, int]
    c: str
    d: typing.Any
    e: typing.Optional[CatchAllVar] = field(default=None)
    f: typing.Optional[CatchAllVar] = field(default_factory=dict)
    g: typing.Optional[int] = None
    h: typing.Optional[int] = field(default=None)
    i: list = field(default_factory=list)
    def op(self, o):
      return o
    j: typing.Callable = op

  print(schema(D, None, False))

# Generated at 2022-06-21 11:27:58.525370
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import dataclasses
    import typing
    from marshmallow import fields, Schema

    @dataclasses.dataclass
    class A:
        a: str
        b: typing.List[str]

    class SchemaA(SchemaF[A]):
        a = fields.Str()
        b = fields.List(fields.Str())

    a = A('a', ['b'])
    schemaA = SchemaA()
    assert 'b' in schemaA.dumps(a)



# Generated at 2022-06-21 11:28:06.149979
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts_field = _TimestampField()
    assert ts_field._serialize(datetime(2019, 1, 1, 0, 0, 0), None, None) == 1546300800.0
    assert ts_field._serialize(None, None, None) == None
    assert ts_field._deserialize(1546300800.0, None, None) == datetime(2019, 1, 1, 0, 0, 0)
    assert ts_field._deserialize(None, None, None) == None


# Generated at 2022-06-21 11:28:18.789284
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    DataClassSchema = build_schema(DummyDataWithConst, Schema, False, True)
    assert DataClassSchema.dump(DummyDataWithConst(12, 13)) == {
        'x': 12,
        'y': 13,
        'z': 17
    }
    assert DataClassSchema.dumps(DummyDataWithConst(12, 13)) == '{"x":12,"y":13,"z":17}'
    assert DataClassSchema().load(
        {"x": 12, "y": 13, "z": 17}).x == 12 and DataClassSchema().load(
        {"x": 12, "y": 13, "z": 17}).y == 13

# Generated at 2022-06-21 11:28:29.991807
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()


# Generated at 2022-06-21 11:28:41.984393
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF.loads("hello world"), str)
    assert isinstance(SchemaF.loads("hello world", many=True)[0], str)
    assert isinstance(SchemaF.loads(b"hello world"), bytes)
    assert isinstance(SchemaF.loads(b"hello world", many=True)[0], bytes)
    assert isinstance(SchemaF.loads(bytearray(b"hello world")), bytearray)
    assert isinstance(SchemaF.loads(bytearray(b"hello world"), many=True)[0], bytearray)



# Generated at 2022-06-21 11:28:51.409875
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import json
    class Foo(typing.NamedTuple):
        a: str

    class Bar(typing.NamedTuple):
        a: str
        b: int

    class FooBar(typing.NamedTuple):
        a: str
        bar: Bar

    schema_foo = SchemaF[Foo]()
    schema_foo.dump(Foo('a'))

    schema_bar = SchemaF[Bar]()
    schema_bar.dump(Bar('a', 1))

    schema_foobar = SchemaF[FooBar]()
    schema_foobar.dump(FooBar('a', Bar('a', 1)))

    schema_foobar = SchemaF[Bar](dump_only=True)


# Generated at 2022-06-21 11:28:57.061917
# Unit test for constructor of class _IsoField
def test__IsoField():
    from marshmallow import ValidationError
    iso = _IsoField()
    assert iso._serialize(None, None, None) is None
    assert iso._serialize(datetime.fromisoformat("2019-11-07T10:00:00-05:00"), None, None) == "2019-11-07T10:00:00-05:00"
    try:
        iso._serialize(None, None, None, required=True)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-21 11:29:06.107165
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    from dataclasses import dataclass

    @dataclass
    class X:
        y: int

    @dataclass
    class Z:
        x: X

    def test(expect, actual, msg):
        # type: (TOneOrMulti, TOneOrMulti, str) -> None
        if expect != actual:
            raise AssertionError(f"{msg}: {expect} != {actual}")

    z = dumps(load(Z(x=X(42)), Z))
    test(Z(x=X(42)), loads(z, Z), "SchemaF.loads(SchemaF.dumps(obj, cls), cls), cls=Z")
    sf = SchemaF[Z]()

# Generated at 2022-06-21 11:29:15.585647
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()

# Generated at 2022-06-21 11:29:19.339452
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class SimpleClass:
        a: str

    schema = build_schema(SimpleClass, "", "", "")
    assert schema



# Generated at 2022-06-21 11:29:29.388985
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        def __init__(self, x: int):
            self.x = x

    class B:
        def __init__(self, y: int):
            self.y = y

    @dataclass
    class C:
        x: typing.Union[A, B]

    class A_Schema(Schema):
        x = fields.Int()

    class B_Schema(Schema):
        y = fields.Int()

    @dataclass_json
    class C_Schema(Schema):
        x = _UnionField(
            desc={A: A_Schema(), B: B_Schema()},
            cls=C,
            field=C.__dataclass_fields__['x']
        )

    a = A(1)
    b = B(2)


# Generated at 2022-06-21 11:29:37.570466
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    from marshmallow import Schema, fields

    class MySchema(SchemaF[int]):
        num = fields.Int()

    schema = MySchema()
    assert schema.load({"num": 3}) == 3
    assert schema.load([{"num": 3}, {"num": 4}]) == [3, 4]
    assert schema.load({"num": 3}, many=True) == [3]
    assert schema.load([{"num": 3}, {"num": 4}], many=True) == [3, 4]

    with pytest.raises(ValidationError):
        schema.load([3, 4])
    with pytest.raises(ValidationError):
        schema.load(3)



# Generated at 2022-06-21 11:29:44.634957
# Unit test for function build_type
def test_build_type():
    import typing
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class A:
        pass


    @dataclass
    class B(A):
        pass


    @dataclass
    class C:
        pass

    @dataclass
    class D:
        a: typing.List[A]

    @dataclass
    class E:
        b: typing.List[typing.Optional[A]]

    @dataclass
    class F:
        c: typing.Union[str, int, A]

    @dataclass
    class G:
        d: typing.Optional[typing.Union[str, int, A]]

    @dataclass
    class H:
        e: typing.Union[str, int, A]


# Generated at 2022-06-21 11:30:06.313532
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass  # type: ignore



# Generated at 2022-06-21 11:30:08.069378
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField(allow_none=True)
    _IsoField(allow_none=False)


# Generated at 2022-06-21 11:30:18.310661
# Unit test for function build_schema
def test_build_schema():
    class A:
        def __init__(self, i: int):
            self.i = i

    a = A(1)
    assert hasattr(A, '__annotations__')
    assert hasattr(A, '__init__')
    assert hasattr(A, '__name__')
    assert hasattr(A, '__module__')
    assert callable(getattr(A, '__init__'))
    assert isinstance(getattr(A, '__annotations__'), dict)
    assert isinstance(getattr(A, '__name__'), str)
    assert isinstance(getattr(A, '__module__'), str)
    assert getattr(A, '__name__') == 'A'
    assert getattr(A, '__module__') == __name__

# Generated at 2022-06-21 11:30:19.281481
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()



# Generated at 2022-06-21 11:30:29.273825
# Unit test for function schema
def test_schema():
    import unittest
    import dataclasses
    import marshmallow.fields
    import typing
    
    class TestSchema(unittest.TestCase):
        def assertSchema(self, cls, mixin, result):
            self.assertEqual(schema(cls, mixin, True), result)
    
        def test_simple(self):
            @dataclasses.dataclass
            class Simple:
                field: str
            
            self.assertSchema(Simple, dataclass_json.DataClassJsonMixin, {
                "field": marshmallow.fields.Str(),
            })
    
        def test_optional_field(self):
            @dataclasses.dataclass
            class Simple:
                field: typing.Optional[str] = None
            

# Generated at 2022-06-21 11:30:39.228377
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class User:
        def __init__(self, name: str, email: str):
            self.name = name
            self.email = email

    class UserSchema(SchemaF[User]):
        name = fields.String(required=True)
        email = fields.String(required=True)

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)

    user = User(name='Monty', email='monty@python.org')
    schema = UserSchema()
    result = schema.load([{"name": "Mick", "email": "mick@stones.com"},
                          {"name": "Keith", "email": "keith@stones.com"}])

# Generated at 2022-06-21 11:30:42.433995
# Unit test for constructor of class SchemaF
def test_SchemaF():
    wrong_declaration = None  # type: typing.Optional[SchemaF[int]]
    try:
        wrong_declaration = SchemaF()
    except NotImplementedError:
        pass
    assert wrong_declaration is None, 'Wrong declaration of SchemaF class should raise NotImplementedError'



# Generated at 2022-06-21 11:30:52.079399
# Unit test for function build_schema
def test_build_schema():
    class TestDataClass(dataclass.dataclass):
        field1: str
        field2: int
        field3: int = 2
        complex_field: typing.List[typing.Dict[str, typing.Any]] = dataclass.field(
            default_factory=lambda: [
                {"item": 1},
                {"item": 2}
            ])

        # This is a hack of type Optional[CatchAllVar]
        field4: typing.Any = dataclass.field(
            default=None
        )

        @classmethod
        def schema(cls):
            return build_schema(cls, dataclass_json.DataClassJsonMixin,
                                False, False)

    assert TestDataClass.schema.__name__ == "TestdataClassSchema"
    schema = Test

# Generated at 2022-06-21 11:30:55.177549
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    s = SchemaF()
    s.dump(None)

    class T(typing.Generic[A]):
        pass

    t = T()

    s = SchemaF()
    s.dump(t)



# Generated at 2022-06-21 11:31:02.587047
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime(2018, 12, 12), "", "") == 1544585600.0
    assert field._serialize(datetime(2018, 12, 12, 12, 12, 12, 1000), "", "") == 1544589332.001
    assert field._serialize(None, "", "") is None

    assert field._deserialize(0, "", "") == datetime(1970, 1, 1, 0, 0, 0)
    assert field._deserialize(1544585600.0, "", "") == datetime(2018, 12, 12)
    assert field._deserialize(None, "", "") is None

    field = _TimestampField(required=True)

# Generated at 2022-06-21 11:31:43.342860
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Dict, Optional, TypeVar
    from dataclasses_json.api import MODE_ANNOTATIONS

    @dataclass
    class A:
        a: int
        @classmethod
        def schema(cls):
            return SchemaType.from_dataclass(cls)

    @dataclass
    class B:
        b: str
        @classmethod
        def schema(cls):
            return SchemaType.from_dataclass(cls)

    @dataclass_json(mm_field=build_type)
    @dataclass
    class C:
        a: A
        b: B


# Generated at 2022-06-21 11:31:49.630906
# Unit test for function build_schema
def test_build_schema():
    from typing import Union
    from dataclasses import dataclass
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    @dataclass
    class InnerClass:
        str: str
        bool: bool
        int: int
    # type: ignore
    @dataclass
    class TestSchemaClass:
        str: str
        str_none: str
        bool: bool
        int: int
        bool_none: bool
        int_none: int
        map_none: typing.Mapping[int, int]
        list_float: typing.List[float]
        list_float_none: typing.List[float]
        list_inner_class: typing.List[InnerClass]
        list_inner_class_none: typing.List[InnerClass]
        d

# Generated at 2022-06-21 11:31:55.253497
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # test _serialize works properly
    test_data = datetime.now()
    test_field = _TimestampField()
    assert test_field._serialize(test_data, None, None) == test_data.timestamp()

    # test _deserialize works properly
    assert test_field._deserialize(test_data.timestamp(), None, None) == test_data



# Generated at 2022-06-21 11:32:04.450782
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, asdict
    import marshmallow as mm
    from typing import Any, List

    @dataclass
    class User:
        name: str
        age: int

    @dataclass
    class Blog:
        title: str
        content: str
        author: User
        tags: List[str]

    schema = build_schema(User, mm.Schema, False, False)
    b = Blog('Title', 'Content', User('User 1', 10), ['Tag1', 'Tag2'])
    bs = str(schema().dump(b))
    bs = schema().dump(b)
    print(bs)

# Generated at 2022-06-21 11:32:10.526260
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.api import dump_schema
    import json
    from marshmallow import fields

    class MySchemaF(SchemaF[Shoe]):
        pass

    @dataclass
    class Shoe:
        size: int
        brand: str
        construction: str = 'leather'

    dump_schema(MySchemaF(), Shoe)

    schema = MySchemaF()
    shoe = Shoe(size=42, brand='Adidas')
    result = schema.dumps(shoe)
    json.loads(result)



# Generated at 2022-06-21 11:32:19.205847
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass
    from datetime import datetime
    from marshmallow import fields

    @dataclass
    class Person:
        name: str = 'John Doe'
        age: int = 18
        created: datetime = datetime.now()

    fields_ = schema(Person, None, False)
    assert isinstance(fields_['name'], fields.Field), "Check schema for class field"
    assert isinstance(fields_['age'], fields.Field), "Check schema for class field"
    assert isinstance(fields_['created'], fields.Field), "Check schema for class field"



# Generated at 2022-06-21 11:32:21.809453
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    a = SchemaF.loads('{"a":1}',many=False)


# Generated at 2022-06-21 11:32:24.274284
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def dump_test(a: TOneOrMultiEncoded, many: bool = None) -> TOneOrMultiEncoded:
        return a



# Generated at 2022-06-21 11:32:26.212717
# Unit test for function schema
def test_schema():
    pass

# This will fail, but it is meant to show that the function is never called
# @schema
# class TestCls:
#     pass

# Generated at 2022-06-21 11:32:27.940676
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj = SchemaF[int]().dumps(1)
    assert isinstance(obj, str)

# Generated at 2022-06-21 11:32:56.797691
# Unit test for function build_type
def test_build_type():
    import marshmallow
    import dataclasses_json
    import typing
    from typing_inspect import is_union_type  # type: ignore

    # we're going to test with a generic field so we need to get around mypy
    cls = dataclasses.dataclass(frozen=True, unsafe_hash=True)(
        lambda: None).__class__
    f = typing.get_type_hints(lambda: None)['return']
    field = dataclasses.field(metadata={'mm_field': {}})
    type_ = typing.NewType('TestType', typing.List[str])
    origin = getattr(type_, '__origin__', type_)
    inner = build_type(type_, {}, dataclasses_json.MutableMapping, field, cls)
    assert inner == marsh

# Generated at 2022-06-21 11:32:57.413676
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()


# Generated at 2022-06-21 11:33:07.044025
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from marshmallow import Schema, fields
    from marshmallow import pre_load, post_dump

    class MySchema(Schema):
        test_str = fields.Str()
        test_int = fields.Int()

        @pre_load
        def pre_load_method(self, data, **kwargs):
            return data

        @post_dump
        def post_dump_method(self, data, **kwargs):
            return data

    schema_f = SchemaF[List[dict]](strict=True)


# Generated at 2022-06-21 11:33:15.733502
# Unit test for constructor of class _IsoField
def test__IsoField():
    IsoField = _IsoField()
    value = datetime.fromisoformat("2010-10-10T00:00:00")
    assert IsoField._serialize(value, None, None, None) == "2010-10-10T00:00:00"
    assert IsoField._deserialize("2010-10-10T00:00:00", None, None, None) == datetime.fromisoformat("2010-10-10T00:00:00")

    IsoField = _IsoField(required=False)
    assert IsoField._deserialize(None, None, None, None) == None
    assert IsoField._serialize(None, None, None, None) == None



# Generated at 2022-06-21 11:33:20.558876
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import typing
    import marshmallow
    from dataclasses import dataclass

    @dataclass
    class DataClass:
        test: typing.List[int]

    S = SchemaF[DataClass]

    d = DataClass([1,2])
    s = S()

    assert(s.dumps(d) == '{"test": [1, 2]}')


# Generated at 2022-06-21 11:33:31.695562
# Unit test for function build_schema
def test_build_schema():
  from .decorators import dataclass_json
  from dataclasses import dataclass
  @dataclass
  class a:
    x:int
    y:int
  # 
  @dataclass
  class b:
    x:a
    y:a
  assert b.schema==build_schema(b,None,True,False)
  
  @dataclass
  class c:
    x:a
    y:{}
  assert c.schema==build_schema(c,None,True,False)
  
  @dataclass
  class d:
    x:a=None
    y:a=None
  assert d.schema==build_schema(d,None,True,False)
  
  # @dataclass
  # class e:
  #

# Generated at 2022-06-21 11:33:33.214535
# Unit test for function build_type
def test_build_type():
    build_type(A, {}, Mixin, A, A)

# Generated at 2022-06-21 11:33:35.382594
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        _ = SchemaF()



# Generated at 2022-06-21 11:33:37.475010
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    data = datetime.utcnow()
    assert field.deserialize(field.serialize(data)) == data


# Generated at 2022-06-21 11:33:44.653424
# Unit test for function build_type
def test_build_type():
    import typing
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow_enum import EnumField
    from marshmallow_oneofschema import OneOfSchema
    from marshmallow_oneofschema.fields import OneOf
    from dataclasses_json.mm_schema import build_type

    class Enum1(Enum):
        A = "A"

    class Enum2(Enum):
        A = "A"

    class Enum3(Enum):
        A = "A"

    class Enum4(Enum):
        A = "A"

    class TestMixin1:
        dataclass_json_config = {}

    class TestMixin2:
        dataclass_json_config = dict(unknown="EXCLUDE")
