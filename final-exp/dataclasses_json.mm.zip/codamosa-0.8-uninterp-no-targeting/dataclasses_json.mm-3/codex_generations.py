

# Generated at 2022-06-21 11:24:15.218401
# Unit test for constructor of class _UnionField
def test__UnionField():
    pass

# Generated at 2022-06-21 11:24:21.313635
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union, Optional
    from marshmallow import Schema, fields, post_load

    from dataclasses_json.schema import _UnionField

    @dataclass
    class SomeDC:
        a: str

    class SomeDCSchema(Schema):
        a = fields.String()

    @dataclass
    class AnotherDC:
        a: int

    class AnotherDCSchema(Schema):
        a = fields.Integer()

    @dataclass
    class SomeClass:
        field: Union[SomeDC, str]

    class SomeClassSchema(Schema):
        field = _UnionField(desc={SomeDC: SomeDCSchema(), str: fields.String()},
                           cls=SomeClass, field=dc_fields(SomeClass)[0])

   

# Generated at 2022-06-21 11:24:23.145949
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass

# Generated at 2022-06-21 11:24:32.532889
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class _SchemaF(SchemaF):
        """
        Dummy implementation of SchemaF for test purposes.
        """

        def __init__(self, *args, **kwargs):
            """
            Initialize dummy implementation.
            """

            super().__init__(*args, **kwargs)

        def dumps(self, obj: A, many: bool = None, *args,
                  **kwargs) -> str:
            # type: ignore
            return 'test'

    # test dumps
    s = _SchemaF()
    assert s.dumps(1) is 'test'  # type: ignore
    assert s.dumps([1]) is 'test'  # type: ignore
    # test dumps with star args
    s = _SchemaF()

# Generated at 2022-06-21 11:24:41.194384
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # testing incomplete Schema
    class A:
        pass

    class B:
        pass

    class ASchema(SchemaF[A]):
        b = fields.Field()

    class BSchema(SchemaF[B]):
        a = fields.Field()

    SchemaF[A]
    ASchema
    SchemaF[B]
    BSchema

    # testing complete Schema
    @dataclasses.dataclass
    class C:
        a: typing.List[A]
        b: typing.List[B]

    class CSchema(SchemaF[C]):
        a = fields.List(fields.Nested(ASchema))
        b = fields.List(fields.Nested(BSchema))


# Generated at 2022-06-21 11:24:41.789873
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass

# Generated at 2022-06-21 11:24:47.248532
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    from dataclasses import dataclass
    @dataclass
    class Foo:
        i: int

    @dataclass
    class Bar:
        j: int

    class fs(SchemaF[Foo]):
        pass
    assert fs.loads('{"i": 1}') == Foo(1)  # type: ignore

    class bs(SchemaF[Bar]):
        pass
    assert bs.loads('{"j": 1}') == Bar(1)  # type: ignore

    class gs(SchemaF[typing.Union[Foo, Bar]]):
        pass
    assert gs.loads('{"i": 1}') == Foo(1)  # type: ignore



# Generated at 2022-06-21 11:24:48.272229
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-21 11:24:49.637226
# Unit test for constructor of class _IsoField
def test__IsoField():
    with pytest.raises(TypeError):
        _IsoField()



# Generated at 2022-06-21 11:24:50.938238
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().__init__


# Generated at 2022-06-21 11:25:08.966256
# Unit test for function schema
def test_schema():
    @_handle_undefined_parameters_safe
    class Person(Schema):
        name: str
    # FIXME: I don't know why the schema is empty
    print(Person.schema())



# Generated at 2022-06-21 11:25:19.625772
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import fields, Schema
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class User:
        id: str
        email: str
        active: bool

    class UserSchema(Schema, typing.Generic[User]):
        id = fields.Str()
        email = fields.Email()
        active = fields.Bool()

    data = [{
        'id': '1',
        'email': 'test1@example.com',
        'active': True
    }, {
        'id': '2',
        'email': 'test2@example.com',
        'active': False
    }]
    users = UserSchema().loads(data)
    assert len

# Generated at 2022-06-21 11:25:25.648884
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test_value = 42
    test_field = _TimestampField()
    assert test_field._serialize(datetime.utcfromtimestamp(test_value), None, None) == test_value
    assert test_field._deserialize(test_value, None, None) == datetime.utcfromtimestamp(test_value)
    test_field.required = True
    with pytest.raises(ValidationError):
        test_field._serialize(None, None, None)
    with pytest.raises(ValidationError):
        test_field._deserialize(None, None, None)



# Generated at 2022-06-21 11:25:27.209750
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class _SchemaF(SchemaF):
        field: typing.List[A]

    x = _SchemaF()



# Generated at 2022-06-21 11:25:31.502025
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional
    from datetime import date
    import dataclasses_json
    import marshmallow

    @dataclasses_json.dataclass_json(letter_case=dataclasses_json.LetterCase.CAMEL)
    @dataclasses.dataclass
    class User:
        id: int
        name: str
        date_joined: date


# Generated at 2022-06-21 11:25:43.439172
# Unit test for constructor of class _UnionField
def test__UnionField():
    class MyField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            return value

        def _deserialize(self, value, attr, data, **kwargs):
            return value

    class A:
        pass
    class B:
        pass
    class C:
        pass

    dc = typing.Union[A, B, C]

    field = _UnionField(
        desc={
            A: MyField(),
            B: MyField(),
            C: MyField(),
        },
        cls=C,
        field='my_field',
        allow_none=False,
    )

    assert field.allow_none == False
    assert field._serialize(A(), '', None) == A()
    assert field._serialize(B(), '', None)

# Generated at 2022-06-21 11:25:46.714418
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class B:
        b_attr = str

    @dataclass
    class A:
        a_attr = int
        b: B

    d = A(a_attr=42, b=B('test'))
    res = SchemaF[A]().dumps(d, many=False)



# Generated at 2022-06-21 11:25:48.202919
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass



# Generated at 2022-06-21 11:25:49.535421
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[int], {}, list, None, None, )

# Generated at 2022-06-21 11:25:55.443224
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Setup object
    class A:
        pass

    obj = [A(), A()]
    # Setup a mock Marshmallow Schema
    mm_Schema = Schema()
    mm_Schema.dump = lambda obj, many: 'dump_result'  # type: ignore
    # Setup a SchemaF instance
    schema = SchemaF[A]()
    # Make the call to the mock SchemaF
    result = schema.dump(obj)
    assert result == 'dump_result'

# Generated at 2022-06-21 11:26:35.524404
# Unit test for function schema
def test_schema():
    import mypy_extensions
    import typing
    import json
    class _SchemaBase_:
        def __init__(self, **kwargs):
            self._dict = {}
            self._dict.update(kwargs)

        def __getattribute__(self, key):
            try:
                return object.__getattribute__(self, key)
            except AttributeError:
                try:
                    return self._dict[key]
                except KeyError:
                    raise AttributeError(
                        "type object '{}' has no attribute '{}'".format(
                            self.__class__.__name__, key))

        def __setattr__(self, key, value):
            if key in self._dict:
                self._dict[key] = value

# Generated at 2022-06-21 11:26:46.992706
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class Foo:
        id: int
        s: str
    f = Foo(1, 'foo')
    s = SchemaF[Foo]().dumps([f])
    assert s == '[{"id": 1, "s": "foo"}]'

    # check that we can pass instance that is not instance of type A
    try:
        SchemaF[Foo]().dumps(1)
    except ValueError:
        pass
    else:
        assert False

    # check how does this behave on a wrong type
    try:
        SchemaF[int]().dumps(1)
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 11:26:48.528671
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Root(SchemaF[A]):
        pass



# Generated at 2022-06-21 11:26:57.839756
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    from pprint import pprint

    @dataclass
    class A:
        name: str
        age: int
        male: bool = True

    @dataclass
    class B:
        a: A
        last_name: Optional[str] = None

    @dataclass
    class C:
        b: B
        male: Optional[bool] = None

    schema_ = build_schema(C, False)

    pprint(schema_)

    b_schema = build_schema(B, False)
    a_schema = build_schema(A, False)

    schema_ = type('test', (Schema,), {'b': fields.Nested(b_schema), 'Meta': type('Meta', (), {})})

# Generated at 2022-06-21 11:27:06.868812
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass

    @dataclass
    class Book:
        title: str
        pages: int

    class BookSchema(SchemaF[Book]):
        title = fields.Str()
        pages = fields.Int()

        @post_load
        def make_book(self, data):
            return Book(**data)

    book_schema = BookSchema()

    b = Book("My book", 100)
    s = book_schema.dumps(b)
    assert s == '{"title": "My book", "pages": 100}'



# Generated at 2022-06-21 11:27:17.963281
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    class Example(mm.Schema):
        id = mm.fields.Int()

    ExampleF = SchemaF[Example]  # type: ignore
    assert ExampleF.dumps(  # type: ignore
        Example(), many=False) == "{\"id\": null}"
    assert ExampleF.dumps([  # type: ignore
        Example(), Example()
    ]) == "[{\"id\": null}, {\"id\": null}]"
    assert ExampleF.dumps([  # type: ignore
        Example(), Example()
    ], many=False) == "[{\"id\": null}, {\"id\": null}]"
    assert ExampleF.dumps(  # type: ignore
        Example(), many=True) == "{\"id\": null}"

# Generated at 2022-06-21 11:27:20.222633
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(None, None, None) is None
    assert _TimestampField()._serialize(None, None, None) is None


# Generated at 2022-06-21 11:27:21.138179
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-21 11:27:33.843124
# Unit test for function schema
def test_schema():
    """
    This function tests function _schema by creating a schema for the dataclass DCSimple that has
    the following parameters:
        int_: int
        optional_int: Optional[int]
        str_: str
        optional_str: Optional[str]
        int_list: List[int]
        optional_int_list: Optional[List[int]]
    """
    cls = DCSimple
    mixin = None
    infer_missing = True

# Generated at 2022-06-21 11:27:39.042369
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    dc = typing.MutableMapping
    s = SchemaF[dc]
    a: str = s.dumps(dc(), many=False)
    b: typing.List[str] = s.dumps([dc()], many=True)
    c: typing.List[str] = s.dumps([dc(), dc()], many=False)


# Generated at 2022-06-21 11:28:39.490512
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema = SchemaF[int]()
    res = schema.loads('[1, 2, 3]', many=True)

    assert res == [1, 2, 3]

# Generated at 2022-06-21 11:28:42.871664
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Person:
        pass

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()

    p = PersonSchema().loads('{"name": "Jan Kowalski"}')
    assert isinstance(p, Person)



# Generated at 2022-06-21 11:28:52.728606
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json
    from typing import Dict, List
    from marshmallow import Schema, fields


    class Item(Schema):
        name = fields.Str()


    class ItemF(SchemaF[Item]):
        __annotations__ = {'items': List[Item]}
        items: List[Item] = fields.List(fields.Nested(Item))


    schema = ItemF()
    data = '[{"name": "foo"}]'
    result = schema.loads(data)
    assert [{"name": "foo"}] == result  # type: ignore


# Generated at 2022-06-21 11:28:55.137688
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: typing.List
    assert schema(A, None, False)['a'] == fields.List


# Generated at 2022-06-21 11:29:02.534733
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E:
        pass

    class F:
        pass

    class G:
        pass

    # noinspection PyUnusedLocal
    class H(B):
        def __init__(self, a: int, b: float):
            pass

    @dataclass
    class SomeClass:
        v: typing.Union[A, B, int, C, D, E, F, G, str, H]

    c = SomeClass(A())


# Generated at 2022-06-21 11:29:13.088837
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema, fields

    class A:
        pass

    class B:
        pass

    class C:
        pass

    class D:
        pass

    class E:
        pass

    class Fn(Schema):
        pass

    class F(Schema):
        class Meta:
            unknown = 'EXCLUDE'

    class G(Schema):
        pass

    class H(Schema):
        pass

    class I(Schema):
        pass

    class J(Schema):
        pass

    desc = {int: Fn, str: F, A: G, B: H, C: I, D: J}
    cls = E
    field = E.__fields__['field']
    assert cls.__name__ == 'E'
    assert field.name == 'field'
   

# Generated at 2022-06-21 11:29:22.631597
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields
    from dataclasses import dataclass, MISSING
    from typing import Dict, List
    from dataclasses_json import dataclass_json
    import json
    import uuid
    import datetime

    @dataclass_json
    @dataclass
    class Meow:
        meow: int

    @dataclass_json
    @dataclass
    class Meow1:
        meow: int

    @dataclass_json
    @dataclass
    class Meow2:
        meow: int

    @dataclass_json
    @dataclass
    class User:
        id: int
        name: str
        settings: Dict[str, Meow]


# Generated at 2022-06-21 11:29:25.545230
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF[MyData].load([{"a": "b"}, {"a": "c"}]) == [MyData("b"), MyData("c")]
    assert SchemaF[MyData].load({"a": "b"}) == MyData("b")



# Generated at 2022-06-21 11:29:34.731733
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    from dataclasses_json._ast import _EncodeAst  # type: ignore
    from .utils import UnitTestSchema  # type: ignore
    from dataclasses import dataclass  # type: ignore
    from typing import Optional  # type: ignore

    @dataclass
    class Asd:  # type: ignore
        asd: Optional[str]

    class MySchema(SchemaF[Asd]):
        asd = fields.String()

    asd = Asd(asd='qwe')
    schema = MySchema()
    assert schema.dumps(asd) == '{"asd": "qwe"}'  # type: ignore
    assert schema.dump(asd) == {'asd': 'qwe'}  # type: ignore
    assert asd == schema.loads

# Generated at 2022-06-21 11:29:42.758440
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        foo: int

    @dataclass_json
    @dataclass
    class B:
        bar: str

    class C(SchemaF[A]):
        foo: fields.Field
        bar: fields.Field

        @post_load
        def make_A(self, data, **kwargs):
            return A(**data)

    class D(SchemaF[B]):
        bar: fields.Field

        @post_load
        def make_B(self, data, **kwargs):
            return B(**data)

    assert isinstance(C({'foo': 1}), A)
    assert isinstance(D({'bar': 'a'}), B)


# Generated at 2022-06-21 11:32:24.701159
# Unit test for constructor of class _UnionField
def test__UnionField():
    u1 = typing.Union[int, str]
    u2 = typing.Union[int, str, UUID, Decimal, typing.List[int]]
    u3 = typing.Union[int, str, typing.List[int]]
    u4 = typing.Union[str, typing.List[int]]
    u5 = typing.Union[str]

    assert _UnionField({}, None, None, allow_none=False).allow_none is False
    assert _UnionField({}, None, None, allow_none=True).allow_none is True
    assert _UnionField({}, None, None, allow_none=None).allow_none is True
    assert _UnionField(u1, None, None).allow_none
    assert not _UnionField(u2, None, None, allow_none=False).allow_none
    assert _Union

# Generated at 2022-06-21 11:32:27.804460
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    SchemaF.loads('1', 1, many=None, partial=None, unknown=None)
    SchemaF.loads(b'1', 1, many=None, partial=None, unknown=None)
    SchemaF.loads(b'1', 1, many=True, partial=None, unknown=None)  # type: ignore



# Generated at 2022-06-21 11:32:32.107573
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class D:
        a: int
        b: typing.Union[str, bool]

    schema = DcSchema.from_dataclass(D)
    f = schema.fields['b']
    assert isinstance(f, _UnionField)
    assert f.desc[str].__class__ == fields.String
    assert f.desc[bool].__class__ == fields.Boolean



# Generated at 2022-06-21 11:32:39.386065
# Unit test for constructor of class _IsoField
def test__IsoField():
    field=_IsoField()
    datetime_object=datetime(2018, 11, 28, 10, 20, 0)
    assert datetime_object.isoformat() == "2018-11-28T10:20:00"
    assert field._serialize( datetime_object, None, None ) == "2018-11-28T10:20:00"
    assert field._deserialize( "2018-11-28T10:20:00", None, None ) == datetime_object
    return



# Generated at 2022-06-21 11:32:43.930207
# Unit test for constructor of class _IsoField
def test__IsoField():
    # arrange
    test_input = "2010-01-01T00:00:00"
    # act
    result = _IsoField()._deserialize(test_input, "attr", "data")
    # assert
    assert result == datetime(2010, 1, 1)



# Generated at 2022-06-21 11:32:50.401944
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema = SchemaF(many=True)
    schema.load([])
    schema.load([{}])
    schema.load(None)
    schema.load({})
    schema.load({"a": None})
    schema.load({"a": {}})
    schema.load({"a": []})
    schema.load({"a": [{"b": ""}]})



# Generated at 2022-06-21 11:32:53.779183
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test_field = _TimestampField()
    expected_output = 1556098984.0
    assert test_field._serialize(datetime.utcfromtimestamp(1556098984.0), None, None) == expected_output


# Generated at 2022-06-21 11:32:57.309019
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class NotImplementedDataSchema(SchemaF[NotImplementedData]):
        pass
    ds = NotImplementedDataSchema()
    assert ds.dumps(NotImplementedData(1)) == '{"name": "NotImplementedData", "value": 1}'



# Generated at 2022-06-21 11:33:07.044110
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    data = dict(hello="world")
    schema = SchemaF[str]()
    schema.load(data)
    schema.load([data])

    def dict_type_annotation_test(dict: dict):
        schema = SchemaF[str]()
        return schema.load(dict)

    dict_type_annotation_test(data)
    dict_type_annotation_test([data])

    def non_proxy_type_annotation_test(dict: dict):
        schema = SchemaF()
        return schema.load(dict)

    non_proxy_type_annotation_test(data)
    non_proxy_type_annotation_test([data])

    def list_type_annotation_test(ls: list):
        schema = SchemaF[dict]()
        return schema.load(ls)

# Generated at 2022-06-21 11:33:13.059689
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        pass

    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo_schema = FooSchema()
    try:
        # noinspection PyUnresolvedReferences
        foo_schema.dump(['a'])
    except ValidationError as e:
        assert e  # We don't have to specify any value

