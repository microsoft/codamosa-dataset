

# Generated at 2022-06-21 11:24:20.303737
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class Coordinate:
        x: float
        y: float


    @dataclass
    class Map:
        width: int
        height: int
        coordinates: typing.List[Coordinate]

    def test_dump_Map() -> None:
        the_map = Map(100, 100, [Coordinate(0, 0)])
        schema = SchemaF[Map]({'width': fields.Int(),
                               'height': fields.Int(),
                               'coordinates': fields.List(fields.Nested({'x': fields.Float(), 'y': fields.Float()}))},
                              unknown='EXCLUDE')

# Generated at 2022-06-21 11:24:22.487508
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        class _TestClass(SchemaF[str]):
            pass
        _TestClass()



# Generated at 2022-06-21 11:24:29.378860
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    field = fields.Integer()
    schema = SchemaF[int](fields=dict(v=field))
    assert schema.load(dict(v=1)) == 1
    assert schema.load([dict(v=1), dict(v=2)]) == [1, 2]
    assert schema.load(dict(v=1), many=True) == [1]
    assert schema.load(dict(v=1), many=False) == 1


# Generated at 2022-06-21 11:24:36.592288
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Foo:
        a: int

    assert SchemaF[Foo].dumps(Foo(1)) == '{"a": 1}'
    assert SchemaF[Foo].dumps([Foo(1), Foo(2)]) == '[{"a": 1}, {"a": 2}]'



# Generated at 2022-06-21 11:24:39.182491
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), 'attr', 'obj') is not None


# Generated at 2022-06-21 11:24:42.254911
# Unit test for function build_type
def test_build_type():
    options = dict()
    mixin = dict()
    field = dict()
    cls = dict()
    type_ = dict()

    assert build_type(type_, options, mixin, field, cls) == dict



# Generated at 2022-06-21 11:24:50.435669
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow.validate import Length
    from dataclasses_json.schema import SchemaF
    from typing import List

    @dataclass
    class Person:
        name: str = fields.String(validate=[Length(max=20)])
        age: int = fields.Integer()

    @dataclass
    class Employee(Person):
        department: str = fields.String(attribute="dept")

    schema = SchemaF[Person]()
    s = schema.loads(b'{"name": "foo"}')
    assert isinstance(s, Person)
    s = schema.loads(b'[{"name": "foo"}]')
    assert isinstance(s, List)
    assert len(s) == 1

# Generated at 2022-06-21 11:24:53.630662
# Unit test for constructor of class _IsoField
def test__IsoField():
    dt = _IsoField()._deserialize('2020-03-03T17:29:46.853000')
    assert dt.timestamp() == 1583304186.853


# Generated at 2022-06-21 11:25:03.032157
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    p = SchemaF.load([], many=False)  # type: ignore
    p = SchemaF.load(None, many=False, partial=False)  # type: ignore
    p = SchemaF.load(None, many=False, partial=False, unknown="foo")  # type: ignore
    p = SchemaF.load(None, many=False, partial=True, unknown="moo")  # type: ignore
    p = SchemaF.load(None, many=True, partial=False)  # type: ignore
    p = SchemaF.load(None, many=True, partial=False, unknown="foo")  # type: ignore
    p = SchemaF.load(None, many=True, partial=True, unknown="moo")  # type: ignore
    p = SchemaF.load(None)

# Generated at 2022-06-21 11:25:10.025986
# Unit test for constructor of class _IsoField
def test__IsoField():
    from dataclasses import dataclass
    from marshmallow import Schema, fields, post_load
    from marshmallow.exceptions import ValidationError
    from datetime import datetime, timezone
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TimeStamp:
        last_time: datetime = datetime(2090, 3, 5, 12, 45, tzinfo=timezone.utc)

    class TimeStampSchema(Schema):
        last_time = _IsoField()

        @post_load
        def make_object(self, data, **kwargs):
            return TimeStamp(**data)

    result_schema = TimeStampSchema()

# Generated at 2022-06-21 11:25:25.365527
# Unit test for constructor of class _UnionField
def test__UnionField():
    f = _UnionField({int: fields.String()}, 'cls', 'field')
    assert f.desc[int]
    assert f.cls == 'cls'
    assert f.field == 'field'


# Generated at 2022-06-21 11:25:30.466492
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields, post_load
    import typing


    class MyClass(typing.NamedTuple):
        a: int
        b: str


    @dataclass
    class MyDC(Schema):
        aa: int = field(metadata={'marshmallow_field': fields.Int()})


    assert SchemaF(Schema).dump(MyClass(a=1, b='ahoj')) == \
        {'a': 1, 'b': 'ahoj'}
    assert SchemaF(MyDC).dump(MyDC(aa=1)) == {'aa': 1}



# Generated at 2022-06-21 11:25:32.682707
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class Test:
        test: typing.List[str]


# Generated at 2022-06-21 11:25:42.685679
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow import Schema

    @dataclass
    class Student:
      student_id: int
      first_name: str
      last_name: str

    class StudentSchema(Schema):
      student_id = fields.Int(required=True)
      first_name = fields.Str()
      last_name = fields.Str()

    student = Student(123, 'Max', 'Musterman')
    student_s = SchemaF[Student](StudentSchema)
    student_s.dump(student)
    student_s.dump([student])

# Generated at 2022-06-21 11:25:48.932850
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    from marshmallow import Schema, fields

    class E1(Enum):
        a = 1
        b = 2

    @dataclass
    class E2:
        a: int
        b: str

    class S1(Schema):
        a = fields.Integer()
        b = fields.String()

    class S2(Schema):
        a = fields.Integer()
        b = fields.String()
        c = fields.String()

    class S3(Schema):
        a = fields.Integer()
        b = fields.String()
        c = fields.String()

    @dataclass
    class DC:
        a: int
        b: str
        c: Union[E1, E2, None]

# Generated at 2022-06-21 11:25:56.145303
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        v: bool
    
    @dataclass
    class B:
        a: A
    
    assert schema(A, B, True) == {'v': fields.Bool(missing=True)} 

    @dataclass
    class C:
        a: typing.Dict[str, A]
    
    assert schema(C, C, True) == {'a': fields.Dict(keys=fields.Str(missing=True), values=fields.Nested(A.schema(), missing=True))} 


# test_schema()



# Generated at 2022-06-21 11:26:08.942858
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        pass

    @dataclass_json
    @dataclass
    class B:
        pass

    @dataclass
    class C:
        p1: typing.Union[A, B, CatchAllVar]
        p2: typing.List[A]
        p3: typing.Optional[bool]
        p4: typing.Optional[int]
        p5: typing.Optional[A]
        p6: typing.Optional[typing.List[A]]

        class Config:
            arbitrary_types_allowed = True

    s = schema(C, dataclass_json.DataClassJsonMixin, infer_missing=False)

# Generated at 2022-06-21 11:26:09.848301
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert True # TODO: implement your test here



# Generated at 2022-06-21 11:26:17.953309
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class User(SchemaF[A]):
        id = fields.Int()
        name = fields.Str()

    user = User().load({'id': 1, 'name': 'foo'})
    assert user.id == 1
    assert user.name == 'foo'


if sys.version_info >= (3, 7):
    class SchemaWithoutF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-21 11:26:18.597078
# Unit test for function build_schema
def test_build_schema():
    assert True

# Generated at 2022-06-21 11:26:33.494501
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.deserialize(1234.5)
    field.deserialize(None)


# Generated at 2022-06-21 11:26:44.981696
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import json
    import cmarshmallow

    class A:
        def __init__(self, x: int):
            self.x = x
        def __str__(self):
            return f'A(x={self.x})'

    class ASchema(SchemaF[A]):
        x = cmarshmallow.fields.Int()

    serialized = [{'x': 3}, {'x': 4}]
    deserialized = [A(3), A(4)]

    print(serialized)
    serialized_json = json.dumps(serialized)
    deserialized_l = ASchema().loads(serialized_json, many=True)
    assert deserialized == deserialized_l

    print(serialized[0])

# Generated at 2022-06-21 11:26:55.716009
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class Mixin:
        a: typing.Optional[int]

    @dataclasses.dataclass
    class Test(Mixin):
        b: str

    class TestSchema(Schema):
        a = fields.Int()
        b = fields.Str()

    import json
    import pytest

    # Test if function `schema` works correctly
    assert json.dumps(TestSchema().dump(Test(a=4, b='hello'))) == '{"a": 4, "b": "hello"}'
    assert json.dumps(TestSchema().dump(Test(a=None, b='hello'))) == '{"a": null, "b": "hello"}'

# Generated at 2022-06-21 11:26:59.222854
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # This class definition is not really needed for testing. But this problem
    # should not occur in the real world.
    class MyClass(SchemaF[MyClass]):
        pass

    MyClass()



# Generated at 2022-06-21 11:27:09.961024
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema

    class TestSubClass(object):
        def __init__(self, a: int, b: float):
            self.a = a
            self.b = b

    class TestSchema(Schema):
        a = fields.Int()
        b = fields.Int()

    class TestClass(object):
        def __init__(self, a: Union[int, float, TestSubClass]):
            self.a = a

    class TestClassSchema(Schema):
        a = _UnionField(desc={int: fields.Int(),
                     float: fields.Float(),
                     TestSubClass: TestSchema()}, cls=TestClass, field=None)

    data = {'a': {'a': 1, 'b': 2.0}}
    res = TestClass

# Generated at 2022-06-21 11:27:20.224288
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def _test(in_obj: TOneOrMulti, in_many: bool, expected_output: str):
        actual_output: str = _SchemaF_schema.dumps(in_obj, many=in_many)
        assert actual_output == expected_output

    _SchemaF_schema: SchemaF[int] = SchemaF(strict=True, many=True,
                                            default_field=fields.Int())
    _test(in_obj=[], in_many=None,
          expected_output='[]')
    _test(in_obj=[7], in_many=None,
          expected_output='[7]')
    _test(in_obj=[7, 8, 9], in_many=None,
          expected_output='[7,8,9]')

# Generated at 2022-06-21 11:27:32.903462
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    c = SchemaF[int].load([1, 2, 3])  # type: ignore
    d = SchemaF.load([1, 2, 3])  # type: ignore[call-overload]
    e = SchemaF[str].load("hi")  # type: ignore
    f = SchemaF.load("hi")  # type: ignore[call-overload]

# Generated at 2022-06-21 11:27:34.119598
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import Dict, List

    class S(SchemaF[List[Dict[str, int]]]):
        pass



# Generated at 2022-06-21 11:27:38.243971
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestClass:
        a: List[int]
    schema = build_schema(TestClass, mixin=None, infer_missing=False, partial=False)
    assert schema.a.__class__.__name__ == 'List'


# Generated at 2022-06-21 11:27:43.151901
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(FieldsSchema):
        x = fields.Int()

    a = SchemaF[A]()
    x1 = a.loads('{"x": 1}') # type: A
    assert x1.x == 1
    x2 = a.loads('[{"x": 1}, {"x": 2}]') # type: List[A]
    assert x2 == [A(x=1), A(x=2)]



# Generated at 2022-06-21 11:28:17.276235
# Unit test for constructor of class _UnionField
def test__UnionField():
    import unittest
    import dataclasses
    import typing
    import marshmallow
    class Foo:
        def __init__(self, a, b):
            self.a, self.b = a, b
    class Bar:
        def __init__(self, a, b):
            self.a, self.b = a, b
    class Baz:
        def __init__(self, a, b):
            self.a, self.b = a, b
    @dataclasses.dataclass
    class ClsA:
        foo: typing.Union[Foo, Bar]
        baz: typing.Union[Baz, int]

# Generated at 2022-06-21 11:28:20.473737
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    s = SchemaF[dataclasses.dataclass]()
    s.dump(1)
    s.dump([1])
    s.dumps(1)
    s.dumps([1])


# Generated at 2022-06-21 11:28:23.064066
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    iso_field._deserialize('2007-04-05T14:30', None, None)



# Generated at 2022-06-21 11:28:28.432804
# Unit test for constructor of class SchemaF
def test_SchemaF():
    tmp = typing.List[int]()
    tmp2 = SchemaF[int]().dump(tmp, many=True)
    tmp3 = SchemaF[int]().loads(tmp2, many=True)
    assert tmp2 == tmp3
    tmp = 1
    tmp2 = SchemaF[int]().dump(tmp)
    tmp3 = SchemaF[int]().loads(tmp2)
    assert tmp2 == tmp3



# Generated at 2022-06-21 11:28:29.877891
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    x = SchemaF[int]()
    assert x.loads('1') == 1

# Generated at 2022-06-21 11:28:34.585046
# Unit test for function build_type
def test_build_type():
    import typing
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema

    @dataclass_json
    @dataclass
    class Test:
        data: typing.List

    field = dataclasses.Field(type=Test, default=MISSING, default_factory=MISSING,
                              init=True, repr=True, hash=None, compare=True,
                              metadata={})

# Generated at 2022-06-21 11:28:36.875480
# Unit test for constructor of class SchemaF
def test_SchemaF():
    raise NotImplementedError()
# mypy flag: --silent-imports



# Generated at 2022-06-21 11:28:40.082090
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().serialize("some_string") == "some_string"
    assert _TimestampField().deserialize("some_string") == "some_string"


# Generated at 2022-06-21 11:28:49.546699
# Unit test for function schema
def test_schema():
    assert {"a": fields.Field} == schema({"__annotations__": {"a": str}}, object, True)
    assert {"a": fields.Field} == schema({"__annotations__": {"a": typing.TypeVar("A")}}, object, True)
    assert {"a": fields.Field} == schema({"__annotations__": {"a": typing.Any}}, object, True)
    assert {"a": fields.Field} == schema({"__annotations__": {"a": typing.Generic}}, object, True)
    assert {"a": fields.List} == schema({"__annotations__": {"a": typing.List[str]}}, object, True)
    assert {"a": fields.List} == schema({"__annotations__": {"a": list}}, object, True)

# Generated at 2022-06-21 11:28:57.600454
# Unit test for constructor of class SchemaF
def test_SchemaF():  # NOQA
    @dataclass_json
    @dataclass
    class A:
        x: int

    def get_A(x: int) -> A:
        return A(x=x)

    # The following is just to test typing.
    A_F = SchemaF[A]
    a = get_A(1)
    data = A_F().dump(a)
    b = A_F().load(data)
    # The following is to test the real code.
    A_F = SchemaF[A]
    a = A(x=1)
    data = A_F().dump(a)
    b = A_F().load(data)
    assert a.x == b.x



# Generated at 2022-06-21 11:29:31.505810
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema
    from marshmallow.fields import String, Integer
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    class _Foo:
        pass

    @dataclass(frozen=True)
    class _Foo2(_Foo):
        foo: int

    @dataclass
    class _Foo3(_Foo):
        foo: int

    class _Schema1(Schema):
        foo = fields.Integer()

    class _Schema2(Schema):
        foo = fields.Integer()

    class _Schema3(Schema):
        foo = fields.Integer()


# Generated at 2022-06-21 11:29:33.836894
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert hasattr(SchemaF, 'dump')
    assert hasattr(SchemaF, 'dumps')
    assert hasattr(SchemaF, 'load')
    assert hasattr(SchemaF, 'loads')



# Generated at 2022-06-21 11:29:41.952357
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass, MISSING
    from dataclasses_json import dataclass_json
    from typing import List

    @dataclass_json
    @dataclass
    class D1:
        id: str
        name: str

    @dataclass_json
    @dataclass
    class D2:
        id: str
        name: str
        nested: List['D1']

    class S2(SchemaF[D2]):
        id = fields.Str(allow_none=False, data_key='id', load_from='id')
        name = fields.Str(data_key='name', load_from='name')
        nested = fields.List(fields.Nested(lambda: S1, data_key='nested'))


# Generated at 2022-06-21 11:29:48.389800
# Unit test for constructor of class _UnionField
def test__UnionField():
    class FooId:
        def __init__(self, uuid: UUID):
            self.uuid = uuid

    class Foo:
        def __init__(self, id: FooId):
            self.id = id

    @dataclass_json
    @dataclass
    class FooIdData:
        uuid: UUID

    @dataclass_json
    @dataclass
    class FooData:
        id: Union[FooId, FooIdData]

    # this will test the validation of the constructor
    assert str(_UnionField(
        desc={int: fields.Int()},
        cls=FooData,
        field=dc_fields(FooData)[0])) == '<dataclasses_json._UnionField>'

    # this will test we got the correct serialization/deserial

# Generated at 2022-06-21 11:29:59.961541
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class User:
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

        @post_load
        def make_user(self, data, **kwargs):
            return User(name=data["name"], age=data["age"])

    @dataclasses.dataclass
    class User_dc():
        name: str
        age: int

    class User_dc_Schema(SchemaF[User_dc]):
        name = fields.Str()
        age = fields.Int()

    # test non-collection, non-dataclass
    # dump
    x = User(name='Monty', age=42)


# Generated at 2022-06-21 11:30:04.968478
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses.dataclass
    class Foo:
        baz: int

    class FooSchema(SchemaF[Foo]):
        pass

    assert FooSchema[Foo].dump([Foo(1)], many=True) == [{"baz": 1}]



# Generated at 2022-06-21 11:30:10.871520
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, asdict
    from dataclasses_json.mm import MM


# Generated at 2022-06-21 11:30:11.770670
# Unit test for constructor of class _IsoField
def test__IsoField():
    x = _IsoField(default="")


# Generated at 2022-06-21 11:30:16.140202
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def test(json_data: JsonData, many: bool = None, partial: bool = None, unknown: str = None, **kwargs):
        return SchemaF(many=many, partial=partial, unknown=unknown, **kwargs).loads(json_data)

# Generated at 2022-06-21 11:30:17.159827
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    return _TimestampField()


# Generated at 2022-06-21 11:32:11.691661
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    class Dummy(object):
        def __init__(self, a: int, b: str = 'b') -> None:
            self.a = a
            self.b = b

    class DummySchema(SchemaF[Dummy]):
        a = fields.Int()
        b = fields.Str()

    class DummyListSchema(SchemaF[typing.List[Dummy]]):
        dummies = fields.Nested(DummySchema, many=True)

    assert DummySchema().loads(b'{"a": 1, "b": "B"}') == Dummy(1, 'B')
    assert DummySchema().loads(b'{"a": 1}') == Dummy(1)

# Generated at 2022-06-21 11:32:17.628674
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        test: str
        test2: int = '0'

    assert schema(Test, None, False) == {
        'test': fields.Str(),
        'test2': fields.Int(),
    }



# Generated at 2022-06-21 11:32:23.193854
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import typing
    import marshmallow as mm

    class A(typing.Generic[A]):
        def dump(self, obj: A) -> typing.Dict[str, str]:
            pass

    class B(mm.Schema):
        def dump(self, obj: A) -> typing.Dict[str, str]:
            pass



# Generated at 2022-06-21 11:32:31.290289
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.schema import SchemaF
    from dataclasses_json.api import dump_schema, dumps, load_schema, loads
    from dataclasses import dataclass
    @dataclass
    class Foo:
        x: int=100
    result = SchemaF.dumps(Foo(), many=False)
    result1 = dumps(Foo(), include_schema=False)
    result2 = dumps(Foo(), include_schema=True, include_schema_by_default=True)
    result3 = SchemaF.dump(Foo(), many=False)
    result4 = dump_schema(Foo(), include_schema=False)
    result5 = dump_schema(Foo(), include_schema=True, include_schema_by_default=True)


# Generated at 2022-06-21 11:32:42.427268
# Unit test for function build_type
def test_build_type():
    class _MMAware(metaclass=_ExtendedEncoder):
        pass

    class MixTest(Schema):
        class Meta:
            fields = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
                      'm', 'n', 'o', 'p', 'q', 'r',)

        a = fields.Field()
        b = fields.Field()
        c = fields.Field()
        d = fields.Field()
        e = fields.Field()
        f = fields.Field()
        g = fields.Field()
        h = fields.List(fields.Field())
        i = fields.Field()
        j = fields.Field()
        k = fields.Field()
        l = fields.Field()

# Generated at 2022-06-21 11:32:53.819130
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B:
        pass
    # Needed for type checking
    class A1(A):
        pass
    class B1(B):
        pass
    class C:
        def __init__(self, x, y):
            self.x = x
            self.y = y
    class D:
        def __init__(self, u, t, l):
            self.u = u
            self.t = t
            self.l = l
    class E(A, B):
        pass
    class F(A, B):
        pass
    class G(A, B):
        pass
    class H(A, B):
        pass


# Generated at 2022-06-21 11:32:59.858994
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    """Check that the type signature of SchemaF.dump is correct"""
    class TestSchema(SchemaF):
        ...

    s = TestSchema()
    l = []
    # Test default many=None
    e1 = s.dump(l)
    e2 = s.dump(l, True)
    e3 = s.dump(l, False)
    assert str(type(e1)) == str(type(e3))
    assert str(type(e1)) == 'list'
    assert str(type(e2)) == 'dict'

    d = {}
    # Test many=None
    e1 = s.dump(d)
    e2 = s.dump(d, True)
    e3 = s.dump(d, False)

# Generated at 2022-06-21 11:33:09.912667
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import ValidationError

    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.conf import Config

    CONF = Config()

    @dataclass
    class SchemaF_load_sample(DataClassJsonMixin):
        a: int
        b: int

    SCHEMA_F_LOAD_SAMPLE = SchemaF_load_sample[int]

    SCHEMA_F_LOAD_SAMPLE.fields['a'].deserialize(1)
    SCHEMA_F_LOAD_SAMPLE.fields['a'].deserialize('1')
    SCHEMA_F_LOAD_SAMPLE.fields['b'].deserialize(2)

# Generated at 2022-06-21 11:33:19.716810
# Unit test for constructor of class _UnionField
def test__UnionField():
    import dataclasses
    import typing
    class TestA(): pass
    class TestB(): pass
    class TestC(): pass
    class TestD(): pass

    TestUnion1 = typing.Union[TestA]
    TestUnion2 = typing.Union[TestA, TestB]
    TestUnion3 = typing.Union[TestA, TestB, TestC]
    TestUnion4 = typing.Union[TestA, TestB, TestC, TestD]

    class TestSchema1(Schema):
        attr1 = fields.Field()
    class TestSchema2(Schema):
        attr2 = fields.Field()
    class TestSchema3(Schema):
        attr3 = fields.Field()
    class TestSchema4(Schema):
        attr4 = fields.Field()


# Generated at 2022-06-21 11:33:25.770469
# Unit test for function build_schema
def test_build_schema():
    class Point(Schema):
        x = fields.Int()
        y = fields.Int()

    class SchemaA(Schema):
        schema_b = fields.Nested(Point)
        schema_c = fields.Nested(Point)

    assert SchemaA.schema_b is not None
    assert SchemaA.schema_c is not None

