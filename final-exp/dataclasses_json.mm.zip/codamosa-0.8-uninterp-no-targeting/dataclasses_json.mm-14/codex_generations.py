

# Generated at 2022-06-21 11:24:27.235147
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses_json.schema import Schema

    from typing import Union

    from marshmallow import Schema as MarshmallowSchema, fields

    class MarshmallowSchemaA(MarshmallowSchema):
        test = fields.Integer()

    class MarshmallowSchemaB(MarshmallowSchema):
        test = fields.Integer()

    class MarshmallowSchemaC(MarshmallowSchema):
        test = fields.Integer()

    class TestSchema(Schema):
        def get_obj_type(self, obj):
            return type(obj)

        def get_field_schema(self, field):
            if field == 'test':
                return {TestA: MarshmallowSchemaA, TestB: MarshmallowSchemaB}
            elif field == 'test2':
                return {TestC: MarshmallowSchemaC}

       

# Generated at 2022-06-21 11:24:37.992068
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Optional, Union

    class G(Enum):
        a = 'a'


    @dataclass
    class _A:
        a: str

    @dataclass
    class _B:
        b: int

    @dataclass
    class _C:
        c: float

    @dataclass
    class _D:
        d: UUID

    @dataclass
    class _E:
        e: Decimal

    @dataclass
    class _F:
        f: datetime

    @dataclass
    class _Simple:
        a: int = 0
        b: str = ''
        c: float = 0
        d: bool = False
        e: UUID = None
        f: datetime = None
        g: Decimal = None
        h: bytes = None

# Generated at 2022-06-21 11:24:46.942556
# Unit test for function schema
def test_schema():
    def assert_schema(actual, expected, msg=None):
        assert actual.keys() == expected.keys(), \
            '{} != {}'.format(actual.keys(), expected.keys())
        assert all(
            isinstance(actual[k]['type'], expected[k]['type'])
            for k in actual.keys()
        )
        # assert all(
        #     actual[k]['required'] == expected[k]['required']
        #     for k in actual.keys()
        # )
        # assert all(
        #     actual[k]['allow_none'] == expected[k]['allow_none']
        #     for k in actual.keys()
        # )
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

# Generated at 2022-06-21 11:24:52.219557
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class S(SchemaF[A]):
        pass
    json_data = '[{"a": 1}]'
    res: typing.List[A] = S().loads(json_data)

# Generated at 2022-06-21 11:25:01.802802
# Unit test for function schema
def test_schema():
    from dataclasses_json.api import dataclass_json
    from marshmallow import Schema as _Schema

    def _extend_schema(cls, mixin):
        if _issubclass_safe(cls, mixin):
            if not hasattr(cls, 'Schema'):
                cls.Schema = type('Schema', (_Schema,), schema(cls, mixin, False))
            return cls.Schema
        return None

    def _wrap_schema(cls, mixin):
        return dataclass_json(cls, encoder=_ExtendedEncoder, _extend_schema=_extend_schema)

    @_wrap_schema
    class Person:
        name: str
        age: int = 18
        home: typing.Optional[str]

# Generated at 2022-06-21 11:25:03.587017
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Dupa(SchemaF):
        pass



# Generated at 2022-06-21 11:25:07.950132
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields

    class B:
        pass

    class A:
        a: int
        b: typing.Optional[B]

    class Af(SchemaF[A]):
        a = fields.Int()
        b = fields.Nested('Bf')

    class Bf(SchemaF[B]):
        pass

    s = Af()
    s.dumps(A(1, B()))

# Generated at 2022-06-21 11:25:13.877401
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    try:
        import dataclasses_json
    except ImportError:
        import sys
        sys.path.append('.')
        import dataclasses_json
    @dataclasses_json.dataclass_json
    @dataclass
    class Test1:  
        a: str
        b: int
        c: datetime
        d: typing.Optional[datetime] = None
        e: typing.List[int] = field(default_factory=list)
    @dataclasses_json.dataclass_json
    @dataclass
    class Test2:  
        a: str
        b: int
        c: Test1
        d: typing.Optional[Test1] = None

# Generated at 2022-06-21 11:25:21.641662
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class S(SchemaF[int]):
        pass
    assert S([1, 2, 3]).data == [1, 2, 3]
    assert S(1).data == 1
    assert S([1, 2, 3]).dumps() == '[1, 2, 3]'
    assert S(1).dumps() == '1'
    assert S(1).load(1).data == 1
    assert S([]).loads('[]').data == []
    assert S([]).loads('[1,2,3]').data == [1, 2, 3]



# Generated at 2022-06-21 11:25:27.787432
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    @dataclass
    class Person:
        name: str
        age: int
    class MySchema(SchemaF[Person]):
        name = fields.String()
        age = fields.Integer()
    schema = MySchema()
    # doctest: +NORMALIZE_WHITESPACE
    assert schema.loads('[{"age": 10, "name": "p1"},{"age": 20, "name": "p2"}]') == [Person("p1", 10), Person("p2", 20)]
    assert schema.loads('{"age": 10, "name": "p1"}') == Person("p1", 10)



# Generated at 2022-06-21 11:25:43.985101
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF.__init__(SchemaF)
    except NotImplementedError:
        pass
    except Exception:
        assert False  # wrong exception type



# Generated at 2022-06-21 11:25:46.658854
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json.loads(SchemaF[int].loads(1))


# Generated at 2022-06-21 11:25:56.180379
# Unit test for function build_type
def test_build_type():
    import sys
    import dataclasses
    from enum import Enum
    from typing import Dict
    from marshmallow import fields
    from marshmallow_enum import EnumField

    class MmMixin(object):
        @classmethod
        def schema(cls):
            from marshmallow import fields, Schema
            from marshmallow.fields import Field
            from dataclasses_json.core import _Decoder, _Encoder
            from typing import Dict, List

            class _MmSchema(Schema):
                class Meta:
                    ordered = True
                    unknown = "EXCLUDE"
                    dataclass = dataclasses.dataclass
                    dataclasses_module = dataclasses
                    json_module = json
                    tuple_as_array = True

            return _MmSchema


# Generated at 2022-06-21 11:26:08.890207
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from json import dumps as json_dumps
    from marshmallow import Schema
    _f1 = lambda:1
    assert SchemaF[int]().dumps(_f1()) == json_dumps(_f1())
    assert SchemaF[int]().dumps(_f1()) == Schema[int]().dumps(_f1())
    _f2 = lambda:[1,2]
    assert SchemaF[int](many=True).dumps(_f2()) == json_dumps(_f2())
    assert SchemaF[int](many=True).dumps(_f2()) == Schema[int](many=True).dumps(_f2())




# Generated at 2022-06-21 11:26:13.534862
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class A:
        a: str

    schema = SchemaF[A](type_=A)
    assert isinstance(schema.load([{'a': 'b'}, {'a': 'c'}]), list)
    assert isinstance(schema.load({'a': 'b'}), A)



# Generated at 2022-06-21 11:26:24.537610
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow
    import typing
    import datetime

    class UnionFieldSchema(marshmallow.Schema):
        f = _UnionField(desc={
            typing.Any: marshmallow.fields.Field(),
            typing.List[typing.Union[int, dict]]: marshmallow.fields.List(marshmallow.fields.Int()),
            datetime.datetime: marshmallow.fields.DateTime(),
            typing.Union[datetime.datetime, int]: marshmallow.fields.Integer(),
            }, cls=None, field=None)

    res = UnionFieldSchema().load({'f': 'a'})
    assert res['f'] == 'a'

    res = UnionFieldSchema().load({'f': [1, '2',  {3: 42}]})

# Generated at 2022-06-21 11:26:34.611831
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    @dataclass
    class Dc:
        x: bool
        y: typing.Optional[int]

    @dataclass_json
    @dataclass
    class Dc1:
        x: bool
        y: typing.Optional[Dc]

    @dataclass_json
    @dataclass
    class Dc2:
        x: bool
        y: Dc1

    @dataclass_json
    @dataclass
    class Dc3:
        x: bool
        y: typing.List[Dc1]


    assert isinstance(build_type(typing.Optional[bool], {}, _ExtendedEncoder, dc_fields(Dc)[1], Dc), fields.Boolean)

# Generated at 2022-06-21 11:26:46.622496
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import config
    @dataclass
    class Article:
        title: str
        authors: list
        year: int

    ArticleSchema = build_schema(Article, (object,), False, False)
    print(ArticleSchema)
    print(ArticleSchema.__mro__)
    print(ArticleSchema.Meta.fields)
    for field in ArticleSchema.Meta.fields:
        print(field)
        print(getattr(ArticleSchema, field))
    article = Article('test', ['Cory Benfield', 'Ian Stapleton Cordasco'], 1981)
    print(article)
    print(ArticleSchema.dump(article))

if __name__ == "__main__":
    test_build_schema()

# Generated at 2022-06-21 11:26:56.607511
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field

    from dataclasses_json import dataclass_json

    from marshmallow import fields as mm_fields

    import enum

    @dataclass_json
    @dataclass
    class A:
        pass

    class MyEnum(enum.Enum):
        A = 1

    @dataclass
    class D(A):
        f1: list = field(metadata={'mm_field': mm_fields.String(required=True)})
        f2: int = field(metadata={'mm_field': mm_fields.Boolean(missing=None)})
        f3: float = field(metadata={'mm_field': mm_fields.Decimal(allow_none=False)})

# Generated at 2022-06-21 11:27:07.361695
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.abc import DataClassJson
    from marshmallow import fields
    from marshmallow_enum import EnumField

    class MyMixin(DataClassJson):
        ...

    @dataclass
    class MyNestedClass(MyMixin):
        x: int

    @dataclass
    class MyNestedClassA(MyNestedClass):
        ...

    @dataclass
    class MyNestedClassB(MyNestedClass):
        ...

    @dataclass
    class MyNestedClassC(MyNestedClass):
        ...

    @dataclass
    class MyNestedClassD(MyNestedClass):
        ...

    @dataclass
    class MyNestedClassE(MyNestedClass):
        ...


# Generated at 2022-06-21 11:27:41.582271
# Unit test for function build_schema
def test_build_schema():
    assert 1 == 1

# Generated at 2022-06-21 11:27:42.917053
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass


# Generated at 2022-06-21 11:27:54.793336
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Book(typing.NamedTuple):
        title: str
        author: str

    class BookSchema(SchemaF[Book]):
        title = fields.Str()
        author = fields.Str()

        @post_load
        def make_book(self, data, **kwargs):  # type: ignore
            return Book(**data)

    books_schema = BookSchema(many=True)
    books_data = [{'title': 'Crime and Punishment', 'author': 'Fyodor Dostoyevsky'},
                  {'title': 'The Idiot', 'author': 'Fyodor Dostoyevsky'}]
    books = books_schema.load(books_data)
    assert books[0].title == 'Crime and Punishment'

# Generated at 2022-06-21 11:28:00.513040
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class A:
        b: str

    class ASchema(SchemaF[A]):
        b = fields.Str()

    assert ASchema().dumps(A('test')) == '{"b": "test"}'
    assert ASchema().dumps([A('test')]) == '[{"b": "test"}]'



# Generated at 2022-06-21 11:28:05.892144
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField(default=None, missing=None, allow_none=True, required=False)
    value = '2020-11-10T11:30:00+00:00'
    assert datetime.fromisoformat(iso_field._deserialize(value=value, attr=None, data=None)) == datetime.fromisoformat(value)


# Generated at 2022-06-21 11:28:07.724199
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp = _TimestampField()
    assert isinstance(timestamp, fields.Field)



# Generated at 2022-06-21 11:28:20.295187
# Unit test for function build_schema
def test_build_schema():

    class Point:
        x: int
        y: int

    class SchemaWithoutAnyFields(Schema):
        pass

    class SchemaInheriting(SchemaWithoutAnyFields):
        x: int

        class Meta:
            fields = ('x',)

    class SchemaInherited(SchemaInheriting):
        y: int

        class Meta:
            fields = ('y',)

    output_schema = build_schema(Point, dotdict(), False, False)

    assert len(output_schema._declared_fields) == 2
    assert isinstance(output_schema._declared_fields['x'], mm.fields.Integer)

    assert len(SchemaWithoutAnyFields._declared_fields) == 0

    assert len(SchemaInheriting._declared_fields) == 1
   

# Generated at 2022-06-21 11:28:29.878114
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Protocol):  # type: ignore
        x: int

    class FooImpl(Foo):
        def __init__(self, x: int):
            self.x = x
    # $ExpectType <FooImpl>
    SchemaF[FooImpl].loads('{"x":1}')


# Generated at 2022-06-21 11:28:33.287853
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def foo(self, obj: typing.Union[typing.List[A], A] = None) -> typing.Union[typing.List[TEncoded], TEncoded]:
            pass

    foo = Foo[int]()
    foo.foo([1, 2])
    foo.foo(1)
    foo.foo()

# Generated at 2022-06-21 11:28:39.186159
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Other:
        test: str = 3

    @dataclass
    class MyClass:
        foo: str
        bar: int = field(default="4")
        other: Other = field(default=Other())

    schema = build_schema(MyClass, [], True, False)
    assert schema.Meta.fields == ('foo', 'bar', 'other')
    assert isinstance(schema.__dict__['foo'], fields.Field)
    assert isinstance(schema.__dict__['bar'], fields.Field)
    assert isinstance(schema.__dict__['other'], fields.Nested)
    assert schema.__dict__['foo'].default is None
    assert schema.__dict__['bar'].default == "4"



# Generated at 2022-06-21 11:29:39.834017
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    from typing import List, Union, Optional

    @dataclass
    class Employee:
        name: str
        id: int


    @dataclass
    class Person:
        name: str
        id: int = field(metadata=dataclasses_json.config(mm_field=fields.Int()))


    @dataclass
    class EmployeeOpt:
        name: str
        id: Optional[int]

    @dataclass
    class PersonOpt:
        name: str
        id: Optional[int] = field(metadata=dataclasses_json.config(mm_field=fields.Int()))

    @dataclass
    class EmployeeUnion:
        name: str
        id: Union[int, str]


# Generated at 2022-06-21 11:29:43.813831
# Unit test for function build_type
def test_build_type():
    assert fields.Mapping == build_type(typing.Mapping, {}, object, object, object)
    assert fields.List == build_type(typing.List, {}, object, object, object)
    assert _TimestampField == build_type(datetime, {}, object, object, object)
    assert fields.Tuple == build_type(typing.Tuple, {}, object, object, object)



# Generated at 2022-06-21 11:29:55.294835
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    try:
        SchemaF()
        assert False
    except NotImplementedError:
        assert True


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass


# Generated at 2022-06-21 11:30:07.101655
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    class ExampleSchema(SchemaF[str]):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        pass

    esch = ExampleSchema()
    assert esch.dump("test") == "test"
    assert esch.dump(["a", "b"]) == ["a", "b"]
    assert esch.dump("test", many=False) == "test"
    assert esch.dump(["a", "b"], many=False) == ["a", "b"]
    assert esch.dumps("test") == '"test"'
    assert esch.dumps(["a", "b"]) == '["a","b"]'
    assert esch.dumps("test", many=False) == '"test"'
    assert esch

# Generated at 2022-06-21 11:30:17.436043
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, mm_field
    @dataclass_json
    @dataclass
    class Cat:
        name: str
        age: int
        weight: float = 10.0
        female: bool = True
        kittens: typing.List[str] = ()
        kitten_ages: typing.List[int] = ()
        kitten_weights: typing.List[float] = ()
        kitten_females: typing.List[bool] = ()
        extra: typing.Dict[str, type(None)] = {}
        extra_int: typing.Dict[str, int] = {}
        extra_str: typing.Dict[str, str] = {}
        extra_float: typing.Dict[str, float] = {}
        extra

# Generated at 2022-06-21 11:30:27.653109
# Unit test for function build_type
def test_build_type():
    import dataclasses
    import marshmallow_dataclass
    from marshmallow import fields
    
    @dataclasses.dataclass
    class ExampleClass:
        x: int
        y: float
    
    @dataclasses.dataclass
    class ExampleClass2:
        x: int
        y: float
    
    @dataclasses.dataclass
    class ExampleClass3:
        x: int
        y: float
    
    @dataclasses.dataclass
    class ExampleClass4:
        x: int
        y: float
    
    @dataclasses.dataclass
    class ExampleClass5:
        x: int
        y: float
    
    @dataclasses.dataclass
    class ExampleClass6:
        x: int
        y: float
    

# Generated at 2022-06-21 11:30:29.680701
# Unit test for constructor of class _UnionField

# Generated at 2022-06-21 11:30:36.057548
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, fields
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields as mm_fields
    import typing

    @dataclass
    class BaseClass(DataClassJsonMixin, datetime=datetime):
        dummy: typing.List[int]

    @dataclass
    class TestClass(BaseClass):
        string_field: str
        int_field: int = 10
        optional_field: typing.Optional[int] = ...
        union_field: typing.Union[int, str] = ...
        optional_union_field: typing.Optional[typing.Union[int, None]] = ...
        recursive_field: typing.Optional[typing.Optional[typing.Optional[int]]] = ...


# Generated at 2022-06-21 11:30:36.614608
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass

# Generated at 2022-06-21 11:30:38.965351
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class Test:
        pass

    assert build_schema(Test, TestMixin, False, False) is not None

# Generated at 2022-06-21 11:32:51.744064
# Unit test for function build_schema
def test_build_schema(): # pragma: no cover
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema

    @dataclass(eq=True, frozen=True)
    class TestMe:
        pass

    try:
        build_schema(TestMe, SchemaOpts, infer_missing=True, partial=False)
    except NotImplementedError:
        pass
    else:
        assert False

# Generated at 2022-06-21 11:32:52.434882
# Unit test for function build_type
def test_build_type():
    assert True



# Generated at 2022-06-21 11:32:57.936070
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = dict(name="Zed", age=42, spooky=True)
    class UserSchema(SchemaF[dict]):
        name = fields.String()
        age = fields.Integer()
        spooky = fields.Boolean()
    user_serialized: str = UserSchema().dumps(a)
    assert isinstance(user_serialized, str)
    user_deserialized = UserSchema().loads(user_serialized)
    assert isinstance(user_deserialized, dict)
    assert user_deserialized == a



# Generated at 2022-06-21 11:33:01.950446
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """
    Unit test for the SchemaF class.
    """
    with pytest.raises(NotImplementedError):
        SchemaF()


try:
    from typing import Literal  # type: ignore
except ImportError:
    from typing_extensions import Literal  # type: ignore



# Generated at 2022-06-21 11:33:06.923363
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Foo:
        a: int = 10
        b:str = None

    fs = build_schema(Foo, None, False, False)
    assert hasattr(fs, 'Meta')
    assert hasattr(fs, 'a')
    assert hasattr(fs, 'b')
    assert hasattr(fs, 'make_foo')



# Generated at 2022-06-21 11:33:10.986376
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    _ = SchemaF.loads  # noqa


# Generated at 2022-06-21 11:33:20.526351
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow as mm
    import marshmallow.fields as mmf

    class S(SchemaF[typing.Dict[str, typing.Any]]):
        a = mmf.Int()

    class T(SchemaF[typing.Dict[str, typing.Any]]):
        b = mmf.Int()

    s = S()
    assert s.dump({"a": 1}) == {"a": 1}
    assert s.dump({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    t = T()
    assert t.dump({"b": 1}) == {"b": 1}
    assert t.dump({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    c = mm.Nested(T())
    assert c.dump

# Generated at 2022-06-21 11:33:22.146772
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert True

# Generated at 2022-06-21 11:33:33.171411
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    from marshmallow import fields
    from dataclasses_json import dataclass_json
    from dataclasses_json.schema import Schema
    from .utils import _is_new_type

    @dataclass_json
    @dataclass
    class A:
        a: Union[int, str]

    field_a = A.__dataclass_fields__['a']
    assert _is_new_type(type(field_a)) is False
    un_field_a = Schema._get_field(field_a, True, A)
    assert _is_new_type(type(un_field_a)) is False
    assert isinstance(un_field_a, fields.Field) is True

# Generated at 2022-06-21 11:33:39.957383
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class Foo:
        bar: str

    schema = SchemaF[Foo]()

    foo = Foo(bar='baz')
    data = {'bar': 'baz'}  # type: TEncoded

    assert schema.dump(foo) == data
    assert schema.dumps(foo) == json.dumps(data)
    assert schema.dump([foo]) == [data]
    assert schema.dumps([foo]) == json.dumps([data])
