

# Generated at 2022-06-21 11:24:30.414002
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class TestSchema(SchemaF[int]):
        a = fields.Int()
    TestSchema().loads('{"a": 1}')
    TestSchema().loads(b'{"a": 1}')
    TestSchema().loads(bytearray(b'{"a": 1}'))



# Generated at 2022-06-21 11:24:35.914681
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class Test:
        field: typing.Union[int, str]

    test_schema = _ExtendedEncoder.schema_base()
    assert isinstance(test_schema.fields['field'], _UnionField)
    assert len(test_schema.fields['field'].desc) == 2



# Generated at 2022-06-21 11:24:45.804010
# Unit test for function build_type
def test_build_type():
    @dataclass
    class A:
        a: int

    class B(mixin):
        a: int
        b: int

    @dataclass
    class C(mixin):
        a: int
        b: str
        c = 'default value'

    f = fields.Field()
    g = fields.Field()
    h = fields.Field()

    assert build_type(A, {}, A, f, A) == fields.Nested(A.schema(), f)
    assert build_type(B, {}, B, g, B) == fields.Nested(B.schema(), g)
    assert build_type(C, {}, C, h, C) == fields.Nested(C.schema(), h)



# Generated at 2022-06-21 11:24:52.384958
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2007, 1, 10, 15, 30, 45, 123456), None, None) == "2007-01-10T15:30:45.123456"
    assert _IsoField()._deserialize("2007-01-10T15:30:45.123456", None, None) == datetime(2007, 1, 10, 15, 30, 45, 123456)


# Generated at 2022-06-21 11:25:01.984196
# Unit test for constructor of class _UnionField
def test__UnionField():
    # test a simple case with a single union type
    from typing import Union
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: Union[str, int]
    field = dc_fields(A)['b']
    field_ = _UnionField(field.type.__args__, A, field)

    assert field_.desc[str] == fields.Field
    assert field_.desc[int] == fields.Integer

    # test a nested union type case
    @dataclass
    class B:
        a: Union[str, int]
        b: Union[str, int]
    field = dc_fields(B)['b']
    field_ = _UnionField(field.type.__args__, B, field)

# Generated at 2022-06-21 11:25:06.139759
# Unit test for constructor of class _UnionField
def test__UnionField():
    desc = {
        int: fields.Integer(),
        bool: fields.Boolean()
    }
    field = _UnionField(desc, None, None, allow_none=True)
    assert field._serialize(None, None, None, allow_none=True) is None
    assert field._serialize(1, None, None) == 1
    assert field._serialize(True, None, None) is True



# Generated at 2022-06-21 11:25:07.090624
# Unit test for constructor of class SchemaF
def test_SchemaF():
    raise NotImplementedError()



# Generated at 2022-06-21 11:25:10.217798
# Unit test for function build_type
def test_build_type():
    assert str(build_type(Enum, {}, None, None, None)) == "EnumField(enum=<enum 'Enum'>, by_value=True)"


# Generated at 2022-06-21 11:25:20.828130
# Unit test for function build_schema
def test_build_schema():
    class User(BaseModel):
        name: str
        age: int = 0

    class Pet(BaseModel):
        name: str

    class Human(User):
        pet: Pet

    class PetSchema(Schema):
        class Meta:
            fields = ('name',)

    schema = build_schema(User, None, False, False)
    isinstance(schema(only=('name',)), Schema)

    schema = build_schema(Human, None, False, False)
    isinstance(schema(partial=('name',)), Schema)
    assert schema.Meta.fields == ('name', 'pet', 'age')

    schema = build_schema(User, None, True, False)
    assert schema.Meta.fields == ('name', 'age')


# Generated at 2022-06-21 11:25:29.540784
# Unit test for function build_type
def test_build_type(): # pragma: no cover
    from typing import List, Optional, Union

    from dataclasses import dataclass
    from marshmallow import Schema
    from marshmallow_enum import EnumField

    @dataclass
    class DCLS:
        field: int

    @dataclass
    class CLS:
        field: int
        field_dcls: DCLS
        field_opt_dcls: Optional[DCLS]
        field_union: Union[str, int]
        field_union_dcls: Union[str, DCLS]
        field_union_dcls2: Union[int, DCLS]
        field_list: List[DCLS]

    class CLS_MIXIN:
        @classmethod
        def schema(cls):
            return Schema

    CLS.schema

# Generated at 2022-06-21 11:25:47.945073
# Unit test for function schema
def test_schema():
    cls = dataclasses.dataclass(frozen=True)(
        lambda: 0,
        metadata={
            'dataclasses_json': {
                'mm_field': fields.String(validate=validate.Length(min=1))
            }
        }
    )
    mixin = dataclasses_json.Mixin
    infer_missing = dataclasses_json.core.FieldOptions(False, False)
    schema(cls, mixin, infer_missing)



# Generated at 2022-06-21 11:25:56.728999
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.TypedDict):
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    foo_schema = FooSchema()

    foo_instance = Foo(bar=1)
    foo_instance_in_list = [foo_instance, foo_instance]

    foo_json = foo_schema.dumps(foo_instance)
    assert foo_json == '{"bar": 1}'
    foo_json = foo_schema.dumps(foo_instance, many=False)
    assert foo_json == '{"bar": 1}'
    foo_json = foo_schema.dumps(foo_instance_in_list)
    assert foo_json == '[{"bar": 1}, {"bar": 1}]'
    foo_json = foo_

# Generated at 2022-06-21 11:26:09.970991
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import MmSchema
    from marshmallow import fields as mmfields

    @dataclass_json
    @dataclass
    class SomeData:
        not_marshmallow: str
        name: str


    @dataclass_json(mm_schema=MmSchema)
    @dataclass
    class Data:
        not_marshmallow: SomeData
        name: str
        mm: mmfields.Str


    @dataclass_json(mm_schema=MmSchema)
    @dataclass
    class DataSchema:
        field: Data
        name: str = "default"
        mm: mmfields.Str = "default"


# Generated at 2022-06-21 11:26:18.046295
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List

    class MyData:
        name: str
        count: int

    class MyDataSchema(Schema):
        name = fields.Str()
        count = fields.Int()

    class MyData2:
        lst: List[MyData]

    class MyData2Schema(Schema):
        lst = fields.Nested(MyDataSchema, many=True)

    m = MyData2()
    m.lst.append(MyData())
    m.lst[0].name = "test"
    m.lst[0].count = 3
    m2s = MyData2Schema()
    assert m2s.dumps(m) == b'{"lst":[{"name":"test","count":3}]}'



# Generated at 2022-06-21 11:26:23.817961
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # https://stackoverflow.com/a/53202690/7817792
    _SchemaF: typing.Type['SchemaF'] = SchemaF
    schema = _SchemaF(strict=True)
    s = schema.dump([1, 2])
    assert s == [1, 2]

    # @typing.overload
    # def foo(a: int) -> int:
    #     return a
    #
    # @typing.overload
    # def foo(a: str) -> str:
    #     return a
    #
    # def foo(a: typing.Union[int, str]) -> typing.Union[int, str]:
    #     pass
    #
    # foo('foo')
    # foo(1)

    # stackoverflow.com/a/53182838

# Generated at 2022-06-21 11:26:30.708558
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class UserSchema(SchemaF):
        id = fields.Int(load_from='id', dump_to='id')
        email = fields.Str()
        created_at = fields.Time()

    user = User(1, 'test@example.com',
                datetime(2018, 1, 14, 17, 29, 49, tzinfo=timezone.utc))
    user_json_str = UserSchema().dumps(user)
    assert user_json_str == """{"id": 1, "email": "test@example.com", "created_at": "2018-01-14T17:29:49Z"}"""



# Generated at 2022-06-21 11:26:42.852198
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class Annotation:
        a: List[int]
        b: int

    marsh = Schema(Annotation)
    assert list(marsh.dump(Annotation([1, 2, 3], 4)).keys()) == ['a', 'b']
    assert marsh.dump(Annotation([1, 2, 3], 4))['a'] == [1, 2, 3]
    assert marsh.dump(Annotation([1, 2, 3], 4))['b'] == 4
    assert marsh.dump(Annotation([1, 2, 3], 4), many=False)['a'] == [1, 2, 3]
    assert marsh.dump(Annotation([1, 2, 3], 4), many=False)['b'] == 4


# Generated at 2022-06-21 11:26:53.751754
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    import dataclasses
    import pytest

    @dataclasses.dataclass
    class G:
        mm_field = fields.String(attribute="a")
        a: int

    @dataclasses.dataclass
    class F:
        mm_field: fields.Field = G
        a: int
        b: int

    @dataclasses.dataclass
    class E:
        a: str
        b: int = 5

    @dataclasses.dataclass
    class D:
        a: typing.Dict[bool, str] = {}
        b: typing.List[int] = [1, 2, 3]
        c: typing.Tuple[bool, int] = (True, 1)
        d: typing.Callable = lambda x: x + 1
        e

# Generated at 2022-06-21 11:26:59.518077
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        class Foo:
            pass

        schema = SchemaF[Foo]()
        assert schema.__class__.__name__ == 'Schema'
        assert schema.__qualname__ == 'Schema'
        assert schema.__module__ == 'marshmallow.schema'
    else:
        assert 'mypy' in sys.modules
        assert 'dataclasses' in sys.modules
        assert 'marshmallow' not in sys.modules
        assert 'marshmallow.schema' == 'Schema'
        assert 'A' == 'Foo'



# Generated at 2022-06-21 11:27:10.321407
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        def __init__(self, value: A):
            self.value = value

    @dataclasses_json.dataclass_json
    class Bar:
        a: str
        b: int

    @dataclasses_json.dataclass_json
    class Bar1(Bar):
        c: bool

    SchemaF[Bar]()  # type: ignore
    SchemaF[Foo[Bar]]()  # type: ignore
    SchemaF[Foo[Bar1]]()  # type: ignore
    SchemaF[Foo[str]]()  # type: ignore
    SchemaF[Bar][Bar1]()  # type: ignore  # noqa
    SchemaF[Bar1]()  # type: ignore
    SchemaF['Bar']()

# Generated at 2022-06-21 11:27:35.943618
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields, pre_load

    @pre_load
    def pre_load(self, data):
        data['name'] = data['name'].upper()
        return data

    class UserSchemaV2(SchemaF[UserV2]):
        name = fields.Str()
        email = fields.Email()

        pre_load = pre_load

        @post_load
        def make_user(self, data, **kwargs):
            return UserV2(**data)

    schema = UserSchemaV2()

    user = schema.load(
        {'name': 'Monty', 'email': 'monty@python.org'})
    assert user.name == 'MONTY'
    assert user.email == 'monty@python.org'


# Generated at 2022-06-21 11:27:47.632605
# Unit test for constructor of class SchemaF
def test_SchemaF():
    import marshmallow  # type: ignore
    from marshmallow import fields as mm
    from marshmallow.exceptions import ValidationError

    class UserSchema(SchemaF[A]):
        id = mm.Integer()
        name = mm.String()
        date = mm.DateTime()
        friends = mm.List(mm.Nested("self"))

    u = UserSchema()
    assert u.dump([{'id': 1, 'name': 'Fred', 'date': datetime.now()},
                   {'id': 2, 'name': 'Jane'}]) == \
        [{'id': 1, 'name': u'Fred', 'date': datetime.now().isoformat()},
         {'id': 2, 'name': u'Jane'}]

# Generated at 2022-06-21 11:27:59.294033
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass

    @dataclass
    class A:
        val: int

    @dataclass
    class B:
        val: int

    schema = SchemaF.infer(_A)

    instance = schema.load([{'val': 1}, {'val': 2}])
    assert len(instance) == 2
    for e in instance:
        assert isinstance(e, _A)

    instance = schema.load({'val': 1})
    assert isinstance(instance, _A)

    instance = schema.load({'val': 1}, many=True)
    assert isinstance(instance[0], _A)

    instance = schema.load({'val': 1}, many=False)
    assert isinstance(instance, _A)

    schemab = SchemaF.infer(_B)

# Generated at 2022-06-21 11:28:05.152467
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class C(metaclass=dataclasses_json.DataClassJsonMixin):
        foo: int
        bar: int = 2


# Generated at 2022-06-21 11:28:08.960466
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF[int]()
    assert schema.dumps([1, 2, 3]) == '[1, 2, 3]'
    assert schema.dumps(42) == '42'
    assert schema.dumps([42]) == '[42]'
    assert schema.dumps((42,)) == '[42]'
    assert schema.dumps({"result": 42}) == '{"result": 42}'


# Generated at 2022-06-21 11:28:18.656685
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema = SchemaF[int]()
    data = [1, 2, 3]
    expected = [1, 2, 3]
    result = schema.loads(data, many=True)
    assert result == expected


# Generated at 2022-06-21 11:28:23.463106
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.fromtimestamp(1517414400), "datetime_field", None) == 1517414400
    assert field._deserialize(1517414400, "datetime_field", None) == datetime.fromtimestamp(1517414400)


# Generated at 2022-06-21 11:28:29.702610
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Inner:
        a: int

    @dataclass
    class A:
        b: int
        c: int = field(metadata={'dataclasses_json': {'mm_field': fields.Bool()}})
        d: Inner = field(metadata={'dataclasses_json': {'mm_field': fields.Bool()}})

    assert list(schema(A, 'LOWER_CAMEL', False).keys()) == ['b', 'c', 'd']


# Generated at 2022-06-21 11:28:35.622745
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from typing import Dict, List

    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test1:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class Test2:
        a: Test1
        b: float
        c: Test1

    @dataclass_json
    @dataclass
    class Main:
        a: Test1
        b: Test2
        c: List[Test1]
        d: List[Test1]
        e: Dict[str, Test2]
        f: Dict[str, Test2]


# Generated at 2022-06-21 11:28:46.306814
# Unit test for constructor of class SchemaF
def test_SchemaF():
    def test_one(obj: A, many: bool = None) -> TEncoded:
        return SchemaF[A]().dump(obj, many)

    def test_multi(obj: typing.List[A], many: bool = None) -> typing.List[
        TEncoded]:  # type: ignore
        return SchemaF[A]().dump(obj, many)

    assert test_one([1, 2, 3]) == [1, 2, 3]
    assert test_one({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    assert test_multi([[1, 2, 3], [4, 5, 6]]) == [[1, 2, 3], [4, 5, 6]]

# Generated at 2022-06-21 11:29:17.611153
# Unit test for function schema
def test_schema():
    from marshmallow import Schema

    from dataclasses import dataclass
    import typing
    import uuid
    import datetime
    import decimal

    @dataclass
    class SimpleClass1:
        foo: str

    @dataclass
    class SimpleClass2:
        bar: int

    @dataclass
    class SimpleClass3:
        baz: typing.List[str]
        boo: typing.Dict[str, int]

    @dataclass
    class SimpleClass4:
        baa: datetime.datetime
        bee: datetime.time

    @dataclass
    class SimpleClass5:
        type: 'SimpleClass1'
        baa: datetime.datetime
        bee: datetime.time

    @dataclass
    class SimpleClass6:
        type: typing.Union

# Generated at 2022-06-21 11:29:18.721449
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField(None, None, None, None, None)



# Generated at 2022-06-21 11:29:22.444682
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @_user_overrides_or_exts(
        extra=EnumField,
        unknown='EXCLUDE',
        json_module=None,
        encoder=_ExtendedEncoder,
        use_decimal=True)
    class MySchemaF(SchemaF[int]):
        pass



# Generated at 2022-06-21 11:29:26.806019
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class PersonSchema(SchemaF[Person]):
        name = fields.String()
    assert PersonSchema.loads(b'{}') == Person('', 0)

# Generated at 2022-06-21 11:29:36.018746
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert isinstance(SchemaF.load, typing.Callable)  # noqa: E721


if sys.version_info >= (3, 7):
    class SchemaX(SchemaF[A]):
        def __init__(self, cls, skip_defaults=False, config=None) -> None:
            if not is_dataclass(cls):
                raise ValueError(
                    'Expected dataclass (got type {})'.format(cls))
            self.cls = cls
            self.base_fields, self.cos_fields, self.co_fields, self.field_names, \
            self.dump_fields, self.extra_dump_fields = _decode_dataclass(
                cls, config=config)
            super().__init__(*args, **kwargs)

# Generated at 2022-06-21 11:29:40.262733
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Test(typing.Generic[A]):
        def func(
            self,
            x: SchemaF[A],
        ):
            x.dump(None)
            x.dumps(None)
            x.load(None)
            x.loads(None)

    Test[int].func(None, None)
    Test[list[int]].func(None, None)
    Test[typing.List[int]].func(None, None)
    assert Test.func(None, None)



# Generated at 2022-06-21 11:29:46.643343
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass

    from marshmallow import Schema, post_load
    from marshmallow.fields import String

    @dataclass
    class Foo:
        s: str

    class FooSchema(SchemaF[Foo]):
        s = String()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    f = FooSchema().load({"s": "Hello"})
    assert f.s == "Hello"


if sys.version_info >= (3, 7):
    SchemaF[int]  # Just checking to see if it works as intended
    SchemaF[int].load  # Just checking to see if it works as intended


# Generated at 2022-06-21 11:29:57.773654
# Unit test for function build_type
def test_build_type():
    # Test if build_type correctly converts all the types
    class EmptyMixin:
        pass

    class C:
        pass
    dc_fields(C)

    class C2(EmptyMixin):
        pass
    dc_fields(C2)

    class C3:
        @property
        def a(self):
            return self.b

    dc_fields(C3)

    def f():
        pass

    class A:
        f: typing.Callable
        c: C
        c2: C2
        c3: C3
        s: typing.List[str]
        l: typing.List[int]
        i: typing.List[int]
        b: typing.List[bool]
        fl: typing.List[float]
        u: typing.List[UUID]

# Generated at 2022-06-21 11:29:59.118875
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-21 11:30:10.121582
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    from marshmallow import Schema

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        b: Union[A, B]

    @dataclass_json
    class ASchema(Schema):
        class Meta:
            target = A

    @dataclass_json
    class BSchema(Schema):
        class Meta:
            target = B

    @dataclass_json
    class CSchema(Schema):
        class Meta:
            target = C

    # Test 1: Serialize value of dataclass
    b1 = B()
    d1 = CSchema().dump(C(b=b1))
    assert d1

# Generated at 2022-06-21 11:31:07.090147
# Unit test for function build_type
def test_build_type():
    from dataclasses_json import dataclass_json, config
    from .test_common import test_field_types
    from .test_generic import generic_schema_test

    def test_build_type(test_field_types):
        for field in test_field_types:
            for mm_field, mm_field_kwargs in field.marshmallow_fields:
                yield check_build_type, field, mm_field, mm_field_kwargs

    def check_build_type(field, mm_field, mm_field_kwargs):
        mm_field_kwargs = mm_field_kwargs or {}
        mm_field_kwargs.update({"required": field.metadata.required})

# Generated at 2022-06-21 11:31:19.950461
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm

    class MyDc(typing.Generic[A]):
        def __init__(self, data: A):
            self.data = data


    class MySchemaF(mm.Schema, typing.Generic[A]):
        class Meta:
            ordered = True

        data = mm.fields.Field()

        @post_load
        def make_object(self, data, **kwargs):
            return MyDc[A](data['data'])  # type: ignore

    schema = MySchemaF[int]()

    res = schema.dumps([{'data': 1}, {'data': 2}])
    assert res == '[{"data": 1}, {"data": 2}]'
    res = schema.dumps({'data': 2})
    assert res == '{"data": 2}'

# Generated at 2022-06-21 11:31:27.847328
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Serialize
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None)

    nullable_field = _TimestampField(required=False)
    assert not nullable_field._serialize(None, None, None)

    # Deserialize
    assert field._deserialize(datetime.now().timestamp(), None, None)

    nullable_field = _TimestampField(required=False)
    assert not nullable_field._deserialize(None, None, None)



# Generated at 2022-06-21 11:31:38.859875
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import json
    from typing import List, Dict
    class Foo:
        def __init__(self, bar: int):
            self.bar = bar
    class FooSchema(SchemaF[Foo]):
        bar = fields.Integer()

    foo = Foo(bar=1)
    s = FooSchema()
    assert json.loads(s.dumps(foo)) == {"bar": 1}

    # Should work even when dumping a list
    foos = [Foo(bar=i) for i in range(1, 3)]
    assert json.loads(s.dumps(foos, many=True)) == [{"bar": i} for i in range(1, 3)]
    assert json.loads(s.dumps(foos)) == [{"bar": i} for i in range(1, 3)]
    #

# Generated at 2022-06-21 11:31:41.772764
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF.dump([1], True) == [1]
    assert SchemaF.dump({"a": 1}, False) == {"a": 1}
test_SchemaF_dump()

# Generated at 2022-06-21 11:31:46.662736
# Unit test for function build_schema
def test_build_schema():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        x: int


    s = build_schema(Test, object, False, False)
    assert s.__name__ == 'TestSchema'
    assert s().dump({'x': 1}) == {'x': 1}



# Generated at 2022-06-21 11:31:54.301157
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.mm import MMSchema


    @dataclass
    class MyClass(DataClassJsonMixin):
        x: int
        y: float
        z: List[str]


    MyClass.schema()
    assert type(MyClass.schema()) is MMSchema
    assert len(MyClass.schema().fields.keys()) == 3



# Generated at 2022-06-21 11:32:03.396867
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    pass


# Generated at 2022-06-21 11:32:07.819984
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[int], {}, "", "", "")
    assert build_type(typing.Optional[int], {}, "", "", "")
    assert build_type(typing.Union[int, float], {}, "", "", "")
    assert build_type(UUID, {}, "", "", "")
    assert build_type(Decimal, {}, "", "", "")
    assert build_type(datetime, {"allow_none": True}, "", "", "")
    assert build_type(datetime, {}, "", "", "")



# Generated at 2022-06-21 11:32:15.810216
# Unit test for function build_schema
def test_build_schema():
    from typing import List
    from dataclasses import dataclass, asdict
    @dataclass
    class C:
        id: int
        name: str
    f = build_schema(C, None, True, None)
    print(f.Meta.fields)
    assert f.Meta.fields == ('id', 'name')
    print (asdict(f.load({"id": 1, "name": "a"})))
    assert asdict(f.load({"id": 1, "name": "a"})) == {"id": 1, "name": "a"}
