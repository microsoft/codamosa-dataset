

# Generated at 2022-06-21 11:24:18.474423
# Unit test for method load of class SchemaF

# Generated at 2022-06-21 11:24:29.212554
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Test _serialize and _deserialize methods
    test_obj_1 = _IsoField()
    # Test serialize
    test_obj_1._serialize(None, "", object(), many=False)
    test_obj_1._serialize(datetime.fromisoformat("2018-7-1T1:41:53"), "", object(), many=False)
    test_obj_1.required = True
    test_obj_1._serialize(datetime.fromisoformat("2018-7-1T1:41:53"), "", object(), many=False)
    try:
        test_obj_1._serialize(None, "", object(), many=False)
    except ValidationError:
        pass
    test_obj_1.required = False
    # Test deserialize
    test_obj_1

# Generated at 2022-06-21 11:24:39.315248
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    _: typing.List[TEncoded] = SchemaF[int].dump([1,2,3])
    _: typing.List[TEncoded] = SchemaF[int].dump([1,2,3], many=True)
    _: typing.List[TEncoded] = SchemaF[int].dump([1,2,3], many=False)
    _: TEncoded = SchemaF[int].dump(1)
    _: TEncoded = SchemaF[int].dump(1, many=True)
    _: TEncoded = SchemaF[int].dump(1, many=False)
    _: typing.List[TEncoded] = SchemaF[int]().dump([1,2,3])
    _: typing.List[TEncoded] = SchemaF[int]().dump

# Generated at 2022-06-21 11:24:41.734358
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = _TimestampField()
    dt = datetime.now()
    assert dt == ts._deserialize(dt.timestamp())


# Generated at 2022-06-21 11:24:43.446333
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Test for constructor _IsoField
    value = _IsoField()
    assert value


# Generated at 2022-06-21 11:24:53.731193
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def mock_schema_dumps(
        self: Schema,
        obj: TOneOrMulti,
        many: bool = None,
    ) -> str:
        if many is None:
            many = False
        return 'foo'

    # This is a workaround to mypy not being capable of handling the dynamic creation
    # of a method.
    # The library dataclasses_json uses a class of type
    # typing.Type[SchemaF[typing.Any]] in order to dynamically create a new
    # class.
    # Mypy sees this as the creation of a class of type SchemaF[typing.Any] and
    # when we try to assign the mock dumps method to it, mypy complains that the
    # type of the method is incompatible with the type of the class.
    # As a workaround, we define this wrapper class

# Generated at 2022-06-21 11:24:57.970965
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class IntSchema(SchemaF[int]):
        # noinspection PyMissingConstructor
        def __init__(self): pass

    value: int = 5
    result = IntSchema(many=True).dump([value])
    assert result == [{'val': 5}]



# Generated at 2022-06-21 11:25:00.640388
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(
        desc={datetime: _IsoField()},
        cls=datetime,
        field=None
    )



# Generated at 2022-06-21 11:25:10.876799
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    """
    This is a test if class SchemaF is correctly implemented.
    This test cannot be run if the class is not correctly implemented.
    """

    class ListDC(typing.List[int]):
        pass

    class TupleDC(typing.Tuple[int, str, float]):
        pass

    class Test(typing.Protocol):
        pass

    class TestDC(typing.Generic[Test]):
        def __init__(self, obj: Test):
            self.obj = obj

    class TestDC1(TestDC[int]):  # type: ignore
        def __init__(self, obj: int):
            self.obj = obj


# Generated at 2022-06-21 11:25:21.382689
# Unit test for function build_schema
def test_build_schema():
    from marshmallow.fields import Dict, Tuple, List, fields
    f = build_schema(A, None, False, False)
    assert type(f.Meta) is type
    assert f.Meta.fields == tuple()
    assert f.dumps is Schema.dumps
    assert isinstance(f.make_a, Callable)
    assert isinstance(f.dataclass_json_config, fields.Field)
    assert isinstance(f.a, fields.Field)
    f = build_schema(B, None, False, False)
    assert type(f.Meta) is type
    assert f.Meta.fields == ('a', 'b', 'c', 'd')
    assert f.dumps is Schema.dumps
    assert isinstance(f.make_b, Callable)
    assert isinstance

# Generated at 2022-06-21 11:25:44.262368
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF(unknown='raise').dumps(['1'], many=True) == "['1']"
    assert SchemaF(unknown='raise').dumps(['1'], many=False) == "['1']"
    assert SchemaF(unknown='raise').dumps('1', many=True) == "'1'"
    assert SchemaF(unknown='raise').dumps('1', many=False) == "'1'"
    assert SchemaF(unknown='raise').dumps(1, many=True) == "1"
    assert SchemaF(unknown='raise').dumps(1, many=False) == "1"
    assert SchemaF(unknown='raise').dumps([], many=True) == "[]"
    assert SchemaF(unknown='raise').dumps([], many=False) == "[]"


# Generated at 2022-06-21 11:25:54.239978
# Unit test for function schema
def test_schema():
    import marshmallow as ma
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class UserSchema(object):
        name: str
        age: int

        @classmethod
        def schema(cls):
            return SchemaType.schema_cls(cls, schema(cls, cls, infer_missing=True))


    @dataclass_json
    @dataclass
    class Person(UserSchema):
        age: int = None


    @dataclass_json
    @dataclass
    class TestSchema(object):
        name: str = None
        optional: typing.Optional[float] = None

# Generated at 2022-06-21 11:26:00.823951
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF[typing.List[int]].load([{"x": "1"}, {"x": "2"}], many=True) == [{"x": "1"}, {"x": "2"}]
    assert SchemaF[typing.List[int]].load({"x": "1"}) == [{"x": "1"}]

# Generated at 2022-06-21 11:26:01.613620
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass

# Generated at 2022-06-21 11:26:13.784933
# Unit test for function build_schema
def test_build_schema():
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class User:
        username: str
        is_active: bool = True
        number_of_orders: int = 0
        profile: typing.Optional['Profile'] = None

    @dataclass
    class Profile:
        first_name: str
        last_name: str
        orders: typing.List['Order'] = field(default_factory=list)

    @dataclass
    class Order:
        items: typing.List[typing.Any] = field(default_factory=list)
        status: str = 'pending'

    UserSchema = build_schema(User, None, None, None)

# Generated at 2022-06-21 11:26:15.994284
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass
    MySchema(many=True).dumps([{'a': 'b'}])


# Generated at 2022-06-21 11:26:26.713833
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str
        email: str

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()

    user = User(name="John Doe", email="john@doe.com")
    user_serialized = UserSchema().dumps(user)
    assert user_serialized == '{"name": "John Doe", "email": "john@doe.com"}'

    users = [user, user]
    users_serialised = UserSchema().dumps(users)

# Generated at 2022-06-21 11:26:37.084248
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    assert build_type(int, {'x': 5}, int, mm.Field(), int)._class_ == mm.fields.Int
    assert build_type(float, {'x': 5}, int, mm.Field(), int)._class_ == mm.fields.Float
    assert build_type(bool, {'x': 5}, int, mm.Field(), int)._class_ == mm.fields.Bool
    assert build_type(bool, {'x': 5, 'allow_none': True}, int, mm.Field(), int)._class_ == mm.fields.Bool
    assert build_type(int, {'x': 5, 'allow_none': True}, int, mm.Field(), int)._class_ == mm.fields.Int



# Generated at 2022-06-21 11:26:38.295977
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-21 11:26:43.669246
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    _SchemaF = SchemaF[int]  # type: ignore
    s = _SchemaF()  # type: ignore
    assert s.dumps([1, 2, 3]) == '[1, 2, 3]'
    assert s.dumps(1) == '1'



# Generated at 2022-06-21 11:26:59.527108
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class SimpleClass:
        def __init__(self, name: str):
            self.name = name

    schema = SchemaF[SimpleClass](type_='object', properties={'name': {'type': 'string'}})

    assert schema.loads('{"name": "Joe"}') == {'name': 'Joe'}  # type: ignore

# Generated at 2022-06-21 11:27:01.394883
# Unit test for function build_schema
def test_build_schema():
    """
    Return the Schema instance
    :return: Schema
    """
    build_schema()

# Generated at 2022-06-21 11:27:12.381705
# Unit test for function schema
def test_schema():
    from dataclasses_json.core import _get_dataclass_fields
    from dataclasses_json.mm import DataclassJSONMixin
    from dataclasses import dataclass, field

    @dataclass
    class User(DataclassJSONMixin):
        name: str
        uid: int = field(metadata={'dataclasses_json': {}})

    assert schema(User, DataclassJSONMixin, False) == \
        {'name': fields.Str(required=True,
                            data_key='name',
                            error_messages={'required': 'Field is required.'}),
         'uid': fields.Int(default=0,
                           data_key='uid',
                           error_messages={'required': 'Field is required.'})
         }


# Generated at 2022-06-21 11:27:13.496562
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF[str]


# Generated at 2022-06-21 11:27:17.212482
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow.fields import Field
    from marshmallow import Schema

    class DataSchema(Schema):
        f = Field()

    assert type(DataSchema().load({"f": "f"})) == dict



# Generated at 2022-06-21 11:27:24.234237
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    @dataclass_json()
    @dataclass
    class X:
        field: str

    class Y(Schema):
        field = fields.Str()

    class Z(SchemaF[X]):
        field = fields.Str()

    dump1 = Y().dump(X('x'), many=False)
    dump2 = Z().dump(X('x'))
    assert dump1 == dump2

    dmp1 = Y().dumps(X('x'), many=False)
    dmp2 = Z().dumps(X('x'))
    assert dmp1 == dmp2

    assert Z().dump([X('x')], many=True) == [{'field': 'x'}]

# Generated at 2022-06-21 11:27:24.993083
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert False



# Generated at 2022-06-21 11:27:27.446217
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None)



# Generated at 2022-06-21 11:27:34.544987
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class User:
        username: str
        age: int = None

    @dataclass
    class User2(User):
        is_member: bool = False

    @dataclass
    class User3(User2):
        phone_number: str = None
        address: str = None
    
    assert issubclass(build_schema(User, _MixIn, False, False), Schema)



# Generated at 2022-06-21 11:27:35.175345
# Unit test for function schema
def test_schema():
    pass



# Generated at 2022-06-21 11:28:05.358887
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Person:
        name: str = 'John'
        age: int = 18
        is_adult: bool = False

    assert (schema(Person, MetadataMixin, infer_missing=True) == {
        'name': fields.String(default='John'),
        'age': fields.Integer(default=18),
        'is_adult': fields.Boolean(default=False),
    })



# Generated at 2022-06-21 11:28:11.763259
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().deserialize("2019-02-21T05:19:11.511000") == datetime.fromisoformat("2019-02-21T05:19:11.511000")
    assert _IsoField().serialize(datetime.fromisoformat("2019-02-21T05:19:11.511000")) == "2019-02-21T05:19:11.511000"


# Generated at 2022-06-21 11:28:23.817344
# Unit test for function schema
def test_schema():
    """to run it: python -c "import dataclasses_json.marshmallow_; dataclasses_json.marshmallow_.test_schema()" """
    from dataclasses import dataclass
    from typing import Optional, List, TypedDict, Union, cast

    @dataclass
    class Map(TypedDict):
        a: int
        b: str

    @dataclass
    class User:
        name: str
        email: str
        friends: Optional[List[str]]
        info: Union[str, int, Map]

    print(schema(User, None, True))

    @dataclass
    class User2:
        name: str
        email: str
        friends: Optional[str]
        info: Union[str, int, Map]


# Generated at 2022-06-21 11:28:26.107983
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert(_IsoField() is not None)
    assert(_IsoField(required=True) is not None)


# Generated at 2022-06-21 11:28:33.344863
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class A:
        x: int
        y: str

    assert SchemaF[List[A]].dump(A(42, 'foo')) == {'x': 42, 'y': 'foo'}
    assert SchemaF[List[A]].dump([A(42, 'foo')]) == [{'x': 42, 'y': 'foo'}]
    assert SchemaF[A].dump([A(42, 'foo')]) == {'x': 42, 'y': 'foo'}
    assert SchemaF[A].dump(A(42, 'foo')) == {'x': 42, 'y': 'foo'}

    assert SchemaF[Option[A]].dump(None) is None
    assert SchemaF[Option[A]].dump

# Generated at 2022-06-21 11:28:38.568918
# Unit test for constructor of class _UnionField
def test__UnionField():
    expected_ = {
        'type_': fields.Field,
        'desc': {},
        'cls': 'cls',
        'field': 'field'
    }
    assert vars(_UnionField('type_', 'cls', 'field')) == expected_


# Generated at 2022-06-21 11:28:41.904587
# Unit test for constructor of class SchemaF
def test_SchemaF():
    def _is_f(cls: type) -> bool:
        return cls.__name__ == "SchemaF"

    assert _is_f(SchemaF)  # type: ignore



# Generated at 2022-06-21 11:28:47.684925
# Unit test for function build_schema
def test_build_schema():
    # empty schema
    @dataclass
    class Schema1:
        pass
    SchemaType = build_schema(Schema1, _Mixin, False, True)
    assert fields.Field.missing is None
    assert SchemaType.Meta.fields == ()

    # basic schema
    @dataclass_json
    @dataclass
    class Schema2:
        a: int
        b: str
        c: datetime = field(default=datetime.now())
    SchemaType = build_schema(Schema2, _Mixin, False, True)
    assert fields.Field.missing is None
    assert SchemaType.Meta.fields == ('a', 'b', 'c')
    assert isinstance(SchemaType.a, fields.Int)

# Generated at 2022-06-21 11:28:56.692089
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from dataclasses import dataclass
    from marshmallow import Schema
    from dataclasses_json.schema import SchemaF
    import json

    class A(Schema):
        x = 2

    class B(SchemaF[A]):
        y = 2

    b = B()
    # Test for a list
    assert json.loads(b.dumps([])) == []

    # Test for a dataclass
    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        class Meta:
            dataclass = Foo

    assert json.loads(FooSchema().dumps(Foo(1))) == json.loads(
        FooSchema().dumps([Foo(1)]))
    assert FooSchema

# Generated at 2022-06-21 11:29:01.784518
# Unit test for function build_type
def test_build_type():
    class A(Schema):
        pass

    class B(Schema):
        pass

    @dataclass
    class C:
        d: typing.List[A]

    c_schema = build_type(C.__annotations__['d'], {}, Schema, dc_fields(C)[0], C)
    assert(isinstance(c_schema, fields.Nested))

    @dataclass
    class D:
        d: typing.List[B]

    d_schema = build_type(D.__annotations__['d'], {}, Schema, dc_fields(D)[0], D)
    assert(isinstance(d_schema, fields.List))


# Generated at 2022-06-21 11:29:30.518638
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Person(typing.Generic[A]):
        name: A

    class PersonSchema(SchemaF[Person[typing.Any]]):
        pass

    PersonSchema  # noqa


# Generated at 2022-06-21 11:29:38.974535
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Example of a simple use case:
    field1 = _IsoField(default=datetime.fromisoformat('2019-04-25'))
    assert field1.deserialize('2019-04-25T11:19:59') == datetime(2019, 4, 25, 11, 19, 59)
    assert field1.serialize(datetime(2019, 4, 25, 11, 19, 59)) == '2019-04-25T11:19:59'
    assert field1.default == datetime.fromisoformat('2019-04-25')

    # Example of a use case with data that does not obey ISO format:
    field4 = _IsoField()

# Generated at 2022-06-21 11:29:46.120813
# Unit test for function schema
def test_schema():
    from marshmallow import Schema
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from dataclasses_json import config

    from typing import Optional
    from typing import Union

    from marshmallow_enum import EnumField

    config.ENFORCE_SCHEMA_MATCHING = False

    class ValidationError(Exception):
        pass

    @dataclass_json(enforce_schema=False)
    @dataclass
    class MySchema(Schema):
        a = field(metadata={"mm_field": fields.Int()})
        b = field(metadata={"mm_field": fields.Int(), "letter_case": "lower"})


# Generated at 2022-06-21 11:29:57.223056
# Unit test for function build_schema
def test_build_schema():
    import unittest
    import datetime
    import decimal
    import re
    import typing
    import dataclasses

    @dataclasses.dataclass
    class Student:
        name: str
        age: int
        grades: typing.List[int]
        optional_field: typing.Optional[int] = None
        default_field: int = 1
        default_factory_field: int = dataclasses.field(
            default_factory=lambda: 1)
        bool_default_true: bool = True
        bool_default_false: bool = False
        datetime_field: datetime.datetime = datetime.datetime.now()
        uuid_field: UUID = uuid4()
        decimal_field: Decimal = Decimal(
            '1000000000000000000000000000000000')
        regex_field: re

# Generated at 2022-06-21 11:30:08.733751
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF()
    x : str
    x = s.loads('"a"')
    assert x == 'a'
    s.dump(x)
    xs : typing.List[str]
    xs = s.loads('["a","b"]', many=True)
    assert xs[0] == 'a' and xs[1] == 'b'
    s.dump(xs)
    with pytest.raises(AttributeError):
        s.loads(xs)
    with pytest.raises(AttributeError):
        s.dump('a')
    with pytest.raises(AttributeError):
        s.dumps('a')
    with pytest.raises(NotImplementedError):
        s.loads(xs, many=True)


_MISSING = MISSING  #

# Generated at 2022-06-21 11:30:18.996197
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert issubclass(SchemaF, Schema)
    # test that the constructor raises an error
    with pytest.raises(NotImplementedError):
        SchemaF()
    # test that the subclass works as expected
    _SchemaF = typing.TypeVar("_SchemaF", bound=SchemaF)
    @dataclasses.dataclass
    class A:
        item: int

    class B(SchemaF[A]):
        item = fields.Integer()

    b = B()

    a = A(item=1)
    b.dump(a)
    assert b.dump(a) == {'item': 1}

    b.dumps(a)
    assert b.dumps(a) == '{"item": 1}'

    # use _SchemaF because b is already an instance of

# Generated at 2022-06-21 11:30:26.773320
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    mixin = dataclass_json.DataClassJsonMixin

    @dataclass_json
    @dataclass
    class Demo:
        x: int
        y: str = "World"

        @property
        def hello(self):
            return f"Hello, {self.y}"

    assert schema(Demo, mixin, True) == {
        'x': fields.Int(),
        'y': fields.Str(missing='World')
    }



# Generated at 2022-06-21 11:30:31.422636
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # The following line must be protected in a no_mypy block because we don't want
    # mypy to check the return type of SchemaF.dump. The correct return type is defined by
    # the Schema.dump function but because this function is overridden in SchemaF the
    # return type does not match. Therefore we use the type: ignore statement.
    # isort: off
    # mypy: off
    class A(SchemaF[int]):
        pass
    # isort: on
    # mypy: on


# Generated at 2022-06-21 11:30:39.192359
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()
    # Test for _serialize
    assert a._serialize(1, 1, 1) == None
    assert a._serialize('1', 1, 1) == None
    with pytest.raises(ValidationError):
        a._serialize(1, 1, 1, required=True)
    # Test for _deserialize
    assert a._deserialize(1, 1, 1) == None
    assert a._deserialize('1', 1, 1) == None
    with pytest.raises(ValidationError):
        a._deserialize(1, 1, 1, required=True)



# Generated at 2022-06-21 11:30:41.192692
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # Check that the constructor is not implemented
    try:
        SchemaF()
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-21 11:31:32.113199
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    raise NotImplementedError()



# Generated at 2022-06-21 11:31:38.130877
# Unit test for constructor of class _UnionField
def test__UnionField():
    basic = _UnionField({
        int: fields.Integer,
        str: fields.String
    }, None, None)

    assert basic._serialize(1, None, None) == 1
    assert basic._serialize('1', None, None) == '1'

    assert basic._deserialize(1, None, None) == 1
    assert basic._deserialize('1', None, None) == '1'



# Generated at 2022-06-21 11:31:47.422981
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json_data = b"{}"
    obj = SchemaF[Enum].loads(json_data=json_data, many=False)



# Generated at 2022-06-21 11:31:57.700536
# Unit test for function build_schema
def test_build_schema():
    import tempfile
    from unittest import mock

    from json import load
    from dataclasses import dataclass
    from typing import Optional, List

    from dataclasses_json import DataClassJsonMixin

    with tempfile.TemporaryDirectory() as tmp_dir:
        input_file = tmp_dir + "/dataclass.json"
        expected_file = tmp_dir + "/expected_result.json"
        schema_file = tmp_dir + "/schema.py"
        with open(schema_file, 'w') as f:
            f.write("from dataclasses_json import DataClassJsonMixin\n")
            f.write("from marshmallow import Schema, fields\n")
            f.write("class A(DataClassJsonMixin):\n")

# Generated at 2022-06-21 11:32:02.747691
# Unit test for function schema
def test_schema():
    art_schema = schema(Art, None, False)
    assert art_schema['name'] is fields.Str
    assert art_schema['note'] is fields.Int
    assert art_schema['time'] is fields.Int
    assert art_schema['id'] is fields.UUID
    assert art_schema['price'] is fields.Decimal
    assert art_schema['available'] is fields.Bool



# Generated at 2022-06-21 11:32:03.321577
# Unit test for constructor of class _UnionField
def test__UnionField():
    return



# Generated at 2022-06-21 11:32:11.400933
# Unit test for function schema
def test_schema():
    from dataclasses_json.api import load, dump, loadb, dumpb
    from marshmallow import ValidationError
    from typing import Optional, List

    class Example:
        """
        This class is used for testing python `dataclass` serialization and
        deserialization functionality.
        """
        schema = SchemaType  # type: ignore

        def __init__(self, x: str, y: str, z: Optional[str] = None, w: typing.Dict[str, int] = None, v: typing.List[str] = None):
            self.x: str = x
            self.y: str = y
            self.z: Optional[str] = z
            self.w: typing.Dict[str, int] = w
            self.v: typing.List[str] = v


# Generated at 2022-06-21 11:32:13.771380
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert None


SchemaF.__module__ = "marshmallow.schema"



# Generated at 2022-06-21 11:32:24.576694
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    from marshmallow import ValidationError

    from .utils import _is_optional

    @dataclass
    class Foo(metaclass=dataclasses_json.DataClassJsonMixin):
        x: Optional[float] = None

        def __post_init__(self):
            assert self.x is None

    class FooSchema(Schema):
        x = fields.Float(allow_none=True, required=True)

    @dataclass
    class Bar(metaclass=dataclasses_json.DataClassJsonMixin):
        x: Union[float, str]

    class BarSchema(Schema):
        x = fields.Float()


# Generated at 2022-06-21 11:32:26.172273
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    s = SchemaF[int]()
    s.dumps(1)  # type: ignore

