

# Generated at 2022-06-21 11:24:21.297359
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF[str]  # should not raise exception
    SchemaF[str]()  # should not raise exception



# Generated at 2022-06-21 11:24:31.580749
# Unit test for constructor of class _UnionField
def test__UnionField():
    uf = _UnionField(desc={}, cls=None, field=None)
    assert isinstance(uf, _UnionField)

if typing.TYPE_CHECKING:
    from typing import Any, Callable, List, Tuple, Union
    from marshmallow.exceptions import ValidationError
    from marshmallow import validate
    from marshmallow_oneofschema import OneOfSchema  # type: ignore

    _CustomFields = typing.Dict[type, typing.Tuple[Any, Callable]]
    _CustomFieldsValidator = typing.Dict[type, typing.Union[Callable, validate.Validator]]
    _CustomFieldsParam = typing.Union[_CustomFields, _CustomFieldsValidator]
    _CustomEnum = typing.Union[Enum, List[Enum]]

# Generated at 2022-06-21 11:24:40.561462
# Unit test for function build_type
def test_build_type():
    from unittest.mock import patch
    import marshmallow as mm
    from marshmallow.fields import Field
    from marshmallow.exceptions import ValidationError
    from marshmallow import Schema
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    import typing

    class MmClass(mm.Schema):

        name = mm.fields.Str(required=True, load_only=True)
        age = mm.fields.Int(required=True)

        @mm.post_load
        def make_marshmallow(self, data, **kwargs):
            return MmClass(**data)

    @dataclass_json
    @dataclass
    class Base:

        age: int = field(metadata={"mm_field": mm.fields.Int()})


# Generated at 2022-06-21 11:24:44.454470
# Unit test for constructor of class _UnionField
def test__UnionField():
    import pytest
    from dataclasses_json.core import mk_dataclass

    @mk_dataclass
    class User:
        name: str
        age: int
    _UnionField(desc={int: fields.Integer()}, cls=User, field = fields.Field())


# Generated at 2022-06-21 11:24:55.194276
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: int

    @dataclass_json
    @dataclass
    class C:
        a: B

    assert build_type(str, {}, type, C.__annotations__['a'], C) == \
        fields.Nested(B.schema(), many=False)
    assert build_type(C, {}, type, A.__annotations__['a'], A) == \
        fields.Field(allow_none=False)



# Generated at 2022-06-21 11:24:58.101720
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(1.0, None, None) is not None


# Generated at 2022-06-21 11:25:04.289093
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    "Make sure dumps methods in SchemaF class has proper typing."
    import dataclasses
    import json

    @dataclasses.dataclass
    class DC:
        a: int

    f = SchemaF[DC]()
    a = DC(a=2)
    f.dumps(a)
    f.dumps([a])
    json.dumps([a], cls=_ExtendedEncoder)



# Generated at 2022-06-21 11:25:05.488377
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(_IsoField(), _IsoField)


# Generated at 2022-06-21 11:25:11.240205
# Unit test for constructor of class _UnionField
def test__UnionField():
    def test_me(item, cls, field):
        _UnionField(item, cls, field)._deserialize({"__type": "a", "a": 42}, None, None)

    class a: pass
    class b: pass

    test_me({a: fields.Integer()}, a, None)
    test_me({b: fields.Integer()}, b, None)


# Generated at 2022-06-21 11:25:15.408729
# Unit test for function schema
def test_schema():
    import typing
    import dataclasses_json
    from dataclasses import dataclass
    from typing import List
    from enum import Enum
    import pytest

    @dataclass_json.dataclass_json(letter_case=dataclasses_json.LetterCase.CAMEL)
    @dataclass
    class Bar:
        bar: float

    @dataclass
    class Foo:
        foo: Bar

    def test_type():
        assert schema(Foo, None, False) == {'foo': fields.Nested(Bar.schema())}

    test_type()

    @dataclass_json.dataclass_json(letter_case=dataclasses_json.LetterCase.CAMEL)
    @dataclass
    class Bar:
        bar: int


# Generated at 2022-06-21 11:25:28.379129
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = _TimestampField()
    assert ts is not None


# Generated at 2022-06-21 11:25:31.717686
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[dict].dumps({'hello': 'world'}, many=False) == '{"hello": "world"}'
    assert isinstance(SchemaF[dict].dumps([{'hello': 'world'}], many=True), str)


# Generated at 2022-06-21 11:25:43.693838
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import asdict

    class Color(str, Enum):
        RED = 'red'
        BLUE = 'blue'
        GREEN = 'green'

    class DummyDataClassA:
        pass

    @dataclass
    class DummyDataClassB:
        a: int

    @dataclass
    class DummyDataClassC:
        a: int

    union_desc = _UnionField(
        desc={
            DummyDataClassA: DummyDataClassA,
            DummyDataClassB: Schema.from_dataclass(DummyDataClassB)},
        cls=DummyDataClassA, field='a', required=False)

    union_desc._validated = True
    assert union_desc._serialize(DummyDataClassA, 'a', None) == {}

# Generated at 2022-06-21 11:25:49.048635
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class A:
        a: int = dataclasses.field(metadata={"marshmallow_field":
                                             fields.Boolean()})
    aschema = SchemaF[A]
    aschema.Meta.fields = ("a",)
    a = A(a=3)
    aschema.dumps(a)

# Generated at 2022-06-21 11:25:57.176491
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField(required=True)._deserialize(1.0, None, None) == datetime.fromisoformat('1.0')
    assert _IsoField(required=True)._deserialize('1.0', None, None) == datetime.fromisoformat('1.0')
    assert _IsoField(required=False)._deserialize('1.0', None, None) == datetime.fromisoformat('1.0')
    assert _IsoField(required=True)._serialize(datetime.fromisoformat('1.0'), None, None) == '1.0'
    assert _IsoField(required=False)._serialize(datetime.fromisoformat('1.0'), None, None) == '1.0'



# Generated at 2022-06-21 11:26:10.300419
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass



# Generated at 2022-06-21 11:26:11.285981
# Unit test for constructor of class _IsoField
def test__IsoField(): 
    _IsoField()


# Generated at 2022-06-21 11:26:16.864278
# Unit test for function build_type
def test_build_type():
    assert dict in TYPES
    assert typing.Dict in TYPES
    assert typing.Union in TYPES
    assert typing.List in TYPES
    assert typing.Callable in TYPES
    assert typing.Any in TYPES
    assert typing.Mapping in TYPES
    assert typing.MutableMapping in TYPES
    assert typing.Tuple in TYPES
    assert datetime in TYPES
    assert UUID in TYPES
    assert Decimal in TYPES
    assert CatchAllVar in TYPES



# Generated at 2022-06-21 11:26:20.823910
# Unit test for function schema
def test_schema():
    assert schema(
        dict(),
        dict(),
        True
    ) == dict(
        name=fields.Str(),
        value=fields.Field(),
        perc=fields.Decimal()
    )

# Generated at 2022-06-21 11:26:29.039828
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema
    from marshmallow.fields import String

    @dataclasses.dataclass
    class User:
        name: str

    class UserSchema(Schema, typing.Generic[User]):
        name = String(required=True)

    obj = [User('name1'), User('name2')]
    expected = [{'name': 'name1'}, {'name': 'name2'}]
    assert UserSchema(strict=True).dump(obj) == expected
    assert UserSchema(strict=True).dumps(obj) == json.dumps(expected)

    obj = User('name1')
    expected = {'name': 'name1'}
    assert UserSchema(strict=True).dump(obj) == expected
    assert UserSchema(strict=True).d

# Generated at 2022-06-21 11:26:52.200996
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field is not None

_MARSHMALLOW_TYPE_MAP = {
    fields.Integer: int,
    fields.Boolean: bool,
    fields.String: str,
    fields.List: list,
    fields.Dict: dict,
    fields.Float: float,
    fields.Field: object,
    fields.Raw: object,
    fields.Nested: object,
    fields.UUID: UUID,
    fields.Date: datetime.date,
    fields.DateTime: datetime,
    fields.Time: datetime.time,
    fields.Str: str,
    fields.Number: float,
    fields.Decimal: Decimal,
    _IsoField: datetime,
    _TimestampField: datetime
}



# Generated at 2022-06-21 11:26:59.700777
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow_dataclass import dataclass as dc_to_schema # type: ignore

    @dataclass
    class MyClass:
        a: str

    class MyOtherClass:
        pass

    s = SchemaF[MyClass]() # type: ignore
    s2 = SchemaF[MyOtherClass]() # type: ignore
    s3 = SchemaF[MyClass]() # type: ignore
    assert isinstance(s, dc_to_schema.class_registry.SchemaMetaclass)
    assert s.load({'a': 1}) == MyClass('1')
    assert s2.load({'a': 1}) == {'a': '1'}

# Generated at 2022-06-21 11:27:01.525797
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # noinspection PyTypeChecker
    def f(x: SchemaF[str]):
        pass



# Generated at 2022-06-21 11:27:12.484981
# Unit test for function build_type
def test_build_type():
    import typing
    import marshmallow

    class ClassWithOptions:
        def __init__(
                self,
                option1=None,
                option2=None,
                option3=None,
                option4=None
        ):
            self.option1=option1
            self.option2=option2
            self.option3=option3
            self.option4=option4

    class TestObject:

        @classmethod
        def schema(self):
            return TestObjectSchema

        @staticmethod
        def mm(type_, options, mixin, field, cls):
            return build_type(type_, options, mixin, field, cls)


# Generated at 2022-06-21 11:27:20.222012
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    @dataclass
    class Foo:
        a: str
    @dataclass
    class Bar(Foo):
        b: int
    fooObj = Foo('abc')
    fooObjs = [fooObj, fooObj]
    barObj = Bar('abc', 1)
    barObjs = [barObj, barObj]
    sc = SchemaF.from_dataclass(Foo)
    sc.dump(fooObj)
    sc.dump(fooObjs)
    sc.dump(barObj)
    sc.dump(barObjs)


# Generated at 2022-06-21 11:27:24.730655
# Unit test for function build_type
def test_build_type():
    from typing import Optional
    import marshmallow as mm
    class A(mm.Schema):
        pass

    field = mm.fields.Field()
    assert build_type(Optional[int], {}, {}, field, {}) == mm.fields.Integer(
        allow_none=True)



# Generated at 2022-06-21 11:27:26.361432
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-21 11:27:30.671136
# Unit test for function schema
def test_schema():
    class Person(Schema):
        name: str
        age: int

    assert schema(Person, dict, lambda x: False) == {
        'name': fields.Str(),
        'age': fields.Int()
    }



# Generated at 2022-06-21 11:27:37.538916
# Unit test for function build_type
def test_build_type():
    @dataclass
    class Foo:
        data: list
        data2: typing.Mapping[int, str]
        data3: typing.List[int]
        data4: typing.Dict[int, str]

    @dataclass_json
    class Bar:
        foo: Foo

    assert isinstance(Bar.schema(), Schema)
    assert isinstance(Bar.schema(ordered=True), Schema)

test_build_type()


# Generated at 2022-06-21 11:27:45.159176
# Unit test for function build_schema
def test_build_schema():
    dc = dataclasses.dataclass(frozen=True)(
        lambda cls: cls)

    @dc
    class Foo:
        a: int = 1
        b: str = "a"
        c: List[str] = ["a", "b"]
        d: Tuple[str] = ("a", "b")
        e: Dict[str, int] = {"a": 1, "b": 2}
        f: Set[str] = {"a", "b"}
        g: Mapping[str, int] = {"a": 1, "b": 2}
        h: MutableMapping[str, int] = {"a": 1, "b": 2}
        i: FrozenSet[str] = {"a", "b"}
        j : Callable = lambda x: x
        k: Any = 1



# Generated at 2022-06-21 11:28:20.471250
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        pass

    @dataclass
    class Student:
        name: str = field(metadata=dict(
            dataclasses_json=config(field_name="student_name")))

    @dataclass_json
    @dataclass
    class Address:
        street: str = field(metadata=dict(
            dataclasses_json=config(field_name="student_address")))
        number: int

    @dataclass_json
    @dataclass
    class Grade:
        course: str
        grade: int

    @dataclass_json
    @dataclass
    class Info:
        address: Address
        grades: typing.List[Grade]

    student = Student(name="Janko")
    address = Address(street="Mickiewiczova", number=23)
   

# Generated at 2022-06-21 11:28:26.236177
# Unit test for function build_schema
def test_build_schema():
    assert not hasattr(build_schema(XXX, Noen, True, True), 'm')
    assert not hasattr(build_schema(XXX, Noen, False, False), 'm')
    assert not hasattr(build_schema(XXX, Noen, False, True), 'm')
    assert not hasattr(build_schema(XXX, Noen, True, False), 'm')


# Generated at 2022-06-21 11:28:30.415136
# Unit test for function build_schema
def test_build_schema():
    class Base:
        a: str
        @property
        def prop(self):
            return 'prop'

    @dataclass
    class Foo(Base):
        a: str
        b: typing.Union[int, str]
        c: typing.List[str]
        d: typing.Optional[str]
        e: typing.Dict[str, int]
        f: typing.Set[str]
    m = build_schema(Foo, None, True, False)
    assert isinstance(m.declared_fields['a'], fields.Field)
    assert isinstance(m.make_foo(dict(a='123', b=1)), Foo)
    assert isinstance(m.declared_fields['b'], _UnionField)

# Generated at 2022-06-21 11:28:42.099036
# Unit test for function build_type
def test_build_type():
    assert '_TimestampField' in str(build_type(datetime, {}, None, None, None))
    assert '_IsoField' in str(build_type(datetime, {'isoformat': True}, None, None, None))
    assert 'EnumField' in str(build_type(Enum("TestEnum", {"A": 0}), {}, None, None, None))
    assert '_UnionField' in str(build_type(typing.Union[int, float], {}, None, None, None))
    assert '_UnionField' in str(build_type(typing.Union[int, float, str], {}, None, None, None))
    assert '_UnionField' in str(build_type(typing.Union[int, float, str, None], {}, None, None, None))

# Generated at 2022-06-21 11:28:47.928509
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    import dataclasses_json

    class Settings:
        pass

    settings = Settings()
    dataclasses_json.config.settings._replace(settings)

    @dataclass
    class Arc(settings.mixin):
        radius: str
        start_angle: int
        end_angle: float
        # this doesn't work for now
        # https://github.com/agronholm/typeguard/pull/211
        # https://github.com/python/mypy/issues/6978
        # thickness: Union[int, float] = 1

    assert issubclass(build_schema(Arc, settings.mixin, False, False), Schema)


# Generated at 2022-06-21 11:28:56.950463
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        def f(self, obj: typing.List[A], many: bool = None) -> typing.List[TEncoded]: pass
        def g(self, obj: typing.List[A], many: bool = None) -> TOneOrMultiEncoded: pass
        def h(self, obj: A, many: bool = None) -> typing.List[TEncoded]: pass
        # This is valid
        def i(self, obj: A, many: bool = None) -> TOneOrMultiEncoded: pass

    # Valid
    class MySchema(SchemaF[int]): pass
    class MySchema2(SchemaF[A]): pass

    # Invalid
    class MySchema3(SchemaF[str]): pass  # error: Type argument cannot be a subclass of typing

# Generated at 2022-06-21 11:29:05.987324
# Unit test for function build_type
def test_build_type():
    import pathlib
    from dataclasses_json.mm_schema import SchemaFactory
    from dataclasses_json.api import mm_schema
    from typing import Optional, List

    class Config:
        pass

    @mm_schema(encoder=SchemaFactory.encoder(catchall=True))
    class Config2(Config):
        pass

    @mm_schema
    class Basic:
        bool: bool
        int: int
        float: float
        str: str
        list: List[int]
        dict: dict
        tuple: tuple
        path: pathlib.Path
        config: Optional[Config2]

    cls = Basic
    field = dc_fields(cls)[0]


# Generated at 2022-06-21 11:29:07.463392
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert str(f) == "<fields.IsoField>"


# Generated at 2022-06-21 11:29:14.947286
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Book:
        title: str
        readers: typing.List[int]
    book = Book('Ender\'s game', [2, 3, 4])
    schema = SchemaF[Book]()
    json = schema.dumps(book, many=False)
    assert 'Ender\'s game' in json

    books = [book]
    json = schema.dumps(books, many=True)
    assert 'Ender\'s game' in json
    assert '"readers": [2, 3, 4]' in json

# Generated at 2022-06-21 11:29:18.012941
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class ExampleSchema(SchemaF):
        pass

    try:
        ExampleSchema()
    except NotImplementedError:
        pass



# Generated at 2022-06-21 11:30:08.620910
# Unit test for function build_schema
def test_build_schema():
    class Cls:
        pass

    assert build_schema(A, Cls, True, True)
    assert build_schema(A, Cls, False, True)
    assert build_schema(A, Cls, False, False)
    assert build_schema(A, Cls, True, False)



# Generated at 2022-06-21 11:30:11.727909
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        if sys.version_info >= (3, 7):
            SchemaF()
    except NotImplementedError:
        pass
    else:
        raise Exception("The constructor of class SchemaF should raise an exception.")



# Generated at 2022-06-21 11:30:21.845241
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def tt(x: typing.Mapping[typing.Any, typing.Any]) -> None:
        pass

    def tt(x: typing.Mapping[typing.Any, typing.Any]) -> None:
        pass

    tt(SchemaF.dumps((typing.Mapping[typing.Any, typing.Any], {1:1})))
    SchemaF.dumps((typing.Mapping[typing.Any, typing.Any], {1: 1}), *(),
                  **{'indent': 1})
    SchemaF.dumps.__annotations__  # mypy ignore: used for type-checking
    SchemaF.dumps.__annotations__  # mypy ignore: used for type-checking


# Generated at 2022-06-21 11:30:23.777071
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class TestS(SchemaF):
        s = fields.String()

    TestS()



# Generated at 2022-06-21 11:30:32.396839
# Unit test for constructor of class _UnionField

# Generated at 2022-06-21 11:30:41.231587
# Unit test for function build_type
def test_build_type():
    from marshmallow import validate
    from dataclasses import dataclass, field
    from typing import Set

    dc = dataclass(frozen=True)

    @dc
    class A:
        a: int
        b: bool
        c: str
        d: float
        e: Set[int]

    options = {
        "allow_none": False
    }

    @dc
    class B:
        a: A = field(metadata={"mm_field": fields.Nested(A.schema())})
        b: A = field(metadata={"mm_field": fields.Nested(A.schema(),
                                                         allow_none=True)})

# Generated at 2022-06-21 11:30:50.139445
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    from marshmallow import Schema

    from dataclasses_json.mixin import DataclassJsonMixin


    def test_schema_creation(cls, dct, mixin):
        assert cls.schema()._declared_fields == dct


    @dataclass
    class Test(DataclassJsonMixin):
        a: str
        b: int = 10
        c: typing.Optional[str] = None
        d: typing.Optional[int] = None
        e: typing.List[str] = typing.field(default_factory=list)
        f: typing.Dict[str, int] = typing.field(default_factory=dict)

# Generated at 2022-06-21 11:30:58.931403
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class E(Enum):
        a = 1
        b = 2

    @dataclass
    class B:
        x: int

    @dataclass
    class C:
        x: int

    @dataclass
    class D:
        a: B
        c: typing.Union[B, C]


# Generated at 2022-06-21 11:31:03.574252
# Unit test for function build_schema
def test_build_schema():
    class Actor(Schema):
        id: int
        name: str
    class Movie(Schema):
        id: int
        title: str
        actors: str
    class Mixed(Schema):
        id: int
        title: str
        actors: Actor
    class List(Schema):
        id: int
        title: str
        actors: List[Actor]

    class Mixed(Schema):
        id: int
        title: str
        actors: typing.List[Actor]



# Generated at 2022-06-21 11:31:06.196507
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_string = '2018-06-27T02:36:31.286Z'
    field = _IsoField()
    field._deserialize(iso_string, None, None)


# Generated at 2022-06-21 11:32:48.512747
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF[int]()
    result = s.load([1, 2, 3])
    assert result == [1, 2, 3]
    assert isinstance(result, list)
    result = s.load([1, 2, 3], many=False)
    assert result == [1, 2, 3]
    assert isinstance(result, list)
    result = s.load(1)
    assert result == 1
    assert isinstance(result, int)


# Generated at 2022-06-21 11:32:57.288667
# Unit test for function build_schema
def test_build_schema():
    @dataclass(frozen=True)
    class A:
        a: int = 5

    @dataclass(frozen=True)
    class B:
        b: str = "5"

    @dataclass(frozen=True)
    class C:
        c: Union[A, B]

    @dataclass(frozen=True)
    class D:
        d: Optional[List[A]]

    @dataclass(frozen=True)
    class E:
        e: Union[List[A], A]

    assert build_schema(C, None, True, False).__name__ == 'CSchema'
    assert build_schema(D, None, True, False).__name__ == 'DSchema'
    assert build_schema(E, None, True, False).__

# Generated at 2022-06-21 11:32:57.936767
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-21 11:33:07.820015
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A(Enum):
        a = 'A'
        b = 'B'
    class B(Enum):
        a = 'A'
        b = 'B'
    class C:
        def __init__(self, value):
            self.value = value

    @dataclass
    class D:
        val: typing.Union[int, str]
        enm: typing.Union[A, B]
        clz: typing.Union[int, C]
    d_schema = _create_schema(D)

    d1 = D(val='str', enm=A.a, clz=C(5))
    assert d1 == d_schema.load(d_schema.dump(d1))

# Generated at 2022-06-21 11:33:17.776270
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    a: SchemaF[int] = SchemaF(fields={"name": fields.Int()})
    b: SchemaF[float] = SchemaF(fields={"name": fields.Float()})
    c: SchemaF[Decimal] = SchemaF(fields={"name": fields.Decimal()})
    d: SchemaF[str] = SchemaF(fields={"name": fields.Str()})
    e: SchemaF[bool] = SchemaF(fields={"name": fields.Bool()})
    f: SchemaF[UUID] = SchemaF(fields={"name": fields.UUID()})
    g: SchemaF[datetime] = SchemaF(fields={"name": _TimestampField()})

# Generated at 2022-06-21 11:33:21.093972
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    class S(SchemaF[A], Schema):
        x: int
        y: str
    obj = S.loads({"x": 1, "y": "a"})
    assert obj.x == 1
    assert obj.y == "a"



# Generated at 2022-06-21 11:33:23.172655
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
    except Exception as e:
        assert isinstance(e, NotImplementedError)



# Generated at 2022-06-21 11:33:34.679424
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses_json.mm_schema import SchemaF

    class InnerSchema(Schema):
        a = fields.Int(data_key='b', required=True)
        b = fields.Int()

    class OuterSchema(Schema):
        a = fields.Nested(InnerSchema)

    inner = InnerSchema()
    result = inner.load({'a': 1, 'b': 2})
    assert result.a == 1
    assert result.b == 2

    type_result = typing.get_type_hints(result)
    assert type_result == {'a': int, 'b': int}

    result = inner.load({'a': 1})
    assert result.a == 1
    assert not hasattr(result, 'b')

    result

# Generated at 2022-06-21 11:33:42.869120
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import json


    class TestA:
        def __init__(self, a: int):
            self.a = a


    class TestASchema(SchemaF[TestA]):
        a = fields.Int()


        @post_load
        def dump_a(self, data, many, **kwargs):
            return TestA(data['a'])


    test_a = TestA(a=1)

    assert TestASchema().dump(test_a) == {'a': 1}

    assert json.loads(TestASchema().dumps(test_a)) == {'a': 1}

    test_a_list = [TestA(a=1), TestA(a=2)]


# Generated at 2022-06-21 11:33:53.614683
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    from typing import TypeVar
    from marshmallow import Schema, fields
    from marshmallow.utils import from_mimetype
    from marshmallow.exceptions import ValidationError

    T = TypeVar('T')

    class Foo(Schema):
        a = fields.Field()

    class Bar(Schema):
        b = fields.Field()

    serializer = SchemaF[T]()
    assert serializer.loads(json_data=b'', many=True) == []
    assert serializer.loads(json_data=b'', many=False) is None
    assert serializer.loads(json_data=b'{"data": [null]}', many=True,
                            unknown="EXCLUDE") == []