

# Generated at 2022-06-21 11:24:21.214451
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class S(SchemaF[A]):
        pass

    def multi(schema: S, json_data: str) -> typing.List[A]:
        return schema.loads(json_data, many=True)

    def single(schema: S, json_data: str) -> A:
        return schema.loads(json_data, many=False)

    def tests_load(json_data: str, schema: S) -> None:
        assert isinstance(multi(schema, json_data), typing.List)
        assert isinstance(single(schema, json_data), A)

    class C(typing.Generic[A]):
        pass

    class B:
        pass
    tests_load('["1"]', S[C[B]])

# Generated at 2022-06-21 11:24:23.513279
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__class__.__name__ is "_TimestampField"


# Generated at 2022-06-21 11:24:32.798036
# Unit test for constructor of class _UnionField
def test__UnionField():
    def test_a():
        class TestA:
            pass
    class TestB1:
        pass
    class TestB2:
        pass
    class TestC(TestB1, TestB2):
        pass
    test_a_schema = fields.Field()
    test_b1_schema = fields.Field()
    test_b2_schema = fields.Field()
    test_c_schema = fields.Field()
    union_desc = {
        test_a: test_a_schema,
        test_b1_schema: test_b1_schema,
        TestB2: test_b2_schema,
        TestC: test_c_schema,
        }
    union_field = _UnionField(union_desc, type, 'test')
    test_a_obj

# Generated at 2022-06-21 11:24:37.464187
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize(None, None, None) == None
    assert _IsoField()._deserialize('2019-04-02T10:18:00.000001+01:00', None, None) == datetime(2019, 4, 2, 10, 18, 0, 1)
    assert _IsoField()._deserialize('2019-04-02T10:18:00.000001', None, None) == datetime(2019, 4, 2, 10, 18, 0, 1)
    assert _IsoField()._deserialize('2019-04-02T10:18:00', None, None) == datetime(2019, 4, 2, 10, 18)



# Generated at 2022-06-21 11:24:46.619368
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import Any, Dict
    from marshmallow import Schema
    from mypy_extensions import TypedDict

    class Dummy(TypedDict):
        a: str
        b: int

    class SchemaForDummy(Schema):
        pass

    def f(obj: Dummy) -> Dummy:
        s = SchemaForDummy(unknown='EXCLUDE')
        s.dump(obj)
        # mm has the wrong return type annotation (dict) so we can ignore the mypy error
        # for the return type overlap
        return s.dump(obj)  # type: ignore

    def g(obj: Dummy) -> Dummy:
        s = SchemaForDummy(unknown='EXCLUDE')
        s.dumps(obj)
        return s.dumps(obj)

   

# Generated at 2022-06-21 11:24:48.871204
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts_field = _TimestampField()
    assert ts_field is not None
    assert type(ts_field) is _TimestampField



# Generated at 2022-06-21 11:24:50.159832
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None


# Generated at 2022-06-21 11:24:59.996560
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class MySchema(Schema):
        f = fields.Int()

    assert MySchema(strict=True).load({'f': 3}) == {'f': 3}
    assert MySchema(strict=True).load([{'f': 3}]) == [{'f': 3}]
    assert MySchema(strict=True).load([{'f': 3}], many=False) == {'f': 3}
    assert MySchema(strict=True).load({'f': 3}, many=True) == [{'f': 3}]

    class A:
        pass

    class MySchemaF(SchemaF):
        class Meta:
            target_class = A

    assert isinstance(MySchemaF(strict=True).load({'f': 3}), A)

# Generated at 2022-06-21 11:25:07.950108
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[int], {}, object, None, None) == fields.List
    assert build_type(typing.Tuple, {}, object, None, None) == fields.Tuple
    assert build_type(typing.Callable, {}, object, None, None) == fields.Function
    assert build_type(typing.Any, {}, object, None, None) == fields.Raw
    assert build_type(dict, {}, object, None, None) == fields.Dict
    assert build_type(list, {}, object, None, None) == fields.List
    assert build_type(str, {}, object, None, None) == fields.Str
    assert build_type(int, {}, object, None, None) == fields.Int

# Generated at 2022-06-21 11:25:18.455335
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF[typing.List[int]]):
        @post_load
        def make_int_list(self, data, **kwargs):  # type: ignore
            return list(data.values())[0]
    data = {'one': [1, 2, 3]}
    result = dumps(S(strict=True), data, many=True)
    assert result == '[1,2,3]'
    result2 = S().loads(result, many=True)
    assert result2 == [1, 2, 3]
test_SchemaF_dumps()

# Generated at 2022-06-21 11:25:35.210838
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        str: str
        int: int

    infer_missing = False
    partial = False
    cls = Test
    mixin = type(None)
    schema = build_schema(cls, mixin, infer_missing, partial)
    assert type(schema) is type
    assert issubclass(schema, Schema)
    assert schema.Meta.fields == ('str', 'int')
    assert schema.make_test.__name__ == 'make_test'
    assert type(schema.make_test) is function
    assert schema.__name__ == 'TestSchema'
    assert type(schema.dumps) is function
    assert type(schema.dump) is function
    assert schema.__dict__['str'].__class

# Generated at 2022-06-21 11:25:45.850638
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import fields, Schema
    from dataclasses import dataclass
    from marshmallow_dataclass import class_schema

    @dataclass
    class User:
        name: str
        age: int

    user_schema = class_schema(User)
    user_schema_type = class_schema(User, base=SchemaF)
    user = User(name='John', age=35)

    assert type(user_schema.dump(user)) == dict
    assert type(user_schema_type.dump(user)) == dict

    assert type(user_schema.dump([user])) == list
    assert type(user_schema_type.dump([user])) == list

    assert type(user_schema.dump([user])[0]) == dict

# Generated at 2022-06-21 11:25:55.620789
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class A:
        x: int

    @dataclass_json
    @dataclass
    class A_List(typing.List[A]):
        pass

    schema = SchemaF[A_List]()
    obj = schema.load([{'x': 1}, {'x': 2}, {'x': 3}])



# Generated at 2022-06-21 11:26:03.760347
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):  # type: ignore
        pass

    FooSchema.loads('{"bar": 3}')  # type: ignore
    FooSchema.loads(b'{"bar": 3}')

if sys.version_info < (3, 7):
    SchemaF = typing.TypeVar('SchemaF')  # type: ignore
else:
    SchemaF = Schema



# Generated at 2022-06-21 11:26:15.198909
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestDC:
        field: int
        another_field: str = "test"

    test_dc_schema = build_schema(TestDC, None, False, False)

    @test_dc_schema.validates('another_field')
    def another_field_validates(self, another_field: str) -> str:
        assert another_field is not None
        return another_field

    test_dc = TestDC(field=1, another_field="test")
    test_dc_schema.validate(test_dc)
    test_dc_dict = test_dc_schema.dump(test_dc)
    test_dc_loads = test_dc_schema.load(test_dc_dict)
    assert test_dc == test_dc_loads


TEncoded

# Generated at 2022-06-21 11:26:25.440016
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema
    from marshmallow_dataclass import dataclass

    @dataclass
    class Foo:
        x: int
        y: str

    schema = SchemaF[Foo]()

    # in mypy, this gets resolved to the first overload because we are passing a list
    cls = schema.dumps([Foo(42, "Henk"), Foo(666, "Earl")])  # type: ignore
    assert isinstance(cls, str)

    # in mypy, this gets resolved to the second overload because we are passing a Foo
    cls = schema.dumps(Foo(42, "Henk"))  # type: ignore
    assert isinstance(cls, str)



# Generated at 2022-06-21 11:26:35.888180
# Unit test for function build_schema
def test_build_schema():
    import json
    @dataclass
    class Person:
        first_name: Optional[str] = None
        last_name: Optional[str] = None
        age: int = 18
        all_fields: CatchAllVar = field(metadata={'dataclasses_json': {'mm_field': fields.Dict()}})

    S = build_schema(Person, None, True, False)
    assert Person.schema() == S

    p = Person(first_name='John', last_name='Doe', age=30, all_fields={})
    data, errors = S().dump(p)
    assert data == {'first_name': 'John', 'last_name': 'Doe', 'age': 30, 'all_fields': {}}
    assert errors == {}


# Generated at 2022-06-21 11:26:44.511030
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class User(typing.TypedDict):
        id: int

    class UserSchema(SchemaF[User]):  # type: ignore
        id = fields.Int()

    u, = UserSchema().load([{'id': 1}])
    assert u['id'] == 1

    u = UserSchema().load({'id': 1})
    assert u['id'] == 1

    try:
        UserSchema().load({'i': 1})
    except ValidationError:
        assert 1
    else:
        assert False



# Generated at 2022-06-21 11:26:55.252740
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def _test_dumps(schema, obj, expected):
        s = schema()
        assert s.dumps(obj) == expected

    class Schema1(SchemaF[int]):
        pass

    class Schema2(SchemaF[int]):
        def __init__(self, many: bool = False, *args, **kwargs):
            super().__init__(*args, **kwargs)

    with warnings.catch_warnings(record=True) as warn:
        _test_dumps(Schema1, 1, '1')
        _test_dumps(Schema1, [1, 2], '[1,2]')
        _test_dumps(Schema2, 1, '1')
        _test_dumps(Schema2, [1, 2], '[1,2]')
       

# Generated at 2022-06-21 11:27:00.509880
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert(_TimestampField()._deserialize(1234567) == datetime(1973, 11, 29, 21, 33, 47, tzinfo=timezone.utc))
    assert(_TimestampField()._serialize(datetime(1973, 11, 29, 21, 33, 47, tzinfo=timezone.utc)) == 1234567)


# Generated at 2022-06-21 11:27:35.434842
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import typing
    import pytest
    from typing_inspect import is_union_type
    from marshmallow import fields, Schema, post_load
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.mm import Schema as SchemaType
    from dataclasses_json import dataclass_json
    class mixin:
        @classmethod
        def schema(cls) -> SchemaType[cls]:
            pass

    class mixin2:
        @classmethod
        def schema(cls) -> SchemaType[cls]:
            pass

    @dataclass_json
    @dataclass
    class MyClass(mixin):
        name: str
        age: int
        b: bool


# Generated at 2022-06-21 11:27:38.874555
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = Schema(__annotations__={'dump': typing.List[int], 'load': typing.List[float]})
    # expecting "NotImplementedError"
    SchemaF[str]()


# Generated at 2022-06-21 11:27:46.428115
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    @dataclass
    class C:
        pass
    dc = C()
    t = type(dc)
    field = dc_fields(t)[0]
    desc = {
        t: Schema,
    }
    f = _UnionField(desc, t, field)
    assert f.desc == desc
    assert f.cls == t
    assert f.field == field



# Generated at 2022-06-21 11:27:57.986323
# Unit test for function schema
def test_schema():
    import re
    import unittest
    import marshmallow as mm

    from dataclasses import dataclass
    from dataclasses_json.mm import Schema

    @Schema
    @dataclass
    class Simple:
        id: int
        name: str

    @Schema
    @dataclass
    class Nested:
        id: int
        simple: Simple

    @Schema
    @dataclass
    class Address:
        street: str
        zip: int

    @Schema
    @dataclass
    class Person:
        name: str
        age: int
        nickname: typing.Optional[str] = None
        simple: typing.Optional[Simple] = None
        address: typing.Optional[Address] = None

        class Meta:
            letter_case = mm.fields.FIELD_REQU

# Generated at 2022-06-21 11:28:07.806457
# Unit test for constructor of class SchemaF
def test_SchemaF():
    sf = SchemaF[int]
    assert issubclass(sf, Schema)
    assert typing.get_type_hints(sf.dump) == {
        'obj': 'List[int]',
        'many': 'None',
        'Return': 'Union[List[Dict[str, Any]], Dict[str, Any]]'
    }
    assert typing.get_type_hints(sf.dumps) == {
        'obj': 'List[int]',
        'many': 'None',
        '*args': 'tuple',
        '**kwargs': 'dict',
        'Return': 'str'
    }

# Generated at 2022-06-21 11:28:20.339511
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    @dataclass
    class A:
        b: typing.List[int]
        c: typing.Optional[int]


    @dataclass
    class B:
        d: typing.List[A]
        e: typing.Optional[A]
        f: typing.Dict[int, A]


    @dataclass
    class C:
        g: typing.Dict[int, typing.List[int]]
        h: typing.Dict[int, typing.Optional[int]]


    mixin = dataclasses_json.DataClassJsonMixin
    
    assert build_type(A, {}, mixin, dc_fields(B)[0], B).__class__ == fields.Nested

# Generated at 2022-06-21 11:28:29.918390
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    from typing import Optional, List, Dict

    class PersonSchema(SchemaF[str]):
        name = fields.Str()

    class PetSchema(SchemaF[List[PersonSchema]]):
        name = fields.Str()

    class TreeSchema(SchemaF[Dict[str, PetSchema]]):
        name = fields.Str()

    assert PersonSchema().load(dict(name='John')) == 'John'
    assert PersonSchema().load([dict(name='John')]) == ['John']
    assert PersonSchema().load(dict(name='John'), many=True) == ['John']
    assert (PersonSchema().load(dict(name='John'), many=False) ==
            PersonSchema().load(dict(name='John')))
    assert PersonSchema

# Generated at 2022-06-21 11:28:37.977101
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    obj = _TimestampField()
    assert str(obj) == '<fields.Float>'
    assert obj.deserialize(1488232437.418776) == datetime(2017, 2, 28, 23, 20, 37, 418776)
    assert obj.serialize(datetime(2017, 2, 28, 23, 20, 37, 418776)) == 1488232437.418776
    assert obj.serialize(None) is None
    assert obj.deserialize(None) is None


# Generated at 2022-06-21 11:28:43.101160
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF.load([object()], many=True, partial=True, unknown='abc') == \
        [object()]
    assert SchemaF.load(object(), many=False, partial=None, unknown='abc') == \
        object()
    assert SchemaF.load(object(), many=True, partial=False, unknown='abc') == \
        object()

# Generated at 2022-06-21 11:28:52.888424
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses.dataclass(frozen=True)
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        pass

    x = [Foo(a=1, b='hello'), Foo(b='world', a=2)]
    x_encoded = FooSchema().dump(x, many=True)
    assert x_encoded == [{'a': 1, 'b': 'hello'}, {'a': 2, 'b': 'world'}]
    assert FooSchema().dumps(x, many=True) == '[{"a": 1, "b": "hello"}, {"a": 2, "b": "world"}]'

# Generated at 2022-06-21 11:29:21.041227
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    s = SchemaF()
    assert isinstance(s.dumps(1), str)
    assert isinstance(s.dumps([1]), str)
    assert isinstance(s.dumps({"a": 1}), str)
    assert isinstance(s.dumps([{"a": 1}]), str)

# Generated at 2022-06-21 11:29:23.303506
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field.__class__ == _IsoField


# Generated at 2022-06-21 11:29:30.609495
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    class Schema1(SchemaF[int]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    schema = Schema1()
    assert schema.dumps(1) == '[1]'
    assert schema.dumps([1, 2]) == '[1, 2]'
    assert isinstance(schema.dumps(1), str)
    assert isinstance(schema.dumps([1, 2]), str)
    assert schema.dumps(1, many=False) == '1'
    assert schema.dumps([1, 2], many=False) == '[1, 2]'

    class Schema2(SchemaF[int]):
        def __init__(self, *args, **kwargs):
            super().__

# Generated at 2022-06-21 11:29:39.113675
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class DataType2:
        _name: str

    @dataclass
    class DataType1:
        _name: str
        dt2: DataType2

    @dataclass
    class DataType:
        _name: str
        dt1: DataType1

    DataTypeSchema = build_schema(DataType, Mixin, False, False)
    dt = DataType("test",
                  dt1=DataType1("test1",
                                DataType2("test2")))
    assert DataTypeSchema().dump(dt) == {
        "_name": "test",
        "dt1": {
            "_name": "test1",
            "dt2": {
                "_name": "test2"
            }
        }
    }


# Generated at 2022-06-21 11:29:46.209248
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class S:
        a: Union[int, str, 'S']

    class S_SCHEMA(Schema):
        a = _UnionField(desc={
            int: fields.Int(),
            str: fields.Str(),
            S: S_SCHEMA,
        }, cls=S, field=dc_fields(S).a)

    assert S_SCHEMA().dumps(S(1)).decode() == '{"a": 1}'
    assert S_SCHEMA().dumps(S('a')).decode() == '{"a": "a"}'

# Generated at 2022-06-21 11:29:57.410055
# Unit test for function build_schema
def test_build_schema():
    from typing import List, Dict
    import dataclasses
    @dataclasses.dataclass
    class A():
     name: str
    @dataclasses.dataclass
    class B(A):
        age: int
    @dataclasses.dataclass
    class C(B):
        score: float
    x = build_schema(A, [], True, False)
    assert x.Meta.fields == ("name",)
    assert isinstance(x.name, fields.Str)
    y = build_schema(B, [], True, False)
    assert y.Meta.fields == ("name", "age")
    assert isinstance(y.name, fields.Str)
    assert isinstance(y.age, fields.Int)
    z = build_schema(C, [], True, False)

# Generated at 2022-06-21 11:30:08.943512
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Obj:
        x: int = field(default=None)

    DataClassSchema = build_schema(Obj, None, False, False)

    # Make sure the schema correctly handles objects with default values
    obj_1 = DataClassSchema().load({"x": 1})
    obj_2 = DataClassSchema().load({"x": None})
    assert obj_1 == obj_2
    assert obj_1.x == obj_2.x == None


    # Make sure the schema correctly handles objects with optional fields
    @dataclass
    class OptionalObj:
        x: int = field(default=None, metadata={"dataclasses_json": {"mm_field": fields.Int(allow_none=True)}})


# Generated at 2022-06-21 11:30:11.381038
# Unit test for constructor of class SchemaF
def test_SchemaF():
    def test_function(a: SchemaF[int], b: SchemaF[int], c: SchemaF[int]):
        return a, c

    pass



# Generated at 2022-06-21 11:30:16.901219
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class Person:
        name: str

    schema_f = SchemaF[Person]
    p = Person("Alice")
    enc = schema_f.dumps(p)
    assert enc == '{"name": "Alice"}'
    assert schema_f.loads(enc) == p



# Generated at 2022-06-21 11:30:19.660080
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF[datetime].load({'__type': 'datetime', 'isoformat': 'Z'})  # type: ignore
    assert s is not None  # type: ignore


# Generated at 2022-06-21 11:32:09.842564
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    pass


# Generated at 2022-06-21 11:32:20.152610
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    class User(typing.TypedDict):
        name: str
        email: str

    class Users(typing.TypedDict):
        users: typing.List[User]

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()

    class UsersSchema(SchemaF[Users]):
        users = fields.Nested(UserSchema, many=True)

    users_schema = UsersSchema()
    user_schema = UserSchema()

    # test case: list of Users
    users_data = {'users': [{'name': 'Bob', 'email': 'bob@example.com'},
                            {'name': 'John', 'email': 'john@example.com'}]}
    loaded_users

# Generated at 2022-06-21 11:32:22.561427
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(_IsoField(), _IsoField)


# Generated at 2022-06-21 11:32:30.846602
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    @dataclass
    class A:
        i: int

    schema = SchemaF[A]
    a = A(1)
    aa = [A(1), A(2)]

    assert schema.dumps(a) == '{"i": 1}'
    assert schema.dumps(aa) == '[{"i": 1}, {"i": 2}]'
    assert schema.dumps(a, many=True) == '[{"i": 1}]'
    assert schema.dumps(a, many=False) == '{"i": 1}'
    assert schema.dumps(aa, many=True) == '[{"i": 1}, {"i": 2}]'
    assert schema.dumps(aa, many=False) == '[{"i": 1}, {"i": 2}]'

    #

# Generated at 2022-06-21 11:32:36.145033
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Example(typing.Generic[A]):
        pass

    obj = SchemaF(Example[int], unknown=EXCLUDE)

# Unit tests for methods of class SchemaF
# http://mypy.readthedocs.io/en/latest/generics.html#generic-functions

# Generated at 2022-06-21 11:32:38.355063
# Unit test for constructor of class SchemaF
def test_SchemaF():
    def assert_raises():
        class CustomSchema(SchemaF):
            pass

    assert_raises()



# Generated at 2022-06-21 11:32:46.557416
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class TestCase:
        number: int

    TestCaseSchema = dataclasses_json.configure_marshmallow(
        SchemaF[TestCase],
        encoder=dataclasses_json.MSGPackEncoder
    )
    tc = TestCase(number=10)
    data = TestCaseSchema().dumps(tc)
    expected = b'\x81\xabnumber\n'
    assert type(data) == bytes
    assert data == expected

# Generated at 2022-06-21 11:32:53.124862
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp_field = _TimestampField()

    timestamp = 100000
    dt_aware = _timestamp_to_dt_aware(timestamp)

    timestamp_re = timestamp_field._serialize(value=dt_aware, attr=None, obj=None)
    assert timestamp_re == timestamp

    dt_aware_re = timestamp_field._deserialize(value=timestamp, attr=None, data=None)
    assert dt_aware_re == dt_aware


# Generated at 2022-06-21 11:32:59.595494
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        skill: typing.List[str]
        is_boy: bool
        other_data: typing.Dict[str, float]

    test_schema = schema(Person, None, False)
    assert isinstance(test_schema['name'], fields.Str)
    assert isinstance(test_schema['age'], fields.Int)
    assert isinstance(test_schema['skill'], fields.List)
    assert isinstance(test_schema['is_boy'], fields.Bool)
    assert isinstance(test_schema['other_data'], fields.Dict)

# Generated at 2022-06-21 11:33:09.629770
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields, pprint
    from typing import List, Union
    from marshmallow_dataclass import dataclass
    from dataclasses_json.api import encoder, dataclass_json

    @dataclass
    class User:
        email: str
        full_name: str
        books: List[str]

    @dataclass
    class Payload:
        message: str
        user: Union[User, List[User]]

    @dataclass_json
    @dataclass
    class PayloadModel:
        message: str
        user: Union[User, List[User]]

    schema = SchemaF()
    schema.fields['message'] = fields.String()
    schema.fields['user'] = fields.Nested(PayloadModel.Schema())