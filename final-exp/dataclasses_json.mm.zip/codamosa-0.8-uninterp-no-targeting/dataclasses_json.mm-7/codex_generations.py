

# Generated at 2022-06-21 11:24:10.229811
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField(required=True)
    field.deserialize(1234567890)
    try:
        field.deserialize(None)
        assert False, "_TimestampField.deserialize() should raise ValidationError"
    except ValidationError:
        pass



# Generated at 2022-06-21 11:24:20.302401
# Unit test for function build_type
def test_build_type():
    options_empty = {}
    options_with_data = {"key": "value"}
    original_inner = fields.Field(**options_empty)
    original_type = int
    original_type_many = typing.List[int]
    original_type_optional = typing.Optional[typing.List[int]]
    original_type_union = typing.Union[int, typing.List[int], typing.Dict[str, str]]
    original_type_union_optional = typing.Optional[typing.Union[int, typing.List[int]]]
    original_type_enum = typing.Optional[typing.Union[int, typing.List[int]]]

    assert build_type(original_type, options_empty, None, None, None)(original_type, options_empty) == original_inner

# Generated at 2022-06-21 11:24:21.174134
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass


# Generated at 2022-06-21 11:24:31.511270
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    F = fields.Field

    @dataclass
    class B:
        f: str

    class BSchema(Schema):
        class Meta:
            unknown = None
        f = F(missing='asd')


    @dataclass
    class C:
        f: str

    class CSchema(Schema):
        class Meta:
            unknown = None
        f = F(missing='asd')

    @dataclass
    class A:
        f: Union[B, C]

    class ASchema(Schema):
        class Meta:
            unknown = None

# Generated at 2022-06-21 11:24:32.603753
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()


# Generated at 2022-06-21 11:24:41.262344
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Foo(typing.NamedTuple):
        var_a: int

    class FooSchema(SchemaF[Foo]):
        var_a = fields.Int()

    @dataclasses.dataclass
    class FooDc:
        var_a: int

    schema = FooSchema()

    # dataclass
    foo_dc = FooDc(var_a=3)
    json_data = schema.dumps(foo_dc, many=False)
    assert json_data == '{"var_a": 3}'

    # list of dataclass
    list_foo_dc = [FooDc(var_a=3), FooDc(var_a=4)]

# Generated at 2022-06-21 11:24:42.519604
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    obj = _TimestampField()
    assert obj is not None


# Generated at 2022-06-21 11:24:50.650256
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass
    from sys import version_info

    @dataclass
    class MyClass:
        num1: Union[int, str, float] = 1
        num2: Union[int, str, float] = '2'
        num3: Union[int, str, float] = 3.0

    schema = _MarshmallowSchema.from_dataclass(MyClass)
    dc_loaded = schema.load(
        {'num1': 1, 'num2': '2', 'num3': 3.0}
    )
    dc_serialized = schema.dump(dc_loaded)
    if version_info >= (3, 7):
        assert dc_serialized == {'num1': 1, 'num2': '2', 'num3': 3.0}
   

# Generated at 2022-06-21 11:25:00.430906
# Unit test for function build_type
def test_build_type():
    import marshmallow as ma

    class A(ma.Schema):
        _options = [
            ('a', 'b', 'c'),
            ('d', 'e', 'f')
        ]
        name = ma.fields.Str()
        age = ma.fields.Int()

    class B(ma.Schema):
        _options = [
            ('g', 'h', 'i'),
            ('j', 'k', 'l')
        ]
        name = ma.fields.Str()
        age = ma.fields.Int()

    class C(B):
        pass

    class D(ma.Schema):
        _options = [
            ('m', 'n', 'o'),
            ('d', 'e', 'f')
        ]
        a = ma.fields.Nested(A, many=True)
        b

# Generated at 2022-06-21 11:25:10.628358
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: (...) -> None
    class Inner(typing.NamedTuple):
        my_key: int
        some_other_key: str

    class Outer(typing.NamedTuple):
        my_key: Inner
        some_other_key: Inner

    class InnerSchema(Schema):
        my_key = fields.Int()
        some_other_key = fields.Str()

    class OuterSchema(Schema):
        my_key = fields.Nested(InnerSchema)
        some_other_key = fields.Nested(InnerSchema)

    outer_schema = OuterSchema()
    outer = Outer(Inner(5, 'hello'), Inner(6, 'world'))


# Generated at 2022-06-21 11:25:25.074876
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass


    # Unit test for method dumps of class SchemaF
    def test_SchemaF_dumps():
        pass


# Generated at 2022-06-21 11:25:26.077448
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField
    assert True



# Generated at 2022-06-21 11:25:30.352785
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    from dataclasses import dataclass
    from marshmallow.schema import Schema

    @dataclass
    class P:
        a: int

    class S(SchemaF, Schema):
        pass

    assert S().dump([P(1)], many=True) == [{'a': 1}]

# Generated at 2022-06-21 11:25:42.276571
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union, List, Literal, NewType, get_type_hints
    from marshmallow import fields
    from marshmallow_enum import EnumField

    if sys.version_info < (3, 7):
        return True

    def to_type(t):
        if isinstance(t, type):
            return t
        type_hints = get_type_hints(t)
        return type(t.__name__, (t.__bases__,), type_hints)

    @to_type
    class Test():
        int_val: int = 5
        float_val: float = 6.7
        str_val: str = 'str'
        bool_val: bool = True
        bytes_val: bytes = b'bytes'

# Generated at 2022-06-21 11:25:45.599532
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert SchemaF[Dataclass]  # noqa
    assert SchemaF[List[Dataclass]]  # noqa
    assert SchemaF[
        typing.Union[List[Dataclass], Dataclass, Optional[Dataclass]]]  # noqa



# Generated at 2022-06-21 11:25:51.870435
# Unit test for constructor of class _UnionField
def test__UnionField():
    from . import test_unions
    from .test_unions import Test, Test1, Test2, Test3
    from .test_unions import Test4, Test5, Test6, Test7
    from .test_unions import Test8, Test9, Test10, Test11

    assert fields.Field and EnumField

    for cls, field, desc in test_unions.get_union_data():
        _UnionField(desc, cls, field)



# Generated at 2022-06-21 11:25:54.354514
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF[int]({})
    assert s.dump(2) == 2
    assert s.dump([2]) == [2]



# Generated at 2022-06-21 11:26:00.348910
# Unit test for constructor of class _UnionField
def test__UnionField():
    U = typing.Union[int, str]
    class X(typing.NamedTuple):
        x: U

    class S(_ExtendedEncoder, Schema):
        class Meta:
            target_class = X

        x = _UnionField(desc={int: fields.Integer, str: fields.String},
                        cls=X, field=X.__annotations__['x'])

    s = S()
    assert s.load({'x': 1}) == X(x=1)
    assert s.load({'x': '1'}) == X(x=1)

    s = S()
    assert s.load({'x': 1}).x == X(x=1).x
    assert s.load({'x': '1'}).x == X(x=1).x


# Generated at 2022-06-21 11:26:12.783552
# Unit test for function build_type
def test_build_type():
    from typing import Literal, Union, Optional, TypeVar, Dict, Any
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from marshmallow.utils import is_collection
    from dataclasses import dataclass

    @dataclass
    class Point:
        x: int
        y: int

    @dataclass
    class Rectangle:
        point: Point
        width: int
        height: int

    @dataclass
    class Sender:
        name: str
        address: str
        age: int


    @dataclass
    class Message:
        sender: Sender
        date: datetime
        is_important: bool
        sender_id: int = 42
        address_map: Dict[str, Point]

   

# Generated at 2022-06-21 11:26:23.930397
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Foo(Enum):
        a = 1
        b = 2

    t1 = typing.TypeVar('t')

    @dataclass
    class X:
        f1: t1

    @dataclass
    class Y:
        f1: int

    @dataclass
    class Z:
        f1: t1

    @dataclass
    class W:
        f1: typing.List[t1]

    @dataclass
    class V:
        f1: typing.Optional[typing.Union[t1, int]]

    @dataclass
    class U:
        f1: typing.Optional[typing.Union[X, Y]]
        f2: typing.Optional[typing.Union[Y, X]]

    @dataclass
    class T:
        f1: typing

# Generated at 2022-06-21 11:26:53.010526
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """Need to be a function because of mypy"""
    s = SchemaF[int]()



# Generated at 2022-06-21 11:26:56.680573
# Unit test for function build_schema
def test_build_schema():
    Schema = build_schema(cls=BasicExample,
                          mixin=object,
                          infer_missing=None,
                          partial=None)
    assert Schema.Meta.fields == ('a',)
    assert isinstance(Schema.a, fields.Int)


# Generated at 2022-06-21 11:27:06.736074
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import Any, Dict, List
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.utils import is_iterable_but_not_string
    from marshmallow.validate import Validator

    class UserSchema(Schema):
        id = fields.Int()

    def serialize(data: Any, many: bool, dump_method: str, serializer):
        many_ = many if many is not None else is_iterable_but_not_string(data)
        data, errors = getattr(serializer, dump_method)(data, many=many_)
        if errors:
            raise ValidationError(errors, data=data)
        else:
            return data


# Generated at 2022-06-21 11:27:16.457202
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow
    # Type check on the input
    try:
        schema = SchemaF[int]()
        assert False
    except NotImplementedError:
        pass

    # Type check on the return type
    class MySchema(SchemaF[int]):
        # noinspection PyMethodParameters,PyUnresolvedReferences
        @post_load
        def myfunc(self, d):
            return d

    schema = MySchema()
    data = schema.load({'one': 1})
    ret = schema.dump(data)
    assert isinstance(ret, dict)
    ret = schema.dump([data, data])
    assert isinstance(ret, list)



# Generated at 2022-06-21 11:27:19.390319
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError) as execinfo:
        SchemaF()
    assert 'SchemaF is helper class only' in str(execinfo.value)



# Generated at 2022-06-21 11:27:31.673207
# Unit test for function build_schema
def test_build_schema():
    from typing import Literal
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields
    import pytest

    @dataclass
    class A:
        a: Literal["A"]
        b: int = 2

    @dataclass
    class B:
        a: A

    b_schema = build_schema(B, None, False, True)

    assert b_schema(strict=True).load({'a': {"a": "A", "b": 2}}) == B(a=A(b=2))
    assert b_schema(strict=True).load({'a': {"a": "A"}}) == B(a=A(b=2))

    # Uncomment when https://github.com/marshmallow-code/marshmallow/issues/1899

# Generated at 2022-06-21 11:27:41.600325
# Unit test for function schema
def test_schema():
    from typing import List, Optional, Union
    from dataclasses import dataclass

    @dataclass
    class A:
        i: int
        s: str = 'a'
        l: List[int] = []
        u: Union[str, int, None] = None

    s = schema(A, None, False)
    assert len(s) == 4
    assert isinstance(s['i'], fields.Int)
    assert isinstance(s['s'], fields.Str)
    assert isinstance(s['l'], fields.List)
    assert isinstance(s['u'], fields.Field)

    @dataclass
    class B:
        n: Optional[int] = None

    s = schema(B, None, False)
    assert len(s) == 1

# Generated at 2022-06-21 11:27:52.095898
# Unit test for function build_type
def test_build_type():
    # Unit test
    from dataclasses import dataclass, field
    import typing
    import marshmallow

    @dataclass
    class TestObject:
        a: str
        b: typing.List[int]

    @dataclass
    class Test:
        a: TestObject
        b: typing.List[TestObject]

    schema = Test.schema()

    assert isinstance(schema.fields['a'], fields.Nested)
    assert isinstance(schema.fields['b'], fields.Nested)

    assert isinstance(schema.fields['a'].nested, marshmallow.Schema)
    assert isinstance(schema.fields['b'].nested, marshmallow.Schema)



# Generated at 2022-06-21 11:28:03.817373
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import ClassVar, List, Dict
    from marshmallow import Schema, fields
    class Base(Schema):
        foo: ClassVar[str] = fields.Str()
        # Pass unknown fields
        unknown = fields.Str()
    class Foo(Base):
        bar: ClassVar[Dict[str, int]] = fields.Dict(keys=fields.Str(), values=fields.Int())
    schema = SchemaF[Foo]()
    a = schema.load({'foo': 'bar', 'bar': {'a': 1}, 'baz': 2}, partial=True)
    a = schema.load({'foo': 'bar', 'bar': {'a': 'a'}, 'baz': 2}, many=True)

# Generated at 2022-06-21 11:28:06.063795
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()
    assert _TimestampField(default=datetime.now())
    assert _TimestampField(allow_none=True)


# Generated at 2022-06-21 11:29:00.223574
# Unit test for function schema
def test_schema():
    assert True

# Generated at 2022-06-21 11:29:06.306090
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class FakeSchema(SchemaF[str]):
        pass
    fake_json_data = ''
    p1: TOneOrMulti = FakeSchema().loads(fake_json_data)
    p2: TOneOrMulti = FakeSchema().loads(fake_json_data, many=True)
    p3: TOneOrMulti = FakeSchema().loads(fake_json_data, many=False)
    assert p1 == p2 == p3 == []



# Generated at 2022-06-21 11:29:08.471616
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__class__.__name__ == '_TimestampField'



# Generated at 2022-06-21 11:29:13.239214
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.fromisoformat('2020-01-01T01:01:01'), None, None) == 1577836661.0
    assert field._deserialize(1577836661.0, None, None) == datetime.fromisoformat('2020-01-01T01:01:01')


# Generated at 2022-06-21 11:29:22.739672
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import json
    from dataclasses import dataclass

    @dataclass
    class DC:
        pass

    def test():
        # dumps
        assert SchemaF[DC].dumps([DC()], many=True) == "[{}]"
        assert SchemaF[DC].dumps([DC()], many=True) == "[{}]"
        assert SchemaF[DC].dumps([DC()]) == "[{}]"
        assert SchemaF[DC].dumps(DC()) == "{}"
        assert SchemaF[DC].dumps(DC(), many=False) == "{}"

        assert SchemaF[DC]().dumps([DC()], many=True) == "[{}]"
        assert SchemaF[DC]().dumps([DC()], many=True) == "[{}]"

# Generated at 2022-06-21 11:29:30.150037
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass


# Generated at 2022-06-21 11:29:37.165377
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class TestClass:
        test: typing.List[TestClass]

        def __hash__(self):
            return hash((self.test))

    @dataclasses.dataclass
    class TestClass:
        test: typing.List[TestClass]

        def __hash__(self):
            return hash((self.test))

    S = dataclasses_json.configure(type_generator=SchemaF)

    c = TestClass([TestClass([])])
    j = S.dumps(c)
    assert j == '[{"test": [{"test": []}]}]'



# Generated at 2022-06-21 11:29:44.213173
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Ad:
        a: int

    @dataclass
    class A:
        l: typing.List[int]
        ad: Ad

    s = Schema.from_dataclass(A)
    sf = SchemaF.from_dataclass(A)
    assert s.dumps([A([1], Ad(1))]) == sf.dumps([A([1], Ad(1))])
    assert s.dumps(A([1], Ad(1))) == sf.dumps(A([1], Ad(1)))
    assert s.dumps(A([1], Ad(1))) == sf.dumps([A([1], Ad(1))], many=False)

# Generated at 2022-06-21 11:29:47.573022
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def dump(obj: typing.List[A], many: bool = None) -> typing.List[A]:
        pass

    data = [1, 2]
    dump(data)

# Generated at 2022-06-21 11:29:49.547724
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()
    return a


# Generated at 2022-06-21 11:32:02.159446
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses_json.schema import SchemaF
    from typing import List

    @dataclass
    class User:
        username: str
        email: str
        age: int

    class UserSchema(SchemaF[User]):
        username = fields.String()
        email = fields.Email()
        age = fields.Integer()

    user = User(username='hasadna', email='hasadna@example.com', age=21)
    users: List[User] = [user, user]
    schema = UserSchema()
    schema.dump(user)
    schema.dump(users)
    user_schema = UserSchema(many=False)
    user_schema.dump(user)
    user_schema.dump(users)

test_SchemaF_dump.__annotations__

# Generated at 2022-06-21 11:32:10.685009
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    item = SchemaF[str]().loads('{"foo": "bar"}')
    assert isinstance(item, str)

    items = SchemaF[str]().loads('[{"foo": "bar"}]')
    assert isinstance(items, list)
    assert isinstance(items[0], str)

# Generated at 2022-06-21 11:32:21.719284
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class _Class(SchemaF[int]):
        a: int = fields.Int()

    class _Class2(SchemaF[typing.List[int]]):
        a: int = fields.Int()

    # Uncomment next two lines for type check
    # _test_loads_and_test_cls(_Class(), [{"a": 1}, {"a": 2}])
    # _test_loads_and_test_cls(_Class2(), [{"a": 1}, {"a": 2}])
    pass


if sys.version_info >= (3, 7):
    class _SchemaWithGeneric(Schema):
        def __init_subclass__(cls, *args, **kwargs):
            super().__init_subclass__(*args, **kwargs)

# Generated at 2022-06-21 11:32:27.108612
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass



# Generated at 2022-06-21 11:32:38.401393
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow_enum import EnumField
    from marshmallow import validate

    from dataclasses_json.mm import MMEncoder
    from dataclasses_json.undefined import Undefined
    from dataclasses_json.mm_field import mm_field

    from tests.test_mm_field import test_all_cases


    @dataclass
    class TestClass:
        required_string: str = MISSING
        optional_string: typing.Optional[str] = None

    assert TestClass.schema().keys() == {'required_string', 'optional_string'}
    assert TestClass.schema()['required_string'].required
    assert not TestClass.schema()['optional_string'].required
    assert TestClass.schema()['optional_string'].allow_none

# Generated at 2022-06-21 11:32:42.212019
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp = datetime(2000, 12, 31, 23, 59, 59, 999999)
    assert _TimestampField()._deserialize(timestamp.timestamp()) == timestamp
    assert _TimestampField()._serialize(timestamp) == timestamp.timestamp()



# Generated at 2022-06-21 11:32:47.110767
# Unit test for constructor of class SchemaF
def test_SchemaF():
    _SchemaF = SchemaF[int]
    Schema  # this is here to suppress the ide warning that Schema is unused - we need it for the class above
    _: typing.Type[SchemaF]
    assert _SchemaF



# Generated at 2022-06-21 11:32:56.258099
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import fields
    from marshmallow.fields import Field

    class MyIntField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            return int(value)
        def _deserialize(self, value, attr, data, **kwargs):
            return int(value)

    class MyStrField(Field):
        def _serialize(self, value, attr, obj, **kwargs):
            return str(value)
        def _deserialize(self, value, attr, data, **kwargs):
            return str(value)


    class MySubFloatField(fields.Float):
        def _serialize(self, value, attr, obj, **kwargs):
            return float(value)

# Generated at 2022-06-21 11:32:57.232993
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-21 11:33:06.964637
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Person:
        def __init__(self, name):
            self.name = name
    class Employee(Person):
        def __init__(self, name, salary):
            super().__init__(name)
            self.salary = salary
    class Employer(Person):
        def __init__(self, name, employees):
            super().__init__(name)
            self.employees = employees
    from marshmallow import Schema
    from marshmallow import fields
    class PersonSchema(Schema):
        name = fields.String()
    class EmployeeSchema(Schema):
        salary = fields.Decimal()
        name = fields.String()
    class EmployerSchema(Schema):
        employees = fields.List(fields.Nested('PersonSchema'))
        name = fields.String()

    desc