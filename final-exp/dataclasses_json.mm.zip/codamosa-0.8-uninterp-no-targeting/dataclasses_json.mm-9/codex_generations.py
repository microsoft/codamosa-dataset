

# Generated at 2022-06-21 11:24:14.417748
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF[C].loads('[{"a": 2}]', many=True)[0], C)

# Generated at 2022-06-21 11:24:17.014383
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class S(SchemaF[A]):
        pass
    s = S()
    x: S = s
    x.dump([])
    x.dump([1])
    x.dump(1)
    obj = [1]
    x.dump(obj)

# Generated at 2022-06-21 11:24:18.844981
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():  # type: ignore
    # This function will be removed in the future
    pass

# Generated at 2022-06-21 11:24:23.940393
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class MyClass(object):
        def __init__(self, foo):
            # type: (int) -> None
            self.foo = foo

    class MySchema(SchemaF[MyClass]):
        foo = fields.Int()

    instance1 = MySchema().load({'foo': 1})
    assert instance1.foo == 1
    instance2 = MySchema().load([{'foo': 1}])[0]
    assert instance2.foo == 1



# Generated at 2022-06-21 11:24:32.828496
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MyDc(typing.Generic[A]):
        pass

    class MySchema(SchemaF[A]):
        def __init__(self, data: A):
            self.data = data
            super().__init__(strict=True)

        @post_load
        def make_obj(self, data):
            return self.data

    my_schema = MySchema[MyDc]({1, 2, 3})
    assert my_schema.dump(MyDc()).keys() == {'data'}
    assert my_schema.loads('{"data": {"1", "2", "3"}}').data == {1, 2, 3}

# Generated at 2022-06-21 11:24:44.751109
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    class Example(SchemaF):
        name: str
        age: int
    # Test example 1
    example = Example(unknown=EXCLUDE)
    obj = example.load({'name': 'Mr. Foo', 'age': 42})
    assert obj.name == 'Mr. Foo'
    assert obj.age == 42
    # Test example 2
    example = Example(unknown=EXCLUDE)
    obj = example.loads('{"name":"Mr. Foo", "age":42}')
    assert obj.name == 'Mr. Foo'
    assert obj.age == 42



# Generated at 2022-06-21 11:24:49.418290
# Unit test for function build_schema
def test_build_schema():
    import pydantic
    import typing
    from marshmallow import Schema

    C, D = typing.TypeVar('C'), typing.TypeVar('D')

    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json
    @dataclass
    class B(A):
        b: str

    @dataclass_json
    @dataclass
    class E(A, B):
        e: str

    @dataclass_json
    @dataclass
    class F:
        e: E

    @dataclass_json
    @dataclass
    class G:
        f: typing.List[F]


# Generated at 2022-06-21 11:24:55.928673
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SchemaFImpl(SchemaF):
        pass
    obj = None
    SchemaFImpl().dumps(obj, many=None)
    SchemaFImpl().dump(obj, many=None)
    SchemaFImpl().load(obj, many=None, unknown=None)
    SchemaFImpl().loads(obj, many=None)



# Generated at 2022-06-21 11:24:57.724541
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # noinspection PyTypeChecker
    sf = SchemaF()
    assert False


# Generated at 2022-06-21 11:25:08.366872
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import overload

    from marshmallow.exceptions import ValidationError
    from typing_extensions import Literal

    @overload
    def dump(b: bytes, c: Literal['a']) -> Literal[1]: pass

    @overload
    def dump(b: bytes, c: Literal['b']) -> Literal[2]: pass

    @overload
    def dump(b: bytes, c: Literal['c']) -> Literal[3]: pass

    def dump(b: bytes, c: Literal['a']) -> Literal[1]: return 1

    def dump(b: bytes, c: Literal['b']) -> Literal[2]: return 2

    def dump(b: bytes, c: Literal['c']) -> Literal[3]: return 3


# Generated at 2022-06-21 11:25:28.142781
# Unit test for function build_type
def test_build_type():
    from dataclasses_json import dataclass_json
    import marshmallow as ma

    @dataclass_json
    @dataclass
    class User:
        first_name: str
        last_name: str

    @dataclass_json
    @dataclass
    class Asset:
        name: str

    @dataclass_json
    @dataclass
    class Task:
        title: str
        slug: str

    @dataclass_json
    @dataclass
    class MyClass:
        user: User
        users: typing.List[User]
        assets: typing.Dict[str, Asset]
        ids: typing.List[int]
        tasks: typing.List[Task]
        cast_optional: typing.Optional[int]
        task: typing.Optional[Task]
       

# Generated at 2022-06-21 11:25:39.628440
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[int]):
        x = fields.Int()
    schema = TestSchema()

    assert schema.dumps({'x': 1}) == '{"x": 1}'
    assert schema.dumps({'x': 1}, many=False) == '{"x": 1}'
    assert schema.dumps([{'x': 1}, {'x': 2}]) == '[{"x": 1}, {"x": 2}]'
    assert schema.dumps([{'x': 1}, {'x': 2}], many=True) == '[{"x": 1}, {"x": 2}]'
    assert schema.dumps([{'x': 1}, {'x': 2}], many=False) == '[{"x": 1}, {"x": 2}]'

# Generated at 2022-06-21 11:25:42.012143
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    SchemaF[str].dumps(['a', 'b'])
    SchemaF[str].dumps('a')

# Generated at 2022-06-21 11:25:51.714338
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TestClass:
        pass

    class TestClass2:
        pass

    test_field = dc_fields(default_factory=list)
    test_field.init_dataclass(TestClass, 'field_name')
    test_field.metadata = {}
    test_field.type = typing.Union[TestClass, TestClass2]
    test_field.__module__ = '__main__'
    t = _UnionField(
        {TestClass: fields.Field, TestClass2: fields.Field}, TestClass,
        test_field)
    assert t.desc == {TestClass: fields.Field, TestClass2: fields.Field}
    assert t.cls == TestClass
    assert t.field == test_field

# Generated at 2022-06-21 11:25:55.559637
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestFoo(typing.NamedTuple):
        a: str
        b: Optional[str] = None

    class TestSchemaF(SchemaF[TestFoo]):
        a = fields.Str()
        b = fields.Str()

    assert TestSchemaF().load(dict(a='x', b='y')) == TestFoo('x', 'y')



# Generated at 2022-06-21 11:26:08.129742
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize('2020-01-02T03:04:05.678901+00:00', 'a', {}) == datetime(2020, 1,  2, 3,  4,  5,  678901, tzinfo=datetime.timezone.utc)
    assert field._serialize(datetime(2020, 1,  2, 3,  4,  5,  678901, tzinfo=datetime.timezone.utc), 'a', {}) == '2020-01-02T03:04:05.678901+00:00'

# Generated at 2022-06-21 11:26:17.213689
# Unit test for constructor of class _UnionField
def test__UnionField():
    from decimal import Decimal
    from dataclasses import dataclass
    from typing import List, Union, Any

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        a: Union[A, B, str, int, float, List[str], List[int], List[float], List[A], List[B]]

    schema = create_schema(C)

    assert isinstance(schema.declared_fields['a'], _UnionField)

# Generated at 2022-06-21 11:26:27.225869
# Unit test for function build_schema
def test_build_schema():
    class Coords:
        def __init__(self, x: float, y: float):
            self.x = x
            self.y = y

    def custom_schema_dumps(self, *args, **kwargs):
        if 'cls' not in kwargs:
            kwargs['cls'] = _ExtendedEncoder

        return Schema.dumps(self, *args, **kwargs)

    @dataclass
    class Tweets:
        id: str
        coords: Coords

    mixin = serializable()(Tweets)
    partial = False

    DataClassSchema = build_schema(mixin, False, partial)

    assert hasattr(DataClassSchema, 'Meta')
    assert hasattr(DataClassSchema, 'make_tweets')
    assert hasattr

# Generated at 2022-06-21 11:26:30.346986
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class TestClass:
        a: str 


    assert isinstance(schema(TestClass, Schema, False), dict)

# Generated at 2022-06-21 11:26:34.289735
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    obj = 1
    assert isinstance(SchemaF[int].load(1), int)

    objs = [1, 2, 3]
    assert isinstance(SchemaF[int].load(objs), list)



# Generated at 2022-06-21 11:27:08.981851
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        _TimestampField()._serialize(datetime.now(), None, None)
        _TimestampField()._deserialize(datetime.now().timestamp(), None, None)
    except ValidationError as e:
        assert False, "Failed to serialize or deserialize, error: " + str(e)
    try:
        _TimestampField()._serialize(None, None, None)
    except ValidationError as e:
        assert False, "Failed to serialize, error: " + str(e)
    try:
        _TimestampField()._deserialize(None, None, None)
    except ValidationError as e:
        assert False, "Failed to deserialize, error: " + str(e)

# Generated at 2022-06-21 11:27:16.366973
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class X:
        x: int

    SchemaF[X].load([{"x": 4}], many=True)



# Generated at 2022-06-21 11:27:22.097410
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_format = datetime.now().isoformat()
    iso_field = _IsoField()
    deserialized = iso_field._deserialize(iso_format, None, None)
    serialized = iso_field._serialize(deserialized, None, None)
    assert deserialized.isoformat() == serialized
    # a deserialized datetime object should be equal to utcnow
    assert deserialized - datetime.utcnow() < datetime.timedelta(seconds=0.001)



# Generated at 2022-06-21 11:27:29.097390
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f._serialize(datetime(2020, 1, 1), "test", None) == 1577836800.0
    assert (f._deserialize(1577836800.0, "test", None) ==
            datetime(2020, 1, 1, tzinfo=fields.LocalTimezone()))
    assert f.__class__.__name__ == "_TimestampField"


# Generated at 2022-06-21 11:27:29.788641
# Unit test for constructor of class _UnionField
def test__UnionField():
    pass



# Generated at 2022-06-21 11:27:40.733621
# Unit test for constructor of class _UnionField
def test__UnionField():
    # empty schema
    schema_ = Schema(type_='object')
    desc = {int: schema_}
    field = _UnionField(desc=desc, cls='test_cls', field='test_field')
    assert field.desc == desc
    assert field.cls == 'test_cls'
    assert field.field == 'test_field'
    assert field.allow_none is True
    assert field.required is False
    assert field.load_only is False
    assert field.dump_only is False

    # not empty schema
    schema_ = Schema(type_='object', required=True, allow_none=False)
    desc = {int: schema_}
    field = _UnionField(desc=desc, cls='test_cls', field='test_field')
    assert field.desc == desc


# Generated at 2022-06-21 11:27:48.614790
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class Item(object):
        def __init__(self, name: str, price: Decimal) -> None:
            self.name = name
            self.price = price

    class ItemSchema(Schema):
        name = fields.Str()
        price = fields.Decimal()

    item = Item('foo', Decimal('12.345'))

    res = ItemSchema().dumps(item)
    assert res == '{"name": "foo", "price": "12.345"}'


# Generated at 2022-06-21 11:27:50.793521
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[TestDc].loads('').first_field == 'x'


# Generated at 2022-06-21 11:28:02.823480
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    # this method is required to test usage of SchemaF
    class T(typing.Generic[A]):
        def loads(self, json_data, **kwargs):  # type: ignore
            pass
    T.loads(None, None)

# Generated at 2022-06-21 11:28:06.614919
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass()
    class ABC:
        a: str
        b: int
    assert(SchemaF[ABC]().dumps([ABC(a='a', b=5), ABC(a='b', b=6)]) == '[{"b": 5, "a": "a"}, {"b": 6, "a": "b"}]')

# Generated at 2022-06-21 11:29:01.992509
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Test(SchemaF):
        class Meta:
            fields = ('a', )
    Test.loads(b'{}')  # type: ignore


# Generated at 2022-06-21 11:29:05.583164
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields, Schema

    class Test(Schema, typing.Generic[A]):
        id = fields.Int(dump_only=True)

    assert Test[int]().dumps(42) == '{"id": 42}'



# Generated at 2022-06-21 11:29:12.090113
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from datetime import datetime
    timestampfield = _TimestampField(required=False, default=None)
    assert timestampfield._serialize(datetime.now(), None, None) is not None
    assert timestampfield._serialize(None, None, None) is None
    assert timestampfield._deserialize(datetime.now().timestamp(), None, None) is not None
    assert timestampfield._deserialize(None, None, None) is None

test__TimestampField()



# Generated at 2022-06-21 11:29:21.850747
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class B:
        def __init__(self, x: int, y: str):
            self.x = x
            self.y = y

    class C:
        def __init__(self, z: int):
            self.z = z

    class UnionSchema(Schema):
        a = fields.Integer()

    class BAndCSchema(Schema):
        x = fields.Integer()
        y = fields.String()
        z = fields.Integer()

    class TestSchema(Schema):
        union = _UnionField(
            {A: UnionSchema, B: BAndCSchema, C: BAndCSchema},
            'TestSchema', A, a=fields.Integer())

    schema = TestSchema()

    a = A()
    b = B

# Generated at 2022-06-21 11:29:29.404812
# Unit test for function build_schema
def test_build_schema():
    dc_class = ...  # type: typing.Type[A]
    mixin = ...  # type: typing.Type[A]
    infer_missing = ...  # type: bool
    partial = ...  # type: bool
    assert isinstance(build_schema(dc_class, mixin, infer_missing, partial), SchemaF)


if sys.version_info >= (3, 7):
    @functools.singledispatch
    def SchemaDecorator(cls, *, mixin=None, infer_missing=True,
                        partial=False):
        return build_schema(cls, mixin, infer_missing, partial)
else:
    def SchemaDecorator(cls, *, mixin=None, infer_missing=True,
                        partial=False):
        return build_schema

# Generated at 2022-06-21 11:29:31.127793
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__class__.__name__ == '_IsoField'


# Generated at 2022-06-21 11:29:38.591915
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass
    class FooSchema(SchemaF[Foo]):
        pass

    x: typing.List[Foo] = [Foo(), Foo()]
    result = FooSchema().dump(x, many=True)
    assert result == [{}, {}]

    x = Foo()
    result = FooSchema().dump(x, many=False)
    assert result == {}

    result = FooSchema().dump(x)
    assert result == {}

    x = [Foo(), Foo()]
    result = FooSchema().dump(x)
    assert result == [{}, {}]

    x = Foo()
    result = FooSchema().dump(x)
    assert result == {}

    class Bar:
        pass
    class BarSchema(SchemaF[Bar]):
        pass



# Generated at 2022-06-21 11:29:43.287306
# Unit test for function build_schema
def test_build_schema():
    class Dummy:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    @dataclass
    class Y:
        pass


    @dataclass
    class X:
        y: Y = field(default_factory=Y)
        z: int = field(default=2)

    assert isinstance(build_schema(X, Dummy, False, False), type)



# Generated at 2022-06-21 11:29:55.214013
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def f(obj):
        assert isinstance(obj, list)
        return len(obj) - 1
    class A:
        def __init__(self, x: int):
            self.x = x
    class S(SchemaF[A]):
        @post_load
        def make_object(self, data, many, **kwargs):
            return A(data['x'])
    s = S()
    res = s.load([{'x': 1}, {'x': 2}, {'x': 3}], many=True, unknown=f)
    assert type(res) is list
    assert isinstance(res[0], A)
    assert len(res) == 3
    assert res[0].x == 1
    assert res[1].x == 2
    assert res[2].x == 3
# Unit

# Generated at 2022-06-21 11:30:07.102322
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class T(Enum):
        option1 = 1
        option2 = 2

    @dataclass
    class Tmp(object):
        field1: typing.Union[str, T]
        field2: typing.List[typing.Union[str, int]]

    schema = SchemaF[Tmp](unknown='EXCLUDE')

    assert schema.load({'field2': ['42', '24']}).field2 == ['42', '24']
    assert schema.load({'field1': '42', 'field2': ['24']}).field2 == ['24']
    assert schema.load({'field1': 1, 'field2': ['42', '24']}).field1 == T.option1
    assert schema.load({'field1': 1, 'field2': [42, 24]}, many=False).field

# Generated at 2022-06-21 11:32:13.726130
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField is not None


# Generated at 2022-06-21 11:32:24.489118
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    """
    Run the unit test for method dumps of class SchemaF.
    """
    from marshmallow import Schema, fields, post_dump
    from dataclasses import dataclass

    @dataclass
    class Todo:
        task: str
        id: int = None

    class TodoSchema(Schema):
        class Meta:
            # Fields to expose
            fields = ('task', 'id')

        @post_dump
        def wrap(self, in_data, many, **kwargs):
            return {"todos": in_data} if many else in_data

    schema = TodoSchema()

    assert '{"todos":[{"task":"Run around in circles","id":1}]}' == schema.dumps([Todo(task="Run around in circles", id=1)])

# Generated at 2022-06-21 11:32:25.091960
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-21 11:32:32.624706
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing_extensions import TypedDict

    class MiniDcClass(TypedDict):
        name: str
    dc_schema = SchemaF[MiniDcClass]()
    # notice that mm has not just the correct return type
    # you can see it when you uncomment the next line
    # res = dc_schema.dump({'name': 'my name'}, many=False)
    # When you uncomment the next line you will see an error:
    # Incompatible types in assignment (expression has type "Dict[str, Any]",
    # variable has type "SchemaF[{'name': str}][TEncoded]")
    # res: SchemaF[{'name': str}][TEncoded]  = dc_schema.dump({'name': 'my name'}, many=False)


# Generated at 2022-06-21 11:32:43.775746
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A, b: A):
            self.a = a
            self.b = b

    class FooSchema(SchemaF[Foo[str]]):
        class Meta:
            dataclass = Foo
            unknown = EXCLUDE

        a = fields.Str()
        b = fields.Str()

    foo = Foo(a='a', b='b')
    assert foo == FooSchema().loads({"a": "a", "b": "b"})
    assert foo == FooSchema().loads(
        '{"a": "a", "b": "b"}')[0] or FooSchema().loads(
            '[{"a": "a", "b": "b"}]')[0]
    # test the type of the

# Generated at 2022-06-21 11:32:54.700135
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class StudentF(typing.Generic[A]):
        id: int
        first_name: str
        last_name: str
        age: int
        tutor: A

    class TutorF(typing.Generic[A]):
        id: int
        first_name: str
        last_name: str
        age: int

    @dataclasses.dataclass
    class TutorWithStudentsF(typing.Generic[A], TutorF[A]):
        students: typing.List[A]

    @dataclasses.dataclass
    class StudentWithTutorF(typing.Generic[A], StudentF[A]):
        tutor: A


# Generated at 2022-06-21 11:33:01.385932
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    @dataclass
    class Point(DataClassJsonMixin):
        x: int
        y: int
        z: int = 0
    schema = build_schema(Point, DataClassJsonMixin, True, False)
    assert issubclass(schema, Schema)
    assert schema.Meta.fields == ('x','y','z')
    assert isinstance(schema.Meta.render_module, str)
    assert callable(schema.make_point)
    assert callable(schema.dump)
    assert callable(schema.dumps)
    assert isinstance(schema.x,fields.Integer)
    assert isinstance

# Generated at 2022-06-21 11:33:02.908998
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-21 11:33:12.976639
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, asdict
    from schema.schema import build_schema
    import typing
    import uuid
    from dataclasses_json.api import (
        config,
        get_schema,
        load,
        loads,
        mm_schema
    )
    from json import loads as json_loads
    from dataclasses_json.api import DataclassJSONMixin
    base_config = config()
    def test_decorator():
        @dataclass
        class Test:
            union: typing.Union[int, str]
            add: typing.Generic[int]
            optional: typing.Optional[int]
        TestSchema = build_schema(Test, type, base_config.infer_missing,
                                  base_config.error_on_unknown)
       

# Generated at 2022-06-21 11:33:21.767199
# Unit test for function build_type
def test_build_type():
    """
    Testing for the build_type function
    """
    from marshmallow import fields
    from typing_inspect import is_union_type as ut
    from dataclasses import dataclass
    from enum import Enum

    @dataclass
    class _D(object):
        pass

    class _E(Enum):
        foo = 1
        bar = 2

    def _get_type(t):
        return build_type(t, options={}, mixin=_D, field=None, cls=_D)

    # Test basic types
    int_type = _get_type(int)
    assert isinstance(int_type, fields.Int)

    dict_type = _get_type(dict)
    assert isinstance(dict_type, fields.Dict)

    # Test optional types
    not_optional