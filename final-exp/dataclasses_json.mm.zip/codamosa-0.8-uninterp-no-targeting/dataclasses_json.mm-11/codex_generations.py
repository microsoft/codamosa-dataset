

# Generated at 2022-06-21 11:24:37.993896
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class Foo:
        foo: int
    schema = Schema(Foo)
    f = schema.load({'foo': 1})
    assert isinstance(f, Foo)
    f = schema.loads(b'{"foo": 1}')
    assert isinstance(f, Foo)
    f = schema.load([{'foo': 1}, {'foo': 2}])
    assert isinstance(f, typing.List[Foo])
    f = schema.loads(b'''
        [{"foo": 1}, {"foo": 2}]
        '''.decode('utf-8'))
    assert isinstance(f, typing.List[Foo])


# Generated at 2022-06-21 11:24:45.648056
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json()
    @dataclass
    class MyClass:
        field1: int
        field2: str
        field3: float=None
        field4: bool
        field5: Tuple[float, ...]=None

    schemas = build_schema(MyClass, ..., True, False)
    fields = schemas().fields
    assert fields.keys() == {'field1', 'field2', 'field3', 'field4', 'field5'}
    # keys = [f.name for f in fields]
    assert fields['field1'].__class__.__name__ == "Integer"
    assert fields['field2'].__class__.__name__ == "String"
    assert fields['field3'].__class__.__name__ == "Float"

# Generated at 2022-06-21 11:24:56.466561
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    class MM(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            if value is not None:
                return value.timestamp()
            else:
                if not self.required:
                    return None
                else:
                    raise ValidationError(self.default_error_messages["required"])

        def _deserialize(self, value, attr, data, **kwargs):
            if value is not None:
                return _timestamp_to_dt_aware(value)
            else:
                if not self.required:
                    return None
                else:
                    raise ValidationError(self.default_error_messages["required"])

    @dataclass
    class DataClass:
        mm_field: MM = MM()


# Generated at 2022-06-21 11:25:05.291255
# Unit test for function build_type
def test_build_type():
    # Test for typing.Optional[typing.Union[int, None]]
    field_name = 'id'
    field_type = typing.Optional[typing.Union[int, None]]
    options = {'required': False}
    mixin = object
    field = dc_fields(typing.NamedTuple("TmpCls", [(field_name, field_type)]))[0]
    cls = typing.NamedTuple("TmpCls", [(field_name, field_type)])
    generated_field = build_type(field_type, options, mixin, field, cls)
    expected_field = fields.Int(required=False, allow_none=True)
    assert str(generated_field) == str(expected_field)

    # Test for typing.Optional[typing.Union[datetime.

# Generated at 2022-06-21 11:25:14.096738
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    iso_field._serialize(datetime.today())
    iso_field._deserialize(datetime.today().isoformat())
    # Test auto error handling
    try:
        iso_field._serialize(None)
        assert False
    except ValidationError:
        pass
    try:
        iso_field._deserialize(None)
        assert False
    except ValidationError:
        pass
    # Test required
    iso_field = _IsoField(required=False)
    assert iso_field._serialize(None) is None
    assert iso_field._deserialize(None) is None



# Generated at 2022-06-21 11:25:17.456336
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) == datetime.now().isoformat()
    assert _IsoField(required=True)._serialize(None, None, None) == "required"



# Generated at 2022-06-21 11:25:19.199606
# Unit test for constructor of class _UnionField
def test__UnionField():
    Union = typing.Union



# Generated at 2022-06-21 11:25:26.780004
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, asdict
    @dataclass
    class A:
        b: int

    @dataclass_json
    class B:
        a: typing.Union[A, int]
        c: typing.Mapping[int, str]
        d: typing.Tuple[int, str, float]

    b = B(A(b=1), {1: "foo"}, (1, "foo", 3.14))

    schema = B.schema()
    assert asdict(schema.load(schema.dump(b))) == asdict(b)

# Generated at 2022-06-21 11:25:32.542047
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    SchemaF.loads(json_data=b"", many=True, unknown='error')
    SchemaF.loads(json_data='', many=None, unknown='error')
    SchemaF.loads(json_data=b"")

# Generated at 2022-06-21 11:25:44.301807
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.schema_codegen import SchemaF as SF
    from tests import TestEnum


    @dataclasses.dataclass
    class TestClass:
        test_data: str

    @dataclasses.dataclass
    class TestClass2:
        test_data: TestEnum

    fields = {
        'test_data': fields.Str()
    }

    fields2 = {
        'test_data': EnumField(TestEnum)
    }

    class TestSchema(SF[TestClass]):
        test_data = fields['test_data']

    class TestSchema2(SF[TestClass2]):
        test_data = fields2['test_data']

    assert TestSchema().load

# Generated at 2022-06-21 11:26:03.414423
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class X(A):
        pass

    class S(SchemaF[X]):
        pass

    assert S.dump([X()], many=True) == [{}]
    assert S.dumps([X()], many=True)
    assert S.dumps([X()], many=True, **{'separators': (',', ':')})
    assert S.loads(b'[{}]', many=True) == [X()]
    assert S.load(b'[{}]', many=True) == [X()]



# Generated at 2022-06-21 11:26:06.625548
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    SchemaF[int]
    SchemaF[typing.List[int]]



# Generated at 2022-06-21 11:26:14.597457
# Unit test for function schema
def test_schema():
    import marshmallow.fields as f

    class User:
        def __init__(self, id=0, name='Maximilian'):
            self.id = id
            self.name = name

    from dataclasses import dataclass, field

    import dataclasses_json
    import json


    @dataclass
    class A:
        id: int
        b: User
        c: typing.Optional[User] = None
        d: typing.List[User]

    @dataclass
    class B:
        id: int
        b: typing.Optional[User]
        c: typing.Optional[User] = None
        d: typing.List[User]

    @dataclass
    class C:
        id: int
        b: User
        c: typing.Optional[User] = None
        d

# Generated at 2022-06-21 11:26:24.494988
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class User:
        name: str
        age: int
        birthday: typing.Optional[datetime]
        some_dict: typing.Optional[CatchAllVar]
        something_else: typing.Optional[CatchAllVar]

    assert schema(User, User, False) == {
        'name': fields.String(),
        'age': fields.Integer(),
        'birthday': _TimestampField(allow_none=True),
        'some_dict': fields.Dict(),
        'something_else': fields.Dict(),
    }



# Generated at 2022-06-21 11:26:32.596900
# Unit test for constructor of class _IsoField
def test__IsoField():
	t = _IsoField()
	assert t._deserialize(t._serialize(datetime.now()),None,None)
	assert t._deserialize(t._serialize(float('nan')),None,None)
	assert t._deserialize(t._serialize(float('inf')),None,None)
	assert t._deserialize(t._serialize(None),None,None)
	try:
		t._deserialize(None,None,None)
		assert False,'ValidationError Exception is not raised for _deserialize(None,None,None)'
	except ValidationError:
		pass


# Generated at 2022-06-21 11:26:44.188740
# Unit test for function build_schema
def test_build_schema():
    import pytest
    from ..core import DataclassJsonMixin
    from ..core import fields
    from ..core import case, dataclass_json

    # prepare data
    @dataclass_json
    @dataclass
    class Sample(DataclassJsonMixin):
        val_a: int = field(metadata=dict(mm_field=fields.Int()))
        val_b: str = field(metadata=dict(
            mm_field=fields.Str(validate=lambda x: len(x) > 2)))

    # prepare scema
    @dataclass_json
    @dataclass
    class SampleSchema(DataclassJsonMixin):
        val_a: int = field(metadata=dict(mm_field=fields.Int()))

# Generated at 2022-06-21 11:26:53.928634
# Unit test for function schema
def test_schema():
    @dataclass
    class BaseSchema(SchemaType):
        d: datetime = field(mm_field=fields.DateTime, default=CatchAllVar)

    @dataclass
    class A:
        a: int = 1
        b: str = "test"
        c: UUID = UUID("3b44dade-66c8-44de-bdfb-6f9b6c2b6d7c")

    schema = {
        "a": fields.Int,
        "b": fields.Str,
        "c": fields.UUID
    }
    assert schema(A, BaseSchema, infer_missing=True) == schema


# Generated at 2022-06-21 11:26:56.097032
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        with pytest.raises(NotImplementedError) as excinfo:
            SchemaF()



# Generated at 2022-06-21 11:26:59.135262
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # type: () -> None

    with warnings.catch_warnings(record=True):
        SchemaF()
        assert True



# Generated at 2022-06-21 11:27:01.308034
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp_field = _TimestampField()
    assert str(datetime.now()) in str(timestamp_field)



# Generated at 2022-06-21 11:27:36.457718
# Unit test for function build_type
def test_build_type():
    import marshmallow
    import typing
    # this tests the inner function of build_type which is defined above
    assert(isinstance(build_type({}, {}, None, None, None)(typing.Any, {}), marshmallow.fields.Raw))  # noqa: E501
    import marshmallow_enum
    @dataclass_json
    @dataclass
    class TestEnum(Enum):
        A = 1
        B = 2
    assert(isinstance(build_type(TestEnum, {}, None, None, None)(TestEnum, {}), marshmallow_enum.EnumField))  # noqa: E501
    import typing
    @dataclass_json
    @dataclass
    class TestUnion:
        some_thing: typing.Union[str, int]

# Generated at 2022-06-21 11:27:44.712015
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow.schema import Schema as SchemaF_Schema  # noqa
    if sys.version_info < (3, 7):
        return
    class A(object):
        def __init__(self, x: int) -> None:
            self.x = x
    class B(A):
        def __init__(self, x: int, y: A) -> None:
            self.x = x
            self.y = y
    class C(SchemaF_Schema):
        x = fields.Int()
        y = fields.Nested('self')
    class D(SchemaF_Schema):
        x = fields.Int()
    class E(SchemaF[A]):
        x = fields.Int()
    class F(SchemaF[A]):
        x = fields.Int

# Generated at 2022-06-21 11:27:55.852700
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclass
    class Foo:
        bar: str

    @dataclass
    class Bar:
        xyz: int
        foo: typing.List[Foo]

    assert SchemaF[Foo].from_dataclass(Foo('x')).dumps([Foo('a'), Foo('b')]) == (
        '[{"bar": "a"}, {"bar": "b"}]')
    assert SchemaF[Bar].from_dataclass(Bar(42, [Foo('x')])).dumps(
        Bar(42, [Foo('a'), Foo('b')])) == '{"xyz": 42, "foo": [{"bar": "a"}, {"bar": "b"}]}'

# Generated at 2022-06-21 11:28:06.544720
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def loads(p1, p2, *p3, p4) -> typing.Union[str, list[str]]: ...
    assert typing.get_type_hints(loads)['return'] == typing.Union[str, list[str]]


# Generated at 2022-06-21 11:28:19.252625
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Simple(typing.Generic[A]):
        def __init__(self, t: A) -> None:
            self.t = t

    s = SchemaF()
    many = True
    partial = None
    unknown = None
    data = Simple([])
    data = Simple({})
    data = Simple(123)
    data = Simple(123.4)
    data = Simple('str')
    data = Simple(True)

    s.dumps(data, many)
    s.dump(data, many)
    s.loads(data, many)
    s.load(data, many)

    data = [Simple({})]
    data = [Simple(123)]
    data = [Simple(123.4)]
    data = [Simple('str')]
    data = [Simple(True)]

# Generated at 2022-06-21 11:28:22.038481
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        class TestSchema(SchemaF, typing.Generic[A], Schema):
            pass



# Generated at 2022-06-21 11:28:30.963775
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Movie:
        def __init__(self, title: str, genre: str,
                     release_year: datetime.date,
                     extra_data: typing.Dict[str, int]) -> None:
            self.title = title
            self.genre = genre
            self.release_year = release_year
            self.extra_data = extra_data

    @dataclasses_json.dataclass_json(decoder=SchemaF, encoder=SchemaF)
    class MovieF(Movie):
        pass

    json = """
    {"title":"THX 1138",
    "genre":"Science fiction",
    "release_year":"1971"}
    """
    movie = dataclasses_json.loads(json, MovieF)
    assert movie.title == 'THX 1138'

# Generated at 2022-06-21 11:28:42.451107
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import typing
    import marshmallow
    import marshmallow_dataclass
    from django.db import models
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class SchemaF(typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-21 11:28:48.684680
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()

    serialized_value = iso_field._serialize(datetime(2019, 12, 18), "attr", "obj")
    assert serialized_value == "2019-12-18T00:00:00"

    deserialized_value = iso_field._deserialize("2019-12-18T00:00:00", "attr", "data")
    assert deserialized_value == datetime(2019, 12, 18)

test__IsoField()



# Generated at 2022-06-21 11:28:53.115747
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = [1, 2, 3]
    dumps = SchemaF[int]().dumps(data)
    assert dumps == '[1, 2, 3]', 'Multiple objects not serialized properly'
    dumps = SchemaF[int]().dumps(0)
    assert dumps == '0', 'Single object not serialized properly'


# Generated at 2022-06-21 11:29:39.001371
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema
    assert isinstance(SchemaF(Schema), SchemaF)



# Generated at 2022-06-21 11:29:43.351320
# Unit test for constructor of class _IsoField
def test__IsoField():
    required = _IsoField(required=True)
    not_required = _IsoField(required=False)
    assert required._deserialize("2020-01-01T00:00:00") == datetime(2020,1,1)
    assert not_required._deserialize("2020-01-01T00:00:00") == datetime(2020,1,1)
    with pytest.raises(ValidationError):
        required._deserialize(None)
    with pytest.raises(ValidationError):
        required._deserialize("20200101") # wrong format
    with pytest.raises(ValidationError):
        not_required._deserialize(None)




# Generated at 2022-06-21 11:29:55.251704
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses_json import M, dataclass_json

    @dataclass_json
    @dataclass
    class Foo(object):
        c: int

    @dataclass_json
    @dataclass
    class Bar(object):
        d: int

    s = M(Foo)
    assert isinstance(s.load([{'c': 2}]), list)
    assert isinstance(s.load({'c': 2}), Foo)
    assert isinstance(s.load(), list)
    assert isinstance(s.load(unknown='EXCLUDE'), list)
    assert isinstance(s.load(unknown='RAISE'), list)
    assert isinstance(s.load(many=True), list)
    assert isinstance(s.load(many=False), Foo)


# Generated at 2022-06-21 11:30:07.143045
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, *args, **kwargs):
            pass

        def loads(self, json_data: JsonData,
                  many: bool = None, partial: bool = None, unknown: str = None,
                  **kwargs) -> TOneOrMulti:
            pass

    class_ = Foo # type: typing.Type[typing.Generic[A]]
    method = class_.loads # type: typing.Callable[[typing.Generic[A], JsonData, bool, bool, str], TOneOrMulti]
    if False:
        method("")
        method("", True)
        method("", False)
        method("", False, False)
        method("", False, False, "")
        method("", False, True, "")

# Generated at 2022-06-21 11:30:17.479406
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(SchemaF[int]):
        pass

    assert A().dumps(1) == '1'
    assert A().dumps(1, many=True) == '[1]'
    assert A().dumps([1]) == '[1]'
    assert A().dumps([1], many=True) == '[1]'
    # Unit test for method loads of class SchemaF
    def test_SchemaF_loads():
        class A(SchemaF[int]):
            pass

        assert A().loads('1') == 1
        assert A().loads('1', many=True) == [1]
        assert A().loads('[1]') == 1
        assert A().loads('[1]', many=True) == [1]


G = typing.TypeVar('G', bound=Enum)



# Generated at 2022-06-21 11:30:26.333098
# Unit test for constructor of class _UnionField
def test__UnionField():
    @dataclass(repr=False, eq=False)
    class InnerData:
        inner_field: str = field(default_factory=lambda: "test")

    @dataclass(repr=False, eq=False)
    class OuterData:
        inner: typing.Union[InnerData, str]

    class CustomSchema(Schema):
        inner_field = fields.String()

    class OuterSchema(Schema):
        inner = fields.Nested(CustomSchema)

    schema = OuterSchema()
    instance = schema.load({"inner": {"inner_field": "str"}})
    assert isinstance(instance['inner'], InnerData)



# Generated at 2022-06-21 11:30:29.236284
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(),'attr', 'obj') is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(),'attr', 'obj') is not None



# Generated at 2022-06-21 11:30:33.029505
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class _T(typing.Generic[A]):
        def dump(self, obj: A) -> A:
            pass

    x = _T()
    assert x.dump("abc") == "abc"



# Generated at 2022-06-21 11:30:40.855917
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert bool(
        SchemaF.load.__annotations__['return'] is typing.List[A]) is True
    assert bool(
        SchemaF.load.__annotations__['return'] is A) is True
    assert bool(
        SchemaF.load.__annotations__['data'] is typing.List[TEncoded]) is True
    assert bool(
        SchemaF.load.__annotations__['data'] is TEncoded) is True
    assert bool(
        SchemaF.load.__annotations__['return'] is TOneOrMulti) is True
    assert bool(
        SchemaF.load.__annotations__['data'] is TOneOrMultiEncoded) is True


# Generated at 2022-06-21 11:30:44.361430
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF[int]
    x = s.loads('[1, 2, 3]', many=True)
    assert x == [1, 2, 3]


# Generated at 2022-06-21 11:32:47.108466
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow_dataclass import class_schema
    from typing import List, Dict
    import dataclasses
    discriminator = "__type"
    @dataclasses.dataclass
    class Car:
        make: str
        model: str
        color: str
    @dataclasses.dataclass
    class Truck:
        payload: int
        color: str
    @dataclasses.dataclass
    class Container:
        __type: str
        payload: Dict
    @dataclasses.dataclass
    class Vehicle:
        vehicle: typing.Union[Car, Truck]
    @dataclasses.dataclass
    class ContainerVehicles:
        vehicles: List[Vehicle]
    # Car
    car = Car("Fiat", "Panda", "Red")
    data = class_sche

# Generated at 2022-06-21 11:32:56.256334
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        pass

    f1 = Foo(1)
    f2 = Foo(2)
    s = FooSchema()
    s.dump(f1)
    s.dump([f1, f2])
    # note that mypy has errors here because it cannot infer the type
    # of the object returned by s.load() -- see the comment above the
    # class SchemaF
    s.load([{'a': 1}])
    s.load({'a': 1})
    s.dumps([f1, f2])
    s.dumps({'a': 1})
    s.loads(b'{"a": 1}')
    s.loads(b'[{"a": 1}]')



# Generated at 2022-06-21 11:32:59.153751
# Unit test for function build_schema
def test_build_schema():
    # just for test
    class Mixin:
        pass

    @dataclass
    class User(Mixin):
        name: str
        age: int

    assert sorted(build_schema(User, Mixin, False, False).Meta.fields) == ['age', 'name']



# Generated at 2022-06-21 11:33:00.067827
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(None, None, None)



# Generated at 2022-06-21 11:33:10.065099
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import fields, Schema
    import typing

    class S(SchemaF[typing.Dict[str, int]]):
        a = fields.Str(required=True)
        b = fields.Int()
        c = fields.Int()

    x = {'a': '1', 'b': '2', 'c': '3'}
    obj = S().load(x)
    assert isinstance(obj, dict)
    assert set(obj.keys()) == {'a', 'b', 'c'}
    assert isinstance(obj['b'], int)
    assert isinstance(obj['c'], int)

    obj2 = S().load([x])
    assert isinstance(obj2, list)
    assert isinstance(obj2[0], dict)

# Generated at 2022-06-21 11:33:11.408908
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF.load(SchemaF, []) == []



# Generated at 2022-06-21 11:33:20.838916
# Unit test for constructor of class _UnionField
def test__UnionField():
    tmp_field = _UnionField(
        {int: fields.Integer(), str: fields.String()},
        None,
        None)
    res = tmp_field._serialize(3, None, None)
    assert res == 3
    res = tmp_field._serialize('hello', None, None)
    assert res == 'hello'
    res = tmp_field._serialize(None, None, None)
    assert res is None
    tmp_field.allow_none = False
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        res = tmp_field._serialize(3.5, None, None)
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)

# Generated at 2022-06-21 11:33:25.498703
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class _Test:
        a: int

    assert SchemaF[_Test].dump(
        [_Test(1), _Test(2)], many=True) == [{'a': 1}, {'a': 2}]


# Generated at 2022-06-21 11:33:36.211427
# Unit test for constructor of class _UnionField
def test__UnionField():
    # for dataclass
    class One:
        pass
    class Two:
        pass
    @dataclass
    class A:
        x: Union[One, Two]
    # for unmarshallable object
    class Three:
        pass
    @dataclass
    class B:
        x: Union[One, Three]
    # for newtype union
    class NT1:
        pass
    class NT2:
        pass
    @dataclass
    class C:
        x: Union[NewType('a', NT1), NewType('b', NT2)]
    # for NewType union and unmarshallable object
    class NT3:
        pass
    @dataclass
    class D:
        x: Union[NewType('a', NT1), NT3]


# Generated at 2022-06-21 11:33:43.867535
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # class A(SchemaF):
    #     pass
    # assert A().dumps([]) == "[]"
    pass

