

# Generated at 2022-06-21 11:24:15.741242
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow
    from dataclasses import dataclass

    @dataclass
    class Something(object):
        foo: int
        bar: str

    class Something2(object):
        def __init__(self, bar: str):
            self.bar = bar

    @dataclass
    class Input(object):
        v: typing.List[Something]

    @dataclass
    class Output(object):
        v: typing.List[Something2]

    s = SchemaF.infer({
        'v': fields.Nested(marshmallow.Schema(only=('bar', )))
    }, allow_unknown=True, base_schema=marshmallow.Schema)

    o = Output()
    o.v = [Something2(bar='a'), Something2(bar='b')]
    assert s

# Generated at 2022-06-21 11:24:21.765996
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Should be able to successfully load a dataclass instance
    assert SchemaF[User].load([{'id': 1, 'name': 'David'}]) == [
        User(id=1, name='David')]


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass


# Generated at 2022-06-21 11:24:25.371423
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """
    Test if constructing new object of class SchemaF raises exception.
    """

    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-21 11:24:33.413113
# Unit test for constructor of class _UnionField
def test__UnionField():
    from .typing_support import typing_options

    d = {'a': 1, 'b': 2}
    @typing_options(typed=True)
    class Object:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    Object = _decode_dataclass(Object)
    sc = Object.Schema()
    # pylint: disable=no-value-for-parameter
    f = _UnionField({Object: sc}, Object, dc_fields(Object)[0])
    assert f._serialize(Object(1, 2)) == d
    assert f._deserialize(d) == Object(1, 2)

# class _CollectionField(fields.Field):
#     def __init__(self, item_field, *args, **kwargs

# Generated at 2022-06-21 11:24:42.253915
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema
    from marshmallow.exceptions import ValidationError
    import marshmallow.fields
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Person(DataClassJsonMixin):
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = marshmallow.fields.String()
        age = marshmallow.fields.Integer()

    PersonSchema().dump(Person('John', 42))

    PersonSchema().loads('{"name": "John", "age": 42}')


# in case the user already defined `SchemaF`
if "SchemaF" not in globals():
    SchemaF = Schema



# Generated at 2022-06-21 11:24:50.435667
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import pytest
    from unittest.mock import MagicMock, Mock
    from datetime import datetime

    val = datetime.utcnow()
    serialized = val.timestamp()

    f = _TimestampField()
    f._serialize(val, 'attr', 'obj') == serialized
    f._deserialize(serialized, 'attr', 'obj') == val

    # Test serialize empty value with required True
    with pytest.raises(ValidationError):
        f._serialize(None, 'attr', 'obj', required=True)

    # Test serialize empty value with required False
    serialized = f._serialize(None, 'attr', 'obj', required=False)
    assert serialized == None

    # Test deserialize empty value with required True

# Generated at 2022-06-21 11:25:00.236659
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Case 1:
    # Postive case for serializing timestamp to datetime object
    # Input:
    # value = datetime.now()
    # Expected output:
    # value.timestamp()
    test_field = _TimestampField()
    value = datetime.now()
    exp_output = value.timestamp()
    act_output = test_field._serialize(value, 'attr', 'obj')

    assert exp_output == act_output
    # Case 2:
    # Positive case for serializing timestamp to datetime object
    # Input:
    # value = None
    # Expected output:
    # None
    test_field = _TimestampField()
    value = None
    exp_output = None
    act_output = test_field._serialize(value, 'attr', 'obj')

# Generated at 2022-06-21 11:25:04.333811
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields
    from typing import List

    class MySchema(SchemaF[List[int]]):
        foo = fields.Int()

    assert MySchema().dumps([{'foo': 1},{'foo': 2}]) == '[{"foo": 1}, {"foo": 2}]'



# Generated at 2022-06-21 11:25:14.488573
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    from marshmallow.exceptions import ValidationError
    data = {'a': 1}
    schema = SchemaF(strict=True)

    def load(self, data, many=None, partial=None, unknown=None):
        return data

    @schema.validator(many=True)  # type: ignore
    @schema.validates(many=True)  # type: ignore
    def validate(self, data, many=None, partial=None, unknown=None):
        return data

    x = schema.load([data])
    assert x == [data]

    y = schema.load(data)
    assert y == data

    schema.strict = False
    y = schema.load(data)
    assert y == data

    schema.strict = True

# Generated at 2022-06-21 11:25:21.907539
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class B:
        pass

    foo_desc = { A: 'A schema', B: 'B schema' }
    foo_field = 'foo'
    foo_cls = 'AClass'
    field = _UnionField(foo_desc, foo_cls, foo_field)

    assert field.desc == foo_desc
    assert field.cls == foo_cls
    assert field.field == foo_field
    assert field.required == False



# Generated at 2022-06-21 11:25:48.103052
# Unit test for function build_schema
def test_build_schema():
    class Config:
        dict_type = dict
        encoding = 'utf-8'
        encode_email = False
        encode_dataclass = False
        mm_field = None
        letter_case = False
        exclude = ()
        unknown = 'EXCLUDE'
        config = None
        allow_pickle = False
        dataclass_json = global_config.dataclass_json_config

    @dataclass
    class _Container:
        name: str = dataclass_field(metadata={'dataclasses_json': Config()})
        value: int
        value2: int

    @dataclass
    class _Example:
        value: int
        value2: int
        value3: int
        value4: int = dataclass_field(metadata={'dataclasses_json': Config()})


# Generated at 2022-06-21 11:25:56.820447
# Unit test for function schema
def test_schema():
    from marshmallow.fields import Field, Nested
    from marshmallow.schema import BaseSchema
    from marshmallow.marshalling import Unmarshaller
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass, field
    from typing import List, Dict, Optional, Union

    def test_case(target, mixin, infer_missing):
        @dataclass
        class TestMixin:
            coord: Optional[List[float]]
            x: Optional[float] = field(metadata=dict(mm_field=fields.Float))
            x2: Optional[float] = field(
                metadata=dict(mm_field=fields.Float(), letter_case=str.upper))

# Generated at 2022-06-21 11:26:10.021356
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Optional
    from marshmallow_dataclass import class_schema
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow import Schema as SM
    import warnings

    @dataclass
    class Color:
        name: str
        code: str

    @dataclass
    class ColorSchema(SM):
        name = fields.Str()
        code = fields.Str()

    @dataclass
    class Visitor:
        name: str
        fav_color: Color

    @dataclass
    class VisitorSchema(SM):
        name = fields.Str()
        fav_color = fields.Nested(ColorSchema)

    @dataclass
    class Data:
        name: str

# Generated at 2022-06-21 11:26:11.271809
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        pass

    foo: Foo[int] = Foo()



# Generated at 2022-06-21 11:26:16.831967
# Unit test for function build_schema
def test_build_schema():
    import marshmallow
    from dataclasses import dataclass, field
    from typing import Optional
    @dataclass
    class Test:
        @dataclass
        class A:
            v: str
        a: Test.A
        x: str
        b: Optional[str] = field(default=None)
    Test.schema()



# Generated at 2022-06-21 11:26:20.736064
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
    except NotImplementedError:
        pass
    except Exception as e:
        raise RuntimeError(e)

# Unit tests for the overloads of SchemaF

# Generated at 2022-06-21 11:26:28.982127
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class ClassA(typing.NamedTuple):
        __slots__ = ()

    class ClassB(typing.NamedTuple):
        __slots__ = ()

    class ClassC(typing.NamedTuple):
        __slots__ = ()

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class MyClass:
        a: str
        b: ClassA

    my_instance_1 = MyClass(a='foo', b=ClassA())
    my_instance_2 = MyClass(a='bar', b=ClassB())
    my_instance_3 = MyClass(a='baz', b=ClassC())
    ret = SchemaF[MyClass].dumps([my_instance_1, my_instance_2, my_instance_3])

# Generated at 2022-06-21 11:26:36.794513
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class InnerSchema(Schema):
        type_ = fields.Str()

    class OuterSchema(SchemaF[List[InnerSchema]]):
        inner = fields.Nested(InnerSchema, many=True)

    dump_data = OuterSchema().dump([{"type_": "A"}, {"type_": "B"}])
    assert dump_data == [{'inner': [{'type_': 'A'}, {'type_': 'B'}]}]



# Generated at 2022-06-21 11:26:48.529750
# Unit test for function build_schema
def test_build_schema():
    import uuid

    @dataclass
    class Color:
        name: str
        hexcode: str

    @dataclass
    class Red:
        color: Color

    @dataclass_json
    @dataclass
    class User:
        name: str
        age: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int())))
        uuid: uuid.UUID = field(metadata=dict(dataclasses_json=dict(mm_field=fields.UUID())))
        red: Red = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Nested(Red.schema()))))

# Generated at 2022-06-21 11:26:51.324842
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj_1 = _IsoField()
    assert(obj_1.default_error_messages == fields.Field.default_error_messages)



# Generated at 2022-06-21 11:27:17.264526
# Unit test for constructor of class SchemaF
def test_SchemaF():
    test_schema = SchemaF[datetime]()
    assert test_schema.loads('{}') == datetime.min
    assert test_schema.dump(datetime.now()).get('created_at') is not None



# Generated at 2022-06-21 11:27:24.280782
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    obj = SchemaF[int].load(1)
    assert obj == 1
    obj = SchemaF[int].load([1])
    assert obj == [1]
    try:
        obj = SchemaF[int].load(1, many=True)
    except AssertionError as e:
        assert str(e) == 'The parameter many cannot be True in load method of class SchemaF'
    try:
        obj = SchemaF[int].load([1], many=False)
    except AssertionError as e:
        assert str(e) == 'The parameter many cannot be False in load method of class SchemaF'

# Generated at 2022-06-21 11:27:36.509234
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    import typing
    from typing import Optional, Union, List

    from marshmallow import Schema, fields
    from marshmallow.validate import Range

    from deliverable_model.dataclass_json import DataClassJsonMixin

    # Define OriginalDataClass
    @dataclass
    class OriginalDataClass(DataClassJsonMixin):
        project: str
        rating: Optional[Union[str, int]] = field(default=None, metadata={'marshmallow_field': fields.Integer(validate=Range(min=0, max=5))})
        url: str = field(metadata={'marshmallow_field': fields.URL()})
        extra: Optional[Union[OriginalDataClass, List[OriginalDataClass]]] = field(default=None)
    # -----------------------------------------------------------



# Generated at 2022-06-21 11:27:44.741253
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class SubSchema(Schema):
        s = fields.Str()

    class SubSchemaF(SchemaF[SubSchema]):
        pass

    class SubSchema2(Schema):
        s = fields.Str()

    class SubSchemaF2(SchemaF[SubSchema2]):
        pass

    class FooSchema(Schema):
        s = fields.Nested(SubSchemaF)
        l = fields.Nested(SubSchemaF2, many=True)

    s = FooSchema()
    v = [{'s': {'s': 'a'}}, {'s': {'s': 'b'}}]
    encoded = s.dump(v, many=True)

# Generated at 2022-06-21 11:27:56.272754
# Unit test for function build_type
def test_build_type():
    from typing import Dict, List, Tuple
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields

    @dataclass
    class Mixin:
        pass

    @dataclass_json(mm_field=mm_fields.Int)
    @dataclass
    class DC1(Mixin):
        i: int

    @dataclass
    class DC2:
        i: int

    assert build_type(int, {}, Mixin, DC1.i, DC1) == mm_fields.Int
    assert build_type(List[int], {}, Mixin, DC1.i, DC1) == mm_fields.List
    assert build_type(List[List[int]], {}, Mixin, DC1.i, DC1) == mm_fields.List
    assert build_

# Generated at 2022-06-21 11:28:05.318162
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class User:
        name: str

    user = User("Marcin")
    # type: TOneOrMulti
    data, _ = SchemaF[TOneOrMulti]().dump(user)
    # type: TOneOrMulti
    assert data == {"name": "Marcin"}

    users = [User("Marcin")]
    # type: TOneOrMulti
    data, _ = SchemaF[TOneOrMulti]().dump(users, many=True)
    # type: TOneOrMulti
    assert data == [{"name": "Marcin"}]



# Generated at 2022-06-21 11:28:11.609095
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 9, 22, 21, 51, 41, 871779), '', '')=='2020-09-22T21:51:41.871779'
    assert field._deserialize('2020-09-22T21:51:41.871779', '', '')==datetime(2020, 9, 22, 21, 51, 41, 871779)



# Generated at 2022-06-21 11:28:17.656389
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[str]):
        pass

    assert MySchema().loads("") is not None
    assert MySchema().loads("", many=True) == []


# see https://github.com/marshmallow-code/marshmallow/issues/1552

# Generated at 2022-06-21 11:28:27.721137
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    import marshmallow.fields as mm_fields
    from typing import List
    from datetime import datetime, timedelta, timezone
    from dataclasses import dataclass
    from uuid import UUID

    from dataclasses_json.api import dataclass_json

    @dataclass_json
    @dataclass
    class Dummy:
        id: int
        now: datetime
        ts: float
        utc: timezone
        uuid: UUID
        nested: 'Dummy'
        list_str: List[str]
        list_dict: List[dict]
        list_int: List[int]
        list_ts: List[timedelta]
        list_dt: List[datetime]
        list_dc: List['Dummy']

# Generated at 2022-06-21 11:28:30.696638
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    class SomeMixin:
        pass

    @dataclass
    class A(SomeMixin):
        d: Decimal = Decimal(0)

    @dataclass
    class B(SomeMixin):
        a: A = None

    assert schema(A, SomeMixin, False)['d'].__class__ is fields.Decimal
    assert schema(B, SomeMixin, False)['a'].__class__ is fields.Nested



# Generated at 2022-06-21 11:29:19.959762
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def fn1(d1: typing.List[int]) -> typing.List[int]:
        return [1, 2, 4]

    def fn2(d1: int) -> int:
        return 1

    fn1(SchemaF[int]().dump([1, 2, 3]))
    fn2(SchemaF[int]().dump(1))


# Generated at 2022-06-21 11:29:25.048246
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import Union

    class A:
        pass

    class B:
        pass

    @dataclass_json
    @dataclass
    class C(SchemaF[Union[A, B]]):
        a: str

    c = C('a')
    assert c.dumps() == '{"a": "a"}'



# Generated at 2022-06-21 11:29:29.738859
# Unit test for constructor of class _IsoField
def test__IsoField():
    new_iso_field = _IsoField()
    value = "2019-12-31T23:59:59.999999"
    attr = "test"
    data = None
    deserialized = new_iso_field._deserialize(value, attr, data)
    assert deserialized == datetime.fromisoformat(value)


# Generated at 2022-06-21 11:29:37.501109
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    @dataclasses.dataclass
    class User:
        name: str
        surname: str

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        surname = fields.Str()

        @post_load
        def make_object(self, data, **kwargs):
            return User(**data)

    data = [{'name': 'foo', 'surname': 'bar'}]

    result = UserSchema().load(data, many=True)
    assert result[0].name == 'foo'
    assert result[0].surname == 'bar'

    result = UserSchema().load(data[0])
    assert result.name == 'foo'
    assert result.surname == 'bar'


# Generated at 2022-06-21 11:29:39.453555
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()  # pylint: disable=abstract-class-instantiated



# Generated at 2022-06-21 11:29:41.086268
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(
        {datetime: fields.DateTime(format="iso")},
        'cls', 'field', required=True)



# Generated at 2022-06-21 11:29:47.046718
# Unit test for constructor of class _IsoField
def test__IsoField():
    print('\n' + '#'*40)
    print('Testing _IsoField')
    print('#'*40)
    d = datetime(2010, 5, 29, 23, 8, 5, 479000)
    iso = d.isoformat()
    print(iso)
    field = _IsoField(missing=None, default=None, validate=None, required=False, load_only=False, dump_only=False)
    print('#'*40)
    print('calling _serialize(d) ->', field._serialize(d, None, None, None, None))
    print('calling _deserialize(iso) ->', field._deserialize(iso, None, None, None, None))
    print('#'*40)
    print()



# Generated at 2022-06-21 11:29:50.522202
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF[int].load([{"int": 1}, {"int": 2}]) == [1, 2]
    assert SchemaF[int].load({"int": 1}) == 1



# Generated at 2022-06-21 11:29:55.011572
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int = 0
        hobby: typing.Optional[str] = None
        dad: typing.Optional['Person'] = None

    schema = build_schema(Person, None, False, False)

# Generated at 2022-06-21 11:29:59.422907
# Unit test for constructor of class _UnionField
def test__UnionField():
    desc = {int: fields.Integer(), str: fields.String()}
    cls = _UnionField(desc, None, None)
    assert cls.desc == desc
    assert cls.cls is None
    assert cls.field is None



# Generated at 2022-06-21 11:31:49.344480
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    data = [{"a": 3}]
    s = SchemaF.dump(data, many=True)



# Generated at 2022-06-21 11:31:54.551749
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()  # type: ignore


EXTENSIONS = {
    datetime: _IsoField,
}

_TYPE_ORIGIN_TYPES = (list, tuple, typing.List, typing.Tuple,
                      typing.MutableSequence, typing.Sequence)



# Generated at 2022-06-21 11:32:03.780894
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass, field
    @dataclass
    class User:
        name: str
        age: int
    SchemaF[User].dump([User(name='foo', age=42), User(name='bar', age=43)])
    SchemaF[User].dump(User(name='foo', age=42))
    SchemaF[User].dump(User(name='foo', age=42), many=False)
    SchemaF[User].dump(User(name='foo', age=42), many=True)
    SchemaF[User].dump([User(name='foo', age=42), User(name='bar', age=43)], many=True)
    # check that mypy does not raise a warning for the following methods
    SchemaF[User].dump(None)
    SchemaF

# Generated at 2022-06-21 11:32:11.610545
# Unit test for function schema
def test_schema():
    from dataclasses_json.core import _user_overrides_or_exts
    assert isinstance(schema(None, None, False).get("foo", None), fields.Field)
    assert isinstance(schema(None, None, False).get("bar", None), fields.Field)
    assert isinstance(schema(None, None, False).get("baz", None), fields.Field)
    assert isinstance(schema(None, None, False).get("fizz", None), fields.Field)
    assert isinstance(schema(None, None, False).get("fuzz", None), fields.Field)
    assert isinstance(schema(None, None, False).get("fuzz", None), fields.Field)

# Generated at 2022-06-21 11:32:23.237838
# Unit test for function schema
def test_schema():
    from typing import Union
    from enum import Enum
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from datetime import datetime
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class EnumFieldTest(object):
        enum_field: EnumField

# Generated at 2022-06-21 11:32:31.350567
# Unit test for function schema
def test_schema():
    class CMixin:
        @classmethod
        def json_encoder_class(cls, typ, registry={}):
            if __debug__:
                return registry.setdefault(typ, _ExtendedEncoder)
            else:
                return registry.setdefault(typ, _ExtendedEncoder)
    @dataclass_json(encoder_class=CMixin.json_encoder_class)
    class C:
        s: str
        d: datetime
        u: UUID
        l: typing.List[int]
        di: typing.Dict[str, typing.Optional[str]]
        ui: typing.Union[str, int]
        opt: typing.Optional[str]

# Generated at 2022-06-21 11:32:33.677425
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(None, "attr", "obj") is None



# Generated at 2022-06-21 11:32:40.688250
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class DataClass:
        a: int

    schema = build_schema(DataClass, None, False, False)
    assert issubclass(schema, Schema)
    assert schema.Meta.fields == ('a',)
    assert isinstance(schema.a, fields.Int)

"""
File schema.py
"""

# TODO #180
# def dumps(obj, *, cls=_ExtendedEncoder, **kwargs):
#     return JSONEncoder(**kwargs).encode(obj)



# Generated at 2022-06-21 11:32:42.681731
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()
    assert isinstance(obj, fields.Field)


# Generated at 2022-06-21 11:32:45.756371
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """Should not raise error"""
    with pytest.raises(NotImplementedError):
        SchemaF()

