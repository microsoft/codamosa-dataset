

# Generated at 2022-06-21 11:24:19.591194
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from uuid import uuid4
    from datetime import datetime

    class TestSchema(Schema):
        str_ = fields.Str(required=True)
        non_required_str = fields.Str(required=False)
        non_required_and_none = fields.Str(required=False, allow_none=True)
        str_not_required_with_default = fields.Str(default='test_str', missing='test_str')
        str_not_required_with_default_factory = fields.Str(default_factory=str)
        str_not_required_with_default_factory_lambda = fields.Str(
            default_factory=lambda: 'anonymous_str')

# Generated at 2022-06-21 11:24:29.500333
# Unit test for function build_type
def test_build_type():
    assert not _is_collection(int)
    assert not _issubclass_safe(str, Enum)
    assert _is_optional(typing.Optional[str])
    assert not _is_optional(str)
    assert issubclass(int, typing.Callable)
    assert _get_type_origin(typing.Tuple[int, str]) == tuple
    assert typing.Tuple[int, str].__args__ == (int, str)
    assert not is_union_type(typing.Optional[int])
    assert is_union_type(typing.Union[int, str])
    assert not getattr(int, '__origin__', None)
    assert getattr(typing.Union[int], '__origin__', None) == typing.Union

# Generated at 2022-06-21 11:24:39.534806
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()
        email = fields.Email()

    schema = UserSchema()
    user_data = {'name': 'José', 'email': 'jose@example.com', 'age': 42}
    json_data = '{}'

    # TYPE CHECKING
    user = schema.load(user_data)  # type: A
    # E: User

    users = schema.load([user_data])  # type: typing.List[A]
    # E: typing.List[User]
    users = schema.load([user_data, user_data])  # type: typing.List[A]
    # E: typing.List[User]

    # TYPE CHECKING

# Generated at 2022-06-21 11:24:43.843925
# Unit test for constructor of class _IsoField
def test__IsoField():
    dt = datetime.now()
    iso_field = _IsoField()

    # serialize
    assert iso_field._serialize(dt, None, None) == dt.isoformat()

    # deserialize
    assert iso_field._deserialize(dt.isoformat(), None, None) == dt



# Generated at 2022-06-21 11:24:54.681366
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    @dataclasses.dataclass
    class AC(object):
        a: int

    class SchemaAC(SchemaF[AC]):
        pass

    assert SchemaAC().load([{'a': 1}]) == [AC(1)]
    assert SchemaAC().load({'a': 1}) == AC(1)

    @dataclasses.dataclass
    class AD(object):
        a: int
        b: typing.List[AC]

    class SchemaAD(SchemaF[AD]):
        a = fields.Int()
        b = fields.Nested('SchemaAC', many=True)

    assert SchemaAD().load({'a': 1, 'b': [{'a': 2}]}) == AD(1, [AC(2)])


# Generated at 2022-06-21 11:25:03.943164
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Class:
        int_class: int
        str_class: str = field(default='str_class')
        field: typing.Callable = field(default=lambda: '')
        let_case: typing.Dict[str, str] = field(metadata={'dataclasses_json': {'letter_case': lambda x: x.upper()}})

    schema_ = schema(Class, dict, False)
    assert isinstance(schema_['int_class'], fields.Integer)
    assert isinstance(schema_['str_class'], fields.String)

# Generated at 2022-06-21 11:25:07.312328
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-21 11:25:12.655270
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class MySchema(SchemaF[str]):
        foo = fields.Str()

    s = MySchema()
    assert s.dump(List[str](['foo', 'bar'])) == [{'foo': 'foo'}, {'foo': 'bar'}]



# Generated at 2022-06-21 11:25:22.983887
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json(encoder=ExtendedEncoder)
    @dataclass
    class TestData:
        x: int
        y: str

    s = TestDataSchema.loads(b'{"x": 3, "y": "hello"}')
    assert isinstance(s, TestData)
    assert s.x == 3
    assert s.y == "hello"

# Generated at 2022-06-21 11:25:31.596087
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class MySchema(SchemaF[A]):
        @post_load
        def make_thing(self, data, **kwargs):
            return A(**data)
    res: typing.List[int] = SchemaF[int].dump([1, 2, 3], many=True)
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == 3

    data = typing.List[TEncoded] = SchemaF[int].dump(1)
    assert data == 1

    data = MySchema().dump([A(id=1), A(id=2), A(id=3)], many=True)
    assert data[0] == {'id': 1}
    assert data[1] == {'id': 2}

# Generated at 2022-06-21 11:25:53.210069
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():  # type: ignore
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Test:
        x: int
        y: str

    class TestSchema(Schema):
        class Meta:
            unknown = EXCLUDE

        x = fields.Integer(required=True)
        y = fields.String(required=True)


# Generated at 2022-06-21 11:25:57.003067
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tf = _TimestampField()
    assert tf._serialize(datetime(2019, 5, 1, 3, 9, 23), None, None) == 1556711063.0
    assert tf._deserialize(1556711063.0, None, None) == datetime(2019, 5, 1, 3, 9, 23)



# Generated at 2022-06-21 11:25:59.689777
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert issubclass(SchemaF, Schema)
    assert issubclass(SchemaF, typing.Generic)



# Generated at 2022-06-21 11:26:12.306925
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Union
    @dataclass_json
    @dataclass
    class TestArr:
        value: int
    @dataclass_json
    @dataclass
    class TestStr:
        value: str
    @dataclass_json
    @dataclass
    class TestDict:
        value: dict
    @dataclass
    class Test:
        foo: Union[TestArr, TestStr, TestDict]
    schema = TestSchema()
    assert hasattr(schema._declared_fields['foo'], 'desc')
    assert isinstance(schema._declared_fields['foo'].desc, dict)

# Generated at 2022-06-21 11:26:23.360701
# Unit test for function build_type
def test_build_type():
    from dataclasses import field
    from datetime import date
    from typing import List, Union
    from dataclasses_json.schema import Schema

    @dataclass
    class Pet:
        name: str

    @dataclass_json
    @dataclass
    class Person:
        age: int
        birth_date: date = field(metadata=dataclass_json(
            mm_field=fields.Date(format='%d-%m-%Y')))
        name: str

    @dataclass_json
    @dataclass
    class User:
        name: str
        address: str
        pets: List[Pet] = field(default_factory=list)

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)

   

# Generated at 2022-06-21 11:26:28.226405
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class UserSchema(SchemaF):
        username = fields.Str()
        age = fields.Int()
    user = UserSchema().load({'username': 'joe', 'age': 15}, partial=True)
    assert UserSchema().dumps(user) == '{"username":"joe","age":15}'


# Generated at 2022-06-21 11:26:39.608992
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow as mm
    import marshmallow.fields as mmf
    class ClassTest:
        def __init__(self, x):
            self.x = x
    class_test_type = ClassTest(int)

    record_type = typing.Record(x=int, y=str)
    record_type_instance = record_type(x=1, y='string')

    class ClassTest2:
        def __init__(self, x):
            self.x = x
    class ClassTest2Field(mmf.Field):
        def _deserialize(self, value, attr, data, **kwargs):
            return value + 1
    class ClassTest2MetaSchema(mm.Schema):
        x = ClassTest2Field()
    class_test_type2 = ClassTest2(2)
    class_

# Generated at 2022-06-21 11:26:44.699264
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class ExampleSchema(SchemaF[ExampleClass]):
        msg = fields.Str()
    s = ExampleSchema()
    obj = ExampleClass('Test')
    data = s.dump(obj)
    loaded_obj: ExampleClass = s.load(data)
    assert loaded_obj.msg == obj.msg

# Generated at 2022-06-21 11:26:46.146612
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()



# Generated at 2022-06-21 11:26:49.759896
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    assert field.deserialize(1550034322.5) == datetime(2019, 2, 18, 21, 35, 22, 500000)



# Generated at 2022-06-21 11:27:09.258547
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass(frozen=True)
    class A:
        b: int
        c: int = 1
        d: dict = field(metadata={"dataclasses_json": {"mm_field": fields.Dict()}})
    a = A(b=1, c=3)
    DataClassSchema = build_schema(A, dataclass_json, infer_missing=False, partial=False)
    assert DataClassSchema().dump(a) == {'b': 1, 'd': {}, 'c': 3}



# Generated at 2022-06-21 11:27:19.670845
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestClass:
        name: str
        age: int
        
    TestSchema = build_schema(TestClass, None, None, None)
    assert TestSchema.__name__ == 'TestClassSchema'
    test_instance = TestSchema()
    assert isinstance(test_instance.Meta, type)
    assert TestClassSchema.Meta.fields == ('name', 'age')
    assert TestClassSchema.__dict__['make_testclass'].__name__ == 'make_instance'
    assert TestClassSchema.__dict__['dumps'].__name__ == 'dumps'
    assert TestClassSchema.__dict__['dump'].__name__ == 'dump'
    assert _issubclass_safe(TestClassSchema, Schema)
    
test_build

# Generated at 2022-06-21 11:27:32.035007
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    obj_a: TEncoded = {'a': 1}
    obj_b: TEncoded = {'b': 2}

    class SchemaA(SchemaF[A]):
        pass

    schema = SchemaA()
    assert type(schema.loads(obj_a)) == dict
    assert type(schema.loads(obj_b)) == dict

    class SchemaB(SchemaF[A]):
        pass

    schema = SchemaB()
    assert type(schema.loads(obj_a)) == dict
    assert type(schema.loads(obj_b)) == dict

    class SchemaC(SchemaF[A]):
        pass

    schema = SchemaC()
    assert type(schema.loads(obj_a)) == dict

# Generated at 2022-06-21 11:27:41.893297
# Unit test for function build_schema
def test_build_schema():
    if sys.version_info >= (3, 7):
        from dataclasses_json.tests.test_primitive_types import test as test_primitive_types
        from dataclasses_json.tests.test_dict import test as test_dict
        from dataclasses_json.tests.test_marshmallow_type import test as test_marshmallow_type
        from dataclasses_json.tests.test_ignore import test as test_ignore
        from dataclasses_json.tests.test_non_nullable import test as test_non_nullable
        from dataclasses_json.tests.test_decimal import test as test_decimal
        from dataclasses_json.tests.test_datetime import test as test_datetime
        from dataclasses_json.tests.test_list import test as test_list
       

# Generated at 2022-06-21 11:27:49.683482
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    class Dummy(SchemaF):
        def __init__(self, obj):
            self.obj = obj

        @property
        def fields(self):
            return {
                'obj': fields.Field()  # type: ignore
            }

        @post_load
        def make_obj(self, data):
            return data['obj']

    data = '{"foo": "bar"}'
    assert Dummy(data).dump() == data
    assert Dummy([data, data]).dump() == [data, data]



# Generated at 2022-06-21 11:27:52.679337
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def load_test(test_dict: typing.Dict[str, str]):
        # type: (typing.Dict[str, str]) -> TOneOrMulti
        class _Test(SchemaF):
            pass
        return _Test().load(test_dict)
    assert test_SchemaF_load()



# Generated at 2022-06-21 11:28:04.391214
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert isinstance(SchemaF.dump, typing.Callable)
    assert not hasattr(SchemaF.dump, '__module__')

    # test the first overload
    assert hasattr(SchemaF.dump, '__extra__')
    assert SchemaF.dump.__extra__ == 'overload-1'
    assert hasattr(SchemaF.dump, '__wrapped__')
    assert isinstance(SchemaF.dump.__wrapped__, typing.Callable)
    assert SchemaF.dump.__wrapped__.__module__ == 'marshmallow.schema'
    assert SchemaF.dump.__wrapped__.__name__ == 'Schema.dump'

    # test the second overload
    overload2 = SchemaF.dump.__overloads__[1]

# Generated at 2022-06-21 11:28:04.995632
# Unit test for constructor of class SchemaF
def test_SchemaF():
    pass



# Generated at 2022-06-21 11:28:07.967337
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = dict()
    data['one'] = 1
    data['two'] = 2
    rv: str = SchemaF.dumps(data)
    assert rv == '{"one": 1, "two": 2}'



# Generated at 2022-06-21 11:28:10.102763
# Unit test for function build_type
def test_build_type():
    # This function was automatically generated. Please do not edit it manually.
    raise NotImplementedError()



# Generated at 2022-06-21 11:28:41.592939
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass
    class MyClass:
        pk: int
        name: str
        optional: Optional[str]

    @dataclass
    class MyUnion:
        status: Union[str, MyClass]

    sc = dataclass_json(_ExtendedEncoder, _user_overrides_or_exts=None)(MyUnion)

    assert sc.fields['status'].field_schema.fields[
        'optional'].allow_none == True
    assert sc.fields['status'].field_schema.fields['name'].required == True


_used_schemas: dict = {}



# Generated at 2022-06-21 11:28:42.451349
# Unit test for constructor of class _IsoField
def test__IsoField():
    _TimestampField
    _IsoField


# Generated at 2022-06-21 11:28:52.234423
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow as mm
    class IntField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            return int(value)
        def _deserialize(self, value, attr, data, **kwargs):
            return int(value)

    class StrField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            return str(value)
        def _deserialize(self, value, attr, data, **kwargs):
            return str(value)

    class Schema(mm.Schema):
        enum = EnumField(IntEnum)
        int_field = IntField()
        str_field = StrField()


# Generated at 2022-06-21 11:28:59.544168
# Unit test for constructor of class _UnionField
def test__UnionField():
    class IntOrStr(Enum):
        A = 1
        B = '2'

    @dataclass
    class Nested:
        a: int

    @dataclass
    class SimpleDC:
        a: int
        b: str
        c: typing.Optional[int]

    @dataclass
    class DCWithUnion:
        a: typing.Union[int, str]
        b: typing.Union[int, str, SimpleDC, Nested]
        c: typing.Union[IntOrStr, str]

    schema = _ExtendedEncoder()._get_schema(DCWithUnion)
    s = schema()
    assert isinstance(s.declared_fields['a'], fields.Integer)

# Generated at 2022-06-21 11:29:09.762029
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TestDataClass:
        name: str
        age: int = 42
        a_dict: typing.Dict = {}
        a_list: typing.List[int] = []
        some_type: typing.Optional[typing.List[typing.Tuple[typing.Any, int]]] = None

    s = schema(TestDataClass, dataclass, True)
    assert len(s) == 5
    assert s['name'].__class__ == fields.Str
    assert s['age'].__class__ == fields.Int
    assert s['a_dict'].__class__ == fields.Dict



# Generated at 2022-06-21 11:29:17.376425
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    o = SchemaF.load(None, dict())
    o = SchemaF.load(None, dict(), many=True)
    o = SchemaF.load(None, dict(), many=False)
    o = SchemaF.load(None, dict(), partial=True)
    o = SchemaF.load(None, dict(), partial=False)
    o = SchemaF.load(None, dict(), unknown='EXCLUDE')
    o = SchemaF.load(None, dict(), unknown='INCLUDE')
    o = SchemaF.load(None, dict(), unknown='RAISE')
    o = SchemaF.loads(None, '')
    o = SchemaF.loads(None, '', many=True)
    o = SchemaF.loads(None, '', many=False)
    o

# Generated at 2022-06-21 11:29:18.749615
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int



# Generated at 2022-06-21 11:29:23.902877
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass as _dataclass
    from typing import Optional
    from dataclasses_json import config
    from dataclasses_json.delete_undefined import DeleteUndefined
    @_dataclass
    class MyClass:
        pass
    DataClassSchema = build_schema(MyClass, DeleteUndefined, config.infer_missing, config.partial)
    pass


# Generated at 2022-06-21 11:29:31.081132
# Unit test for function build_type
def test_build_type():
    from typing import Dict, Union, List
    from datetime import date
    from decimal import Decimal

    class TestClass:
        pass

    # typing.Optional[int]
    f = build_type(int, {}, TestClass, dc_fields(TestClass)[0], TestClass)
    assert _issubclass_safe(f, fields.Int)

    # typing.Union[str, int]
    f = build_type(Union[str, int], {}, TestClass, dc_fields(TestClass)[0], TestClass)
    assert _issubclass_safe(f, _UnionField)

    # typing.Dict[str,int]
    f = build_type(Dict[str, int], {}, TestClass, dc_fields(TestClass)[0], TestClass)

# Generated at 2022-06-21 11:29:32.348734
# Unit test for function schema
def test_schema():
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 11:30:13.624865
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()  # type: ignore



# Generated at 2022-06-21 11:30:21.085182
# Unit test for constructor of class _IsoField
def test__IsoField():
    # should be able to construct the class
    fields.Field
    # should be able to construct a subclass
    fields.Raw
    # should be able to construct a subclass of a subclass
    _IsoField
    from marshmallow.fields import Number
    Number(validate=lambda n: n > 0)
    # should be able to construct a subclass of a subclass with a lambda
    _IsoField(lambda n: n > 0)
    # should be able to construct a subclass of a subclass with a lambda
    _TimestampField(lambda n: n > 0)



# Generated at 2022-06-21 11:30:28.199809
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema

    class SimpleModel(Schema):
        one = fields.Int(required=True)
        two = fields.Int()

    @dataclass
    class SimpleModelType:
        one: int
        two: int

    schema = SchemaF[SimpleModelType]()
    t = schema.load({'one': 1, 'two': 2})
    assert isinstance(t, SimpleModelType)


marshmallow_version_info = getattr(fields, "__version_info__", (3, 0, 0))



# Generated at 2022-06-21 11:30:37.447471
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from dataclasses import dataclass

    class C:
        pass

    @dataclass(frozen=True)
    class D:
        i: int

    class E(Enum):
        A = 1
        B = 2

    class E2(Enum):
        A = 1
        B = 2

    class E3(E):
        C = 3

    class F:
        def __init__(self, i=1):
            self.i = i

    class G:
        def __init__(self, i):
            self.i = i

    class H:
        def __init__(self, i):
            self.i = i

    class I:
        def __init__(self, i):
            self.i = i


# Generated at 2022-06-21 11:30:45.747277
# Unit test for function build_type
def test_build_type():
    options = {}
    class TestEnum(Enum):
        test = 1
    class TestClass:
        pass


    # Case 1: Origin is in TYPES
    type_ = typing.Dict[int, int]
    schema_field = build_type(type_, options, mixin=None, field=None, cls=None)
    assert isinstance(schema_field, fields.Mapping)

    # Case 2: Origin is a subclass of Enum
    type_ = typing.Union[TestEnum, None]
    schema_field = build_type(type_, options, mixin=None, field=None, cls=None)
    assert isinstance(schema_field, EnumField)

    # Case 3: Origin is a subclass of typing.Union
    type_ = typing.Union[int, float]

# Generated at 2022-06-21 11:30:55.062165
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Tag:
        value: str

    @dataclass
    class TagWithSchema(Tag):
        class Schema(SchemaF[Tag]):
            value = fields.String()

    @dataclass
    class Book:
        title: str
        tags: List[Tag]
        class Schema(SchemaF[Book]):
            title = fields.String()
            tags = fields.List(fields.Nested(TagWithSchema.Schema))

    @dataclass
    class BookWithSchema(Book):
        class Schema(SchemaF[Book]):
            title = fields.String()

# Generated at 2022-06-21 11:30:59.378149
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    assert FooSchema().dump(Foo(a=1)) == {'a': 1}
    assert FooSchema().dump([Foo(a=1), Foo(a=2)]) == [{'a': 1}, {'a': 2}]

# Generated at 2022-06-21 11:31:05.284924
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import fields as mf

    class SchemaFSub(SchemaF):
        class Meta:
            strict = True

        my_str = mf.Str()


    dump = SchemaFSub.loads('{"my_str": "a"}', many=None)
    assert isinstance(dump, typing.Dict)


    dump = SchemaFSub.loads('[{"my_str": "a"}]', many=True)
    assert isinstance(dump, typing.List)

# Generated at 2022-06-21 11:31:06.529607
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(None) is None


# Generated at 2022-06-21 11:31:08.430511
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-21 11:32:54.185297
# Unit test for function schema
def test_schema():
    @dataclasses_json.dataclass_json
    class SchemaMixin(object):
        @classmethod
        def schema(cls):
            return schema(cls, cls, True)

    @dataclasses_json.dataclass_json
    class A(SchemaMixin):
        a: int

    class B(SchemaMixin):
        b: str

    @dataclasses_json.dataclass_json
    class C(SchemaMixin):
        c: typing.List[A]

    @dataclasses_json.dataclass_json(infer_missing=False)
    class D(SchemaMixin):
        d: typing.Optional[B]


# Generated at 2022-06-21 11:33:00.953402
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from marshmallow import Schema, post_load
    from typing import List, Optional, Union, Literal, Dict, Any

    @dataclass
    class ListDataSch:
        l: List[int]

    @dataclass
    class OptionalDataSch:
        o: Optional[int]

    @dataclass
    class OptionalUnionDataSch:
        ou: Optional[Union[int, str]]

    @dataclass
    class OptionalUnionDictDataSch:
        oud: Optional[Union[int, Dict[str, str]]]

    @dataclass
    class OptionalLiteralDataSch:
        ol: Optional[Literal[1, 2, 3]]


# Generated at 2022-06-21 11:33:04.148854
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj = 10
    assert SchemaF[int]().dumps(obj) == Schema().dumps(obj)
    obj = [10, 15]
    assert SchemaF[int]().dumps(obj) == Schema().dumps(obj)


# Generated at 2022-06-21 11:33:10.585591
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm import MM

    @MM.schema(auto_nullable=True)
    @dataclasses.dataclass
    class A:
        name: str
        age: int
        b: typing.Optional[int]

    a = A(name="ala", age=23)
    assert a.__class__.schema().dump(a) == {"name": "ala", "age": 23, "b": None}



# Generated at 2022-06-21 11:33:13.102336
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    res: List[str] = SchemaF.dump(['test'])
    assert all(isinstance(e, str) for e in res)



# Generated at 2022-06-21 11:33:18.170067
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class ExampleDataSchema(SchemaF[ExampleData]):
        class Meta:
            ordered = True

        a = fields.Str()
        b = fields.DateTime()

    result = ExampleDataSchema().dumps(ExampleData("a", datetime.utcnow()))
    print(result)  # Just calling so it is covered by the unit test
    assert result



# Generated at 2022-06-21 11:33:24.470525
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import TypeVar, List, Union

    class MyModel(object):
        ...  # type: ignore

    schema = TypeVar("schema", bound="MySchemaF")

    class MySchemaF(SchemaF[MyModel]):
        ...  # type: ignore

    json_dict = {"foo": "bar"}
    # fmt: off
    json_list: List[TEncoded] = [json_dict]
    json_data: Union[TEncoded, JsonData] = json_dict
    # fmt: on

    # call load with required *args
    MySchemaF().load(json_data)
    MySchemaF(unknown="EXCLUDE").load(json_data)

    # call load with required *args and optional **kwargs

# Generated at 2022-06-21 11:33:33.259476
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow_dataclass import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    @dataclass
    class Bar:
        x: Foo
        y: int
        z: typing.List[str]

    assert SchemaF[Bar].dumps(Bar(Foo(123, "abc"), 345, ["def", "ghi"])) == \
           (
        '{"x": {"a": 123, "b": "abc"}, "y": 345, '
        '"z": ["def", "ghi"]}'
    )



# Generated at 2022-06-21 11:33:42.227095
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test_data = _timestamp_to_dt_aware(1562182400)

    field = fields.Field(**{})
    assert isinstance(field, fields.Field)

    field2 = _TimestampField(**{})
    assert isinstance(field2, fields.Field)
    assert isinstance(field2, _TimestampField)

    assert field2._serialize(test_data, 'attr', 'obj', None) == 1562182400
    assert field2._deserialize(15621824000.0, 'attr', 'data', None) == test_data # type: ignore
    assert field2._deserialize(1562182400, 'attr', 'data', None) == test_data
    assert field2._deserialize('1562182400.0', 'attr', 'data', None)

# Generated at 2022-06-21 11:33:48.750162
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    dc_class = typing.TypeVar('dc_class')
    sample_schema = SchemaF[dc_class]  # type: ignore
    assert sample_schema.dumps([0], many=False) == '[0]'
    assert sample_schema.dumps([1,2], many=True) == '[1, 2]'
    assert sample_schema.dumps(1, many=False) == '1'