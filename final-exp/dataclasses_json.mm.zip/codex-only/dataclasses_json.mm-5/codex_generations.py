

# Generated at 2022-06-23 16:45:00.898047
# Unit test for function schema

# Generated at 2022-06-23 16:45:08.011048
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import Schema, fields, post_load

    class DataClassJsonMixin:
        @classmethod
        def schema(cls):
            raise NotImplementedError()

    @dataclass
    class Locale(DataClassJsonMixin):
        lang: str

    @dataclass
    class User(DataClassJsonMixin):
        name: str
        age: Optional[int] = None

    @dataclass
    class Department(DataClassJsonMixin):
        name: str
        locales: Optional[List[Locale]] = None

    @dataclass
    class Company(DataClassJsonMixin):
        name: str

# Generated at 2022-06-23 16:45:15.876399
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    s = _TimestampField()
    assert s._serialize(datetime.utcfromtimestamp(0), None, None) == 0
    assert s._deserialize(0, None, None) == datetime.utcfromtimestamp(0)
    try:
        assert s._serialize(None, None, None) is None
        assert False
    except ValidationError as e:
        assert e.messages == ['Missing data for required field.']
    try:
        assert s._deserialize(None, None, None) is None
        assert False
    except ValidationError as e:
        assert e.messages == ['Missing data for required field.']



# Generated at 2022-06-23 16:45:25.199318
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class D:
        u: typing.Union[A, B]

    a = A()
    tmp = _UnionField(
        desc={A: A, B: B},
        cls=D,
        field=D.__annotations__['u'],
        allow_none=True)
    assert tmp._serialize(a, 'u', None)['__type'] == 'A'
    tmp = _UnionField(
        desc={A: A, B: B},
        cls=D,
        field=D.__annotations__['u'],
        allow_none=False)

# Generated at 2022-06-23 16:45:33.319114
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class A:
        x: int = 0

    @dataclass_json
    @dataclass
    class B:
        x: int = 0

    # noinspection PyTypeChecker
    class SchemaA(SchemaF[A]):
        x = fields.Int()

    # noinspection PyTypeChecker
    class SchemaB(SchemaF[B]):
        x = fields.Int()

    a1 = A(x=1)
    a2 = A(x=2)

    b1 = B(x=1)
    b2 = B(x=2)

    schema_a = SchemaA()
    schema_b = SchemaB()

    assert schema_a.dump(a1) == {'x': 1}


# Generated at 2022-06-23 16:45:39.593401
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B:
        pass
    @dataclass
    class C:
        a: typing.Union[A, B]
    cls = C
    field = dc_fields(C)[0]
    desc = typing.get_args(field.type)
    args = []
    kwargs = {}
    _UnionField(desc, cls, field, *args, **kwargs)


# Generated at 2022-06-23 16:45:49.365307
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        class MySchema(SchemaF[int]):
            foo = fields.Int()

# Generated at 2022-06-23 16:45:55.146739
# Unit test for function build_type
def test_build_type():
    import dataclasses
    @dataclasses.dataclass
    class A:
        x: int
    @dataclasses.dataclass
    class B:
        x: int
        y: A
        z: typing.List[A]
    res = build_type(B.__annotations__['y'], {}, type(None), namedtuple('f', 'name type'), B).__class__
    assert(res == fields.Nested)


# Generated at 2022-06-23 16:46:04.897267
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None

    from marshmallow import Schema, fields

    class FooSchema(SchemaF[Foo]):
        class Meta:
            # noinspection PyUnresolvedReferences
            dataclass = Foo
            unknown = "EXCLUDE"

        value: fields.Integer = fields.Integer()

    foo1 = Foo(value=42)

    serialized_foo1 = FooSchema().dump(foo1)
    assert serialized_foo1 == {'value': 42}

    foo2 = Foo(value=1)

    serialized_foos = FooSchema().dump([foo1, foo2])
    assert serialized_foos == [{'value': 42}, {'value': 1}]

    serialized_foos = FooSchema().dump(iter([foo1, foo2]))
   

# Generated at 2022-06-23 16:46:16.926455
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    test_value = datetime.now()
    test_value_serialized = test_value.isoformat()
    assert field.serialize(test_value) == test_value_serialized
    assert field.deserialize(test_value_serialized) == test_value
    assert field.deserialize('2009-02-13T23:31:30.123456+00:00') == datetime(2009,2,13,23,31,30,123456)
    assert field.deserialize('2009-02-13T23:31:30.123456') == datetime(2009,2,13,23,31,30,123456)

# Generated at 2022-06-23 16:46:20.295131
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_iso = "2019-03-12T21:23:21.801687"
    test_field = _IsoField()
    print(type(test_field._deserialize(test_iso, "attr", "data")))


# Generated at 2022-06-23 16:46:28.989289
# Unit test for function schema
def test_schema():
    import marshmallow as mm

    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config, dataclass_json

    DC_JSON_CONFIG = config.new(infer_optional=True)


# Generated at 2022-06-23 16:46:32.878791
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class A:
        pass

    s = SchemaF[A]()
    x = s.dumps(A())
    y = s.dumps([A(), A()])
    z = s.loads(x)
    z = s.loads(y)



# Generated at 2022-06-23 16:46:43.569066
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict
    from dataclasses_json import DataClassJsonMixin


    @dataclass
    class A(DataClassJsonMixin):
        pass


    @dataclass
    class B(DataClassJsonMixin):
        a: int
        b: Optional[int] = None


    @dataclass
    class C(DataClassJsonMixin):
        a: int
        d: Union[int, str]


    @dataclass
    class D(DataClassJsonMixin):
        a: List[int]
        d: Union[int, str]


    @dataclass
    class E(DataClassJsonMixin):
        d: Dict[str, int]



# Generated at 2022-06-23 16:46:51.438413
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import dataclasses
    @dataclasses.dataclass
    class SimpleClass:
        integer: int

    @dataclasses.dataclass
    class ComplexClass:
        simple_list: typing.List[SimpleClass]
        simple_class: SimpleClass

    class SimpleSchema(SchemaF[SimpleClass]):
        integer = fields.Int(required=True)

    class ComplexSchema(SchemaF[ComplexClass]):
        simple_list = fields.Nested(SimpleSchema, many=True, required=True)
        simple_class = fields.Nested(SimpleSchema, required=True)

    simple_schema = SimpleSchema()
    complex_schema = ComplexSchema()

    result = simple_schema.dump([SimpleClass(integer=1)], many=True)

# Generated at 2022-06-23 16:46:53.325825
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int()



# Generated at 2022-06-23 16:47:01.391235
# Unit test for constructor of class _UnionField
def test__UnionField():
    x = _UnionField(None, None, None)
    assert x.default is fields.missing
    assert x.missing is fields.missing
    assert x.data_key is None
    assert x.load_only is False
    assert x.dump_only is False
    assert x.error_messages == {}
    assert x.validate == []
    assert x.required is False
    assert x.allow_none is False
    assert repr(x) == '<fields.Field>'


# Generated at 2022-06-23 16:47:12.318793
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class User:
        def __init__(self, name, email):
            self.name = name
            self.email = email

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()

    user_schema = UserSchema()
    user = User("Monty", "monty@python.org")
    encoded = user_schema.dump(user)
    decoded = user_schema.load(encoded)
    assert 'name' in decoded
    assert decoded['name'] == 'Monty'
    assert 'email' in decoded
    assert decoded['email'] == 'monty@python.org'
    decoded = user_schema.load(encoded)
    assert 'name' in decoded

# Generated at 2022-06-23 16:47:12.911122
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass

# Generated at 2022-06-23 16:47:23.062122
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Dict, Tuple, List, Set, Union
    from datetime import date

    from marshmallow import Schema

    from dataclasses import dataclass, field

    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: List[str]

        class Config:
            additional = ('a',)

    @dataclass
    class B(DataClassJsonMixin):
        b: Set[int]

        class Config:
            additional = ('b',)

    @dataclass
    class C(DataClassJsonMixin):
        c: Tuple[float, float]

        class Config:
            additional = ('c',)


# Generated at 2022-06-23 16:47:25.307170
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        pass

    with pytest.raises(NotImplementedError):
        SchemaF[Foo]()



# Generated at 2022-06-23 16:47:36.848473
# Unit test for constructor of class _UnionField
def test__UnionField():
    # A couple of classes for testing the code below
    class Cat:
        pass

    class Dog:
        pass

    class Blob:
        pass

    class Animal:
        pass

    # Create a list of classes that we can use to test
    classes = [Cat, Dog, Blob]

    # Create a dict that we can use to test
    unions = {
        Union[Cat, Dog, Blob]: {Cat: _UnionField(None, Animal, None),
                                Dog: _UnionField(None, Animal, None),
                                Blob: _UnionField(None, Animal, None)}
        }

    # Test the class constructor with a couple different arguments
    with pytest.raises(TypeError):
        _UnionField({}, Animal, None)


# Generated at 2022-06-23 16:47:48.108758
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF[int].loads('{"a":1}', many=False), int)
    assert isinstance(SchemaF.loads('{"a":1}', many=False), dict)
    assert isinstance(SchemaF[int].loads('[{"a":1}]', many=True), list)
    assert isinstance(SchemaF.loads('[{"a":1}]', many=True), list)
    assert isinstance(SchemaF[int].loads('{"a":[1]}'), int)
    assert isinstance(SchemaF[int].loads('[{"a":[1]}]'), list)
    assert isinstance(SchemaF.loads('{"a":[1]}'), dict)
    assert isinstance(SchemaF.loads('[{"a":[1]}]'), list)



# Generated at 2022-06-23 16:47:49.588665
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()



# Generated at 2022-06-23 16:47:54.993758
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF[int].loads('[1, 2, 3]'), typing.List[int])
    assert isinstance(SchemaF[int].loads('[1, 2, 3]', many=True), typing.List[int])
    assert isinstance(SchemaF[int].loads('[1, 2, 3]', many=False), int)
    assert isinstance(SchemaF[int].loads('[1, 2, 3]', many=None), typing.List[int])
    assert isinstance(SchemaF[int].loads('1'), int)
    assert isinstance(SchemaF[int].loads('1', many=True), typing.List[int])
    assert isinstance(SchemaF[int].loads('1', many=False), int)

# Generated at 2022-06-23 16:48:00.159527
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = 1530058326.73943
    t = datetime.utcfromtimestamp(ts)
    tf = _TimestampField()

    assert(tf._serialize(t, None, None) == ts)
    assert(tf._deserialize(ts, None, None) == t)


# Generated at 2022-06-23 16:48:02.147903
# Unit test for constructor of class _IsoField
def test__IsoField():
    instance = _IsoField(allow_none=True)
    assert isinstance(instance, _IsoField)


# Generated at 2022-06-23 16:48:10.329554
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    @dataclass
    class Foo:
        bar: str
        baz: int
    class FooSchema(Schema):
        bar = fields.Str()
        baz = fields.Int()
    schema = FooSchema.as_marshmallow_schema()
    foo = Foo('bar', 1)
    assert schema.dump(foo) == {'bar': 'bar', 'baz': 1}
    assert schema.dump([foo, foo]) == [{'bar': 'bar', 'baz': 1}, {'bar': 'bar', 'baz': 1}]

# Generated at 2022-06-23 16:48:16.939588
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tf = _TimestampField()
    tf.required = True
    with pytest.raises(ValidationError):
        tf._deserialize(None, None, None)
    assert tf._deserialize(0, None, None) == datetime(1970, 1, 1, tzinfo=UTC)
    assert tf._serialize(datetime(1970, 1, 1, tzinfo=UTC), None, None) == 0



# Generated at 2022-06-23 16:48:27.127844
# Unit test for function build_schema
def test_build_schema():
    # DataClassFoo = dataclass_json
    class DataClassFoo:
        pass
    DataClassFoo_ = build_schema(DataClassFoo)
    # assert DataClassFoo_.dumps(DataClassFoo_) == "{}"
    assert DataClassFoo_.dumps(DataClassFoo_) == '{"Meta": {"fields": ()}}'

    # DataClassBar = dataclass_json(mm_field=fields.Str)
    class DataClassBar:
        pass
    DataClassBar_ = build_schema(DataClassBar)
    # assert DataClassBar_.dumps(DataClassBar_) is "{}"
    # This is not necessary true!
    # assert DataClassBar_.dumps(DataClassBar_) == '{"Meta": {<fields.Field: dataclass_json_config

# Generated at 2022-06-23 16:48:32.534740
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(year=1, month=1, day=1), "attr", None) == "0001-01-01T00:00:00"
    assert field._deserialize("0001-01-01T00:00:00", "attr", None) == datetime(year=1, month=1, day=1)
    return "OK"


# Generated at 2022-06-23 16:48:37.093588
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    val = field._deserialize('2019-04-07T11:59:25.315692')
    assert val.isoformat() == '2019-04-07T11:59:25.315692'


# Generated at 2022-06-23 16:48:47.029463
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class User(typing.NamedTuple):
        id: int
        name: str
        email: str

    class UserSchema(SchemaF[User]):
        id = fields.Int()
        name = fields.Str()
        email = fields.Email()

    schema = UserSchema()
    user = schema.load({'id': 123, 'name': 'foo', 'email': 'foo@bar.org'})
    assert isinstance(user, User)
    assert user.name == 'foo'
    assert schema.type_name == 'User'
    users = schema.load([{'id': 123, 'name': 'foo', 'email': 'foo@bar.org'}])
    assert isinstance(users, list)
    assert isinstance(users[0], User)

# Generated at 2022-06-23 16:48:52.690769
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields, Schema

    class Bla(Schema):
        name: str

    assert Bla.load({'name': 'asdf'}) == {'name': 'asdf'}
    assert Bla.load({'name': 'asdf'}, many=False) == {'name': 'asdf'}



# Generated at 2022-06-23 16:48:56.627823
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class TestSchema(SchemaF):
        test_field = fields.Str()

    assert TestSchema.loads({"test_field": "test"}) == {"test_field": "test"}



# Generated at 2022-06-23 16:49:05.363734
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import datetime
    import uuid

    class _FakeSchema(SchemaF[A]):
        def __init__(self, x: datetime.datetime):
            super().__init__()
            self.x = x

    x = datetime.datetime.now()
    res = _FakeSchema(x).dump(x)
    assert res == x.timestamp()
    res = _FakeSchema(x).dump([x])
    assert res == [x.timestamp()]
    assert _FakeSchema(x).dump(x, many=False) == x.timestamp()
    assert _FakeSchema(x).dump([x], many=False) == [x.timestamp()]

    u = uuid.uuid4()
    res = _FakeSchema(uuid.uuid4()).dump

# Generated at 2022-06-23 16:49:09.730567
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None
    assert _TimestampField()._serialize(None, None, None) is None


# Generated at 2022-06-23 16:49:18.280257
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # Simple dataclass
    @dataclass
    class A:
        x: int

    a = A(5)
    b = [A(5), A(6)]

    # Typed schema
    sa = SchemaF[A]()
    assert sa.dump(a) == {"x": 5}
    assert sa.dumps(a) == '{"x": 5}'
    assert sa.dump(b) == [{"x": 5}, {"x": 6}]
    assert sa.dumps(b) == '[{"x": 5}, {"x": 6}]'

    deserialized = sa.loads('{"x": 5}')
    assert deserialized == A(5)
    assert type(deserialized) is A

    deserialized = sa.load('{"x": 5}')

# Generated at 2022-06-23 16:49:26.296874
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class SchemaFSub(SchemaF):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.original_loads = self.loads
            self.loads = self.my_loads

        def my_loads(self, obj_or_json, *args, **kwargs):
            if isinstance(obj_or_json, str):
                return self.original_loads(obj_or_json, *args, **kwargs)
            else:
                return "a string"
    a = SchemaFSub([])
    assert a.loads("[1, 2, 3]") == ["a string", "a string", "a string"]
    assert a.loads(b"[1, 2, 3]") == ["a string", "a string", "a string"]

# Generated at 2022-06-23 16:49:35.763094
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema

    class STest(Schema):
        bar = fields.Str()

    class DTest:
        def __init__(self, bar):
            self.bar = bar

    class DTests(Schema):
        foo = fields.Nested(STest)

    # we need to tell mypy that this is actually an instance of SchemaF
    dt = SchemaF[DTest](DTests, many=True)  # type: ignore

    dt.dump([DTest(1), DTest(2)])



# Generated at 2022-06-23 16:49:43.852924
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Test:
        x: int

    class TestSchema(SchemaF[Test]):
        x = fields.Int()

        @post_load
        def make_object(self, data, **kwargs):
            print(data)
            return Test(**data)

    test_schema = TestSchema()
    test_schema.load({"x": 3})
    test_schema.load([{"x": 2}, {"x": 3}])



# Generated at 2022-06-23 16:49:44.568916
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()


# Generated at 2022-06-23 16:49:47.426317
# Unit test for constructor of class _IsoField
def test__IsoField():
    i1 = _IsoField(required=True)
    assert i1.required == True
    assert i1.location == 'query'
    assert i1.data_key == None


# Generated at 2022-06-23 16:49:52.651353
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    class S(typing.Generic[A], SchemaF):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    S._resolve_custom_class(fields.Field)



# Generated at 2022-06-23 16:49:59.026407
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List, Dict
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Domain(object):
        value: str

    @dataclass
    class Foo(object):
        id: str
        domains: List[str]
        domains_obj: List[Domain]
        domains_dict: List[Dict[str, str]]

    class DomainSchema(Schema):
        value = fields.String()

    class FooSchema(SchemaF[Foo]):
        id = fields.String()
        domains = fields.List(fields.String())
        domains_obj = fields.List(fields.Nested(DomainSchema))
        domains_dict = fields.List(fields.Dict())



# Generated at 2022-06-23 16:50:00.256331
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, None, None, None) == fields.Str

# Generated at 2022-06-23 16:50:02.191522
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert not _UnionField({}, {}, {}, {})


# Generated at 2022-06-23 16:50:07.221367
# Unit test for function build_schema
def test_build_schema():
    class P(typing.Protocol):
        def __getitem__(self, i: int) -> int: ...

    class C1:
        def __init__(self, i):
            self.i = i

        def __getitem__(self, i: int) -> int:
            return self.i

    class C2:
        pass

    @dataclass
    class Point:
        x: int
        y: int

    @dataclass
    class Line:
        p1: Point
        p2: Point

    @dataclass
    class Circle:
        r: int
        center: Point

    @dataclass
    class R:
        i: typing.Union[int, C1, C2, 'R', P]

    assert str(build_schema(Line, None, True, False))

# Generated at 2022-06-23 16:50:10.383838
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class X:
        i: int

    assert schema(X, ..., ...) == {'i': fields.Int()}


# Generated at 2022-06-23 16:50:10.991201
# Unit test for function build_schema
def test_build_schema():
    import typing
    import dataclasses
    imp

# Generated at 2022-06-23 16:50:17.246597
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """
    For no mypy error
    """
    v1 = SchemaF[int]().dump(1)
    v2 = SchemaF[int]().dumps(1)
    v3 = SchemaF[int]().load(v1)
    v4 = SchemaF[int]().loads(v2)


# TODO: Add a class for Enum to be compliant with the type of fields.List

# Generated at 2022-06-23 16:50:19.389143
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    loads(loads, SchemaF)  # test that the overload is correctly resolved



# Generated at 2022-06-23 16:50:21.286666
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    instance = _TimestampField()
    assert isinstance(instance, _TimestampField)


# Generated at 2022-06-23 16:50:23.759024
# Unit test for function schema
def test_schema():
    class Test:
        pass
    s = schema(Test, 'SomeCls', False)
    assert s == {}



# Generated at 2022-06-23 16:50:34.039422
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json.api import mm_field

    class PersonSchema(SchemaType):  # type: ignore
        id = mm_field(int, dump_only=True)
        age = mm_field(int)
        name = mm_field(str, required=True)

    @dataclass
    class Employee(PersonSchema):
        ssn: int

    schema = Employee.schema()
    assert type(schema.fields['id']) == fields.Int
    assert type(schema.fields['ssn']) == fields.Int
    del(schema.fields['id'])
    assert type(schema.fields['ssn']) == fields.Int
    assert type(schema.fields['age']) == fields.Int



# Generated at 2022-06-23 16:50:41.419155
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f._serialize(datetime(1970, 1, 1, 1, 1, 1), None, None) == 3661
    assert f._serialize(None, None, None) is None
    assert f._deserialize(3661, None, None) == datetime(1970, 1, 1, 1, 1, 1)
    assert f._deserialize(None, None, None) is None



# Generated at 2022-06-23 16:50:51.553732
# Unit test for function build_type
def test_build_type():
    from typing import List
    from marshmallow import fields, Schema
    import pytest

    class One:
        pass

    class Two:
        pass

    class Three(One):
        pass

    class Four(One):
        pass

    class S(Schema[One]):
        @post_load
        def one(self, data, **kwargs):
            return One()

    class S1(Schema[Three]):
        @post_load
        def one(self, data, **kwargs):
            return Three()

    class S2(Schema[Four]):
        @post_load
        def one(self, data, **kwargs):
            return Four()


# Generated at 2022-06-23 16:50:59.554133
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: int

    schema = dataclass_json.Schema(A, unknown="EXCLUDE")

    x: A = schema.loads(json_data='{"a": 1}', many=False)
    assert x.a == 1
    assert isinstance(x, A)
    assert not isinstance(x, tuple)

    x: typing.List[A] = schema.loads(json_data='[{"a": 1}]', many=True)
    assert x[0].a == 1
    assert isinstance(x[0], A)
    assert not isinstance(x[0], tuple)


# Generated at 2022-06-23 16:51:02.445711
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(1582695526.0, None, None) == datetime(2020, 2, 24, 18, 32, 6, tzinfo=utc)



# Generated at 2022-06-23 16:51:04.859863
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), fields.Field)


# Generated at 2022-06-23 16:51:08.294907
# Unit test for function build_schema
def test_build_schema():
    assert issubclass(
        build_schema(
            cls=typing.Type[A],
            mixin='',
            infer_missing='',
            partial=''),
        Schema)



# Generated at 2022-06-23 16:51:18.793732
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json.mm_schema_field_override import mm_field
    from dataclasses_json.mm_schema_dataclass import dataclass_json

    @dataclass
    class A:
        a: str

    @dataclass
    class D:
        """
        This is an example of an unsupported dataclass.
        """
        a: A
        b: int
        c: typing.Dict[str, str]

    assert schema(D, dataclass_json, False) == {
        'a': fields.Field(),
        'b': fields.Field(),
        'c': fields.Dict
    }


# Generated at 2022-06-23 16:51:29.410828
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow_dataclass import class_schema
    from marshmallow_dataclass.schema import SchemaF
    from marshmallow import fields, Schema, post_load
    from dataclasses import dataclass
    @dataclass
    class Test:
        a: int
        b: str
    assert SchemaF[Test].dumps(Test(1, '2')) == '{"a": 1, "b": "2"}'
    assert SchemaF[Test].dumps([Test(1, '2'), Test(3, '4')]) == '[{"a": 1, "b": "2"}, {"a": 3, "b": "4"}]'
    assert SchemaF[Test].dumps(None) == 'null'

# Generated at 2022-06-23 16:51:33.364456
# Unit test for constructor of class _IsoField
def test__IsoField():
    d = datetime.now()
    assert d == _IsoField()._deserialize(_IsoField()._serialize(d, "", ""), "", "")


# Generated at 2022-06-23 16:51:44.155221
# Unit test for function build_schema
def test_build_schema():
    import typing
    import datetime

    from dataclasses import dataclass, fields

    from dataclasses_json.config import Config

    import marshmallow as mm
    from marshmallow import fields as f
    from marshmallow.validate import Range

    @dataclass
    class User:
        name: str
        github: str
        age: int = None
        created_at: typing.Optional[datetime.datetime] = None

    import pytest


# Generated at 2022-06-23 16:51:53.386175
# Unit test for function build_schema
def test_build_schema():
    assert hasattr(build_schema(build_schema(TestClass)[0],
                                None,
                                False,
                                False),
                   'Meta')
    assert hasattr(build_schema(build_schema(TestClass)[0],
                                None,
                                False,
                                False),
                   'objects')
    assert hasattr(build_schema(build_schema(TestClass)[0],
                                None,
                                False,
                                False),
                   'make_testclass')
    assert hasattr(build_schema(build_schema(TestClass)[0],
                                None,
                                False,
                                False),
                   'dumps')

# Generated at 2022-06-23 16:51:57.566801
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(
        desc={int: fields.Int()},
        cls=CatchAllVar('cls'),
        field=CatchAllVar('field')
    )


# Generated at 2022-06-23 16:52:08.449926
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from typing import Optional, Union, List

    @dataclass
    class Person(DataClassJsonMixin):
        name: str

    @dataclass
    class User(DataClassJsonMixin):
        id: int
        age: int
        person: Person

    assert build_schema(Person, DataClassJsonMixin, False, True).__name__ == "PersonSchema"
    assert build_schema(User, DataClassJsonMixin, False, True).__name__ == "UserSchema"
    assert build_schema(Person, DataClassJsonMixin, False, True).Meta.fields == ("name",)

# Generated at 2022-06-23 16:52:14.077339
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert(SchemaF.load([{}]))

# Generated at 2022-06-23 16:52:20.252037
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF[str].dump(['1', '2', '3'], many=True) == [{'data': '1'}, {'data': '2'}, {'data': '3'}]
    assert SchemaF[str].dump('foo', many=False) == {'data': 'foo'}
    assert SchemaF[str].dump(['1', '2', '3']) == [{'data': '1'}, {'data': '2'}, {'data': '3'}]
    assert SchemaF[str].dump('foo') == {'data': 'foo'}
    assert SchemaF[str].dump(['1', '2', '3'], many=False) == {'data': '1'}

# Generated at 2022-06-23 16:52:26.871596
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json, config

    @dataclass_json
    class Test:
        a: str
        b: int = 1

    s = schema(Test, config.MIXIN, False)
    assert s == {'a': fields.Str(), 'b': fields.Int()}



# Generated at 2022-06-23 16:52:38.317847
# Unit test for function build_type
def test_build_type():
    has_warnings = False
    import warnings
    import marshmallow as ma

    class MyEnum(Enum):
        FOO = 1
        BAR = 2
        FOOBAR = 3

    @dataclass_json
    @dataclass
    class SubDataclass:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class Dataclass:
        a: int
        b: str
        c: Optional[str]
        d: typing.Union[SubDataclass, str]
        e: datetime
        f: UUID
        g: typing.Union[int, float]
        h: MyEnum
        i: Optional[MyEnum]
        j: List[str]
        k: typing.Mapping[str, str]

# Generated at 2022-06-23 16:52:50.053219
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = typing.List[int]
    a = [1, 2, 3]
    schema = SchemaF()
    res = schema.dumps(a)
    assert isinstance(res, str)
    res = schema.dumps(a, many=True)
    assert isinstance(res, str)
    res = schema.dumps(a, many=False)
    assert isinstance(res, str)
    res = schema.dump(a)
    assert isinstance(res, typing.List)
    res = schema.dump(a, many=True)
    assert isinstance(res, typing.List)
    res = schema.dump(a, many=False)
    assert isinstance(res, dict)
    a = typing.List[float]  # type: ignore

# Generated at 2022-06-23 16:52:55.580419
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class SimpleSchema(SchemaF[str]):
        field = fields.String()

    data = '{"field": "hello world"}'
    obj = SimpleSchema().loads(data)
    assert obj == 'hello world'



# Generated at 2022-06-23 16:52:56.521462
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-23 16:53:02.645859
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    import typing
    import pytest
    class ExampleMixin(object):
        pass

    @dataclass
    class Example1(ExampleMixin):
        pass

    @dataclass
    class Example2(ExampleMixin):
        pass

    @dataclass
    class Example(ExampleMixin):
        num: typing.Optional[int] = None
        choice: typing.Optional[typing.Union[Example1, Example2]] = None
        num2: typing.Optional[int] = None

    @dataclass
    class Example(ExampleMixin):
        num: typing.Optional[int] = None
        choice: typing.Optional[typing.Union[Example1, Example2]] = None
        num2: typing.Optional[int] = None


# Generated at 2022-06-23 16:53:10.108253
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Arrange
    dt = datetime.utcnow()
    expected_serialization = dt.timestamp()
    expected_deserialization = dt

    field = _TimestampField()

    # Act
    serialization = field.serialize(dt)
    deserialization = field.deserialize(expected_serialization)

    # Assert
    assert expected_serialization == serialization
    assert expected_deserialization == deserialization



# Generated at 2022-06-23 16:53:18.154331
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def parse_json(self, json_string: str, **kwargs):
        return json.loads(json_string, **kwargs)

    SchemaF.parse_json = parse_json

    def test(json_string, many: bool, cls: typing.Type[A]):
        s = SchemaF[cls]
        return s.loads(json_string, many=many)

    def test_list(json_string, many: bool, cls: typing.Type[A]):
        s = SchemaF[typing.List[cls]]
        return s.loads(json_string, many=many)

    from dataclasses_json.tests.test_customtypes import Account

# Generated at 2022-06-23 16:53:21.988142
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from datetime import date
    from marshmallow import fields

    class TestSchemaF(SchemaF[date]):
        pass

    TestSchemaF._declared_fields = {
        'date': fields.Date(),
    }



# Generated at 2022-06-23 16:53:32.858945
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union

    from marshmallow import fields

    from dataclasses import dataclass
    from dataclasses_json.annotation import mm_field, mm_schema
    from dataclasses_json.utils import _is_optional, _is_union_type

    @dataclass
    class A:
        mm_field(float, mm_field=fields.Decimal, allow_none=True)
        mm_field(Optional[float], mm_field=fields.Decimal, allow_none=True)
        mm_field(Optional[int], mm_field=fields.Decimal, allow_none=True)
        mm_field(Union[str, int], mm_field=fields.Str, allow_none=True)

    @dataclass
    class B(A):
        """ Some comment """
        pass



# Generated at 2022-06-23 16:53:34.229193
# Unit test for function build_type
def test_build_type():
    # TODO:  
    pass



# Generated at 2022-06-23 16:53:37.785713
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    class A(Schema):
        x = fields.Int()
        y = fields.Int()
    s = A()
    s.load({'x': 1})



# Generated at 2022-06-23 16:53:44.630865
# Unit test for function build_schema
def test_build_schema():
    class Foo: pass
    class Base: pass
    class Sub(Base): pass
    # Unit test for the class definition
    @dataclass
    class TestForBuildSchema:
        a: Optional[int]
        b: Optional[str]
        c: typing.Dict[str, int]
        d: typing.Tuple[str, int]
        e: typing.List[str]
        f: typing.Union[int, str, bool]

    test_build_schema_obj = TestForBuildSchema(a=1, b='b', c={'a':1}, d=('a',1), e=['1'], f=int(1))
    schema_obj = build_schema(TestForBuildSchema, dataclass_json.mixin(Base), False, False)

# Generated at 2022-06-23 16:53:56.280780
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    @dataclass
    class A:
        field: str
    @dataclass
    class B(A):
        field: str
    @dataclass
    class C:
        field: typing.List[A]
    @dataclass
    class D:
        field: typing.Mapping[str, A]

    def inner(type_, options):
        origin = getattr(type_, '__origin__', type_)
        args = [inner(a, {}) for a in getattr(type_, '__args__', []) if
                a is not type(None)]

        if _is_optional(type_):
            options["allow_none"] = True

        if origin in TYPES:
            return TYPES[origin](*args, **options)


# Generated at 2022-06-23 16:54:07.530679
# Unit test for function build_schema
def test_build_schema():
    class SubMixin:
        a: int

    class Mixin(SubMixin):
        b: int

    @dataclass_json
    class Example:
        a: int
        b: int


# Generated at 2022-06-23 16:54:08.674298
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-23 16:54:12.462387
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    now = datetime.now()
    tf = _TimestampField()
    assert tf._serialize(now,None,None) == now.timestamp()
    assert tf._deserialize(now.timestamp(),None,None) == now


# Generated at 2022-06-23 16:54:20.880464
# Unit test for constructor of class _IsoField
def test__IsoField():
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", r"^Using or importing the ABCs from 'collections'")
        if sys.version_info < (3, 5):
            assert _IsoField()._serialize(datetime(2010, 2, 3, 4, 5, 6, 789)) == '2010-02-03T04:05:06.000789'
            assert _IsoField()._deserialize('2010-02-03T04:05:06.000789') == datetime(2010, 2, 3, 4, 5, 6, 789)
        else:
            assert _IsoField()._serialize(datetime(2010, 2, 3, 4, 5, 6, 789)) == '2010-02-03T04:05:06.000789'
            assert _Iso

# Generated at 2022-06-23 16:54:28.888982
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import fields
    from marshmallow.schema import Schema
    from marshmallow.schema import SchemaOpts
    from dataclasses_json import Schema
    from typing import List, Dict
    from dataclasses import dataclass
    import json
    import marshmallow
    @dataclass
    class DummySchema(Schema, typing.Generic[A]):
        pass

    @dataclass
    class DummySchemaWithBinary(Schema, typing.Generic[A]):
        pass





# Generated at 2022-06-23 16:54:32.189591
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class A(object):
        pass

    class B(SchemaF[A]):
        pass

    a = A()
    b = B.load([a])
    assert b[0] is a

    b = B.load(a)
    assert b is a


# Generated at 2022-06-23 16:54:35.959522
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class SomeSchema(SchemaF[A]):
        pass

    try:
        SomeSchema()
    except NotImplementedError:
        pass
    else:
        assert False, "Expected NotImplementedError"



# Generated at 2022-06-23 16:54:40.265725
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test_datetime = datetime(2020, 2, 20, 0, 0, 0)
    assert _TimestampField()._serialize(test_datetime, None, None) == 1582137600.0
    assert _TimestampField()._deserialize(1582137600.0, None, None) == test_datetime


# Generated at 2022-06-23 16:54:44.930892
# Unit test for constructor of class SchemaF
def test_SchemaF():
    sf = SchemaF[int]()
    if sys.version_info >= (3, 7):
        assert False, "Should not be possible to instantiate class SchemaF!!"
    else:
        assert isinstance(sf, Schema)


# Generated at 2022-06-23 16:54:55.017783
# Unit test for function schema
def test_schema():
    import mm_example
    t = schema(mm_example.Person, mm_example.DataclassJsonMixin, False)
    assert t['name']._deserialize("stefano") == "stefano"
    assert t['age']._deserialize(1) == 1
    assert t['birthday']._deserialize({"__type": "Date", "year": 1997}) == datetime(1997, 1, 1)
    assert t['is_new']._deserialize(True) is True
    assert t['is_new']._deserialize(False) is False
    assert type(t['optional']) == _UnionField
    assert t['optional']._deserialize({"__type": "Date", "year": 1997}) == datetime(1997, 1, 1)

# Generated at 2022-06-23 16:55:06.973736
# Unit test for function schema
def test_schema():
    import dataclasses
    @dataclasses.dataclass
    class V:
        v: float
    class V(dataclasses.dataclass):
        v: float
    @dataclasses.dataclass
    class A:
        a: int
    @dataclasses.dataclass
    class B:
        b: typing.Union[V, typing.Optional[A]]
    @dataclasses.dataclass
    class C:
        c: typing.Union[B, V]
    @dataclasses.dataclass
    class D:
        d: typing.List[typing.List[int]]
    @dataclasses.dataclass
    class E:
        e: typing.Dict[str, int]
    @dataclasses.dataclass
    class F:
        f: typing