

# Generated at 2022-06-23 16:44:57.409942
# Unit test for constructor of class SchemaF
def test_SchemaF():
    pass



# Generated at 2022-06-23 16:45:05.860665
# Unit test for method loads of class SchemaF

# Generated at 2022-06-23 16:45:07.503057
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f: SchemaF[int]
    value = schema_f.loads(b'123')



# Generated at 2022-06-23 16:45:16.795770
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def test_load_SchemaF_many1():
        from typing import List
        import marshmallow
        class _Schema(SchemaF[List[int]]): pass
        _dump = _Schema().load([1, 2, 3], many=True)
        assert _dump == [1, 2, 3]
        assert isinstance(_dump, List[int])

    def test_load_SchemaF_many2():
        from typing import List
        import marshmallow
        class _Schema(SchemaF[List[int]]): pass
        _dump = _Schema().load([1, 2, 3])
        assert _dump == [1, 2, 3]

    def test_load_SchemaF_single1():
        from typing import List
        import marshmallow
        class _Schema(SchemaF[int]): pass

# Generated at 2022-06-23 16:45:25.981357
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union

    @dataclass
    class A:
        b: Union[int, float, str, bool]

    from marshmallow import Schema
    from marshmallow.fields import Int, Float, String, Boolean

    class ASchema(Schema):
        b = _UnionField(
            A.__annotations__['b'],
            A,
            A.__dataclass_fields__['b'],
            fields=[
                Int(attribute='b'),
                Float(attribute='b'),
                String(attribute='b'),
                Boolean(attribute='b')
            ])

    a = A(b='b')
    a_schema = ASchema()
    a_data, _ = a_schema.dump(a)

# Generated at 2022-06-23 16:45:33.804867
# Unit test for constructor of class _UnionField
def test__UnionField():
    try:
        from typing import Union
    except ImportError:
        assert True
        return
    from dataclasses import dataclass
    from marshmallow import Schema
    from marshmallow.fields import String
    from marshmallow.exceptions import ValidationError

    # definition of dataclasses
    @dataclass
    class StringDC:
        s: str

    @dataclass
    class IntDC:
        i: int

    @dataclass
    class MainDC:
        value: Union[StringDC, IntDC]

    # definition of schemas
    class StringSchema(Schema):
        s = String()

    class IntSchema(Schema):
        i = fields.Integer()


# Generated at 2022-06-23 16:45:41.968787
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class A(typing.NamedTuple):
        pass
    class B(typing.NamedTuple):
        pass

    @dataclasses_json.dataclass_json(unknown=EXCLUDE)
    @dataclasses.dataclass
    class T(typing.NamedTuple):
        a: A
        b: B

    @dataclasses.dataclass
    class Test(typing.NamedTuple):
        a: A
        b: B
        t: typing.Union[A, B, T]
    with pytest.raises(NotImplementedError):
        SchemaF[Test]()



# Generated at 2022-06-23 16:45:50.137847
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    from datetime import datetime
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class Helper:
        name: str
    schema = SchemaF[Helper]()
    values = schema.load([{'name': 'test'}], many=True)
    assert isinstance(values, List)
    assert values[0].name == 'test'

    value = schema.load({'name': 'test'})
    assert isinstance(value, Helper)
    assert value.name == 'test'

    value2 = schema.load({'name': 'test'}, many=False)
    assert isinstance(value2, Helper)
    assert value2.name == 'test'



# Generated at 2022-06-23 16:45:57.168272
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    SchemaF.dump(None, None)
    SchemaF(MISSING).dump(None, None)
    SchemaF(MISSING).dump([], None)
    SchemaF(MISSING).dump("test", None)
    SchemaF(MISSING).dump("test", True)
    SchemaF(MISSING).dump(["test"], None)
    SchemaF(MISSING).dump(["test"], True)
    SchemaF(MISSING).dump("test", False)
    SchemaF(MISSING).dump(["test"], False)
test_SchemaF_dump()


# Generated at 2022-06-23 16:46:08.857335
# Unit test for constructor of class _UnionField
def test__UnionField():
    def dcfactory(field_, _cls=None, **kwargs):
        return fields.Field(metadata=kwargs, default=MISSING, default_factory=MISSING, init=True, repr=True, hash=None, compare=True, metadata=None)

    class E(Enum):
        a = 'a'
        b = 'b'

    u = typing.Union[E, int, str]

    _validate_union(u, _UnionField, dcfactory)

    u = typing.Union[E, int, str, typing.Optional[typing.List[E]]]

    _validate_union(u, _UnionField, dcfactory)

    u = typing.Union[E, int, str, typing.Dict[str, E], typing.List[E]]

    _validate_

# Generated at 2022-06-23 16:46:19.066866
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema, EXCLUDE, pre_load, post_load
    from marshmallow.validate import Length, Range
    from marshmallow.fields import String, Int

    @pre_load
    def prepare_date(data, **kwargs):
        data['created_at'] = datetime.utcnow().isoformat()
        return data

    @post_load
    def make_author(data, **kwargs):
        return Author(**data)

    class AuthorSchema(SchemaF[Author]):
        name = String(required=True, validate=Length(min=1))
        age = Int(validate=Range(min=0))
        created_at = String()

        class Meta:
            unknown = EXCLUDE


# Generated at 2022-06-23 16:46:29.038886
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    from marshmallow import fields as ma_fields

    @dataclass
    class A:
        field: Union[int, str]

    @dataclass
    class B:
        field: Union[A, int]

    @dataclass
    class C:
        field: Union[A]

    adc = {A: A.__annotations__, B: B.__annotations__, C: C.__annotations__}

    assert _is_union_type(A.__annotations__['field'])
    assert _is_union_type(B.__annotations__['field'])
    assert _is_union_type(C.__annotations__['field'])


# Generated at 2022-06-23 16:46:30.719045
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # noinspection PyTypeChecker
    x = SchemaF()  # type: ignore



# Generated at 2022-06-23 16:46:33.899423
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF.load([], many=True) == []
    assert SchemaF.load({}, many=False) == {}

# Generated at 2022-06-23 16:46:44.399636
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        Obj = typing.List[int]

        class SchemaT(SchemaF[Obj]):
            pass

        s = SchemaT()
        s.dumps([4, 5, 6], many=True)

        def f(obj: Obj) -> str:
            return s.dumps(obj)

        def f2(obj: Obj) -> str:
            # Raise error because type is generic!
            return SchemaF.dumps(s, obj)

        def f3(obj: Obj, many: bool) -> str:
            return SchemaF.dumps(s, obj, many)

        def f4(obj: Obj, unknown: str) -> str:
            return SchemaF.dumps(s, obj, unknown=unknown)

       

# Generated at 2022-06-23 16:46:45.244742
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()



# Generated at 2022-06-23 16:46:49.470246
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # Make sure that the constructor of SchemaF raises an exception when it is inherited
    class FooF(SchemaF[int]):
        pass

    try:
        foo = FooF()
        raise Exception()
    except NotImplementedError:
        pass


_SchemaType = typing.TypeVar('_SchemaType', bound='SchemaF')



# Generated at 2022-06-23 16:46:57.366353
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional, List
    @dataclass
    class B:
        one: str
        two: List[int]
        three: Optional[float]
    assert schema(B, None, None) == {'one': fields.Str(), 'two': fields.List(fields.Int()), 'three': fields.Float()}
    assert set(schema(B, None, True).keys()) == {'one', 'two', 'three'}


# Generated at 2022-06-23 16:47:06.725973
# Unit test for function build_type
def test_build_type():
    mixin = type('mixin', (object,), {})
    mm_field = fields.Str()
    cls = type('cls', (object,), {})
    field = type('field', (object,), {'name': 'name'})

    mm_field_type = build_type(str, {}, mixin, field, cls)
    assert isinstance(mm_field_type, fields.Str)

    mm_field_type = build_type(int, {}, mixin, field, cls)
    assert isinstance(mm_field_type, fields.Int)

    mm_field_type = build_type(float, {}, mixin, field, cls)
    assert isinstance(mm_field_type, fields.Float)


# Generated at 2022-06-23 16:47:15.777934
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow as ma
    import typing as tp
    import dataclasses_json
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class MyClass:
        my_datetime: datetime.datetime
    schema_f = dataclasses_json.MarshmallowF()
    str = u'{"my_datetime": "2019-07-14T14:52:35.903011"}'
    my_class = schema_f.loads(str, cls=MyClass)
    assert(isinstance(my_class, MyClass))
    assert(my_class.my_datetime == datetime.datetime(2019, 7, 14, 14, 52, 35, 903011))


# Generated at 2022-06-23 16:47:21.887532
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow
    import dataclasses_json.schema
    import typing

    @dataclasses_json.schema.configure(unknown=dataclasses_json.UNDEFINED)
    @dataclasses.dataclass
    class MyData:
        stuff: typing.List[int]

    schema = dataclasses_json.schema.Schema(MyData)
    assert schema.dumps(MyData(stuff=[1, 2])).strip() == '{"stuff": [1, 2]}'


if sys.version_info < (3, 7):
    SchemaF = Schema



# Generated at 2022-06-23 16:47:23.705933
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    dt = datetime.now()
    iso_field._deserialize(dt.isoformat(), 'attr', {})


# Generated at 2022-06-23 16:47:25.164792
# Unit test for function build_schema
def test_build_schema():
    pass

#####################
# Exceptions
#####################



# Generated at 2022-06-23 16:47:32.935981
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema
    from marshmallow.fields import Integer, String

    class Person:
        def __init__(self, first_name: str, last_name: str):
            self.first_name, self.last_name = first_name, last_name

    class PersonSchema(Schema):
        first_name = fields.Str()
        last_name = fields.Str()

        @post_load
        def make_user(self, data, **kwargs):
            return Person(**data)

    class Address:
        def __init__(self, street: str, city: str):
            self.street, self.city = street, city

    class AddressSchema(Schema):
        street = fields.Str()
        city = fields.Str()


# Generated at 2022-06-23 16:47:42.231000
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class M:
        a : int

    assert schema(M, object, False) == {
        'a': fields.Integer(),
    }

    @dataclass_json
    @dataclass
    class N:
        s : str = 2

    assert schema(N, object, False) == {
        's': fields.String(missing=2),
    }

    @dataclass_json
    @dataclass
    class O:
        s : str = 's'

    assert schema(O, object, False) == {
        's': fields.String(missing='s'),
    }


# Generated at 2022-06-23 16:47:50.630488
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF.loads('[]'), list)
    assert isinstance(SchemaF.loads('{}'), dict)


# Generated at 2022-06-23 16:47:58.374851
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclasses.dataclass
    class DataClass:
        name: str
        age: int

    @dataclasses.dataclass
    class DataClassList(typing.List[DataClass]):
        pass

    data_class = DataClass('foo', 42)
    data_class_list = DataClassList(['foo', 'bar'], [42, 3])

    schema = SchemaF[DataClass]()
    res1 = schema.loads(data_class)
    res2 = schema.loads([data_class, data_class])
    assert isinstance(res1, DataClass)
    assert isinstance(res2, DataClassList)


if sys.version_info >= (3, 8):
    TYPES[typing.Literal] = EnumField

# Generated at 2022-06-23 16:48:07.504848
# Unit test for constructor of class _IsoField
def test__IsoField():
    # 1 _serialize
    test_value = datetime.now()
    test_field = _IsoField()
    serial_value = test_field._serialize(test_value, None, None)
    assert isinstance(serial_value, str)
    assert serial_value == test_value.isoformat()


    # 2 _deserialize
    test_value = "2020-07-16T22:09:40.528617"
    test_field = _IsoField()
    deserial_value = test_field._deserialize(test_value, None, None)
    assert isinstance(deserial_value, datetime)
    assert deserial_value == datetime.fromisoformat(test_value)


# Generated at 2022-06-23 16:48:12.822984
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    obj = [1, 2]
    sf = SchemaF()
    sf.dump(obj)  # type: ignore
    sf.dump(obj, many=False)  # type: ignore
    sf.dump(obj, many=True)  # type: ignore
    sf.dump(obj[0])  # type: ignore
    sf.dump(obj[0], many=False)  # type: ignore
    sf.dump(obj[0], many=True)  # type: ignore

# Generated at 2022-06-23 16:48:23.404186
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from dataclasses_json.schema import schema_factory

    @dataclass
    class C:
        a: int

    SchemaF[C]().dump([C(1)], many=True)
    SchemaF[C]().dump(C(1))

    # testing non-dataclass
    SchemaF[int]().dump([3], many=True)
    SchemaF[int]().dump(3)

    # testing non-dataclass
    class MySchema(Schema):
        a = fields.Int()

    SchemaF[typing.Dict[str, int]](cls_or_schema=MySchema()).dump([{'a': 3}], many=True)
    Schema

# Generated at 2022-06-23 16:48:32.020470
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.mm import Schema, MappingSchema
    from dataclasses import dataclass
    from typing import List, Dict, Tuple
    from marshmallow import fields as mm_fields

    @dataclass
    class A:
        b: Dict[str, float]
        c: float = 5
        d: List[A]

    assert build_type(A, {}, Schema, A.__annotations__['d'], A) == \
        mm_fields.Nested(fields=A.schema().fields, many=True, allow_none=True)
    assert build_type(A, {}, Schema, A.__annotations__['c'], A) == \
        mm_fields.Float(allow_none=False, default=5)

# Generated at 2022-06-23 16:48:41.974013
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from decimal import Decimal

    @dataclass
    class MyDataClass(DataClassJsonMixin):
        value1: str
        value2: int
        value3: bool
        value4: Decimal

    @dataclass
    class MyDataClass2(DataClassJsonMixin):
        value1: str
        value2: int
        value3: bool
        value4: Decimal

    @dataclass
    class DataClassWithList(DataClassJsonMixin):
        value1: List[MyDataClass]
        value2: List[MyDataClass]

    data1 = MyDataClass('test', 1, True, Decimal(1.0))
    data2 = My

# Generated at 2022-06-23 16:48:49.877641
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import List, Optional

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: Optional[str]

    @dataclass_json
    @dataclass
    class B:
        a: List[A]

    assert issubclass(build_schema(cls=A, mixin=None, infer_missing=False, partial=None), Schema)
    assert issubclass(build_schema(cls=B, mixin=None, infer_missing=False, partial=None), Schema)
    assert issubclass(build_schema(cls=A, mixin=None, infer_missing=True, partial=None), Schema)
    assert iss

# Generated at 2022-06-23 16:48:52.199524
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        pass

    class C(dataclasses.dataclass(), Mixin):
        pass

    # TODO test that it works with fields
    assert build_schema(C, Mixin, True, True)



# Generated at 2022-06-23 16:49:02.574651
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert str(_IsoField(required=True)) == 'Field(required=True, default=<marshmallow.missing>, validate=None, load_only=False, dump_only=False, error_messages={}, attribute=None, data_key=None)'
    assert str(_IsoField(required=False)) == 'Field(required=False, default=None, validate=None, load_only=False, dump_only=False, error_messages={}, attribute=None, data_key=None)'
    assert str(_IsoField(default=str)) == 'Field(required=False, default=<class \'str\'>, validate=None, load_only=False, dump_only=False, error_messages={}, attribute=None, data_key=None)'

# Generated at 2022-06-23 16:49:05.672799
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()

_MODULE = sys.modules[__name__]



# Generated at 2022-06-23 16:49:11.205748
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert isinstance(SchemaF, type)
    try:
        SchemaF()
        assert False
    except NotImplementedError:
        pass

    t1 = typing.List[int]
    data = [1, 2, 3]
    sf = SchemaF.from_dataclass(t1)
    assert sf.load(data).tolist() == data



# Generated at 2022-06-23 16:49:15.819541
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    SchemaF[a].dumps(a)
    SchemaF[a].dumps(a, many=True)
    SchemaF[a].dumps(a, many=False)
    SchemaF[a].dumps(a, many=False, *args, **kwargs)
    SchemaF[a].dumps(a, many=False, *args, *kwargs)



# Generated at 2022-06-23 16:49:23.740421
# Unit test for constructor of class SchemaF
def test_SchemaF():

    class TestSchema(SchemaF[str]):
        class Meta:
            strict = True

        foo = fields.Str()
        bar = fields.Str()

        @post_load
        def make_object(self, data, **kwargs):
            return data['foo'] + ' ' + data['bar']

    assert TestSchema().load({'foo': 'foo', 'bar': 'bar'}) == 'foo bar'
    assert TestSchema(strict=False).load({'foo': 'foo'}) == 'foo None'  # type: ignore
    assert TestSchema(strict=False).load({'foo': 'foo', 'bar': 'bar'}) == 'foo bar'



# Generated at 2022-06-23 16:49:36.410822
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema, fields, missing
    from marshmallow.exceptions import ValidationError
    from typing import Optional
    from dataclasses import dataclass
    import datetime
    import uuid

    @dataclass
    class SimpleBadDC:
        pass

    @dataclass
    class BadDC:
        simples: typing.List[SimpleBadDC]

    @dataclass
    class BaseDC:
        name: str
        date: datetime.datetime
        uuid: uuid.UUID
        simples: typing.List[SimpleBadDC]

    @dataclass
    class BadDC2:
        name: str
        date: datetime.datetime
        uuid: uuid.UUID
        simples: Optional[typing.List[SimpleBadDC]]


# Generated at 2022-06-23 16:49:46.955604
# Unit test for function schema
def test_schema():
    from marshmallow import Schema
    from dataclasses import dataclass
    from typing import List, Optional, Union, Mapping, Any

    @dataclass
    class Person:
        name: str
        age: int
        
    @dataclass
    class Remote:
        host: str
        port: int
        
    @dataclass
    class Endpoint:
        ports: List[int]
        url: str
        
    @dataclass
    class A:
        endpoint: Optional[Endpoint]
        remote: Optional[Union[Remote, None]]
        person: Optional[Person]
        

    @dataclass
    class B:
        endpoint: Optional[Endpoint]
        remote: Optional[Remote]
        person: Optional[Person]

    @dataclass
    class C:
        endpoint: Optional

# Generated at 2022-06-23 16:49:59.051010
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # test whether serialization returns datetime.timestamp(dt)
    assert _TimestampField()._serialize(
        datetime.utcfromtimestamp(0),
        None,
        None
    ) == 0

    # test if _serialize with wrong value type raises a ValidationError
    with pytest.raises(ValidationError):
        _TimestampField()._serialize(
            0,
            None,
            None
        )
    # test whether deserialization works as expected for timestamp
    assert _TimestampField()._deserialize(
        0,
        None,
        None
    ) == datetime.utcfromtimestamp(0)

    # test if _deserialize with wrong value type raises a ValidationError
    with pytest.raises(ValidationError):
        _TimestampField()._des

# Generated at 2022-06-23 16:50:00.237756
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert 3 == 3
    pass

# Generated at 2022-06-23 16:50:09.549828
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow as ma
    from typing import Optional, Union
    from dataclasses import dataclass

    @dataclass
    class Mass:
        value: float
        unit: str

    @dataclass
    class Volume:
        value: float
        unit: str

    @dataclass
    class Density:
        value: float
        units: Union[Mass, Volume]

    class DensitySchema(ma.Schema):
        value = ma.fields.Float()
        units = _UnionField(
            {Mass: MassSchema, Volume: VolumeSchema},
            cls=Density, field=dc_fields(Density)[1]
        )

    class MassSchema(ma.Schema):
        value = ma.fields.Float()
        unit = ma.fields.Str()


# Generated at 2022-06-23 16:50:13.186181
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class User:
        id: int = None
        name: str = 'Default Name'

    assert build_schema(User, mixin(), False, False) == build_schema(User, mixin(), False, True)
    assert build_schema(User, mixin(), False, True) == build_schema(User, mixin(), True, True)



# Generated at 2022-06-23 16:50:22.754157
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields, Schema, post_load


    class User:
        def __init__(self, name: typing.Optional[str], id: int) -> None:
            self.name = name
            self.id = id


    class UserSchema(SchemaF[User]):
        name = fields.Str()
        id = fields.Int()

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)


    user = User("Monty", 42)
    schema = UserSchema()
    result = schema.dumps(user)



# Generated at 2022-06-23 16:50:33.405791
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from marshmallow import fields, post_load
    from marshmallow.utils import pydict

    @dataclass
    class Car:
        speed: float = 120
        gps: str = 'WGS84'

    class CarSchema(Schema):
        speed = fields.Float()
        gps = fields.Str()

    @dataclass
    class Car2:
        speed: float = 120
        gps: str = 'WGS84'

    class CarSchema2(Schema):
        speed = fields.Float()
        gps = fields.Str()

    @post_load
    def make_car2(self, kwargs: dict, **kwargs2):
        return Car(**pydict(kwargs, camel_killer_robot=False))


# Generated at 2022-06-23 16:50:40.318761
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF.load

# Generated at 2022-06-23 16:50:45.568175
# Unit test for function build_schema
def test_build_schema():
    """
    This unit test case is used to test the function build_schema
    :return:
    """
    # TODO: make this test more complete
    from dataclasses import dataclass
    schema = build_schema(Person, None, False, False)
    assert schema.Meta.fields == ()


# Generated at 2022-06-23 16:50:56.152044
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    from marshmallow import Schema, fields

    class A(object):
        pass


    class MySchema(SchemaF[A]):
        @property
        def __model__(self):
            return A

    assert MySchema().load({}).__model__ == A
    assert isinstance(MySchema().load({})['foo'], A)

    # Unit test for method loads of class SchemaF
    def test_SchemaF_loads():
        # type: () -> None
        from marshmallow import Schema, fields

        class A(object):
            pass


        class MySchema(SchemaF[A]):
            @property
            def __model__(self):
                return A

        assert MySchema().loads(b'').__model__ == A

# Generated at 2022-06-23 16:51:03.962570
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def assert_load_schema_f(obj: typing.List[A],
                             expected_type: str) -> None:
        schema = SchemaF()
        obj = schema.load(obj, many=True)
        assert isinstance(obj, list)
        assert obj == [obj[0]]
        assert isinstance(obj[0], A)
        assert type(obj[0]).__name__ == expected_type
    assert_load_schema_f([{"a": 1, "b": 2}], 'A')
test_SchemaF_load()


# Generated at 2022-06-23 16:51:05.516589
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF[A]()  # type: ignore



# Generated at 2022-06-23 16:51:16.627480
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None)(int, {}) == fields.Int
    assert build_type(Enum, {}, None, None, None)(
        Enum, {}) == EnumField(by_value=True)
    assert build_type(datetime, {}, None, None, None)(
        datetime, {}) == _TimestampField
    assert build_type(typing.Optional[int], {}, None, None, None)(
        typing.Optional[int], {}).allow_none == True
    assert build_type(typing.Optional[int], {}, None, None, None)(
        typing.Optional[int], {}).required == False

# Generated at 2022-06-23 16:51:21.124419
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union

    @dataclass
    class D:
        id_: Union["D", int]
        name: str = "default"

    schema = Schema.from_dataclass(D)

    def test(obj):
        assert schema.loads(schema.dumps(obj)) == obj

    test(D(D(1)))


# Generated at 2022-06-23 16:51:30.103476
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    foo_schema = FooSchema()
    foo_schema.dump([Foo(), Foo()])
    foo_schema.dump(Foo())
    foo_schema.loads(b'[{"bar": 1}]')
    foo_schema.loads(b'{"bar": 1}')


if sys.version_info >= (3, 6):
    class _DictField(fields.Dict):
        def _serialize(self, value, *args, **kwargs):
            if value is None:
                return None

            if not _is_collection(value):
                raise ValidationError(
                    "Must be a dict-like type")


# Generated at 2022-06-23 16:51:36.491487
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Nested:
        uuid: str
        @property
        def text(self) -> str:
            return 'Test'

    @dataclass_json
    @dataclass
    class Person:
        id_: int = field(metadata={"data_key": "id"})
        uuid: str
        name: str
        score: float = 20.0
        optional: Optional[float]
        integer_list: List[int] = field(default_factory=list)
        float_list: List[float] = field(default_factory=list)
        nested: Nested = field(default_factory=Nested)
        dict_: dict = field(default_factory=dict)

# Generated at 2022-06-23 16:51:40.021926
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
    except NotImplementedError:
        pass


StrictSchemaF = SchemaF



# Generated at 2022-06-23 16:51:47.763119
# Unit test for function build_schema
def test_build_schema():
    class MyModel:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    MyModelSchema: typing.Type[SchemaType] = build_schema(
        MyModel, mixin=None, infer_missing=False, partial=False)
    assert SchemaType.__supertype__ == MyModelSchema.__supertype__



# Generated at 2022-06-23 16:52:01.334118
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    import typing
    import pytest


# Generated at 2022-06-23 16:52:03.099936
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert True is True



# Generated at 2022-06-23 16:52:05.190252
# Unit test for function build_schema
def test_build_schema():
    # TODO Implement unit test for function build_schema
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 16:52:14.996163
# Unit test for constructor of class SchemaF
def test_SchemaF():
    d = SchemaF[str]()
    assert False  # should not get here because of exception in constructor

# if sys.version_info >= (3, 7):
#     class SchemaF(Schema, typing.Generic[A]):
#         """Lift Schema into a type constructor"""
#
#         def __init__(self, *args, **kwargs):
#             # super().__init__(*args, **kwargs)
#             raise NotImplementedError()
#
#         def dump(self, obj: A, many: bool = None) -> TEncoded:
#             pass
#
#         def dumps(self, obj: A, many: bool = None, *args, **kwargs) -> str:
#             pass
#
#         def load(self, data: TEncoded, many: bool =

# Generated at 2022-06-23 16:52:19.106883
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class A:
        a: int

    assert {'a': 123} == SchemaF[A].dump(A(a=123))

    assert [{'a': 123}, {'a': 456}] == SchemaF[A].dump([A(a=123), A(a=456)], many=True)



# Generated at 2022-06-23 16:52:29.829909
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    fld = _TimestampField()
    fld._validated = True

    # Test serialize
    assert fld._serialize(123) is 123
    assert fld._serialize(None) is None
    fld.required = True
    with pytest.raises(ValidationError):
        fld._serialize(None)

    # Test deserialize
    assert fld._deserialize(123) == datetime.fromtimestamp(123)
    assert fld._deserialize(None) is None
    fld.required = True
    with pytest.raises(ValidationError):
        fld._deserialize(None)



# Generated at 2022-06-23 16:52:39.675371
# Unit test for function schema
def test_schema():
    import unittest
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class A:
        a0: str = "a0"
        a1: int = 1
        a2: List[int] = [1, 2, 3]

    class B(A):
        b0: str = "b0"

    class C(A):
        def __init__(self):
            self.a0 = "c0"
            self.a1 = 2
            self.a2 = [4, 5, 6]

        def __eq__(self, other):
            if self.a0 != other.a0:
                return False
            if self.a1 != other.a1:
                return False
            if self.a2 != other.a2:
                return False
           

# Generated at 2022-06-23 16:52:46.999731
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    a = SchemaF.loads('["test"]')
    b = SchemaF.loads('{}')
    assert len(a) == 1
    assert len(b.keys()) == 0
    assert SchemaF.loads('{}', many=False) == {}  # type: ignore
    assert SchemaF.loads('[{}]', many=False) == [{}]  # type: ignore



# Generated at 2022-06-23 16:52:55.940588
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: Optional[int]

    global test

    test = build_schema(Test, Mixin, True, False)
    t = test()
    assert isinstance(t.declared_fields.get("a"), fields.Str)
    assert isinstance(t.declared_fields.get("b"), fields.Int)


# Generated at 2022-06-23 16:52:58.348046
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    obj = [SchemaF[int].load([1,2,3])]


# Generated at 2022-06-23 16:53:03.581123
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        val: int = 1

    @dataclass
    class B(DataClassJsonMixin):
        val: str = 's'

    @dataclass
    class C(DataClassJsonMixin):
        val: typing.Union[int, A, B] = 1

    # TODO: create appropriate test case.
    # The test is not finished, because the _UnionField class was not used
    # in the serialization of dataclasses.
    # The _UnionField class is used if you manually create a Schema.
    # But the Schema is created in the dataclasses_json itself.


# Generated at 2022-06-23 16:53:12.334146
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def test_func():
        from dataclasses import dataclass
        from dataclasses_json import dataclass_json

        @dataclass_json
        @dataclass
        class DataClass:
            i: int

        res = SchemaF[DataClass].dump([DataClass(i=3)])
        assert isinstance(res, list)
        res = SchemaF[DataClass].dump(DataClass(i=3))
        assert isinstance(res, dict)
        assert res['i'] == 3



# Generated at 2022-06-23 16:53:20.075368
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses.dataclass
    class T1:
        a: int

    @dataclasses.dataclass
    class T2:
        t1s: typing.List[T1]

    t2 = T2([T1(1), T1(2)])
    data = SchemaF[T2]().dumps(t2)
    data = SchemaF[T2]().loads(data)
    assert data.t1s[0].a == 1


# Generated at 2022-06-23 16:53:21.592644
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsf = _TimestampField()
    assert isinstance(tsf, _TimestampField)



# Generated at 2022-06-23 16:53:23.923883
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    f = SchemaF[int]()
    f.loads('[1, 2, 3]')


# Generated at 2022-06-23 16:53:26.658241
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass
    class Test:
        x: int
        y: float

    schema = SchemaF[Test]

    assert isinstance(schema, Schema)



# Generated at 2022-06-23 16:53:28.597958
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        pass

    # typecheck
    foo = Foo[int]()  # type: ignore


# Generated at 2022-06-23 16:53:35.976708
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import typing
    import marshmallow as mm
    class MyClass(typing.NamedTuple):
        x: int
        y: float
    s = mm.Schema.from_dict({'x': mm.fields.Int(), 'y': mm.fields.Float()})
    assert SchemaF[MyClass]().load({'x': '10', 'y': '10.5'}) == MyClass(10, 10.5)  # type: ignore



# Generated at 2022-06-23 16:53:43.893320
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    str_schema = SchemaF[str]()
    list_str_schema = SchemaF[List[str]]()
    list_list_str_schema = SchemaF[List[List[str]]]()
    assert list_str_schema.load(['a']) == ['a']
    assert list_str_schema.loads('["a"]') == ['a']
    assert list_str_schema.loads(b'["a"]') == ['a']
    assert list_list_str_schema.load([['a']]) == [['a']]
    assert list_str_schema.load(['a', 'b']) == ['a', 'b']
    assert list_str_schema.loads('["a", "b"]') == ['a', 'b']
    assert list_str

# Generated at 2022-06-23 16:53:55.841921
# Unit test for function build_type
def test_build_type():
    from marshmallow_enum import EnumField
    from marshmallow import fields
    from datetime import datetime
    from typing import Union, List, Dict, Optional, TypeVar, Any
    import datetime as dt

    assert build_type(Optional[Dict[int, str]], {}, object, object, object).__class__ == fields.Dict
    assert build_type(float, {}, object, object, object).__class__ == fields.Float
    assert build_type(Union[str, datetime], {}, object, object, object).__class__ == _UnionField
    assert build_type(datetime, {}, object, object, object).__class__ == _TimestampField
    assert build_type(Optional[datetime], {}, object, object, object).__class__ == _TimestampField

# Generated at 2022-06-23 16:54:06.967275
# Unit test for function build_type
def test_build_type():
    assert build_type(str,{},None,None,None)(str,{}) == fields.Str()
    assert build_type(bool,{},None,None,None)(bool,{}) == fields.Bool()
    assert build_type(int,{},None,None,None)(int,{}) == fields.Int()
    assert build_type(float,{},None,None,None)(float,{}) == fields.Float()
    assert build_type(tuple,{},None,None,None)(tuple,{}) == fields.Tuple()
    assert build_type(list,{},None,None,None)(list,{}) == fields.List()
    assert build_type(dict,{},None,None,None)(dict,{}) == fields.Dict()

# Generated at 2022-06-23 16:54:13.065764
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():

    json_data: JsonData
    many: bool
    partial: bool
    unknown: str
    kwargs: typing.Dict[str, typing.Any]

    def f(schema: SchemaF[A], obj: A) -> typing.Any:
        return schema.loads(json_data=json_data, many=many, partial=partial, unknown=unknown, **kwargs)



# Generated at 2022-06-23 16:54:21.127606
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    @dataclasses.dataclass
    class Bar:
        i: int
        t: typing.Tuple[str, float]

    foo = Foo()
    bar = Bar(1, ('2', 3.0))

    assert SchemaF[Foo]().load(foo) == foo
    assert SchemaF[Bar]().load(bar) == bar


if sys.version_info >= (3, 7):
    class SchemaOptF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise Not

# Generated at 2022-06-23 16:54:31.944781
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow.schema
    import marshmallow.fields
    import typing
    import mypy_extensions
    import sys
    import uuid
    import datetime
    import json

    class User(mypy_extensions.TypedDict):
        id: uuid.UUID
        email: str
        created_at: datetime.datetime

    class UserSchema(SchemaF[User]):
        id = marshmallow.fields.UUID(data_key='my_id')
        email = marshmallow.fields.Str()
        created_at = marshmallow.fields.DateTime()

    schema = UserSchema()

# Generated at 2022-06-23 16:54:37.596899
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        item: str

    DataClassSchema = build_schema(TestClass, None, False, False)
    schema = DataClassSchema()
    data = {'item': 'one'}
    result = schema.load(data)
    assert result == TestClass('one')



# Generated at 2022-06-23 16:54:42.432995
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tf = _TimestampField()

    assert tf._serialize(datetime.now(), "name", None)
    assert not tf._serialize(None, "name", None)
    assert tf._serialize(None, "name", None, required=True)

    assert tf._deserialize(datetime.now().timestamp(), "name", None)
    assert not tf._deserialize(None, "name", None)
    assert tf._deserialize(None, "name", None, required=True)



# Generated at 2022-06-23 16:54:51.748919
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2018, 2, 3, 13, 30, 30, 123456)) == '2018-02-03T13:30:30.123456'
    assert _IsoField()._deserialize(datetime(2018, 2, 3, 13, 30, 30, 123456)) == datetime(2018, 2, 3, 13, 30, 30, 123456)
    return True

# ----------------
# Custom Marshmallow fields
# See https://github.com/marshmallow-code/marshmallow/issues/723


# Generated at 2022-06-23 16:54:59.754926
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now()) is not None
    assert _TimestampField()._serialize(None) is None
    assert _TimestampField()._deserialize(datetime.now().timestamp()) is not None
    assert _TimestampField()._deserialize(None) is None
    # assert _TimestampField()._deserialize("") is None
    # assert _TimestampField()._deserialize("") is None

