

# Generated at 2022-06-23 16:45:06.164607
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class A(typing.Generic[B]):
        def __init__(self, data: B):
            self.data = data
    class C(SchemaF[A[B]]):
        pass
    # because of mypy/issues/2572 we need to define the variable with the concrete type
    c: C = C()
    a1: A[B] = c.load({'data': 'hello'})
    a2: A[B] = c.load([{'data': 'hello'}, {'data': 'world'}])  # type: ignore
    a3: typing.List[A[B]] = c.load([{'data': 'hello'}, {'data': 'world'}], many=True)  # type: ignore
    assert a1.data == 'hello'

# Generated at 2022-06-23 16:45:15.379220
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    @dataclass
    class Example(object):
        id: int
    try:
        import pytest
    except (ModuleNotFoundError, ImportError):
        raise ModuleNotFoundError('Module pytest not found')
    from marshmallow import fields, Schema

    @dataclass
    class Sample(object):
        id: int

    sample_schema = build_type(Sample, {}, None, Sample.__dataclass_fields__['id'], Sample)
    assert isinstance(sample_schema, fields.Field)

    union_schema = build_type(typing.Union[Sample, Example], {}, None, Sample.__dataclass_fields__['id'], Sample)
    assert isinstance(union_schema, _UnionField)


# Generated at 2022-06-23 16:45:16.548161
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert False
    # TODO write this unit test


# Generated at 2022-06-23 16:45:17.032333
# Unit test for constructor of class _UnionField
def test__UnionField():
    ...


# Generated at 2022-06-23 16:45:19.710658
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class _Schema(SchemaF[int]):
        pass
    _Schema.loads([10, 2], many=True)



# Generated at 2022-06-23 16:45:20.226490
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert True


# Generated at 2022-06-23 16:45:27.898234
# Unit test for function schema
def test_schema():
    import inspect
    import unittest
    import marshmallow as mm

    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        x: typing.List[str]
        y: str

    class TestSchema(unittest.TestCase):
        def test(self):
            s = schema(A, mm.Schema, False)
            self.assertDictEqual({'x': mm.fields.List(mm.fields.Str()), 'y': mm.fields.Str()}, s)

    TestSchema.test()



# Generated at 2022-06-23 16:45:35.486766
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def nest(n):
        if n == 0:
            return []
        else:
            return [nest(n - 1)]

    @dataclass
    class SchemaF_dump_A:
        a: int

    @dataclass
    class SchemaF_dump_B:
        a: typing.List[SchemaF_dump_A]

    # test with many=False
    data = SchemaF_dump_A(a=1)
    schema = SchemaF_dump_A.Schema()

    dumped = schema.dump(data)
    assert data.a == dumped['a']
    assert not isinstance(dumped, list)

    # test with many=True
    data = [SchemaF_dump_A(a=2)]
    schema = SchemaF_dump_A.Schema()

# Generated at 2022-06-23 16:45:37.294314
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert False

_F = typing.TypeVar('_F', bound=SchemaF)



# Generated at 2022-06-23 16:45:47.502343
# Unit test for function schema
def test_schema():
    from dataclasses_json.core import _is_generic_type
    from dataclasses import asdict
    from dataclasses_json import dataclass_json
    from pytest import raises

    @dataclass_json
    class Inner:
        a: str

    @dataclass_json
    class X:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.List[str]
        f: typing.Dict[str, int]
        g: typing.Dict[str, int] = {}
        j: typing.Union[str, Inner]

    @dataclass_json
    class XX:
        a: typing.Optional[str]
        b: typing.Optional[int]
        c: typing.Type

# Generated at 2022-06-23 16:45:48.184663
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass

# Generated at 2022-06-23 16:45:53.852009
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Test(typing.Generic[A]):
        def test(self, obj: TOneOrMultiEncoded,
                 many: bool = None, partial: bool = None,
                 unknown: str = None) -> TOneOrMulti:
            pass

    u = Test()
    u.test([1, 2, 3])
    u.test(['a', 'b', 'c'])



# Generated at 2022-06-23 16:45:57.957490
# Unit test for constructor of class _IsoField
def test__IsoField():
    time_field = _IsoField()
    test_data = '2019-01-02T12:30:00'
    assert(test_data == time_field._serialize(datetime.fromisoformat(test_data), None, None))


# Generated at 2022-06-23 16:46:06.708398
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class TestSchema(SchemaF[str]):
        t = fields.String()

        @post_load
        def make_str(self, data, **kwargs):
            return data['t']

    schema = TestSchema()

    assert schema.load({"t": "x"}) == "x"
    assert schema.loads('{"t": "x"}') == "x"



# Generated at 2022-06-23 16:46:12.256420
# Unit test for constructor of class _IsoField
def test__IsoField():
    print('haha')
    a=datetime.now()
    print(a)
    b=_IsoField(required=False)._serialize(a,'attr',{})
    print(b)
    c=_IsoField(required=False)._deserialize(b,'attr','data')
    print(c)
    print('hehe')

    

# Generated at 2022-06-23 16:46:12.795398
# Unit test for function build_type
def test_build_type():
    assert True == True

# Generated at 2022-06-23 16:46:19.403348
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from datetime import datetime
    tsf = _TimestampField()
    # serialization
    assert tsf._serialize(datetime.fromtimestamp(1), "attr", "obj", extra_arg=42) == 1
    assert tsf._serialize(None, "attr", "obj", extra_arg=42) is None
    try:
        tsf._serialize(None, "attr", "obj", extra_arg=42, required=True)
        assert False, "Should have failed"
    except ValidationError:
        pass
    # deserialization
    assert tsf._deserialize(1, "attr", "data", extra_arg=42) == datetime.fromtimestamp(1)
    assert tsf._deserialize(None, "attr", "data", extra_arg=42) is None

# Generated at 2022-06-23 16:46:29.214065
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class C(typing.NamedTuple):
        a: int
        b: str

    s = SchemaF.from_dataclass(_ExtendedEncoder(None))  # type: ignore
    assert s.__class__ == SchemaF  # type: ignore
    assert s.load([{'a': 1}]) == [C(1, None)]  # type: ignore
    assert s.load({'a': 1}) == C(1, None)  # type: ignore
    # test method load of type parameter A
    assert s.load([{'a': 1}], many=False) == [C(1, None)]  # type: ignore
    assert s.load([{'a': 1}], many=True) == [C(1, None)]  # type: ignore

# Generated at 2022-06-23 16:46:30.908806
# Unit test for constructor of class _IsoField
def test__IsoField():
    val = _IsoField()
    val._serialize('val', 'attr', 'obj')


# Generated at 2022-06-23 16:46:32.647148
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__str__() == "Unknown"



# Generated at 2022-06-23 16:46:41.431015
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_input_date = '2020-06-06T10:00:00'
    test_date = datetime.fromisoformat(test_input_date)
    test_field = _IsoField()
    # check serialization
    serialized_date = test_field._serialize(test_date, 'test_attr', None, **{})
    assert serialized_date == test_input_date
    # check deserialization
    deserialized_date = test_field._deserialize(test_input_date, 'test_attr', None, **{})
    assert deserialized_date == test_date


# Generated at 2022-06-23 16:46:50.659444
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    from dataclasses_json import dataclass_json, config

    @dataclass_json
    @dataclass
    class Test:
        test: str
        test2: typing.Union[str, int]
        test3: typing.Union[str, Test]
        test4: typing.Union[str, typing.List[int]]
        test5: typing.Optional[str]
        test6: typing.Optional[typing.Union[typing.List[int], str]]
        test7: typing.Optional[typing.Union[typing.List[int], str, None]]

    schema_ = schema(Test, config.Config, False)

# Generated at 2022-06-23 16:47:02.134068
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A) -> None:
            self.a = a
    def foo_loader(data):
        return Foo(str(data))
    from marshmallow import EXCLUDE  # type: ignore
    class FooSchema(SchemaF[Foo[str]]):
        class Meta:
            unknown = EXCLUDE
        a = fields.Function(deserialize=foo_loader)
    data: TEncoded = {'a': 'bar'}
    deserialized = FooSchema().load(data=data)
    assert deserialized.a == 'bar'
    assert isinstance(deserialized, Foo)
    assert isinstance(deserialized.a, str)



# Generated at 2022-06-23 16:47:04.533834
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()

## Unit test for _IsoField's method _serialize

# Generated at 2022-06-23 16:47:14.103536
# Unit test for constructor of class _UnionField
def test__UnionField():
    @dataclasses.dataclass
    class ClassTest:
        value: typing.Union[int, str, typing.List[int]]

    cls_type = typing.TypeVar('cls_type', ClassTest, str)
    field = typing.TypeVar('field', dataclasses.Field, fields.Field)

    def _type(type_: type) -> type:
        return type_

    test_class = ClassTest(1)

# Generated at 2022-06-23 16:47:24.527090
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow as mm
    from dataclasses_json.schema import SchemaF
    from typing import List

    @dataclass
    class Person:
        name: str

    class PersonSchema(SchemaF[Person]):
        name = mm.fields.Str()

    @dataclass
    class Person2:
        name: str

    class PersonSchema2(SchemaF[Person2]):
        name = mm.fields.Str()

    assert PersonSchema().load({'name': 'Foo'}) == Person(name='Foo')
    assert PersonSchema().load([{'name': 'Foo'}, {'name': 'Bar'}]) == [Person(name='Foo'), Person(name='Bar')]
    assert PersonSchema2().load({'name': 'Foo'}) == Person2

# Generated at 2022-06-23 16:47:25.368485
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None



# Generated at 2022-06-23 16:47:26.369460
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()



# Generated at 2022-06-23 16:47:27.267731
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField() is not None



# Generated at 2022-06-23 16:47:31.078210
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now())
    assert field._deserialize('2020-01-01')


# Generated at 2022-06-23 16:47:32.663389
# Unit test for constructor of class _IsoField
def test__IsoField():
    field_obj = _IsoField()
    assert field_obj is not None



# Generated at 2022-06-23 16:47:38.080530
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Foo:
        foo: str
        bar: int
        baz: typing.List[float]

    class FooSchema(SchemaF[Foo]):
        foo = fields.Str()
        bar = fields.Integer()
        baz = fields.List(fields.Float())

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    foo = Foo('123', 456, [1.0, 2.0, 3.0])
    schema = FooSchema()
    rv = schema.dumps(foo)
    assert rv == '{"bar": 456, "baz": [1.0, 2.0, 3.0], "foo": "123"}'



# Generated at 2022-06-23 16:47:44.822369
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def takes_list(x: typing.List[str]):
        pass

    def takes_str(x: str):
        pass

    takes_list(SchemaF.loads(str, "{}", many=True))
    takes_str(SchemaF.loads(str, "{}"))
    takes_str(SchemaF.loads(str, "{}", many=False))


NO_DEFAULT = object()



# Generated at 2022-06-23 16:47:47.280745
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, None, None, None)(str, {}) == fields.Str()



# Generated at 2022-06-23 16:47:51.286798
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    @dataclass
    class Test:
        name: str

    assert schema(Test, int, True) == {'name': fields.Str(data_key='name', default=None, allow_none=True)}
    assert schema(Test, int, False) == {'name': fields.Str(data_key='name', allow_none=False)}



# Generated at 2022-06-23 16:47:55.182991
# Unit test for constructor of class _UnionField
def test__UnionField():
    uf = _UnionField(None, None, None, default=None, missing=None, allow_none=True,
                     error_messages=None)
    assert uf.default == None
    assert uf.missing == None
    assert uf.allow_none == True
    assert uf.error_messages == None


# Generated at 2022-06-23 16:48:06.254683
# Unit test for function schema
def test_schema():
    from typing import Optional
    from marshmallow import Schema, fields, post_load

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    class PersonSchema(Schema):
        name = fields.Str()
        age = fields.Integer()

        @post_load
        def make_person(self, data):
            return Person(**data)

    s = PersonSchema()  # Our MappingSchema

    class X:
        def __init__(self, y: Optional[Person]):
            self.y = y

    class XSchema(SchemaType):
        y = fields.Nested(PersonSchema, allow_none=True)

    s = PersonSchema()  # Our MappingSchema


# Generated at 2022-06-23 16:48:12.942171
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: str
        b: str

    @dataclass
    class Test2:
        a: str
        b: int

    @dataclass
    class Test3:
        a: str
        b: typing.Optional[str]

    @dataclass
    class Test4:
        a: str
        b: typing.Union[str, int]

    @dataclass
    class Test5:
        a: str
        b: typing.Dict[str, int]

    class Mixin:
        pass

    class Mixin2:
        pass

    TestSchema = build_schema(Test, Mixin, False, False)
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema

# Generated at 2022-06-23 16:48:22.834774
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF()
    s.dump([1, 2, 3])
    s.dump(1)
    s.dump([1, 2, 3], many=True)
    s.dump([1, 2, 3], many=False)
    s.dump(1, many=True)
    s.dump(1, many=False)
    s.dump(1, many=False, another_arg=1)
    # test for issue #78
    s.dump([1, 2, 3], another_arg=1)
    # test for issue #79
    m = typing.MutableMapping[str, str]
    s.dump(m())
    s.dump(m(), many=True)


# Generated at 2022-06-23 16:48:25.818875
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso = _IsoField()
    v = iso._serialize(None, None, None)
    assert v == None
    v = iso._deserialize(None, None, None)
    assert v == None



# Generated at 2022-06-23 16:48:34.759202
# Unit test for function build_type
def test_build_type():
    import typing
    import marshmallow.fields as mf
    import dataclasses
    import marshmallow_enum
    from enum import Enum

    @dataclasses.dataclass
    class Nested(metaclass=dataclasses.dataclass):
        a: int

    class Meta(Enum):
        a = 1
        b = 2

    @dataclasses.dataclass
    class Test:
        a: Nested
        b: typing.Optional[int]
        c: typing.List[int]
        d: typing.Union[str, Nested]
        e: Meta

        @dataclasses.dataclass_json
        class Schema(SchemaType):
            a: mf.Nested = build_type(Nested, {}, None, Test.a, Test)

# Generated at 2022-06-23 16:48:45.570133
# Unit test for function build_type
def test_build_type():
    class X:
        def test(self):
            return 'x'

    class Y:
        pass

    class Z:
        pass

    class Mixin:
        pass

    @dataclass_json(mm_field=build_type)
    @dataclass
    class A:
        x: X
        y: Y
        z: Z
        m: Mixin

    @dataclass_json(mm_field=build_type)
    @dataclass
    class B(Mixin):
        pass

    assert isinstance(A.schema().declared_fields['x'], fields.Nested)
    assert isinstance(A.schema().declared_fields['y'], fields.Field)
    assert isinstance(A.schema().declared_fields['z'], fields.Field)

# Generated at 2022-06-23 16:48:57.234199
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema = SchemaF.from_dataclasses(
        User.dataclass_schema(unknown=UNKNOWN))
    # type: typing.List[User]
    users = [User(name='Jack', age=42, email='jack@black.com'),
             User(name='Jill', age=35, email='jill@hill.com')]
    assert schema.dump(users) == [
        {'age': 42, 'email': 'jack@black.com', 'name': 'Jack'},
        {'age': 35, 'email': 'jill@hill.com', 'name': 'Jill'}]
    # type: typing.List[User]

# Generated at 2022-06-23 16:49:00.890432
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(required = False)._serialize(datetime.now())
    try:
        _TimestampField(required = True)._serialize(None)
        assert False
    except:
        assert True


# Generated at 2022-06-23 16:49:04.960381
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class S(SchemaF[int]):
        pass
    S().dumps(1)
    S().dumps([1, 2])


# Generated at 2022-06-23 16:49:14.850788
# Unit test for constructor of class _UnionField
def test__UnionField():
    # Test for __init__
    from typing import Union
    from marshmallow import Schema
    from dataclasses import dataclass
    from dataclasses_json.core import _DC_GENERIC_HANDLERS
    @dataclass
    class A:
        pass
    @dataclass
    class B:
        pass
    @dataclass
    class C(Schema):
        a: A
    @dataclass
    class D:
        a: Union[A, B, C]

# Generated at 2022-06-23 16:49:24.009486
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass

    @dataclass
    class MyData0:
        field0: str

    class TestSchemaF(SchemaF):  # type: ignore
        field0 = fields.Str()

        @post_load
        def make_object(self, data, **kwargs):
            return MyData0(**data)

    schema = TestSchemaF()
    instance = MyData0('test')
    encoded = schema.dump(instance)
    assert encoded == {'field0': 'test'}
    assert schema.load(encoded) == instance

    schema = TestSchemaF(many=True)
    encoded_many = schema.dump([instance, instance, instance])

# Generated at 2022-06-23 16:49:24.620728
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert True


# Generated at 2022-06-23 16:49:25.791965
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField is not None



# Generated at 2022-06-23 16:49:28.289433
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class C:
        pass
    SchemaF[C].dump([], many=True)
    SchemaF[C].dump([], many=False)

# Generated at 2022-06-23 16:49:40.084960
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, 0, None, None)(str, {}) == fields.Str()
    assert build_type(int, {}, 0, None, None)(int, {}) == fields.Int()
    assert build_type(float, {}, 0, None, None)(float, {}) == fields.Float()
    assert build_type(bool, {}, 0, None, None)(bool, {}) == fields.Bool()
    assert build_type(datetime, {}, 0, None, None)(datetime, {}) == \
           _TimestampField()
    assert build_type(UUID, {}, 0, None, None)(UUID, {}) == fields.UUID()
    assert build_type(Decimal, {}, 0, None, None)(Decimal, {}) == fields.Decimal()
    assert build_

# Generated at 2022-06-23 16:49:51.102071
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json(letter_case=LetterCase.PASCAL)
    @dataclass
    class A:
        i: int

    @dataclass_json
    @dataclass
    class B:
        i: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str)))
        b: A

    @dataclass_json
    @dataclass
    class C:
        i: typing.Optional[int]
        b: typing.Optional[B]

    assert isinstance(build_schema(A, {'dataclass_json'}, False, False).fields[
                          'i'], fields.Int)

# Generated at 2022-06-23 16:49:55.571499
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class X:
        x: int

    s = SchemaF[X](X)

    assert s.loads('{"x": 1}') == X(1)
    assert s.dumps([X(1), X(2)]) == '[{"x": 1}, {"x": 2}]'


# Generated at 2022-06-23 16:50:06.619849
# Unit test for function schema
def test_schema():
    class C(SchemaType[C]):
        a: typing.List[typing.List[typing.Optional[typing.Type[typing.Any]]]]
        b: typing.Dict
        c: typing.Mapping
        d: typing.Callable
        e: typing.Any
        f: typing.Union[datetime, int]
        g: str
        h: int
        i: float
        j: bool
        k: datetime
        l: UUID
        m: Decimal
        n: typing.Optional[CatchAllVar]
        o: typing.List[typing.Optional[CatchAllVar]]
        p: typing.Optional[CatchAllVar]

    print(C.schema())

# Generated at 2022-06-23 16:50:12.021541
# Unit test for function build_schema
def test_build_schema():
    from dataclasses_json.api import load
    from marshmallow.fields import Nested
    from marshmallow.schema import Schema
    from dataclasses import dataclass

    @dataclass
    class Inner:
        a: int
        b: str

    @dataclass
    class Data:
        x: int
        y: Inner

    @dataclass
    class Data2:
        x: int
        y: Inner

    DataClassSchema1: typing.Type[Schema] = build_schema(
        Data, dataclass_json.DataClassJsonMixin, True, True)

    DataClassSchema2: typing.Type[Schema] = build_schema(
        Data2, dataclass_json.DataClassJsonMixin, True, True)


# Generated at 2022-06-23 16:50:22.726967
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    from marshmallow_enum import EnumField
    from typing import Optional, TypeVar
    from marshmallow import fields
    from marshmallow.fields import Raw, Dict
    from marshmallow.fields import List, Tuple, Function
    from marshmallow.fields import UUID, Decimal
    from marshmallow.fields import Str, Int, Float, Bool, Mapping
    from dataclasses_json.utils import CatchAllVar
    from marshmallow.exceptions import ValidationError
    from marshmallow.validate import OneOf
    from datetime import datetime, timedelta
    from dataclasses_json.utils import _timestamp_to_dt_aware
    from marshmallow.fields import Field
    from marshmallow import validate
    from marshmallow_enum import EnumField

# Generated at 2022-06-23 16:50:31.894758
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str = "test"

    schema_f = SchemaF[A]
    res = schema_f.dumps(A(a=1))
    assert res == '{"a": 1, "b": "test"}'  # type: ignore
    res = schema_f.dumps([A(a=1), A(a=2, b="test2")])
    assert res == '[{"a": 1, "b": "test"}, {"a": 2, "b": "test2"}]'  # type: ignore


# Generated at 2022-06-23 16:50:40.954260
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    from marshmallow.schema import Schema
    from marshmallow import fields

    class TestSchema(Schema):
        test_field = fields.Field()

    schema = TestSchema()
    data, errors = schema.load({"test_field": "2019-11-20T23:20:43.123456"})
    assert errors == {}
    assert data['test_field'] == "2019-11-20T23:20:43.123456"


# Generated at 2022-06-23 16:50:51.191224
# Unit test for function schema
def test_schema():
    from typing import Dict, List, Optional, Union
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import fields as mm_fields

    @config(mm_field_decoders={
        List[str]: mm_fields.String,
    })
    class Base(DataClassJsonMixin):
        opt_str: Optional[str]
        opt_str_default_factory: Optional[str] = None
        opt_str_metadata: Optional[str]
        opt_str_default_factory_metadata: Optional[str] = None
        opt_str_metadata_decoder: Optional[List[str]]
        opt_str_default_factory_metadata_decoder: Optional[List[str]] = None


# Generated at 2022-06-23 16:50:57.579003
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def f(mapping: typing.MutableMapping[int, str]):
        pass
    v = f.__annotations__['mapping']
    assert is_union_type(v)
    schema = SchemaF.from_typing(v)  # type: ignore
    r = schema.dump({})
    assert isinstance(r, dict)


# Generated at 2022-06-23 16:51:01.370680
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Test that the load method of SchemaF is valid (mypy)
    return SchemaF.load(obj=None, data=None, many=None, partial=None)



# Generated at 2022-06-23 16:51:14.383764
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class A:
        pass

    @dataclasses.dataclass
    class B:
        a: str


    class BSchema(SchemaF[B]):
        a = fields.Str()

    o = [B('foo'), B('bar')]
    d = BSchema().dump(o, many=True)
    assert d == [{'a': 'foo'}, {'a': 'bar'}]

    d = BSchema().dump(B('foo'), many=False)
    assert d == {'a': 'foo'}

    a = BSchema().load(d)
    assert a.a == 'foo'

    a = BSchema().load([d, d])
    assert a[0].a == 'foo'

# Generated at 2022-06-23 16:51:15.930374
# Unit test for constructor of class SchemaF
def test_SchemaF():
    pass


# noinspection PyTypeChecker

# Generated at 2022-06-23 16:51:20.790066
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class A:
        a: str
    s = SchemaF[A]()
    res = s.load({'a': 'b'})
    assert res.a == 'b'



# Generated at 2022-06-23 16:51:30.038591
# Unit test for function schema
def test_schema():
    pass
    # @dataclass
    # class MyClass:
    #     x: int
    #
    # MyClass.schema()
    #
    # @dataclass
    # class MyClass:
    #     x: List[int]
    #
    # MyClass.schema()
    #
    # @dataclass
    # class MyClass:
    #     x: List
    #
    # MyClass.schema()
    #
    # @dataclass
    # class MyClass:
    #     x: List[List[int]]
    #
    # MyClass.schema()
    #
    # @dataclass
    # class MyClass:
    #     x: List[List]
    #
    # MyClass.schema()
    #
    # @datac

# Generated at 2022-06-23 16:51:38.068759
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses.dataclass
    class C:
        a: int
        b: str

    class F(SchemaF[C]):
        @post_load
        def make_obj(self, data, **kwargs):
            return data

    def f(c: C) -> None:
        # type: ignore
        F().dump([c])
        F().dump(c)

    # Unit test for method loads of class SchemaF
    def test_SchemaF_loads():
        # type: () -> None
        F().load([{}])
        F().load({})



# Generated at 2022-06-23 16:51:47.325334
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class A(object):
        pass

    class SchemaFTest(SchemaF[A]):
        pass

    obj = A()
    y = SchemaFTest.dumps(obj, many=False)
    assert isinstance(y, str)
    y = SchemaFTest.dumps(obj, many=True)
    assert isinstance(y, str)
    y = SchemaFTest.dumps([obj, obj], many=False)
    assert isinstance(y, str)
    # test that the error message is not stupid
    try:
        y = SchemaFTest.dumps(obj, many=None)
        assert False
    except TypeError as e:
        assert "Missing 1 required positional argument" not in str(e)



# Generated at 2022-06-23 16:51:51.681945
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    assert is_union_type(Union[int, str])
    assert not is_union_type(int)


# Generated at 2022-06-23 16:52:03.487458
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union, Optional
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    @dataclass
    class A:
        name: Union[int, str, "B"]

    @dataclass
    class B:
        num: int

    @dataclass
    class C:
        name: Union[int, Optional[A]]

    _UnionField(
        {int: fields.Integer(), str: fields.Str(), A: A.schema(), B: B.schema()},
        A, A.__annotations__['name']
    )

# Generated at 2022-06-23 16:52:07.652055
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union, List
    from marshmallow import Schema

    class Test1(Schema): pass
    class Test2(Schema): pass

    m = _UnionField(
        desc={int: Test1, float: Test2},
        cls=Union[int, float],
        field=None)
    assert m is not None


# Generated at 2022-06-23 16:52:11.730022
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass
    class B:
        a: int

    class C(SchemaF[B]):
        pass

    C.loads('[{"a": 3}, {"a": 4}]', many=True)



# Generated at 2022-06-23 16:52:19.203749
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # pylint: disable=unused-argument
    @dataclasses.dataclass
    class D:
        a: int = 1

    class MySchema(SchemaF[D]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            class A:
                pass
            self.a = A()

    if sys.version_info >= (3, 7):
        # pylint: disable=not-callable
        assert (isinstance(MySchema(unknown='exclude'), MySchema))
    else:
        with pytest.raises(TypeError):
            MySchema(unknown='exclude')



# Generated at 2022-06-23 16:52:30.757017
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, x:A) -> None:
            self.x = x

    class FooSchema(SchemaF[A]):
        x = fields.Field()

    y = Foo[TEncoded](TEncoded({'a': 1}))
    y_dict = {'x': {'a': 1}}

    assert FooSchema().load(y_dict) == y
    # Need to ensure that a list of encoded types is also handled
    assert FooSchema().load([y_dict]) == [y]
    assert FooSchema().loads(json.dumps(y_dict)) == y
    assert FooSchema().loads(json.dumps([y_dict])) == [y]



# Generated at 2022-06-23 16:52:32.984233
# Unit test for function build_schema
def test_build_schema():
    class ms1(metaclass=DataclassJSON):
        a: int = 2

    assert isinstance(build_schema(ms1, _Base, False, False), type)
test_build_schema()



# Generated at 2022-06-23 16:52:35.068638
# Unit test for function schema

# Generated at 2022-06-23 16:52:43.656404
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: float
        c: typing.List[int]
        d: A

    class ASchema(Schema):
        a = fields.Int()

    class BSchema(Schema):
        b = fields.Float()
        c = fields.List(fields.Int())
        d = fields.Nested(ASchema)

    b = B(0.5, [1, 2, 3], A(1))
    bs = BSchema()
    encoded = bs.dump(b)
    assert encoded == {'b': 0.5, 'c': [1, 2, 3], 'd': {'a': 1}}

    encoded = bs.dumps(b)

# Generated at 2022-06-23 16:52:47.334195
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField(required=True)
    assert field._serialize(datetime.now(), 'attr', None)
    assert field._deserialize(1517470872.0, 'attr', None) is not None

    field = _TimestampField(required=False)
    assert field._serialize(None, 'attr', None) is None
    assert field._deserialize(None, 'attr', None) is None



# Generated at 2022-06-23 16:52:59.585061
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class X:
        x: int

    schema = build_schema(X, None, False, False)
    assert schema.Meta.fields == ('x',)
    assert schema().make_x({}) == X(x=int())
    class X_Schema(Schema):
        class Meta:
            fields = ('x',)

        def make_x(self, kvs, **kwargs):
            from dataclasses import dataclass
            from datetime import datetime
            payload = kvs
            return X(x=payload.get("x")
                     )

    assert schema().dump(X(x=1)) == X_Schema().dump(X(x=1))



# Generated at 2022-06-23 16:53:02.204524
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert True # FIXME: implement your test here



# Generated at 2022-06-23 16:53:07.821267
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcfromtimestamp(1_000_000),
                                        None, None) == 1_000_000

    assert _TimestampField()._deserialize(1_000_000, None, None) == datetime(1970, 1, 12, 11, 46, 40)



# Generated at 2022-06-23 16:53:09.586965
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().__name__ == "_IsoField"


# Generated at 2022-06-23 16:53:13.640674
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field

    @dataclass
    class X(object):
        type: str
        name: str = field(metadata={"dataclasses_json": {}})

    assert build_schema(X, None, True, False)


# Generated at 2022-06-23 16:53:23.580444
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field

    @dataclass
    class Dummy:
        a: int
        b: str = field(metadata={'dataclasses_json':{'mm_field': fields.Str()}})
        c: typing.Optional[str] = None

    assert schema(Dummy, object, True) == {
        'b': fields.Str()
    }

    @dataclass
    class Dummy:
        a: str
        b: typing.Optional[str] = None
        c: typing.Optional[int] = None

    res = schema(Dummy, object, True)
    assert isinstance(res['b'], fields.Str)
    assert isinstance(res['c'], fields.Int)
    assert 'missing' in res['c'].__dict__

# Generated at 2022-06-23 16:53:29.038953
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List

    class ExampleSchema(SchemaF[int]):
        pass

    assert ExampleSchema.dump([1, 2, 3], many=True) == [1, 2, 3]
    assert ExampleSchema.dump([1, 2, 3], many=False) == [1, 2, 3]
    assert ExampleSchema.dump(1, many=False) == 1
    assert ExampleSchema.dump(1, many=True) == 1


# Generated at 2022-06-23 16:53:35.044352
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[int]):
        pass

    schema = TestSchema()
    assert schema.dump([1,2,3], many=True) == [1,2,3]
    assert schema.dumps([1,2,3], many=True) == '[1, 2, 3]'
    assert schema.dump(1, many=False) == 1
    assert schema.dumps(1, many=False) == '1'
    assert schema.dump([], many=True) == []
    assert schema.dumps([], many=True) == '[]'
    assert schema.dump(None, many=False) is None
    assert schema.dumps(None, many=False) == 'null'


# Generated at 2022-06-23 16:53:43.446879
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    from marshmallow import post_load
    from typing import List, Optional

    from dataclasses_json.schema import SchemaF

    class UserSchema(SchemaF[User]):
        id = fields.Int()
        name = fields.Str()
        # we need to define optional field as instance of Schema
        # without passing additional arguments
        optional_data = fields.Nested(Schema)

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)

    @dataclass
    class User:
        id: int
        name: str
        optional_data: Optional[dict]  # type: ignore



# Generated at 2022-06-23 16:53:54.492725
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import TypedDict, List, Dict
    @dataclass
    class Team:
        name: str
        player: List[str]
        ranking: Dict[str, float]
    team = Team('test', ['Paul', 'Harry', 'George'], {'test': 1})
    _schema = build_schema(Team, mixin=TypedDict, infer_missing=False, partial=False)
    schema = _schema()
    result = schema.dump(team)
    assert result['name'] == 'test'
    assert result['player'] == ['Paul', 'Harry', 'George']
    assert result['ranking'] == {'test': 1}

# Generated at 2022-06-23 16:54:03.113059
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), 'attr', 'obj', **{'load_context':{'k':'v'}})
    assert _TimestampField(missing=None)._serialize(None, 'attr', 'obj', **{'load_context':{'k':'v'}}) == None
    assert _TimestampField(missing=None)._deserialize(None, 'attr', 'data', **{'load_context':{'k':'v'}}) == None
    assert _TimestampField(missing=None, required=False)._deserialize(None, 'attr', 'data', **{'load_context':{'k':'v'}}) == None

# Generated at 2022-06-23 16:54:15.326698
# Unit test for function build_schema
def test_build_schema():
    class A:
        x: int = 0
        y: str = "test"
        z: typing.Optional[int] = None

    m = build_schema(A, cls=A, mixin=A, infer_missing=False, partial=False)
    assert m.Meta.fields == ("x", "y", "z")
    assert not m.Meta.partial
    assert m.dump({}) == {"x": 0, "y": "test", "z": None}
    #assert str(m.dump({})) == "{'x': 0, 'y': 'test', 'z': None}"# this doesn't work on python 3.5
    assert m.load({"x": 1, "y": ""}) == A(1, "")

# Generated at 2022-06-23 16:54:26.785164
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import typing
    import marshmallow_dataclass as md
    import marshmallow_dataclass.conf as md_conf
    # Define decode dataclass
    @dataclasses.dataclass
    class A:
        a: int = 10
        b: str = "10"
        c: typing.List[int] = dataclasses.field(default_factory=list)
    # Define the schema for decode dataclass
    @md.dataclass
    class ASchema:
        a: md.Int(allow_none=True)
        b: md.Str(allow_none=True)
        c: md.List(md.Int(allow_none=True), allow_none=True)
    # Define class B

# Generated at 2022-06-23 16:54:38.769111
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF()
    schema.dumps({'a': 1})
    schema.dumps([{'a': 1}])
    schema.dumps(None)

SchemaF = typing.GenericMeta(str('_SchemaF'), (SchemaF,), {})


# Generated at 2022-06-23 16:54:46.704002
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class O:
        a: str
        b: typing.Optional[int]

    sc = schema(O, SchemaType, False)
    assert len(sc) == 2
    from marshmallow.fields import Str
    from marshmallow.fields import Int

    assert isinstance(sc['a'], Str)
    assert isinstance(sc['b'], Int)



# Generated at 2022-06-23 16:54:55.912508
# Unit test for function build_type
def test_build_type():
    from typing import Mapping, Union, List
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    dataclass, dataclass_json = _handle_undefined_parameters_safe(
        dataclass, dataclass_json)
    @dataclass
    class A:
        pass
    @dataclass
    class B:
        pass
    @dataclass
    class C:
        pass
    @dataclass
    class TestClass:
        a: List[Union[A, B, None]]
        b: Mapping[C, A]
    @dataclass
    class TestClass2:
        a: Union[int, str]
        b: Union[A, B]

# Generated at 2022-06-23 16:55:07.386427
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields

    class C:
        pass

    class C1(C):
        pass

    class C2(C):
        pass

    class S(SchemaF[C]):
        pass

    @S.schema_cls.register(C1)
    class _S1(S.schema_cls):
        pass

    @S.schema_cls.register(C2)
    class _S2(S.schema_cls):
        pass

    field = fields.Field()

    @field.serializer
    def serialize_c1(value, attr, obj):
        res = {'__type': C1.__name__}
        res.update(value)
        return res

    class _S1(Schema):
        field = field
