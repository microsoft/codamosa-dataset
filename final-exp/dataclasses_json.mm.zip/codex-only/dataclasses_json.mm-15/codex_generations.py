

# Generated at 2022-06-23 16:45:09.450065
# Unit test for constructor of class _UnionField
def test__UnionField():
    d = {'a': 'b'}
    cls = type('X', (), {})
    field = type('Y', (), {})()
    field.name = 'name'
    desc = {
        int: 1,
        str: 2
    }
    a = _UnionField(desc, cls, field, allow_none=False, required=False)
    assert a._deserialize(d, None, None) == d
    assert a._serialize(d, None, None) == d
    assert a._deserialize('a', None, None) == 'a'
    assert a._serialize('a', None, None) == 'a'
    assert a._deserialize(1, None, None) == 1
    assert a._serialize(1, None, None) == 1



# Generated at 2022-06-23 16:45:14.380591
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SimpleSchema(SchemaF):
        dynamo_id = fields.Integer()
        name = fields.String()

    dump_result = SimpleSchema().dumps(
        {'dynamo_id': 123, 'name': 'John Doe'},
        many=False)

    assert dump_result == '{"dynamo_id": 123, "name": "John Doe"}'

# Generated at 2022-06-23 16:45:15.378436
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass



# Generated at 2022-06-23 16:45:21.627986
# Unit test for function build_schema
def test_build_schema():
    import unittest
    from dataclasses import dataclass, field

    @dataclass
    class Test(object):
        a: int = 10
        b: int = 10

    @dataclass
    class Test2(object):
        a: str = 'a'
        b: str = 'b'

    assert build_schema(Test, None, False, False) is not build_schema(
        Test2, None, False, False)
    assert build_schema(Test, None, False, False) is not build_schema(
        Test, None, True, False)
    assert build_schema(Test, None, False, False) is build_schema(
        Test, None, False, True)


# Generated at 2022-06-23 16:45:25.765704
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(
        desc={int: fields.Integer()}, cls=None, field=None,
        default=None, attribute=None, load_only=False, dump_only=False, required=False,
        allow_none=False, missing=MISSING, error_messages=None)


# Generated at 2022-06-23 16:45:38.556850
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from dataclasses_json.__main__ import test_dataclass
    from dataclasses import dataclass

    @dataclass
    class Data:
        x: List[str]

    d = Data(['thing'])
    t = SchemaF(strict=True)
    a: str = t.dumps(d)
    assert a == "{'x': ['thing']}"

    # It should not be possible to instantiate the class
    try:
        s = SchemaF()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:45:43.299490
# Unit test for constructor of class _IsoField
def test__IsoField():
    dt = datetime.now()
    field = _IsoField()
    assert field._serialize(dt, "", "") == dt.isoformat()
    assert field._deserialize(dt.isoformat(), "", "") == dt


# Generated at 2022-06-23 16:45:45.526903
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        pass

    with pytest.raises(NotImplementedError):
        SchemaF()


# Generated at 2022-06-23 16:45:52.237163
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    def foo(bar: int) -> int:
        pass

    inst_ = SchemaF.loads(b'{"bar": 1, "baz": 2}', many=True)
    if False:
        inst_.bar  # type: int
    else:
        foo(inst_[0].bar)  # type: ignore


# Generated at 2022-06-23 16:45:58.478964
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    SchemaF(fields=[]).dumps(1, many=False)
    SchemaF(fields=[]).dumps(1, many=True)
    SchemaF(fields=[]).dumps([1], many=True)
    SchemaF(fields=[]).dumps([1], many=False)



# Generated at 2022-06-23 16:46:10.513504
# Unit test for constructor of class _UnionField
def test__UnionField():
    Field = typing.NewType('Field', int)
    class S(Schema):
        x = _UnionField(
            typing.Union[float, str, dict, Field, int],
            'test', 'test',
            fields.Integer(), missing=0
        )

    s = S()
    assert s.load({'x': 1}) == {'x': 1}
    assert s.load({'x': '1'}) == {'x': '1'}
    assert s.load({'x': {'x': 1}}) == {'x': {'x': 1}}
    assert s.load({'x': Field(1)}) == {'x': Field(1)}
    assert s.load({'x': None}) == {'x': 0}

# Generated at 2022-06-23 16:46:13.764668
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF[str]):
        def __init__(self):
            pass

    s = S()
    assert s.loads('"1"') == '1'



# Generated at 2022-06-23 16:46:14.431277
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-23 16:46:18.174606
# Unit test for function build_type
def test_build_type():
    assert _issubclass_safe(type(build_type(type(None),
                                            {},
                                            int,
                                            dataclasses.Field(...),
                                            type(None))),
                            type(lambda: None))


# Generated at 2022-06-23 16:46:25.422178
# Unit test for constructor of class _UnionField
def test__UnionField():
    type_list = typing.List[str]
    type_str = str
    type_tuple = typing.Tuple[str]
    desc = {
        type_list: fields.String,
        type_str: fields.String,
        type_tuple: fields.String,
    }
    field = _UnionField(desc, 'TestDc', 'test_field')
    assert field.desc == desc
    assert field.cls == 'TestDc'
    assert field.field == 'test_field'



# Generated at 2022-06-23 16:46:35.947009
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class A:
        pass

    class B:
        pass

    schema = SchemaF[A]()
    data = schema.dump(B())
    schema.load(data)

test_SchemaF()

if sys.version_info >= (3, 7):

    class SchemaF_(SchemaF):
        """
        This class is needed to make typing.Union work in combination with mm.
        It is a workaround for mm, which does not have a way to specialize Generic Schema for
        a specific return type.
        So we use a decorator, dataclasses_json.Schema, which will specialize this class.
        """

        def __init__(self, *args, **kwargs):
            raise NotImplementedError()



# Generated at 2022-06-23 16:46:41.431036
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None)

# Generated at 2022-06-23 16:46:50.657949
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, asdict, field
    from dataclasses import dataclass, field as standard_field
    from dataclasses_json.config import config
    from marshmallow import Schema, fields
    from marshmallow import pre_dump, post_dump, pre_load, post_load, validate
    from marshmallow import pre_dump, post_dump, pre_load, post_load
    from marshmallow import validate, validates, validates_schema
    from marshmallow import EXCLUDE
    from marshmallow.exceptions import ValidationError, UnmarshallingError
    from marshmallow.utils import is_collection
    from collections.abc import Mapping
    from typing import Optional, Union

    class CustomEnum(Enum):
        one = "one"
        two = "two"
        three = "three"

# Generated at 2022-06-23 16:46:51.936551
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()


# Generated at 2022-06-23 16:46:53.854794
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List, {}, None, "name", "cls") == fields.List



# Generated at 2022-06-23 16:47:04.896067
# Unit test for function schema
def test_schema():
    import dataclasses

    from dataclasses_json.mm_schema import build_type, schema

    from marshmallow import Schema, fields

    @dataclasses.dataclass
    class Inner:
        foo: str
        bar: int

    @dataclasses.dataclass
    class Obj:
        a: str
        b: int = 3
        c: typing.List[Inner] = dataclasses.field(default_factory=list)
        d: typing.Optional[typing.List[Inner]] = None
        e: typing.Optional[typing.Optional[str]] = None
        f: typing.Optional[typing.List[typing.Optional[int]]] = None

    class InnerSchema(Schema):
        foo = fields.String()
        bar = fields.Integer()


# Generated at 2022-06-23 16:47:08.426848
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF.__new__(SchemaF) # type: SchemaF[A]
    s.dump([0]) # type: List[A]
    s.dump(None) # type: A



# Generated at 2022-06-23 16:47:09.418665
# Unit test for constructor of class _UnionField
def test__UnionField():
    f = _UnionField(None, None, None, required=False, allow_none=True)
    assert f.required is False
    assert f.allow_none is True


# Generated at 2022-06-23 16:47:18.057884
# Unit test for constructor of class _IsoField

# Generated at 2022-06-23 16:47:19.893292
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField() is not None



# Generated at 2022-06-23 16:47:30.666650
# Unit test for constructor of class _UnionField
def test__UnionField():
    class U(Enum):
        A = 1
        B = 2

    @dataclass
    class A:
        b: str

    @dataclass
    class B:
        b: str

    @dataclass
    class DC:
        a: Union[A, B, int, str, U]

    s = DCSchema()
    u = U.A
    a = A('some text')
    b = B('some text')
    dc = DC(u)
    assert s.dump(dc) == {'a': {'__type': 'A'}}
    assert s.dump(DC(a)) == {'a': {'__type': 'A', 'b': 'some text'}}

# Generated at 2022-06-23 16:47:33.523445
# Unit test for function schema
def test_schema():
    class Mixin:
        pass

    fake_field = dc_fields(Mixin)[0]
    assert schema(Mixin, Mixin, infer_missing=True) == {}

# Generated at 2022-06-23 16:47:39.028403
# Unit test for function schema
def test_schema():
    import marshmallow
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class foo:
        first_name: str
        last_name: str = 'gaga'
        age: int = 23
        a: bool = True
        b: Optional[int] = 12
        c: typing.Optional[bool] = None
        d: typing.Optional[int] = None
        e: typing.Optional[CatchAllVar] = None
        f: typing.Optional[CatchAllVar] = None
    

# Generated at 2022-06-23 16:47:48.618654
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def test():
        from marshmallow import Schema, fields


        class S1(SchemaF[int]):
            a: int


        class S2(SchemaF[int]):
            a: int


        s = S1()
        assert 3 == s.loads(b'{"a": 3}')
        assert [3] == s.loads(b'[{"a": 3}]')
        assert [3] == s.loads(b'[{"a": 3}]', many=True)
        assert [3] == s.loads(b'[{"a": 3}]', many=False)
        assert 3 == s.loads(b'{"a": 3}', many=False)
        assert 3 == s.loads(b'{"a": 3}', many=True)

# Generated at 2022-06-23 16:47:54.372755
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass

    @dataclass
    class Inner:
        a: int
        b: int

    @dataclass
    class NewInner:
        c: str
        d: str

    @dataclass
    class Dc:
        field: Union[int, float, Inner, NewInner]

    dc_field = dc_fields(Dc)[0]
    uf = _UnionField({int: fields.Int(), float: fields.Float(), Inner: fields.Nested(Inner),
                      NewInner: fields.Nested(NewInner)}, Dc, dc_field)

# Generated at 2022-06-23 16:48:00.115503
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Example(typing.Generic[A]): pass
    class Db: pass
    class Db2: pass
    schema = SchemaF[Example]()  # type: ignore
    schema.dumps([Db(), Db2()])
    schema.dumps(Db())
    schema.dumps(None)


# Generated at 2022-06-23 16:48:03.529840
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Person(SchemaF[Person]):
        name = fields.String()
        age = fields.Integer()

    Person().loads(b'{"name": "John Doe", "age": 42}')

    # Unit test for method dump of class SchemaF

# Generated at 2022-06-23 16:48:06.540043
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None



# Generated at 2022-06-23 16:48:09.970385
# Unit test for function schema
def test_schema():

    @dataclass
    class Person:
        name: str
        age: int

    schema = schema(Person, Person, False)
    assert 'age' in schema
    assert 'name' in schema

test_schema()



# Generated at 2022-06-23 16:48:20.824600
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields as mmf, EXCLUDE
    @dataclasses.dataclass
    class Point:
        x: int
        y: int

    @dataclasses.dataclass
    class Line:
        p1: Point
        p2: Point

    class LineSchema(Schema, typing.Generic[Line]):
        class Meta:
            unknown = EXCLUDE

        p1 = mmf.Nested(PointSchema)
        p2 = mmf.Nested(PointSchema)

        @post_load
        def make_line(self, data, **kwargs):
            return Line(**data)

    class PointSchema(Schema, typing.Generic[Point]):
        x = mmf.Float()
        y = mmf.Float()

# Generated at 2022-06-23 16:48:28.268225
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow.exceptions import ValidationError
    from marshmallow.schema import Schema

    class UserSchema(Schema):
        name = fields.Str()
        email = fields.Email()

    user_data = {'name': 'Monty', 'email': 'monty@python.org'}
    schema = UserSchema()  # type: ignore
    result = schema.load(user_data)
    assert result.data == user_data

    try:
        schema.load({'email': 'bad_email_address'})
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-23 16:48:31.135534
# Unit test for function build_schema
def test_build_schema():
    # type: () -> None
    import pytest

    # TODO check the not implemented function
    with pytest.raises(NotImplementedError):
        SchemaF[int]()



# Generated at 2022-06-23 16:48:43.206823
# Unit test for function build_type
def test_build_type():
    assert 'marshmallow_enum.EnumField' in str(build_type(typing.List[int], {}, None, None, int))
    assert 'dataclasses_json.Schema' in str(build_type(typing.List[int], {}, dataclasses_json.Schema, None, int))
    assert 'marshmallow.fields.Field' in str(
        build_type(typing.List[typing.List], {}, dataclasses_json.Schema, None, int))
    assert 'marshmallow.fields.Field' in str(build_type(typing.List, {}, dataclasses_json.Schema, None, int))
    assert 'dataclasses_json.Schema' in str(build_type(str, {}, dataclasses_json.Schema, None, int))

# Generated at 2022-06-23 16:48:44.442904
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()


# Generated at 2022-06-23 16:48:51.955904
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import json

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    class PersonSchema(SchemaF[Person]):
        name: str = fields.Str()
        age: int = fields.Int()

    person_schema: PersonSchema = PersonSchema()
    schema_output: TEncoded[Person] = person_schema.dump(Person('Foo', 42))
    assert schema_output == {'name': 'Foo', 'age': 42}
    json_output: bytes = person_schema.dumps(Person('Foo', 42))
    assert json.loads(json_output) == {'name': 'Foo', 'age': 42}

# Generated at 2022-06-23 16:49:02.400323
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    @dataclass
    class A:
        pass
    @dataclass
    class B:
        pass
    class C(Enum):
        A = A()
        B = B()

    test_field = _UnionField(
        desc={object: Schema(), str: fields.Str()},
        cls=None,
        field=None,
        allow_none=True,
    )
    assert test_field._serialize(None, None, None) is None
    assert test_field._serialize({}, None, None) == {}
    assert test_field._serialize('', None, None) == ''
    assert test_field._deserialize(None, None, None) is None
    assert test_field._deserialize({}, None, None) == {}

# Generated at 2022-06-23 16:49:12.352050
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from marshmallow_union import Union

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        field: Union[A, B]

    class DummySchema(Schema):
        field = _UnionField(
            desc={A: {}},
            cls=C,
            field=dc_fields(C)[0],
            missing=MISSING,
            allow_none=True,
        )

    assert isinstance(DummySchema.declared_fields["field"], _UnionField) and True


# Generated at 2022-06-23 16:49:21.499594
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize('2020-09-01T10:00:00', 'attr', {}) == datetime(2020, 9, 1, 10)
    assert field._deserialize('2020-09-01', 'attr', {}) == datetime(2020, 9, 1, 0)
    assert field._deserialize('2020-09-01T', 'attr', {}) == datetime(2020, 9, 1, 0)

    with pytest.raises(ValidationError):
        field._deserialize('2020-09-01T10:69', 'attr', {})



# Generated at 2022-06-23 16:49:28.158352
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: A

    @dataclass
    class C:
        c: B

    s = SchemaF.of(C)()
    c = C.from_json('{"c": {"b": {"a": 1}}}')

    assert c == s.load(s.dump(c))
    assert [c] == s.load(s.dump([c]))



# Generated at 2022-06-23 16:49:33.850129
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        name: str
        age: int
        description: str = 'Hello'

    assert isinstance(build_schema(A, None, None, None), type)



# Generated at 2022-06-23 16:49:45.682924
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    T = typing.TypeVar('T')
    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    @dataclasses.dataclass()
    class PersonDataClass:
        name: str
        age: int

    def _test(obj: T) -> None:
        name: str
        age: int
        if isinstance(obj, PersonDataClass):
            name = obj.name
            age = obj.age
        elif isinstance(obj, Person):
            name = obj.name
            age = obj.age
        else:
            raise RuntimeError

        class PersonSchema(SchemaF[T]):
            name = fields.Str()
            age = fields.Int()

        schema = PersonSchema()

        # method dumps problem use Type

# Generated at 2022-06-23 16:49:47.775318
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
        raise Exception("Should never get here")
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:49:59.619526
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import marshmallow as ma
    tt = _TimestampField(missing=None)  # does not raise
    tt = _TimestampField(missing=0)  # does not raise
    tt = _TimestampField(missing='')  # does not raise
    tt = _TimestampField(missing=())  # does not raise
    tt = _TimestampField(missing={})  # does not raise
    tt = _TimestampField(missing=[])  # does not raise
    tt = _TimestampField(missing=ma.missing)  # does not raise
    tt = _TimestampField(missing=MISSING)  # does not raise

    with pytest.raises(TypeError):
        tt = _TimestampField(missing=0.0)

# Generated at 2022-06-23 16:50:09.538732
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    if sys.version_info < (3, 7):
        return

    from marshmallow import Schema, fields, pre_load

    class Car(typing.NamedTuple):
        name: str
        price: int

    class Option(typing.NamedTuple):
        color: str
        cost: int

    class CarSchema(Schema):
        name = fields.String(required=True)
        price = fields.Integer(required=True)
        options = fields.Nested(
            lambda: OptionSchema, required=True, many=True)

        @pre_load
        def pre_load(self, data, many, partial):
            if many:
                return [item for item in data]
            else:
                return data


# Generated at 2022-06-23 16:50:20.037619
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class ADataClass:
        a_field: str
    schema = SchemaF[ADataClass]()
    assert schema.dump(ADataClass("data")) == {'a_field': 'data'}
    assert schema.dump([ADataClass("data1"), ADataClass("data2")]) == [{'a_field': 'data1'}, {'a_field': 'data2'}]
    assert schema.dump(ADataClass("data"), many=False) == {'a_field': 'data'}
    assert schema.dump([ADataClass("data1"), ADataClass("data2")], many=False) == [{'a_field': 'data1'}, {'a_field': 'data2'}]


# Generated at 2022-06-23 16:50:32.387815
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class B:
        pass

    @dataclass
    class Foo:
        x: typing.Union[A, B]

    class ASchema(Schema):
        class Meta:
            strict = True
            unknown = Raise
            ordered = False

        a_field = fields.Int(load_only=True)

    class BSchema(Schema):
        class Meta:
            strict = True
            unknown = Raise
            ordered = False

        b_field = fields.Int(load_only=True)

    foo = Foo(x=A())
    a = ASchema()
    b = BSchema()
    union = _UnionField({A: a, B: b}, Foo, dc_fields(Foo)[0])

# Generated at 2022-06-23 16:50:34.311362
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    class Foo(SchemaF):
        pass



# Generated at 2022-06-23 16:50:38.326204
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[str]):
        pass

    MySchema().dump(['a', 'b'])
    MySchema().dump('a')



# Generated at 2022-06-23 16:50:48.527296
# Unit test for function build_type
def test_build_type():
    class C: pass
    class D(C): pass
    class E(C): pass
    field = dc_fields(D)[0]
    options = {'required': False}
    mm_field = build_type(type(None), options, C, field, D)
    assert isinstance(mm_field, fields.Field)
    assert options['required'] == False

    options['required'] = True
    mm_field = build_type(D, options, C, field, D)
    assert isinstance(mm_field, fields.Nested)
    assert options['required'] == True

    mm_field = build_type(typing.Optional[E], options, C, field, D)
    assert isinstance(mm_field, fields.Nested)
    assert options['required'] == False


# Generated at 2022-06-23 16:51:00.592013
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import asdict
    from dataclasses_json import dataclass_json
    from typing import Union, Optional, List

    @dataclass_json
    @dataclass
    class Foo1:
        value: int

    @dataclass_json
    @dataclass
    class Foo2:
        value: Optional[int]

    @dataclass_json
    @dataclass
    class Foo3:
        value: float

    @dataclass_json
    @dataclass
    class Foo4:
        value: str

    @dataclass_json
    @dataclass
    class Foo5:
        value: List[int]

    @dataclass_json
    @dataclass
    class Foo6:
        value: Optional[List[int]]


# Generated at 2022-06-23 16:51:13.876070
# Unit test for function schema
def test_schema():
    class TestSchemaMixin(SchemaType):
        timestamp = fields.Integer(data_key="time", allow_none=True)

    @dataclass_json(mm_field=fields.Integer(allow_none=True), letter_case=camel_case, infer_missing=False)
    class Test(TestSchemaMixin):
        test: typing.Optional[int]
        age: int = field(default=1)
        child: typing.Union[int, str, typing.Optional[float]] = field(default=0.5, metadata={'dataclasses_json':
            {'letter_case': snake_case, 'mm_field': fields.Float(required=False, allow_none=True)}})

# Generated at 2022-06-23 16:51:22.410407
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    # This is a test to check that mypy recognizes the overloads of load and loads
    # correctly. If it proves to be impossible to check this with mypy, then this
    # test should be removed.
    from typing import List, Mapping, Any, TypeVar
    from marshmallow import fields
    A = TypeVar('A')
    class MySchema(SchemaF[A]):
        pass
    MySchema().loads('[{}]')
    MySchema().loads({})
    MySchema().loads(b'[{}]')
    # MySchema().loads(b'\x80') # Bytes with only one byte (b'\x80') can not be
    # decoded to str
    # MySchema().loads('\x80') # And this is also not possible



# Generated at 2022-06-23 16:51:24.508820
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().deserialize(None) is None
    assert _TimestampField().deserialize(0) == datetime.fromtimestamp(0)
    assert _TimestampField().deserialize(1000) == datetime.fromtimestamp(1000)


# Generated at 2022-06-23 16:51:24.992378
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass

# Generated at 2022-06-23 16:51:30.323988
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class Person2:
        name: str

    s = SchemaF[Person2]()  # type: ignore
    assert isinstance(s, type)
    assert s.__name__ == 'SchemaF'
    assert s.__qualname__ == 'SchemaF'
    assert not issubclass(s, Schema)
    assert not issubclass(s, typing.Generic)
    assert not issubclass(s, typing.GenericMeta)
    assert not issubclass(s, typing.Mapping)

    class Person2Schema(s):
        class Meta:
            dataclass = Person2
            unknown = EXCLUDE

        name = fields.Str()

    p = Person2('John')
    assert Person2Schema().dump(p)

# Generated at 2022-06-23 16:51:37.719511
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = _TimestampField()
    assert ts.get_value(None, None, datetime(2019,2,2,0,0,0)) == 1551411200.0
    assert ts.get_value(None, None, None) is None

    ts = _TimestampField()
    assert ts.deserialize(1551411200.0) == datetime(2019,2,2,0,0,0)
    assert ts.deserialize(None) is None


# Generated at 2022-06-23 16:51:50.869281
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    _: str
    _: typing.List[str]
    _: typing.Dict[str, str]
    _: typing.List[typing.Dict[str, str]]

    assert isinstance(SchemaF[str].loads('1'), str)
    assert isinstance(SchemaF[str].loads('1', many=False), str)
    assert isinstance(SchemaF[str].loads('[1]'), typing.List[str])
    assert isinstance(SchemaF[str].loads('[1]', many=False), str)

    assert isinstance(SchemaF[typing.List[str]].loads('[1]'), typing.List[str])
    assert isinstance(SchemaF[typing.List[str]].loads('[1]', many=False), typing.List[str])
   

# Generated at 2022-06-23 16:51:52.769145
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert(_TimestampField() is not None)


# Generated at 2022-06-23 16:52:00.001282
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field._serialize(datetime(2019, 12, 31, 23, 59, 59),
                                None, None) == '2019-12-31T23:59:59'
    assert iso_field._deserialize('2019-12-31T23:59:59', None, None) == \
        datetime(2019, 12, 31, 23, 59, 59)



# Generated at 2022-06-23 16:52:09.251347
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.config import Config
    from typing import List
    from datetime import datetime
    from marshmallow import post_load
    from marshmallow import EXCLUDE

    @dataclass
    class Foo:
        x: int

    c = Config()

    @dataclass
    class Bar:
        foo: List[Foo] = c.field(default_factory=lambda: [Foo(0), Foo(1)])

    schema = SchemaF[Bar]()

    assert schema.dump(Bar()) == {'foo': [{'x': 0}, {'x': 1}]}

    def test_SchemaF_loads():
        from dataclasses import dataclass
        from marshmallow import fields
        from typing import List

# Generated at 2022-06-23 16:52:17.301746
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses_json.api import dump, load, Config
    from dataclasses import dataclass

    @dataclass
    class User:
        id: int
        name: str

    @dataclass
    class Message:
        text: str
        user: Union[User, str]

    config = Config()

    msg_schema = config.schema_class(Message, unknown=MISSING)

    assert msg_schema.fields['user'].__class__.__name__ == '_UnionField'

    msg_data = {
        "text": "Hello!",
        "user": {
            "__type": "User",
            "id": 1,
            "name": "Name 1"
        }
    }

    msg = load(msg_data, Message)

    #

# Generated at 2022-06-23 16:52:24.748656
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    _json_data = '{"name": "Test"}'
    _schemaF_obj = SchemaF.loads(_json_data, cls=UserSchema)
    _schemaF_obj_dump = _schemaF_obj.dump()
    assert _schemaF_obj_dump.get('name') == 'Test'


# Generated at 2022-06-23 16:52:28.712291
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SchemaExample(SchemaF[str]):
        pass

    assert SchemaExample().dumps('a') == '"a"'
    assert SchemaExample().dumps(['a', 'b']) == '["a", "b"]'



# Generated at 2022-06-23 16:52:33.647113
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        pass

    with pytest.raises(NotImplementedError):
        SchemaF()
    with pytest.raises(NotImplementedError):
        SchemaF[Foo]()



# Generated at 2022-06-23 16:52:40.341006
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow.fields import Field
    from typing import Union
    from dataclasses import dataclass

    class A(Union):
        def __init__(self, cls, field):
            pass

    class B(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class C:
        def __init__(self, a, b):
            pass

    assert _UnionField(a=A(C, 'b'), b=B(), c=C('a', 'b')) is not None


# Generated at 2022-06-23 16:52:41.358126
# Unit test for function schema
def test_schema():
    assert(schema())

# Generated at 2022-06-23 16:52:51.178385
# Unit test for function build_schema
def test_build_schema():

    class MySchema(Schema):
        __doc__ = build_schema(MyClass, Schema, True, False).__doc__
        Meta = build_schema(MyClass, Schema, True, False).Meta
        make_myclass = build_schema(MyClass, Schema, True, False).make_myclass
        dumps = build_schema(MyClass, Schema, True, False).dumps

        def dump(self, obj, *, many=None):
            return build_schema(MyClass, Schema, True, False).dump(self, obj, many)

        a = build_schema(MyClass, Schema, True, False).a

        b = build_schema(MyClass, Schema, True, False).b


# Generated at 2022-06-23 16:52:58.227102
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data_list = [
        {"a": 1, "b": 2},
        {"a": 3, "b": 4},
        {"a": 5, "b": 6}
    ]
    data_dict = {"a": 1, "b": 2}
    schema = SchemaF.from_dict({"a": fields.Int(), "b": fields.Int()})
    assert schema.dumps(data_dict) == dumps(data_dict)
    assert schema.dumps(data_list) == dumps(data_list)
    assert schema.dump(data_dict) == dump(data_dict)
    assert schema.dump(data_list) == dump(data_list)
    # test to make sure the alias of dumps and dump works properly

# Generated at 2022-06-23 16:53:03.552774
# Unit test for constructor of class _IsoField
def test__IsoField():
    data = {'timestamp': '2020-08-19T18:43:10.958Z'}
    class IsoSchema(Schema):
        timestamp = _IsoField()

    iso_object = IsoSchema().load(data)
    assert iso_object.data['timestamp'] == datetime.fromisoformat('2020-08-19T18:43:10.958Z')



# Generated at 2022-06-23 16:53:09.153411
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
    # ret = schema(A, A, False)
    # print(ret)




# Generated at 2022-06-23 16:53:16.985275
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    t1 = datetime.utcnow()
    tf1 = _TimestampField()
    assert tf1.serialize(t1) == pytest.approx(t1.timestamp())

    t2 = datetime(2011, 9, 8, 6, 5, 4, tzinfo=pytz.utc)
    tf1.deserialize(t2.timestamp()) == t2

    # with missing value
    with pytest.raises(ValidationError):
        print(tf1.deserialize(None))

    # set required=False
    tf2 = _TimestampField(required=False)
    assert tf2.deserialize(None) is None



# Generated at 2022-06-23 16:53:21.822036
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    @dataclass_json
    @dataclass
    class A:
        a: int
    assert SchemaF[A]().loads(b'{"a":1}') == A(1)  # type: ignore



# Generated at 2022-06-23 16:53:32.599438
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Optional
    from marshmallow import fields, Schema
    class _UnionFieldTestSchema(Schema):
        uuid = fields.UUID()
        int = fields.Int()
    _is_union_type = is_union_type
    def is_union_type_mock(x):
        if x == Optional[UUID]:
            return [UUID, type(None)]
        elif x == int:
            return [int]
        else:
            return []
    is_union_type = is_union_type_mock

# Generated at 2022-06-23 16:53:42.279316
# Unit test for function schema

# Generated at 2022-06-23 16:53:45.177636
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert isinstance(field._serialize('dummy', 'dummy', 'dummy'), float)
    assert isinstance(field._deserialize('dummy', 'dummy', 'dummy'), datetime)



# Generated at 2022-06-23 16:53:52.023224
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MyClass(typing.Generic[A]):
        def __init__(self, a: A) -> None:
            self.a = a

    class OutSchema(SchemaF[MyClass[A]]):
        a = fields.Field()

    schema = OutSchema()
    assert list(schema.dump(MyClass(1))) == [{'a': 1}]

# Generated at 2022-06-23 16:54:00.053144
# Unit test for function schema
def test_schema():
  from dataclasses import dataclass

  from dataclasses_json import DataClassJsonMixin, config

  @dataclass
  class Foo(DataClassJsonMixin):
      x: int
      y: int
      z: str

  assert schema(Foo, DataClassJsonMixin, False) == {'x': fields.Int(),
  'y': fields.Int(), 'z': fields.Str()}
  assert schema(Foo, DataClassJsonMixin, True) == {'x': fields.Int(),
  'y': fields.Int(missing=int()), 'z': fields.Str(missing=str())}

# Generated at 2022-06-23 16:54:01.804176
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:54:04.484463
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert issubclass(_UnionField, fields.Field) is True


# Generated at 2022-06-23 16:54:15.891186
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert 'test' == SchemaF[str].loads(b'{"test":"test"}')
    assert ['test'] == SchemaF[str].loads(b'[{"test":"test"}]')

# Generated at 2022-06-23 16:54:27.135431
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class C:
        a: int
        b: str

    @dataclass
    class D:
        a: int
        b: str

    @dataclass
    class E:
        a: C
        b: typing.Union[D, int]

    assert schema(C, None, False) == {
        'a': fields.Int(missing=MISSING, allow_none=False),
        'b': fields.Str(missing=MISSING, allow_none=False)}


# Generated at 2022-06-23 16:54:31.357719
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.deserialize("2020-01-01T01:01:01") == datetime(2020, 1, 1, 1, 1, 1)



# Generated at 2022-06-23 16:54:41.432641
# Unit test for function build_schema
def test_build_schema():
    x = 'dataclasses_json.dataclass_json.build_schema'
    class Foo:
        def __init__(self):
            self.a = None
            self.b = None

    class _ExtendedEncoder(json.JSONEncoder):
        def default(self, o):
            if isinstance(o, Foo):
                return {'a': o.a, 'b': o.b}
            return super().default(o)

    class DataClassSchema(Schema):
        a = fields.Int()
        b = fields.Int()

        class Meta:
            fields = ('a', 'b')

        def make_foo(self, kvs, **kwargs):
            return Foo()


# Generated at 2022-06-23 16:54:44.983756
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    value = datetime.now()
    assert field.serialize(value, "attr", "obj") == value.timestamp()



# Generated at 2022-06-23 16:54:46.095835
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import Optional
    pass

# Generated at 2022-06-23 16:54:55.629799
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Arrange
    _value = '2017-11-01'
    f = _IsoField(missing=None, default=None, required=False)
    # Act
    actual = f.deserialize(_value)
    # Assert
    assert actual == datetime(2017, 11, 1)
    # Arrange
    _attr = ''
    _data = {}
    # Act
    actual = f.serialize(actual, _attr, _data)
    # Assert
    assert actual == '2017-11-01T00:00:00'
    # Arrange
    _value = '2017-11-01'
    # Act
    f.required = True
    actual = f.deserialize(_value)
    # Assert
    assert actual == datetime(2017, 11, 1)
    # Arrange
   

# Generated at 2022-06-23 16:55:00.202962
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField(required=True)
    assert f._deserialize('2019-12-08T06:02:23.346000') == datetime(2019, 12, 8, 6, 2, 23, 346000)



# Generated at 2022-06-23 16:55:09.035243
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import Schema

    @dataclass
    class Bar(DataClassJsonMixin):
        s: str

    class BarSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'

    @dataclass
    class Foo(DataClassJsonMixin):
        i: int
        bar: Bar

    class FooSchema(Schema, typing.Generic[Foo]):
        class Meta:
            unknown = 'EXCLUDE'

    schema = FooSchema()
    foo: Foo = schema.loads(b'{"i": 5, "bar": {"s": "hello"}}')
