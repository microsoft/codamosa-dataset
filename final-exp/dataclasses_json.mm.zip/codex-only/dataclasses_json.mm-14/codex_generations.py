

# Generated at 2022-06-23 16:45:15.697043
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema

    class SubSchema(SchemaF[int]):
        pass

    class SubSubSchema2(Schema):
        num = fields.Int(required=True)

    class SubSubSchema1(Schema):
        num = fields.Int(required=True)

    class SubSchema(Schema):
        enum_field = EnumField(enum=TestEnum, required=True)
        sub_dc = fields.Nested(SubSubSchema1, required=True)

    class TestSchema(SchemaF[TestDcOne]):
        name = fields.Str(required=True)
        num = fields.Int(required=True)
        dt = fields.DateTime(required=True)
        enum_field = EnumField(enum=TestEnum, required=True)


# Generated at 2022-06-23 16:45:18.579226
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    obj: List[A] = ...
    json_string: str = ...
    schema: SchemaF[A] = ...
    obj = schema.loads(json_string)
    obj = schema.loads(json_string, many=True)
    pass

# Generated at 2022-06-23 16:45:25.361317
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from marshmallow import Schema

    class A(Schema):
        a: int

    a = A()
    b = A(many=True)

    x = a.dumps({'a': 1})
    assert x == '{"a": 1}'

    y = a.dumps([{'a': 2}])
    assert y == '{"a": 2}'

    A.dumps(a, {'a': 1})

    A.dumps(b, [{'a': 2}])
    A.dumps([{'a': 2}])



# Generated at 2022-06-23 16:45:33.227687
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class S(SchemaF[A]):
        a = fields.Field()

    S().load({'a': 1})
    S().load([{'a': 1}])

    s = S(many=True)
    s.load({'a': 1})
    s.load([{'a': 1}])

    with pytest.raises(TypeError):
        S().load('{"a": 1}')
    with pytest.raises(TypeError):
        S().load(['{"a": 1}'])
    with pytest.raises(TypeError):
        s.load('{"a": 1}')
    with pytest.raises(TypeError):
        s.load(['{"a": 1}'])

# Generated at 2022-06-23 16:45:43.521607
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import Schema, fields, SchemaF, pre_load

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    @pre_load
    def lowercase_name(self, data, **kwargs):
        data['name'] = data['name'].lower()
        return data

    schema = PersonSchema(unknown='EXCLUDE')
    schema_f = SchemaF[Person](unknown='EXCLUDE', pre_load=[lowercase_name])
    assert schema_f.loads('{"name": "TEST"}') == Person(name='test', age=None)



# Generated at 2022-06-23 16:45:48.624650
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TestSchema(Schema):
        a = _UnionField({int: fields.Integer(), float: fields.Float()}, 0, 0)

    vs = [
        (1, 1),
        (1.0, 1.0),
        ('1', ValidationError())
    ]
    for v, expected in vs:
        res = TestSchema(strict=True).load({'a': v})
        assert res.data['a'] == expected



# Generated at 2022-06-23 16:45:57.613117
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class SampleF:
        name: str

    assert isinstance(SampleF(name='foo'), SampleF)
    schema_f = SchemaF[SampleF]()
    assert isinstance(schema_f, Schema)
    assert isinstance(schema_f.dump(SampleF(name='foo')), dict)
    assert isinstance(schema_f.dumps(SampleF(name='foo')), str)
    assert isinstance(schema_f.load({'name': 'foo'}), SampleF)
    assert isinstance(schema_f.loads('{"name": "foo"}'), SampleF)

# Generated at 2022-06-23 16:45:59.501406
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__class__ == _IsoField
    assert isinstance(field, _IsoField)


# Generated at 2022-06-23 16:46:11.425177
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow
    class SomeSchema(SchemaF[A]):
        pass

    class SomeSchema2(SchemaF[A]):
        pass

    class SomeSchema3(SchemaF[A]):
        pass

    class SomeSchema4(SchemaF[A]):
        pass

    class SomeSchema5(SchemaF[A]):
        pass

    class SomeSchema6(SchemaF[A]):
        pass

    class SomeSchema7(SchemaF[A]):
        pass

    class SomeSchema8(SchemaF[A]):
        pass

    class SomeSchema9(SchemaF[A]):
        pass

    class SomeSchema10(SchemaF[A]):
        pass


# Generated at 2022-06-23 16:46:14.576072
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class S(Schema):
        pass

    s = S()
    s.loads(b'{}')
    s.loads('{}')
    s.loads([b'{}'])
    s.loads(['{}'])

# Generated at 2022-06-23 16:46:22.580913
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from dataclasses_json import Dict
    from dataclasses_json import dataclass_json

    @dataclass
    @dataclass_json
    class User:
        id: int
        name: str
        info: Dict[str, int] = {}

    data = {
        'id': 1,
        'name': 'John Doe'
    }

    obj = SchemaF.load(data, cls=User)
    assert obj.id == 1
    assert obj.name == 'John Doe'
    assert obj.info == {}


# Generated at 2022-06-23 16:46:30.637434
# Unit test for constructor of class _UnionField
def test__UnionField():
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Bar(DataClassJsonMixin):
        bar_size: int

    @dataclass
    class Foo(DataClassJsonMixin):
        foo_name: str
        foo_size: int = 5
        foo_bar: typing.Union[Bar, int] = 5

    schema = Foo.schema()
    uf = _UnionField(schema.descriptors['foo_bar'], Foo, Foo.__dataclass_fields__['foo_bar'])

    assert uf.desc == {
        Bar: Bar.schema(),
        int: fields.Integer(required=True)
    }
    assert uf.cls is Foo
    assert uf

# Generated at 2022-06-23 16:46:41.281647
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class C:
        def __call__(self, *args, **kwargs) -> str:
            pass
    class V:
        def __call__(self, *args, **kwargs) -> None:
            pass

    cf = C()
    vf = V()
    sf = SchemaF()

    sf.loads(b'', many=True)  # mypy: ok
    sf.loads('', many=True)
    sf.loads([], many=True)

    sf.loads(b'', many=False)  # mypy: ok
    sf.loads('', many=False)
    sf.loads([], many=False)

    sf.loads(b'', many=None)  # mypy: ok
    sf.loads('', many=None)
    sf

# Generated at 2022-06-23 16:46:45.699006
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 2, 6, 12, 0, tzinfo=None)) == '2020-02-06T12:00:00'
    assert _IsoField()._serialize(datetime(2020, 2, 6, 12, 0, tzinfo=None)) == '2020-02-06T12:00:00'



# Generated at 2022-06-23 16:46:50.807317
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class User:
        def __init__(self, name: str, email: str = None) -> None:
            self.name = name
            self.email = email

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()

    s = UserSchema()
    r = s.load({'name': 'Bob'})



# Generated at 2022-06-23 16:47:02.475245
# Unit test for function build_type
def test_build_type():
    import unittest
    import marshmallow
    from marshmallow import fields
    from enum import Enum
    
    from typing import List, Dict, Tuple, Union
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mixin import JsonMixin

    class TestSchema(SchemaType):
        pass

    @dataclass_json
    @dataclass
    class Example1(JsonMixin):
        pass

    @dataclass_json
    @dataclass
    class Example2(JsonMixin):
        pass

    @dataclass_json
    @dataclass
    class Many(JsonMixin):
        example: List[Example1]
        example2: List[Example2]


# Generated at 2022-06-23 16:47:09.466311
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(2019,8,14,0,34,57), None, None, None) == 1565742897
    assert _TimestampField()._deserialize(1565742897, None, None, None) == datetime(2019,8,14,0,34,57, tzinfo=datetime.utcnow().astimezone().tzinfo)
    _TimestampField()._deserialize(None, None, None, None)


# Generated at 2022-06-23 16:47:18.095569
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    class ClassB(Enum):
        foo = 1
        bar = 2

    @dataclass
    class ClassC:
        a: int

    class ClassD:
        def __init__(self, a):
            self.a = a

    @dataclass
    class ClassA:
        u: typing.Union[int, ClassB, ClassC, ClassD]

    class TestSchema(Schema):
        u = _UnionField(desc={int: fields.Integer()}, cls=ClassA, field=dc_fields(ClassA)[0])

    test_schema = TestSchema()

    test1 = ClassA(u=1)
    assert test_schema.dump(test1) == {"u": 1}

# Generated at 2022-06-23 16:47:24.249741
# Unit test for function schema
def test_schema():
    from marshmallow.fields import Raw, List, Nested
    from marshmallow import fields
    from dataclasses import dataclass, field
    @dataclass
    class C:
        a: int = 1
    @dataclass
    class CatchAll:
        a: str
        b: int
        c: typing.Dict = field(default_factory=dict)
    assert schema(C, None, False) == {'a': fields.Integer()}
    assert schema(CatchAll, None, False) == {'a': fields.Str(), 'b': fields.Integer(), 'c': Raw()}
    @dataclass
    class D:
        a: typing.Dict[str, typing.Union[int, float, str]]

# Generated at 2022-06-23 16:47:30.265669
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    x = [SchemaF[int].load([1, 2])]
    assert x == [SchemaF[int].load([1, 2])]


# Generated at 2022-06-23 16:47:32.663699
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().__class__.__name__ == "_TimestampField"


# Generated at 2022-06-23 16:47:33.599849
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(object):
        pass

    s = SchemaF()
    s.dumps([A(), A()], many=True)



# Generated at 2022-06-23 16:47:35.659934
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def func(obj: A) -> str:
        ...

    func(SchemaF().dumps([{'a': 7}]))
    func(SchemaF().dumps({'a': 7}))


# Generated at 2022-06-23 16:47:37.175742
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps(1) == "1"
    assert SchemaF[int].dumps([1, 2]) == "[1, 2]"


# Generated at 2022-06-23 16:47:46.261033
# Unit test for constructor of class _IsoField
def test__IsoField():
    val = datetime.now()
    field = _IsoField()
    field = _IsoField(required=False)
    field._serialize(val, "attr", "obj")
    field._deserialize(val.isoformat(), "attr", {})
    field.required = True
    try:
        field._deserialize(None, "attr", {})
        raise AssertionError()
    except ValidationError:
        pass
    try:
        field._serialize(None, "attr", "obj")
        raise AssertionError()
    except ValidationError:
        pass


# Generated at 2022-06-23 16:47:52.313188
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses_json import DataClassJsonMixin
    class A(DataClassJsonMixin):
        a: int

    class B(DataClassJsonMixin):
        b: str

    class SchemaTest(Schema):
        u = _UnionField({int: A, str: B}, str, 'name')

    s = SchemaTest()
    s.load({'u': 10})
    s.load({'u': 'a'})
    s.load({'u': {'a': 10}})
    s.load({'u': {'b': 'a'}})
    s.load({'u': {'b': 'a', '__type': 'A'}})


# Generated at 2022-06-23 16:47:59.301042
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass()
    class A:
        a: int

    schema = SchemaF[A]()
    a1 = A(1)
    a2 = A(2)
    assert schema.dumps(a1) == "{\"a\": 1}"
    assert schema.dumps([a1, a2]) == "[{\"a\": 1}, {\"a\": 2}]"



# Generated at 2022-06-23 16:47:59.935828
# Unit test for constructor of class _IsoField
def test__IsoField():
    pass



# Generated at 2022-06-23 16:48:09.679799
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Dict, Mapping, Union, Optional
    from marshmallow import Schema, fields
    @dataclass
    class A:
        a: int

    class B(Schema):
        a = fields.Int()

    assert build_type(List[int], {}, object, None, object) == fields.List(fields.Int())
    assert build_type(Dict[int, str], {}, object, None, object) == fields.Mapping(fields.Int(), fields.Str())
    assert build_type(Mapping[int, str], {}, object, None, object) == fields.Mapping(fields.Int(), fields.Str())
    assert build_type(Optional[int], {}, object, None, object) == fields.Int(allow_none=True)
   

# Generated at 2022-06-23 16:48:21.510529
# Unit test for function schema
def test_schema():
    import enum
    import typing
    from typing import Union
    import dataclasses_json
    import marshmallow

    @dataclasses_json.dataclass_json
    class User:
        name: str
        email: str

    @dataclasses_json.dataclass_json
    class Author(User):
        pass

    @dataclasses_json.dataclass_json
    class Post:
        title: str
        content: str
        author: User

    @dataclasses_json.dataclass_json
    class Comment:
        email: str
        content: str
        author: Author = None

    @dataclasses_json.dataclass_json
    class Color(enum.IntEnum):
        red = 1
        green = 2
        blue = 3


# Generated at 2022-06-23 16:48:26.803013
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import typing
    import marshmallow
    from dataclasses import dataclass
    from marshmallow import fields, Schema


    @dataclass
    class Fruit:
        name: str


    class FruitSchema(Schema):
        name = fields.Str()

    fruit = Fruit("banana")
    fruit_dict = {'name': 'banana'}

    f = FruitSchema()

    res = f.dump(fruit)
    assert typing.get_type_hints(FruitSchema.dump)['return'] == typing.Union[
        list, dict]
    assert isinstance(res, dict)
    assert res == fruit_dict

    fs = FruitSchema(many=True)

    res = fs.dump([fruit])

# Generated at 2022-06-23 16:48:37.683267
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses_json.core import _handle_undefined_parameters_safe
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    @dataclass
    class A(DataClassJsonMixin):
        field: typing.List[int]
    tst = schema(A, DataClassJsonMixin, False)
    assert tst[
        'field'] is fields.List, "This test should not display a warning message"
    @dataclass
    class B(DataClassJsonMixin):
        field: typing.List[str]
    tst = schema(B, DataClassJsonMixin, False)
    assert tst[
        'field'] is fields.List, "This test should not display a warning message"

# Generated at 2022-06-23 16:48:47.581284
# Unit test for function build_schema
def test_build_schema():
    class Foo:
        pass

    class Bar(Foo):
        pass

    class Baz:
        pass

    class _Meta:
        mm_field = fields.Int()

    def _foo():
        pass

    def _bar():
        pass

    class FooSchema(SchemaType):
        i: fields.Int
        j: fields.Int = fields.Int(metadata={"dataclasses_json": _Meta()})
        k: typing.List[str]
        l: typing.List[str] = fields.List(fields.String())
        m: typing.Dict[str, int]
        n: typing.Dict[str, int] = fields.Dict(keys=fields.String(),
                                               values=fields.Integer())
        o: typing.Mapping[str, int]

# Generated at 2022-06-23 16:48:51.635638
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    _x = SchemaF[int]()
    _y = typing.cast(SchemaF[int], _x)  # Passes mypy
    _y.load  # type: ignore  # Passes mypy
    _y.load([])  # type: ignore  # Passes mypy
    _y.load([{}])  # type: ignore  # Passes mypy
    _y.load({})  # type: ignore  # Passes mypy

# Generated at 2022-06-23 16:49:00.420965
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Data:
        a: int

    class DataV1(SchemaF[Data]):
        a = fields.Int()

    d1 = DataV1().load({'a': 1}, many=True)
    assert isinstance(d1, list)
    assert isinstance(d1[0], Data)

    d2 = DataV1().load({'a': 1}, many=False)
    assert isinstance(d2, Data)

# Generated at 2022-06-23 16:49:06.183216
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def fn(obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
        pass
    def fn2(obj: A, many: bool = None) -> TEncoded:
        pass
    fn = SchemaF.dump
    fn2 = SchemaF.dump



# Generated at 2022-06-23 16:49:15.382140
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Test serialize
    assert _TimestampField()._serialize(datetime.now(), 'datetime', None)
    assert _TimestampField(required=False)._serialize(None, 'datetime', None) is None
    with pytest.raises(ValidationError):
        _TimestampField(required=True)._serialize(None, 'datetime', None)

    # Test deserialize
    assert _TimestampField()._deserialize('1', 'datetime', None)
    assert _TimestampField(required=False)._deserialize(None, 'datetime', None) is None
    with pytest.raises(ValidationError):
        _TimestampField(required=True)._deserialize(None, 'datetime', None)



# Generated at 2022-06-23 16:49:24.335863
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF[A]()
    s.loads([''])
    s.loads([''], many=False)
    s.loads('{}')
    s.loads('{}', many=False)

# Generated at 2022-06-23 16:49:25.382609
# Unit test for function build_schema
def test_build_schema():
    pass



# Generated at 2022-06-23 16:49:37.279113
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    obj = [1]
    s = SchemaF[typing.List[int]]()
    s.dump(obj)
    # Unit test for method dump of class SchemaF
    def test_SchemaF_dump():
        obj = [1]
        s = SchemaF[typing.List[int]]()
        s.dump(obj)

    # Unit test for method dumps of class SchemaF
    def test_SchemaF_dumps():
        obj = [1]
        s = SchemaF[typing.List[int]]()
        s.dumps(obj)

    # Unit test for method load of class SchemaF
    def test_SchemaF_load():
        obj = [1]
        s = SchemaF[typing.List[int]]()
        s.load(obj)

   

# Generated at 2022-06-23 16:49:37.816839
# Unit test for function build_type
def test_build_type():
    assert False


# Generated at 2022-06-23 16:49:42.349932
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    res = SchemaF[int].loads([{'foo': 5}], many=True)[0]
    assert isinstance(res, int)
    assert res == 5

    res = SchemaF[int].loads({'foo': 5}, many=False)
    assert isinstance(res, int)
    assert res == 5



# Generated at 2022-06-23 16:49:49.693537
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(SchemaF[TOneOrMulti]):
        pass
    x = Foo.dumps(1, many=False)
    assert isinstance(x, str)
    x = Foo.dumps([1], many=True)
    assert isinstance(x, str)
    x = Foo.dumps(1, many=None)
    assert isinstance(x, str)
    x = Foo.dumps([1], many=None)
    assert isinstance(x, str)


# Generated at 2022-06-23 16:49:56.405981
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None, None) is not None
    assert _TimestampField()._deserialize(0, None, None, None) is not None

# TODO:
#   * bytes/str
#   * Dict[str, T] where T is a type
#   * Decimal
#   * datetime
#   * UUID


# Generated at 2022-06-23 16:50:07.487072
# Unit test for function build_type
def test_build_type():
    class Person():
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return isinstance(other, Person) and other.name == self.name

    def func():
        pass

    class MySchema(Schema):
        name = fields.Str()

    class MyEnum(Enum):
        ONE = 1
        TWO = 2

    class Dummy:
        pass

    assert build_type(int, {}, Dummy, Dummy, Dummy)(int, {}) == fields.Int()
    assert build_type(str, {}, Dummy, Dummy, Dummy)(str, {}) == fields.Str()
    assert build_type(float, {}, Dummy, Dummy, Dummy)(float, {}) == fields.Float()
    assert build_type

# Generated at 2022-06-23 16:50:18.332145
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow_dataclass
    class Foo:
        pass
    obj = Foo()
    res = marshmallow_dataclass.SchemaF[Foo].loads(obj)



# Generated at 2022-06-23 16:50:26.648171
# Unit test for function schema

# Generated at 2022-06-23 16:50:35.236173
# Unit test for constructor of class _IsoField
def test__IsoField():
    field_iso = _IsoField(required=True)
    field_iso._serialize(datetime(2020, 10, 24, 8, 37, 0), 'datetime_field', 'obj') == '2020-10-24T08:37:00'
    field_iso._deserialize('2020-10-24T08:37:00', 'datetime_field', 'obj') == datetime(2020, 10, 24, 8, 37, 0)


# Generated at 2022-06-23 16:50:47.116786
# Unit test for function build_type
def test_build_type():
    dataclass_json.configure_mapping()

    @dataclass_json
    @dataclass
    class SimpleUser:
        age: int
        created_at: datetime

    @dataclass_json
    @dataclass
    class User(SimpleUser):
        name: str = field(metadata={"mm_field": fields.Str})
        uuid: UUID = field(metadata={"mm_field": fields.UUID})
        active: bool = field(default=True,
                             metadata={"mm_field": fields.Bool, "required": False})
        friends: "List[User]" = field(default_factory=list,
                                      metadata={"mm_field": fields.Nested("self", many=True)})


# Generated at 2022-06-23 16:50:55.103062
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json  # type: ignore
    @dataclass
    class X:
        x: str

    assert build_schema(X, None, False, False) == {"x": fields.Str}

    @dataclass_json  # type: ignore
    @dataclass
    class Y:
        y: int

    assert build_schema(Y, None, False, False) == {"y": fields.Int}

    @dataclass_json  # type: ignore
    @dataclass
    class Z:
        z: float

    assert build_schema(Z, None, False, False) == {"z": fields.Float}

# Generated at 2022-06-23 16:51:00.137603
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class _SchemaF(SchemaF[A]):
        pass
        _SchemaF("")  # type: ignore
    json.loads("")  # type: ignore
    _SchemaF.loads("")  # type: ignore
    _SchemaF().loads("")  # type: ignore

# Generated at 2022-06-23 16:51:06.868399
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            pass
    d = SchemaF[Foo[int]]({}).loads('{"a": 3}')
    assert isinstance(d, typing.List)
    with pytest.raises(NotImplementedError):
        d = SchemaF[Foo[int]]({})  # type: ignore[call]  # mypy doesn't consider NotImplementedError as a possible error
    d = SchemaF[Foo[int]]({}).loads(b'{"a": 3}')

# Generated at 2022-06-23 16:51:17.642787
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MyClass(object):
        pass

    class MySchema(SchemaF[MyClass]):
        pass

    m = MySchema()
    m.loads('{"key1": "value1"}')  # Works
    m.loads(b'{"key1": "value1"}')  # Works
    m.loads(bytearray('{"key1": "value1"}', 'utf-8'))  # Works
    m.loads([b'{"key1": "value1"}'], many=True)  # Works
    m.loads([{'key1': 'value1'}])  # Works

    m.dump(MyClass())  # Works
    m.dump([MyClass()])  # Works


# Generated at 2022-06-23 16:51:25.625372
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_date = datetime(year=1987, month=6, day=5, hour=1, minute=20, second=3, microsecond=99, tzinfo=None)
    obj = _IsoField()
    assert obj.deserialize(test_date.isoformat()) == test_date
    assert obj.serialize(test_date) == test_date.isoformat()


# Generated at 2022-06-23 16:51:27.217001
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF()



# Generated at 2022-06-23 16:51:39.284163
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import date, datetime, timezone, timedelta
    # Initialize input
    iso_str = "2020-02-01T23:19:00.003699+00:00"
    iso_date = date(2020, 2, 1)
    iso_datetime = datetime(2020, 2, 1, 23, 19, 0, 3699, tzinfo=timezone.utc)

    # Test _IsoField class
    IsoField = _IsoField()
    assert IsoField._serialize(iso_datetime, None, None, None) == iso_str
    assert IsoField._serialize(iso_date, None, None, None) == iso_str
    assert IsoField._serialize(None, None, None, None) is None

# Generated at 2022-06-23 16:51:42.562104
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestCls:
        foo: str
        _bar: int

    build_schema(TestCls)

# Generated at 2022-06-23 16:51:52.964679
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(SchemaF):
        bar = fields.Field()

    Foo().load([{'bar': 1}, {'bar': 2}], many=True)
    Foo().load({'bar': 1}, many=False)

# Generated at 2022-06-23 16:51:57.658371
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class S(SchemaF[int]):
        pass
    s = S()
    assert s.dumps(x) == '1'



# Generated at 2022-06-23 16:51:59.298175
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    foo = SchemaF[str]()
    foo.dump('foo')



# Generated at 2022-06-23 16:52:09.016577
# Unit test for function build_type
def test_build_type():
    class Mixin:
        @classmethod
        def schema(cls, *args, **kwargs):
            return SchemaType(*args, **kwargs)


    class Test:
        def __init__(self, value):
            self.value = value


    class Test2:
        def __init__(self, value):
            self.value = value

        @classmethod
        def schema(cls, *args, **kwargs):
            return SchemaType(*args, **kwargs)


    class Test3:
        def __init__(self, value):
            self.value = value


    class A(Mixin):
        test: Test
        tests: List[Test2]


# Generated at 2022-06-23 16:52:18.663146
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    @dataclass
    class Person:
        name: str
        age: int
        father: 'Person' = None
        mother: typing.Optional['Person'] = None
        _private = field(default=False, metadata=dict(dataclasses_json=dict(mm_field=fields.Bool())))

    print(schema(Person, mixin=object))
    # {'name': <marshmallow.fields.String object at 0x7f790b7c8128>, 'age': <marshmallow.fields.Integer object at 0x7f790b7c8160>, 'father': <marshmallow.fields.Nested object at 0x7f790b7c81d0>, 'mother': <marshmallow.fields.Nested object at 0x7f790b7

# Generated at 2022-06-23 16:52:23.146077
# Unit test for constructor of class _UnionField
def test__UnionField():
    return


# Set default encoder to `_ExtendedEncoder` that handles extended Python types
try:
    import ujson as json
except ImportError:
    import json



# Generated at 2022-06-23 16:52:32.404162
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        foo: str

    class Mixin:
        pass

    schema = build_schema(Test, Mixin, infer_missing=True, partial=False)

    assert issubclass(schema, Schema)
    assert Test.schema() == schema
    assert Test.schema().Meta.fields == ('foo',)
    assert Test.schema().fields == {'foo': fields.Str(missing=fields.missing,
                                                      allow_none=False)}
    assert Test.schema().dump(Test(foo='bar')) == {'foo': 'bar'}

    @dataclass
    class Test:
        foo: str
        bar: int

    schema = build_schema(Test, Mixin, infer_missing=True, partial=False)


# Generated at 2022-06-23 16:52:41.583343
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow
    from typing import Union
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.schema import Schema


    @dataclass
    class Color(DataClassJsonMixin):
        name: str
        value: int

    class ColorSchema(Schema):
        name = marshmallow.fields.String(attribute='name')
        value = marshmallow.fields.Integer(attribute='value')


    @dataclass
    class Car(DataClassJsonMixin):
        model: str
        color: Union[str, Color] = 'White'

    class CarSchema(Schema):
        model = marshmallow.fields.String(attribute='model')

# Generated at 2022-06-23 16:52:47.115538
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from typing import List
    @dataclass
    class TestNested:
        key: str
    @dataclass
    class Main:
        key: TestNested
        key2: TestNested 
        key3: str
    data = Main(TestNested('test'), TestNested('test'), 'str')
    schema = build_schema(Main, None, True, False)()
    print(schema.dumps(data,))

if __name__ == "__main__":
    test_build_schema()

# Generated at 2022-06-23 16:52:53.304989
# Unit test for function build_schema
def test_build_schema():
    class A(dataclass):
        a = int
    # TODO extend tests
    assert A.schema().dump(A(a=1)) == {"a": 1}
    assert A.schema().load({"a": 1}) == A(a=1)

# Generated at 2022-06-23 16:53:00.316181
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    class Mix(object):
        pass

    @dataclass
    class B(Mix):
        pass

    @dataclass
    class A(Mix):
        b: B

    @dataclass
    class C(object):
        x: typing.List[A]

    assert isinstance(build_type(C, {}, Mix, dc_fields(C)[0], A)(A, {}),
                      fields.Nested)

# Generated at 2022-06-23 16:53:02.283871
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:53:09.360466
# Unit test for function build_schema
def test_build_schema():
    dc = {"id": str}
    cls = dataclass_json.DataClass('Person', [('id', str, str)])
    my_schema = build_schema(cls=cls, mixin=None, infer_missing=None, partial=None)
    assert my_schema.Meta.fields == ('id',)
    assert my_schema.declared_fields == {'id': fields.Field}
    pass



# Generated at 2022-06-23 16:53:17.905930
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF[int]

if sys.version_info >= (3, 7):
    T = typing.TypeVar('T')

    class _Meta(Schema.__class__):
        def __instancecheck__(cls, instance):
            return isinstance(instance, Schema)

        def __subclasscheck__(cls, subclass):
            return is_dataclass(subclass)

    class DataclassSchemaMeta(type, _Meta):  # type: ignore
        pass



# Generated at 2022-06-23 16:53:26.895004
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize("2017-04-27T14:22:58.105395+03:00", "", {}) == datetime(2017, 4, 27, 14, 22, 58, 105395, tzinfo=datetime.now().astimezone().tzinfo)
    assert field._deserialize("2017-04-27T14:22:58.105395", "", {}) == datetime(2017, 4, 27, 14, 22, 58, 105395)
    assert field._deserialize("2017-04-27T14:22:58", "", {}) == datetime(2017, 4, 27, 14, 22, 58)

# Generated at 2022-06-23 16:53:35.157329
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField(required=True)
    assert f.required == True
    with pytest.raises(ValidationError) as excinfo:
        f._deserialize(None, "attr", {},)
    assert excinfo.value.messages == {'required': ['Missing data for required field.']}
    assert f._deserialize(1568238400, "attr", {}) == datetime(2019, 9, 12, 18, 0)
    assert f._serialize(datetime(2019, 9, 12, 18, 0), "attr", {}) == 1568238400



# Generated at 2022-06-23 16:53:42.857477
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class A:
        f: int

    @dataclasses.dataclass
    class B:
        f: typing.List[A]

    schema = SchemaF[A]()
    a = A(f=1)
    b = B(f=[A(f=1), A(f=2)])
    assert schema.dump(a) == {'f': 1}
    assert schema.dump(b) == {'f': [{'f': 1}, {'f': 2}]}
    assert type(schema.dump(b)[
                   'f']) == dict  # mm has the wrong return type annotation (list)



# Generated at 2022-06-23 16:53:55.256854
# Unit test for function build_type
def test_build_type():
    import typing
    import marshmallow as mm
    import dataclasses as dc
    import uuid
    from dataclasses_json.core import build_type, MISSING
    from datetime import datetime
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    
    @dc.dataclass
    class InnerTestSchema1(object):
        id: str = dc.field(metadata={"mm_field": mm.fields.UUID, "data_key": "idx"})

    @dc.dataclass
    class InnerTestSchema(object):
        id: typing.List[InnerTestSchema1]

    @dc.dataclass
    class TestSchema(object):
        id: typing.List[str]
        idx: typing

# Generated at 2022-06-23 16:54:03.627624
# Unit test for constructor of class _UnionField
def test__UnionField():
    # Empty declarations
    with pytest.raises(ValueError) as excinfo:
        _UnionField()
    assert str(excinfo.value) == 'Tuple "desc" must be provided'

    with pytest.raises(ValueError) as excinfo:
        _UnionField([])
    assert str(excinfo.value) == 'Tuple "desc" must be provided'

    with pytest.raises(ValueError) as excinfo:
        _UnionField(desc=(), cls=None)
    assert str(excinfo.value) == 'Class "cls" must be provided'

    with pytest.raises(ValueError) as excinfo:
        _UnionField(desc=(), cls=None, field=None)
    assert str(excinfo.value) == 'Field "field" must be provided'


# Generated at 2022-06-23 16:54:05.080345
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-23 16:54:16.321292
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing_inspect import get_origin
    from marshmallow import Schema
    from marshmallow.exceptions import ValidationError
    from marshmallow.utils import missing
    from decimal import Decimal
    import dataclasses

    @dataclasses.dataclass
    class Name(object):
        name: str

    class NameSchema(Schema):
        name = fields.Str()

    schema_f = SchemaF[Name]

    assert issubclass(schema_f, Schema)
    assert get_origin(schema_f) is list

    d = schema_f.dump(Name('name'))
    assert d == {'name': 'name'}

    d = schema_f.dump(Name('name'), many=True)
    assert d == [{'name': 'name'}]

    d = schema

# Generated at 2022-06-23 16:54:19.946021
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # type: () -> None
    """Unit test for constructor of class SchemaF"""
    class _Schema(SchemaF):
        pass

    import pytest
    with pytest.raises(NotImplementedError):
        _Schema()



# Generated at 2022-06-23 16:54:31.144110
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        x: str

    @dataclass_json
    @dataclass
    class B:
        y: int

    @dataclass_json
    @dataclass
    class Data:
        a: A
        b: B
        c: List[int]
        d: Optional[Dict[str, float]]
        e: Optional[Union[str, int]]
        f: Optional[str]


# Generated at 2022-06-23 16:54:41.216232
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Person:
        def __init__(self, name: int, age: int):
            self.name = name
            self.age = age

    class PersonSchema(Schema):
        name = fields.Int()
        age = fields.Int()

    PersonSchemaF = SchemaF[  # type: ignore
        Person]  # We need to add type ignore because of some bug in mypy
    person_serialized = \
        [{'name': 1, 'age': 2}, {'name': 2, 'age': 3}, {'name': 3}]
    person_data = PersonSchemaF.loads(  # type: ignore
        person_serialized)  # type: ignore # We need to add type ignore because of some bug in mypy

# Generated at 2022-06-23 16:54:50.678546
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso1 = _IsoField()
    iso2 = _IsoField()
    iso1._deserialize(
        value="2020-04-20T17:20:59.710923+00:00",
        attr=None,
        data=None,
        partial=None
    )
    iso2._deserialize(value="2020-04-20T17:20:59.710923+00:00", attr=None, data=None, partial=None)
    assert iso1 is not None
    assert iso2 is not None



# Generated at 2022-06-23 16:54:56.067983
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[str]):
        def __init__(self):
            super().__init__()
            self.data = 'a data'

        @post_load
        def make_object(self, data, **kwargs):
            data['added_key'] = 'added_value'
            return data

    assert MySchema().data == 'a data'
    assert MySchema().load({'some_key': 'some_value'}) == {'some_key': 'some_value', 'added_key': 'added_value'}
    assert MySchema().dump({'some_key': 'some_value'}) == {'some_key': 'some_value'}



# Generated at 2022-06-23 16:55:07.666653
# Unit test for function schema
def test_schema():
    class Model(object):
        # TODO: check the schema here, the default_factory should not be in this test
        def __init__(self, a, b, c=5, d=7, e=None, f=MISSING, g="abc", h=None, i="def"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
            self.g = g
            self.h = h
            self.i = i

        def default_factory(self):
            return 2

    m = Model(10, 20, 30, 40, 50, 60, 70, 80, 90)