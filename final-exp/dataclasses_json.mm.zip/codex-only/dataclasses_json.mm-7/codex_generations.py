

# Generated at 2022-06-23 16:45:07.367849
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses.dataclass
    class Foo:
        f1: str

    s = SchemaF[Foo](
        only=('f1',))  # mm has the wrong return type annotation (dict) so we can ignore the mypy error
    s.dumps(Foo('a'))



# Generated at 2022-06-23 16:45:14.444405
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    dc = _decode_dataclass(
        "A", ("foo", "bar", "baz"),
        {"foo": ("foo", str),
         "bar": ("bar", int),
         "baz": ("baz", typing.List[str])},
        [],
        [],
        None,
        False)
    schema = SchemaF[dc](type_=dc, context=dc)

    res = schema.load({"foo": "foo", "bar": 1, "baz": ["baz"]})
    assert isinstance(res, dc)



# Generated at 2022-06-23 16:45:21.057463
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class Test:
        foo: str
        bar: int

    class TestSchema(SchemaF[Test]):
        foo = fields.String()
        bar = fields.Integer()

    schema = TestSchema()
    obj = Test('asdf', 12)

    assert isinstance(obj, Test)
    assert isinstance(schema.load(schema.dumps(obj)), Test)



# Generated at 2022-06-23 16:45:29.322807
# Unit test for function schema
def test_schema():
    field_meta_data = {'dataclasses_json': {'mm_field': None, 'encoder': None, 'key_transformer': None, 'letter_case': 'camel'}}
    new_field = dc_fields.Field(int, False, None, None, None, field_meta_data)
    overrides = {}
    infer_missing = True
    mixin = object
    cls = object
    field = new_field
    type_ = type_ = field.type
    options = {}
    missing_key = 'missing' if infer_missing else 'default'
    if field.default is not MISSING:
        options[missing_key] = field.default
    elif field.default_factory is not MISSING:
        options[missing_key] = field.default_factory


# Generated at 2022-06-23 16:45:35.332210
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF[TOneOrMultiEncoded]
    d = {'a':1}
    assert schema.dumps(d) == '{"a": 1}'
    assert schema.dumps([d]) == '[{"a": 1}]'

# Generated at 2022-06-23 16:45:45.668428
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    if sys.version_info < (3, 7):
        _TEST_TIMESTAMP = 1523832800.0
    else:
        _TEST_TIMESTAMP = datetime(2018, 4, 14, 14, 0, tzinfo=timezone.utc).timestamp()

    # test serialization
    testfield = _TimestampField(required=True)
    assert testfield._serialize(_TEST_TIMESTAMP, "attr", None) == _TEST_TIMESTAMP

    testfield = _TimestampField(required=False)
    assert testfield._serialize(_TEST_TIMESTAMP, "attr", None) == _TEST_TIMESTAMP

    # test deserialization
    testfield = _TimestampField(required=True)

# Generated at 2022-06-23 16:45:56.073902
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses_json.schema import SchemaF
    import typing

    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: typing.List[int]

    @dataclasses.dataclass
    class B:
        a: A
        b: typing.List[A]

    # test typing.List[A]
    schema = SchemaF[typing.List[A]]()  # type: SchemaF[typing.List[A]]
    objs = [A(1, 2, [1, 2, 3]), A(4, 5, [4, 5, 6])]

# Generated at 2022-06-23 16:46:05.095328
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Set up the arguments that will be sent to the called method
    obj: typing.List[int] = [1, 2, 3]
    many = True
    # Set up the return value that will be returned to the caller
    ret_val: typing.List[TEncoded] = []
    # Define a method to be called when the load is called
    def mock_dump(obj_: A, many_: bool):
        # If the arguments match the arguments of the call to be mocked,
        # set the return value to the return value defined above
        if obj_ == obj and many_ == many:
            return ret_val

    # Create a mock SchemaF object
    schema_f_obj = SchemaF()

    # Set the mock_dump method as the dump method
    schema_f_obj.dump = mock_dump  # type

# Generated at 2022-06-23 16:46:07.628205
# Unit test for constructor of class _IsoField
def test__IsoField():
    r = _IsoField(required=True, allow_none=False)

    assert r is not None



# Generated at 2022-06-23 16:46:17.571442
# Unit test for constructor of class _IsoField
def test__IsoField():
    default_kwargs = {'load_from': None, 'dump_to': None, 'load_only': False, 'dump_only': False, 'missing': None, 'allow_none': False, 'error_messages': {'null': 'Field may not be null.', 'required': 'Missing data for required field.', 'validator_failed': 'Invalid value.', 'validator_failed_allow_none': 'Invalid value.  Allowable values are:'}, 'validate': None, 'validators': (), 'required': False}
    field = _IsoField(**default_kwargs)
    assert field.deserialize('AAA') == datetime(2020, 1, 1, 0, 0)


# Generated at 2022-06-23 16:46:18.862104
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), fields.Field)


# Generated at 2022-06-23 16:46:28.934055
# Unit test for constructor of class SchemaF
def test_SchemaF():
    import os
    import json
    import tempfile

    class Foo:
        def __init__(self, name: str):
            self.name = name

    class Bar:
        def __init__(self, name: str, baz: str):
            self.name = name
            self.baz = baz

    @dataclass_json
    @dataclass
    class Baz:
        name: str
        bar: typing.Optional[Bar]

    @dataclass_json
    @dataclass
    class FooSchema(SchemaF[Foo]):
        name: str

    @dataclass_json
    @dataclass
    class BazSchema(SchemaF[Baz]):
        name: str


# Generated at 2022-06-23 16:46:38.998460
# Unit test for function build_type
def test_build_type():

    class SomeClass:
        pass

    dummy_class = SomeClass()
    dummy_field = None # type: ignore

    from marshmallow import fields, Schema

    obj = build_type(dict, {}, dummy_class, dummy_field, dummy_class)
    assert isinstance(obj, fields.Dict)

    obj = build_type(typing.Mapping, {}, dummy_class, dummy_field, dummy_class)
    assert isinstance(obj, fields.Mapping)

    obj = build_type(typing.MutableMapping, {}, dummy_class, dummy_field, dummy_class)
    assert isinstance(obj, fields.Mapping)

    obj = build_type(list, {}, dummy_class, dummy_field, dummy_class)
    assert isinstance(obj, fields.List)


# Generated at 2022-06-23 16:46:42.797488
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    value = field._serialize(None, None, None)
    assert value is None
    value = field._serialize(datetime.today(), None, None)
    assert value is not None


# Generated at 2022-06-23 16:46:51.125203
# Unit test for function build_type
def test_build_type():
    class Model(SchemaType):
        pass

    @dataclass
    class _P:
        p: typing.Any = MISSING

        def _m(v):
            return v

        @property
        def _p(self):
            return '_p'

        @_p.setter
        def _p(self, v):
            self.p = v

    class _Q(Model):
        pass

    class _A:
        pass

    class _B(_A):
        pass

    class _C(_A):
        pass

    class _D(_C):
        pass

    class _E(_B):
        pass

    class _F(_D, _E):
        pass

    class _N(typing.NamedTuple):
        a: str
        b: list


# Generated at 2022-06-23 16:46:51.976224
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso = _IsoField()


# Generated at 2022-06-23 16:47:03.367203
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from marshmallow_dataclass import dataclass as mmdc
    from marshmallow import fields as mmfields

    @dataclass
    class Dummy:
        value: int

    @dataclass
    class TestNested:
        id: str
        value: typing.List[Dummy]

    @mmdc
    class TestNestedSchema(SchemaType):
        id: mmfields.String
        value: mmfields.List(mmfields.Nested(Dummy.schema()))

    @dataclass
    class TestClass:
        id: str
        value: typing.List[TestNested]

    result = schema(TestClass, SchemaType, False)

# Generated at 2022-06-23 16:47:13.434939
# Unit test for function build_type
def test_build_type():
    _is_new_type = lambda it: False
    _is_supported_generic = lambda it: True
    _is_collection = lambda it: True
    _is_optional = lambda it: True
    _issubclass_safe = lambda a, b: True
    is_union_type = lambda it: True
    is_dataclass = lambda it: True
    class mixin:
        def __init__(self):
            self.__name__ = 'Foo'
        schema = lambda self: self
    class cls:
        def __init__(self):
            self.__name__ = 'Bar'
    class Enum:
        def __init__(self):
            self.__name__ = 'Baz'
    class field:
        def __init__(self):
            self.name = 'test'
           

# Generated at 2022-06-23 16:47:23.768001
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import marshmallow
    import marshmallow_enum
    import dataclasses_json

    def test_schema(cls):
        schema = {}
        overrides = _user_overrides_or_exts(cls)
        # TODO check the undefined parameters and add the proper schema action
        #  https://marshmallow.readthedocs.io/en/stable/quickstart.html
        for field in dc_fields(cls):
            metadata = (field.metadata or {}).get('dataclasses_json', {})
            metadata = overrides[field.name]
            if metadata.mm_field is not None:
                schema[field.name] = metadata.mm_field
            else:
                t = marshmallow.fields.Field(**options)
                # if type

# Generated at 2022-06-23 16:47:25.583633
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s: SchemaF[int] = SchemaF()
    s.loads('{"a": 1}')

# Generated at 2022-06-23 16:47:33.178796
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class T(Enum):
        A = 1
        B = 2
        C = 3

    class S(SchemaF):
        a: int = fields.Int()
        b: str = fields.Str()
        c: T = EnumField(enum=T)

    assert isinstance(S().load({"a": 3, "b": "foo", "c": "A"}), S)
    assert isinstance(S().load([{"a": 3, "b": "foo", "c": "A"}]), typing.List[S])
    assert S().load({"a": "3", "b": "foo", "c": "A"}) is None
    assert S().load({"a": 3, "b": "foo", "c": "F"}) is None



# Generated at 2022-06-23 16:47:39.200407
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema

    class User(Schema):
        name = fields.Str()

    class UserSchema(SchemaF[User]):
        name = fields.Str()

    schema = UserSchema()
    res = schema.load({"name": "George"}, many=False)
    assert type(res) == User
    res = schema.load([{"name": "George"}, {"name": "John"}], many=True)
    assert type(res) == List[User]



# Generated at 2022-06-23 16:47:41.643327
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    fields = {'id': str, 'name': str, }
    @dataclass
    class TestDataClass:
        id: str = "1"
        name: str = "test"
    TestDataClass.schema()
# Test for function build_schema
test_build_schema()


# Generated at 2022-06-23 16:47:50.167751
# Unit test for constructor of class SchemaF

# Generated at 2022-06-23 16:47:53.173479
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import typing

    data = [{"a": 1}]
    actual = SchemaF.load(data)
    expected = [Schema().load(data)]
    assert actual == expected



# Generated at 2022-06-23 16:47:57.085911
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    result = SchemaF.dumps(None, None)
    assert result is not None
    assert isinstance(result, str)

# Generated at 2022-06-23 16:48:07.078775
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    foo = Foo()

    # instance of FooSchema is not allowed
    with pytest.raises(NotImplementedError):
        FooSchema()

    # the following code may raise NotImplementedError but the test is just
    # to make sure that the code passes the syntax checking of Python 3.6
    FooSchema.dump([foo])
    FooSchema.dump(foo)
    FooSchema.dump(foo, many=False)
    FooSchema.dumps(foo, many=False)

    FooSchema.load([])
    FooSchema.load({})
    FooSchema.loads(b'')
    FooSchema.loads(b'', many=False)



# Generated at 2022-06-23 16:48:15.247361
# Unit test for function build_schema
def test_build_schema():
    class C(object):
        def __init__(self, bar: str, baz: int):
            self.bar = bar
            self.baz = baz

    class D(object):
        def __init__(self, bar: int, baz: str):
            self.bar = bar
            self.baz = baz

    class B(object):
        def __init__(self, foo: Union[C, D], w: str):
            self.foo = foo
            self.w = w

    class A(object):
        def __init__(self, f: str, b: B):
            self.f = f
            self.b = b

    class AA(object):
        def __init__(self, f: str, b: List[B]):
            self.f = f

# Generated at 2022-06-23 16:48:25.249410
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union
    from marshmallow import fields
    from dataclasses_json.schema import _UnionField

    @dataclass
    class A:
        x: Union[str, int, float]

    desc = {str: fields.Field(), int: fields.Field(),
            float: fields.Field()}
    union_field = _UnionField(desc=desc, cls=A, field=A.__annotations__['x'],
                              allow_none=False, default='default_value')
    assert isinstance(union_field.desc, dict)
    assert union_field.cls == A
    assert union_field.field == A.__annotations__['x']
    assert not union_field.allow_none

# Generated at 2022-06-23 16:48:28.683857
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2019-04-18T03:03:15') == datetime.fromisoformat('2019-04-18T03:03:15')



# Generated at 2022-06-23 16:48:29.594961
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF()



# Generated at 2022-06-23 16:48:34.853909
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(Schema):
        a = fields.Int()

        @post_load
        def make_A(self, data, **kwargs):
            return A(**data)

    def serialize(a: A) -> JsonData:
        return ASchema(unknown=EXCLUDE).dumps(a)

    pass



# Generated at 2022-06-23 16:48:43.205697
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF[bool]()
    s.dump(True, many=True)
    s.dump([True], many=False)
    s.dump([True], many=True)
    # s.dump([True], many=None)  # Error
    s.dump(True)
    # s.dump(True, many=False)  # Error
    s.dump([True], many=None)
    # s.dump(True, many=None)  # Error
    s.dump([True])
    s.dump(True, many=True)


# Generated at 2022-06-23 16:48:50.559676
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        ...

    schema = SchemaF[Foo]()
    data = Foo()
    str_data = schema.dumps([data])
    assert str_data == "[{}]"
    str_data = schema.dumps(data)
    assert str_data == "{}"
    schema = SchemaF[Foo]()
    data = [Foo()]
    str_data = schema.dumps(data)
    assert str_data == "[{}]"
    str_data = schema.dumps(data, many=True)
    assert str_data == "[{}]"
    str_data = schema.dumps(data, many=False)
    assert str_data == "[{}]"
    str_data = schema.dumps(data, many=None)

# Generated at 2022-06-23 16:49:00.849095
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # noqa
    from typing import List

    S = SchemaF[List[int]]

    assert S.load([{"a": 1}, {"a": 2}]) == [{"a": 1}, {"a": 2}]

    assert S.load([{"a": 1}, {"a": 2}], many=True) == [{"a": 1}, {"a": 2}]

    assert S.loads(b'[{"a": 1}, {"a": 2}]') == [{"a": 1}, {"a": 2}]

    assert S.loads('[{"a": 1}, {"a": 2}]') == [{"a": 1}, {"a": 2}]

    with raises(TypeError):
        S.loads(1)



# Generated at 2022-06-23 16:49:02.572339
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert False  # SchemaF.dump not working for py < 3.7


# Generated at 2022-06-23 16:49:11.708110
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int()
    assert build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int())
    assert build_type(typing.Optional[int], {}, None, None, None) == fields.Int(allow_none=True)
    assert build_type(typing.List[typing.Optional[int]], {}, None, None, None) == fields.List(fields.Int(allow_none=True))

    # TODO: add other types
test_build_type()


# Generated at 2022-06-23 16:49:12.233576
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert 1 == 1



# Generated at 2022-06-23 16:49:23.469766
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Test(object):
        def __init__(self, test: int):
            self.test = test
    class TestDc(typing.Generic[A], object):
        def __init__(self, test: A):
            self.test = test
    class TestSchema(SchemaF[TestDc[int]]):
        test = fields.Int()
        @post_load
        def make_object(self, data):
            return TestDc[int](**data)

    @dataclasses.dataclass
    class DcTest(object):
        test: int

    dc_schema = dataclasses_json.Schema.for_dataclass(DcTest)
    dc_schema.loads('{"test": 1}')


# Generated at 2022-06-23 16:49:30.815298
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields as fld
    @dataclass
    class MyData:
        my_str: str
        my_int: int
    sf = SchemaF[MyData]
    assert sf.loads("{}") == None  # type: ignore
    assert sf.loads("{}", many=True) == []  # type: ignore
    assert sf.loads("{}", many=False) == None  # type: ignore
    assert sf.loads("{}", many=None) == None  # type: ignore



# Generated at 2022-06-23 16:49:39.835940
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow as mm

    class A(mm.Schema):
        a = mm.fields.Integer()

    class B(mm.Schema):
        b = mm.fields.Integer()

    class C(mm.Schema):
        a = mm.fields.Nested(A)
        b = mm.fields.Nested(B)

    def m(x: SchemaF[C], y: SchemaF[B]):
        x.load([])
        y.load({})
        x.loads('[{}]')
        y.loads('{}')
        x.validate([])
        y.validate({})
        pass



# Generated at 2022-06-23 16:49:50.616195
# Unit test for function schema
def test_schema():
    from .json import _PostLoadExt
    from .utils import _get_schema_attr_name, _get_schema_name
    from .types import T, JsonData
    from dataclasses import dataclass, asdict
    import marshmallow as mm
    import marshmallow_enum as menum
    import marshmallow.fields as mf
    import marshmallow.validate as mv
    import datetime as dt
    import uuid
    import typing
    # Test 1
    @dataclass
    class A:
        a: int = 10

    @dataclass
    class B:
        a: A = A()

    @dataclass
    class C:
        a: A = A()

    assert schema(B, _PostLoadExt, False) == schema(C, _PostLoadExt, False)



# Generated at 2022-06-23 16:49:58.193581
# Unit test for function schema
def test_schema():
    import unittest
    from dataclasses import dataclass
    import dataclasses_json
    from marshmallow.exceptions import ValidationError

    @dataclass
    class test_class:
        a:int
        b:list
        c:dict
    test = test_class(1,[1,2,3],{"wb":123})
    test_schema = schema(test_class,dataclasses_json.DataClassJsonMixin, True)
    assert test_schema['a']._deserialize("1") == 1
    assert test_schema['b']._deserialize("1,2,3") == ['1','2','3']
    assert test_schema['c']._deserialize("{'wb':123}") == {'wb':123}
    assert test_schema

# Generated at 2022-06-23 16:50:00.255943
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert isinstance(SchemaF.dumps(SchemaF, list), object)
    assert isinstance(SchemaF.dumps(SchemaF, dict), object)

# Generated at 2022-06-23 16:50:05.452423
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class User:
        name: str
        age: int
        is_active: bool = False
        # This will be serialized as the catch all field
        catch_all: CatchAllVar = field(metadata={"dataclasses_json": {
            "omit_if_none": True
        }})

    schema = build_schema(User, Schema, infer_missing=True, partial=True)

    assert schema.make_user({"name": "Chuck", "age": 42}) == User("Chuck", 42)
    assert schema.make_user({"name": "Chuck", "age": 42, "is_active": True}) == User(
        "Chuck", 42, True)

    # Test the catch all field

# Generated at 2022-06-23 16:50:15.732550
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Bar:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

        def __repr__(self):
            return '<{}(a={}, b={})>'.format(self.__class__.__name__, self.a, self.b)

    class SchemaBar(Schema):
        a = fields.Int()
        b = fields.Str()

        @post_load
        def make_object(self, data, **kwargs):
            return Bar(**data)

    @dataclass_json
    @dataclass
    class Foo:
        x: int
        y: Bar


# Generated at 2022-06-23 16:50:24.843215
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    @dataclass_json
    @dataclass
    class Test:
        val: str

    Test(val="test")
    Test(val=1)

    SchemaF[Test]
    SchemaF[int]
    SchemaF[typing.List[int]]
    SchemaF[typing.List[Test]]

    s = SchemaF[Test]()
    t = Test("test")
    t2 = Test("test2")
    s.dump(t)
    s.dump([t, t2])
    s.loads(s.dumps(t))
    s.loads(s.dumps([t, t2]))



# Generated at 2022-06-23 16:50:34.243484
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class DataClass:
        a: int
        b: str = fields.Str(allow_none=True)

    @dataclass
    class DataClass2(DataClassJsonMixin):
        a: int
        b: str = fields.Str(allow_none=True)

    almost_correct = schema(DataClass, DataClassJsonMixin, False)
    correct = schema(DataClass2, DataClassJsonMixin, False)
    assert almost_correct == correct



# Generated at 2022-06-23 16:50:37.682435
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestampfield = _TimestampField(required=True)
    timestampfield._serialize(datetime.now(), '', None)



# Generated at 2022-06-23 16:50:38.772482
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()


# Generated at 2022-06-23 16:50:40.093619
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.data == None


# Generated at 2022-06-23 16:50:50.714486
# Unit test for constructor of class _UnionField
def test__UnionField():
    from .base import BaseSettings

    class _SimpleClass:
        def __init__(self, x):
            self.x = x

    class _SimpleClass2:
        def __init__(self, x):
            self.x = x

    class _Dataclass(BaseSettings):
        def __init__(self, x: typing.Union[_SimpleClass, typing.Optional[int],
                                           typing.Optional[_SimpleClass2]] = None):
            super().__init__()
            self.x = x

    class _Schema(_Dataclass.Schema):
        pass

    dc = _Dataclass()
    schema = _Schema(unknown='EXCLUDE')
    assert schema.dump(dc).data == {}
    assert schema.load({}).data == dc

# Generated at 2022-06-23 16:50:53.602776
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MyDataF(typing.Generic[A]):
        pass


# Generated at 2022-06-23 16:51:00.616815
# Unit test for function schema
def test_schema():
    from dataclasses_json.api import _dc2mm_schema
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import Any

    @dataclass
    class MyMixin:
        pass

    @dataclass
    class A(MyMixin):
        a: int
        b: str = ''
        c: Enum = field(init=False)
        d: Any = field(metadata={'dataclasses_json': {
            'mm_field': fields.Int(),
            'letter_case': 'lower'
        }})
        e: typing.List[Any] = field(metadata={'dataclasses_json': {
            'mm_field': fields.Int(),
            'letter_case': 'lower'
        }})


# Generated at 2022-06-23 16:51:13.875959
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from marshmallow.fields import List
    from marshmallow_enum import EnumField
    from dataclasses_json import dataclass_json, DataClassJsonMixin
    from typing import Optional, List as TList, Union

    @dataclass
    class SubThing(DataClassJsonMixin):
        a: int

    @dataclass_json
    @dataclass
    class Thing(DataClassJsonMixin):
        b: SubThing
        c: List[int]

    @dataclass
    class NonThing:
        d: SubThing
        e: List[int]

    @dataclass_json
    @dataclass
    class TopThing(DataClassJsonMixin):
        f: Thing

# Generated at 2022-06-23 16:51:14.640315
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass



# Generated at 2022-06-23 16:51:27.964078
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from typing import List
    class InnerSchema(Schema):
        id = fields.Str()
    class OuterSchema(SchemaF[List[InnerSchema]]):
        inner = fields.Nested(InnerSchema, many=True)
    outer = OuterSchema()
    print(outer.loads('{"inner": [{"id": "a"}]}'))
    # should print [{InnerSchema(strict=False): {'id': 'a'}}]
    print(outer.loads('{"inner": [{"id": "a"}, {"id": "b"}]}'))
    # should print [{InnerSchema(strict=False): {'id': 'a'}},
    #                {InnerSchema(strict=False): {'id': 'b

# Generated at 2022-06-23 16:51:39.696070
# Unit test for function build_type
def test_build_type():
    # import pytest
    from dataclasses_json.mixin import DataclassJsonMixin
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import NewType
    from typing_extensions import Literal
    from datetime import date
    import dataclasses

    @dataclasses.dataclass
    class Some(DataclassJsonMixin):
        i: int = 42
        s: str = 'spam'

    @dataclasses.dataclass
    class Some2(DataclassJsonMixin):
        i: Some

    @dataclasses.dataclass
    class Some3(DataclassJsonMixin):
        i: typing.Optional[Some]


# Generated at 2022-06-23 16:51:48.217847
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    data = SchemaF.loads(json_data=b'[{"serial": 65, "serial2": 65}]', many=False)
    assert isinstance(data, list)
    assert isinstance(data[0], dict)


# Generated at 2022-06-23 16:52:01.490175
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[int]): pass
    s = MySchema()
    assert s.loads("1", many=False) == 1
    assert s.loads("[1, 2]") == [1, 2]
    assert s.dump([1, 2]) == [1, 2]
    assert s.dump(1) == 1

SchemaF = SchemaF if sys.version_info >= (3, 7) else Schema

DC_TYPE_TO_MARSHMALLOW_FIELD = {
    UUID: fields.UUID,
    int: fields.Int,
    datetime: _IsoField,
    Decimal: fields.Decimal,
    str: fields.Str,
    bytes: fields.Bytes,
    bool: fields.Bool,
    float: fields.Float,
}


# Generated at 2022-06-23 16:52:12.389455
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A:
        x: str
        y: int
    class B(SchemaF[A]):
        x = fields.Str()
        y = fields.Int()
    a = B().loads(dict(x = 'fo', y = 42))
    assert isinstance(a, A)
    assert a.x == 'fo'
    assert a.y == 42
    b = B().loads(dict(x = 'fo', y = 42), many = True)
    assert isinstance(b[0], A)
    assert b[0].x == 'fo'
    assert b[0].y == 42

if sys.version_info >= (3, 8):
    class SchemaF(Schema, typing.Protocol):
        """Lift Schema into a type constructor"""


# Generated at 2022-06-23 16:52:19.010175
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class MySchema(SchemaF):  # type: ignore
        name = fields.Str()

    schema = MySchema()
    assert schema.load({'name': 'name'}) == {'name': 'name'}
    assert schema.load([{'name': 'name'}, {'name': 'name2'}], many=True) == [{
        'name': 'name'
    }, {'name': 'name2'}]

    class MySchema2(SchemaF):
        name = fields.Str()

    assert MySchema2.load({'name': 'name'}, many=False) == {'name': 'name'}

# Generated at 2022-06-23 16:52:27.911189
# Unit test for function build_schema
def test_build_schema():
    class Book:
        # dataclass_json_config = Config()
        title: str
        author: User

    book_schema = build_schema(Book, None, None, None)
    assert book_schema.fields == ("title", "author")
    assert issubclass(book_schema, Schema)
    # assert book_schema.Meta.render_module == global_config.json_module
    assert book_schema.Meta.strict is False

# Generated at 2022-06-23 16:52:37.469363
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class User(typing.NamedTuple):
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    test = UserSchema()

    assert test.loads('{"name": "John Doe", "age": 42}') == User(name="John Doe", age=42)
    assert test.loads('[{"name": "John Doe", "age": 42}]') == [User(name="John Doe", age=42)]


TDecoded = typing.Dict[str, typing.Any]
TOneOrMultiDecoded = typing.Union[typing.List[TDecoded], TDecoded]



# Generated at 2022-06-23 16:52:43.471825
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Color(Enum):
        RED = 'red'
        GREEN = 'green'
        BLUE = 'blue'
    dataclass = {
        '__type': 'Color',
        'value': 'red'
    }
    union_field = _UnionField({
        Color: EnumField(Color)
    }, Color, Color.__annotations__['value'])
    assert union_field._deserialize(dataclass) is Color.RED
    assert union_field._serialize(Color.RED) == dataclass



# Generated at 2022-06-23 16:52:47.143432
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField(required=False)
    field._serialize(None, "attr", None)
    field._deserialize(None, "attr", None)
    with pytest.raises(ValidationError):
        field._deserialize(None, "attr", None, required=True)
    with pytest.raises(ValidationError):
        field._serialize(None, "attr", None, required=True)



# Generated at 2022-06-23 16:53:00.477571
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow.schema import Schema as _Schema
    from marshmallow.schema import _Schema as _BaseSchema
    from marshmallow.schema import SchemaOpts
    from marshmallow_dataclass import dataclass as _dataclass
    from marshmallow_dataclass import NewType as _NewType
    from typing import List as _List
    from typing import Dict as _Dict
    from typing import Callable as _Callable
    from typing import Any as _Any
    from typing import Union as _Union
    from marshmallow_dataclass.class_registry import registry as _registry
    from marshmallow import fields as _fields
    from marshmallow import post_load as _post_load
    from marshmallow import validate as _validate
    from marshmallow.validate import ValidationError as _ValidationError

# Generated at 2022-06-23 16:53:13.140816
# Unit test for function schema
def test_schema():
    import unittest

    import dataclasses
    from dataclasses_json.mm import MmSchema

    from marshmallow_enum import EnumField
    from marshmallow.fields import Tuple

    @dataclasses.dataclass
    class Dc(MmSchema):
        a: str = dataclasses.field(metadata={'dataclasses_json': {'mm_field': None}})
        b: Enum = None

    assert isinstance(schema(Dc, dict(), True)['a'], fields.Str)
    assert isinstance(schema(Dc, dict(), True)['b'], EnumField)


# Generated at 2022-06-23 16:53:16.547600
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF.dump([1], many=True)
    assert isinstance(s, list)
    assert s[0] == 1



# Generated at 2022-06-23 16:53:19.905563
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    data = '["a"]'
    schema = SchemaF[str]()
    result1 = schema.loads(data, many=True)
    result2 = schema.loads(data)
    assert result1 == result2 == ['a']



# Generated at 2022-06-23 16:53:30.639879
# Unit test for constructor of class SchemaF
def test_SchemaF():
    def unmarshalling(json_data):
        schema = SchemaF[A]()
        return schema.loads(json_data)

    class A(typing.NamedTuple):
        a: typing.Optional[str]
        b: typing.Optional[int]

    data = unmarshalling(b'{"a": "a", "b": 100}')
    assert data.a == "a"
    assert data.b == 100

    def f(json_data) -> typing.List[A]:
        return unmarshalling(json_data)

    data = f(b'[{"a": "a1", "b": 100}]')
    assert data[0].a == "a1"
    assert data[0].b == 100



# Generated at 2022-06-23 16:53:41.013337
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class C:
        a: int

    s = SchemaF.from_dataclass(C)
    assert s.load({"a": 1}) == C(a=1)
    assert s.load([{"a": 1}]) == [C(a=1)]
    assert s.load({"a": 1}, many=True) == [C(a=1)]
    assert s.load({"a": 1}, many=False) == C(a=1)
    assert s.load([{"a": 1}], many=False) == C(a=1)

    assert s.load({"a": 1}, partial=True) == C(a=1)
    assert s.load([{"a": 1}], partial=True) == [C(a=1)]

# Generated at 2022-06-23 16:53:43.820037
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A(Enum):
        A = 1
    class _B:
        pass
    _UnionField(
        desc={int: fields.Integer, str: fields.String, A: EnumField,
              _B: fields.Field()},
        cls=int,
        field=int,
        allow_none=True)


# Generated at 2022-06-23 16:53:55.850372
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: int
        b: str
        c: List[List[int]]

    @dataclass_json
    @dataclass
    class C:
        a: int

    a_data_1: typing.Dict[str, typing.Any] = {
        'a': 1,
        'b': 'b',
    }

# Generated at 2022-06-23 16:53:59.860580
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.fromisoformat('1990-05-01'), 'field_name', None) == '1990-05-01'
    assert _IsoField()._deserialize('1990-05-01', 'field_name', None) == datetime.fromisoformat('1990-05-01')


# Generated at 2022-06-23 16:54:12.167464
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class Config:
        ini: str
    test_cls_name = "test_build_schema_Test1"
    meta_class_name = "test_build_schema_Meta"
    test_cls = type(test_cls_name, (MappingSchema,),
                    {"Meta": type(meta_class_name, (), {"fields": tuple()}),
                     "test_1": fields.Str()})
    assert test_cls_name == test_cls.__name__
    test_schema = build_schema(Config, MappingSchema, False, False)
    assert test_cls.__name__ == test_schema.__name__
    assert test_cls.Meta.__name__ == test_schema

# Generated at 2022-06-23 16:54:15.806096
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class X:
        pass
    cls = SchemaF() # type: SchemaF[X]
    cls.dump([X(), X()])
    cls.dump(X())

# Generated at 2022-06-23 16:54:27.084923
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses_json.api import mm_schema_for
    @mm_schema_for(CatchAllVar)
    class CatchAllVarSchema(Schema):
        class Meta:
            unknown = EXCLUDE
    @mm_schema_for(CatchAllVar)
    class CatchAllVarSchema(Schema):
        class Meta:
            unknown = INCLUDE
    @mm_schema_for(CatchAllVar)
    class CatchAllVarSchema(Schema):
        class Meta:
            unknown = RAISE
    @mm_schema_for(CatchAllVar)
    class CatchAllVarSchema(Schema):
        class Meta:
            unknown = 'ignore'

# Generated at 2022-06-23 16:54:31.021968
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: Union[str, int, bool] = None
    assert type(build_schema(A, None, False, False)) == type(SchemaType)


test_build_schema()

# Generated at 2022-06-23 16:54:41.120146
# Unit test for function build_type
def test_build_type():
    import unittest

    import dataclasses_json

    class Schema(dataclasses_json.Schema):
        @dataclasses_json.dataclass
        class EnumCls:
            x: typing.Optional[str]

        @dataclasses_json.dataclass
        class Optional:
            x: typing.Optional[typing.Union[int, float]]
            y: typing.Optional[typing.Union[EnumCls]]

    class TestBuildType(unittest.TestCase):
        def test_simple(self):
            schema = Schema._get_schema(Schema.EnumCls)
            self.assertIsInstance(
                schema._declared_fields['x'], EnumField)


# Generated at 2022-06-23 16:54:47.671711
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class User:
        def __init__(self, name):
            self.name = name

    class UserSchema(SchemaF[User]):
        name = fields.Str()

    us = UserSchema().loads("{\"name\": \"foo\"}")
    assert isinstance(us, User)
    assert us.name == "foo"



# Generated at 2022-06-23 16:54:50.019141
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.fromtimestamp(0), None, None) == 0



# Generated at 2022-06-23 16:54:51.838507
# Unit test for function build_type
def test_build_type():
    assert True
    assert build_type({}, {}, None, None, None)

# Generated at 2022-06-23 16:55:05.046077
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """
    Test is here mainly because of mypy warning

        Incompatible return value type (got "List[B]", expected "List[A]")

    Note: the warning is wrong
    """
    from typing import List

    class B:
        pass

    class A(B):
        pass

    s = SchemaF[A]

    x: List[A] = s.load([{"a": "a"}, {"a": "b"}], many=True)
    assert isinstance(x[0], A)
    assert isinstance(x[1], A)

    y = s.load({"a": "a"}, many=False)
    assert isinstance(y, A)

    def _test_case(obj, many):
        x = s.dump(obj, many=many)
        assert isinstance(x, List) 