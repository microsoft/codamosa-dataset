

# Generated at 2022-06-23 16:45:06.181986
# Unit test for function build_type
def test_build_type():
    assert _is_new_type(id)
    assert not _is_new_type(list)
    assert not _is_new_type(A)
    assert not _is_new_type(None)
    assert issubclass(id, object)
    assert not issubclass(id, str)
    assert issubclass(A, object)
    assert not issubclass(A, str)



# Generated at 2022-06-23 16:45:08.623815
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class SchemaF_(SchemaF[int]):
        pass

    dummy = SchemaF_()

    def a() -> None:
        return dummy.dumps([1, 2], many=True)



# Generated at 2022-06-23 16:45:17.367599
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class FooSchema(SchemaF[Foo]):
        class Meta:
            pass

    instance_field_types = {
        'bar': int
    }

    @dataclass_json(encoder=_ExtendedEncoder)
    @dataclass
    class Foo:
        bar: int

    sch = FooSchema()
    res = sch.dump(Foo(bar=1))
    assert res == {'bar': 1}
    sch = FooSchema()
    res = sch.dump([Foo(bar=1), Foo(bar=2)])
    assert res == [{'bar': 1}, {'bar': 2}]
    sch = FooSchema()
    res = sch.dump(Foo(bar=1), many=True)
    assert res == [{'bar': 1}]
#

# Generated at 2022-06-23 16:45:27.264033
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class S(SchemaF[int]):
        name = fields.String()

    # Define a dataclass
    @dataclass_json
    @dataclass
    class Person:
        name: str

    # mm has the wrong return type annotation (dict) so we can ignore the mypy error
    p = S().load(['a', 'b'])  # type: ignore
    p = S().load([{'name': 'a'}])  # type: ignore
    p = S().load({'name': 'a'})  # type: ignore
    p = S().load('f')  # type: ignore

    p = S().loads('[{"name": "a"}]')  # type: ignore
    p = S().loads('{"name": "a"}')  # type: ignore
    p = S().loads

# Generated at 2022-06-23 16:45:28.312520
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    obj: typing.List[str] = SchemaF[str].load([])

# Generated at 2022-06-23 16:45:34.007268
# Unit test for function build_type
def test_build_type():
    if sys.version_info < (3, 5, 2):
        return

    class SomeEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class DummyDataclass:
        pass

    @dataclass_json
    class NestedDataclass:
        i: int = 1


    @dataclass_json
    class DataclassMixin(DCMixin):
        field1: typing.Optional[int]


    @dataclass_json(mm_field=build_type)
    class Dataclass:
        field1: int = field(metadata={"test": "field1"})
        field2: typing.Tuple[str, int, float] = field(default_factory=lambda: ("test", 2, 3.0))

# Generated at 2022-06-23 16:45:44.078120
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    d1: typing.Dict[str, typing.Any]
    d2: typing.Dict[str, typing.Any]
    obj: typing.List[typing.Dict[str, typing.Any]]
    obj = [{'x': 'y'}, {'x': 'y'}]  # type: ignore[var-annotated]
    d1 = {'x': 'y'}
    l: typing.List[typing.Dict[str, typing.Any]]
    l = SchemaF.dump(obj, many=True)
    obj[0]['x'] = 'z'
    obj[1]['x'] = 'z'
    d2 = SchemaF.dump(d1, many=False)
    obj2 = SchemaF.dump(None, many=False)

# Generated at 2022-06-23 16:45:49.128818
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        assert isinstance(SchemaF[int](), Schema)  # type: ignore
        assert isinstance(SchemaF[int](), typing.Generic)  # type: ignore


# Generated at 2022-06-23 16:45:52.111520
# Unit test for function build_type
def test_build_type():
    import datetime
    actual = build_type(datetime.datetime, {'required': False}, None, None, None)
    assert isinstance(actual, _TimestampField)



# Generated at 2022-06-23 16:45:54.333336
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()
    assert a is not None


_new_type_registry = {}  # type: typing.Dict[UUID, typing.Type]


# Generated at 2022-06-23 16:46:04.217950
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    from dataclasses import dataclass, field

    @dataclass
    class B:
        b: int

    @dataclass
    class C:
        c: int

    A = typing.TypeVar('A')
    @dataclass
    class A(typing.Generic[A]):
        d: typing.Union[B, C] = field(metadata={'mm_field': fields.Field})

    schema = SchemaF[A](strict=True, unknown='EXCLUDE')
    assert schema.dumps(A(d=B(b=1))) == '{"d": {"b": 1}}'
    assert schema.dumps(A(d=C(c=1))) == '{"d": {"c": 1}}'


# Generated at 2022-06-23 16:46:16.385701
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # (typing.List[JsonData], bool, typing.Optional[bool], typing.Optional[str], **typing.Any) -> typing.List[A]
    # (JsonData, None, typing.Optional[bool], typing.Optional[str], **typing.Any) -> A
    # (JsonData, bool, typing.Optional[bool], typing.Optional[str], **typing.Any) -> typing.Union[typing.List[A], A]
    pass

# Generated at 2022-06-23 16:46:21.162460
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class A:
        a: int

    assert SchemaF[A].dumps([A(1)]) == '[{"a": 1}]'

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class A:
        a: int

    assert SchemaF[A].dumps(A(1)) == '{"a": 1}'


# Generated at 2022-06-23 16:46:29.831169
# Unit test for function schema
def test_schema():
    from dataclasses_json.mixin import DataclassJsonMixin

    @dataclass_json
    @dataclass
    class Nested(DataclassJsonMixin):
        x: int

    @dataclass_json
    @dataclass
    class A(DataclassJsonMixin):
        y: Nested

    @dataclass_json
    @dataclass
    class B(DataclassJsonMixin):
        y: typing.Union[Nested, list, str]

    @dataclass_json
    @dataclass
    class C(DataclassJsonMixin):
        z: typing.Optional[int]

    print(schema(A, DataclassJsonMixin, False))

# Generated at 2022-06-23 16:46:40.320526
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    assert isinstance(build_type(int, {}, None, None, None), mm.fields.Integer)
    assert isinstance(build_type(float, {}, None, None, None), mm.fields.Float)
    assert isinstance(build_type(bool, {}, None, None, None), mm.fields.Boolean)
    assert isinstance(build_type(datetime, {}, None, None, None), mm.fields.Field)
    assert isinstance(build_type(UUID, {}, None, None, None), mm.fields.UUID)
    assert isinstance(build_type(Decimal, {}, None, None, None), mm.fields.Decimal)
    assert isinstance(build_type(list, {}, None, None, None), mm.fields.List)
    assert isinstance

# Generated at 2022-06-23 16:46:49.314641
# Unit test for function build_type
def test_build_type():
    type_ = dict
    options = {'allow_none': True}
    mixin = SchemaType
    class field:
        type = type_
        name = 'test'
    # here cls is not a dataclass, so the Nested option is not applicable
    cls = int
    test_inner = build_type(type_, options, mixin, field, cls)
    assert test_inner == fields.Dict(allow_none=True)
    class cls:
        @classmethod
        def schema(cls):
            return Schema
    class test_field:
        type = cls
        name = 'test'
    test_inner_2 = build_type(cls, {}, mixin, test_field, cls)

# Generated at 2022-06-23 16:46:54.217498
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields, Schema
    import dataclasses

    @dataclasses.dataclass
    class Named:
        name: str

    class NamedSchema(SchemaF[Named]):
        name = fields.Str()

    assert NamedSchema().load({"name": "test"}) == Named("test")
    assert NamedSchema().load([{"name": "test"}, {"name": "test2"}]) == [Named("test"), Named("test2")]

# Generated at 2022-06-23 16:47:02.639441
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @DataclassJson
    @dataclass
    class Foo:
        s: str = None

    schema = SchemaF[Foo]()
    assert schema.load(
        {'s': 'foo'}) == Foo(s='foo') == schema.loads('{"s": "foo"}')

    assert schema.dump([Foo(s='foo')]) == [{'s': 'foo'}]
    assert schema.dumps([Foo(s='foo')]) == '[{"s": "foo"}]'



# Generated at 2022-06-23 16:47:12.903695
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    _SchemaF = typing.TypeVar('_SchemaF', bound=SchemaF)
    def _dummy(schema: _SchemaF):
        data: typing.List[TEncoded] = [{}]
        return schema.load(data, many=True)  # type: ignore

    class Test:
        num: int
    schema = SchemaF(Test, many=True)
    _dummy(schema)


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)


# Generated at 2022-06-23 16:47:14.159173
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF.dump(int(), int())



# Generated at 2022-06-23 16:47:14.867256
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert 1 == 1  # just so this method does not stay empty

# Generated at 2022-06-23 16:47:17.896046
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    data = {'some': 'data'}

    class MySchema(SchemaF[dict]):
        pass

    schema = MySchema()
    schema.load(data)

    assert True  # no exception was raised

    class MySchema2(SchemaF[dict]):
        pass

    schema = MySchema2()
    schema.load([data])

    assert True  # no exception was raised



# Generated at 2022-06-23 16:47:22.528500
# Unit test for constructor of class _IsoField
def test__IsoField():
  f = _IsoField()
  assert f._serialize(datetime.now(), 'attr', 'obj') != None
  assert f._deserialize('2020-12-03T10:15:30', 'attr', 'data') != None
  assert f._deserialize(None, 'attr', 'data') == None


# Generated at 2022-06-23 16:47:27.011892
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class S(SchemaF[str]):
        pass

    S().loads(b'{"a":"a"}')
    S().loads(b'{"a":"a"}', many=True)
    S().loads(b'[{"a":"a"}]', many=False)

# Generated at 2022-06-23 16:47:29.167390
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF[int]()  # type: ignore
    s.dump
    s.dumps
    s.load
    s.loads



# Generated at 2022-06-23 16:47:39.319769
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema
    from marshmallow.fields import Field

    @dataclasses.dataclass
    class Foo:
        a: int
        b: str = 'bar'
    class FooSchema(SchemaF[Foo]):
        a: Field = fields.Integer()
        b: Field = fields.String()

    schema = FooSchema()
    obj = Foo(a=1)
    data = schema.dump(obj)
    assert data == {'a': 1, 'b': 'bar'}

    objs = [Foo(a=1), Foo(a=2)]
    data = schema.dump(objs, many=True)
    assert data == [{'a': 1, 'b': 'bar'}, {'a': 2, 'b': 'bar'}]

# Generated at 2022-06-23 16:47:48.765214
# Unit test for function build_schema
def test_build_schema():
    class A:
        a = 1

    class B(A):
        b = 2

    class C(B):
        c = 3

    class D(C):
        d = 4

    class E(D):
        e = 5

    class F(E):
        f = 6

    class G(F):
        g = 7

    class H(G):
        h = 8

    class I(H):
        i = 9

    class J(I):
        j = 10

        
    @dataclass_json
    @dataclass
    class Test10(J):
        def __init__(self):
            pass

    @dataclass_json
    @dataclass
    class Test9(I):
        def __init__(self):
            pass


# Generated at 2022-06-23 16:47:57.264939
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema, fields

    class A(Schema):
        a = fields.Int()
        b = fields.Str()

    class B(Schema):
        a = fields.Str()
        b = fields.Float()

    class C(Schema):
        a = fields.Float()

    class D(Schema):
        x = fields.Int()
        y = fields.Int()

    class E(object):
        pass

    class F(Enum):
        x = 'x'
        y = 'y'

    class G(Schema):
        x = fields.Int()
        y = fields.Int()

    class H(Schema):
        x = fields.List(fields.Int())

    class I(Schema):
        x = fields.Int()


# Generated at 2022-06-23 16:48:02.019787
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class Person(SchemaF[A]):
        name = fields.Str()
        alive = fields.Bool()

    class Person1:
        name = 'John'
        alive = True

    p = Person()
    res = p.load(Person1())
    assert 'name' in res
    assert res['alive'] is True



# Generated at 2022-06-23 16:48:14.146237
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, {}, {'name': 'str'}, {}) is fields.Str
    assert isinstance(build_type(Mapping[str, int], {}, {}, {'name': 'map'}, {}),
                      fields.Mapping)
    assert isinstance(build_type(MutableMapping[str, int], {}, {}, {'name': 'map'}, {}),
                      fields.Mapping)
    assert isinstance(build_type(List[int], {}, {}, {'name': 'list'}, {}),
                      fields.List)
    assert build_type(List[int], {}, {}, {'name': 'list'}, {}) is fields.List
    assert isinstance(build_type(int, {}, {}, {'name': 'integer'}, {}),
                      fields.Int)

# Generated at 2022-06-23 16:48:15.390311
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:48:25.355683
# Unit test for constructor of class _UnionField
def test__UnionField():
    import dataclasses
    import marshmallow as ma
    from dataclasses_json.schema import Schema

    @dataclasses.dataclass
    class Banana:
        pass

    @dataclasses.dataclass
    class Apple:
        pass

    @dataclasses.dataclass
    class Fruit:
        my_fruit: typing.Union[Banana, Apple]

    @dataclasses.dataclass
    class FavoriteFruit:
        my_fruit: typing.Union[Banana, Apple, str]

    class BananaSchema(Schema):
        class Meta:
            target = Banana

    class AppleSchema(Schema):
        class Meta:
            target = Apple

    class FruitSchema(Schema):
        class Meta:
            target = Fruit


# Generated at 2022-06-23 16:48:27.370563
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:48:35.918849
# Unit test for constructor of class _UnionField
def test__UnionField():
    class S(Schema):
        id = fields.Integer()

    class N(Schema):
        id = fields.Integer()

    class A(Schema):
        id = fields.Integer()
        s = fields.Nested(S)
        n = fields.Nested(N)
        u = _UnionField({Union[S, N]: fields.Nested(S)}, 'UnionFieldTests', 'u')

    dc = A._deserialize({'id': 1, 's': {'id': 2}, 'n': {'id': 3}, 'u': {'id': 4}})
    assert dc.s.id == 2
    assert dc.n.id == 3
    assert dc.u.id == 4



# Generated at 2022-06-23 16:48:37.782859
# Unit test for function schema
def test_schema():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 16:48:45.892655
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses_json.schema import SchemaF


    @dataclass
    class Employee:
        name: str
        id: int
        department: str


    class EmployeeSchema(SchemaF[Employee]):
        name = fields.Str()
        id = fields.Int()
        department = fields.Str()


    e = Employee('John Doe', 123, 'IT')

    assert isinstance(EmployeeSchema().dump(e), dict)
    assert isinstance(EmployeeSchema().dump([e]), list)
    assert isinstance(EmployeeSchema().dump({e}), list)



# Generated at 2022-06-23 16:48:47.801407
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses.dataclass
    class TestF:
        name: str

    assert SchemaF[TestF](strict=True)



# Generated at 2022-06-23 16:48:54.113336
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    from marshmallow import fields

    from dataclasses_json.mm import MM
    from dataclasses_json import letter_case


    @dataclass
    @letter_case('snake')
    class User:
        name: str
        age: int
        friends: typing.List[str] = None


    @dataclass
    class Friend(MM):
        name: str
        age: int


    assert schema(User, MM, True) == {
        'name': fields.String(),
        'age': fields.Integer(),
        'friends': fields.List(fields.String()),
    }

    @dataclass
    class Teacher(MM):
        name: str
        age: int
        friend: Friend = None



# Generated at 2022-06-23 16:48:57.183785
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso = _IsoField()
    assert iso._deserialize("2018-12-31T10:23:59") == datetime(2018,12,31,10,23,59)


# Generated at 2022-06-23 16:49:06.156381
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import pytest
    from datetime import datetime
    from marshmallow.exceptions import ValidationError
    field = _TimestampField()
    # serialize test
    assert field._serialize(datetime.now(), None, None) is not None
    # deserialize test
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None
    # for missing value, serialize and deserialize should return None when required=False
    field.required = False
    assert field._serialize(None, None, None) is None
    assert field._deserialize(None, None, None) is None

    # raise ValidationError if value is None and required=True
    field.required = True
    with pytest.raises(ValidationError):
        field._serialize(None, None, None)


# Generated at 2022-06-23 16:49:09.310681
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(1, 1, 1) == "1"
    assert _IsoField()._deserialize(1, 1, 1) == datetime.fromisoformat("1")


# Generated at 2022-06-23 16:49:12.667026
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    dummyDate = datetime.now()
    _TimestampField()._serialize(dummyDate, "dummyDate", None)
    _TimestampField()._deserialize(dummyDate.timestamp(), "dummyDate", None)


# Generated at 2022-06-23 16:49:23.504431
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class Bar:
        i: int

    @dataclass
    class Foo:
        bar: Bar
        bars: List[Bar]

    class BarSchema(Schema):
        i = fields.Integer()

    class FooSchema(SchemaF[Foo]):
        bar = fields.Nested(BarSchema)
        bars = fields.Nested(BarSchema, many=True)

    foo_schema = FooSchema()
    foo = Foo(bar=Bar(1), bars=[Bar(1), Bar(2)])
    # check results
    res_dumps = foo_schema.dumps(foo)
    res_dumps_many = foo_schema.dumps(foo, many=True)
   

# Generated at 2022-06-23 16:49:30.834841
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses_json.api import TypedEncoder, TypedDecoder
    from typing import Union
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    class C:
        def __init__(self, c: float):
            self.c = c

    @dataclass
    class D:
        a: Union[A, B, C]

    class E(Enum):
        A = 'a'
        B = 'b'
        C = 'c'

    @dataclass
    class F:
        a: Union[int, E]

    encoder = TypedEncoder()
    decoder = TypedDecoder()

    f = F(2)
    assert f == dec

# Generated at 2022-06-23 16:49:35.378220
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing
    import marshmallow
    import pytest
    from enum import Enum
    from decimal import Decimal
    from uuid import UUID

    @dataclasses.dataclass()
    class Test:
        a: int
        b: str

    @dataclasses.dataclass()
    class Test2:
        c: Test
        d: typing.List[Test]
        e: str
        i: typing.Optional[Test]
        j: typing.List[typing.Optional[Test]]

        @dataclasses.dataclass_json(mm_field=marshmallow.fields.Decimal())
        @property
        def g(self) -> Decimal:
            return Decimal(self.e)


# Generated at 2022-06-23 16:49:46.551277
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema
    from typing import Union

    class X:
        pass

    class Y:
        pass

    class Z(X):
        pass

    ZSchema = Schema.from_dataclass(Z)
    XSchema = Schema.from_dataclass(X)
    YSchema = Schema.from_dataclass(Y)

    assert isinstance(_UnionField({Union[X, Y]: XSchema}, object, object, None),
                      _UnionField)
    assert isinstance(_UnionField({Union[X, Y]: YSchema}, object, object, None),
                      _UnionField)
    assert isinstance(_UnionField({Union[X, Y]: XSchema, Union[Z, Y]: ZSchema}, object, object, None),
                      _UnionField)



# Generated at 2022-06-23 16:49:54.528776
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        name: str
        role: str
        age: int = 0

    res = schema(Test, dataclass_json, infer_missing=False)
    assert res == {'name': fields.Str(), 'role': fields.Str(), 'age': fields.Int()}



# Generated at 2022-06-23 16:50:01.900666
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow_dataclass import dataclass as dcd

    @dataclass
    class ModelA:
        name: str

    @dcd
    @dataclass
    class ModelB(SchemaF):
        model_a: ModelA

    data = '{"model_a": {"name": "name"}}'
    result = ModelB.loads(json_data=data)
    assert isinstance(result, ModelB)


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def dump(self, obj, many=None):
            """Serialize object(s) to native Python data types."""
            return super().dump(obj, many=many)


# Generated at 2022-06-23 16:50:06.963845
# Unit test for function build_schema
def test_build_schema():
    class A():
        a: int
    
    assert len(build_schema(A, object, True, False).__dict__) == 8
    assert len(build_schema(A, object, True, False).__dict__) == 8
    assert len(build_schema(A, object, True, False).__dict__['Meta'].__dict__) == 3
    assert len(build_schema(A, object, True, False).__dict__['a'].__dict__) == 9
    assert len(build_schema(A, object, True, False).__dict__['make_a'].__closure__) == 2
    assert len(build_schema(A, object, True, False).__dict__['dump'].__closure__) == 2

# Generated at 2022-06-23 16:50:09.628619
# Unit test for function build_schema
def test_build_schema():
    from . import dataclass_json, mixin

    @dataclass_json(encoder=EncodeToFloat)
    class Person:
        name: str
        age: int = 23

    mixin.SchemaMixin.schema = build_schema(Person, mixin.SchemaMixin, False, False)
    assert issubclass(Person.schema(), SchemaType)



# Generated at 2022-06-23 16:50:20.668731
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json
    @dataclass
    class User:
        name: str
        email: str
        age: int

    assert SchemaF[User]().loads('{"name": "Foo", "email": "foo@bar.com", "age": 42}') == User('Foo', 'foo@bar.com', 42)
    assert SchemaF[User]().loads('[{"name": "Foo", "email": "foo@bar.com", "age": 42}]') == [User('Foo', 'foo@bar.com', 42)]
    assert SchemaF[User]().loads(b'{"name": "Foo", "email": "foo@bar.com", "age": 42}') == User('Foo', 'foo@bar.com', 42)
    assert SchemaF[User]().loads

# Generated at 2022-06-23 16:50:25.510279
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        attr1: str
        attr2: int = field(default=None)

    result = build_schema(Test, object, object, object)
    assert result.Meta.fields == ('attr1', 'attr2')



# Generated at 2022-06-23 16:50:34.998877
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List

    class schema_load(SchemaF[str]):
        @post_load
        def make_object(self, data, **kwargs):
            return "test"

    # test case: return type is a List
    assert isinstance(schema_load().dump(List[str](["test", "test"]), many=True), list)
    # test case: return type is a dict
    assert isinstance(schema_load().dump(List[str](["test"])[0], many=False), dict)

    # test case: return type is a List
    assert isinstance(schema_load().dump(List[str](["test", "test"])), list)
    # test case: return type is a dict

# Generated at 2022-06-23 16:50:46.883311
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # _TimestampField - serialize test
    f = _TimestampField(attribute="test")
    now = datetime.now()
    assert f._serialize(now, "test", None) == now.timestamp()
    f.required = True
    try:
        f._serialize(None, "test", None)
        assert False
    except ValidationError:
        assert True

    # _TimestampField - deserialize test
    f = _TimestampField(attribute="test")
    now = datetime.now()
    assert f._deserialize(now.timestamp(), "test", None) == _timestamp_to_dt_aware(now.timestamp())
    f.required = True

# Generated at 2022-06-23 16:50:50.347030
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import SchemaF as SF2
    from typing_extensions import Annotated
    class S3(SF2[Annotated[list, 'S3']]):
        pass



# Generated at 2022-06-23 16:50:54.641524
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    obj = ['hello']
    many = True
    res1 = SchemaF.dump(obj, many)  # type: ignore
    res2 = SchemaF.dump(obj)  # type: ignore
    assert res1 == res2 == 'hello'

# Generated at 2022-06-23 16:50:56.545361
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField() is not None


# Generated at 2022-06-23 16:51:02.240724
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    j = _TimestampField()
    dt = datetime.utcnow()
    assert dt == j._deserialize(j._serialize(dt, 'unused', 'unused'), 'unused', 'unused')

_MARSHMALLOW_SUPPORTED_BASICS = (  # type: ignore
    int, str, float, bool, bytes, type(None))



# Generated at 2022-06-23 16:51:14.710302
# Unit test for function schema
def test_schema():

    from typing import Optional, List, Dict
    from dataclasses_json import DataClassJsonMixin

    @dataclass_json
    class A(DataClassJsonMixin):
        a: Optional[int]
        b: str

    @dataclass_json
    class B(DataClassJsonMixin):
        a: List[A]
        b: Optional[Dict[str, A]]

    assert schema(A, DataClassJsonMixin, infer_missing=False) == {
        'a': fields.Int(allow_none=True, default=None),
        'b': fields.Str(allow_none=False, default=MISSING)
    }


# Generated at 2022-06-23 16:51:24.866051
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert isinstance(SchemaF.dumps(SchemaF[int](), 1, many=False), str)
    assert isinstance(SchemaF.dumps(SchemaF[int](), [1, 2, 3], many=True), str)
    assert isinstance(SchemaF.dumps(SchemaF[int](), 1), str)
    assert isinstance(SchemaF.dumps(SchemaF[int](), [1, 2, 3]), str)



# Generated at 2022-06-23 16:51:31.662209
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Test:
        i: int

    data = Test(1)
    schema = SchemaF[Test]()
    model = schema.load(schema.dump(data))
    assert data.i == model.i


# Generated at 2022-06-23 16:51:41.225840
# Unit test for function schema
def test_schema():
    '''
    Test for find_union_types
    '''
    from typing import Optional
    from tests.data import TestDataClass, TestMixed
    from tests.data_gen import gen_new_types
    from dataclasses import dataclass

    # Simple class to test, a new type is used to make sure classes are displayed properly
    @dataclass
    class TestA(TestDataClass):
        b: TestDataClass
        c: TestMixed
        d: Optional[UUID]
        e: TestMixed
        f: str

    v = TestA(TestDataClass(1, '1', dt=datetime.now()), TestMixed('test'), None, TestMixed(1), 'test')
    test_schema = Schema.from_dataclass(TestA)
    # TODO: Create

# Generated at 2022-06-23 16:51:52.406031
# Unit test for function build_schema
def test_build_schema():
    import marshmallow.fields
    assert issubclass(build_schema(Test, None, False, False),Schema)
    assert build_schema(Test, None, False, False).Meta.fields == ('b', 'a', 'c', 'd')
    assert type(build_schema(Test, None, False, False).a) == marshmallow.fields.Int
    assert type(build_schema(Test, None, False, False).b) == marshmallow.fields.Str
    assert type(build_schema(Test, None, False, False).c) == marshmallow.fields.Int
    assert type(build_schema(Test, None, False, False).d) == marshmallow.fields.Str
    assert build_schema(Test, None, False, False).__name__.capitalize() == 'TestSchema'


# Generated at 2022-06-23 16:51:54.775903
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(TypeError):
        SchemaF()



# Generated at 2022-06-23 16:51:59.540473
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json()
    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()

    person = dict(name="Monty", age=26)
    json_person = schema.loads(person)
    assert person == schema.load(person)
    assert isinstance(json_person, Person)

    people = [person, dict(name="Monty", age=26)]
    json_people = schema.loads(people)
    assert people == schema.load(people)
    assert isinstance(json_people[0], Person)



# Generated at 2022-06-23 16:52:06.508560
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    x: typing.List[int] = [1, 2, 3]
    x_serialized = SchemaF.dump(x)  # type: ignore
    assert(isinstance(x_serialized, list))
    y: int = 42
    y_serialized = SchemaF.dump(y)  # type: ignore
    assert(isinstance(y_serialized, int))

# Generated at 2022-06-23 16:52:07.990396
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-23 16:52:15.875561
# Unit test for constructor of class _IsoField
def test__IsoField():
    with pytest.raises(ValidationError):
        _IsoField()._deserialize(None, None, None)
    assert _IsoField(required=False)._deserialize(None, None, None) == None
    assert _IsoField(required=False)._deserialize(
        "2020-07-11T07:06:05.123456", None, None
    ) == datetime(2020, 7, 11, 7, 6, 5, 123456)



# Generated at 2022-06-23 16:52:29.462288
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    # Test serialization
    assert f._serialize(datetime.utcnow(), 'attr', None)
    assert f._serialize(None, 'attr', None, required=False)
    # Test deserialization
    assert f._deserialize(datetime.utcnow().timestamp(), 'attr', None)
    assert f._deserialize(None, 'attr', None, required=False)
    # Test required
    try:
        f._serialize(None, 'attr', None, required=True)
    except ValidationError:
        pass
    else:
        assert False
    try:
        f._deserialize(None, 'attr', None, required=True)
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:52:39.507854
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF):
        pass

    with pytest.raises(NotImplementedError):
        MySchema()

# Generated at 2022-06-23 16:52:42.181716
# Unit test for constructor of class _IsoField
def test__IsoField():
    date = datetime.now()
    date_str = date.isoformat()
    date2 = datetime.fromisoformat(date_str)
    assert date2 == date


# Generated at 2022-06-23 16:52:52.165268
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow_dataclass as mm
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        num: int = 0

    @dataclass
    class Bar:
        f: int
        s: int

    @dataclass
    class B:
        num: int
        n: float
        foo: Foo
        bar: Bar
        list: List[int]

    sf = mm.SchemaF[B]()
    b = sf.load({"num": 1, "n" : 1.0, "foo" : {"num": 1}, "bar" : {"f": 1, "s" : 2}, "list" : [1, 2]})
    assert b.num == 1
    assert b.n == 1.0

# Generated at 2022-06-23 16:53:01.274793
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass(order=True)
    class Obj:
        v: int

    sf = SchemaF[Obj](  # type: ignore
        strict=True,
        encoder=_ExtendedEncoder(
            use_enum_values=True,
            unknown=lambda x: f'<unknown type: {type(x)}>'),
        error_messages={'required': 'The field is required.'})
    objs = [Obj(1), Obj(2), Obj(3)]
    result = sf.dump(objs)
    assert len(result) == 3



# Generated at 2022-06-23 16:53:13.270683
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm import MM

    @dataclass_json
    @dataclass(frozen=True)
    class A:
        a: int
        b: str = 'b'
        c: bool = False

    assert schema(A, MM, False) == {'a': fields.Int(missing=MISSING),
                                    'b': fields.Str(missing='b'),
                                    'c': fields.Bool(missing=False)}

    assert schema(A, MM, True) == {'a': fields.Int(missing=MISSING),
                                   'b': fields.Str(missing='b'),
                                   'c': fields.Bool(missing=False)}

    @dataclass_json
    @dataclass(frozen=True)
    class A:
        a: typing.Optional

# Generated at 2022-06-23 16:53:22.009245
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.deserialize(None)
    field.deserialize(0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)
    field.deserialize(0.0)




# Generated at 2022-06-23 16:53:30.592738
# Unit test for function build_type
def test_build_type():
    options = {}
    mixin = ""
    field = ""
    cls = ""
    type_ = typing.Any
    assert build_type(type_, options, mixin, field, cls) == fields.Raw
    type_ = typing.Optional[typing.Optional[str]]
    assert build_type(type_, options, mixin, field, cls) == fields.Str(**{"allow_none": True})
    type_ = typing.List[typing.List[str]]
    assert build_type(type_, options, mixin, field, cls) == fields.List(fields.List(fields.Str))
    type_ = typing.List[int]
    assert build_type(type_, options, mixin, field, cls) == fields.List(fields.Int)
    type_ = typing.Union

# Generated at 2022-06-23 16:53:41.013713
# Unit test for function schema
def test_schema():
    """
    If a field is marked as CatchAllVar type, then it should be ignored.
    :return:
    """
    from typing import Dict, Any
    from dataclasses import dataclass
    from dataclasses_json.mm import M


    @dataclass
    class CatchAllVarClass:
        class_field: CatchAllVar = {}
        class_optional_dict: Dict[Any, Any] = '{}'

    @dataclass
    class A(M):
        class_field: CatchAllVar = {}
        class_optional_dict: Dict[Any, Any] = '{}'
        class_dict: Dict[Any, Any] = '{}'

    assert schema(A, M, False) == {}

# Generated at 2022-06-23 16:53:49.118003
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import SchemaF
    from marshmallow import fields

    class UserSchema(SchemaF):
        name = fields.Str()
        age = fields.Int()

    user = UserSchema().load(dict(name='John', age=42))
    assert user.name == 'John'
    assert user.age == 42
    dumps = UserSchema().dump(user)
    assert dumps == {'name': 'John', 'age': 42}
    users = UserSchema(many=True).load([dict(name='John'), dict(name='James')])
    assert isinstance(users, list)
    assert all(u.name in ('John', 'James') and isinstance(u.age, int) for u in users)
    loads = UserSchema(many=True).dump(users)


# Generated at 2022-06-23 16:53:51.428821
# Unit test for constructor of class _IsoField
def test__IsoField():
    value = datetime.now()
    i = _IsoField()
    assert (i._serialize(value, None, None) == value.isoformat())
    assert (i._deserialize(value.isoformat(), None, None) == value)


# Generated at 2022-06-23 16:53:52.910468
# Unit test for constructor of class _IsoField
def test__IsoField():  # TODO
    x = _IsoField
    assert 1==1



# Generated at 2022-06-23 16:54:02.072579
# Unit test for function build_type
def test_build_type():
    T = typing.TypeVar('T')
    T1 = typing.NewType('T1', int)
    T2 = typing.NewType('T1', T1)
    T3 = typing.NewType('T1', T2)
    T4 = typing.NewType('T1', T3)
    assert build_type(T3, {}, None, None, None)(int, {}).__class__ == fields.Int
    assert build_type(typing.List[T3], {}, None, None, None)(
        int, {}).__class__ == fields.List
    assert build_type(typing.Optional[T3], {}, None, None,
                      None)(int, {}).__class__ == fields.Int

# Generated at 2022-06-23 16:54:15.053280
# Unit test for function build_schema
def test_build_schema():
    class TestMixin:
        pass
    @dataclass_json(letter_case=LetterCase.CAMEL)
    @dataclass
    class TestDC:
        int_field: int = 0
        str_field: str = 'hello'
        list_field: typing.List[int] = []
        list_field_none: typing.List[int] = None
        optional_dataclass: typing.Optional[datetime.datetime] = None
        union_field: typing.Optional[typing.Union[int, str]] = None
        any_field: typing.Any = None
        mapping_field: typing.Mapping[str, int] = {}
        optional_mapping_field: typing.Optional[typing.Mapping[str, int]] = None

# Generated at 2022-06-23 16:54:25.611769
# Unit test for function build_type
def test_build_type():
    assert str(build_type(list, {}, 0, 0, 0)) == '<class \'marshmallow.fields.List\'>'
    assert str(build_type(int, {}, 0, 0, 0)) == '<class \'marshmallow.fields.Integer\'>'
    assert str(build_type(float, {}, 0, 0, 0)) == '<class \'marshmallow.fields.Float\'>'
    assert str(build_type(str, {}, 0, 0, 0)) == '<class \'marshmallow.fields.String\'>'
    assert (str(build_type(typing.Optional[str], {}, 0, 0, 0))
        == '<class \'marshmallow.fields.String\'>')



# Generated at 2022-06-23 16:54:31.326852
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    class Example(SchemaF):
        bool_field = fields.Bool()
    assert Example.dump([{'bool_field': True}, {'bool_field': False}], many=True) == [{'bool_field': True}, {'bool_field': False}]
    assert Example.dump({'bool_field': True}, many=False) == {'bool_field': True}


# Generated at 2022-06-23 16:54:32.397511
# Unit test for function build_type
def test_build_type():
    assert True
# End def test_build_type


# Generated at 2022-06-23 16:54:41.824549
# Unit test for method loads of class SchemaF
def test_SchemaF_loads(): # type: ignore
    class Test(TypedSchemaF[int]):
        pass
    schema = Test()
    response = schema.loads('[1]', many=True)  # type: ignore
    assert response == [1]



# Generated at 2022-06-23 16:54:46.653336
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Test_SchemaF(SchemaF[A]):
        pass


    obj: A = Test_SchemaF().loads('')

    assert isinstance(Test_SchemaF().dumps(obj), str)
    # Unit test for method loads of class SchemaF

# Generated at 2022-06-23 16:54:49.020812
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(None, "", "") is None



# Generated at 2022-06-23 16:54:53.473457
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class M(SchemaF[str]):
        pass  # pass

    # type: dict
    obj = M().dump(["a"])
    # type: dict
    obj = M().dump("a")
    # type: list[dict]
    obj = M().dump(["a"], many=True)


# Generated at 2022-06-23 16:55:06.120824
# Unit test for constructor of class _UnionField
def test__UnionField():
    import pytest

    class DummySchema(Schema):
        a = fields.List(fields.Int())
        b = fields.Int()

    class DummyClass:
        pass

    @dataclasses.dataclass
    class DCClass:
        pass
    dc_cls = DCClass()
    DCSchema = _decode_dataclass(DCClass)
    with pytest.raises(Exception):
        _UnionField({int: DummyClass()}, '', '')
    with pytest.raises(Exception):
        _UnionField({list: DummyClass()}, '', '')
    with pytest.raises(Exception):
        _UnionField({int: DummyClass}, '', '')