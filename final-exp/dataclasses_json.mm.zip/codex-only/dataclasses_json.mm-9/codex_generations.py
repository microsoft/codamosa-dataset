

# Generated at 2022-06-23 16:45:03.557712
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[str]):
        field: str

    TestSchema().load({"field": "value"})
    TestSchema().load([{"field": "value1"}, {"field": "value2"}])
    TestSchema().load([{"field": "value1"}, {"field": "value2"}], many=True)
    TestSchema().load([{"field": "value1"}, {"field": "value2"}], many=False)



# Generated at 2022-06-23 16:45:11.154014
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields, post_load

    @post_load
    def make_user(self, data, **kwargs):
        return User(**data)


    class User:
        def __init__(self, name, email):
            self.name = name
            self.email = email


    class UserSchema(Schema):
        name = fields.Str()
        email = fields.Email()


    schema = SchemaF[User](schema_cls=UserSchema, post_load=make_user)

    u = schema.loads('{"name": "Monty", "email": "monty@python.org"}')
    assert isinstance(u, User)

    schema.dump(u)
    assert isinstance(u, User)


# Generated at 2022-06-23 16:45:14.758691
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema
    from dataclasses_json.schema import SchemaF

    class S(Schema): pass

    s: SchemaF[List[int]] = S()
    s.dump([1, 2])

# Generated at 2022-06-23 16:45:24.666787
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    import marshmallow


    @dataclasses.dataclass
    class SomeSchema(SchemaF[SomeData]):

        @marshmallow.post_load
        def make_object(self, data: SomeData) -> ClassData:
            # type: () -> None
            return ClassData(data['num'])


    @dataclasses.dataclass
    class SomeData:
        num: int


    @dataclasses.dataclass
    class ClassData:
        num: int


    d = SomeData(12)
    s = SomeSchema()
    assert s.load(dataclasses.asdict(d)) == ClassData(12)
    assert s.load([dataclasses.asdict(d)]) == [ClassData(12)]
    assert s.load

# Generated at 2022-06-23 16:45:29.025352
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    s = FooSchema()

    data_single = {"one": 1}
    data_multiple = [{"one": 1}, {"two": 2}]
    assert s.load(data_single) is not None
    assert s.load(data_multiple) is not None
    assert s.many



# Generated at 2022-06-23 16:45:36.032681
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert(_TimestampField()._deserialize(1574660081, "foo", {"bar": "baz"}) == datetime(2019, 11, 25, 17, 48, 1))
    assert(_TimestampField()._serialize(datetime(2019, 11, 25, 17, 48, 1), "foo", {"bar": "baz"}) == 1574660081)


# Generated at 2022-06-23 16:45:39.953998
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.serialize(
        datetime.now(), 'new_datetime', None, strict=True) is not None
    assert field.deserialize(
        datetime.now().timestamp(), 'new_datetime', None, strict=True) is not None



# Generated at 2022-06-23 16:45:49.643571
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class Foo:
        foo: int

    class FooSchema(SchemaF[Foo]):
        foo = fields.Int()

        @post_load
        def make_foo(self, data):
            return Foo(**data)

    @dataclasses.dataclass
    class Bar:
        bar: int

    class BarSchema(SchemaF[Bar]):
        bar = fields.Int()

        @post_load
        def make_bar(self, data):
            return Bar(**data)

    foo = Foo(foo=1)
    bar = Bar(bar=2)
    assert foo == FooSchema().load(FooSchema().dump(foo))
    assert bar == BarSchema().load(BarSchema().dump(bar))



# Generated at 2022-06-23 16:45:57.863144
# Unit test for function schema
def test_schema():
    import dataclasses
    from dataclasses_json.mm import MMList, MMObject
    from marshmallow import fields
    from typing import Optional

    @dataclasses.dataclass
    class User(MMObject):
        name: str
        is_active: bool
        age: Optional[int]
        color: str = 'red'

    @dataclasses.dataclass
    class UserSchema(schema(User, MMObject, True)):
        users: MMList[User]



    assert {'name': fields.String, 'is_active': fields.Boolean, 'age': fields.Integer,
            'color': fields.String, 'users': fields.List} == UserSchema.__dict__



# Generated at 2022-06-23 16:46:07.989454
# Unit test for function build_schema
def test_build_schema():
    import unittest
    import datetime
    @dataclass_json
    @dataclass
    class Cls:
        id: int

    class TestBuildSchema(unittest.TestCase):
        def test_build_schema(self):
            schema = build_schema(Cls, object, True, True)
            obj = Cls(id=1)
            s = schema()
            data = s.dump(obj)
            self.assertEqual(data, {'id': 1})
            schema_obj = schema()
            data = schema_obj.dumps(obj)
            self.assertEqual(data, '{"id": 1}')

    unittest.main()


# Generated at 2022-06-23 16:46:09.827571
# Unit test for constructor of class _IsoField
def test__IsoField():
    if _IsoField() is not None:
        pass


# Generated at 2022-06-23 16:46:14.397498
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    @dataclass
    class P:
        i: int
    class S(SchemaF[P]):
        i = fields.Integer()
    S().load([{'i':4}], many=True) == [P(i=4)]

# Generated at 2022-06-23 16:46:18.395848
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    if not field:
        raise AssertionError("Expecting True, actual False")


# Generated at 2022-06-23 16:46:28.571205
# Unit test for function schema
def test_schema():  # NOQA
    # import sys
    # sys.path.insert(0, '..')
    from typing import Dict, Tuple
    from dataclasses import dataclass, field

    @dataclass
    class Address:
        street: str
        number: int

    @dataclass
    class Person:
        name: str
        age: int
        address: Address
        _email: str = field(metadata={'dataclasses_json': {
            'mm_field': fields.Email()}})

    assert schema(Person, None, False) == {
        'name': fields.Str(),
        'age': fields.Int(),
        'address': fields.Nested(schema(Address, None, False)),
        '_email': fields.Email()
    }


# Generated at 2022-06-23 16:46:31.337979
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        test: int
        test_2: int
        test_3: int
    assert build_schema(Test, None, None, None)

# Generated at 2022-06-23 16:46:40.006768
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class InnerTestClass(typing.Generic[A]):
        def schema_f_dump(self, schema: SchemaF[A]) -> TOneOrMultiEncoded:
            return SchemaF(self.get_schema()).dump(self.get_data())

    class TestClass(InnerTestClass[str]):
        def get_schema(self) -> Schema:
            return Schema()

        def get_data(self) -> TOneOrMulti:
            return "test"

    test = TestClass()
    test.schema_f_dump(SchemaF(test.get_schema()))


# Generated at 2022-06-23 16:46:49.079964
# Unit test for function build_type
def test_build_type():
    from typing import List, Dict, Tuple, Callable, Optional
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json(mm_field=fields.Int, unknown='raise')
    @dataclass
    class B:
        b: int

    @dataclass_json(mm_field=fields.UUID)
    @dataclass
    class C:
        c: UUID

    @dataclass_json
    @dataclass
    class D:
        d: List[int]

    @dataclass_json(mm_field=fields.Str)
    @dataclass
    class E:
        e: Optional[int]


# Generated at 2022-06-23 16:47:01.157816
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import cast
    from dataclasses import dataclass
    from marshmallow import Schema as SchemaBase

    @dataclass
    class Foo:
        pass

    @dataclass
    class Bar:
        pass

    @dataclass
    class Baz:
        foo: Foo
        bar: Bar

    class FooSchema(SchemaF[Foo]):
        pass

    class BarSchema(SchemaF[Bar]):
        pass

    class BazSchema(SchemaF[Baz]):
        foo: FooSchema
        bar: BarSchema

    foo = Foo()
    bar = Bar()
    baz = Baz(foo, bar)
    baz.bar = bar
    baz.foo = foo

    assert isinstance(BazSchema(), SchemaBase)
    assert isinstance

# Generated at 2022-06-23 16:47:11.111881
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json(letter_case=LetterCase.CAMEL)
    @dataclass
    class DataClass:
        name: str = 'my_name'
        count: int = 0
        item: typing.Mapping[str, int] = field(default_factory=dict)
        flag: bool = False
    schema = build_schema(DataClass, 'mixin', False, True)
    assert isinstance(schema().fields['name'], fields.String)
    assert isinstance(schema().fields['count'], fields.Integer)
    assert isinstance(schema().fields['item'], fields.Dict)
    assert isinstance(schema().fields['flag'], fields.Boolean)

# Generated at 2022-06-23 16:47:15.548022
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class MySchema(SchemaF[int]):
        pass
    schema = MySchema()
    input_data = [1]
    result : typing.List[int] = schema.load(input_data)
    assert result == [1]

# Generated at 2022-06-23 16:47:21.280854
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class Foo:
        i: int

    class FooSchema(SchemaF[Foo]):
        i = fields.Int(required=True, load_from='i', dump_to='i')

    foo = Foo(1)
    # i: int is expected to be dumped as 'i': 1
    assert FooSchema().dump(foo) == {'i': 1}

    foo = [Foo(1), Foo(2)]
    # [Foo(1), Foo(2)] is expected to be dumped as '[{'i', 1}]
    assert FooSchema().dump(foo) == [{'i': 1}, {'i': 2}]

# Generated at 2022-06-23 16:47:27.515300
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = _TimestampField()
    assert ts.deserialize(1574804401.0) == datetime(2019, 11, 26, 10, 40, 1)
    assert ts.serialize(datetime(2019, 11, 26, 10, 40, 1)) == 1574804401.0
    assert ts.serialize(None) == None
    assert ts.deserialize(None) == None


# Generated at 2022-06-23 16:47:38.654554
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema
    from marshmallow_dataclass import NewType
    from dataclasses import dataclass

    class MySchemaF(SchemaF[A]):
        pass

    class MyNewTypeSchemaF(SchemaF[A]):
        pass

    @dataclass
    class X1:
        a: int
        b: str
    class X1Schema(Schema):
        a = fields.Int()
        b = fields.Str()

    @dataclass
    class X2:
        c: float
        d: typing.List[int]
    class X2Schema(Schema):
        c = fields.Float()
        d = fields.List(fields.Int())

    @dataclass
    class X3:
        e: UUID
        f: typing.D

# Generated at 2022-06-23 16:47:48.551682
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Function test_SchemaF_loads Example 1
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        blah = fields.Field()

        @post_load
        def make_foo(self, data, **kwargs) -> Foo:
            return Foo()

    FooSchema().loads('{}')

    # Function test_SchemaF_loads Example 2
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        blah = fields.Field()

        @post_load
        def make_foo(self, data, **kwargs) -> Foo:
            return Foo()

    FooSchema().loads('{}', many=True)

    # Function test_SchemaF_loads Example 3
    class Foo:
        pass


# Generated at 2022-06-23 16:47:51.660601
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps(2) == '2'
    assert SchemaF[typing.List[int]].dumps([1, 2]) == '[1, 2]'



# Generated at 2022-06-23 16:47:55.477928
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime(2020, 1, 1), 'attr', 'obj', **{}) == 1577836800.0
    assert field._deserialize(1577836800.0, 'attr', 'data', **{}) == datetime(2020, 1, 1)


# Generated at 2022-06-23 16:48:06.285014
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    # test single nested __call__
    @dataclass
    class A:
        data: str

    class B:
        pass

    @dataclass
    class C:
        data: Union[A, B]

    try:
        class CS(Schema):
            data = _UnionField(C, C.__annotations__['data'])
    except Exception as e:
        raise RuntimeError(e)

    # test __call__ nested in flatten
    @dataclass
    class D:
        data: str

    class E:
        pass

    @dataclass
    class F:
        data: Union[A, E]


# Generated at 2022-06-23 16:48:12.406008
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TestSchema(Schema):
        t1 = _UnionField(
            desc={int: fields.Integer()}, cls=None, field=None, allow_none=False)

    assert TestSchema().load({'t1': 1}).data['t1'] == 1

DICT_TYPE = typing.Dict[typing.Any, typing.Any]

if typing.TYPE_CHECKING:
    from typing import Any, Callable, Generic, List, Optional, Tuple, TypeVar

    T = TypeVar('T', bound='CustomType')  # noqa: F811



# Generated at 2022-06-23 16:48:23.622701
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField(required=False)
    assert field._serialize(None, None, None) == None
    assert field._deserialize(None, None, None) == None

    field = _TimestampField(required=True)
    try:
        field._serialize(None, None, None)
    except ValidationError as e:
        assert True
    except:
        assert False
    try:
        field._deserialize(None, None, None)
    except ValidationError as e:
        assert True
    except:
        assert False

    # Add timestamp
    import time
    current_time = time.time()
    assert field._serialize(current_time, None, None) == current_time
    assert field._deserialize(current_time, None, None) == current_time

    # Add

# Generated at 2022-06-23 16:48:32.553370
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Person(SchemaF):
        name = fields.String()

    assert Person().load({'name': 'test'}) == {'name': 'test'}
    assert Person().load({'name': 'test'}, many=False) == {'name': 'test'}
    assert Person().load({'name': 'test'}, many=True) == [{'name': 'test'}]
    # Unit test for method loads of class SchemaF
    assert Person().loads('{"name": "test"}') == [{'name': 'test'}]
    assert Person().loads('{"name": "test"}', many=False) == {'name': 'test'}
    assert Person().loads('{"name": "test"}', many=True) == [{'name': 'test'}]


# Generated at 2022-06-23 16:48:41.731877
# Unit test for function schema
def test_schema():
    class Person(SchemaType):
        __dataclass_json__ = dataclasses_json.DataClassJsonMixin
        name: typing.Optional[str]
        age: int = 1
        loc: typing.Optional[typing.Dict[str,str]]

    assert schema(Person, Person.__dataclass_json__, True) == {
        'name': fields.Field(allow_none=True),
        'age': fields.Field(missing=1, allow_none=True),
        'loc': fields.Field(allow_none=True)
    }



# Generated at 2022-06-23 16:48:42.300244
# Unit test for function schema
def test_schema():
    pass

# Generated at 2022-06-23 16:48:43.294066
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    pass


# Generated at 2022-06-23 16:48:50.606756
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class TestData:
        foo: Optional[int] = None
        bar: Dict[UUID, str] = {}
        baz: typing.List[int] = field(default_factory=list)
        test: Optional[typing.List[UUID]] = None
        optional_uuid: Optional[UUID] = None
        uuid: UUID = UUID('000000000000000000000000000000')
        # bare: Tuple = field(default_factory=tuple)
        bare: Tuple[int, str] = field(default_factory=tuple)
        bare_list: List = field(default_factory=list)
        bare_dict: Dict = field(default_factory=dict)
        some_dict: Dict[str, Any] = field

# Generated at 2022-06-23 16:48:58.464830
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class MySchema(SchemaF[int]):
        pass

    MySchema(many=True).dump([1, 2, 3])
    MySchema(many=False).dump(1)
    MySchema().dump([1, 2, 3])
    MySchema().dump(1)
    MySchema().dump(1, many=False)
    MySchema().dump([1, 2, 3], many=True)


# Generated at 2022-06-23 16:48:59.807619
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-23 16:49:11.106021
# Unit test for function build_type
def test_build_type():
    import pytest
    from dataclasses import dataclass, is_dataclass
    from typing import Optional, Union, TypeVar

    @dataclass
    class Base:
        pass

    @dataclass
    class String(Base):
        pass

    @dataclass
    class OptionalString(Base):
        pass

    @dataclass
    class UnionString(Base):
        pass

    @dataclass
    class NormalString(Base):
        pass

    @dataclass
    class NormalList(Base):
        pass

    @dataclass
    class UnionList(Base):
        pass

    @dataclass
    class OptionalList(Base):
        pass

    @dataclass
    class OptionalUnionList(Base):
        pass

    class Options:
        mm_field = build_type


# Generated at 2022-06-23 16:49:13.247513
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List, {}, Schema, "field", "cls") == fields.List



# Generated at 2022-06-23 16:49:20.656089
# Unit test for function build_schema
def test_build_schema():
    from inputoutput_utils import seurlize_string
    mixin = SchemaMixin
    infer_missing = True
    partial = True
    class Category(enum.Enum):
        A = 'A'
        B = 'B'

    config2 = dataclass_json.config.Config(
        datetime=options.TimeStamp(),
        date = options.TimeStamp("%m/%d/%Y"),
        na_filter=True,
        orm_mode=True,
        letter_case=options.LetterCase.CAMEL,
        validate_schema=True,
        encoders={Category: lambda c: c.name},
        decoders={'Category': lambda v: Category(v['value'])}
    )


# Generated at 2022-06-23 16:49:24.730796
# Unit test for constructor of class _IsoField
def test__IsoField():
    import datetime
    str_date = _IsoField()._deserialize('2016-07-08', 'attr')
    assert isinstance(str_date, datetime.datetime)
    date = _IsoField()._deserialize(datetime.datetime(2016, 7, 8), 'attr')
    assert isinstance(date, datetime.datetime)



# Generated at 2022-06-23 16:49:27.500210
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0)



# Generated at 2022-06-23 16:49:36.451915
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str = fields.Str(required=True)

    @SchemaF.from_dataclass
    class PersonSchema(Schema):
        pass

    p = Person('John')
    p_str = PersonSchema().dumps(p)
    assert p_str == '{"name": "John"}'
    assert PersonSchema().dumps([p]) == '[{"name": "John"}]'



# Generated at 2022-06-23 16:49:42.569512
# Unit test for function schema
def test_schema():
  from dataclasses import dataclass
  from dataclasses_json.mm import Config
  @dataclass(config=Config)
  class Test:
    name: str
    age: int

# Generated at 2022-06-23 16:49:50.952887
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class cls:
        my_field: str = "my string"
        my_int: int = 5

    mixin = type('Mixin', (), {})
    schema = build_schema(cls, mixin, False, False)
    schema_obj = schema()
    schema_obj.dumps(cls())
    schema_obj.dumps([cls()])
    schema_obj.dump(cls())
    schema_obj.dump([cls()])

# Generated at 2022-06-23 16:49:55.316702
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None) != 0
    assert _TimestampField()._serialize(None, None, None) is None
    assert _TimestampField()._deserialize(10, None, None) is not None
    assert _TimestampField()._deserialize(None, None, None) is None


# Generated at 2022-06-23 16:49:57.052821
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.deserialize(None) is None



# Generated at 2022-06-23 16:50:07.609527
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class A:
        a: int

    # def test_SchemaF_dumps(self):
    schema = SchemaF[A].schema_class()
    obj = A(a=10)
    assert schema.dumps(obj, many=False) == '{"a": 10}'
    obj = [A(a=10), A(a=20)]
    assert schema.dumps(obj, many=True) == '[{"a": 10}, {"a": 20}]'

    # def test_SchemaF_dumps_wrong_input(self):
    with pytest.raises(TypeError):
        schema.dumps('a', many=False)

    # def test_SchemaF_dumps_wrong_input_many(self):

# Generated at 2022-06-23 16:50:09.705439
# Unit test for constructor of class _IsoField
def test__IsoField():
    actual_value = _IsoField()
    expected_value = fields.Field()
    assert actual_value.__class__ is expected_value.__class__


# Generated at 2022-06-23 16:50:11.897139
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        class DummySchema(SchemaF):
            pass



# Generated at 2022-06-23 16:50:14.338031
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField.__init__.__code__.co_argcount == 5, \
        'Constructor of class _UnionField should have five arguments'



# Generated at 2022-06-23 16:50:21.202892
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    test_datetime = datetime.now()
    serialized_value = field.__serialize__(test_datetime, 'attr', 'obj')
    deserialized_value = field.__deserialize__(serialized_value, 'attr', 'data')
    assert isinstance(deserialized_value, datetime)
    assert deserialized_value == test_datetime



# Generated at 2022-06-23 16:50:25.236927
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: str
        b:int

    @dataclass
    class B:
        b: A

    c = schema(B, {}, False)
    print(c)



# Generated at 2022-06-23 16:50:33.012860
# Unit test for constructor of class _UnionField
def test__UnionField():
    def _serialize(self, obj, *args, **kwargs):
        return 1

    def _deserialize(self, value, *args, **kwargs):
        return 1
    field = fields.Field()
    field._serialize = _serialize
    field._deserialize = _deserialize
    desc = {int: field, str: field}
    cls = int
    cls_field = str
    union_field = _UnionField(desc, cls, cls_field)
    assert union_field is not None



# Generated at 2022-06-23 16:50:45.403586
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    from marshmallow import fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        first_name: str
        last_name: str
        age: int

    @dataclass
    class Book:
        title: str
        author: Person
        price: float
        tags: list

    class PersonSchema(mm.Schema):
        first_name = mm.fields.Str()
        last_name = mm.fields.Str()
        age = mm.fields.Int()
        # def __init__(self, *args, **kwargs):
        #     super(PersonSchema, self).__init__(*args, **kwargs)

    class BookSchema(mm.Schema):
        title = mm.fields.Str()

# Generated at 2022-06-23 16:50:53.029081
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[int].loads("1") == 1
    assert SchemaF[int].loads("1", many=False) == 1
    assert SchemaF[int].loads("1", many=True) == [1]
    assert SchemaF[int].loads(b"1") == 1
    assert SchemaF[int].loads(b"1", many=False) == 1
    assert SchemaF[int].loads(b"1", many=True) == [1]


# Generated at 2022-06-23 16:50:53.673436
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-23 16:51:00.907989
# Unit test for function build_type
def test_build_type():
    class Foo:
        pass

    class Foo2(Foo):
        pass

    class Foo3(Foo2):
        pass

    class Bar:
        pass

    class Bar2(Bar):
        pass

    class Test:
        def __init__(self, test):
            self.test = test

        @property
        def test2(self):
            return 'test2'

    class C:
        class D:
            pass

        class E(D):
            pass

    class Serializable:
        def _serialize(self, *args, **kwargs):
            return self.__dict__

        def _deserialize(self, *args, **kwargs):
            return self

    class Serializable2(Serializable):
        pass

    class Serializable3(Serializable2):
        pass


# Generated at 2022-06-23 16:51:04.808755
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    s = SchemaF.dumps(1,2)
    assert s == '2'


# Generated at 2022-06-23 16:51:08.480060
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from datetime import datetime
    # Deserialize
    ts = _TimestampField()
    assert ts._deserialize(1593539222.495546, "attr", {}) == \
        datetime(2020, 6, 30, 15, 47, 2, 495546)
    # Serialize
    ts = _TimestampField()
    assert ts._serialize(datetime(2020, 6, 30, 15, 47, 2, 495546), "attr", {}) == \
        1593539222.495546



# Generated at 2022-06-23 16:51:18.931036
# Unit test for function build_schema
def test_build_schema():
    from datetime import datetime
    from marshmallow.fields import Dict, List
    from dataclasses_json.api import Schema

    @dataclass
    class TestA:
        a: int
        b: str

    @dataclass
    class Test:
        a: List[str]
        b: List[TestA]
        c: int

    class M:
        dataclass_json_config: dict = dict(
            unknown="EXCLUDE",
            meta=dict(
                fields=("a", "b", "c")
            )
        )

    s = build_schema(Test, M, True, False)
    assert s.Meta.fields == ('a', 'b', 'c')
    assert type(s.a) == List
    assert type(s.b) == fields.N

# Generated at 2022-06-23 16:51:28.074419
# Unit test for function build_type
def test_build_type():
    # Test Union
    assert hasattr(build_type(typing.Union[int, str], {}, None, None, None)(
                   typing.Union[int, str], {}), 'field')
    # Test Optional
    assert build_type(typing.Optional[int], {}, None, None, None)(
        typing.Optional[int], {}).allow_none
    # Test dataclass
    assert isinstance(build_type(typing.List[int], {'field_many': True}, None, None, None)(
        typing.List[int], {'field_many': True}), fields.List)


# Generated at 2022-06-23 16:51:39.771552
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    class MySchema(SchemaF[str]):
        name = fields.Str()
    obj = [MySchema().dump(x) for x in ["foo", "bar"]]
    obj = MySchema().load(obj)
    assert obj == ["foo", "bar"]


if sys.version_info >= (3, 7):
    class Mapping(SchemaF[A]):
        """Lifts Mapping type defined in typing to have correct types"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:51:44.928538
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass

    _UnionField({A: fields.Field, D: fields.Field}, None, None)
    _UnionField({A: fields.Field, D: fields.Field, 1: fields.Field}, None, None)
    try:
        _UnionField({B: fields.Field, C: fields.Field}, None, None)
        assert False
    except TypeError:
        pass
    try:
        _UnionField({E: fields.Field, F: fields.Field}, None, None)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-23 16:51:53.595591
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Any, List
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    import dataclasses
    from dataclasses import dataclass
    from dataclasses_json.schema import SchemaF

    class MySchema(Schema):
        # The code below is to shut up mypy as it cannot check that
        # the inputs to SchemaF are correct.
        @dataclasses.dataclass
        class MyClass:
            pass
        x: int = fields.Integer()

    s = MySchema()  # type: SchemaF[MySchema.MyClass]


    # The code below is to shut up mypy as it cannot check that
    # the inputs to SchemaF are correct.

# Generated at 2022-06-23 16:51:57.290599
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class SC(SchemaF[str]):
        pass

    with pytest.raises(NotImplementedError):
        SC()


# Generated at 2022-06-23 16:52:07.241828
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.utcnow(), None, None) is not None
    assert field._deserialize(datetime.utcnow().timestamp(), None, None) is not None
    assert field._deserialize(None, None, None) is None
    with warnings.catch_warnings():
        warnings.simplefilter('error')
        with pytest.raises(ValidationError) as excinfo:
            field._deserialize(None, None, None, required=True)
        assert excinfo.value.messages == {'_schema': ['Missing data for required field.']}


# Generated at 2022-06-23 16:52:15.189996
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField(default_error_messages={"required": "required"},
                          required=True)
    value = "2020-03-29T13:35:20"
    expect_value = datetime.fromisoformat(value)
    assert iso_field._serialize(expect_value, None, None) == value
    assert iso_field._deserialize(value, None, None) == expect_value



# Generated at 2022-06-23 16:52:23.754236
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json

    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Person:
        name: str
        age: int
        is_adult: bool

    # type checking
    schema = SchemaF[Person]()
    assert schema.loads(b'{"name": "foo", "age": 1, "is_adult": false}') == \
           Person(name="foo", age=1, is_adult=False)  # type: ignore

# Generated at 2022-06-23 16:52:36.208416
# Unit test for function build_type
def test_build_type():
    def test_unimplemented_types(type_):
        class Test:
            a: type_ = None

        return build_type(type_, {}, None, Test.__dataclass_fields__['a'], Test)

    assert isinstance(test_unimplemented_types(datetime), _TimestampField)
    assert isinstance(test_unimplemented_types(Decimal), fields.Decimal)
    assert isinstance(test_unimplemented_types(UUID), fields.UUID)
    assert isinstance(test_unimplemented_types(int), fields.Int)
    assert isinstance(test_unimplemented_types(str), fields.Str)
    assert isinstance(test_unimplemented_types(float), fields.Float)

# Generated at 2022-06-23 16:52:49.419111
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Person(typing.NamedTuple):
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    p = Person("John", 10)
    p2 = Person("John", 10)
    # dumps
    assert isinstance(PersonSchema().dumps(p), str)
    assert isinstance(PersonSchema().dumps([p, p2]), str)
    # dump
    assert isinstance(PersonSchema().dump(p), dict)
    assert isinstance(PersonSchema().dump([p, p2]), list)
    # loads
    assert isinstance(PersonSchema().loads("{}", many=True), list)
    assert isinstance(PersonSchema().loads("{}"), Person)
    # load

# Generated at 2022-06-23 16:52:51.942366
# Unit test for function schema
def test_schema():
    assert isinstance(schema(int, int, True), dict)



# Generated at 2022-06-23 16:53:02.432689
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.utils import _is_new_type

    type_1 = type(None)
    options = {}
    mixin = None
    field = None
    cls = None
    _ = build_type(type_1, options, mixin, field, cls)

    type_2 = fields.Field
    _ = build_type(type_2, options, mixin, field, cls)

    type_3 = None
    _ = build_type(type_3, options, mixin, field, cls)

    # type_4 = Union[int, str]
    # _ = build_type(type_4, options, mixin, field, cls)

    type_5 = EnumField
    _ = build_

# Generated at 2022-06-23 16:53:13.953692
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class Person:
        name: str

    class PersonSchema(SchemaF[Person]):
        name = fields.String()

    schema = PersonSchema()

    person = Person(name='foo')
    result = schema.dump(person)
    assert result == {'name': 'foo'}

    people = [Person(name='foo'), Person(name='bar')]
    result = schema.dump(people, many=True)
    assert result == [{'name': 'foo'}, {'name': 'bar'}]

    with pytest.raises(NotImplementedError):
        PersonSchema()



# Generated at 2022-06-23 16:53:23.827094
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema, fields
    from typing import List

    class ItemSchema(SchemaF[int]):
        id = fields.Integer()

    def test_dump(schema, obj):
        encoded = schema.dump(obj)
        assert encoded
        return encoded

    x = test_dump(ItemSchema(), 5)
    assert x["id"] == 5

    y = test_dump(ItemSchema(many=True), [5, 6])
    assert y[0] == {"id": 5}
    assert y[1] == {"id": 6}

    def test_load(schema, data):
        decoded = schema.load(data)
        assert decoded
        return decoded

    z = test_load(ItemSchema(), {"id": 5})
    assert z == 5


# Generated at 2022-06-23 16:53:29.555550
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # test when value is not None
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(_TimestampField()._serialize(datetime.now(), None, None), None, None) is not None

    # test when value is None
    assert _TimestampField()._serialize(None, None, None) is None
    assert _TimestampField()._deserialize(None, None, None) is None


# Generated at 2022-06-23 16:53:32.644714
# Unit test for function schema
def test_schema():
    import marshmallow
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    import pytest
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
    assert schema(A, dataclass_json.M, False) == {'a': marshmallow.fields.Str, 'b': marshmallow.fields.Int}

# Generated at 2022-06-23 16:53:42.308722
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    class Person:
        def __init__(self,name):
            self.name = name

    @dataclass
    class PersonData:
        name: str
        age: int = field(default=0)
        # address: AddressData

    # Create a DataClassSchema.
    @dataclass
    class AddressData:
        name: str
        city: str
        state: str

    # Create a DataClassSchema.
    schema_ = build_schema(AddressData)

    # Create a DataClassSchema.
    schema = build_schema(PersonData)

    # Serialize `address` with the nested `AddressSchema`.
    person = PersonData('richard', 25)
    obj = schema.dump(person,many=False)
    print(obj)


# Generated at 2022-06-23 16:53:49.763290
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import Any
    from marshmallow import Schema

    class Foo(Schema):
        something = fields.Str()

    class FooSchema(SchemaF[Any]):
        foo = fields.Nested(Foo)

    obj: typing.Dict = {'foo': {'something': 'a string'}}

    assert json.loads(FooSchema().dumps(obj)) == obj

# Generated at 2022-06-23 16:53:52.437840
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Arrange
    json = {
        'birth_date': '1988-05-16T00:00:00.000000'
    }
    schema = TestSchema()
    # Action
    result = schema.load(json)
    # Assert
    assert result.birth_date == datetime(1988, 5, 16)


# Generated at 2022-06-23 16:54:01.740984
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(typing.Optional[int], {}, None, None, None) == fields.Int
    assert build_type(typing.Optional[int], {}, None, None, None)(None, {}) == fields.Int(allow_none=True)
    assert build_type(typing.Union[int, str], {}, None, None, None) == fields.Field
    assert _issubclass_safe(type(build_type(typing.Union[int, str], {}, None, None, None)(None, {})), _UnionField)
    assert build_type(typing.Union[int, str], {}, typing.Generic, None, None) == fields.Field

# Generated at 2022-06-23 16:54:07.739595
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from typing import List, Dict
    from marshmallow import Schema
    
    @dataclass
    class MyTest:
        name: str
        age: int
        weight: float
        male: bool
        children: List[str] = field(default_factory=list)
        schema_1: Schema = field(default_factory=Schema)
        schema_2: Schema = field(default_factory=Schema)
    
    import marshmallow_enum
    from enum import Enum
    
    
    @dataclass
    class MyTest2:
        name: str
        age: int
        weight: float
        male: bool
        children: List[str] = field(default_factory=list)
        schema_1: Schema = field

# Generated at 2022-06-23 16:54:10.787284
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Schem(Schema):
        text = fields.Str()

    SchemaF[Schem].load(Schem(), {'text': 'asdf'})

# Generated at 2022-06-23 16:54:19.894171
# Unit test for function build_type
def test_build_type():
    """
    Tests the build_type function
    """
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields
    from marshmallow_enum import EnumField  # type: ignore

    import dataclasses_json
    import enum

    @dataclasses_json.dataclass_json
    @dataclass
    class Person:
        name: str

    class Color(enum.Enum):
        red = 0
        blue = 1
        green = 2

    @dataclasses_json.dataclass_json
    @dataclass
    class Meta:
        mapping: typing.Dict[str, str]
        tuples: typing.Tuple[str, str]
        opts: typing.Optional[str]
        lists: typing.List[str]

# Generated at 2022-06-23 16:54:31.063892
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import TypeVar
    from dataclasses import dataclass

    @dataclass
    class DataClass:
        id: int
        name: str

    class DataClassSchema(SchemaF[DataClass]):
        id = fields.Int()
        name = fields.Str()

    print(DataClassSchema().dump([DataClass(id=1, name='ABC'), DataClass(id=2, name='DEF')]))
    print(DataClassSchema().dump(DataClass(id=1, name='ABC')))

# Generated at 2022-06-23 16:54:34.100657
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def test(a: SchemaF[int], b: str) -> None:
        pass
    test(SchemaF[int](), "hello world")



# Generated at 2022-06-23 16:54:36.044142
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class InnerSchema(Schema):
        pass

    assert isinstance(SchemaF[InnerSchema], type)
    assert issubclass(SchemaF[InnerSchema], Schema)



# Generated at 2022-06-23 16:54:37.729332
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF.loads('"xxx"', many=None)



# Generated at 2022-06-23 16:54:51.294789
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Union as U
    from typing import Tuple as T
    from marshmallow import Schema as S, fields as F
    from marshmallow import ValidationError as VE
    @dataclass_json
    @dataclass
    class DT1:
        a: int = field(metadata={'marshmallow_field': F.Int})
    @dataclass_json
    @dataclass
    class DT2:
        b: str = field(metadata={'marshmallow_field': F.Str})
    @dataclass_json
    @dataclass
    class DT3:
        u: U[DT1, DT2]

# Generated at 2022-06-23 16:55:04.137819
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class Cat:
        name: str = 'unknown'
        age: int = 9
        mood: Optional[str] = None
        best_friend: Optional['Cat'] = None

    assert schema(Cat, schema, False) == {
        'name': fields.Str(data_key='name', default='unknown'),
        'age': fields.Int(data_key='age', default=9),
        'mood': fields.Str(data_key='mood', allow_none=True),
        'best_friend': fields.Nested('Cat', data_key='best_friend', allow_none=True)
    }
