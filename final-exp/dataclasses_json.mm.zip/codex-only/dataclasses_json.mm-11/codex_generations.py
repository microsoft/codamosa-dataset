

# Generated at 2022-06-23 16:45:01.018297
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        class A(SchemaF):
            pass



# Generated at 2022-06-23 16:45:02.530743
# Unit test for function build_schema
def test_build_schema():
    assert not hasattr(build_schema, '__annotations__')
    assert not hasattr(build_schema, '__name__')





# Generated at 2022-06-23 16:45:10.478706
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass_json
    class Cls:
        @dataclass_json
        class NestedCls:
            nested_field: str

        field: NestedCls
        nested_cls: NestedCls
        option_field: typing.Optional[NestedCls] = None


# Generated at 2022-06-23 16:45:21.695457
# Unit test for function schema
def test_schema():
    import marshmallow

    @dataclass_json
    @dataclass(frozen=True)
    class Mixin:
        @classmethod
        def schema(cls):
            return Schema.from_dict(schema(cls, Mixin, False))

    @dataclass_json
    @dataclass(frozen=True)
    class D(Mixin):
        a: str

    assert isinstance(D.schema().fields['a'], fields.Str)

    @dataclass_json
    @dataclass(frozen=True)
    class E(Mixin):
        a: int

    assert isinstance(E.schema().fields['a'], fields.Int)


# Generated at 2022-06-23 16:45:29.955367
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class MyClass:
        a: str
        b: int
        c: typing.List[int]

    sf = SchemaF[MyClass]
    assert sf.__class__.__name__ == 'SchemaF'
    assert sf.__bases__ == (Schema,)

    # some pytest magic to test the function signature of the dump function
    fd = sf.dump
    assert fd.__module__ == 'dataclasses_json.schema'
    assert fd.__name__ == 'dump'

    fd = sf.dumps
    assert fd.__module__ == 'dataclasses_json.schema'
    assert fd.__name__ == 'dumps'

    fd = sf.load

# Generated at 2022-06-23 16:45:41.286997
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow.exceptions
    import marshmallow_dataclass.class_registry
    import marshmallow_dataclass.schema
    import marshmallow_dataclass.schema_options
    import marshmallow_dataclass.utils
    import string
    import uuid

    class StringA(str):
        def __init__(self):
            self.a = 2

    class StringB(str):
        def __init__(self):
            self.b = 4

    class StringABSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'

        def __init__(self,
        *args,
        **kwargs) -> None:
            super().__init__(*args, **kwargs)

# Generated at 2022-06-23 16:45:53.489393
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses_json import _UnionField
    from dataclasses import dataclass
    from typing import Union

    @dataclass
    class A:
        a: str
        b: int

    @dataclass
    class B:
        a: str
        b: int
        c: str

    @dataclass
    class ABC:
        abc: Union[A, B]

    class C:
        _schema = ABC.schema()

        def __getitem__(self, item):
            return getattr(self._schema, item)
        pass

    a_field = C()['abc']['fields']['abc']
    assert a_field.__class__ == _UnionField
    assert a_field.cls == ABC
    assert a_field.field.name == 'abc'


# Generated at 2022-06-23 16:46:02.400449
# Unit test for function schema
def test_schema():
    from marshmallow import Schema, fields
    from dataclasses_json.schema import Schema
    from dataclasses_json.schema import schema
    import typing

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: typing.Any

    class ASchema(Schema):
        a = fields.Str()
        b = fields.Int()
        c = fields.Raw()

    assert schema(A, ASchema) == {
        'a': fields.Str(),
        'b': fields.Int(),
        'c': fields.Raw()
    }



# Generated at 2022-06-23 16:46:07.632611
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class TestSchema:
        a: int = 3

    DataClassSchema = build_schema(TestSchema, None, None, None)

    assert DataClassSchema.Meta.fields

# Generated at 2022-06-23 16:46:12.728209
# Unit test for function schema
def test_schema():
    class MyClass:
        field: int

    ret = schema(MyClass, None, False)
    # assert type(ret['field']) is fields.Int
    assert issubclass(ret['field'].__class__, fields.Int) # type: ignore
    assert ret['field'].__class__ != fields.Int # type: ignore



# Generated at 2022-06-23 16:46:19.985075
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo:
        bar = int

    class Foos(SchemaF[Foo]):
        class Meta:
            unknown = EXCLUDE

    json_data = '[{"bar": "1"}, {"bar": "2"}]'
    r = Foos().loads(json_data)
    assert r[0].bar == 1 and r[1].bar == 2


# Generated at 2022-06-23 16:46:29.375050
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # this test needs to have better mypy-checking than the rest
    # pylint: disable=no-self-use

    class _Doc(typing.Generic[A]):

        def __init__(self, data: A):
            self.data = data

    # this if block should not be indented inside the class
    # because it should work with and without python 3.7
    if sys.version_info >= (3, 7):

        class _DocSchema(SchemaF[_Doc[int]]):
            pass

        s = _DocSchema()

        class _Int(typing.Generic[A]):

            def __init__(self, a: A):
                self.a = a

        class _IntSchema(SchemaF[_Int[int]]):
            pass

        i = _IntSchema()

       

# Generated at 2022-06-23 16:46:33.634575
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass
    class A:
        a: int

    a = A(a=1)

    @dataclass
    class B:
        b: typing.List[A]

    schema = dataclasses_json.schema(B)()
    schema.dump(B(b=[a]))  # should not raise exception



# Generated at 2022-06-23 16:46:44.232452
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert issubclass(SchemaF, Schema)

    @dataclasses.dataclass
    class A:
        a: int

    @dataclasses.dataclass
    class B:
        b: str

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert isinstance(
        ASchema(many=True).dump([A(1), A(2)]), list
    )  # type: ignore
    assert isinstance(
        ASchema().dump(A(1)), dict
    )
    assert isinstance(
        ASchema(many=True).loads('[{"a":1}, {"a":2}]'), list
    )  # type: ignore
    assert isinstance(
        ASchema().loads('{"a":1}'), A
    )  #

# Generated at 2022-06-23 16:46:52.821477
# Unit test for function build_type
def test_build_type():
    from .mixins.mm import Mixin
    from . import dataclass_json

    @dataclass_json
    class DummySchema(Mixin, object):
        pass

    @dataclass_json
    class DummySchema2(Mixin, object):
        pass

    @dataclass_json
    class DummySchema3(object):
        pass

    @dataclass_json
    class DummySchema4(object):
        pass

    class DummySchema5:
        pass

    @dataclass_json
    class DummyEnum(Enum):
        a = 'a'
        b = 'b'

    @dataclass_json
    class Dummy(object):
        a: typing.Optional[DummySchema]

# Generated at 2022-06-23 16:46:53.751147
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:46:57.141008
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class CustomContainerSchema(SchemaF[A]):
        pass
    assert CustomContainerSchema.load({'x': 1}) == {'x': 1}


# Generated at 2022-06-23 16:47:01.718639
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.NamedTuple):
        a: int
    class B(SchemaF[A]):
        a = fields.Int()
    class C(SchemaF[A]):
        a = fields.Int()
        @post_load
        def make_a(self, data, **kwargs):
            return A(**data)
    class D(SchemaF[A]):
        a = fields.Int()
        @post_load
        def make_a(self, data, **kwargs):
            return A(data['a'] + 1)
    class E(SchemaF[A]):
        a = fields.Int()
        @post_load
        def make_a(self, data, **kwargs):
            return A(**data)

# Generated at 2022-06-23 16:47:03.066165
# Unit test for function schema
def test_schema():
    schema(int, str, False)

# Generated at 2022-06-23 16:47:13.235564
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: str
        c: float = 1.0
        d: typing.Optional[typing.List[int]] = None
        e: typing.Optional[typing.Tuple[int, ...]] = None
        f: typing.Optional[typing.Tuple[typing.Tuple[int, int], typing.Tuple[int, int]]] = None
        g: typing.List[typing.Optional[int]] = None

    sc = schema(A, None, True)

    assert sc['a'] == fields.Int()
    assert sc['b'] == fields.Str()
    assert sc['c'] == fields.Float()
    assert sc['d'] == fields.List()

# Generated at 2022-06-23 16:47:23.512134
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass, field

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.Union[A, B]

    d = C(c=A(1))

    class Schema(Schema):
        c = _UnionField(
            desc={
                A: fields.Nested(Schema, allow_none=True, required=True),
                B: fields.Nested(Schema, allow_none=True, required=True)
            },
            cls=C,
            field=dc_fields(C)[0],
            allow_none=True,
            required=True
        )

    schema = Schema()


# Generated at 2022-06-23 16:47:27.805287
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    dt = datetime.utcnow()
    timestamp_field = _TimestampField()
    assert timestamp_field._serialize(dt, None, None) == dt.timestamp()
    assert timestamp_field._deserialize(dt.timestamp(), None, None) == dt.replace(tzinfo=None)



# Generated at 2022-06-23 16:47:38.654724
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow as ma

    class Foo1(ma.Schema):
        class Meta:
            unknown = ma.EXCLUDE

        foo = ma.fields.String(required=True, allow_none=False)

    class Foo2(ma.Schema):
        class Meta:
            unknown = ma.EXCLUDE

        foo = ma.fields.String(required=True, allow_none=False)

    class BarF(ma.Schema, typing.Generic[A]):
        """Raises exception because this class should not be inherited. This class is helper only."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:47:48.548514
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema
    from dataclasses import dataclass, field

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class Union:
        a: typing.Union[A, B]

    @dataclass_json
    class UnionSchema(Schema):
        class Meta:
            dataclass = Union

    assert UnionSchema().__class__._declared_fields['a'].desc == {
        A: UnionSchema._declared_fields['a'].description[0].schemas[A],
        B: UnionSchema._declared_fields['a'].description[0].schemas[B]}
    assert UnionSchema().__class__._declared_fields['a'].cls == Union
   

# Generated at 2022-06-23 16:47:52.468799
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(1571306548.651466) == datetime(2019, 10, 21, 9, 49, 8, 651466, tzinfo=None)
    assert field.deserialize(None) == None


# Generated at 2022-06-23 16:47:59.450450
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchemaF(SchemaF):
        pass

    @dataclass
    class Example:
        x: str = "test"

    serializer = TestSchemaF()
    rtn = serializer.dump([Example()])
    assert isinstance(rtn, list)

    rtn = serializer.dump(Example())
    assert isinstance(rtn, dict)



# Generated at 2022-06-23 16:48:11.156089
# Unit test for method load of class SchemaF
def test_SchemaF_load(): # type: ignore
    schema_f = SchemaF.load(1)
    schema_f = SchemaF.load([1])
    schema_f = SchemaF.load(1, many=True)
    schema_f = SchemaF.load([1], many=True)

# Generated at 2022-06-23 16:48:22.322727
# Unit test for function build_type
def test_build_type():
    class TestClass(mixin):
        x: str


    class TestMixin:
        @classmethod
        def schema(cls):
            return type('test', (), {"test_field": fields.Field()})


    @dataclass_json
    @dataclass
    class TestClass2(TestMixin):
        test_field: str


    @dataclass
    class TestClass3(TestMixin):
        test_field: str


    options = {'allow_none': False}
    assert build_type(TestClass, options, TestMixin, '', TestClass) == fields.Nested(
        {'test_field': fields.Field(allow_none=False, field_many=False)},
        allow_none=False)
    options = {'allow_none': True}
    assert build

# Generated at 2022-06-23 16:48:32.079708
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class FooSchema(SchemaF[str]):
        pass

    s = FooSchema()

    try:
        s.dump(["one", "two"])
        assert True
    except NotImplementedError:
        assert False

    try:
        s.dump("test")
        assert True
    except NotImplementedError:
        assert False

    try:
        s.dumps("test")
        assert True
    except NotImplementedError:
        assert False

    try:
        s.dumps(["one", "two"])
        assert True
    except NotImplementedError:
        assert False

    try:
        s.load([1, 2])
        assert True
    except NotImplementedError:
        assert False


# Generated at 2022-06-23 16:48:44.240124
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses_json.schema import SchemaF

    class Empty:
        pass

    SchemaF[Empty].loads(b'{}')
    SchemaF[Empty].loads([b'{}'])


if sys.version_info < (3, 7):
    SchemaF = Schema

ENCODERS = {
    datetime: {'cls': _IsoField, 'kwargs': {}},
    UUID: {'cls': fields.UUID, 'kwargs': {'missing': None}},
    Decimal: {'cls': fields.Decimal, 'kwargs': {'missing': None}},
    CatchAllVar: {'cls': fields.Dict, 'kwargs': {'default': {}, 'missing': {}}},
}

SCHEMA_LOAD_METHODS

# Generated at 2022-06-23 16:48:49.167302
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class NamesSchema(SchemaF[typing.Dict[str, str]]):
        name = fields.Str(required=True)

    schema = NamesSchema()
    assert schema.loads('{"name": "Jack"}') == {'name': 'Jack'}

    result = schema.loads('[{"name": "Jack"}, {"name": "David"}]')
    assert result == [{'name': 'Jack'}, {'name': 'David'}]



# Generated at 2022-06-23 16:48:52.456777
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema = SchemaF[int]()
    assert schema.load([1]) == [1]
    assert schema.load({'x': 1}) == 1



# Generated at 2022-06-23 16:49:02.798483
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A:
        field: int

    class ASchema(SchemaF[A]):
        field = fields.Int()

        @post_load
        def make_A(self, data, **kwargs):
            return A(**data)

    # Successful case
    assert isinstance(ASchema().loads('{"field": 2}'), A)
    assert isinstance(ASchema().loads('{"field": 2}').field, int)
    assert ASchema().loads('{"field": 2}').field == 2

    # Field value must be int
    try:
        ASchema().loads('{"field": "2"}')
    except Exception as e:
        assert isinstance(e, ValidationError)
        assert e.messages['field'][0] == 'Not a valid integer.'

# Generated at 2022-06-23 16:49:13.951788
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union
    from marshmallow import fields, Schema, SchemaOpts
    from marshmallow.exceptions import ValidationError
    from dataclasses_json import dataclass_json
    from dataclasses import dataclass

    class MySchemaOpts(SchemaOpts):
        """Same as SchemaOpts but with a custom option"""
        def __init__(self, meta, *args, **kwargs):
            super().__init__(meta, *args, **kwargs)
            self.my_custom_option = getattr(meta, 'my_custom_option', None)

    @dataclass_json(mm_schema_opts=MySchemaOpts)
    class MySchema(Schema):
        """Same as Schema but with a custom option"""

# Generated at 2022-06-23 16:49:23.784520
# Unit test for function build_type
def test_build_type():
    from typing import List
    import marshmallow  # type: ignore
    from dataclasses_json.mm import Schema
    from marshmallow.fields import Str
    from marshmallow import Schema as MmSchema  # type: ignore


    class Mixin:
        class Meta:
            pass


    @dataclass_json
    class TestClass:
        a: List[int] = field(metadata={'mm_field': Str})
        b: List[int] = None

    schema_type = build_type(TestClass.__annotations__['a'], {}, Mixin,
                             TestClass.__annotations__['a'], TestClass)
    assert isinstance(schema_type, Str)

# Generated at 2022-06-23 16:49:30.878110
# Unit test for function build_type
def test_build_type():
    from enum import Enum
    from typing import Tuple, Optional, Union, Type

    from marshmallow import fields

    from marshmallow_enum import EnumField

    from dataclasses_json import dataclass_json
    from dataclasses import dataclass
    import pytest

    my_enum = Enum('MyEnum', 'a b c')

# Generated at 2022-06-23 16:49:34.585696
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    the_past = datetime(1970, 1, 1)
    the_future = datetime(2070, 1, 1)

    # both return the utc time stamp
    assert field._serialize(the_past, None, None) == the_past.timestamp()
    assert field._serialize(the_future, None, None) == the_future.timestamp()

    # both return the datetime
    assert field._deserialize(the_past.timestamp(), None, None) == the_past
    assert field._deserialize(the_future.timestamp(), None, None) == the_future


# Generated at 2022-06-23 16:49:46.049900
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclassJ_ex(mm=True)
    @dataclass
    class A:
        # a: typing.Optional[int] = field(default=None, metadata={'mm_field': fields.Int()})
        a: int
        # b: typing.Union[str, typing.List[float]] = field(default='', metadata={'mm_field': fields.Str()})
        b: typing.Union[str, typing.List[float]]

    @dataclassJ_ex(mm=True)
    @dataclass
    class B:
        # a: typing.Optional[int] = field(default=None, metadata={'mm_field': fields.Int()})
        a: int
        # b: typing.Union[float, str] = field(default=0.0, metadata={'mm_field':

# Generated at 2022-06-23 16:49:47.508615
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()

Timestamp = _TimestampField



# Generated at 2022-06-23 16:49:51.555941
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema = SchemaF[Tuple[int, str]]()

    assert schema.load([[1, '2']]) == [(1, '2')]



# Generated at 2022-06-23 16:49:55.240866
# Unit test for constructor of class _IsoField
def test__IsoField():
    if sys.version_info < (3, 7, 0):
        warnings.warn("_IsoField has limited functionality on python versions < 3.7")



# Generated at 2022-06-23 16:49:59.192043
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def _test(input): pass  # noqa
    assert typing.get_type_hints(_test) == {
        'input': typing.Union[typing.List[typing.Any], typing.Any]}
    input: typing.Any = 'test'
    output = input
    _test(input)
    _test(output)

# Generated at 2022-06-23 16:50:01.387190
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF()
    assert s.dump([1, 2, 3], many=True) == [1, 2, 3]
    assert s.dump(1, many=False) == 1



# Generated at 2022-06-23 16:50:10.117033
# Unit test for function build_type
def test_build_type():
    from typing import Dict
    from marshmallow import fields as mm_fields
    from dataclasses_json.mm_field import _SchemaField
    from dataclasses import dataclass
    from datetime import date

    @dataclass
    class _Test:
        a: Dict[str, str]
        b: Dict[str, int]
        c: Dict[str, bool]
        d: Dict[str, float]

    inner = build_type(Dict[str, str], {}, _SchemaField, None, _Test)
    assert isinstance(inner, mm_fields.Dict)
    # ensure args are correct
    assert inner.value_field.__class__ == mm_fields.Str
    assert inner.key_field.__class__ == mm_fields.Str
    inner = build_type

# Generated at 2022-06-23 16:50:15.993600
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, dataclass_json
    from marshmallow_enum import EnumField

    class En(Enum):
        FOO = 1
        BAR = 2

    @dataclass
    class Nested(DataClassJsonMixin):
        id: int

    assert build_type(Nested, {}, None, None, None).__class__ == fields.Nested

    assert build_type(typing.Mapping[str, En], {}, None, None, None).__class__ == \
           fields.Mapping

    assert build_type(typing.Union[Nested, En], {}, None, None, None).__class__ ==\
           _UnionField


# Generated at 2022-06-23 16:50:25.891284
# Unit test for function build_schema
def test_build_schema():
    from .dataclasses_ import dataclass, field

    @dataclass(frozen=True)
    class Test:
        a: int = field(metadata={'dataclasses_json': {'mm_field': mm.Int()}})

    mixin = None
    infer_missing = False
    partial = False
    try:
        out = build_schema(Test, mixin, infer_missing, partial)
    except Exception as e:
        assert False, "Caught exception during schema creation: " + str(e)
    else:
        assert hasattr(out, 'Meta') # type: ignore
        assert hasattr(out, 'make_test') # type: ignore
        assert hasattr(out, 'dumps') # type: ignore
        assert hasattr(out, 'dump') # type: ignore
        assert hasattr

# Generated at 2022-06-23 16:50:35.013120
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import SchemaF as SchemaF_
    from typing import cast
    from marshmallow import Schema

    class ExampleIndex(Schema):
        index = fields.Int()

    class ExampleInfo(Schema):
        index = fields.Int()

    class ExampleSchema(SchemaF_[ExampleInfo, ExampleIndex]):  # type: ignore
        index = fields.Int()
        info = fields.Nested(ExampleInfo)

        @post_load
        def post_load(self, data, **kwargs):
            return ExampleIndex(**data)

    index = cast(Examples.ExampleIndex, ExampleSchema().load({'index': 1}))  # type: ignore
    assert index.index == 1

    index = cast(Examples.ExampleIndex, ExampleSchema().load([{'index': 1}]))  # type

# Generated at 2022-06-23 16:50:46.930616
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():

    class _TestSchema(SchemaF):
        def __init__(self):
            super(_TestSchema, self).__init__()

    # Test the static typing of lots of loads(), which is the point of SchemaF

    # Test the many overload
    _TestSchema().loads(b'[1,2,3]', many=True)
    _TestSchema().loads(b'[1,2,3]', many=False)
    _TestSchema().loads(b'1', many=None)
    _TestSchema().loads(b'[1,2,3]', many=None)

    # Test the many=True overload
    _TestSchema().loads(b'[1,2,3]', many=True)

# Generated at 2022-06-23 16:50:51.878136
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    T = typing.TypeVar('T')
    class Dummy(typing.Generic[T]):
        pass
    class DummySchema(SchemaF[Dummy[T]]):
        id = fields.Str()

    desr_value = DummySchema().load({'id': '123'})
    assert desr_value.id == '123'

# Generated at 2022-06-23 16:50:53.459366
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    pass


# Generated at 2022-06-23 16:51:04.446000
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields, Schema
    from dataclasses_json.api import load
    from typing import Optional

    class UserSchema(SchemaF[User]):
        id = fields.Int()
        name = fields.Str()
        age = fields.Int()

    @dataclass
    class User:
        id: int
        name: str
        age: int
        ext_refs: Optional[List[str]] = None

    schema = UserSchema()
    schema.load([{'id': 1, 'name': 'Fred', 'age': 28}])
    schema.load({'id': 1, 'name': 'Fred', 'age': 28})
    schema.load(User(1, 'Fred', 28))  # type: ignore
    schema.load([User(1, 'Fred', 28)])  # type

# Generated at 2022-06-23 16:51:07.463093
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    timestamp = datetime.now().timestamp()
    field.deserialize(timestamp)
    field.serialize(datetime.now())


# Generated at 2022-06-23 16:51:14.033015
# Unit test for function build_schema
def test_build_schema():
    with pytest.raises(TypeError) as excinfo:
        build_schema(None, None, None, None)
        assert 'Build schema function received None as a type parameter' in str(
            excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        build_schema(Empty, None, None, None)
        assert 'Empty type should have at least one field' in str(excinfo.value)

# Generated at 2022-06-23 16:51:22.501949
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    class Dataclass:
        def dataclass(self):
            pass

    assert SchemaF[Dataclass.dataclass].dump(Dataclass()) == {}

    @dataclass
    class Dataclass:
        value: int

    assert SchemaF[Dataclass].dump(Dataclass(0)) == {'value': 0}

    @dataclass
    class Dataclass:
        value: typing.Optional[int]

    assert SchemaF[Dataclass].dump(Dataclass(0)) == {'value': 0}
    assert SchemaF[Dataclass].dump(Dataclass(None)) == {'value': None}

    @dataclass
    class Dataclass:
        value: typing.List[int]


# Generated at 2022-06-23 16:51:25.082235
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField(missing=MISSING).missing == MISSING 


# Generated at 2022-06-23 16:51:28.839351
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.deserialize('1512809124.0')
    field.serialize(datetime(2017, 12, 8, 9, 12, 4))
    field.validate([0])
    field.validate(0.0)
    field.validate('1512809124.0')
    field.validate(None)



# Generated at 2022-06-23 16:51:30.966233
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()
    assert a


# Generated at 2022-06-23 16:51:36.519473
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class ShemaF(SchemaF):
        x: int

    data = {'x': 1}
    schema = ShemaF()
    schema.dump(data)
    schema.dumps(data)
    schema.load(data)
    schema.loads(json.dumps(data))



# Generated at 2022-06-23 16:51:50.283949
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses_json.api import unbox
    from marshmallow.exceptions import ValidationError

    class A:
        pass

    class B:
        pass

    class InnerSchema(Schema):
        a = fields.Integer()
        b = fields.Integer()

    class InnerClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    Inner = unbox(InnerClass, InnerSchema)

    class TestUnionClass:
        def __init__(self, a: typing.Union[InnerClass, A, B]):
            self.a = a

    u = TestUnionClass(Inner(a=1, b=2))
    schema = Schema()

# Generated at 2022-06-23 16:51:51.198135
# Unit test for function build_schema
def test_build_schema():
    pass



# Generated at 2022-06-23 16:52:03.307885
# Unit test for function build_type
def test_build_type():
    class Person:
        def __init__(self, name: str):
            self.name = name


    @dataclass_json
    @dataclass
    class PersonSchema(Schema):
        name: str = mm_field(mm_str)


    @dataclass_json
    @dataclass
    class PersonSchema2(Schema):
        name: str = mm_field(mm_str, validate=validates.Length(max=2))


    @dataclass_json
    @dataclass
    class PersonSchema3(Schema):
        name: List[Person] = mm_field(mm_list, mm_nested(PersonSchema), validate=validates.Length(max=2))



# Generated at 2022-06-23 16:52:06.060250
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema = SchemaF[int]()
    assert schema.dump([1, 2, 3]) == [1, 2, 3]
    assert schema.dump(1) == 1



# Generated at 2022-06-23 16:52:07.036969
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField(required=True)



# Generated at 2022-06-23 16:52:17.944481
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class ConcreteClass(A):
        pass

    schema = SchemaF[ConcreteClass]

    assert isinstance(schema.dump([], many=True), typing.List[
        TEncoded])  # type: ignore
    assert isinstance(schema.dump([], many=False), TEncoded)  # type: ignore
    assert isinstance(schema.dump([ConcreteClass()]), typing.List[
        TEncoded])  # type: ignore
    assert isinstance(schema.dump(ConcreteClass()), TEncoded)  # type: ignore

    assert isinstance(schema.dumps([], many=True), str)
    assert isinstance(schema.dumps([], many=False), str)
    assert isinstance(schema.dumps([ConcreteClass()]), str)

# Generated at 2022-06-23 16:52:24.306937
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class IntListSchema(SchemaF[typing.List[int]]):

        def __init__(self):
            super().__init__()

    IntListSchema().loads('')
    IntListSchema().loads(b'', many=True)



# Generated at 2022-06-23 16:52:32.805803
# Unit test for function schema
def test_schema():
    from datetime import date
    from decimal import Decimal
    from . import dataclass_json, config
    from .utils import from_dict


    @dataclass_json(mm_field=fields.Str())
    class Bar:
        s: str


    def letter_case(name):
        return name.lower()


    @dataclass_json(letter_case=letter_case)
    class Foo:
        x: int
        y: Bar
        z: Decimal
        some_date: date
        some_date_again: date
        some_optional: typing.Optional[int]
        some_optional_again: typing.Optional[int]
        some_optional_dict: typing.Optional[CatchAllVar]


    # The key of the dict will be the `data_key` of the `fields.

# Generated at 2022-06-23 16:52:38.761073
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()  # type: ignore
    current_time = datetime.now()
    serialized_time = f._serialize(current_time, None, None)
    assert serialized_time == current_time.timestamp()
    deserialized_time = f._deserialize(serialized_time, None, None)
    assert (deserialized_time == _timestamp_to_dt_aware(current_time.timestamp()))


# Generated at 2022-06-23 16:52:46.264761
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass(frozen=True)
    class A:
        a: str

    sf = SchemaF[A](type_="model", strict=True)

    print(sf.dump([A(a='hi'), A(a='there')]))
    print(sf.dump(A(a='hi')))



# Generated at 2022-06-23 16:52:59.901987
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from .decorator import DataclassJsonMixin
    from marshmallow import Schema, fields

    @dataclass
    class D(DataclassJsonMixin):
        a: int
        b: int

    @dataclass
    class E(DataclassJsonMixin):
        a: str
        b: str

    @dataclass
    class C(DataclassJsonMixin):
        a: int
        b: E
        c: typing.List[D]

    @dataclass
    class B(DataclassJsonMixin):
        a: int
        b: C

    @dataclass
    class A(DataclassJsonMixin):
        a: int
        b: str
        c: B
        d

# Generated at 2022-06-23 16:53:12.918533
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now())
    assert _TimestampField()._deserialize(1598508001)

_FLOAT_TYPES = (float,)

if sys.version_info >= (3, 7):
    _FLOAT_TYPES += (Decimal,)

_ANY_TYPE_MARKER = object()

_BASE_TYPE_TO_MARSHMALLOW_FIELD = {
    int: fields.Integer(),
    float: fields.Float(),
    str: fields.Str(),
    bool: fields.Boolean(),
    Decimal: fields.Decimal(),
    datetime: _TimestampField(),
    UUID: fields.UUID()
}

if sys.version_info >= (3, 7):
    _BASE_TYPE_TO_

# Generated at 2022-06-23 16:53:15.609408
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF.dumps(EmptySchema(), '') == '""'
test_SchemaF_dumps()

# Generated at 2022-06-23 16:53:20.765782
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    unittest.TestCase().assertEqual(
        _TimestampField()._deserialize(
            None, "test", data=None, many=False, partial=False, unknown=CatchAllVar(),
            context=None, validate=False, error_messages=None, load_from=None, index=None
        ),
        None
    )


# Generated at 2022-06-23 16:53:23.049721
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:53:31.357825
# Unit test for function schema
def test_schema():

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: int
        c: int = 2
        d: str = "hello"
        e: int = field(default=2, metadata={"dataclasses_json": {"mm_field": fields.Str()}})
        f: typing.List[int]
        g: typing.Dict[str, int]
        h: typing.Optional[int] = None
        i: typing.Optional[int] = field(default=2, metadata={"dataclasses_json": {"mm_field": fields.Str()}})
        j: typing.Optional[int] = field(default=None, metadata={"dataclasses_json": {"mm_field": fields.Str()}})

# Generated at 2022-06-23 16:53:36.507712
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    value = datetime.now()
    result = iso_field._serialize(value, None, None)
    assert value.isoformat() == result
    result = iso_field._deserialize(value.isoformat(), None, None)
    assert value.isoformat() == result.isoformat()


# Generated at 2022-06-23 16:53:46.563248
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow_enum import EnumField  # type: ignore
    from typing import Union
    from dataclasses_json.schema import _UnionField

    class ABC(Enum):
        A = 'a'
        B = 'b'
        C = 'c'

    @dataclass
    class ADataclass:
        b: int

    @dataclass
    class BDataclass:
        b: int

    @dataclass
    class MyDataclass:
        x: Union[ADataclass, BDataclass, str, ABC]


# Generated at 2022-06-23 16:53:54.493975
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json

    @dataclass_json
    @dataclass
    class Data:
        parent: str

    JsonData = typing.Union[str, bytes, bytearray]
    SchemaF[Data].loads(json.dumps(dict(parent='foo')), many=None, partial=None, unknown=None, **dict())
    SchemaF[Data].loads(json.dumps([dict(parent='foo')]), many=True, partial=None, unknown=None, **dict())



# Generated at 2022-06-23 16:53:55.274533
# Unit test for constructor of class _UnionField
def test__UnionField():
    _UnionField(None, None, None)



# Generated at 2022-06-23 16:53:56.237246
# Unit test for constructor of class SchemaF
def test_SchemaF():
    pass


# Generated at 2022-06-23 16:53:59.860720
# Unit test for function build_type
def test_build_type():
    # type: () -> None
    import marshmallow_field

    field = dc_fields(str)(default='str_default', default_factory=lambda: 'str_default')
    assert isinstance(build_type(str, {}, Mixin, field, None), marshmallow_field)



# Generated at 2022-06-23 16:54:12.167738
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from typing import TypedDict

    @dataclass
    class _something(TypedDict):
        a: str

    @dataclass
    class _data(TypedDict):
        some: str
        another: _something

    class _my_schema(SchemaF[_data]):
        some: str
        another: fields.Nested(fields.Dict(keys=fields.Str(),
                                           values=fields.Str()))

        @post_load
        def make_obj(self, data: dict, **kwargs) -> _data:
            return _data(**data)

    sch = _my_schema()
    # Works
    sch.dumps({'some': 'some', 'another': {'a': 'a'}})
    # Works

# Generated at 2022-06-23 16:54:20.711374
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union, Optional
    from marshmallow import Schema
    from unittest import TestCase


    class Foo:
        def __init__(self, value):
            self.value = value

    class Bar:
        def __init__(self, value):
            self.value = value

    class MySchema(Schema):
        bar = fields.Integer()

    class MyUnionSchema(Schema):
        foo = fields.String()

    union_desc = {
        Foo: MySchema,
        Bar: MyUnionSchema,
        int: fields.Integer(),
        Union[int, str]: fields.String()
    }


# Generated at 2022-06-23 16:54:26.987821
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B:
        pass
    desc = typing.Dict[type, 'Schema']
    cls = A()
    field = B()
    a = _UnionField(desc, cls, field)
    assert a.desc == desc
    assert a.cls == cls
    assert a.field == field



# Generated at 2022-06-23 16:54:35.082859
# Unit test for constructor of class _UnionField
def test__UnionField():
    import enum
    import typing as typing

    class EnumElement(Enum):
        E1 = 1
        E2 = 2

    class EnumElement2(Enum):
        E21 = 1
        E22 = 2

    class A:
        pass

    class B:
        pass

    class C:
        pass

    class X:
        pass

    class Y:
        pass

    class Z:
        pass

    @_user_overrides_or_exts()
    class MyDataclass(metaclass=dataclasses.dataclass):
        field1: typing.Union[A, B] = None
        field2: typing.Union[C, Dict[str, int]] = None
        field3: typing.Union[EnumElement, EnumElement2] = None

# Generated at 2022-06-23 16:54:40.942917
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class ASchema(SchemaF[A]):
        pass

    assert isinstance(ASchema().dump([{'a': 1}], many=True), typing.List[dict])
    assert isinstance(ASchema().dump([{'a': 1}]), typing.List[dict])
    assert isinstance(ASchema().dump({'a': 1}, many=False), dict)
    assert isinstance(ASchema().dump({'a': 1}), dict)



# Generated at 2022-06-23 16:54:43.540778
# Unit test for constructor of class _UnionField
def test__UnionField():
    x = _UnionField(None, None, None)
    assert x is not None


# Generated at 2022-06-23 16:54:52.909355
# Unit test for function build_type
def test_build_type():
    import typing
    import marshmallow
    from marshmallow import fields

    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(typing.Optional[int], {}, None, None, None).allow_none == True
    assert build_type(str, {}, None, None, None) == fields.Str
    assert isinstance(build_type(Tuple[int, str], {}, None, None, None), fields.Field) == False
    assert build_type(Tuple[int, str], {}, None, None, None) == fields.Tuple(fields.Int(), fields.Str())


# Generated at 2022-06-23 16:55:05.753870
# Unit test for function build_type
def test_build_type():

    import marshmallow as ma

    mm_field = _make_field(
        mm_field=ma.fields.String(description='description'),
        default=MISSING,
        default_factory=MISSING,
        mm_schema=None,
        mm_schema_opts=None,
        mm_field_kwargs={},
        mm_schema_kwargs={},
    )

    assert mm_field._validated_data is None
    assert isinstance(mm_field, fields.String)
    assert mm_field.describe() == {
        'default': MISSING,
        'description': 'description',
        'missing': None,
        'required': True,
        'type': 'string',
    }

    class Foo(ma.Schema):
        code = ma.fields.Integer()
       