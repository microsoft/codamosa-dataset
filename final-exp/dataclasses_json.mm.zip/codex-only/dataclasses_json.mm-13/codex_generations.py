

# Generated at 2022-06-23 16:45:10.671541
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json(mm_field_types={
        datetime: _TimestampField,
    })
    @dataclass
    class A:
        a: int

    list = [A(a=1), A(a=2)]
    assert SchemaF[A].dumps(list) == '[{"a": 1}, {"a": 2}]'
    assert SchemaF[A].dumps(list, many=True) == '[{"a": 1}, {"a": 2}]'
    assert SchemaF[A].dumps(list, many=False) == '[{"a": 1}, {"a": 2}]'
    assert SchemaF[A].dumps(A(a=1)) == '{"a": 1}'

# Generated at 2022-06-23 16:45:12.346099
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        _ = SchemaF



# Generated at 2022-06-23 16:45:17.066969
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF[str]()
    assert schema_f.load('{"a": "b"}', many=False) == '{"a": "b"}'
    assert schema_f.load('{"a": "b"}', many=True) == ['{"a": "b"}']


SchemaF = typing.cast(
    typing.TypeVar('SchemaF', bound='SchemaF'), typing.Type[SchemaF])



# Generated at 2022-06-23 16:45:22.291045
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class X:
        s: str

        @dataclass_json
        @dataclass
        class Inner:
            s: str

    assert len(build_schema(X, None, False, False).__mro__) == 3
    assert build_schema(X, None, False, False).Meta.fields == ('s',)



# Generated at 2022-06-23 16:45:30.560101
# Unit test for function schema
def test_schema():
    from typing import List, Mapping, MutableMapping, Optional
    from marshmallow import fields as mm_fields, validate
    from marshmallow.exceptions import ValidationError
    import uuid
    import datetime

    from dataclasses_json.core import _decode_dataclass
    from dataclasses import dataclass, field

    @dataclass
    class CustomType:
        pass

    @dataclass
    class Nested:
        letter_case: str = None

        @property
        def mm_field(self):
            return mm_fields.Str(validate=validate.OneOf(['upper', 'lower']),
                                 data_key=self.letter_case)


# Generated at 2022-06-23 16:45:41.177202
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class A:
        i: int
        j: int = 2
        k: str = 'aoeu'

    @dataclass_json
    @dataclass
    class B:
        i: int
        j: typing.List[A]

    a = A(1)
    b = B(i=1, j=[a, a])

    s = SchemaF()
    ser = s.dump(a)
    sern = s.dumps(a)
    serl = s.dump([a, a])
    serln = s.dumps([a, a])

    s = SchemaF()
    ser = s.dump(b)
    sern = s.dumps(b)



# Generated at 2022-06-23 16:45:48.226636
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test for the SchemaF.loads method
    from marshmallow import Schema, fields
    from typing import List

    class MySchema(SchemaF[List[str]]):
        a = fields.Integer()

    my_schema = MySchema()
    assert my_schema.loads([{'a': 1}]) == [{'a': 1}]

    my_schema = MySchema()
    assert my_schema.loads({'a': 1}, many=None) == {'a': 1}

# Generated at 2022-06-23 16:45:53.717606
# Unit test for function schema
def test_schema():
    from marshmallow import Schema, fields, post_load
    from dataclasses_json import dataclass_json, config
    from dataclasses import dataclass
    import typing
    import marshmallow
    from marshmallow import Schema, fields, post_load
    from dataclasses_json import dataclass_json, config
    from dataclasses import dataclass
    import typing

    @dataclass
    class User:
        age: int
        name: str

    @dataclass_json
    @dataclass
    class User:
        age: int
        name: str


    class UserSchema(Schema):
        age = fields.Int()
        name = fields.Str()

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)



# Generated at 2022-06-23 16:45:57.304861
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert isinstance(SchemaF[str], typing.Type)
    assert issubclass(SchemaF[str], Schema)
    assert SchemaF[str].__name__ == "SchemaF"



# Generated at 2022-06-23 16:46:09.007089
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field_1 = _IsoField(
        load_from = "field1",
        dump_to = "field2",
        allow_none = False,
        missing = None,
        required = True,
        validate = None,
        error_messages = None
    )
    iso_field_2 = _IsoField()
    assert iso_field_1.load_from == "field1"
    assert iso_field_1.dump_to == "field2"
    assert iso_field_1.allow_none == False
    assert iso_field_1.missing == None
    assert iso_field_1.required == True
    assert iso_field_1.validate == None
    assert iso_field_1.error_messages == None
    
    assert iso_field_2.load_from == None


# Generated at 2022-06-23 16:46:17.362051
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    @dataclass
    class Employee(DataClassJsonMixin):
        name: str
    @dataclass
    class Student(DataClassJsonMixin):
        name: str
    data = [{"class": "Employee", "name": "a"}, {"class": "Student", "name": "b"}]
    schema = SchemaF[typing.Union[Employee, Student]]()
    objs = schema.load(data, many=True)
    assert objs[0].name == "a"
    assert objs[1].name == "b"


# Generated at 2022-06-23 16:46:23.173375
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import Union

    class A(object):
        pass

    @dataclasses.dataclass
    class B(object):
        a: Union[A, str]
        b: int

    schema = SchemaF[B](
        type_='list'
    )

    assert schema.load([{'a': 'some_string', 'b': 1}]) == [B(a='some_string', b=1)]



# Generated at 2022-06-23 16:46:32.692784
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class Human(object):
        name: str
        age: int = 42

    class HumanSchema(SchemaF[Human]):
        name = fields.String()
        age = fields.Integer()

    schema = HumanSchema()

    res = schema.load({'name': 'Paul', 'age': 13})
    assert(res.name == 'Paul')
    assert(res.age == 13)

    res = schema.load([{'name': 'Paul', 'age': 13}, {'name': 'Elizabeth', 'age': 6}])
    assert(res[0].name == 'Paul')
    assert(res[0].age == 13)
    assert(res[1].name == 'Elizabeth')
    assert(res[1].age == 6)


# Generated at 2022-06-23 16:46:37.698818
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Test for dict input
    x: SchemaF[A] = SchemaF()
    assert x.dumps({"a": 1}, many=False) == '{"a": 1}'

    # Test for list input
    assert x.dumps([{"a": 1}, {"b": 23}], many=True) == '[{"a": 1}, {"b": 23}]'



# Generated at 2022-06-23 16:46:47.569835
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Dict, Union

    @dataclass
    class A:
        x: int
        y: int

    @dataclass
    class B:
        x: int
        y: str

    @dataclass
    class C:
        a: Union[A, B]

    class D(Enum):
        a = 1
        b = "b"

    class E(Enum):
        c = 1
        d = "c"

    @dataclass
    class F:
        d: Union[D, E]

    @dataclass
    class G:
        d: Union[D, str]

    @dataclass
    class H:
        d: Union[int, str]


# Generated at 2022-06-23 16:46:49.119942
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None)



# Generated at 2022-06-23 16:46:50.224510
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class TestSchema(SchemaF[int]):
        pass



# Generated at 2022-06-23 16:46:56.543580
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Data:
        a: str = field(metadata=dict(dataclasses_json = dict(mm_field = fields.Str(required = True))))
        b: str
    DataSchema = build_schema(Data, Schema, False, False)
    assert(DataSchema.__name__ == 'DataSchema')
    assert(DataSchema.Meta.fields == ('a', 'b'))
    assert(DataSchema.__dict__.keys() == {'Meta', 'make_data', 'a', 'b', 'dumps', 'dump'})
    assert(isinstance(DataSchema.a, fields.Str))
    assert(isinstance(DataSchema.b, fields.Str))
    assert(DataSchema.__dict__['a'].required == True)

# Generated at 2022-06-23 16:47:04.781374
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclasses.dataclass
    class T:
        a: str

    @dataclasses.dataclass
    class C:
        ts: typing.List[T]
    t = T("a")
    c = C([t])
    s = dataclasses_json.Schema.from_dataclass(C)
    json_str = s.dumps(c)
    r = s.loads(json_str)
    assert r == c

# Generated at 2022-06-23 16:47:09.432633
# Unit test for constructor of class _IsoField
def test__IsoField():
    isoField = _IsoField()

    assert(isoField._deserialize("2000-01-01T00:00:00") == datetime(2000, 1, 1, 0, 0))
    assert(isoField._serialize(datetime(2000, 1, 1, 0, 0)) == "2000-01-01T00:00:00")


# Generated at 2022-06-23 16:47:13.360126
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import fields

    @dataclasses.dataclass
    class Dummy:
        name: str

    class DummySchema(SchemaF[Dummy]):
        __dataclass_fields__ = {
            'name': 'name',
        }
        name = fields.Str(required=True)

    # test if dump with two @dataclasses works
    data = [Dummy(name='A'), Dummy(name='B')]
    res_ = DummySchema().dump(data)
    res_ = [res_.pop() for _ in range(len(data))]
    expected_ = [{'name': 'A'}, {'name': 'B'}]
    assert res_ == expected_

    # test if dump with one @dataclass works
    data = D

# Generated at 2022-06-23 16:47:15.241985
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestampfield = _TimestampField()
    assert timestampfield != None
# End unit test for constructor of class _TimestampField



# Generated at 2022-06-23 16:47:21.361120
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema
    from marshmallow.fields import Nested
    from typing_extensions import Literal
    from dataclasses import dataclass
    import marshmallow as ma
    from datetime import datetime

    class MyNested(Schema):
        a = ma.fields.String()

    @dataclass
    class MyClass:
        my_field: str
        my_nested: MyNested
        my_int: int

    class MySchema(SchemaF[MyClass]):
        my_field = ma.fields.String()
        my_nested = Nested(MyNested)
        my_int = ma.fields.Integer()

    MyClass(my_field='test', my_nested=MyNested(), my_int=1)

    schema = MySchema()

# Generated at 2022-06-23 16:47:31.170784
# Unit test for method load of class SchemaF
def test_SchemaF_load():

    class MySchema(SchemaF[A]):
        pass

    class C(typing.NamedTuple):
        x: int
        y: typing.List[int]

    class User:
        def __init__(self, name: str, age: int, email: typing.Optional[str]):
            self.name = name
            self.age = age
            self.email = email

    schema = MySchema(strict=True)
    res = schema.load({"name": "Monty", "age": 42})  # type: ignore
    res = schema.load([{"name": "Monty", "age": 42}])  # type: ignore
    res = schema.load(None, many=True)  # type: ignore
    res = schema.load(None, many=False)  # type: ignore


# Generated at 2022-06-23 16:47:33.737728
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField({complex: fields.Field()}, str, str).desc == {complex: fields.Field()}
    assert _UnionField({complex: fields.Field()}, str, str).cls == str
    assert _UnionField({complex: fields.Field()}, str, str).field == str


# Generated at 2022-06-23 16:47:35.062744
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # type: () -> None
    with pytest.raises(NotImplementedError):
        SchemaF()


# Generated at 2022-06-23 16:47:37.869235
# Unit test for function build_schema
def test_build_schema():
    from marshmallow_dataclass import class_schema
    import marshmallow
    class Data:
        pass

    try:
        kv = class_schema(Data) # our method
    except:
        pass
    try:
        kv = marshmallow.class_schema(Data,unknown='EXCLUDE') # Marshmallow method
    except:
        pass


# Generated at 2022-06-23 16:47:42.067939
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional, Dict

    @dataclass
    class data:
        i: Dict
    assert schema(data, '', False)['i'] == dict



# Generated at 2022-06-23 16:47:50.220674
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class MyDC:
        a: int

    sch = MyDC.schema()
    #  @typing.overload
    #  def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
    #      TEncoded]:  # type: ignore
    assert sch.dump([MyDC(a=2), MyDC(a=3)]) == [{"a": 2}, {"a": 3}]
    # @typing.overload
    # def dump(self, obj: A, many: bool = None) -> TEncoded:
    assert sch.dump(MyDC(a=2)) == {"a": 2}


# Unit tests for method load of class SchemaF

# Generated at 2022-06-23 16:47:53.206670
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import dataclasses
    X = dataclasses.dataclass(frozen=True)
    x = X(1, 2, 3)
    y = SchemaF[X].dumps(x)


# Generated at 2022-06-23 16:47:55.822562
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField(desc=None, cls=None, field=None)



# Generated at 2022-06-23 16:47:59.746698
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert typing.get_type_hints(SchemaF) == {}

    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:48:09.535383
# Unit test for constructor of class _IsoField

# Generated at 2022-06-23 16:48:11.959938
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = fields.Field(missing=None)
    from marshmallow.validate import Range
    field = fields.Float(validate=Range(min=0., max=100.),required=False,allow_none=True)


# Generated at 2022-06-23 16:48:13.480270
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF[int]()  # raises NotImplementedError



# Generated at 2022-06-23 16:48:15.151859
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField() is not None


# Generated at 2022-06-23 16:48:25.177098
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import marshmallow

    class Foo(marshmallow.Schema):
        pass

    class Bar(marshmallow.Schema):
        pass

    def test_foo(foo: SchemaF[Foo]) -> None:
        pass

    def test_bar(bar: SchemaF[Bar]) -> None:
        pass

    def test_two(foo: SchemaF[Foo], bar: SchemaF[Bar]) -> None:
        pass



# Generated at 2022-06-23 16:48:34.449977
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: (...) -> None
    class User(typing.NamedTuple):
        username: str
        password: str

    class UserSchema(SchemaF[User]):
        username = fields.String()
        password = fields.String()

    user = User(username='vlkv', password='pswd')
    schema = UserSchema()

    json_data = schema.dumps(user)
    assert isinstance(json_data, str)
    assert json_data == '{"username": "vlkv", "password": "pswd"}'

    json_data = schema.dumps(user, many=False)
    assert isinstance(json_data, str)
    assert json_data == '{"username": "vlkv", "password": "pswd"}'


# Generated at 2022-06-23 16:48:45.447116
# Unit test for function build_type
def test_build_type():
    from typing import Optional, ClassVar
    from marshmallow import fields
    from dataclasses_json.mm_field import build_type

    @dataclass
    class TestType:
        ts: Optional[datetime]
        dc: Optional[str]
        u: Optional[Union[datetime, str]]
        m: Optional[MutableMapping[str, str]]
        s: Optional[str]

        class Meta:
            dataclass_json = {
                "mm_field": {
                    "u": {
                        "mm_field": {
                            str: {"load_only": True},
                            datetime: {"dump_only": True}
                        }
                    }
                }
            }

    @dataclass
    class TestType2:
        t: Optional[TestType]


# Generated at 2022-06-23 16:48:49.317438
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class PersonDC:
        name: str

    class Person(SchemaF[PersonDC]):
        name = fields.Str()

    json_data = b'{"name": "Alfie"}'
    john = Person().loads(json_data)
    assert john.name == "Alfie"

# Generated at 2022-06-23 16:49:00.848729
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List

    class ArticleSchema(SchemaF[Article]):
        title = fields.Str()

    from dataclasses import dataclass
    class Article:
        title: str

    @dataclass
    class Blog:
        articles: List[Article]

    article = Article(title='Foo')
    blog = Blog([article])

    schema = ArticleSchema()
    assert schema.dump(article) == {'title': 'Foo'}
    assert schema.dump(blog) == [{'title': 'Foo'}]

    schema = ArticleSchema(many=True)
    assert schema.dump(article) == [{'title': 'Foo'}]
    assert schema.dump(blog) == [{'title': 'Foo'}]



# Generated at 2022-06-23 16:49:12.253418
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from uuid import UUID
    from typing import Union, List

    class _TimestampField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            if value is not None:
                return value.timestamp()
            else:
                if not self.required:
                    return None
                else:
                    raise ValidationError(self.default_error_messages["required"])

        def _deserialize(self, value, attr, data, **kwargs):
            if value is not None:
                return _timestamp_to_dt_aware(value)
            else:
                if not self.required:
                    return None

# Generated at 2022-06-23 16:49:19.052634
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts_field = _TimestampField()
    assert ts_field._serialize(None, None, None) is None
    assert ts_field._serialize(datetime.now(), None, None) is not None
    assert ts_field._deserialize(None, None, None) is None
    assert ts_field._deserialize(0, None, None) is not None



# Generated at 2022-06-23 16:49:26.323636
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> typing.Any
    obj = None  # type: typing.Any
    many = True  # type: bool
    partial = None  # type: typing.Any
    unknown = 'strict'  # type: str
    data = []  # type: typing.Any
    obj = SchemaF.load(data, many, partial, unknown)
    partial = False  # type: bool
    obj = SchemaF.load(data, many, partial, unknown)
    data = {}  # type: typing.Any
    obj = SchemaF.load(data, many, partial, unknown)
    partial = True  # type: bool
    obj = SchemaF.load(data, many, partial, unknown)


# Generated at 2022-06-23 16:49:37.937294
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    data = {'__type': '', 'name': 'Test'}
    schema = SchemaF()
    schema.loads(data)


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:49:46.610742
# Unit test for function schema
def test_schema():
    import core
    class Foo:
        x: int = 1
        s: str = "foo"
        y: typing.Optional[int] = None
    cls = Foo
    mixin = core.json_dataclass
    infer_missing = False
    test_schema_dict = schema(cls, mixin, infer_missing)
    assert test_schema_dict == {'x': fields.Int(allow_none=False, data_key='x', missing=1), 
                                's': fields.Str(allow_none=False, data_key='s', missing='foo'), 
                                'y': fields.Int(allow_none=True, data_key='y', missing=None)}
    print('Success!')

# Generated at 2022-06-23 16:49:58.900748
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import Optional
    from marshmallow import Schema, fields

    class PersonSchema(Schema):
        name = fields.Str()
        age = fields.Number()

    class Person(object):
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    sch = SchemaF[Person]()
    assert sch.dumps(Person('test', 10)).strip('"') == '{"name": "test", "age": 10}'

    class PersonOptionalAgeSchema(Schema):
        name = fields.Str()
        age = fields.Number(allow_none=True)

    class PersonOptionalAge(object):
        def __init__(self, name: str, age: Optional[int]):
            self.name = name
            self.age = age

# Generated at 2022-06-23 16:50:00.372972
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField('required', default=MISSING)


# Generated at 2022-06-23 16:50:01.924086
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass



# Generated at 2022-06-23 16:50:10.435490
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    data = [1, 2, 3]
    res = SchemaF[int].dump(data, many=True)
    assert isinstance(res, typing.List[TEncoded])

    data = 1
    res = SchemaF[int].dump(data, many=False)
    assert isinstance(res, TEncoded)

    data = [1, 2, 3]
    res = SchemaF[int].dump(data, many=False)
    assert isinstance(res, TEncoded)

    data = 1
    res = SchemaF[int].dump(data, many=True)
    assert isinstance(res, typing.List[TEncoded])

    data = [1, 2, 3]
    res = SchemaF[int].dump(data)

# Generated at 2022-06-23 16:50:12.653439
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def _f():
        schema: SchemaF[int] = \
            SchemaF()  # generate error
    _f()


# Generated at 2022-06-23 16:50:17.706450
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow
    from dataclasses_json.api import dump
    from dataclasses import dataclass

    @dataclass
    class PersonF:
        name: str

    @dataclass
    class PeopleF:
        people: typing.List[PersonF]

    class PeopleSchema(SchemaF[PeopleF], marshmallow.Schema):
        people = fields.Nested(lambda: SchemaF[PersonF], many=True)

    people = PeopleF(people=[PersonF('Foo'), PersonF('Bar')])
    assert dump(people, schema=PeopleSchema()) == dump(people, schema=PeopleSchema, many=True)



# Generated at 2022-06-23 16:50:26.447970
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import overload
    from dataclasses import dataclass
    from marshmallow_enum import EnumField
    import enum
    import typing

    @dataclass
    class Key(enum.Enum):
        key = 0

    @dataclass
    class Value:
        key: Key
        name: str

    class ValueSchema(SchemaF):
        key = EnumField(Key)

        @overload
        def __init__(self):
            ...

        # noinspection PyShadowingBuiltins
        @overload
        def __init__(self, strict: bool = ...):  # type: ignore
            ...

        @overload
        def __init__(self, partial: bool = ...):  # type: ignore
            ...

        # noinspection PyShadowingBuiltins

# Generated at 2022-06-23 16:50:37.966066
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields, post_load
    from .test_stub import Book

    @dataclass
    class Book2:
        author: str
        name: str

        @post_load
        def make_object(self, data, **kwargs):
            return Book2(**data)

    class Book2Schema(SchemaF[Book2]):
        author = fields.Str()
        name = fields.Str()

    # If a list is passed to load,
    s = Book2Schema()
    l: List[Book2] = s.load([{'author': 'test', 'name': 'test2'},
        {'author': 'test3', 'name': 'test4'}])
    assert len(l) == 2

# Generated at 2022-06-23 16:50:41.173983
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field._serialize(datetime(2020, 5, 31, 10, 24, 0), None, None)
    field._deserialize('1590968640', None, None)


# Generated at 2022-06-23 16:50:49.001334
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None) != None
    assert _TimestampField()._deserialize(datetime.utcnow().timestamp(), None, None) != None
    try:
        assert _TimestampField()._serialize(None, None, None) != None
    except ValidationError as e:
        assert "required" in str(e)
    try:
        assert _TimestampField()._deserialize(None, None, None) != None
    except ValidationError as e:
        assert "required" in str(e)


# Generated at 2022-06-23 16:51:00.843733
# Unit test for function build_type
def test_build_type():
    opts = dict(allow_none=True, required=True)
    mixin_class = None
    field = None
    defn = 'test'

    def test_case(type_, expected_type):
        assert isinstance(build_type(type_, opts, mixin_class, field, defn),
                          expected_type)

    test_case(list, fields.List)
    test_case(list[str], fields.List)
    test_case(Union[str, int], fields.Field)
    test_case(Optional[str], fields.Str)
    test_case(Optional[Optional[str]], fields.Str)
    test_case(Mapping[str, int], fields.Mapping)
    test_case(Any, fields.Raw)
    test_case(int, fields.Int)

# Generated at 2022-06-23 16:51:10.480405
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema, fields

    class Model:
        def __init__(self):
            self.name = 'foo'

    class TestSchema(SchemaF[Model]):
        name = fields.Str()

    schema = TestSchema()
    m = schema.load({'name': 'bar'})
    assert m.name == 'bar'

    # This operation must be a type error
    # schema = TestSchema()
    # m: Model = schema.load({'name': 'bar'})
    # assert m.name == 'bar'



# Generated at 2022-06-23 16:51:20.432068
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional, Union, List
    from enum import Enum
    from dataclasses import dataclass
    from datetime import date
    from decimal import Decimal

    class Gender(Enum):
        MALE = "M"
        FEMALE = "F"

    @dataclass
    class User:
        id: int
        name: str
        gender: Union[Gender, str]
        nickname: Optional[str] = None
        friends: List[int] = field(default_factory=list)
        children: Set[int] = field(default_factory=set)
        birth_date: Optional[date] = None
        address: "Address" = field(default_factory=lambda: Address())
        some_decimal: Decimal = field(default=10.2)



# Generated at 2022-06-23 16:51:25.461241
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField(required=True)
    assert f._serialize(datetime.now(), "attr", None)
    assert f._deserialize("2005-04-03T23:30:00", "attr", None) is not None


# Generated at 2022-06-23 16:51:31.506413
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _timestamp_to_dt_aware(0).timestamp() == 0
    assert _TimestampField().deserialize(0).timestamp() == 0
    assert _TimestampField().serialize(_timestamp_to_dt_aware(0)).timestamp() == 0


# Generated at 2022-06-23 16:51:41.441695
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    # object == object with _IsoField serialize
    _value = datetime(1970, 1, 1)
    assert field._serialize(_value, None, None) == field._serialize(_value, None, None)
    # object with _IsoField deserialize == object with _IsoField deserialize
    assert field._deserialize(field._serialize(_value, None, None), None, None) == field._deserialize(field._serialize(_value, None, None), None, None)
    # object with _IsoField serialize == object with _IsoField deserialize
    assert field._serialize(_value, None, None) == field._deserialize(field._serialize(_value, None, None), None, None)



# Generated at 2022-06-23 16:51:43.805158
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsf = _TimestampField()
    assert tsf is not None



# Generated at 2022-06-23 16:51:53.286986
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info < (3, 7):
        pass
    else:
        # Test that constructor of SchemaF raises exception
        try:
            SchemaF()
            raise AssertionError('This should have raised an exception')
        except NotImplementedError as e:
            pass

        # Test for dump
        class S(Schema):
            field = fields.Str()

        @dataclass
        class D:
            field: str

        s = S()
        d = D('test')
        assert s.dump(d) == {'field': 'test'}
        assert s.dump([d]) == [{'field': 'test'}]

# Generated at 2022-06-23 16:51:56.980924
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    _ = SchemaF([str], many=bool)  # type: ignore



# Generated at 2022-06-23 16:52:06.252479
# Unit test for function build_type
def test_build_type():
    import typing
    from enum import Enum
    from dataclasses import dataclass

    class MyEnum(Enum):
        hello = 0
        world = 1

    @dataclass
    class MmMixin:
        _mm_field = 'hello'

    @dataclass
    class X(MmMixin):
        _mm_field: int

    assert build_type(X, {}, MmMixin, None, None) == fields.Nested(X.schema(), _mm_field='hello')
    assert build_type(typing.List[X], {}, MmMixin, None, None) == fields.Nested(X.schema(), many=True, _mm_field='hello')

# Generated at 2022-06-23 16:52:08.272216
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert 3 + 5 == 8

# Generated at 2022-06-23 16:52:15.120790
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.NamedTuple):
        bar: str
        moo: int


    @typing.no_type_check
    def test_create_SchemaF() -> None:
        SchemaF[Foo]()


    test_create_SchemaF()


SchemaF = typing.TypeVar('SchemaF')



# Generated at 2022-06-23 16:52:23.754013
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class Obj1:
        foo: int

    @dataclasses.dataclass
    class Obj2:
        foo: typing.List[int]

    @dataclasses.dataclass
    class Obj3:
        foo: typing.Dict[str, int]

    @dataclasses.dataclass
    class Obj4:
        foo: typing.List[Obj1]

    @dataclasses.dataclass
    class Obj5:
        foo: typing.Dict[str, Obj1]

    @dataclasses.dataclass
    class Obj6:
        foo: typing.List[typing.List[int]]

    @dataclasses.dataclass
    class Obj7:
        foo: typing.List[typing.Dict[str, int]]

   

# Generated at 2022-06-23 16:52:36.209152
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import marshmallow
    from datetime import datetime
    from marshmallow.fields import String
    v = _TimestampField()
    print(v)
    assert v is not None
    assert issubclass(v.__class__, String)
    assert v.deserialize(None) is None
    assert isinstance(v.deserialize(0.0), datetime)
    assert isinstance(v.deserialize(0.0, a=1), datetime)
    assert isinstance(v.deserialize(0.0, a=1, b=2), datetime)
    assert isinstance(v.deserialize(0.0, a=1, b=2, c=3), datetime)
    assert v.serialize(None) is None

# Generated at 2022-06-23 16:52:49.418954
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing
    import marshmallow
    import dataclasses_json
    from marshmallow_oneofschema import OneOfSchema
    from marshmallow import fields
    from dataclasses import dataclass, field
    from datetime import datetime, timedelta
    from typing import Optional, List, Union, Dict, Any, Literal
    from decimal import Decimal
    from uuid import UUID
    from dataclasses_json import DataClassJsonMixin
    from marshmallow_dataclass import dataclass as mmdataclass
    from marshmallow_dataclass import NewType
    from enum import Enum
    from marshmallow_enum import EnumField

# Generated at 2022-06-23 16:52:57.604319
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Model:
        pass
    m = Model()
    m.a = True
    m.b = "B"
    m2 = Model()
    m2.a = False
    m2.b = "C"
    many = [m, m2]
    single = m
    sf = SchemaF()
    assert sf.load(many) == many
    assert sf.load(single) == single


# Generated at 2022-06-23 16:53:01.534728
# Unit test for constructor of class _IsoField
def test__IsoField():
    schema = Schema()
    schema.declared_fields["iso"] = _IsoField()
    data = {"iso": "2020-06-09T15:58:34.572880"}
    result = schema.load(data)
    assert result.data["iso"] == datetime(2020, 6, 9, 15, 58, 34, 572880)
    data = {"iso": None}
    result = schema.load(data)
    assert result.data["iso"] is None


# Generated at 2022-06-23 16:53:03.722779
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Something(SchemaF[str]):
        field = fields.Str()



# Generated at 2022-06-23 16:53:10.864234
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(default=datetime(2019,4,4,4,4))._serialize(None,None,None) == datetime(2019,4,4,4,4).timestamp()
    assert _TimestampField(default=datetime(2019,4,4,4,4))._deserialize("0.0") == datetime(1969,12,31,19,0)


# Generated at 2022-06-23 16:53:20.647890
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional

    class TInt(int):
        pass

    @dataclass
    class A:
        b: int
        c: str = "2"

    @dataclass(json_module="bla")
    class B:
        a: A
        d: float = 2.0
        e: Optional[TInt] = None

    b = build_type(B, {}, None, None, None)
    assert repr(b) == (
        "Nested(allow_none=False, load_only=False, dump_only=False, "
        "missing=MISSING, error_messages={}, partial=False, unknown=EXCLUDE, "
        "context=None, schema=<class 'test_schema.A'>, many=False)")

# Generated at 2022-06-23 16:53:31.268201
# Unit test for constructor of class _IsoField
def test__IsoField():
    str_1 = _IsoField()._serialize(datetime.fromisoformat('2018-03-08T06:26:36'), 'attr','obj')
    assert str_1 == "2018-03-08T06:26:36"
    dt_1 = _IsoField()._deserialize('2018-03-08T06:26:36', 'attr','obj')
    assert dt_1 == datetime.fromisoformat('2018-03-08T06:26:36')


# Generated at 2022-06-23 16:53:41.487162
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    if sys.version_info >= (3, 7):
        assert build_type(typing.Optional[int], {}, None, None, None) == fields.Int(allow_none=True)
        assert build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int)
        assert build_type(typing.List[typing.Union[str, int]], {}, None, None, None) == _UnionField()
        assert build_type(typing.Union[str, int], {}, None, None, None) == _UnionField()
        assert build_type(typing.Dict[str, int], {}, None, None, None) == fields.Dict(fields.Int)
       

# Generated at 2022-06-23 16:53:49.366032
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class IntSchema(SchemaF[int]):
        pass

    assert IntSchema().dumps(1) == '1'
    assert IntSchema().dumps([1, 2, 3]) == '[1, 2, 3]'

    class BarSchema(SchemaF[A]):
        @post_load
        def post_load(self, data):
            return data['a']

    class FooSchema(SchemaF[A]):
        a = fields.Int()
        b = fields.List(fields.Nested(BarSchema))

    cls = FooSchema()
    assert cls.dumps(1) == '{"a": 1}'
    assert cls.dumps([1, 2, 3]) == '[{"a": 1}, {"a": 2}, {"a": 3}]'
    assert cls

# Generated at 2022-06-23 16:53:52.327147
# Unit test for function build_schema
def test_build_schema():
    class Point:
        x: int
        y: int
    class Circle:
        center: Point
        radius: int
        r: int = None
    g_cls = dataclasses.make_dataclass('Global', (object, ), {})
    def test(cls):
        type(build_schema(cls, g_cls, False, False))
    test(Point)
    test(Circle)
    class Rectangle:
        p1: Point
        p2: Point
    test(Rectangle)

# Generated at 2022-06-23 16:53:57.932860
# Unit test for constructor of class _UnionField
def test__UnionField():
    new_field = _UnionField(
        desc=({UnionType1: Schema1}, {UnionType2: Schema2},),
        cls="cls",
        field=MagicMock(),
    )
    assert new_field.desc == ({UnionType1: Schema1}, {UnionType2: Schema2},)
    assert new_field.cls == "cls"
    assert new_field.field == MagicMock()



# Generated at 2022-06-23 16:54:00.963971
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcfromtimestamp(0), None, None) == 0
    assert _TimestampField()._deserialize(0, None, None) == datetime.utcfromtimestamp(0)



# Generated at 2022-06-23 16:54:11.760254
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A(Enum):
        A = 1

    class B(Enum):
        B = 1

    field = _UnionField({str: fields.Str(), A: EnumField(A)}, None, None)
    assert field._serialize('a') == 'a'
    assert field._serialize(A.A) == '1'
    assert field._deserialize('a') == 'a'
    assert field._deserialize(1) == A.A
    with pytest.raises(ValidationError):
        field._serialize(B.B)
    with pytest.raises(ValidationError):
        field._deserialize(2)



# Generated at 2022-06-23 16:54:20.479420
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class _A:
        a: int

    @dataclass
    class _B:
        b: int

    @dataclass
    class _ABC:
        abc: typing.Union[_A, _B]

    schema = Schema.from_dataclass(_ABC)

    dataclass_field = dc_fields(_ABC)['abc']
    union_field = dataclass_field.type
    assert is_union_type(union_field)
    schema_field = schema.fields['abc']
    assert isinstance(schema_field, _UnionField)
    assert schema_field.desc == {_A: schema, _B: schema}
    assert schema_field.cls == _ABC
    assert schema_field.field == dataclass_

# Generated at 2022-06-23 16:54:24.949217
# Unit test for function build_schema
def test_build_schema():
    _t = build_schema(Cats, dataclass_json.DataClassJsonMixin, False, True)
    assert(isinstance(_t, type))
    assert(_t.__name__ == 'CatsSchema')


# Generated at 2022-06-23 16:54:29.256142
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    #_TimestampField()

    assert(_TimestampField()._serialize(datetime.now(), None, None, None) == float)
    assert(_TimestampField()._deserialize(datetime.now().timestamp(), 
                                          None, None, None) == datetime)



# Generated at 2022-06-23 16:54:30.728828
# Unit test for function schema
def test_schema():
    assert schema._schema(cls, mixin, infer_missing)

# Generated at 2022-06-23 16:54:37.374215
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    import json

    @dataclass
    class Point:
        x: float
        y: float

    class PointSchema(Schema):
        x = fields.Float()
        y = fields.Float()

    class PointSchemaF(SchemaF[Point]):
        x = fields.Float()
        y = fields.Float()

    ps = PointSchema()
    psf = PointSchemaF()
    point_data = {'x': 4.4, 'y': 3.3}
    point = Point(4.4, 3.3)

    x = psf.load(json.dumps(point_data))
    assert isinstance(x, Point)

# Generated at 2022-06-23 16:54:39.270183
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        d = datetime.today()
        _IsoField()._deserialize(d.isoformat(), None, None)
        datetime.fromisoformat(d.isoformat())
    except Exception as e:
        print(e)



# Generated at 2022-06-23 16:54:47.401722
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Test(SchemaF[int]):
        pass
    assert Test().dump([1, 2, 3], many=True) == [1, 2, 3]
    assert Test().dump([1, 2, 3], many=False) == {'data': [1, 2, 3]}
    assert Test().dump(1, many=True) == 1
    assert Test().dump(1, many=False) == {'data': 1}


# Generated at 2022-06-23 16:54:56.131217
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema  # type: ignore
    from marshmallow_enum import EnumField  # type: ignore
    from dataclasses import dataclass
    from enum import Enum

    class Color(str, Enum):
        RED = "red"
        GREEN = "green"
        BLUE = "blue"

    @dataclass
    class Name:
        first: str

    @dataclass
    class NameSchema(Schema):
        first: str = fields.Str()

        @post_load
        def post_load(self, data, **kwargs):
            return Name(**data)

    @dataclass
    class Person:
        name: Union[Name, str]
        gender: str = 'male'
        color: Color = Color.RED


# Generated at 2022-06-23 16:54:58.290478
# Unit test for constructor of class _UnionField
def test__UnionField():
    uf = _UnionField(None, None, None)
    assert uf is not None


# Generated at 2022-06-23 16:55:02.699190
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF.dump(A, [A()], many=True)
    s = SchemaF.dump(A(), many=False)
    s = SchemaF.dump(A(), many=False)


# Generated at 2022-06-23 16:55:04.466696
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    u = SchemaF()
    assert u.dumps([]) == []

