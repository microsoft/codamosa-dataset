

# Generated at 2022-06-23 16:45:02.530768
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        _ignore = SchemaF()


Sc = typing.TypeVar('Sc', bound=Schema)
TEncoded2 = typing.Dict[str, typing.Any]



# Generated at 2022-06-23 16:45:09.372785
# Unit test for constructor of class SchemaF
def test_SchemaF():
    sf = SchemaF[int](fields=['num'])

    sf.dump([1, 2])
    sf.dump(1)

    sf.dumps([1, 2])
    sf.dumps(1)

    sf.load([{'num': 1}, {'num': 2}])
    sf.load({'num': 1})

    sf.loads(b'[{"num": 1}, {"num": 2}]')
    sf.loads(b'{"num": 1}')


# Our own version of partial, which allows us to pass a type
# See also https://github.com/gumuz/dataclasses-json/issues/64

# Generated at 2022-06-23 16:45:10.460119
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField is not None


# Generated at 2022-06-23 16:45:18.814366
# Unit test for function schema
def test_schema():
    assert schema({
        'field': typing.Dict[str, str],
        'field2': typing.Dict[str, typing.Optional[str]]
    }, {
        'field': fields.Dict,
        'field2': fields.Dict
    }) == {
        'field': fields.Dict[str, str],
        'field2': fields.Dict[str, typing.Optional[str]],
    }
    assert schema({
        'field': typing.Dict[str, typing.Optional[str]]
    }, {
        'field': fields.Dict
    }) == {
        'field': fields.Dict[str, typing.Optional[str]],
    }

# Generated at 2022-06-23 16:45:26.187477
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class Person:
        name: str

    assert SchemaF[Person].dump(Person('Florent')) == {'name': 'Florent'}
    assert SchemaF[Person].dump(Person('Florent'), many=False) == {'name':
                                                                    'Florent'}
    assert SchemaF[Person].dump([Person('Florent')]) == [{'name': 'Florent'}]
    assert SchemaF[Person].dump([Person('Florent')], many=True) == [
        {'name': 'Florent'}]



# Generated at 2022-06-23 16:45:28.537741
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField(default=datetime.now()).default == datetime.now()


# Generated at 2022-06-23 16:45:33.469378
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def t1(data: TOneOrMulti, many: bool) -> TOneOrMultiEncoded:
        return data

    def t2(data: TOneOrMulti, many: bool) -> TOneOrMultiEncoded:
        return data
    # mypy is missing a check that many is a keyword argument and therefore we ignore the error
    t1(data=[], many=True)  # type: ignore
    t2(data=None, many=True)  # type: ignore



# Generated at 2022-06-23 16:45:42.186314
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass
    import marshmallow_dataclass.mixin as mc
    @dataclass
    class B(mc.SchemaMixin):
        x: Optional[str]
    @dataclass
    class A:
        b: B

    assert schema(A, mc.SchemaMixin, True) == {'b': {'allow_none': True, 'missing': None}}
    assert isinstance(schema(A, mc.SchemaMixin, True)['b'], fields.Nested)
    assert schema(A, mc.SchemaMixin, True)['b'].nested.__name__ == 'B'


# Generated at 2022-06-23 16:45:54.332313
# Unit test for function build_schema
def test_build_schema():
    # Given
    import pytest
    @dataclass
    class Dog:
        name: str
        age: int = 10
    # When
    S = build_schema(Dog, None, False, False)
    assert S.__name__ == "DogSchema"
    assert S.Meta.fields == ('age', 'name')
    assert S().dump(Dog("a", 1)) == {'age': 1, 'name': 'a'}
    assert S().dump(Dog("a")) == {'age': 10, 'name': 'a'}
    assert S.make_dog(S().load({'age': 1, 'name': 'a'})) == Dog("a", 1)
    with pytest.raises(ValidationError) as e:
        S().validate({})
    assert e.value.messages

# Generated at 2022-06-23 16:46:00.136456
# Unit test for function build_schema
def test_build_schema():
    schema = build_schema(dataclass_json.tests.test_schema.m1.Simple, None, False, False)
    assert issubclass(schema, Schema)
    assert 'a' in schema._declared_fields
    assert 'b' in schema._declared_fields
    assert 'Meta' in schema.__dict__
    assert 'make_simple' in schema.__dict__
    assert 'dumps' in schema.__dict__
    assert 'dump' in schema.__dict__

# Generated at 2022-06-23 16:46:01.277927
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF[A].load(A()) == {}



# Generated at 2022-06-23 16:46:13.633345
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json
    @dataclass
    class ABC:
        a: int


    a = ABC(1)

    assert SchemaF[ABC].loads(js)



# Generated at 2022-06-23 16:46:20.310539
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        x: int
    class F(SchemaF):
        class Meta:
            fields = ('x',)
    assert F().dumps([Foo(1), Foo(2)]) == '[{"x": 1}, {"x": 2}]'
    assert F().dumps(Foo(1)) == '{"x": 1}'
    class F(SchemaF):  # type: ignore
        pass
    assert F().dumps(Foo(1)) == '{"x": 1}'
    assert type(F().dumps(Foo(1))) == str

# Generated at 2022-06-23 16:46:22.596443
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_serialized = _IsoField()._serialize(datetime.utcnow(), None, None)
    iso_deserialized = _IsoField()._deserialize(iso_serialized)



# Generated at 2022-06-23 16:46:30.692763
# Unit test for function schema
def test_schema():
    import typing
    import marshmallow_dataclass
    import dataclasses_json
    import marshmallow

    @dataclasses_json.dataclass_json(letter_case=dataclasses_json.LetterCase.CAMEL)
    @dataclasses.dataclass
    class JsonType:
        json_id: int
        json_value: typing.Optional[str]

        class Field(marshmallow_dataclass.class_schema(auto_dump=True,auto_load=True)):
            json_id: marshmallow.fields.Int = None
            json_value: typing.Optional[str] = None



# Generated at 2022-06-23 16:46:41.332584
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def test(s: SchemaF[A], data: TOneOrMultiEncoded, m: bool, p: bool, u: str) -> TOneOrMulti: ...
    def test_cast(s: SchemaF[int], data: TOneOrMultiEncoded, m: bool, p: bool, u: str) -> TOneOrMulti: ...
    def test_cast2(s: SchemaF[typing.List[int]], data: TOneOrMultiEncoded, m: bool, p: bool, u: str) -> TOneOrMulti: ...

    @post_load
    def make_user(self, data, **kwargs):
        return User(**data)


    class User(typing.NamedTuple):
        id: int


    class UserSchema(SchemaF[User]):
        id

# Generated at 2022-06-23 16:46:43.100614
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    SchemaF[int].load(1)


# Generated at 2022-06-23 16:46:48.097318
# Unit test for constructor of class _UnionField
def test__UnionField():
    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        u: typing.Union[A, B]

    res = _UnionField._serialize(
        _UnionField(None, C, dc_fields(C)[0])(), 'u', C())



# Generated at 2022-06-23 16:46:53.472562
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json
    from typing import Optional
    from dataclasses import dataclass
    from dataclasses_json.schema import SchemaF
    @dataclass
    class MyData(object):
        options: Optional[str] = None
        minimal: Optional[str] = None
    m = MyData(options = None, minimal = None)
    d = SchemaF[MyData]().dumps(m)
    ds = json.loads(SchemaF[MyData]().dumps(m))
    assert ds == {'options': None, 'minimal': None}


# Generated at 2022-06-23 16:47:01.204267
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class Test1:
        field1 = str
        field2 = int

    @dataclass
    class Test2:
        field1 = Test1
        field2 = str

    sch = schema(Test2, None, False)
    assert sch == {"field1": {"field1": {"type": "string"}, "field2": {"type": "integer"}}, "field2": {"type": "string"}}

# Generated at 2022-06-23 16:47:07.884201
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field._deserialize("2020-01-01T01:01:01") == datetime.fromisoformat("2020-01-01T01:01:01")
    assert iso_field._serialize(datetime.fromisoformat("2020-01-01T01:01:01")) == "2020-01-01T01:01:01"


# Generated at 2022-06-23 16:47:08.793473
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert not hasattr(SchemaF, "__new__")



# Generated at 2022-06-23 16:47:12.018755
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Test(Enum):
        TEST = 1
    class TestSchema(Schema):
        __enums__ = {
            'Test': Test
        }
        num = fields.Integer()

    TestSchema._declared_fields['test'] = _UnionField(
        {int: fields.Integer, Test: EnumField(Test)}, TestSchema,
        dc_fields(TestSchema)[2], missing=None, allow_none=True)



# Generated at 2022-06-23 16:47:20.454924
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from marshmallow import Schema, fields

    class Person:
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    @dataclass
    class PersonDC:
        name: str
        age: int

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

        @post_load
        def make_PersonDC(self, data, **kwargs):
            return PersonDC(**data)


# Generated at 2022-06-23 16:47:30.881567
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo:
        x: int

    foo1 = Foo(1)

    class FooSchema(SchemaF[Foo]):
        x = fields.Int(data_key='x')

    schema = FooSchema()
    data = schema.dump(foo1)
    print(data)

    assert isinstance(data, dict)
    assert data == {'x': 1}

    data = schema.dumps(foo1)
    print(data)

    assert isinstance(data, str)
    assert data == '{"x": 1}'

    cls, kwargs = schema.load(data)
    print(cls)

    assert isinstance(cls, Foo)
    assert cls.x == 1
    assert cls == Foo(1)


# Generated at 2022-06-23 16:47:36.707015
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = SchemaF[int]().dumps(1)
    b = SchemaF[int]().dumps([1])
    c = SchemaF[int]().dumps(SchemaF[int]().load(a))
    d = SchemaF[int]().dumps(SchemaF[int]().load(b), many=False)
    e = SchemaF[int]().dumps(SchemaF[int]().load(b))
    f = SchemaF[int]().dumps(SchemaF[int]().load(a), many=True)
    assert a == '1'
    assert b == '[1]'
    assert c == '1'
    assert d == '1'
    assert e == '1'
    assert f == '[1]'

# Generated at 2022-06-23 16:47:41.565289
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize("2019-01-01T00:00:00.000000", "", {}) == datetime(2019,1,1,0,0,0)


# Generated at 2022-06-23 16:47:50.159673
# Unit test for function build_type
def test_build_type():
    import dataclasses
    import typing
    import marshmallow
    from marshmallow import fields
    from dataclasses_json import dataclass_json, config
    from dataclasses_json.mm_schema import build_type
    # Test standard types
    assert build_type(int, {}, typing.Optional, dataclasses.Field(default=lambda : None), None) == fields.Int()
    assert build_type(UUID, {}, typing.Optional, dataclasses.Field(default=lambda : None), None) == fields.UUID()
    assert build_type(Decimal, {}, typing.Optional, dataclasses.Field(default=lambda : None), None) == fields.Decimal()
    assert build_type(bool, {}, typing.Optional, dataclasses.Field(default=lambda : None), None) == fields.B

# Generated at 2022-06-23 16:47:50.643546
# Unit test for function schema
def test_schema():
    pass

# Generated at 2022-06-23 16:47:53.011887
# Unit test for constructor of class SchemaF
def test_SchemaF():
    a = SchemaF[int]()
    assert a.load([1]) == [1]



# Generated at 2022-06-23 16:48:04.172942
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class X:
        pass

    _FC = fields.Field.__init__

    @dataclass
    class ClassUnion:
        cls: typing.Union[A, B, C] = None

    @dataclass
    class NewTypeUnion:
        nt: typing.Union[C, X] = None

    @dataclass
    class ComplexUnion:
        cls: typing.Union[ClassUnion, NewTypeUnion, C] = None

    @dataclass
    class PlainUnion:
        cls: typing.Union[str, int] = None

    class CustomField(fields.Field):
        def __init__(self, *args, **kwargs):
            self.inner_types = []
            self

# Generated at 2022-06-23 16:48:07.987011
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class TestClass(object):
        one: float
        two: str

# Generated at 2022-06-23 16:48:14.714935
# Unit test for function schema
def test_schema():
    import marshmallow
    import dataclasses_json
    import typing
    @dataclasses_json.dataclass_json
    class Person:
        name: str
        last_name: str
        age: int = dataclasses_json.field(metadata = {'dataclasses_json': {'mm_field': marshmallow.fields.Integer(validate=marshmallow.validate.Range(min=0))}})

    @dataclasses_json.dataclass_json
    class Other:
        name: str
        last_name: str
        age: int = dataclasses_json.field(metadata = {'dataclasses_json': {'mm_field': marshmallow.fields.Integer(validate=marshmallow.validate.Range(min=0))}})

# Generated at 2022-06-23 16:48:24.857764
# Unit test for function build_type
def test_build_type():
    from marshmallow.validate import Range
    from typing import Union, List, Optional
    from datetime import timedelta
    from datetime import date
    from marshmallow_enum import Enum
    from marshmallow import fields
    import dataclasses_json as dcj

    class DayOfWeek(Enum):
        MONDAY = "Mo"
        TUESDAY = "Tu"
        WEDNESDAY = "We"
        THURSDAY = "Th"
        FRIDAY = "Fr"
        SATURDAY = "Sa"
        SUNDAY = "Su"

    class SchemaM(Schema, dcj.SchemaABC):
        pass

    @dcj.dataclass_json
    @dataclasses.dataclass
    class A(SchemaM):
        field: int


# Generated at 2022-06-23 16:48:32.117392
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class MySchema(SchemaF[str]):
        pass
    # The `many` argument is passed. Therefore the return type is str
    assert isinstance(MySchema().load(""), str)
    # The `many` argument is not passed. Therefore the return type is list[str]
    assert isinstance(MySchema().load([]), list)
    assert isinstance(MySchema().load("a"), str)
    assert isinstance(MySchema().load("a", many=True), list)


# Generated at 2022-06-23 16:48:44.240051
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    import datetime

    @dataclass
    class Test:
        name: str
        not_optional: typing.List[int] = field(default_factory=lambda: [1, 2, 3])
        optional: typing.List[int] = field(default_factory=lambda: None)
        optional_generic: typing.Optional[typing.List[int]] = field(default_factory=lambda: None)

    @dataclass_json
    class A:
        test: typing.List[Test]
        optional_test: typing.Optional[typing.List[Test]] = None

    @dataclass_json
    class B:
        test: typing.List[Test]

# Generated at 2022-06-23 16:48:51.768019
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json.api import DataclassJsonMixin
    from typing import Optional, List

    class EnumM(Enum):
        m = "m"

    @dataclass
    class Nested(DataclassJsonMixin):
        v: str

    @dataclass
    class Test(DataclassJsonMixin):
        nested: Nested
        nested_list: List[Nested]
        optional: Optional[Nested]
        d: dict
        l: list
        s: str
        i: int
        f: float
        b: bool
        dt: datetime
        uuid: UUID
        dec: Decimal
        enum: EnumM
        optional_enum: Optional[EnumM]
        ca: CatchAllVar



# Generated at 2022-06-23 16:49:02.397189
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        def __init__(self, a: str):
            self.a = a

    class B:
        def __init__(self, b: int):
            self.b = b

    class C(A):
        def __init__(self, a: str, c: str):
            super(C, self).__init__(a)
            self.c = c

    Descriptor = typing.Dict[typing.Any, fields.Field]

    class ABCSchema(Schema):
        a = fields.String(attribute='a')
        b = fields.Integer(attribute='b')

        @post_load
        def make_object(self, data, **kwargs):
            return A(**data)

    class CSchema(Schema):
        a = fields.String(attribute='a')

# Generated at 2022-06-23 16:49:13.709870
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # tests when JSON is a string
    data = '{"a": 1, "b": "test"}'
    assert SchemaF.loads(data, many=False) == {"a": 1, "b": "test"}
    # tests when JSON is bytes
    data = b'{"a": 1, "b": "test"}'
    assert SchemaF.loads(data, many=False) == {"a": 1, "b": "test"}
    # tests when JSON is bytearrays
    data = bytearray('{"a": 1, "b": "test"}', 'utf-8')
    assert SchemaF.loads(data, many=False) == {"a": 1, "b": "test"}

# Generated at 2022-06-23 16:49:20.465918
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), "a", "b")
    assert not _TimestampField(required=False)._serialize(None, "a", "b")
    try:
        assert _TimestampField()._serialize(None, "a", "b")
    except ValidationError:
        assert True
    try:
        assert _TimestampField(required=False)._deserialize(None, "a", "b")
    except ValidationError:
        assert True
    assert _TimestampField()._deserialize(datetime.now(), "a", "b")
    assert not _TimestampField(required=False)._deserialize(None, "a", "b")


# Generated at 2022-06-23 16:49:25.927146
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses_json.api import dump_schema

    @dump_schema
    class TestSchema(SchemaF[int]):
        val = fields.Int()

    # fmt: off
    assert TestSchema().dumps({'val': 1}) == '{"val": 1}'
    # fmt: on

    # fmt: off
    assert TestSchema().loads('{"val": 1}') == {'val': 1}
    # fmt: on



# Generated at 2022-06-23 16:49:37.671670
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    class Test(Enum):
        a = 'a'

    @dataclasses.dataclass
    class Nested:
        a: int
        b: typing.Optional[int]

    @dataclasses.dataclass
    class TestSchema:
        a: int
        b: typing.Optional[int]
        c: Nested
        d: typing.List[Test]

    schema = Schema.from_dataclass(TestSchema)

    data = [{'a': 1, 'b': 2, 'c': {'a': 3, 'b': 4}, 'd': ['a']},
            {'a': 5, 'b': None, 'c': {'a': 6, 'b': None}, 'd': ['a']}]

# Generated at 2022-06-23 16:49:47.817564
# Unit test for function build_type
def test_build_type():
    import marshmallow.validate as validate

    class CustomMappingType(fields.Mapping):
        default_error_messages = {
            'invalid': "Not a valid mapping type."
        }

        def _validated(self, value):
            if not isinstance(value, dict):
                self.fail("invalid")
            return super(CustomMappingType, self)._validated(value)

#     @dataclasses.dataclass

# Generated at 2022-06-23 16:49:59.650566
# Unit test for function build_schema
def test_build_schema():
    # Return a function that handles the actual tests
    # This is necessary because `build_schema` is a closure.
    def _test_build_schema(cls, DataClassSchema):
        # Test that the schema exists and loads and dumps without error
        _schema = DataClassSchema()
        cls_ = cls(name="Hello world")
        _ = _schema.dumps(cls_)
        _ = _schema.dump(cls_)
        _ = _schema.load({'name': "Hello world"})
        _ = _schema.loads('{"name": "Hello world"}')

    # Create a dataclass and a schema for it and test them
    @dataclass_json
    @dataclass(frozen=True)
    class Cls:
        name: str

   

# Generated at 2022-06-23 16:50:09.539820
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass
    MySchema().dumps(1, many=None)
    MySchema().dumps([1], many=True)
    MySchema().dumps([1], many=False)


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """
            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:50:12.876386
# Unit test for constructor of class _UnionField
def test__UnionField():
    import typing

    x = _UnionField(
        desc={typing.Union[int, str]: None},
        cls=None,
        field=None,
        allow_none=False)
    assert type(x) is _UnionField


# Generated at 2022-06-23 16:50:23.412221
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[typing.List[int]].loads([1, 2, 3]) == [1, 2, 3]
    assert SchemaF[int].loads(1) == 1


if sys.version_info >= (3, 5):
    class SchemaF(SchemaF[typing.Any], typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:50:24.373009
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    _ = SchemaF.dumps



# Generated at 2022-06-23 16:50:34.471038
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # MYPY does not understand type var handling, since it doesn't
    # have full support for generics.
    s = SchemaF(  # type: ignore
    )

    def takes_list(x: typing.List[int]):  # type: ignore
        # mypy thinks the return value is a dict here
        return s.load(x, many=True)  # type: ignore

    def takes_dict(x: typing.Dict[str, int]):  # type: ignore
        # mypy thinks the return value is a dict here
        return s.load(x, many=True)  # type: ignore

    def takes_single(x):  # type: ignore
        return s.load(x, many=False)  # type: ignore

    x = []
    assert takes_list(x) == x
   

# Generated at 2022-06-23 16:50:45.278959
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        def __init__(self, x):
            self.x = x

    class B:
        def __init__(self, y):
            self.y = y

    class C(A, B):
        def __init__(self, x, y):
            A.__init__(self, x)
            B.__init__(self, y)

    class DC(C):
        x: int
        y: int

    dc_schema_cls = DataclassSchema.from_dataclass(DC)
    dc_schema = dc_schema_cls()
    assert dc_schema.get_field('x').__class__ is _UnionField



# Generated at 2022-06-23 16:50:52.790126
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field

    @dataclass
    class A(SchemaMixin):
        a: int = field(mm_field=fields.Int(missing=1))

    A.schema()
    assert A.schema().fields["a"].missing == 1

    db_model = build_schema(A, SchemaMixin, False, False)
    #assert issubclass(db_model, SchemaType)



# Generated at 2022-06-23 16:51:03.998670
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.mm import make_schema
    class T(Enum):
        A:str= "A"
        B:str="B"
        C:str="C"
    class B(Enum):
        A:str= "A"
        B:str="B"
        C:str="C"
    @dataclass_json
    @dataclass
    class A:
        a:int
    @dataclass_json
    @dataclass
    class C:
        a:int
    @dataclass_json
    @dataclass
    class D(A):
        b:int
    assert type(build_type(int, {}, C, A.__dataclass_fields__['a'], C)) == fields.Int

# Generated at 2022-06-23 16:51:05.027019
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    try:
        s = SchemaF()
    except Exception:
        pass



# Generated at 2022-06-23 16:51:16.187915
# Unit test for function schema
def test_schema():
    from marshmallow import Schema, fields as F
    import dataclasses
    import typing

    @dataclasses.dataclass
    class F1:
        x: int

    @dataclasses.dataclass
    class F2(F1):
        y: str

    @dataclasses.dataclass
    class F3:
        z: typing.List[int]

    @dataclasses.dataclass
    class F4:
        a: typing.Dict[str, F1]

    @dataclasses.dataclass
    class F5:
        b: typing.Tuple[int, str]

    @dataclasses.dataclass
    class F6:
        c: typing.Callable

    @dataclasses.dataclass
    class F7:
        d: typing.Mapping

# Generated at 2022-06-23 16:51:23.840352
# Unit test for function build_type
def test_build_type():
    assert issubclass(build_type(int, options={}, mixin=CJMixin, field=CJMixin, cls=0), fields.Int)
    assert issubclass(build_type(str, options={}, mixin=CJMixin, field=CJMixin, cls=0), fields.Str)
    assert issubclass(build_type(float, options={}, mixin=CJMixin, field=CJMixin, cls=0), fields.Float)
    assert issubclass(build_type(bool, options={}, mixin=CJMixin, field=CJMixin, cls=0), fields.Bool)

# Generated at 2022-06-23 16:51:29.530516
# Unit test for function schema
def test_schema():
    import json
    import datetime
    import dataclasses
    import typing
    import marshmallow as mm
    @dataclasses.dataclass
    class PaymentInfo:
        name: str
        card: typing.Optional[str] = None
    @dataclasses.dataclass
    class Payment:
        id: int
        info: PaymentInfo
        optional_bool: typing.Optional[bool] = False
        optional_none: typing.Optional[None] = None
        optional_int: typing.Optional[int] = None
        optional_float: typing.Optional[float] = None
        optional_str: typing.Optional[str] = None
        optional_date: typing.Optional[datetime.date] = None
        optional_datetime: typing.Optional[datetime.datetime] = None

# Generated at 2022-06-23 16:51:40.295699
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Any, List
    from marshmallow.schema import Schema
    from marshmallow.fields import Field
    from marshmallow.schema import Schema  # type: ignore

    class ResultSchema(SchemaF[Result]):
        # class ResultSchema(Schema[Result]):
        """
        Schema for Result dataclass
        """

        class Meta:
            unknown = INCLUDE

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        changed: bool = fields.Bool(required=True)

    # def __init__(self, host: str, changed: bool = False) -> None:

    data1 = Result('str')
    data2 = Result2('str', 'str2')

# Generated at 2022-06-23 16:51:49.862156
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class PersonF(typing.Generic[A]):
        name: str

    class PersonSchemaF(SchemaF[PersonF]):
        name = fields.Str()
        age = fields.Int()

    p1 = PersonF[int]("Joe", age=42)
    p2 = PersonF[int]("Joe", age=42)
    res = PersonSchemaF().dump((p1, p2), many=True)
    assert res == [{"name": "Joe", "age": 42}, {"name": "Joe", "age": 42}]



# Generated at 2022-06-23 16:51:51.546532
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert True == True


# Generated at 2022-06-23 16:51:57.054963
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Dummy(SchemaF[TEncoded]):
        pass

    try:
        Dummy()
    except NotImplementedError:
        pass
    else:
        raise Exception("Should not be reached")


# Generated at 2022-06-23 16:52:06.288198
# Unit test for function build_type
def test_build_type():
    class TestClass:
        pass

    from dataclasses import dataclass
    from dataclasses_json.mm_schema import DataClassSchema

    @dataclass
    class TestClassWithSchema(DataClassSchema):
        name: str

    @dataclass
    class TestClassWithMixin(object, DataClassSchema):
        name: str

    obj = TestClassWithSchema()

    obj_mixin = TestClassWithMixin()

    obj2 = TestClass()

    field = dc_fields(TestClassWithSchema)[0]

    assert build_type(field.type, dict(), TestClassWithSchema, field,
                      TestClassWithSchema) == fields.Str(**field.metadata)

# Generated at 2022-06-23 16:52:17.622542
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import unittest
    import pytz
    from datetime import datetime

    class TestCase(unittest.TestCase):
        def test_serialize(self):
            field = _TimestampField(required=False)
            obj1 = field._serialize(datetime.now(pytz.timezone("UTC")), "attr", None)
            self.assertIsInstance(obj1, float)
            obj2 = field._serialize(None, "attr", None)
            self.assertIsNone(obj2)
            with self.assertRaises(ValidationError):
                field._serialize(datetime.now(pytz.timezone("UTC")), "attr", None, required=True)

        def test_deserialize(self):
            field = _TimestampField(required=False)
            utcnow = datetime

# Generated at 2022-06-23 16:52:25.146068
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union

    class C:
        @classmethod
        def __getitem__(cls, item):
            return item

    f = fields.Field()
    json_field = _UnionField({C[int]: f}, C, f, {})
    assert json_field.desc == {int: f}



# Generated at 2022-06-23 16:52:33.081766
# Unit test for function build_schema
def test_build_schema():
    class Point(typing.NamedTuple):
        x: float
        y: float

    @dataclass
    @dataclass_json
    class Line:
        p1: Point
        p2: Point


# Generated at 2022-06-23 16:52:37.469297
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json()
    @dataclass()
    class Dc1:
        a: str
        b: int

    dc1 = Dc1('d', 0)
    assert SchemaF[Dc1].dump(dc1) == {'a': 'd', 'b': 0}


# Generated at 2022-06-23 16:52:49.630023
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class Foo(object):
        a: typing.List[str]
        b: typing.List[str]
        c: typing.List[str]
    class FooSchema(SchemaF[Foo]):
        a = fields.List(fields.Str())
        b = fields.List(fields.Str())
        c = fields.List(fields.Str())
    assert FooSchema().dump([Foo(['a', 'b'], ['a', 'b'], ['a', 'b'])]) == [{'a': ['a', 'b'], 'b': ['a', 'b'], 'c': ['a', 'b']}]

# Generated at 2022-06-23 16:53:01.653621
# Unit test for constructor of class _UnionField
def test__UnionField():
    import datetime as dt
    from dataclasses import dataclass, asdict
    from typing import Union, Optional
    import marshmallow
    class P:
        def __init__(self, x, y=1):
            self.x = x
            self.y = y
    func = lambda a,b=1: None
    @dataclass
    class M:
        field: Union[dt.datetime, dt.timedelta, str, bytes, P, func]

    @dataclass
    class K:
        field: Optional[Union[dt.datetime, dt.timedelta, str, bytes, P, func]] = None

    params = {
        'field': dt.timedelta(seconds=3),
    }
    assert asdict(M(**params)) == params
    assert asdict

# Generated at 2022-06-23 16:53:13.395602
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Any, List, Dict, Type
    from unittest.mock import Mock

    class M1(Mock, typing.Generic[A]):
        def __init__(self, *args, **kwargs):
            self.return_value = kwargs.pop('return_value', None)
            super().__init__(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            return self.return_value

    class M1_many(M1):
        def __call__(self, *args, **kwargs):
            return self.return_value

    m1_many = M1_many(return_value=[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])

# Generated at 2022-06-23 16:53:18.024967
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Test(typing.Generic[A]):
        def m(self, x: A, y: SchemaF[A]) -> A:
            pass

    def test(t: Test[int]) -> int:
        return t.m(2, SchemaF())



# Generated at 2022-06-23 16:53:26.973866
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass
    from marshmallow import Schema

    class Foo(Enum):
        BAR = 'bar'
    @dataclass
    class Bar: pass
    @dataclass
    class Baz: pass
    @dataclass
    class MyClass:
        f: Union[Bar, Baz, Foo, str]

    class BarSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'
        f = fields.Integer()

    class BazSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'
        f = fields.Float()

    class FooSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'
        f = EnumField()


# Generated at 2022-06-23 16:53:32.905710
# Unit test for function schema
def test_schema():
    from .annotations import JsonMixin
    @dataclass_json
    @dataclass
    class Test:
        foo: str
        bar: int
        baz: list

    assert schema(Test, JsonMixin, False) == {'foo': fields.Str(missing=...), 'bar': fields.Int(missing=...), 'baz': fields.List(field=fields.Field(**{}))}



# Generated at 2022-06-23 16:53:37.600216
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Given
    value = "2020-03-04T06:10:45"
    field = _IsoField()

    # When
    result = field.deserialize(value)

    # Then
    assert result == datetime.fromisoformat(value)
    assert result == field.serialize(result)



# Generated at 2022-06-23 16:53:47.476229
# Unit test for constructor of class _UnionField
def test__UnionField():
    pad = 1
    ts = 2
    vid = 3

    @dataclass(frozen=True)
    class Pad:
        x: int = field(default=pad, metadata={'mm_field': fields.Int()})
        y: int = field(default=pad, metadata={'mm_field': fields.Int()})

    @dataclass(frozen=True)
    class TimeStamp:
        dt: datetime = field(
            default_factory=datetime.utcnow,
            metadata={'mm_field': _TimestampField()})


# Generated at 2022-06-23 16:53:54.934928
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import fields
    from dataclasses import dataclass, fields as dc_fields

    @dataclass
    class Test:
        d: str = 'default'
        e: str = fields.Str()
        f: str = fields.Str(default='default')
    s = build_schema(Test, mm.Mixin, True, True)
    assert Test.schema() == s
    assert s.__name__ == 'TestSchema'
    # load and dump should work, skipping



# Generated at 2022-06-23 16:54:03.408741
# Unit test for function build_type
def test_build_type():
    from typing import TypedDict, Optional, Union
    class Point1(TypedDict):
        x: int
        y: int
    class Point2(TypedDict):
        x: int
        y: int

# Generated at 2022-06-23 16:54:07.381150
# Unit test for constructor of class _IsoField
def test__IsoField():
    x = _IsoField(allow_null=True)
    # test if field is a subclass of fields.Field
    assert issubclass(x.__class__, fields.Field)



# Generated at 2022-06-23 16:54:17.776417
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert len(fields.Field._VALID_RUNTIME_TYPES) == 1
    assert type(fields.Field._VALID_RUNTIME_TYPES[0]) == type(type(None))
    assert _IsoField._VALID_RUNTIME_TYPES[0] == fields.Field._VALID_RUNTIME_TYPES[0]
    assert len(_TimestampField._VALID_RUNTIME_TYPES) == 2
    assert type(_TimestampField._VALID_RUNTIME_TYPES[0]) == type(type(None))
    assert type(_TimestampField._VALID_RUNTIME_TYPES[1]) == type(type(None))
    assert _TimestampField._VALID_RUNTIME_TYPES[0] == fields.Field._VALID_R

# Generated at 2022-06-23 16:54:23.316668
# Unit test for function schema
def test_schema():
    class _UserMixin(object):
        pass

    @dataclass_json(mm_field=fields.Int())
    @dataclass
    class User(_UserMixin):
        username: str
        age: int

    s = schema(User, _UserMixin, infer_missing=False)
    assert type(s['age']) is fields.Int



# Generated at 2022-06-23 16:54:33.048299
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TestSchema(Schema):
        int_int = _UnionField(int, "int_int")
        int_str = _UnionField(str, "int_str")

    schema = TestSchema()
    d = {'int_int': 1, 'int_str': 1}
    _UnionField.__init__(_UnionField, 1, "int_int", required=False)
    _UnionField.__init__(_UnionField, 1, "int_int", required=True)
    _UnionField.__init__(_UnionField, 1, "int_int", allow_none=False)
    _UnionField.__init__(_UnionField, 1, "int_int", allow_none=True)
    _UnionField.__init__(_UnionField, 1, "int_int", error_messages=None)
   

# Generated at 2022-06-23 16:54:42.210514
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(Schema[Person]):
        name = fields.Str()
        age = fields.Int()

        @post_load
        def post_load(self, data, **kwargs):
            return Person(**data)

    s = PersonSchema()
    p = s.loads('{"name": "Fred", "age": 18}')
    assert isinstance(p, Person)
    l: List[Person] = s.loads('[{"name": "Fred", "age": 18}]')

# Generated at 2022-06-23 16:54:53.809352
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        def __init__(self):
            self.x = None
            self.y = None
            self.z = None
    class FooSchema(SchemaF[Foo]):
        x = fields.Str()
        y = fields.Str()
        z = fields.Str()
        @post_load
        def make_object(self, data, **kwargs):
            foo = Foo()
            foo.x = data['x']
            foo.y = data['y']
            foo.z = data['z']
            return foo

    f1 = Foo()
    f1.x = 'x'
    f1.y = 'y'
    f1.z = 'z'
    foo_schema = FooSchema(unknown='EXCLUDE')
    foo_as_dict = foo_

# Generated at 2022-06-23 16:55:00.133694
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF[str].load({}).strip() == ''
    assert SchemaF[str].loads(b'').strip() == ''
    assert SchemaF[str].load([{}]).strip() == ''
    assert SchemaF[str].loads(b'', many=True).strip() == ''

