

# Generated at 2022-06-23 16:45:02.836998
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize("2020-08-05T00:00:00", "attr", {}) == datetime(2020, 8, 5)
    assert field._serialize(datetime(2020, 8, 5), "attr", {}) == "2020-08-05T00:00:00"


# Generated at 2022-06-23 16:45:06.804139
# Unit test for constructor of class SchemaF
def test_SchemaF():
    schema = SchemaF[int]()  # noqa
    data: typing.List[int] = []  # type: ignore
    data_any: typing.List[typing.Any] = []  # type: ignore
    schema.dump(data)
    schema.dumps(data)
    schema.load(data_any)
    schema.loads(b"")



# Generated at 2022-06-23 16:45:15.185411
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields, Schema, SchemaOpts, class_registry

    class S(Schema):
        field = fields.Field()

    s = S()

    v = s.dump({"field": 10})
    assert v == {"field": 10}

    v = s.dump([{"field": 10}], many=True)
    assert v == [{"field": 10}]

    class O(object):
        def __init__(self, field):
            self.field = field

        def __eq__(self, other):
            if not isinstance(other, O):
                return False
            return ((self.field == other.field) and
                    (self.__class__ == other.__class__))

    class S2(SchemaF[O]):
        class Meta(SchemaOpts):
            unknown

# Generated at 2022-06-23 16:45:25.145535
# Unit test for constructor of class _UnionField
def test__UnionField():
  class Inner:
    class Doc1:
      @dataclass
      class X:
        i: int
      # dataclass(_name='Doc1')
      i: int = 5
      
    @dataclass
    class Doc2:
      i: int = 6
      
  @dataclass
  class Doc3:
    i: int = 7
  
  # print(Inner.__dict__)
  # print(Inner.__dict__['Doc1'].__dict__)
  # print(Inner.__dict__['Doc1'].__dict__)['__annotations__'])
  # def test_union_field():
  #   type_ = typing.Union[Inner.Doc1, Inner.Doc2, Doc3] # typing.Union[Inner.Doc1.X, Inner.Doc

# Generated at 2022-06-23 16:45:31.923083
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm_schema import schema
    from dataclasses_json.mm_schema import build_type as bt
    from marshmallow import fields
    import typing as t

    class TestType:
        class InnerTest:
            pass

        class InnerTest2:
            pass
    tup = t.Tuple[t.Tuple[int, float], float, float, float]
    un = t.Union[TestType.InnerTest, TestType.InnerTest2]

    assert isinstance(bt(int, {}, object, None, None), fields.Int)
    assert isinstance(bt(tup, {}, object, None, None), fields.Nested)
    assert isinstance(bt(un, {}, object, None, None), _UnionField)



# Generated at 2022-06-23 16:45:42.002794
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    # Expected result for Union
    union = typing.Union[A, B, C]
    assert is_union_type(union)
    # Unsupported types
    assert not is_union_type(typing.List[A])
    assert not is_union_type(typing.List[A])
    assert not is_union_type(A)
    assert not is_union_type(B)
    # Tests for UnionField
    class A(Schema): pass
    class B(Schema): pass
    class C(Schema): pass
    class D(Schema): pass

# Generated at 2022-06-23 16:45:50.166803
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class S(SchemaF[int]):
        pass

    s = S()
    assert s.loads([1, 2, 3]) == [1, 2, 3]
    assert s.loads('[1, 2, 3]') == [1, 2, 3]
    assert s.loads(b'[1, 2, 3]') == [1, 2, 3]



# Generated at 2022-06-23 16:45:53.310453
# Unit test for function build_schema
def test_build_schema():
    import dataclasses_json.api as api
    @dataclasses.dataclass
    class Model:
        field: int

    test = build_schema(Model, None, None, None)




# Generated at 2022-06-23 16:46:03.867359
# Unit test for function schema
def test_schema():
    import dataclasses_json

    @dataclasses_json.dataclass_json(
        mm_field=dataclasses_json.MmField(fields.Int, required=True))
    class A:
        a: int
    b = schema(A, dataclasses_json.MmMixin, infer_missing=True)
    assert isinstance(b['a'], fields.Int)
    assert b['a'].required is True


    @dataclasses_json.dataclass_json
    class B:
        b: typing.Union[int, str, None]
        c: typing.Optional[int]
    b = schema(B, dataclasses_json.MmMixin, infer_missing=True)
    assert isinstance(b['b'], _UnionField)

# Generated at 2022-06-23 16:46:16.143286
# Unit test for function build_type
def test_build_type():
    class A:
        pass
    class Spawned:
        pass
    class Blah(A):
        pass
    class Blah2(A):
        pass
    class Spawned2(Spawned):
        pass
    class Spawned3(Spawned):
        pass
    class Final(Spawned):
        pass
    class Final2(Spawned):
        pass
    class Final3(Spawned):
        pass

    class Mixin:
        pass
    class Mixin2:
        pass
    class Mixin3:
        pass

    @dataclass_json
    class BlahSchema(Mixin, Schema):
        pass
    @dataclass_json(mm_field=EnumField)
    class Blah2Schema(Mixin2, Schema):
        pass


# Generated at 2022-06-23 16:46:21.103037
# Unit test for constructor of class _IsoField
def test__IsoField():
    i = _IsoField()
    assert i._deserialize('2020-01-01T00:00:00.000000') == datetime(2020, 1, 1)
    assert i._serialize(datetime(2020, 1, 1)) == '2020-01-01T00:00:00'
    with pytest.raises(ValidationError):
        i._deserialize(None)


# Generated at 2022-06-23 16:46:29.773275
# Unit test for function build_type
def test_build_type():
    options = {
        'allow_none': False,
        'required': False,
        'validate': None,
        'error_messages': {}
    }

    union_type = typing.Union[int, float, str, type(None)]
    enum_type = typing.Union[Enum, type(None)]
    origin = _get_type_origin(typing.Union)

    assert build_type(int, options, None, None, None) == fields.Int()
    assert build_type(float, options, None, None, None) == fields.Float()
    assert build_type(str, options, None, None, None) == fields.Str()
    assert build_type(bool, options, None, None, None) == fields.Bool()
    assert build_type(type, options, None, None, None)

# Generated at 2022-06-23 16:46:40.268917
# Unit test for function build_type
def test_build_type():
    if sys.version_info >= (3, 7):
        import datetime
        from typing import Optional, List, Union

        from uuid import UUID
        from dataclasses import dataclass

        @dataclass_json
        @dataclass
        class A:
            a: str
            b: int
            c: float
            d: Optional[A]
            e: Optional[List[A]]
            f: List[A]


# Generated at 2022-06-23 16:46:44.920680
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Test:
        a: int
        b: List[int]

    assert schema(Test, {}, infer_missing=False) == {
        'a': fields.Integer(default=None),
        'b': fields.List(fields.Integer(), default=None),
    }



# Generated at 2022-06-23 16:46:51.001991
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # GIVEN
    # A _TimestampField object with a non-required attribute (optional = False).
    field = _TimestampField(required=False)
    # WHEN
    # We attempt to serialize and deserialize a value that is None.
    result1 = field._serialize(None, "attr", "value")
    result2 = field._deserialize(None, "attr", "value")
    # THEN
    # The _serialize and _deserialize functions should return None.
    assert result1 is None
    assert result2 is None


# Generated at 2022-06-23 16:47:02.475796
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF.loads('[{"name": "A"}, {"name": "B"}]') == [{"name": "A"}, {"name": "B"}]
    assert SchemaF.loads('[{"name": "A"}, {"name": "B"}]', many=False) == [{"name": "A"}, {"name": "B"}]
    assert SchemaF.loads('[{"name": "A"}, {"name": "B"}]', many=False, partial=True) == [{"name": "A"}, {"name": "B"}]
    assert SchemaF.loads('[{"name": "A"}, {"name": "B"}]', many=False, partial=True, unknown='EXCLUDE') == [{"name": "A"}, {"name": "B"}]


# Generated at 2022-06-23 16:47:12.781874
# Unit test for function schema
def test_schema():
    from marshmallow import Schema
    from typing import Optional
    from dataclasses_json import dataclass_json
    from dataclasses import dataclass, field

    import pytest
    import marshmallow.errors  # type: ignore
    import marshmallow.fields  # type: ignore

    @dataclass_json
    @dataclass
    class Point:
        x: float
        y: float = 0.0

    @dataclass_json
    @dataclass
    class Address:
        street: str
        postal_code: Optional[int] = None

    @dataclass_json
    @dataclass
    class User:
        name: str = field(metadata={'dataclasses_json': {'mm_field': marshmallow.fields.Str(required=True)}})


# Generated at 2022-06-23 16:47:22.965085
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    """
    This function tests the new typing method loads of class SchemaF.
    """
    class T(typing.NamedTuple):
        a: str

    class T2(typing.NamedTuple):
        a: str
        b: str

    class S1(SchemaF[T]):
        a = fields.Str()

    class S2(SchemaF[T2]):
        a = fields.Str()
        b = fields.Str()


# Generated at 2022-06-23 16:47:27.681137
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(
        datetime(1990, 1, 1, 0, 0, 0), None, None, {}) == 631152000.0
    assert field._deserialize(631152000.0, None, None, {}) == datetime(1990, 1, 1, 0, 0, 0)


# Generated at 2022-06-23 16:47:38.654560
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing_extensions import Literal
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    @dataclass
    class Address:
        city: str
        street: str

    @dataclass
    class Person:
        name: str
        age: int
        address: Address

    class A(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()
        address = fields.Nested('B')

    class B(SchemaF[Address]):
        city = fields.Str()
        street = fields.Str()

    b = B()
    a = A()
    persondata = {'name': 'John', 'age': 42, 'address': {'city': 'Oslo', 'street': 'Some street'}}

# Generated at 2022-06-23 16:47:43.183730
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass()
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    assert schema.dumps(Person("John", 36)) == '{"age": 36, "name": "John"}'

# Generated at 2022-06-23 16:47:46.511923
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    t = datetime.now()
    assert field._serialize(t, None, None) == t.isoformat()
    assert field._deserialize(t.isoformat(), None, None) == t


# Generated at 2022-06-23 16:47:52.994003
# Unit test for constructor of class _UnionField
def test__UnionField(): # type: ignore
    """Unit test for constructor of class _UnionField."""
    cls = typing.Union[int, typing.Optional[int]] # type: ignore
    desc = {int: None, typing.Optional[int]: None} # type: ignore
    field = _UnionField(desc, cls, field=None)
    assert field.desc == desc and field.cls == cls


# Generated at 2022-06-23 16:48:01.447372
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF[int]
    assert s.loads('[1]') == [1]
    assert s.loads('1') == 1


# Generated at 2022-06-23 16:48:07.589729
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = {
        'name': 'John',
        'age': 42
    }
    class Person(typing.NamedTuple):
        name: str
        age: int
    class PersonSchema(SchemaF[Person]):
        name = fields.String()
        age = fields.Integer()

    ps = PersonSchema()
    # If the test yields no error then it is a success
    ps.dumps(Person(**data))



# Generated at 2022-06-23 16:48:09.344405
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow()) is not None


# Generated at 2022-06-23 16:48:20.062569
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union, List
    from marshmallow import Schema

    class A:
        def __init__(self, a):
            self.a = a

    class B:
        def __init__(self, b):
            self.b = b

    @dataclass
    class C:
        x: Union[int, str]

    class CSchema(Schema):
        x = _UnionField({int: fields.Number(), str: fields.String()}, C,
                        C.x)

    class D:
        @dataclass
        class E:
            y: Union[int, str]

    @dataclass
    class F:
        z: Union[D.E, List[int], A]

    class FSchema(Schema):
        z = _

# Generated at 2022-06-23 16:48:29.974666
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field

    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        x: str
        y: int = field(default=1, metadata=dict(dataclasses_json=dict(mm_field=fields.Integer(), letter_case=lambda x: x)))


# Generated at 2022-06-23 16:48:31.375042
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField(default='20200101', required=True)



# Generated at 2022-06-23 16:48:35.585501
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    """
    Unit test for constructor of class _TimestampField
    """
    field = _TimestampField()
    assert field.required == False
    assert field.attribute == False


# Generated at 2022-06-23 16:48:46.050178
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from typing import List


    @dataclass
    class SimplePoint:
        id: int
        name: str


    @dataclass
    class SimplePoint2:
        id: int
        name: str
        version: int = 1


    @dataclass
    class SimplePoint3:
        id: int
        name: str
        version: int = 1
        att: List[SimplePoint2] = None


    class SimplePointSchema(SchemaF[SimplePoint]):
        id = fields.Integer(required=True)
        name = fields.String(required=False)


    class SimplePoint2Schema(SchemaF[SimplePoint2]):
        id = fields.Integer(required=True)
        name = fields.String(required=False)
        version

# Generated at 2022-06-23 16:48:52.827938
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class Uri(SchemaF[str]):
        pass

    class Person(dataclasses.dataclass):
        first_name: str
        last_name: str
        uri: Uri

    class PersonSchema(SchemaF[Person]):
        first_name = fields.Str()
        last_name = fields.Str()
        uri = fields.Nested(Uri())

    p = Person(first_name='John', last_name='Doe', uri='http://www.google.com')
    assert PersonSchema().dump(p) == {
        'first_name': 'John',
        'last_name': 'Doe',
        'uri': 'http://www.google.com'
    }



# Generated at 2022-06-23 16:48:56.365138
# Unit test for function build_type
def test_build_type():
    assert _is_new_type(TEncoded)
    assert _is_new_type(TOneOrMulti)
    assert _is_new_type(TOneOrMultiEncoded)



# Generated at 2022-06-23 16:48:57.424178
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()



# Generated at 2022-06-23 16:49:01.645151
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    A = typing.TypeVar('A')
    class SchemaF(Schema, typing.Generic[A]):
        pass
    SchemaF.loads(SchemaF, typing.Dict[str, typing.Any])
    SchemaF.loads(SchemaF, str)

# Generated at 2022-06-23 16:49:13.113571
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class User:
        name: str
        email: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()
        age = fields.Int()

    user = User('John', 'john@example.com', 18)
    user_serialized = UserSchema().dumps(user)
    assert user_serialized == b'{"name": "John", "email": "john@example.com", "age": 18}'

    user_deserialized = UserSchema().loads(user_serialized)
    assert user_deserialized == user

    multi_users_serialized = UserSchema().dumps([user, user], many=True)


# Generated at 2022-06-23 16:49:18.829550
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(1536741038.199935) == datetime(year=2018, month=9, day=11, hour=3, minute=57, second=18, microsecond=199935)
    assert _TimestampField(required=False)._deserialize(None) == None


# Generated at 2022-06-23 16:49:19.421000
# Unit test for constructor of class _UnionField
def test__UnionField():
    pass


# Generated at 2022-06-23 16:49:22.295914
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import Schema, fields

    class InnerSchema(Schema):
        test = fields.Int()

    class TestSchema(Schema):
        inner = fields.Nested(InnerSchema)
        test = fields.Int()

    gen_schema = build_schema(TestSchema, None, False, False)
    assert isinstance(gen_schema.inner, fields.Nested)
    assert hasattr(gen_schema, "test")
    assert len(gen_schema.declared_fields) == 2


# Generated at 2022-06-23 16:49:30.362878
# Unit test for function schema
def test_schema():
    import typing
    import marshmallow
    import marshmallow.fields as mf
    import dataclasses_json
    import dataclasses

    class Example:
        a: typing.Dict[int, bool]

    assert schema(Example, dataclasses_json.Mixin, False) == {
        "a": mf.Dict,
    }
    assert schema(Example, dataclasses_json.Mixin, True) == {
        "a": mf.Dict,
    }
    assert issubclass(Example.schema().__class__, marshmallow.Schema)

    class Example:
        a: str

    assert schema(Example, dataclasses_json.Mixin, False) == {
        "a": mf.Str,
    }

# Generated at 2022-06-23 16:49:35.898387
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(2018, 12, 27, 15, 21, 38, 585411)) == 1545910498.585411
    assert _TimestampField()._deserialize(1545910498.585411) == datetime(2018, 12, 27, 15, 21, 38, 585411)


# Generated at 2022-06-23 16:49:43.198446
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[A]):
        pass

    a = TestSchema().dumps([1, 2, 3])
    assert a == '[1, 2, 3]'
    b = TestSchema().dumps({"a": 1})
    assert b == '{"a": 1}'
    c = TestSchema().dumps({"a": 1}, many=True)
    assert c == '{"a": 1}'



# Generated at 2022-06-23 16:49:43.766551
# Unit test for constructor of class _IsoField
def test__IsoField(): pass


# Generated at 2022-06-23 16:49:45.765117
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SchemaF_test(SchemaF):
        pass
    assert SchemaF_test.dumps == SchemaF.dumps


# Generated at 2022-06-23 16:49:49.257486
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Given
    field = _IsoField()

    # When
    serialized = field._serialize(datetime(2018, 12, 13, 21, 38), "foo", None)

    # Then
    assert serialized == "2018-12-13T21:38:00"

    # When
    deserialized = field._deserialize("2018-12-13T21:38:00", "foo", None)

    # Then
    assert deserialized == datetime(2018, 12, 13, 21, 38, 0)

# End of unit test for constructor of class _IsoField



# Generated at 2022-06-23 16:49:59.867034
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():

    from decimal import Decimal
    from json import dumps as json_dumps

    from dataclasses import dataclass

    @dataclass
    class Simple:
        price: Decimal

    @dataclass
    class Complex:
        simple: Simple

    class SimpleSchema(SchemaF[Simple]):

        class Meta:
            unknown = 'EXCLUDE'

        price = fields.Decimal()

    class ComplexSchema(SchemaF[Complex]):

        class Meta:
            unknown = 'EXCLUDE'

        simple = fields.Nested(SimpleSchema)

    complex_data = Complex(Simple(Decimal(12.34)))
    serialized = ComplexSchema().dump(complex_data)
    assert serialized == {'simple': {'price': Decimal('12.34')}}

    serialized

# Generated at 2022-06-23 16:50:07.707441
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class User:
        id: int
        name: str

    class UserSchema(Schema):
        id = fields.Int()
        name = fields.Str()

    schema: SchemaF[User] = UserSchema()
    result = schema.dump(User(1, 'foo'))
    assert result == {'id': 1, 'name': 'foo'}
    result = schema.dump([User(1, 'foo')])
    assert result == [{'id': 1, 'name': 'foo'}]

# Generated at 2022-06-23 16:50:10.756856
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class TestCls:
        foo: str = field(metadata=field_metadata(mm_field=fields.Int()))
        bar: int

    sc = build_schema(TestCls, object, False, False)
    assert sc.__name__.startswith('TestCls')
    assert 'foo' not in sc._declared_fields
    assert 'bar' in sc._declared_fields



# Generated at 2022-06-23 16:50:12.606337
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    try:
        SchemaF()
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:50:23.194081
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import fields
    from typing import Union

    class A:
        pass
    class B:
        def __init__(self, a: int):
            self.a = a

    class Schema(Schema):
        a = _UnionField(
            desc={A: fields.Field(),
                  B: fields.Field()},
            cls='cls',
            field='field',
            allow_none=True,
        )

    schema = Schema(strict=True)
    obj = A()
    assert schema.dump(obj) == {'a': None}
    obj = B(2)
    res = schema.dump(obj)
    assert '__type' not in res['a']
    obj = {'__type': 'B', 'a': 2}

# Generated at 2022-06-23 16:50:29.536593
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def test_SchemaF_loads_base(obj: TOneOrMulti, many: bool = None, partial: bool = None, unknown: str = None,
                  **kwargs) -> TOneOrMulti:
        pass
    assert test_SchemaF_loads_base(dict(a=1),many=True) == dict(a=1)


# Generated at 2022-06-23 16:50:34.843923
# Unit test for constructor of class _IsoField
def test__IsoField():
    a_field = _IsoField()

    assert a_field._serialize(datetime(2020, 1, 1), None, None, None) == "2020-01-01T00:00:00"
    assert a_field._deserialize("2020-01-01T00:00:00", None, None, None) == datetime(2020, 1, 1)



# Generated at 2022-06-23 16:50:39.113881
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchemaF(SchemaF[int]):
        pass

    schema = MySchemaF()
    schema.dump([1, 2, 3])  # type: ignore



# Generated at 2022-06-23 16:50:49.580318
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF.loads(str, None, None, None, False), typing.List[int])
    assert isinstance(SchemaF.loads(str, None, None, None, True), typing.List[int])
    assert isinstance(SchemaF.loads(str, None, None, None, 'False'), typing.List[int])
    assert isinstance(SchemaF.loads(str, None, None, None, 'True'), typing.List[int])
    assert isinstance(SchemaF.loads(str, None, None, None), typing.List[int])
    assert isinstance(SchemaF.loads(str, None, None), typing.List[int])
    assert isinstance(SchemaF.loads(str, None), typing.List[int])

# Generated at 2022-06-23 16:50:51.589627
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class Foo:
        a: int

    s = SchemaF[Foo]



# Generated at 2022-06-23 16:50:54.819186
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[str].dumps(['hello world']) == SchemaF.dumps(['hello world'])



# Generated at 2022-06-23 16:51:04.966870
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List, Dict

    class Inner:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

    class OuterDataType:
        def __init__(self, a: int, b: str, c: List[Inner]):
            self.a = a
            self.b = b
            self.c = c

    class Outer(SchemaF[OuterDataType]):
        a = fields.Int()
        b = fields.Str()
        c = fields.Nested('self', many=True, default=None)

        @post_load
        def make_object(self, data: Dict, **kwargs) -> OuterDataType:
            return OuterDataType(**data)

    o = Outer()

    # Should return a list

# Generated at 2022-06-23 16:51:16.140803
# Unit test for constructor of class _UnionField
def test__UnionField():
    import dataclasses
    import typing

    class MyEnum(Enum):
        A = 1
        B = 2

    class MySchema(Schema):
        pass

    class MyEnumSchema(Schema):
        class Meta:
            enum = MyEnum

    class UnionSchema(Schema):
        value = _UnionField(
            {
                bool: MySchema,
                typing.Union[MyEnum, str]: MyEnumSchema
            },
            'UnionSchema',
            dc_fields(UnionSchema)[0])

    class UnionDC(dataclasses.dataclass):
        value: typing.Union[bool, typing.Union[MyEnum, str]]

    obj_false = {'value': False}
    obj_false_serialized = {
        'value': False
    }

# Generated at 2022-06-23 16:51:19.783264
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    a = A()
    assert a.__dict__ == {}
    field = _UnionField(desc={}, cls=A, field=a)
    assert field.desc == {}
    assert field.cls == A
    assert field.field == a



# Generated at 2022-06-23 16:51:28.926152
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # pylint: disable=W0612
    class Person(typing.NamedTuple):
        name: str

    @dataclasses.dataclass
    class Person2(typing.NamedTuple):
        name: str

    @dataclasses.dataclass
    class Person3(typing.NamedTuple):
        name: str

    class ValidSchemaForPerson(SchemaF[Person]):
        name = fields.Str()

    class ValidSchemaForPerson2(SchemaF[Person2]):
        name = fields.Str()

    class ValidSchemaForPerson3(SchemaF[Person3]):
        name = fields.Str()



# Generated at 2022-06-23 16:51:39.733939
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    data: typing.Union[JsonData, typing.Dict]
    typ: SchemaF[typing.Any]
    res: typing.Any
    res = typ.loads(data)



# Generated at 2022-06-23 16:51:51.746483
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class InnerClass():
        a = 1
        def b():
            pass
    class MyClassF(typing.Generic[A]):
        def __init__(self, a: A, b: int, c: InnerClass, d: typing.List[A]):
            self.d = d
        def get_a(self):
            pass
    class MyClass(MyClassF[int]):
        pass
    class MySchema(SchemaF[MyClass]):
        a = fields.Field()
        b = fields.Field()
        c = fields.Field()
        d = fields.Field()
    class MyInnerClassSchema(Schema):
        a = fields.Field()
        b = fields.Function(deserialize=lambda x: x)

# Generated at 2022-06-23 16:51:56.658565
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().deserialize('2020-07-24') == datetime(2020, 7, 24, 0, 0)
    assert _IsoField().deserialize(None) == None



# Generated at 2022-06-23 16:52:01.333097
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow.schema import Schema
    class SubSchema(Schema):
        a = fields.Int()
    class SubSchemaF(SchemaF[SubSchema]):
        pass

    SubSchemaF().load({'a': 1})  # pass
    SubSchemaF().load([{'a': 1}])  # pass


# Generated at 2022-06-23 16:52:12.273265
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(typing.NamedTuple):
        a: int
        b: str
        c: float

    class B(SchemaF[A]):
        a = fields.Int()
        b = fields.Str()
        c = fields.Float()

    assert B().loads('{"a": 1, "b": "test", "c": 1.1}') == A(1, "test", 1.1)
    assert B().loads(b'{"a": 1, "b": "test", "c": 1.1}') == A(1, "test", 1.1)
    assert B().loads(bytearray(b'{"a": 1, "b": "test", "c": 1.1}')) == A(1, "test", 1.1)

# Generated at 2022-06-23 16:52:18.960331
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import List

    from marshmallow import Schema
    import marshmallow.exceptions as marshmallow_exceptions
    import marshmallow_dataclass

    class A:
        def __init__(self, name):
            self.name = name

    class B:
        def __init__(self, a_value, b_value):
            self.a_value = a_value
            self.b_value = b_value

    class _A(Schema):
        name = fields.Str(required=False)

    class _B(Schema):
        a_value = fields.Number(required=True)
        b_value = fields.Number(required=True)

    class _C(_A, _B):
        pass


# Generated at 2022-06-23 16:52:22.911509
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    pass


# Generated at 2022-06-23 16:52:32.313080
# Unit test for function schema
def test_schema():
    import pytest
    import datetime
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        i: int
        j: str

    @dataclass
    class Bar:
        f: Foo
        b: bool
        l: List[datetime.datetime]

    def test_foo():
        s = schema(Foo, None, True)
        assert 'i' in s and type(s['i']) is fields.Int
        assert 'j' in s and type(s['j']) is fields.Str

    def test_bar():
        s = schema(Bar, None, True)
        assert 'f' in s and type(s['f']) is fields.Nested
        assert 'b' in s and type(s['b']) is fields.B

# Generated at 2022-06-23 16:52:41.590637
# Unit test for constructor of class SchemaF
def test_SchemaF():  # pragma: no cover
    # type: () -> None
    class S(SchemaF[int]):
        pass

    # check that there's no constructor
    try:
        S()
    except NotImplementedError:
        pass
    else:
        raise Exception('It should not be possible to create an instance of S')

    # check that an instance of S can be constructed by the metaclass
    assert issubclass(S, Schema)
    assert S.__name__ == 'S'

    data, ser, deser = [1, 2, 3], [{'a': 1}, {'a': 2}, {'a': 3}], [1, 2, 3]

    class S(SchemaF[int]):
        a = fields.Integer()


# Generated at 2022-06-23 16:52:51.219235
# Unit test for function build_type
def test_build_type():
    from marshmallow_dataclass import Field, mm_field
    from typing import Union, Optional
    from dataclasses import dataclass
    from marshmallow import fields
    @dataclass
    # Mixin is not a dataclass
    class Test:
        a: str = mm_field(mm_field, field=dataclasses.Field(default="default"))
        # b is not an instance of dataclass_json
        b: str = mm_field(mm_field, field=dataclasses.Field(default="default"))
        
    # Test None
    assert build_type(None, {}, dataclass_json.MmMixin, Field("a", None), Test) == fields.Field(allow_none=True)

    # Test dataclass

# Generated at 2022-06-23 16:53:02.175968
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        pass

    @dataclass_json
    @dataclass
    class DummyDataclass:
        foo: int = field(metadata={'dataclasses_json': {'letter_case': 'camelize', 'mm_field': fields.Int}})
        bar: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str}})
        baz: typing.Optional[str] = field(metadata={'dataclasses_json': {'mm_field': fields.Str}})
        foo_bar: typing.Union[str, None] = field(metadata={'dataclasses_json': {'mm_field': fields.Str}})

# Generated at 2022-06-23 16:53:13.760224
# Unit test for function build_type
def test_build_type():
    assert build_type(Schema, {}, Schema, _ExtendedEncoder, Schema) == fields.Field(default=None)
    assert build_type(type([]), {}, Schema, _ExtendedEncoder, Schema) == fields.List(allow_none=False)
    assert build_type(UUID, {}, Schema, _ExtendedEncoder, Schema) == fields.UUID(allow_none=False)
    assert build_type(Decimal, {}, Schema, _ExtendedEncoder, Schema) == fields.Decimal(allow_none=False)
    assert build_type(str, {}, Schema, _ExtendedEncoder, Schema) == fields.Str(allow_none=False)
    assert build_type(int, {}, Schema, _ExtendedEncoder, Schema) == fields

# Generated at 2022-06-23 16:53:17.080585
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert hasattr(_UnionField, 'desc')
    assert hasattr(_UnionField, 'cls')
    assert hasattr(_UnionField, 'field')


# Generated at 2022-06-23 16:53:19.259615
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert 1==1


# Generated at 2022-06-23 16:53:21.117970
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj = typing.Dict[str, str]
    schema = SchemaF()
    schema.dumps(obj)



# Generated at 2022-06-23 16:53:31.715615
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    class MySimpleSchema1(SchemaF[A]):
        pass  # pragma: no cover

    class MySimpleSchema2(SchemaF[b'A']):  # type: ignore
        pass  # pragma: no cover

    class MySimpleSchema3(SchemaF[bytes]):  # type: ignore
        pass  # pragma: no cover

    try:
        # Test that SchemaF cannot be directly instantiated
        schema1: SchemaF[str] = SchemaF()
    except NotImplementedError as e:
        assert str(e) == 'This class is helper only'
    else:
        raise AssertionError('SchemaF should have thrown an exception')

    schema2: SchemaF[str] = MySimpleSchema1()
    schema3: Schema

# Generated at 2022-06-23 16:53:41.786816
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields, ValidationError
    from dataclasses import dataclass
    from dataclasses_json.schema import SchemaF

    @dataclass
    class DCTest:
        test: str = 'test'

    @dataclass
    class DCTestData(SchemaF[DCTest]):
        test: str = fields.String(required=True)

        @post_load
        def make_object(self, data, **kwargs):
            return DCTest(**data)

    @dataclass
    class DCTestData2(SchemaF[DCTest]):
        test: str = fields.String(required=True)

        @post_load
        def make_object(self, data, **kwargs):
            return DCTest(**data)

   

# Generated at 2022-06-23 16:53:53.505395
# Unit test for function build_schema
def test_build_schema():
    print('test_build_schema')
    class Mixin:
        @property
        def schema(self):
            raise AttributeError

    from dataclasses import make_dataclass
    from uuid import uuid4
    from typing import Optional

    @dataclass_json
    @dataclass
    class TestSchema:
        uuid_1: UUID
        uuid_2:  UUID
        uuid_3: UUID = field(default=uuid4)
        json_str: str = field(metadata=dict(mm_field=fields.Raw))
        int_list: typing.List[int]
        cat: Optional[CatchAllVar] = field(default_factory=dict)

# Generated at 2022-06-23 16:54:02.143039
# Unit test for constructor of class _IsoField
def test__IsoField():
    a_field = _IsoField()
    dt1 = datetime(2019, 9, 26, 15, 49, 33, 152991)
    dt2 = datetime(2019, 12, 31, 15, 49, 30, 152991)
    assert a_field.serialize(dt1) == "2019-09-26T15:49:33.152991"
    assert a_field.serialize(dt2) == "2019-12-31T15:49:30.152991"
    assert a_field.deserialize("2019-09-26T15:49:33.152991") == dt1
    assert a_field.deserialize("2019-12-31T15:49:30.152991") == dt2



# Generated at 2022-06-23 16:54:08.826506
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    value = field.deserialize(1552688580.766)
    assert value.timestamp() == 1552688580.766
    assert field.deserialize(None) is None
    assert field.deserialize("") is None
    assert field.deserialize("abcd") is None



# Generated at 2022-06-23 16:54:10.533719
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsf = _TimestampField()
    assert tsf is not None


# Generated at 2022-06-23 16:54:16.489469
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import dataclasses
    import marshmallow
    import marshmallow_dataclass
    # for annotations
    import typing

    @dataclasses.dataclass
    class MyClass:
        name: str

    class MySchema(SchemaF[MyClass]):
        name = marshmallow.fields.Str()

    c = MySchema().loads('{"name": "hi"}')
    assert isinstance(c, MyClass)



# Generated at 2022-06-23 16:54:27.726137
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses.dataclass
    class A:
        x: int

    assert A.__name__ == 'A'
    assert A.__doc__ is None

    @dataclasses.dataclass
    class B:
        x: int
        y: int

    assert B.__name__ == 'B'
    assert B.__doc__ is None

    @dataclasses.dataclass
    class C:
        x: int
        y: A

    assert C.__name__ == 'C'
    assert C.__doc__ is None

    try:
        @dataclasses.dataclass
        class D(SchemaF[A]):
            x: int

        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-23 16:54:34.364137
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    value = _TimestampField('name', required=True)
    assert value._serialize(datetime.now(), 'attr', None) > 0
    assert value._deserialize(datetime.now().timestamp(), 'attr', None) == datetime.now()
    assert value._serialize(None, 'attr', None) is None
    assert value._deserialize(None, 'attr', None) is None



# Generated at 2022-06-23 16:54:38.201618
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # test _serialize
    value = datetime.now()
    value_serialize = _TimestampField()._serialize(value, None, None, {})
    assert value_serialize.timestamp() == value.timestamp()

    # test _deserialize
    value = datetime.now()
    value_deserialize = _TimestampField()._deserialize(value.timestamp(), None, None, {})
    assert value_deserialize.timestamp() == value.timestamp()


# Generated at 2022-06-23 16:54:51.442760
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF.loads(['{}'], A=[
        {
            'name': str
        }
    ]) == [{
        'name': ''
    }]

    assert SchemaF.loads('{"name": ""}', A={
        'name': str
    }) == {'name': ''}



# Generated at 2022-06-23 16:55:04.200024
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField
    assert f('test')._serialize(datetime(2002, 9, 22, 11, 37, 49), None, None) == 1033314269.0
    assert f('test')._deserialize(1155227796.0, None, None) == datetime(2007, 4, 15, 7, 49, 56)
    assert f('test')._serialize(None, None, None) == None
    assert f('test')._deserialize(None, None, None) == None
    x = fields.Field('test')
    x.required = True
    f2 = _TimestampField
    f2.required = x.required
    assert f2('test')._serialize(datetime(2002, 9, 22, 11, 37, 49), None, None) == 1033314269.0
   