

# Generated at 2022-06-23 16:45:15.876123
# Unit test for function build_schema
def test_build_schema():
    class A:
        a: str
    class AMixin(A, mm_field=fields.Str()):
        pass
    A = dataclasses.make_dataclass('A', [('a', str)], bases=(AMixin,))
    assert build_schema(A, A, False, False)

    class A:
        a: str
    class AMixin(A, mm_field=fields.Str()):
        pass
    class B:
        a: str
    A = dataclasses.make_dataclass('A', [('a', str)], bases=(AMixin,))
    B = dataclasses.make_dataclass('B', [('a', str)], bases=(AMixin,))
    assert build_schema(B, A, False, False)


# Generated at 2022-06-23 16:45:21.948110
# Unit test for function build_type
def test_build_type():
    _timestamp_field = _TimestampField()
    _iso_field = _IsoField()
    _union_field = _UnionField(None, None, None, None)
    for type_ in (list, typing.List):
        assert build_type(type_, {}, None, None, None) is fields.List

    for type_ in (dict, typing.Mapping, typing.MutableMapping):
        assert build_type(type_, {}, None, None, None) is fields.Mapping

    for type_ in (typing.Tuple, typing.Callable):
        assert build_type(type_, {}, None, None, None) is fields.Function


# Generated at 2022-06-23 16:45:30.108253
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B:
        pass
    desc = {
        typing.Union[A]: type(None),
        typing.Union[B]: type(None),
    }
    cls = A
    field = type(None)
    union_field = _UnionField(desc, cls, field)
    a1 = A()
    a2 = A()
    b = B()
    for val, expected_serialization, expected_deserialization in [
            (None, None, None),
            (a1, None, None),
            (a2, None, None),
            (b, None, None),
    ]:
        assert union_field.serialize(val, None, None) == expected_serialization
        assert union_field.deserialize(val, None, None) == expected_des

# Generated at 2022-06-23 16:45:41.394642
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    import typing
    import marshmallow
    import marshmallow_enum
    from dataclasses_json.schema import SchemaF
    from marshmallow import fields
    from dataclasses import dataclass, MISSING

    @dataclass
    class TEnum(marshmallow_enum.Enum):
        A = 1
        B = 2
        C = 3

    @dataclass
    class TTest(object):
        a: int
        b: TEnum
        c: typing.List[int]

    class TTestSchema(SchemaF[TTest]):
        a = fields.Int()
        b = marshmallow_enum.EnumField(TEnum, by_value=True)
        c = fields.List(fields.Int())


# Generated at 2022-06-23 16:45:43.463147
# Unit test for constructor of class SchemaF
def test_SchemaF():
    a = SchemaF(overload=True)
    # should be error
    b = SchemaF(overload=True)



# Generated at 2022-06-23 16:45:51.040987
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class ExampleSchema(SchemaF[A]):
        pass
    schema = ExampleSchema()
    res = schema.dumps([1, 2, 3])  # type: ignore
    assert isinstance(res, str)
    res = schema.dumps(1)  # type: ignore
    assert isinstance(res, str)
    res = schema.dumps([1, 2, 3], many=True)
    assert isinstance(res, str)
    res = schema.dumps([1, 2, 3], many=False)  # type: ignore
    assert isinstance(res, str)
    res = schema.dumps(1, many=False)
    assert isinstance(res, str)
    res = schema.dumps(1, many=True)  # type: ignore
    assert isinstance(res, str)


# Generated at 2022-06-23 16:45:52.373763
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    if sys.version_info >= (3, 7):
        s = SchemaF[int]()
        assert s.dumps([1, 2]), '[1, 2]'



# Generated at 2022-06-23 16:46:03.640779
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
  from dataclasses import dataclass

  @dataclass
  class DT:
    str_: str

  dt_schema = SchemaF[DT]()
  dt = dt_schema.loads('{"str_": "test"}')
  assert dt == DT('test')
  dt_list = dt_schema.loads('[{"str_": "test"}]', many=True)
  assert dt_list[0] == DT('test')
  assert dt_schema.loads(b'{"str_": "test"}') == DT('test')

# Generated at 2022-06-23 16:46:16.050166
# Unit test for function build_schema
def test_build_schema():
    from .main import from_dict, to_dict, from_json
    from .main import to_json
    from .mixins import FallbackDataClassJsonMixin
    import marshmallow as mm
    from marshmallow.fields import Function
    @dataclass_json(mm_field=Function(lambda x: 'x'))
    @dataclass
    class A:
        a: str

    @dataclass_json(mm_field=Function(lambda x: x))
    @dataclass
    class B:
        a: str

    class C(FallbackDataClassJsonMixin):
        a: str


    data = to_dict(A('a'))
    assert data == {'a': 'x'}
    
    data = to_dict(B('a'))

# Generated at 2022-06-23 16:46:23.046190
# Unit test for function schema
def test_schema():
    assert isinstance(schema({}, {}, False), dict)
    assert isinstance(schema({}, {}, True), dict)
    assert schema(Enum, {}, True) == {'value': fields.Str()}
    assert schema(
        typing.Optional[datetime], {}, True) == {
            'value': fields.DateTime(missing=None, allow_none=True)}
    assert schema(
        typing.Dict[str, typing.List[int]], {}, True) == {
            'value': fields.Dict()}
    assert schema(
        typing.Union[datetime, int], {}, False) == {}
    assert schema(
        typing.Optional[typing.Union[datetime, int]], {}, False) == {}



# Generated at 2022-06-23 16:46:29.123917
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField(required=True)
    assert iso_field._serialize(datetime.now(), None, None, None)
    assert iso_field._deserialize(datetime.now().isoformat(), None, None, None)
    with pytest.raises(ValidationError):
        iso_field._serialize(None, None, None, None)
    with pytest.raises(ValidationError):
        iso_field._deserialize(None, None, None, None)
        

# Generated at 2022-06-23 16:46:39.299877
# Unit test for function schema
def test_schema():
    from unittest.mock import Mock
    from dataclasses_json import DataClassJsonMixin
    from typing import List

    cls = Mock(name='cls')
    mixin = DataClassJsonMixin
    infer_missing = True
    # case 1
    cls.__name__ = 'test'

# Generated at 2022-06-23 16:46:48.753451
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import typing
    import marshmallow as ma
    import datetime

    class _ExampleSchema(ma.Schema):
        foo = ma.fields.Int()
        bar = ma.fields.Float()
        datetime = ma.fields.DateTime()

    Example = typing.NamedTuple('Example', [('foo', int), ('bar', float),
                                            ('datetime', datetime.datetime)])

    s = _ExampleSchema()
    e = Example(foo=1, bar=0.5, datetime=datetime.datetime.now())
    assert s.dump(e) == {'bar': 0.5, 'datetime': e.datetime, 'foo': 1}
    assert s.dumps(e) == '{"bar": 0.5, "datetime": "%s", "foo": 1}'

# Generated at 2022-06-23 16:47:00.850562
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: int

    @dataclass
    class C:
        c: Union[A, str, B]

    class S(Schema):
        pass

    c_schema = S.from_dataclass(C)
    union_field = c_schema._declared_fields['c']
    assert isinstance(union_field, _UnionField)
    assert union_field.cls == C
    assert union_field.field.name == 'c'
    assert union_field.field.type == C.__annotations__['c']
    assert bool(union_field.desc)

# Generated at 2022-06-23 16:47:11.883417
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from typing import Optional

    @dataclass_json
    class C:
        id: int
        name: str

    config.hooks.register_field_schema(int, fields.Integer)

    @dataclass_json
    @dataclass
    class D:
        id: float

    @dataclass_json
    @dataclass
    class E:
        id: int

    @dataclass_json
    @dataclass
    class F:
        id: str

    @dataclass_json
    @dataclass
    class G:
        id: bool

    @dataclass_json
    @dataclass
    class H:
        id: datetime


# Generated at 2022-06-23 16:47:20.112690
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class PointX(SchemaF):
        x: float
        y: float
        z: float

        class Meta:
            unknown = 'EXCLUDE'

    class PointY(SchemaF):
        x: float
        y: float

        class Meta:
            unknown = 'EXCLUDE'

    class PolygonX(SchemaF):
        points: typing.List[PointX] = field(default_factory=list)

        class Meta:
            unknown = 'EXCLUDE'

    p1 = PointX(x=1.0, y=2.0, z=3.0)
    p2 = PointY(x=1.0, y=2.0)
    p1_s = p1.dump(p1)
    print('p1_s', p1_s)

# Generated at 2022-06-23 16:47:30.821523
# Unit test for function schema
def test_schema():
    from dataclasses_json import MM, dataclass_json, config


# Generated at 2022-06-23 16:47:40.679015
# Unit test for function schema
def test_schema():

    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class A:
        a: str
        b: int

    @dataclass
    class B:
        a: str
        b: A

    fields.Dict(
        keys=fields.Str(allow_none=True, data_key='a', default=None),
        values=fields.Nested(A.schema(), many=False, allow_none=True,
                             data_key='b', default=None),
        allow_none=False, required=True, data_key='b', default=None
    )
    x = schema(B, None, False)

# Generated at 2022-06-23 16:47:41.979764
# Unit test for function schema
def test_schema():
    assert schema({},{},{}) != None 


# Generated at 2022-06-23 16:47:53.528776
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class X(typing.Generic[A]):
        pass

    x = X()  # type: SchemaF[A]
    x.dump([1, 2, 3], [4, 5], many=True)
    x.dump([1, 2, 3], many=True)
    x.dump(1, many=False)
    x.dumps([1, 2, 3], many=True)
    x.dumps(1, many=False)
    x.load([1, 2, 3], [4, 5], many=True)
    x.load([1, 2, 3], many=True)
    x.load(1, many=False)
    x.loads([1, 2, 3], many=True)
    x.loads(1, many=False)



# Generated at 2022-06-23 16:47:56.190934
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None



# Generated at 2022-06-23 16:48:01.758077
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    class TestSchema(Schema):
        timestamp_field = _TimestampField()

    dt = datetime.utcnow()
    json_data = {
        'timestamp_field': dt.timestamp()
    }
    s = TestSchema()
    result = s.loads(json.dumps(json_data))
    assert result['timestamp_field'] == dt



# Generated at 2022-06-23 16:48:12.065504
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class Test(Schema):
        name = fields.String()
        age = fields.Integer()

    class TestF(SchemaF[object]):
        name = fields.String()
        age = fields.Integer()

    class TestFEmpty(SchemaF[object]):
        pass

    t1 = TestF.dump(TestFEmpty(), many=True)
    t2 = TestF.dump([TestFEmpty()], many=True)
    t3 = TestF.dump(TestFEmpty())
    t4 = TestF.dumps(TestFEmpty())
    t5 = TestF.dumps([TestFEmpty()])



# Generated at 2022-06-23 16:48:19.539506
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class User(typing.NamedTuple):
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.String()
        age = fields.Integer()

    schema = UserSchema()
    user = User(name='Monty', age=100)
    result = schema.dump(user)
    assert isinstance(result, dict)
    assert result['name'] == 'Monty'
    assert result['age'] == 100

# Generated at 2022-06-23 16:48:20.987701
# Unit test for constructor of class _IsoField
def test__IsoField():
    return _IsoField()



# Generated at 2022-06-23 16:48:21.876016
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:48:22.814664
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Try to create one
    _IsoField()


# Generated at 2022-06-23 16:48:26.131269
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2020-01-01T00:00:00") == datetime(2020,1,1,0,0,0)
    assert _IsoField()._deserialize(None) == None



# Generated at 2022-06-23 16:48:30.014710
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class User(object):
        name : str = 'John Doe'
        age : int = 27
        active : bool = False
        friends : int = None
        lastlogin : datetime = datetime.now()

# Generated at 2022-06-23 16:48:40.693555
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    """Test that the method loads of SchemaF works as intended"""

    from marshmallow import fields

    class Bar(typing.Generic[A]):
        pass

    class SomeSchema(SchemaF[Bar]):
        some_field = fields.Str()

    assert SomeSchema().loads('{"some_field": "the value"}',
                              many=False) == Bar(some_field='the value')

    class Foo(typing.Generic[A]):
        pass

    class SomeSchema(SchemaF[Foo[Bar]]):
        some_field = fields.Str()

    assert SomeSchema().loads('{"some_field": "the value"}',
                              many=False) == Foo(some_field='the value')



# Generated at 2022-06-23 16:48:43.174062
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[A]):
        pass
    assert isinstance(MySchema, typing.GenericMeta)



# Generated at 2022-06-23 16:48:50.535900
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclasses.dataclass
    class User:
        id: int
        name: str

    class UserSchema(SchemaF[User]):
        id = fields.Int()
        name = fields.Str()

    users = [User(1, 'joe'), User(2, 'moe')]
    # dump
    user_schema = UserSchema()
    result = user_schema.dump(users)
    assert result == [{'id': 1, 'name': 'joe'}, {'id': 2, 'name': 'moe'}]
    # dump, many=True
    result = user_schema.dump(users, many=True)
    assert result == [{'id': 1, 'name': 'joe'}, {'id': 2, 'name': 'moe'}]

# Generated at 2022-06-23 16:49:01.800001
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    obj: TOneOrMulti
    many: bool
    partial: bool
    unknown: str
    json_data: JsonData
    kwargs: typing.Dict[str, typing.Any]
    generic = SchemaF[typing.Any]
    _ = generic.loads(json_data=json_data, many=many, partial=partial, unknown=unknown, **kwargs)
    _ = generic.loads(json_data=json_data, many=many, partial=partial, unknown=unknown)
    _ = generic.loads(json_data=json_data, partial=partial, unknown=unknown)
    _ = generic.loads(json_data=json_data, many=many, partial=partial, **kwargs)
    _ = generic.loads(json_data=json_data, many=many, unknown=unknown)
   

# Generated at 2022-06-23 16:49:13.293472
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestClass:
        field_1: int
        field_2: int
        field_3: int
        field_4: int
        field_5: int
        field_6: typing.Optional[float]
        field_7: typing.Optional[float]
        field_8: typing.Optional[float]
        field_9: typing.Optional[float]
        field_10: typing.Optional[float]
        field_11: typing.Optional[float]
        field_12: typing.Optional[float]
        field_neg_1: typing.Optional[float] = None
        field_neg_2: typing.Optional[float] = None
        field_neg_3: typing.Optional[float] = None
        field_neg_4: typing.Optional[float] = None
        field_neg

# Generated at 2022-06-23 16:49:21.584586
# Unit test for constructor of class _IsoField
def test__IsoField():
    sut = _IsoField()
    assert sut._serialize(datetime.now(), '', {}, default_field_name='') is not None
    assert sut._deserialize('2020-05-27T17:24:32.86838+08:00', '', {}, default_field_name='') is not None
    assert sut._deserialize('2020-05-27  17:24:32', '', {}, default_field_name='') is None
    assert sut._deserialize(None, '', {}, default_field_name='') is None


# Generated at 2022-06-23 16:49:29.608702
# Unit test for function schema
def test_schema():
    from marshmallow import Schema

    @dataclass_json
    class A:
        i: int

    assert(isinstance(A.schema(), Schema))

    @dataclass_json
    class B:
        i: typing.Optional[int]

    assert(isinstance(B.schema(), Schema))

    @dataclass_json
    class C:
        i: typing.Optional[int] = None

    assert(isinstance(C.schema(), Schema))

    @dataclass_json
    class D:
        i: typing.Optional[int] = field(default_factory=lambda: None)

    assert(isinstance(D.schema(), Schema))



# Generated at 2022-06-23 16:49:37.052983
# Unit test for function build_schema
def test_build_schema():
    from .mixins import from_json
    from .decorators import dataclass_json

    @dataclass_json
    class TestSchemaClass:
        my_int: int

    schema = build_schema(TestSchemaClass, from_json, False, False)
    assert schema.__name__ == "TestSchemaClassSchema"
    assert schema().Meta.fields == ("my_int",)
    assert issubclass(schema, Schema)



# Generated at 2022-06-23 16:49:38.128839
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()
    assert True


# Generated at 2022-06-23 16:49:41.553583
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF[int]  # type: ignore
    s.dump([1], many=True)
    s.dump([1], many=False)
    s.dump(1, many=False)


# Generated at 2022-06-23 16:49:52.651353
# Unit test for function build_schema
def test_build_schema():
  global TYPES, _user_overrides_or_exts, dc_fields, _decode_dataclass

# Generated at 2022-06-23 16:49:58.798314
# Unit test for constructor of class _IsoField
def test__IsoField():
    sv = datetime.now()
    s_attr = None
    s_obj = None
    s_kwargs = {}
    s_f = _IsoField()
    s_out = s_f._serialize(sv, s_attr, s_obj, **s_kwargs)
    assert(type(s_out) == str)

    dv = s_out
    d_attr = None
    d_data = None
    d_kwargs = {}
    d_f = _IsoField()
    d_out = d_f._deserialize(dv, d_attr, d_data, **d_kwargs)
    assert(type(d_out) == datetime)
    assert(d_out == sv)



# Generated at 2022-06-23 16:50:06.288070
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import dataclasses_json
    s = schema(dataclasses_json.dataclass_json, dataclasses_json.dataclass_json)
    assert isinstance(s, dict)
    assert len(s) == 5
    assert s['name'] == fields.Str()
    assert s['age'] == fields.Int()
    assert s['birthdate'] == _TimestampField()
    assert s['address'] == fields.Str()
    assert s['is_cool'] == fields.Bool()

test_schema()


# Generated at 2022-06-23 16:50:17.679130
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow_enum import EnumField  # type: ignore
    from dataclasses_json.mm import MM
    from typing import List

    @dataclass_json
    @dataclass
    class Person:
        first_name: str
        age: int

    @dataclass_json
    @dataclass
    class Contact:
        email: str
        person: Person
        tag: str = "person"

    @dataclass_json
    @dataclass
    class Account:
        user: Person
        contacts: List[Contact]


# Generated at 2022-06-23 16:50:20.808475
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Example(SchemaF[str]):
        pass

    assert Example().dump("str1") == {"__type": "str", "value": "str1"}



# Generated at 2022-06-23 16:50:32.469854
# Unit test for function build_type
def test_build_type():
    import pytest
    from marshmallow import fields, Schema, post_load
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from tests.dataclasses import F

    class FTest(FTest):
        @post_load
        def make_object(self, data, **kwargs):
            return FTest(**data)

    @dataclass_json
    @dataclass
    class FTest(F):
        @classmethod
        def schema(cls):
            return type('FSchema', (Schema,), dict(
                f_1=fields.Str(), f_2=fields.Str(),
                dataclass_json=dict(mm_field="f_1", mm_many=True,
                                    mm_type=fields.Str)))

    res = F

# Generated at 2022-06-23 16:50:39.262292
# Unit test for constructor of class _IsoField
def test__IsoField():
    t = _IsoField()._serialize(datetime(2017, 1, 1), "t", 12)
    assert t == "2017-01-01T00:00:00"
    t = _IsoField()._deserialize("2017-01-01T00:00:00", "t", 12)
    assert t == datetime(2017, 1, 1)



# Generated at 2022-06-23 16:50:41.241017
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class A(SchemaF):
        pass
    try:
        A()
    except NotImplementedError:
        pass
    else:
        assert False, 'constructor of SchemaF should raise exception'


# Generated at 2022-06-23 16:50:42.829532
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField() is not None


# Generated at 2022-06-23 16:50:49.565670
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def test_json_data(g: SchemaF[str], json_data: str):
        print(g.loads(json_data))
    test_json_data(SchemaF[str], '{"foo": 42}')


if sys.version_info >= (3, 7):
    class SchemaFromDict(SchemaF[A]):  # type: ignore
        pass



# Generated at 2022-06-23 16:50:51.136788
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[str]):
        pass
    MySchema()



# Generated at 2022-06-23 16:51:02.899576
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema
    from marshmallow import fields as f
    import typing

    class A:
        pass

    class B:
        pass

    d = {
        str: f.Str(),
        A: f.Int(),
        typing.List[str]: f.List(f.Str())
    }
    field = _UnionField(d, 'x', 'y')
    assert len(field.desc) == 3
    assert field.desc[str] == d[str]
    assert field.desc[A] == d[A]
    assert field.desc[typing.List[str]] == d[typing.List[str]]

    field = _UnionField(d, 'x', 'y', default=A)
    assert len(field.desc) == 3

# Generated at 2022-06-23 16:51:14.862197
# Unit test for function build_type
def test_build_type():
    from .test_data import build_type_test_data, build_type_test_data_json

    def fail(data: typing.Any, cls: typing.Any) -> bool:
        try:
            expected_json = build_type_test_data_json[cls]
        except KeyError:
            return False
        return Schema(cls).dumps(data) != expected_json

    warn = False
    for cls, data in build_type_test_data.items():
        with warnings.catch_warnings(record=True) as warnings_:
            if fail(data, cls):
                raise ValueError(f"Unit test failed: {Schema(cls).dumps(data)}")

# Generated at 2022-06-23 16:51:21.011486
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    x: SchemaF[str] = Schema()
    x.load({}, many=None)
    x.load({}, many=False)
    x.load([{}], many=True)
    x.load([{}], many=True, partial=True)


# Generated at 2022-06-23 16:51:27.327626
# Unit test for function build_schema
def test_build_schema():
    # Tests for issue https://github.com/lidatong/dataclasses-jsonschema/issues/118
    @dataclass_json
    @dataclass()
    class DataClass:
        string: str = "string"
        integer: int = 123
        boolean: bool = True
        date_time: datetime = datetime.utcnow()
        # note that we use a non-optional type here
        date_time_lazy: datetime = field(repr=False, default_factory=lambda: datetime.utcnow())
        # note that we use a non-optional type here
        custom_parser: datetime = field(default_factory=lambda: datetime.utcnow())
        # note that we use a non-optional type here
        custom_parser_not_called: datetime = field

# Generated at 2022-06-23 16:51:33.365627
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class SchemaFChild(SchemaF[int]):
        pass
    assert SchemaFChild().dump([1, 3]) == [1, 3]
    assert SchemaFChild().dump(2) == 2



# Generated at 2022-06-23 16:51:43.105976
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json import dataclass_json

    # Unit test for method dumps of class SchemaF
    @dataclass_json
    @dataclass
    class Data:
        x: str

    schema: SchemaF[Data] = dataclass_json.configure(tuple_as_unions=True)(SchemaF[Data])

    # success
    schema.dumps(Data('1'))
    schema.dumps([Data('1')])

    # failure
    try:
        schema.dumps(1)
        assert False
    except:
        pass
    try:
        schema.dumps([Data(1)])
        assert False
    except:
        pass



# Generated at 2022-06-23 16:51:49.119323
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[datetime]):
        pass

    s = MySchema()
    dt = datetime.now()
    assert s.dump(dt) == {"created": 1590149437.0}
    assert s.dump([dt]) == [{"created": 1590149437.0}]


# Generated at 2022-06-23 16:51:52.444082
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field

# Dataclass-specific Fields

# Generated at 2022-06-23 16:52:03.838343
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF.dumps() == SchemaF.dumps()


# Generated at 2022-06-23 16:52:13.425229
# Unit test for constructor of class _UnionField
def test__UnionField():
    import pytest
    from dataclasses_json.api import Schema as _Schema, dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass
    class Test:
        a: Union[A, int] = field(metadata={'marshmallow_field': fields.Integer()})

    schema = _Schema(Test)._Schema__schema_cls
    field = schema._declared_fields['a']
    assert field.__class__ == _UnionField
    assert field.desc[A] == A
    assert field.desc[int] == fields.Integer
    assert field.cls == Test
    assert field.field == Test.__annotations__['a']



# Generated at 2022-06-23 16:52:21.406114
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    import pytest  # type: ignore
    import marshmallow.fields # type: ignore


    @dataclass
    class TestDataclass:
        pass

    @dataclass
    class TestDataclassDecorated(mixin=mixin):
        nested_dc: TestDataclass

    type_ = TestDataclassDecorated.__annotations__['nested_dc']
    assert 'nested_dc' in TestDataclassDecorated.__annotations__
    assert build_type(type_, dict(), mixin,dc_fields(TestDataclassDecorated)[0], TestDataclassDecorated) == fields.Nested(TestDataclass.schema(), field_many=False)


# Generated at 2022-06-23 16:52:31.687797
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[str], {}, None, None, None) is fields.List
    assert build_type(typing.Dict[str, int], {"allow_none": True}, None, None, None) is fields.Dict
    assert build_type(typing.Optional[str], {}, None, None, None) is fields.Field
    assert build_type(typing.Optional[int], {}, None, None, None) is fields.Field
    assert build_type(typing.Dict[str, int], {}, None, None, None) is fields.Dict
    assert build_type(typing.Tuple[str, str], {}, None, None, None) is fields.Tuple
    assert build_type(typing.Tuple[str, str, int], {}, None, None, None)

# Generated at 2022-06-23 16:52:41.447004
# Unit test for function schema
def test_schema():
    # we mock dataclasses_json to avoid importing the library
    import builtins
    import unittest.mock as mock
    cls = mock.MagicMock()
    dc_fields = mock.MagicMock(return_value='dc_fields')
    cls.is_dataclass = False
    cls.__name__ = 'cls'
    cls.__module__ = 'module'
    cls.schema = mock.MagicMock(return_value='schema')
    cls.field = mock.MagicMock(return_value='field')
    cls.field.metadata = mock.MagicMock()
    cls.field.default = 'default'
    cls.field.default_factory = 'default_factory'

# Generated at 2022-06-23 16:52:48.224551
# Unit test for constructor of class _IsoField
def test__IsoField():
    print("Testing _IsoField")
    test_data_1 = '2020-01-01'
    test_data_2 = "2020-12-31"
    test_field = _IsoField()
    assert test_field._serialize(datetime(2020, 1, 1), "None", None) == test_data_1
    assert test_field._serialize(datetime(2020, 12, 31), "None", None) == test_data_2
    assert test_field._deserialize(test_data_1, "None", None) == datetime(2020, 1, 1)
    assert test_field._deserialize(test_data_2, "None", None) == datetime(2020, 12, 31)
    assert test_field.serialize(datetime(2020, 1, 1)) == test_data_1

# Generated at 2022-06-23 16:52:55.896456
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as ma
    class DummySchema(SchemaF[str]):
        d1 = ma.fields.String()

    d = DummySchema()
    d.dump("d1")
    d.dump(["d1"])
    d.dumps("d1")
    d.dumps(["d1"])


# Generated at 2022-06-23 16:53:03.761250
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema as MarshmallowSchema

    class MySchema(SchemaF[int], MarshmallowSchema):
        pass
    # Using a new type to denote a factory without value
    class SchemaF_loads_test_type(int):
        pass

    # not using bytes to avoid a mypy error
    obj = MySchema().loads(b'', many=False)
    assert isinstance(obj, SchemaF_loads_test_type) # type: ignore

    obj = MySchema().loads(b'', many=True)
    assert isinstance(obj, list) # type: ignore
    assert isinstance(obj[0], SchemaF_loads_test_type) # type: ignore

    obj = MySchema().loads(b'')

# Generated at 2022-06-23 16:53:15.044958
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List, Dict
    from marshmallow import Schema, fields
    class MySchemaF(SchemaF[List[Dict[str, str]]]):
        pass
    obj = MySchemaF().loads("[{'a': 'b'}]")  # type: ignore



# Generated at 2022-06-23 16:53:18.483344
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Patient(typing.Generic[A]):
        patient_name: str
    d = SchemaF[Patient].loads('{"patient_name": "Testy"}')



# Generated at 2022-06-23 16:53:29.812544
# Unit test for constructor of class _IsoField
def test__IsoField():
    # test for _serialize
    value = datetime.now()
    attr = "test_attr"
    obj = "test_obj"
    kwargs = {
        "deserialize_from": "test_attr",
        "default_in": "test_default_in",
        "deserialize_missing": "test_deserialize_missing",
        "allow_none": True,
        "required": "True",
    }
    iso_field = _IsoField(**kwargs)
    iso_field._serialize(value, attr, obj, **kwargs)

    # test for _deserialize
    value = datetime.now().isoformat()
    iso_field = _IsoField(required=True, allow_none=False, **kwargs)

# Generated at 2022-06-23 16:53:35.540930
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass

    @dataclass
    class D:
        x: int

    class MS(SchemaF[D]):
        x = fields.Integer()

    # mypy issue https://github.com/python/mypy/issues/7196
    MS().loads('{"x": 1}')  # type: ignore
    # mypy issue https://github.com/python/mypy/issues/7196
    MS().loads(b'{"x": 1}')  # type: ignore


if sys.version_info < (3, 7):
    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        # these are just to avoid mypy errors

# Generated at 2022-06-23 16:53:37.831027
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # type: () -> None
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:53:47.689527
# Unit test for function schema

# Generated at 2022-06-23 16:53:55.795561
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.fromtimestamp(0), None, None) == 0.0
    assert field._deserialize(0.0, None, None) == datetime.fromtimestamp(0)
    assert field._deserialize(None, None, None) is None
    field.required = True
    with pytest.raises(ValidationError):
        field._serialize(None, None, None)
    with pytest.raises(ValidationError):
        field._deserialize(None, None, None)


# Generated at 2022-06-23 16:54:06.967404
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    @dataclass
    class E:
        a: Union[A, B]
    class _Schema:
        a1 = fields.Field()
        a2 = fields.Field()
    _UnionField({typing.Union[A, B]: _Schema, typing.Union[B, C]: _Schema}, E, E.__annotations__['a']).__init__(allow_none=True)
    _UnionField({typing.Union[A, B]: _Schema, typing.Union[B, C]: _Schema}, E, E.__annotations__['a'], allow_none=True)

# Generated at 2022-06-23 16:54:13.010742
# Unit test for function build_type
def test_build_type():
    import typing
    assert build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int())
    assert build_type(typing.Union[str, int], {}, None, None, None) == _UnionField(
        union_desc={str: fields.Str(), int: fields.Int()},
        cls=None,
        field=None,
    )



# Generated at 2022-06-23 16:54:15.052119
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert isinstance(SchemaF[int].dumps({'a': 4}, many=False), str)



# Generated at 2022-06-23 16:54:26.684222
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        from dateutil import parser
    except ImportError:
        return
    date_str = '2019-04-12T15:53:49+08:00'
    dt_with_tz = parser.parse(date_str)
    dt_without_tz = dt_with_tz.replace(tzinfo=None)
    f = _IsoField()

    serialized = f._serialize(dt_with_tz, None, None)
    assert serialized == dt_without_tz.isoformat()
    serialized = f._serialize(dt_without_tz, None, None)
    assert serialized == dt_without_tz.isoformat()
    serialized = f._serialize(None, None, None)
    assert serialized is None


# Generated at 2022-06-23 16:54:38.672806
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union

    @dataclass
    class Point:
        x: float
        y: float

    class Shape:
        @dataclass
        class Line:
            p1: Point
            p2: Point

    @dataclass
    class Polygon:
        color: str
        points: list

    @dataclass
    class ShapeUnion:
        shape: Union[Polygon, Shape.Line]

    class ShapeUnionSchema(Schema):
        class Meta:
            unknown = 'EXCLUDE'

    ShapeUnionSchema().load(data={'shape': {
        'color': 'red',
        'points': [{'x': 0, 'y': 0}, {'x': 10, 'y': 10}]
    }})



# Generated at 2022-06-23 16:54:51.882487
# Unit test for function schema
def test_schema():
    from .test_test_classes import T


# Generated at 2022-06-23 16:55:05.091111
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import Generator
    from typing import Tuple
    from dataclasses import dataclass
    @dataclass
    class Foo:
        a: str
    foo = Foo("bar")
    def _loads(self, json_data, many=None, partial=None, unknown=None, **kwargs)->Tuple[Foo, int]:
        return Foo("baz"), 42
    f = SchemaF[Foo]()
    f.loads = _loads # type: ignore
    load_result = f.loads("")
    assert load_result.a == "baz"
    assert isinstance(load_result, Foo)
