

# Generated at 2022-06-23 16:45:10.847993
# Unit test for function build_schema
def test_build_schema():
    class MyMixin:
        pass

    @dataclass_json
    @dataclass
    class MyDataclass:
        name: str
        age: int = 17

    ms = build_schema(MyDataclass, MyMixin, True, True)
    # schema = {'name': <class 'marshmallow.fields.Field'>, 'age': <class 'marshmallow.fields.Int'>,
    # 'make_mydataclass': <function MyDataclassSchema.make_mydataclass at 0x7f3c90828730>}
    assert ms.schema == {'name': fields.Field, 'age': fields.Int}
    assert ms.dump(MyDataclass('John')) == {"name": "John", "age": 17}

# Generated at 2022-06-23 16:45:11.752705
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:45:20.303150
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Math:
        @property
        def name(self):
            return 'math'

    class Foo:
        def __init__(self, a: int, f: int):
            self.a = a
            self.f = f

    class ComplexFoo:
        def __init__(self, b: int, f: int, g: int):
            self.b = b
            self.f = f
            self.g = g

    from typing import Union

    d = {'a': 5, 'f': 10}
    e = {'b': 5, 'f': 10, 'g': 15}
    f = {'f': 10, 'math': Math()}

    x = _UnionField({Foo: None, ComplexFoo: None}, None, None)

# Generated at 2022-06-23 16:45:25.361126
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    dt = datetime.utcnow()
    assert field._deserialize(99500.5, attr=None, data=None, partial=None) == _timestamp_to_dt_aware(99500.5)
    assert field._deserialize(field._serialize(dt, attr=None, obj=None, partial=None), attr=None, data=None, partial=None) == dt


# Generated at 2022-06-23 16:45:27.920593
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    from .test_schema import S
    SchemaF[S]



# Generated at 2022-06-23 16:45:39.675453
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Test:
        def __init__(self, i):
            self.i = i
    class TestDC:
        def __init__(self, i):
            self.i = i
    class TestDCExt(TestDC):
        pass
    @dataclass
    class TestDC2:
        i: int
    desc = {int: fields.Int(allow_none=True),
            str: fields.Str(allow_none=True),
            TestDC: fields.Dict(allow_none=True),
            TestDC2: fields.Dict(allow_none=True)}
    f = _UnionField(desc, 'TestDC', [], allow_none=True)

    assert f._serialize(3, 'x', None) == 3

# Generated at 2022-06-23 16:45:49.433737
# Unit test for constructor of class _UnionField
def test__UnionField():
    class U(Enum):
        A = 1
        B = 2
    class Cls1:
        pass
    class Cls2:
        pass
    class Cls3:
        pass
    class Cls4:
        pass
    @dataclass
    class TestDC(Schema):
        u: Union[Cls1, Cls2]
    f = TestDC.fields["u"]
    assert isinstance(f, _UnionField) and f.desc == {Cls1: fields.Raw, Cls2: fields.Raw}
    f = _UnionField({U: EnumField, int: fields.Integer}, None, None)
    assert isinstance(f, _UnionField) and f.desc == {U: EnumField, int: fields.Integer}


# Generated at 2022-06-23 16:45:54.293127
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Person:
        age: int

    class Student:
        age: int
        school: str

    try:
        tmp = _UnionField(
            {int: fields.Int, Person: fields.Nested(PersonSchema)},
            Union[int, Person],
            "test")
    except Exception:
        assert False
    assert isinstance(tmp, _UnionField)



# Generated at 2022-06-23 16:45:59.099193
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_obj = '2019-12-30T17:29:37.272886+00:00'
    test_field = _IsoField()
    assert (test_field._deserialize(test_obj, 'attr', 'data') ==
            datetime(2019, 12, 30, 17, 29, 37, 272886))



# Generated at 2022-06-23 16:46:00.729550
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timefield = _TimestampField()  # noqa


# Generated at 2022-06-23 16:46:06.618224
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _serialize = _TimestampField()._serialize
    _deserialize = _TimestampField()._deserialize
    assert _serialize(datetime(year=2019, month=1, day=1, hour=1, minute=1, second=1, microsecond=1), None, None) == 1546318461.000001
    assert _deserialize(1546318461.000001, None, None) == datetime(year=2019, month=1, day=1, hour=1, minute=1, second=1, microsecond=10000)


# Generated at 2022-06-23 16:46:17.805863
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, asdict
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class NewType(int):
        def __str__(self):
            return 'My Int'

    @dataclass_json
    @dataclass
    class User:
        name: str

    @dataclass_json
    @dataclass
    class Data:
        name: str = 'test'
        user: typing.Dict[str, str] = None
        new_type: NewType = NewType(2)
        user_list: typing.List[User] = None
        user_dict: typing.Dict[int, User] = None
        user_tuple: typing.Tuple[User] = None

# Generated at 2022-06-23 16:46:20.112718
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.deserialize(1542122376)
    field.serialize(datetime.fromtimestamp(1542122376))


# Generated at 2022-06-23 16:46:29.406531
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import fields, Schema

    class User:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    class SerializedUser(Schema):
        name = fields.Str(required=True)
        age = fields.Int(required=True)

    schema = SchemaF[User]()

    u = User('John', 40)
    assert schema.load(SerializedUser().dump(u, many=False)) == u

    u2 = User('John', 41)
    assert schema.load([SerializedUser().dump(u, many=False), SerializedUser().dump(u2, many=False)], many=True) == [u, u2]

    u = User('John', 42)

# Generated at 2022-06-23 16:46:39.546809
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF()
    s.loads("")
    s.loads("", many=True)
    s.loads("", many=False)
    s.loads("".encode("utf-8"))
    s.loads("".encode("utf-8"), many=True)
    s.loads("".encode("utf-8"), many=False)
    s.loads([])
    s.loads([], many=True)
    s.loads([], many=False)


# Generated at 2022-06-23 16:46:48.877223
# Unit test for function build_type
def test_build_type():
    class E(Enum):
        A = "a"
        B = "b"
    class U:
        pass
    class A:
        pass
    class B:
        pass
    class C:
        pass
    class D:
        pass
    class T(typing.Generic[A]):
        pass
    class K(typing.Generic[A, B, C]):
        pass
    class S(typing.Generic[A, B, C]):
        pass
    class I(typing.Generic[A, B, C]):
        pass
    from dataclasses import dataclass
    @dataclass
    class DData(dict):
        pass
    @dataclass
    class Nested:
        pass

# Generated at 2022-06-23 16:46:53.415521
# Unit test for function build_type
def test_build_type():
    type_ = typing.Mapping
    options = {}
    mixin = None
    field = None
    cls = None
    assert build_type(type_, options, mixin, field, cls)


_SCHEMA_CACHE = {}  # type: typing.dict



# Generated at 2022-06-23 16:47:04.370198
# Unit test for function schema
def test_schema():
    from typing import Optional
    from marshmallow import fields, Schema

    class MetaData:
        mm_field = None
        letter_case = None

# Generated at 2022-06-23 16:47:06.793216
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF[int]()
    result = schema.dumps(1)
    assert result == '1'



# Generated at 2022-06-23 16:47:15.817711
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Point:
        x: int
        y: int

    class PointSchema(Schema):
        x = fields.Int()
        y = fields.Int()

    @dataclass
    class A:
        a: typing.Union[Point, int]

    # without optional
    assert type(_UnionField(desc=A.__annotations__['a']._asdict(),
                            cls=A,
                            field=dc_fields(A)[0])) == _UnionField

    # with optional

# Generated at 2022-06-23 16:47:17.867547
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class S:
        x: str

    s = SchemaF[S]().load({"x": "1"})

    assert s.x == "1"



# Generated at 2022-06-23 16:47:24.030862
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    @dataclasses.dataclass
    class C:
        uuid: uuid.UUID

    dc = C(uuid.UUID('39051e2a-8c42-4645-a734-a86eab6bcbdc'))
    assert SchemaF[C].from_dict(dc).dump() == {
        'uuid': '39051e2a-8c42-4645-a734-a86eab6bcbdc'
    }

# Generated at 2022-06-23 16:47:27.644591
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    obj = '2020-05-14T09:00:00.000'
    obj_iso = field._serialize(obj, 'foo', None)
    assert obj_iso == '2020-05-14T09:00:00.000'
    obj_iso_deserialized = field._deserialize(obj_iso, 'foo', None)
    assert obj_iso_deserialized == obj


# Generated at 2022-06-23 16:47:33.133790
# Unit test for constructor of class _UnionField
def test__UnionField():
    class MyField(fields.Field):
        pass
    desc = {int: MyField()}
    instance = _UnionField(desc, None, None)
    assert instance.desc is desc
    assert instance.cls is None
    assert instance.field is None
    assert instance.allow_none is False



# Generated at 2022-06-23 16:47:42.376727
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[dict].loads('{"toto": 1}', many=False)

# Generated at 2022-06-23 16:47:50.717096
# Unit test for function build_type
def test_build_type():
    from typing import List, Dict
    from marshmallow import fields
    from marshmallow_enum import EnumField  # type: ignore

    assert isinstance(build_type(List[str], {}, None, None, None), fields.List)
    assert isinstance(build_type(List[None], {}, None, None, None), fields.List)  # type: ignore
    assert isinstance(build_type(list, {}, None, None, None), fields.List)
    assert isinstance(build_type(int, {}, None, None, None), fields.Int)
    assert isinstance(build_type(Dict[str, int], {}, None, None, None),
                      fields.Mapping)
    assert isinstance(build_type(dict, {}, None, None, None), fields.Dict)

# Generated at 2022-06-23 16:47:58.450292
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema
    class MySchema(Schema):
        field1 = fields.Str()
    s = MySchema()

    assert s.load({'field1': 'abc'}) == {'field1': 'abc'}
    assert s.load([{'field1': 'abc'}, {'field1': 'def'}]) == [
        {'field1': 'abc'}, {'field1': 'def'}]
    assert s.load({'field1': 'abc'}, True) == [{'field1': 'abc'}]



# Generated at 2022-06-23 16:48:08.301250
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    import marshmallow as mm
    # Note: you cannot use list[int] below because list is not a registered type in the mm
    # type system. List[int] is registered. Since it is registered it is not covered by this unit test.
    class S(SchemaF[int]): pass
    s = S()
    assert s.load({'a':1}) == 1
    assert s.load([{'a':1}, {'a':2}], many=True) == [1, 2]
    with pytest.raises(mm.exceptions.ValidationError):
        s.load([{'a':1}, {'a':2}], many=False)

# Generated at 2022-06-23 16:48:12.184289
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsf = _TimestampField()
    ndt = datetime.now()
    nts = ndt.timestamp()
    assert ndt == tsf.deserialize(nts)
    assert nts == tsf.serialize(ndt)
    assert tsf.deserialize(None) == None
    assert tsf.serialize(None) == None


# Generated at 2022-06-23 16:48:17.035709
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class A:
        field1: float
    a = A(field1=1.0)
    s = SchemaF[A]() # error: Cannot instantiate abstract class SchemaF with abstract attribute _declared_fields
    s.dump(a)



# Generated at 2022-06-23 16:48:27.172794
# Unit test for function build_type
def test_build_type():
    assert(build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int))
    assert(build_type(typing.Optional[typing.List[int]], {}, None, None, None) == fields.List(fields.Int, allow_none=True))
    assert(build_type(typing.Callable[[], bool], {}, None, None, None) == fields.Function)
    assert(build_type(typing.Optional[typing.Callable[[], bool]], {}, None, None, None) == fields.Function(allow_none=True))
    assert(build_type(typing.Optional[typing.Dict], {}, None, None, None) == fields.Dict(allow_none=True))

# Generated at 2022-06-23 16:48:35.849841
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert issubclass(SchemaF[TestData], Schema)
    assert issubclass(SchemaF[TestData], typing.Generic[TestData])

    td = TestData(1, 2.0, 'str')
    schema = SchemaF[TestData]()

    serialized = schema.dumps(td)
    assert serialized == '{"a": 1, "b": 2.0, "c": "str"}'

    serialized_list = schema.dumps([td, td])
    assert serialized_list == '[{"a": 1, "b": 2.0, "c": "str' \
                               '"}, {"a": 1, "b": 2.0, "c": "str"}]'


# Generated at 2022-06-23 16:48:46.238726
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass

    class AA(A):
        a: str

    class B:
        pass

    class BB(B):
        b: int

    class Schema(Schema):
        a = fields.Str()
        b = fields.Int()

    field_a = _UnionField(desc={AA: Schema, BB: Schema}, cls=None, field=None)
    field_b = _UnionField(desc={A: Schema, B: Schema}, cls=None, field=None)

    assert field_a._serialize(AA(a='a'), 'a', {}) == {'a': 'a', '__type': 'AA'}

# Generated at 2022-06-23 16:48:47.040861
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-23 16:48:55.626119
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Person(object):
        pass
    class PersonSchema(SchemaF[Person]):
        pass

    p = Person()
    p.name = "Monty"
    assert PersonSchema().dumps(p) == "{'name': 'Monty'}"

    class Person(object):
        pass
    class PersonSchema(SchemaF[Person]):
        pass

    p = Person()
    p.name = "Monty"
    assert PersonSchema().dumps(p) == "{'name': 'Monty'}"



# Generated at 2022-06-23 16:49:04.569466
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    @dataclass
    class B:
        x: str

    _UnionField({int: 1}, A, int, allow_none=False)
    _UnionField({int: 1, str: 1}, A, int, allow_none=False)
    _UnionField({A: 1, B: 1}, A, A, allow_none=False)
    _UnionField({A: 1, B: 1}, A, A, allow_none=True)
    _UnionField({A: 1, B: 1, int: 1}, A, A, allow_none=False)
    _UnionField({A: 1, B: 1, int: 1}, A, A, allow_none=True)



# Generated at 2022-06-23 16:49:13.951140
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class SchemaClass:
        x: int
    assert SchemaClass.schema().__name__ == 'SchemaClassSchema'
    assert SchemaClass.schema().x.__class__.__name__ == 'Int'
    assert SchemaClass.schema().load({'x': '1'}) == SchemaClass(x=1)
    assert SchemaClass.schema().dump([SchemaClass(x=1), SchemaClass(x=2)]) == [{'x': 1}, {'x': 2}]
    assert SchemaClass.schema().dumps([SchemaClass(x=1), SchemaClass(x=2)]) == '[{"x": 1}, {"x": 2}]'



# Generated at 2022-06-23 16:49:20.685061
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass
    class Person:
        name: str
        age: int

    PersonF = typing.TypeVar('PersonF')

    class PersonSchema(SchemaF[PersonF], typing.Generic[PersonF]):
        name = fields.Str()
        age = fields.Int()

        @post_load
        def make_person(self, data, **kwargs):
            return Person(**data)

    p = Person('John', 42)
    ps = PersonSchema()
    ps.dump(p)
    ps.dumps(p)
    ps.load({'name': 'John', 'age': 42})
    ps.loads(b'{"name": "John", "age": 42}')



# Generated at 2022-06-23 16:49:24.800800
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    f = FooSchema().loads('{"bar": "x"}')
    assert f.bar == 'x'



# Generated at 2022-06-23 16:49:28.583751
# Unit test for function build_schema
def test_build_schema():
    assert 'a' in build_schema(C, None, False, False).__dict__


DATACLASS_JSON_CONFIG = "dataclass_json_config"
""" This is the name of the dataclass field that will be used to store the entire config """



# Generated at 2022-06-23 16:49:33.036057
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        class schema_f(SchemaF):
            pass



# Generated at 2022-06-23 16:49:37.778445
# Unit test for constructor of class _UnionField
def test__UnionField():
    SomeUnion = typing.Union[int, str]
    assert _UnionField(
        desc={int: fields.Integer(), str: fields.String()},
        cls=None,
        field=None,
    ).desc == {int: fields.Integer(), str: fields.String()}


# Generated at 2022-06-23 16:49:42.641159
# Unit test for function schema
def test_schema():
  class Base:
    pass

  @dataclass_json
  class Person(Base):
    name: str
    age: int = field(metadata={'dataclasses_json': {'mm_field': 'test'}})

  assert schema(Person, Base, False) == {
    'name': fields.Field(**{}),
    'age': 'test'
  }

# Generated at 2022-06-23 16:49:50.092641
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert isinstance(SchemaF[datetime].load([])[0], datetime)
    assert isinstance(SchemaF[datetime].load({}), datetime)


    assert isinstance(SchemaF[int].load([])[0], int)
    assert isinstance(SchemaF[int].load({}), int)


    assert isinstance(SchemaF[str].load([])[0], str)
    assert isinstance(SchemaF[str].load({}), str)


    assert isinstance(SchemaF[bool].load([])[0], bool)
    assert isinstance(SchemaF[bool].load({}), bool)


    assert isinstance(SchemaF[float].load([])[0], float)
    assert isinstance(SchemaF[float].load({}), float)




# Generated at 2022-06-23 16:49:56.044805
# Unit test for function build_schema
def test_build_schema():
    from datetime import date
    from uuid import uuid4

    @dataclass
    class Sample:
        i: int
        d: date = datetime.now().date()

    dc_schema = build_schema(Sample, None, False, True)
    assert issubclass(dc_schema, Schema)



# Generated at 2022-06-23 16:50:02.149864
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int = 1

    a = A(2)
    json_a = SchemaF[A].dumps(a)
    assert json_a == '{"a": 2}'



# Generated at 2022-06-23 16:50:08.667214
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass   # noqa

    def test_1_SchemaF_dump(self):
        def test_1_1_SchemaF_dump(self):
            pass   # noqa
            # Unit tests for method dump of class SchemaF
            from datetime import datetime
            from dataclasses import dataclass
            from marshmallow import fields

            @dataclass
            class User:
                name: str
                birthday: datetime
            SchemaF(User)


    SchemaF(User).dump(User(name= 'bob', birthday= datetime(1989, 3, 24)))



# Generated at 2022-06-23 16:50:14.163195
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclasses.dataclass
    class Person:
        name: str

    s = SchemaF(
        fields={
            'name': fields.Str(),
        }).load({})
    s2 = SchemaF(
        fields={
            'name': fields.Str(),
        }).load([{}])
    assert s == Person('', )
    assert s2 == [Person('', )]



# Generated at 2022-06-23 16:50:24.480842
# Unit test for constructor of class _UnionField
def test__UnionField():  # pylint: disable=missing-function-docstring
    from dataclasses import dataclass
    from typing import Union

    from marshmallow_dataclass import dataclass
    from dataclasses_json.api import Schema, configure

    @dataclass
    class SomeDataClass:
        a: int
        b: str

    class SomeEnum(Enum):
        a = 0
        b = 1

    @dataclass
    class ExtraDataClass:
        a: int
        b: str

    @dataclass
    class SimpleDataClass:
        a: Union[int, float, str, None]
        b: Union[bool, float]
        c: Union[SomeEnum, None]
        d: Union[datetime.datetime, None]
        e: Union[datetime.date, None]

# Generated at 2022-06-23 16:50:30.027979
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MyClass:
        def __init__(self, my_id: int, my_name: str):
            self.my_id = my_id
            self.my_name = my_name

    SchemaF(MyClass)



# Generated at 2022-06-23 16:50:38.469119
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass
    class Foo:
        a: str

    class F(SchemaF[Foo]):
        a = fields.Str()

    assert F().loads([
        {'a': 'bar'},
        {'a': 'baz'}
    ]) == [Foo('bar'), Foo('baz')]

    assert F().loads({'a': 'bar'}) == Foo('bar')

    assert F().load([
        {'a': 'bar'},
        {'a': 'baz'}
    ]), [Foo('bar'), Foo('baz')]

    assert F().load({'a': 'bar'}) == Foo('bar')

# Generated at 2022-06-23 16:50:48.651524
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField(required=False)
    assert a.required == False
    assert a.default_error_messages["required"] == "Missing data for required field."
    assert a._serialize(datetime.fromisoformat("1997-07-16T19:20:30.45+01:00"), "attr", "obj", key1=1, key2=2) == "1997-07-16T19:20:30.450000+01:00"
    assert a._deserialize("1997-07-16T19:20:30.45+01:00", "attr", "data", key1=1, key2=2) == datetime(1997, 7, 16, 19, 20, 30, 450000, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))

# Generated at 2022-06-23 16:51:00.591809
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: (...) -> None
    import json
    # test load
    @dataclasses_json.dataclass_json(letter_case=LetterCase.CAMEL)
    class User:
        name: str
        age: int

    class UserSchema(dataclasses_json.SchemaF[User]):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    user_schema = UserSchema()
    user_schema.load({"name": "John", "age": 200})
    user_schema.load([{"name": "John", "age": 200}])
    user_schema.load({"name": "John"}, many=False)
    user_schema.load([{"name": "John"}], many=False)

    user_schema

# Generated at 2022-06-23 16:51:05.252397
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__repr__() == '<fields.TimestampField>'

# Unit tests for serialization of class _TimestampField

# Generated at 2022-06-23 16:51:11.151807
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class C:
        a: int 
        b: str = 'b'
    c = C(1)
    _c = SchemaF[C].dumps(c, many=False)
    c_ = SchemaF[C].dumps([c], many=True)
    assert _c == c_



# Generated at 2022-06-23 16:51:18.077809
# Unit test for function schema
def test_schema():
    import typing

    @dataclass
    class Test:
        a: typing.List[int]
        b: typing.Dict[str, int]

    assert (schema(Test, 0, False) == {'a': fields.List(),
                                       'b': fields.Mapping()})
    @dataclass(frozen=True)
    class Test:
        a: typing.List[int]

    assert (schema(Test, 0, False) == {'a': fields.List()})



# Generated at 2022-06-23 16:51:27.103855
# Unit test for constructor of class SchemaF
def test_SchemaF():
    import dataclasses
    import marshmallow as ma

    @dataclasses.dataclass
    class A:
        x: int

    SchemaF[A]  # should not raise an exception
    ma.Schema.from_dataclass(A)  # should not raise an exception

    class A:
        def __init__(self, x):
            self.x = x

    SchemaF[A]  # should not raise an exception
    ma.Schema.from_dataclass(A)  # should not raise an exception



# Generated at 2022-06-23 16:51:36.796935
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.Dict, {}, None, None, None) == fields.Dict
    assert build_type(typing.List, {}, None, None, None) == fields.List
    assert build_type(typing.Any, {}, None, None, None) == fields.Raw
    assert build_type(typing.Optional[int], {}, None, None, None) == fields.Int
    assert build_type(typing.Optional[typing.List[int]], {}, None, None, None) == fields.List



# Generated at 2022-06-23 16:51:42.629948
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF[int, int]
    assert s.load('1') == 1
    assert s.load(['1']) == [1]
    assert s.loads('1') == 1
    assert s.loads('[1]') == [1]



# Generated at 2022-06-23 16:51:46.883145
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF.loads(bytes([1,2,3]), many=True)


# Generated at 2022-06-23 16:51:48.214263
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass

# Generated at 2022-06-23 16:51:53.867774
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF.loads(SchemaF.dumps(['a']), many=True) == ['a']
    assert SchemaF.loads(SchemaF.dumps('a')) == 'a'



# Generated at 2022-06-23 16:52:04.737657
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List, Union

    from marshmallow import Schema

    class InnerSchema(Schema):
        """Simple Schema class for testing.
        """

        value: str

    class OuterSchema(SchemaF[Union[List[str], str]]):
        """Simple Schema class for testing.
        """

        value: str

    class OuterMultiSchema(SchemaF[Union[List[InnerSchema], InnerSchema]]):
        """Simple Schema class for testing.
        """

        value: str

    inner_instance_data = InnerSchema().load({'value': 'foo'})
    assert inner_instance_data == {'value': 'foo'}

    outer_instance_data = OuterSchema().load({'value': 'foo'})

# Generated at 2022-06-23 16:52:14.576048
# Unit test for function build_type
def test_build_type():
    import marshmallow
    from marshmallow import pre_dump, post_dump
    class DummySchema(Schema):
        field = fields.Nested(Schema)

    # handle dataclasses
    @dataclass
    class DC:
        pass
    @dataclass
    class DCMix(mixin):
        pass
    _ = build_type(DC, {}, mixin, dc_fields(DCMix)[0], DCMix)
    # handle types
    type_ = typing.List[DC]
    assert isinstance(build_type(type_, {}, mixin, dc_fields(DCMix)[0], DCMix), fields.List)
    # handle enums
    type_ = Enum('Enum', [])

# Generated at 2022-06-23 16:52:23.688517
# Unit test for function build_schema
def test_build_schema():
    import marshmallow as mm
    from dataclasses import dataclass
    import dataclasses_json.api as dcj

    @dataclass
    class Person:
        name: str
        age: int = 35

    DataClassSchema = build_schema(Person, False, False, False)
    assert isinstance(DataClassSchema.name, mm.fields.Field)
    assert isinstance(DataClassSchema.age, mm.fields.Int)
    assert not hasattr(DataClassSchema, "dataclass_json_config")

    schema = DataClassSchema()
    assert isinstance(schema, mm.Schema)

    person = Person(name="John Doe")
    result = schema.dumps(person)

    assert isinstance(result, str)

# Generated at 2022-06-23 16:52:26.961681
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    iso_field._serialize(None, None, None)
    iso_field._deserialize(None, None, None)


# Generated at 2022-06-23 16:52:38.374146
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing_extensions import Literal
    from pydantic import BaseModel
    from dataclasses import dataclass
    import marshmallow as mm
    from marshmallow import fields
    from marshmallow_enum import EnumField

    class A(Enum):
        a = 1
        b = 2
        c = 3


    class B(BaseModel):
        x: int
        y: int
        z: A


    @dataclass
    class C:
        x: int
        y: int
        z: A


    class TestSchema_1(SchemaF[B]):
        x = fields.Int()
        y = fields.Int()
        z = EnumField(A)


    class TestSchema_2(SchemaF[C]):
        x = fields.Int()

# Generated at 2022-06-23 16:52:45.039494
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        x: int
        y: dict

    assert issubclass(build_schema(A, None, False, False), Schema)
    assert 'x' in build_schema(A, None, False, False).declared_fields



# Generated at 2022-06-23 16:52:50.394076
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from typing import List, Optional, Union, Dict
    from dataclasses_json import dataclass_json, config
    from marshmallow import Schema

    @dataclass_json
    @dataclass
    class MyClass:
        class_id: int
        name: str
        my_list: List[str] = field(default_factory=list)
        my_list_2: List[int] = field(default_factory=list)
        my_list_3: List[Optional[str]] = field(default_factory=list)
        my_list_4: List[Optional[int]] = field(default_factory=list)
        my_list_5: List[Optional[int]] = field(default_factory=list)
        my_optional

# Generated at 2022-06-23 16:53:01.965703
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import typing
    import marshmallow

    class A:
        def __init__(self, a: int):
            self.a = a

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class B:
        a: typing.List[A]

    a_schema_f = dataclasses_json.configure_schema(SchemaF[A])
    b_schema_f = dataclasses_json.configure_schema(SchemaF[B])

    a = A(1)
    a_serialized = a_schema_f.dump(a)

    b = B([A(2), A(3)])
    b_serialized = b_schema_f.dump(b)

    assert a_serialized == {"a": 1}


# Generated at 2022-06-23 16:53:12.288356
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class Person:
        name: str = ''

    schema = SchemaF[Person]()

    assert schema.dump({'name': 'John'}) == {'name': 'John'}
    assert schema.dump([{'name': 'John'}, {'name': 'Jane'}]) == [{
        'name': 'John'
    }, {'name': 'Jane'}]
    assert schema.dump(Person('John')) == {'name': 'John'}
    assert schema.dump([Person('John'), Person('Jane')]) == [{
        'name': 'John'
    }, {'name': 'Jane'}]



# Generated at 2022-06-23 16:53:15.658771
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info <= (3, 7):
        return  # noqa
    try:
        SchemaF()  # type: ignore
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:53:21.709573
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields
    import dataclasses
    from typing import Any, int

    @dataclasses.dataclass
    class Foo:
        i: int

    schema = SchemaF[Foo]({'i': fields.Integer()})
    assert schema.dumps(Foo(i=1)) == '{"i": 1}'
# for python versions < 3.7 we will not have Generic support

# Generated at 2022-06-23 16:53:22.658605
# Unit test for function build_type
def test_build_type():
    assert True

# Generated at 2022-06-23 16:53:31.081226
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    test_list_1: typing.List[int] = [5, 6]
    schema_instance_1 = SchemaF()
    test_result_1 = schema_instance_1.dumps(test_list_1)
    assert test_result_1 == '''[5, 6]'''

    test_instance_2 = 0
    schema_instance_2 = SchemaF()
    test_result_2 = schema_instance_2.dumps(test_instance_2)
    assert test_result_2 == '''0'''

    test_list_3: typing.List[int] = [5, 6]
    schema_instance_3 = SchemaF()
    test_result_3 = schema_instance_3.dumps(test_list_3, many=True)

# Generated at 2022-06-23 16:53:32.547134
# Unit test for function build_type
def test_build_type():
    pass

    # TODO: enumerate the test cases



# Generated at 2022-06-23 16:53:34.379499
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField(None, 1, 2, 3, 4, 5)



# Generated at 2022-06-23 16:53:40.559874
# Unit test for constructor of class _UnionField
def test__UnionField():
    class _A:
        pass

    class _B:
        pass

    assert _UnionField(
        desc={_A: 'dummy_schema'},
        cls=str,
        field=str,
    ).desc == {_A: 'dummy_schema'}
    assert _UnionField(
        desc={_B: 'dummy_schema'},
        cls=str,
        field=str,
    ).desc == {_B: 'dummy_schema'}


# Generated at 2022-06-23 16:53:46.677946
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class Dc1:
        pass
    class DcSchemaF(SchemaF[Dc1]):
        pass
    dc_schema_f = DcSchemaF()
    dc_schema_f.dump([], many=True)
    dc_schema_f.dump(Dc1(), many=False)
    dc_schema_f.dump([], many=False)
    dc_schema_f.dump(Dc1(), many=True)


# Generated at 2022-06-23 16:53:55.075553
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    obj = DeepThought(
        answer=42,
        question="What is the answer to life, the universe and everything?",
        meaning_of_life=True
    )
    schema = DeepThoughtSchema()
    schema.loads(schema.dumps(obj))
    schema.loads(schema.dumps(obj), many=True)
    schema.loads(schema.dumps([obj]), many=False)
    schema.loads(schema.dumps([obj]), many=True)



# Generated at 2022-06-23 16:54:03.534978
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def f1(p1: typing.List[int], p2: bool) -> typing.List[str]: pass
    def f2(p1: int, p2: bool) -> str: pass

    s = SchemaF([{ 'p1' : [5, 6], 'p2' : True }], many=True, partial=True, unknown=None)
    p1, p2 = s.loads(b'[{"p1": [5, 6], "p2": true}]')
    f1(p1, p2)

    s = SchemaF({ 'p1' : 5, 'p2' : True }, many=True, partial=True, unknown=None)
    p1, p2 = s.loads(b'{"p1": 5, "p2": true}')

# Generated at 2022-06-23 16:54:14.552098
# Unit test for constructor of class _UnionField
def test__UnionField():
    class TestDataclass(metaclasses=[CatchAllVar]):
        pass

    @dataclasses.dataclass
    class DataclassUnion(TestDataclass):
        foo: typing.Union[TestDataclass, str]

    class DataclassSchema(Schema):
        foo = _UnionField(
            desc={
                TestDataclass: None,
                str: fields.Str()
            },
            cls=DataclassUnion,
            field=dc_fields(DataclassUnion)[0],
        )

    obj = DataclassUnion(foo="bar")
    s = DataclassSchema()
    assert s.dump(obj) == {
        "foo": "bar"
    }



# Generated at 2022-06-23 16:54:26.396302
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow as ma
    from typing import Union, Optional
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str

    @dataclass
    class Employee:
        employee_id: int

    @dataclass
    class PersonOrEmployee:
        x: Union[Person, Employee]

    class PersonSchema(ma.Schema):
        name = fields.String()

        @post_load
        def make_person(self, data, **kwargs):
            return Person(**data)

    class EmployeeSchema(ma.Schema):
        employee_id = fields.Integer()

        @post_load
        def make_employee(self, data, **kwargs):
            return Employee(**data)


# Generated at 2022-06-23 16:54:33.449761
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    instance: SchemaF[str] = SchemaF()
    assert isinstance(
        instance.loads('"foobar"', many=False), str)  # type: ignore
    assert isinstance(
        instance.loads('["foobar"]', many=True), typing.List[str])  # type: ignore
    assert isinstance(
        instance.loads(b'"foobar"', many=False), str)  # type: ignore
    assert isinstance(
        instance.loads(b'["foobar"]', many=True), typing.List[str])  # type: ignore



# Generated at 2022-06-23 16:54:38.882913
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    field.name = 'hello'
    value = datetime.now()
    assert field.serialize(value) == value.timestamp()
    assert field.validate(value.timestamp()) == value.timestamp()
    assert field.deserialize(value.timestamp()) == _timestamp_to_dt_aware(value.timestamp())



# Generated at 2022-06-23 16:54:48.578985
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(1970,1,1), "a", 1, a=2) == 0
    assert _TimestampField()._deserialize(10000000000, "b", 2, b=3) == datetime(2001,9,9,1,46,40)
    assert _TimestampField()._serialize(None, "c", 3, c=4) == None
    assert _TimestampField()._deserialize(None, "d", 4, d=5) == None



# Generated at 2022-06-23 16:54:54.641961
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestClass1(typing.Generic[A], SchemaF):
        pass
    class TestClass2(typing.Generic[A], SchemaF):
        pass

    assert(issubclass(TestClass1, Schema))
    assert(issubclass(TestClass2, Schema))

# Generated at 2022-06-23 16:55:06.905717
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields, Schema

    def inner(type_, options):
        if _is_new_type(type_):
            type_ = type_.__supertype__
        if _issubclass_safe(type_, User):
            options['field_many'] = bool(
                _is_supported_generic(field.type) and _is_collection(
                    field.type))
            return fields.Nested(type_.schema(), **options)

        origin = getattr(type_, '__origin__', type_)
        args = [inner(a, {}) for a in getattr(type_, '__args__', []) if
                a is not type(None)]

        if _is_optional(type_):
            options["allow_none"] = True

        if origin in TYPES:
            return TY