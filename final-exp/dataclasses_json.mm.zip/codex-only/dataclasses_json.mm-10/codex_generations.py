

# Generated at 2022-06-23 16:45:01.194022
# Unit test for function build_schema
def test_build_schema():
    assert build_schema(User, None, True, None)

if __name__ == '__main__':
    test_build_schema()

# Generated at 2022-06-23 16:45:09.372820
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Check _TimestampField works correctly
    _Time_instance = datetime(2020, 1, 1)
    _Time_instance_serialized = _Time_instance.timestamp()
    assert _Time_instance == _timestamp_to_dt_aware(_Time_instance_serialized)

    # Check _IsoField works correctly
    _Time_instance_serialized_IsoField = _IsoField()._serialize(_Time_instance, None, None, None)
    _Time_instance_serialized_IsoField_2 = _Time_instance.isoformat()
    assert _Time_instance_serialized_IsoField == _Time_instance_serialized_IsoField_2

# Generated at 2022-06-23 16:45:15.671480
# Unit test for function schema
def test_schema():
    from dataclasses_json import DataClassJsonMixin
    from dataclasses import dataclass

    @dataclass
    class D(DataClassJsonMixin):
        str_name: str
        ...
    assert schema(D, D, False) == {}

    @dataclass
    class D(DataClassJsonMixin):
        str_name: str
        ...

        class Config:
            mm_field = fields.Int()

    assert schema(D, D, False) == {'str_name': fields.Int()}



# Generated at 2022-06-23 16:45:21.833967
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    class Test(DataClassJsonMixin):
        name: str
        id: int
        drop: typing.Optional[str] = None
        another: typing.Optional[str] = None
        def __init__(self,*args,**kwargs):
            # args[0]=self
            args[0].name =args[1]
            args[0].id = args[2]
            # kwargs.update({'name':args[1],'id':args[2]})
            # super().__init__(*args,**kwargs)
    class Test_2(DataClassJsonMixin):
        name: str
        id: int
        drop: typing.Optional[str] = None

# Generated at 2022-06-23 16:45:23.870867
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class MySchema(SchemaF[int]):
        pass
    MySchema()



# Generated at 2022-06-23 16:45:32.299000
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    dt = datetime.utcnow()
    ts = dt.timestamp()
    assert _TimestampField(required=True)._deserialize(ts).replace(tzinfo=None) \
           == dt.replace(tzinfo=None)
    assert _TimestampField(required=False)._deserialize(ts) \
           == dt.replace(tzinfo=None)
    assert _TimestampField(required=False)._deserialize(None) == None
    try:
        _TimestampField(required=True)._deserialize(None) == None
    except ValidationError:
        pass
    try:
        _TimestampField(required=True)._serialize(None) == None
    except ValidationError:
        pass

# Generated at 2022-06-23 16:45:42.222282
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(None, "", "") is None
    assert _IsoField()._deserialize(None, "", "") is None

try:
    import numpy as np

    class NumpyArrayField(fields.Field):
        """
        This field assumes that the value is a 1-Dimension array.
        """
        def _serialize(self, value, attr, obj, **kwargs):
            return value.tolist()

        def _deserialize(self, value, attr, data, **kwargs):
            return np.array(value)
except ImportError:
    pass

_cached_schema_classes: typing.Dict[typing.Type, typing.Type[Schema]] = {}

# Generated at 2022-06-23 16:45:46.152682
# Unit test for constructor of class SchemaF
def test_SchemaF():
    """
    Tests the constructor for class SchemaF.
    This is needed to ensure the constructor is not used by mistake.

    Raises an exception if the constructor is used by mistake.
    """
    with pytest.raises(NotImplementedError):
        class ASchema(SchemaF[A]):
            pass



# Generated at 2022-06-23 16:45:51.764070
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    import marshmallow.exceptions
    class ExampleSchema(SchemaF[int]):
        pass

    with pytest.raises(marshmallow.exceptions.NotImplementedError):
        ExampleSchema() # type: ignore

    assert ExampleSchema.load(data=2) == 2



# Generated at 2022-06-23 16:46:00.530448
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    foos = [Foo(), Foo()]
    schema = FooSchema()
    assert isinstance(schema.dump(foos, many=True), list)
    assert isinstance(schema.dump(foos), list)
    assert isinstance(schema.dump(foos, many=False), dict)
    assert isinstance(schema.dump(foos[0], many=False), dict)
    assert isinstance(schema.dump(foos[0], many=True), dict)
    assert isinstance(schema.dump(foos[0]), dict)
    assert isinstance(schema.dump(foos[0], many=False), dict)

# Generated at 2022-06-23 16:46:01.922331
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()



# Generated at 2022-06-23 16:46:09.309615
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields as f, Schema
    class Foo(Schema):
        field = f.Int()

    dump = SchemaF[int].dump([1, 2], many=True)
    assert dump == [{'field': 1}, {'field': 2}]

    dump = SchemaF[int].dump(2, many=False)
    assert dump == {'field': 2}

# Generated at 2022-06-23 16:46:10.645965
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    pass


# Generated at 2022-06-23 16:46:17.739910
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from typing import Any, List
    from marshmallow import Schema as MS

    class Foo(MS):

        class Meta:
            fields = "__all__"

    f = Foo()
    assert isinstance(f, SchemaF[Any])
    assert isinstance(f, MS)

    class Bar(MS):

        class Meta:
            fields = "__all__"
            ordered = True

    b = Bar()
    assert isinstance(b, SchemaF[Any])
    assert not isinstance(b, MS)

    class Baz(MS):

        class Meta:
            fields = "__all__"

    x = Baz(unknown=EXCLUDE)
    assert isinstance(x, SchemaF[Any])
    assert not isinstance(x, MS)


# Generated at 2022-06-23 16:46:22.780759
# Unit test for function schema
def test_schema():
    from typing import Union
    from marshmallow import fields
    import dataclasses
    @dataclasses.dataclass()
    class Example:
        a: str
        b: Union[str, int]
    assert schema(Example, None, False) == {'a': fields.Str(), 'b': fields.Field()}


# Generated at 2022-06-23 16:46:29.652195
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from .utils import example_data_class, example_data_class_list
    schema = _MappingSchema.from_dataclass(example_data_class).schema
    assert schema.dump(example_data_class("foo", "bar")) == {"a": "foo", "b": "bar"}
    assert schema.dump(example_data_class_list("foo", "bar")) == [{"a": "foo", "b": "bar"}, {"a": "foo", "b": "bar"}]
    with pytest.raises(NotImplementedError):
        SchemaF()

# Generated at 2022-06-23 16:46:40.108470
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow
    import marshmallow.exceptions
    import marshmallow.main
    import marshmallow.schema
    import marshmallow.utils
    import typing
    import uuid

    class User:
        def __init__(self, user_id, email, active=True):
            self.id = user_id
            self.email = email
            self.active = active

    class UserSchema(Schema[User]):
        id = fields.Int()
        email = fields.Str()

    def test_encode(obj: User) -> str:
        u = User(1, 'Mick')
        value = UserSchema().dumps(u)
        assert value == '{"id": 1, "email": "Mick"}'


if sys.version_info < (3, 7):
    SchemaF = Sche

# Generated at 2022-06-23 16:46:45.741251
# Unit test for constructor of class _IsoField
def test__IsoField():
    i = _IsoField()
    assert i._serialize(datetime.fromisoformat("2019-01-01T12:00:00"), "foo", None) == datetime.fromisoformat("2019-01-01T12:00:00").isoformat()
    assert i._deserialize("2019-01-01T12:00:00", "foo", None) == datetime.fromisoformat("2019-01-01T12:00:00")


# Generated at 2022-06-23 16:46:47.645686
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.NamedTuple):
        a: int


    class F(SchemaF[Foo]):
        pass



# Generated at 2022-06-23 16:46:49.822049
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    load = SchemaF[str].loads
    dump = SchemaF[str].dump

    assert dump(["a", "b"]) == ["a", "b"]



# Generated at 2022-06-23 16:46:59.940988
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Request:
        ids: List[int]

    class RequestSchema(SchemaF[Request]):
        ids = fields.List(fields.Int())

    schema = RequestSchema()
    obj = Request([1, 2])
    obj_encoded = {'ids': [1, 2]}
    assert schema.dumps(obj) == obj_encoded
    assert schema.dump(obj) == obj_encoded


# Generated at 2022-06-23 16:47:10.981441
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional, List

    from marshmallow import Schema, fields
    from marshmallow_jsonapi import fields as ma_fields

    from dataclasses import dataclass

    @dataclass
    class B:
        b: str

    @dataclass
    class A:
        a: Optional[str]
        b: B
        c: List[B]
        d: Optional[B]

    class A_Schema(Schema):
        class Meta:
            type_ = "A"
            fields = ('id', 'a', 'b', 'c', 'd')

        id = ma_fields.String()
        a = fields.String()

        @ma_fields.Relationship(type_='B', schema_cls=B)
        def b(self, obj: A):
            return obj.b

       

# Generated at 2022-06-23 16:47:16.018775
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    dt = datetime.fromisoformat("2000-01-01T00:00:00+00:00")
    assert field._serialize(dt, 'attr', 'obj') == "2000-01-01T00:00:00+00:00"
    assert field._deserialize("2000-01-01T00:00:00+00:00", 'attr', 'data') == dt



# Generated at 2022-06-23 16:47:22.102436
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Dataclass(typing.Generic[A]):
        def __init__(self, value: A):
            self.value = value

        def __str__(self):
            return f"<Dataclass({self.__class__.__name__}) with value {self.value}>"

    class SchemaF_test(SchemaF[Dataclass[int]]):
        value = fields.Integer()

    @post_load
    def make_dc(self, data, **kwargs):
        return Dataclass(**data)

    schema_f = SchemaF_test(unknown="EXCLUDE", post_load=make_dc)
    dc = Dataclass(value=1)
    assert schema_f.dumps(dc) == '{"value":1}'

# Generated at 2022-06-23 16:47:31.262700
# Unit test for function schema
def test_schema():
    import datetime
    import typing
    import marshmallow
    import marshmallow_enum
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        s: str
        i: int
        f: float
        b: bool
        d: datetime.datetime
        u: typing.Union[int, str]

    assert isinstance(dataclasses_json.mm_schema(Test).fields['i'], marshmallow.fields.Integer)
    assert isinstance(dataclasses_json.mm_schema(Test).fields['s'], marshmallow.fields.String)
    assert isinstance(dataclasses_json.mm_schema(Test).fields['f'], marshmallow.fields.Float)

# Generated at 2022-06-23 16:47:40.996226
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json
    @dataclass
    class A:
        foo: int

    data: str = '[{"foo": 1}, {"foo": 2}]'
    schema: SchemaF[A] = SchemaF.from_dataclass(A)
    schema.loads(data)
    schema.loads(data, many=True)
    schema.loads(data, many=False)

# Generated at 2022-06-23 16:47:45.289368
# Unit test for function build_type
def test_build_type():
    assert isinstance(build_type(int, {}, None, None, None), fields.Int)
    assert isinstance(build_type(Decimal, {}, None, None, None), fields.Decimal)
    assert isinstance(build_type(typing.List[int], {}, None, None, None), fields.List)



# Generated at 2022-06-23 16:47:50.902970
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class Obj:
        f: int

    # pylint: disable=no-member
    assert isinstance(SchemaF[Obj](), SchemaF)
    assert isinstance(SchemaF[int](), SchemaF)

# Generated at 2022-06-23 16:48:02.613047
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        def __init__(self, foo):
            self.foo = foo

    class B:
        def __init__(self, bar):
            self.bar = bar

    class C:
        def __init__(self, f, b):
            self.f = f
            self.b = b

    class ASchema(Schema):
        foo = fields.Int()

    class BSchema(Schema):
        bar = fields.Float()

    class CSchema(Schema):
        b = fields.Nested(BSchema, dump_to='b', load_from='b')
        f = fields.Nested(ASchema, dump_to='f', load_from='f')


# Generated at 2022-06-23 16:48:14.799832
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.api import Schema, dumps
    from typing import NamedTuple

    class Person(NamedTuple):
        name: str
        age: int

    @Schema
    class PersonSchema:
        name = fields.Str()
        age = fields.Int()

    def test_SchemaF_dumps(s: str):
        # the following lines should be Without error
        dumps(PersonSchema(), Person('Jack', 20))
        dumps(PersonSchema(), [Person('Jack', 20)])
        PersonSchema().loads(s)
        PersonSchema().loads(s, many=True)
        # the following lines should be have error
        dumps(PersonSchema(), 123)
        dumps(PersonSchema(), '123')
        dumps(PersonSchema(), [123])
        PersonSchema().loads

# Generated at 2022-06-23 16:48:24.929443
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_test = fields.String()
    iso_test.validate("2017-12-01T19:16:48.884885+00:00") is True
    iso_test.validate("2017-12-01T19:16:48.884885+00:30") is False
    iso_test.validate("2017-12-01T19:16:48.884885+01:00") is True
    iso_test.validate("2017-12-01T19:16:48.884885+02:00") is True
    iso_test.validate("2017-12-01T19:16:48.884885+07:00") is True
    iso_test.validate("2017-12-01T19:46:48.884885+00:00") is True
    iso_

# Generated at 2022-06-23 16:48:34.240046
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info < (3, 7):
        return
    class Simple(typing.NamedTuple):
        a: int
        b: str

    schema = typing.cast(SchemaF[Simple], Schema)
    obj = Simple(a=2, b='xxx')
    data = schema.dump(obj)
    assert data['a'] == 2, f'Data should be {{"a": 2, "b": "xxx"}}'
    assert data['b'] == 'xxx', f'Data should be {{"a": 2, "b": "xxx"}}'

    data_list = [obj, obj]
    data = schema.dump(data_list)
    assert data[0]['a'] == 2, f'Data should be {{"a": 2, "b": "xxx"}}'

# Generated at 2022-06-23 16:48:45.321375
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing
    import enum
    class A(enum.IntEnum):
        A = 1
    @dataclasses.dataclass
    class B:
        a: int
        b: str
        c: A
        d: typing.List[int]
        e: typing.Optional[int]
        f: typing.List[typing.Optional[str]]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.List[typing.Optional[str]]]

    @dataclasses.dataclass
    class C():
        a: typing.Optional[B]
        b: typing.List[typing.Optional[B]]
        c: typing.Optional[typing.List[B]]
        d: typing.List[B]

# Generated at 2022-06-23 16:48:52.745693
# Unit test for function build_type
def test_build_type():
    print("Start testing build_type...")
    # Test for build_type (binomial tree)
    def generate_binomial_tree(height):
        if height == 1:
            return tree_node(1, None, None)
        else:
            return tree_node(height, generate_binomial_tree(height-1), generate_binomial_tree(height-1))
    class tree_node:
        def __init__(self, value, left, right):
            self.value = value
            self.left = left
            self.right = right

        def __repr__(self):
            if self.left is None and self.right is None:
                return '%d' % self.value
            return '%d(%s, %s)' % (self.value, self.left, self.right)

    tree

# Generated at 2022-06-23 16:49:02.989095
# Unit test for function build_type
def test_build_type():
    assert build_type(1, {}, object, object, object) is not None
    assert build_type(type(1), {}, object, object, object) is not None
    assert build_type(str, {}, object, object, object) is not None
    assert build_type([str], {}, object, object, object) is not None
    assert build_type(typing.Union[int, float], {}, object, object, object) is not None
    assert build_type(typing.Optional[int], {}, object, object, object) is not None
    assert build_type(typing.Union[int, typing.Optional[float]], {}, object, object, object) is not None
    from enum import Enum
    class TEST(Enum):
        pass

# Generated at 2022-06-23 16:49:10.237280
# Unit test for function build_type
def test_build_type():  # type: ignore
    from dataclasses import dataclass, field
    from marshmallow import ValidationError
    from datetime import date, time, date
    from decimal import Decimal
    from uuid import UUID

    @dataclass
    class MmTestMixin:
        mm_field: str

    @dataclass
    class TestDc(MmTestMixin):
        int_field: int
        str_field: str
        float_field: float
        bool_field: bool
        list_field: typing.List[int]
        dict_field: typing.Dict[str, int]
        lambda_field: typing.Callable[[int], int]
        optional_field: typing.Optional[int]
        any_field: typing.Any
        date_field: date
        time_field: time
       

# Generated at 2022-06-23 16:49:18.622397
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.mm import _Schema
    class test1(Enum):
        one=1
    class test2(Enum):
        two=2

    @dataclass_json
    @dataclass
    class test3:
        k: str = field(metadata={"mm_field": fields.Bool()})

    @dataclass_json
    @dataclass
    class test4:
        k: str = field(metadata={"mm_field": fields.Int()})

    @dataclass_json
    @dataclass
    class test5:
        k: str = field(metadata={"mm_field": fields.Field()})


# Generated at 2022-06-23 16:49:25.835296
# Unit test for function build_type
def test_build_type():
    import pytest
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Nested:
        name: str

    @dataclass
    class Test:
        str_field: str
        int_field: int
        nested_field: Nested
        list_field: List[str]

    schema = Schema.from_dataclass(Test)
    data = {
        'str_field': 'test',
        'int_field': 0,
        'nested_field': {'name': 'test'},
        'list_field': ['test'],
    }

    result = schema.load(data)
    assert result == data



# Generated at 2022-06-23 16:49:30.085635
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class X:
        pass

    class XSchema(Schema):
        pass

    t = SchemaF[X](XSchema())
    t.load({}) # E:

# Generated at 2022-06-23 16:49:32.985379
# Unit test for constructor of class _IsoField
def test__IsoField():
    if(isinstance(_IsoField(), fields.Field)):
        return True
    else:
        return False


# Generated at 2022-06-23 16:49:42.420643
# Unit test for function schema
def test_schema():
    from typing import Optional, List, Dict
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    # Union types
    @dataclass
    class TestUnion(DataClassJsonMixin):
        x: typing.Union[int, str, typing.List[int]]
    TestUnion.schema()

    @dataclass
    class TestUnionNested(DataClassJsonMixin):
        x: typing.Union[int, str, typing.List[int], typing.List[str]]
    TestUnionNested.schema()

    @dataclass
    class TestNestedUnion(DataClassJsonMixin):
        x: typing.Union[int, TestUnion]
    TestNestedUnion.schema()


# Generated at 2022-06-23 16:49:47.381639
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class UserSchema(SchemaF[User]):
        id: str = fields.Integer(dump_only=True)
        name: str = fields.String(required=True)
        email: str = fields.String(required=True)

    UserSchema().loads('''{"id":1,"name":"John","email":"john@example.com"}''')


# Generated at 2022-06-23 16:49:59.362114
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import config, dataclass_json
    from marshmallow import fields as mm_fields

    @dataclass_json
    @dataclass
    class MyType:
        f: int = 1
        g: str = 'string'

    @dataclass_json
    @dataclass
    class MyType1:
        f: int = 1
        g: str = 'string'

        @property
        def emp_name(self):
            return self.g.upper()

        def __post_init__(self):
            self.g.upper()

    @dataclass_json
    @dataclass
    class MyDataClass:
        a: int = 1
        b: str = 'string'
        c: typing.Any = None
       

# Generated at 2022-06-23 16:50:01.447375
# Unit test for constructor of class SchemaF
def test_SchemaF():
    s = SchemaF[int]()
    assert 0 == s.loads('0')
    assert [1, 2, 3] == s.loads('[1, 2, 3]')



# Generated at 2022-06-23 16:50:06.401616
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    @dataclass_json
    @dataclass
    class ObjTest:
        n: int
        str_: str

    obj_test = ObjTest(10, 'Hello world!')
    schema = SchemaF[ObjTest]()
    json_str = schema.dumps(obj_test)
    out = schema.loads(json_str)
    assert out == obj_test



# Generated at 2022-06-23 16:50:17.725737
# Unit test for function build_type
def test_build_type():
    from .samples import (AliasModel, ListAliasModel, DictAliasModel,
                          TupleAliasModel)
    from dataclasses import dataclass, field
    from marshmallow import fields, post_load
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class TestSchema(DataClassJsonMixin):
        a: AliasModel

    @dataclass
    class TestListSchema(DataClassJsonMixin):
        a: List[AliasModel]

    @dataclass
    class TestDictSchema(DataClassJsonMixin):
        a: Dict[str, AliasModel]

    @dataclass
    class TestTupleSchema(DataClassJsonMixin):
        a: Tuple[AliasModel, AliasModel]


# Generated at 2022-06-23 16:50:26.447582
# Unit test for method loads of class SchemaF
def test_SchemaF_loads(): # type: ignore
    class Foo:
        pass
    class SchemaFoo(SchemaF[Foo]):
        pass
    s = SchemaFoo()
    data: typing.Dict[str, typing.Any] = {}
    s.loads(data)
    data: typing.List[typing.Dict[str, typing.Any]] = []
    s.loads(data)

# Generated at 2022-06-23 16:50:37.966803
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import TypeVar

    from marshmallow import fields, Schema, post_load

    from dataclasses import dataclass

    A = TypeVar('A')

    @dataclass
    class Foo:
        bar: str
        baz: str

    @dataclass
    class Bar:
        foo: Foo
        baz: str

    class FooSchema(Schema[Foo]):  # type: ignore
        bar = fields.String()
        baz = fields.String()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    class BarSchema(Schema[Bar]):
        foo = fields.Nested(FooSchema)
        baz = fields.String()


# Generated at 2022-06-23 16:50:48.336419
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json
    @dataclass
    class Test:
        i: int

    SchemaF[Test]

if sys.version_info >= (3, 8):
    class SchemaF(Schema, typing.Generic[A], _ExtendedEncoder,
                  _user_overrides_or_exts):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """
            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-23 16:50:57.555102
# Unit test for constructor of class _UnionField
def test__UnionField():
    class A:
        pass
    class B:
        pass
    class C:
        pass

    class D(A):
        pass

    @dataclass
    class Test:
        field: typing.Union[A, typing.List[B], C]
    schema = TestSchema.from_dataclass(Test)()
    field = schema.declared_fields['field']
    assert isinstance(field, _UnionField)
    assert field.desc == {
        A: A.__name__ + 'Schema',
        typing.List[B]: 'List' + B.__name__ + 'Schema',
        C: C.__name__ + 'Schema'
    }
    assert field.decimal_places == 2
    assert field.rounding == 'ROUND_HALF_EVEN'
    assert field

# Generated at 2022-06-23 16:50:59.692108
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert (
        isinstance(_IsoField(missing=MISSING), _IsoField)
    )


# Generated at 2022-06-23 16:51:07.259214
# Unit test for function schema
def test_schema():
    from dataclasses_json.test import m_test
    @m_test
    class Test:
        word: str
        number: int
        word_number: typing.Union[str, int]
        color: Enum = Enum.RED
        colors: typing.List[Enum] = [Enum.BLUE]
        color_optional: typing.Optional[Enum] = Enum.GREEN
        colors_optional: typing.List[typing.Optional[Enum]] = [
            Enum.YELLOW, None]
        colors_union: typing.List[
            typing.Union[Enum, typing.Optional[Enum]]] = [Enum.RED, None]

# Generated at 2022-06-23 16:51:12.928482
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    f.deserialize(1424911405.98893)  # datetime.datetime(2015, 2, 24, 19, 16, 45, 988926)
    f.serialize(datetime(2015, 2, 24, 19, 16, 45, 988926))  # 1424911405.98893



# Generated at 2022-06-23 16:51:15.155157
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        _IsoField()
    except:
        assert False, 'Creation of _IsoField failed'


# Generated at 2022-06-23 16:51:28.258917
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List, Dict

    class MyField(fields.Field):
        def _serialize(self, value: A, attr, obj, *args, **kwargs):
            pass

        def _deserialize(self, value: A, attr, data, *args, **kwargs):
            pass

    class MySchemaF(SchemaF[A]):
        f1: MyField = MyField()

    assert isinstance(MySchemaF.load([]), List)
    assert isinstance(MySchemaF.load({}, many=True), List)

    assert isinstance(MySchemaF.load({}), Dict)
    assert isinstance(MySchemaF.load([], many=False), Dict)

    class Example:
        pass


# Generated at 2022-06-23 16:51:37.718332
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[A]):
        pass
    MySchema.loads('')
    MySchema.loads(b'')
    MySchema.loads([{}])
    MySchema.loads('', many=True)
    MySchema.loads(b'', many=True)
    MySchema.loads([{}], many=True)
    MySchema.loads('', many=False)
    MySchema.loads(b'', many=False)
    MySchema.loads([{}], many=False)



# Generated at 2022-06-23 16:51:47.109220
# Unit test for function schema
def test_schema():
    import pytest

    @dataclasses.dataclass
    class C(object):  # type: ignore
        a: int
        b: typing.Optional[int]
        c: typing.Optional[typing.Union[typing.List[int], int]]

    @dataclasses.dataclass(frozen=True)
    class D(object):
        d: typing.Any
        e: typing.Any
        f: typing.Any

    from marshmallow.exceptions import ValidationError

    @dataclasses.dataclass
    class E(object):
        g: C

    r = schema(C, None, False)
    assert r['a'].deserialize('12') == 12
    assert r['b'].deserialize('13') == 13

# Generated at 2022-06-23 16:52:01.250649
# Unit test for function build_schema

# Generated at 2022-06-23 16:52:12.189444
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().deserialize("2020-07-10T14:00:33.495174") == datetime.fromisoformat("2020-07-10T14:00:33.495174")
    assert _IsoField().deserialize("2020-07-10") == datetime.fromisoformat("2020-07-10")
    assert _IsoField().deserialize("2020-07") == datetime.fromisoformat("2020-07")
    assert _IsoField().deserialize("2020") == datetime.fromisoformat("2020")
    assert _IsoField().deserialize("20200710T140033.495174") == datetime.fromisoformat("20200710T140033.495174")

# Generated at 2022-06-23 16:52:19.693609
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields, Schema
    from typing import List, Union

    class Foo:  # type: ignore
        _a: str
        _b: int

    class FooSchema(Schema):
        a = fields.Str()

    class Bar:  # type: ignore
        _a: int
        _b: int

    class BarSchema(Schema):
        a = fields.Int()

    class Item:
        _a: Union[Foo, Bar]

    class ItemSchema(SchemaF[Item]):
        a = fields.Nested('FooSchema' if isinstance(Foo, type) else FooSchema)

    foo = Foo('foo', 1)
    bar = Bar(10, 1)

    item = Item(foo)

# Generated at 2022-06-23 16:52:22.206670
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    fld = _TimestampField()
    assert fld


# Generated at 2022-06-23 16:52:26.780716
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = fields.Field(attribute='test_attr')
    assert field._serialize('test_attr', True) == 'test_attr'
    assert field._deserialize('test_attr', True) == 'test_attr'



# Generated at 2022-06-23 16:52:28.105281
# Unit test for constructor of class _UnionField
def test__UnionField():
    global _UnionField



# Generated at 2022-06-23 16:52:37.339132
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.codec import json_dumps
    from mypy_extensions import TypedDict

    class MyClass(TypedDict):
        a: str
        b: int

    class MySchema(SchemaF[MyClass]):
        a = fields.String()
        b = fields.Integer()

    data = MyClass(a='str', b=15)
    string = json_dumps(data, cls=MySchema)
    assert string == '{"a": "str", "b": 15}'


# Generated at 2022-06-23 16:52:39.479735
# Unit test for function schema
def test_schema():
    assert schema(TypeError, '_', False) == {}



# Generated at 2022-06-23 16:52:50.518464
# Unit test for constructor of class SchemaF
def test_SchemaF():
    o = object()
    s = SchemaF[object]()
    assert isinstance(s, SchemaF)
    s.dump(o)  # type: ignore

    s = SchemaF[object]()
    assert isinstance(s, SchemaF)
    s.dump([o])  # type: ignore

    s = SchemaF[object]()
    assert isinstance(s, SchemaF)
    s.dumps(o)  # type: ignore

    s = SchemaF[object]()
    assert isinstance(s, SchemaF)
    s.dumps([o])  # type: ignore

    s = SchemaF[object]()
    assert isinstance(s, SchemaF)
    s.load({'o': 1})  # type: ignore


# Generated at 2022-06-23 16:52:54.662265
# Unit test for function build_schema
def test_build_schema():
    class Test:
        i: int
        s: str
        b: bool

    test = TestSchema().load({})
    assert isinstance(test, Test)
    assert test.i == 0
    assert isinstance(test.i, int)
    assert test.s is None
    assert isinstance(test.s, str)
    assert test.b is None
    assert isinstance(test.b, bool)



# Generated at 2022-06-23 16:53:03.340764
# Unit test for function build_schema
def test_build_schema():
    cls = build_schema(Person, mixin=object, infer_missing=False, partial=False)
    assert cls.__name__ == 'PersonSchema'
    assert hasattr(cls, 'Meta')
    assert hasattr(cls, 'make_person')
    assert hasattr(cls, 'validate')
    assert hasattr(cls, 'dumps')
    assert hasattr(cls, 'dump')
    assert hasattr(cls, 'load')
    assert hasattr(cls, 'loads')
    assert hasattr(cls, 'name')
    assert type(cls.dump) is types.MethodType
    assert type(cls.dumps) is types.MethodType
    assert type(cls.load) is types.MethodType
    assert type(cls.loads) is types

# Generated at 2022-06-23 16:53:14.761774
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # verification of typing.overload
    assert SchemaF[int].loads('[{"field": 1}]') == [{"field": 1}]
    assert SchemaF[int].loads(b'[{"field": 1}]') == [{"field": 1}]
    assert SchemaF[int].loads(bytearray('[{"field": 1}]', 'utf-8')) == [{"field": 1}]
    assert SchemaF[int].loads('[{"field": 1}]', many=True) == [{"field": 1}]
    assert SchemaF[int].loads('[{"field": 1}]') == [{"field": 1}]
    assert SchemaF[int].loads('{"field": 1}') == {"field": 1}

# Generated at 2022-06-23 16:53:22.192634
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.NamedTuple):
        f1: str


    class FooSchema(SchemaF[Foo]):
        f1 = fields.Str()

    f = Foo("foo")

    res = FooSchema().load({"f1": "foo"})
    # mypy doesn't like that load returns a Foo but FooSchema() is an instance of SchemaF[Foo]
    # see https://github.com/python/mypy/issues/7185
    res2 = FooSchema().dump(f)  # type: ignore


# Generated at 2022-06-23 16:53:30.695955
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class A: pass

    class B: pass

    class SchemaA(SchemaF[A]):
        pass

    class SchemaAB(SchemaF[typing.Union[A, B]]):
        pass

    a = A()
    b = B()

    a1 = A()
    a2 = A()

    b1 = B()
    b2 = B()

    try:
        SchemaA()
        assert False
    except NotImplementedError:
        pass

    try:
        SchemaAB()
        assert False
    except NotImplementedError:
        pass

    # dump
    assert SchemaAB().dump([a, b]) == [{}, {}]
    assert SchemaAB().dump(a) == {}

# Generated at 2022-06-23 16:53:41.140910
# Unit test for function build_schema
def test_build_schema():
    from . import dataclass_json
    from .dataclasses_ import make_dataclass

    @dataclass_json(letter_case=LetterCase.CAMEL)
    class Simple:
        name: str
        id: int = 123

    # We will create a class `User` and then a schema for it
    User = make_dataclass(name='User',
                          fields=[('name', str),
                                  ('id', int, 123)],
                          bases=(),
                          namespace={})

    # Now, we need to create the classes needed by the function build_schema
    # this is needed because the function itself is not visible
    class Meta:
        fields = ('name', 'id')

    class make_user:
        pass


# Generated at 2022-06-23 16:53:49.222751
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    import pytest
    from marshmallow import Schema, fields
    
    @dataclass_json
    @dataclass
    class Inside:
        x: str
        y: int
        def __post_init__(self) -> None:
            pass
    
    @dataclass_json
    @dataclass
    class Test:
        a: int = 1
        b: str = 'abc'
        c: Inside = field(default_factory=lambda: Inside('x', 1))
        d: typing.List[Inside] = field(default_factory=lambda: [Inside('x', 1)])

# Generated at 2022-06-23 16:53:54.576904
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    import marshmallow as ma
    import marshmallow_enum as me
    from marshmallow_enum import EnumField
    import uuid

    @dataclass
    class Child:
        name: str
        num: int

    class Color(Enum):
        RED = 'red'
        GREEN = 'green'
        BLUE = 'blue'

    @dataclass
    class Parent:
        child: Child
        color: Color
        pi: float
        utime: datetime
        uuid: uuid.UUID

    class ChildSchema(ma.Schema):
        name = ma.fields.Str()
        num = ma.fields.Int()

    ColorField = me.EnumField(Color, by_value=True)


# Generated at 2022-06-23 16:54:05.123546
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    class Foo(typing.Generic[A], SchemaF[A]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-23 16:54:13.690873
# Unit test for constructor of class _UnionField
def test__UnionField():
    assert _UnionField(
        {int: fields.Field},
        type('t', (), {}),
        type('f', (), {})
    ).desc == {int: fields.Field}
    assert _UnionField(
        {int: fields.Field},
        type('t', (), {}),
        type('f', (), {})
    ).cls == type('t', (), {})
    assert _UnionField(
        {int: fields.Field},
        type('t', (), {}),
        type('f', (), {})
    ).field == type('f', (), {})



# Generated at 2022-06-23 16:54:21.343835
# Unit test for function build_type
def test_build_type():
    obj = build_type(typing.Mapping, {}, None, None, None)
    assert obj == fields.Mapping
    obj = build_type(typing.MutableMapping, {}, None, None, None)
    assert obj == fields.Mapping
    obj = build_type(typing.List, {}, None, None, None)
    assert obj == fields.List
    obj = build_type(typing.Dict, {}, None, None, None)
    assert obj == fields.Dict
    obj = build_type(typing.Tuple, {}, None, None, None)
    assert obj == fields.Tuple
    obj = build_type(typing.Callable, {}, None, None, None)
    assert obj == fields.Function

# Generated at 2022-06-23 16:54:27.185321
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    data: TEncoded = {"some": "value"}
    assert SchemaF[int].load(data) == 0

    data: typing.List[TEncoded] = [{"some": "value"}, {"some": "value"}]
    assert SchemaF[int].load(data) == [0, 0]



# Generated at 2022-06-23 16:54:38.234222
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class Nested:
        i: int = 3

    @dataclass
    class Dc:
        t: List[Nested]

    schema = build_schema(Dc, None, True, True)
    sn = schema().dump(Dc([Nested(i=1), Nested(i=2)]), many=True)
    assert sn[0]['i'] == 1
    assert sn[1]['i'] == 2

    sn = schema().dump(Dc([Nested()]))
    assert sn['t'][0]['i'] == 3


####################
# Helper functions #
####################



# Generated at 2022-06-23 16:54:44.388345
# Unit test for function schema
def test_schema():
    # unit tests
    class A(typing.Generic[A]):
        pass
    A = SchemaF[A]

    dataclass_json(unknown=EXCLUDE)
    @dataclass
    class SchemaTest():

        a = mm_field(A, missing=None)



# Generated at 2022-06-23 16:54:52.662898
# Unit test for constructor of class _TimestampField
def test__TimestampField(): # pragma: no cover
    dec_time = _TimestampField()._deserialize(1559497545)
    assert dec_time == datetime(2019, 5, 31, 18, 39, 5, tzinfo=datetime.utcfromtimestamp(1559497545).tzinfo)
    ser_time = _TimestampField()._serialize(datetime(2019, 5, 31, 18, 39, 5, tzinfo=datetime.utcfromtimestamp(1559497545).tzinfo))
    assert ser_time == 1559497545



# Generated at 2022-06-23 16:55:05.517016
# Unit test for function build_type
def test_build_type():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class Foo:
        pass

    expected_options = {'required': True}

    # Test that origin is returned with args in case of new type
    @dataclass
    class Bar:
        x: typing.NewType("Bar", float)
        y: float

    expected_options_x = expected_options.copy()
    expected_options_x.update({'allow_none': True})
    expected_options_y = expected_options.copy()

    assert build_type(Bar.__annotations__['x'], expected_options_x, Foo,
                      Bar.__dataclass_fields__['x'], Bar) == fields.Float(
        *[fields.Float()], **expected_options_x)