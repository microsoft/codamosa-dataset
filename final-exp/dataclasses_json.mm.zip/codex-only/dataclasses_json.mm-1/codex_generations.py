

# Generated at 2022-06-23 16:45:00.898058
# Unit test for function build_type
def test_build_type():
    assert build_type(None, {}, None, None, None) == fields.Field()



# Generated at 2022-06-23 16:45:07.498651
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field

    @dataclass()
    class A:
        a: int
        b: str = 'b1'
        c: typing.Optional[str] = field(default=None)
        d: typing.List[int] = field(default_factory=dict)
        e: typing.List[str] = field(default_factory=lambda: ['1'])
        f: typing.Dict[str, str] = field(default_factory=lambda: {'1': '1'})
        # catch_all: CatchAllVar = field(default_factory=dict)

    print(build_schema(A, mixin=None, infer_missing=True, partial=False))

# Generated at 2022-06-23 16:45:11.226480
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema

    class Foo(SchemaF[A]):
        def dump(self, obj, many=None):
            assert isinstance(obj, list)

    Foo().dump([1, 2, 3])



# Generated at 2022-06-23 16:45:19.831095
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from json import dumps as json_dumps  # type: ignore
    from dataclasses import dataclass, field
    from typing import ClassVar, Type
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    @dataclass
    class Nested:
        one: int

    s = SchemaF[Nested]

    assert s.dumps({'one': 1}) == json_dumps({'one': 1})
    assert s.dumps([{'one': 1}, {'one': 2}, {'one': 3}]) == json_dumps([{'one': 1}, {'one': 2}, {'one': 3}])

    @dataclass
    class Foo:
        one: int
        two: str = 'def'

    s = SchemaF[Foo]


# Generated at 2022-06-23 16:45:23.554127
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    result = (SchemaF.load(TOneOrMultiEncoded, TOneOrMulti)  # type: ignore
    )  # type: ignore



# Generated at 2022-06-23 16:45:31.003752
# Unit test for function build_type
def test_build_type():
    schema_type: SchemaType

    class A:
        pass

    class B:
        def __init__(self, *args):
            self.args = args

    AEnum = Enum('AEnum', [('A', A()), ('B', B(1, '2', 3))])
    Nested = typing.NewType('Nested', A)
    NestedEnum = typing.NewType('NestedEnum', AEnum)
    Union = typing.Union[A]
    EnumUnion = typing.Union[AEnum]
    EnumNewUnion = typing.Union[NestedEnum]
    NewUnion = typing.Union[Nested]
    Optional = typing.Optional[A]
    NewOptional = typing.Optional[Nested]
    EnumOptional = typing.Optional[AEnum]
   

# Generated at 2022-06-23 16:45:36.734492
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    with pytest.raises(ValidationError):
        field.deserialize(MISSING)
    with pytest.raises(ValidationError):
        field.deserialize(MISSING, missing=MISSING)


# Generated at 2022-06-23 16:45:46.843472
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(typing.NamedTuple):
        a: Decimal

    class B(typing.NamedTuple):
        b: str

    class AB(typing.NamedTuple):
        a_b: typing.Union[A, B]

    _: typing.Union[A, B] = AB(A(a=Decimal(1))).a_b

    class ABT(typing.NamedTuple):
        a_b: typing.Tuple[A, B]

    _: typing.List[typing.Union[A, B]] = ABT(A(a=Decimal(1)), B(b='1')).a_b

    class ABC(typing.NamedTuple):
        a_b_c: typing.Dict[str, A]


# Generated at 2022-06-23 16:45:49.276728
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    expected: str = ""
    actual: str = SchemaF(int).dumps(1)
    assert actual == expected



# Generated at 2022-06-23 16:45:58.196901
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Person:
        name: str
        age: int = 0
        pet: Optional[Pet] = None
        contact: List[Contact] = field(default_factory=list)

    @dataclass
    class Pet:
        name: str = "N/A"

    @dataclass
    class Contact:
        name: str
        phone: int

    p = Person("John", 34,
               Pet("Tom"),
               [Contact("Jim", "123"), Contact("Sara", "456")])
    p_schema = build_schema(Person, None, False, False)()
    dumped = p_schema.dump(p)
    assert dumped['name'] == "John"
    assert dumped['age'] == 34
    assert dumped['pet']['name'] == "Tom"
   

# Generated at 2022-06-23 16:46:04.793697
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Point(typing.Protocol):
        x: int

    class PointF(SchemaF[typing.Type[Point]]):
        x = fields.Int()

    assert PointF().load({'x': 2}) == PointF().load({'x': 2}, many=False)
    assert PointF().load([{'x': 2}, {'x': 3}]) == PointF().load([{'x': 2}, {'x': 3}], many=True)



# Generated at 2022-06-23 16:46:09.483572
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Test(SchemaF[str]):
        test = fields.String()

    assert Test().load({"test": "test"}) == "test"
    assert Test().load([{"test": "test"}]) == ["test"]

# Generated at 2022-06-23 16:46:17.418593
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass
    class Bar:
        pass

    class MySchema(Schema, typing.Generic[A]):
        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass

    # Example for this method: https://marshmallow.readthedocs.io/en/stable/api_reference.html#

# Generated at 2022-06-23 16:46:22.911739
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    p = Person("John Doe", 21)
    p_ = Person("John Doe", 21)
    ps = [p, p_]

    schema = SchemaF[Person]()
    assert schema.dumps(p) == schema.dumps(ps)[1:-1]



# Generated at 2022-06-23 16:46:30.831861
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def f1() -> typing.List[str]: ...
    def f2() -> A: ...
    result = f1()
    result = f2()


# Generated at 2022-06-23 16:46:41.483069
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    import unittest
    import dataclasses
    import marshmallow

    from dataclasses_json.marshmallow_schemas import _TimestampField

    @dataclasses.dataclass
    class MyClass:
        dt: datetime
        dt_option: datetime = None

    class MySchema(marshmallow.Schema):
        dt = _TimestampField()
        dt_option = _TimestampField(required=False)

    my_schema = MySchema()

    my_class = MyClass(datetime(2000, 10, 15, 20, 30, 40))
    json1 = my_schema.dumps(my_class)
    my_class1 = my_schema.loads(json1)
    assert my_class == my_class1


# Generated at 2022-06-23 16:46:45.355951
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), "attr", None) == "2020-01-01T00:00:00"
    with pytest.raises(ValidationError):
        field._serialize(None, "attr", None)
    assert field._deserialize("2020-01-01T00:00:00", "attr", None) == datetime(2020, 1, 1)
    with pytest.raises(ValidationError):
        field._deserialize(None, "attr", None)



# Generated at 2022-06-23 16:46:53.247584
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from marshmallow import Schema
    from marshmallow.fields import Str

    class A(SchemaF):
        x: str

        class Meta:
            fields = ('x',)

    assert A.dumps(List[A](A(x='test'))) == '[{"x": "test"}]'
    assert A.dumps(A(x='test')) == '{"x": "test"}'

    with pytest.raises(TypeError):
        A.dumps(List[Schema](A(x='test')))

    with pytest.raises(TypeError):
        A.dumps(A(x='test'), many=True)

    with pytest.raises(TypeError):
        A.dumps(A(x='test'), **{'many': True})


# Generated at 2022-06-23 16:46:54.543097
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField() # noqa: F841
    return



# Generated at 2022-06-23 16:47:00.798207
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[TEncoded]):
        pass

    data = {'key': 'value'}
    t = TestSchema()
    t.dump(data)
    t.dump([data, data])
    t.dump(data, many=True)
    t.dump(data, many=False)



# Generated at 2022-06-23 16:47:08.291893
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    if sys.version_info >= (3, 7):
        class TestSchema(SchemaF[int]):
            pass
        assert TestSchema().dumps([1, 2, 3]) == "[1, 2, 3]"
        assert TestSchema().dumps(1) == "1"
        assert TestSchema().dump([1, 2, 3]) == [1, 2, 3]
        assert TestSchema().dump(1) == 1


# Generated at 2022-06-23 16:47:17.108465
# Unit test for function build_type
def test_build_type():
    # pd.DataFrame is not a dataclass
    assert type(build_type(pd.DataFrame, {}, None, None, None)) == fields.Field
    assert type(build_type(Decimal, {}, None, None, None)) == fields.Decimal
    assert type(build_type(CatchAllVar, {}, None, None, None)) == fields.Dict
    assert type(build_type(datetime, {}, None, None, None)) == _TimestampField
    assert type(build_type(dict(), {}, None, None, None)) == fields.Dict
    assert type(build_type(list, {}, None, None, None)) == fields.List
    assert type(build_type(str, {}, None, None, None)) == fields.Str

# Generated at 2022-06-23 16:47:23.371622
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    """
    Type-checks the method loads of SchemaF

    """
    SchemaF.loads("{}", many=None, cls_or_instance=None, unknown="None")  # type: ignore
    SchemaF.loads("{}", many=False, cls_or_instance=None, unknown="None")  # type: ignore
    SchemaF.loads("{}", many=True, cls_or_instance=None, unknown="None")  # type: ignore
    SchemaF.loads(b"{}", many=False, cls_or_instance=None, unknown="None")  # type: ignore
    SchemaF.loads(b"{}", many=True, cls_or_instance=None, unknown="None")  # type: ignore



# Generated at 2022-06-23 16:47:25.976034
# Unit test for constructor of class _UnionField
def test__UnionField():
    test_obj = _UnionField('', '', None)
    expected_result = fields.Field
    assert(type(test_obj) == expected_result)




# Generated at 2022-06-23 16:47:30.376965
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
        raise ValueError('No exception in constructor')
    except NotImplementedError:
        pass

    # Only test the methods here to make mypy happy
    # They behave the same as in each class
    SchemaF.load({})
    SchemaF.loads('')
    SchemaF.dump({})
    SchemaF.dumps({})



# Generated at 2022-06-23 16:47:40.207520
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow_dataclass
    import marshmallow

    @marshmallow_dataclass.dataclass
    class Dummy:
        id: str
        value: int

    s = SchemaF[Dummy].from_dataclass(Dummy)
    print(s.dumps([Dummy('a', 1)]))
    print(s.dumps(Dummy('a', 1)))
    print(s.dumps([Dummy('a', 1)]))
    print(s.dumps(Dummy('a', 1)))

# Generated at 2022-06-23 16:47:49.074728
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    @dataclass
    class B:
        x: int
        y: int

    A_schema = SchemaF[A](type_=A)
    B_schema = SchemaF[B](type_=B)

    assert A_schema.dump([A(2), A(3)]) == [{'x': 2}, {'x': 3}]
    assert A_schema.dump(A(2)) == {'x': 2}

    assert A_schema.dumps([A(2), A(3)]) == '[{"x": 2}, {"x": 3}]'
    assert A_schema.dumps(A(2)) == '{"x": 2}'

    assert A_sche

# Generated at 2022-06-23 16:47:51.373274
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class Foo(typing.Generic[A]):
        pass
    s: SchemaF[Foo[int]] = SchemaF()



# Generated at 2022-06-23 16:47:56.581431
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    res = f._serialize(datetime(2018, 12, 12), "dummy", "dummy")
    assert res == 1544651200.0
    assert f._serialize(None, "dummy", "dummy") is None

    assert f._deserialize(1544651200.0, "dummy", "dummy") == datetime(2018, 12, 12)
    assert f._deserialize(None, "dummy", "dummy") is None



# Generated at 2022-06-23 16:48:00.654628
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Bar():
        def __init__(self, x):
            self.x = x
    class FooSchema(SchemaF[Bar]):
        x = fields.Int()
    foo = Bar(3)
    assert FooSchema().dumps(foo) == '{"x": 3}'
    assert FooSchema().dumps([foo]) == '[{"x": 3}]'

# Generated at 2022-06-23 16:48:10.260578
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import mypy_extensions
    from marshmallow import fields as mm_fields
    class C(mypy_extensions.TypedDict):
        f1: int
    class A(mypy_extensions.TypedDict):
        f2: str
    class B(A, C):
        pass
    class D(SchemaF[B]):
        f2 = mm_fields.Str()
        f1 = mm_fields.Int()
    assert D().loads({"f1": 1, "f2": "f"}) == B(f2="f", f1=1)
    assert D().loads([{"f1": 1, "f2": "f"}]) == [B(f2="f", f1=1)]

# Generated at 2022-06-23 16:48:21.673358
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    """
    Test method load of class SchemaF
    """
    class _MyType(typing.Generic[A]):
        """Just a type to test method load of class SchemaF"""
        def _load(self):
            assert isinstance(self, type)
            AnySchema = typing.cast(type, self)  # type: ignore
            schema = AnySchema()
            if hasattr(schema, 'load'):
                return typing.cast(A, schema)  # type: ignore

    _MyType.__name__ = '_MyType'
    _MyType[A] = _MyType
    assert isinstance(_MyType, type)
    assert isinstance(_MyType[str](), _MyType[str])
    assert isinstance(_MyType[A], type)

# Generated at 2022-06-23 16:48:26.879702
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # noinspection PyTypeChecker
    SchemaF()


if sys.version_info < (3, 7):

    class SchemaF(Schema):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass


# Generated at 2022-06-23 16:48:36.141766
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm import MmOptions
    @dataclass_json
    @dataclass
    class A:
        a: int
    @dataclass_json
    @dataclass
    class B(A):
        b: int
    @dataclass_json
    @dataclass
    class C(B):
        c: str
    @dataclass_json
    @dataclass
    class D(C):
        d: bool
    mm_schema = schema(D, MmOptions, infer_missing=True)
    a = mm_schema['a']
    assert(a == fields.Int())
    b = mm_schema['b']
    assert(b == fields.Int())
    c = mm_schema['c']
    assert(c == fields.Str())

# Generated at 2022-06-23 16:48:37.465199
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-23 16:48:42.078347
# Unit test for function schema
def test_schema():
    class A:

        def __init__(self, a: typing.Optional[typing.List[int]],
                     b: typing.Optional[typing.Tuple[int, str, int]]):
            self.a = a
            self.b = b

    schema(A, mixin, False)



# Generated at 2022-06-23 16:48:43.435714
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass

# Generated at 2022-06-23 16:48:46.915167
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    d = datetime.fromisoformat('2012-04-01T16:00:00-05:00')
    assert f._deserialize('2012-04-01T16:00:00-05:00', 'a', 'b') == d


# Generated at 2022-06-23 16:48:59.192763
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Foo(typing.Generic[T]):
        def dumps(self, obj: typing.Sequence[T]):
            return obj

    def foo(obj: typing.Sequence[int]):
        pass

    foo(Foo[int]().dumps([1]))
    foo([1])



# Generated at 2022-06-23 16:49:10.318766
# Unit test for constructor of class _UnionField
def test__UnionField():
    field = _UnionField({
        bool: fields.Str,
        int: fields.Str,
        str: fields.Str
    }, None, None)

    res = field._serialize(False)
    assert res == 'False'
    res = field._serialize(1)
    assert res == '1'
    res = field._serialize('abc')
    assert res == 'abc'
    try:
        field._serialize(None)
        field.allow_none = True
        field._serialize(None)
    except ValidationError:
        assert False

    assert field._deserialize('False') is False
    assert field._deserialize('1') == 1
    assert field._deserialize('abc') == 'abc'

# Generated at 2022-06-23 16:49:13.248828
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(SchemaF):
        pass

    assert A().dump([]) == []  # type: ignore
    assert A().dump(None) == {}  # type: ignore



# Generated at 2022-06-23 16:49:23.586387
# Unit test for function schema
def test_schema():
    import marshmallow.fields as f

    class SimpleClass:
        x: int
        y: str = 'z'

    class ClassWithUnsupported:
        x: int
        y: typing.Set[int]

    class ClassWithUnion:
        x: typing.Union[str, int]

    class ClassWithNested:
        x: SimpleClass

    class ClassWithNestedDataclass:
        x: SimpleClass

    class ClassWithNestedEnum:
        x: typing.Optional[UserType]

    class UserType(Enum):
        guest = 1

    class ClassWithSet:
        x: typing.Set[str]

    class ClassWithOptionalSet:
        x: typing.Set[typing.Optional[str]]


# Generated at 2022-06-23 16:49:30.857267
# Unit test for function build_type
def test_build_type():
    class Post:
        pass

    class PostSchema(SchemaType):
        id = fields.Int()

        @post_load
        def make_object(self, data, **kwargs):
            return Post(**data)

    Post.schema = PostSchema

    class Comment:
        pass

    class CommentSchema(SchemaType):
        id = fields.Int()

        @post_load
        def make_object(self, data, **kwargs):
            return Comment(**data)

    Comment.schema = CommentSchema

    class PostUser:
        pass

    class PostUserSchema(SchemaType):
        id = fields.Int()
        name = fields.Str()

        @post_load
        def make_object(self, data, **kwargs):
            return PostUser(**data)



# Generated at 2022-06-23 16:49:37.808030
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Union

    class FakeSchema(SchemaF[Union[int, str]]):
        pass

    assert FakeSchema().dump(1) == 1  # type: ignore
    assert FakeSchema().dump('abc') == 'abc'  # type: ignore
    assert FakeSchema().dump([1]) == [1]  # type: ignore
    assert FakeSchema().dump([1, 'abc', 'cde']) == [1, 'abc', 'cde']  # type: ignore



# Generated at 2022-06-23 16:49:42.924257
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Doc:
        name: str

    class DocSchema(SchemaF[Doc]):
        name = fields.Str()

    doc = Doc('abc')
    doc_json = DocSchema().dump(doc)

    assert doc_json == {'name': 'abc'}



# Generated at 2022-06-23 16:49:46.888351
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Define test data
    data = {'a': 'value'}
    # Define class to test
    class F(SchemaF[A]):
        a = fields.String()
    # Define object to test
    obj = F().load(data)
    # Assert equal
    assert obj.a == 'value'

# Generated at 2022-06-23 16:49:59.054215
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        class X1(typing.NamedTuple):
            x: int

        class X2(typing.NamedTuple):
            x: str

        class TestSchema(SchemaF[typing.Union[X1, X2]]):
            """This is example of usage."""

            x = fields.Int()

        schema = TestSchema()

        t1 = schema.load({'x': 1})
        assert t1 == X1(x=1)

        t2 = schema.load({'x': 'a'})
        assert t2 == X2(x='a')

        def des(data):
            return schema.dump(schema.load(data))

        t3 = des({'x': 1})

# Generated at 2022-06-23 16:50:00.293266
# Unit test for constructor of class SchemaF
def test_SchemaF():
    assert SchemaF[dict].__orig_bases__ == (Schema,)



# Generated at 2022-06-23 16:50:01.024956
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass

# Generated at 2022-06-23 16:50:10.075060
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import ValidationError

    class MySchema(SchemaF[int]):
        foo = fields.Int(required=True)

    try:
        MySchema.loads('{"foo": "a"}')
    except ValidationError as e:
        assert e.field_names == {'foo'}
        assert e.exc.msg == 'Not a valid integer.'

    assert MySchema.loads('{"foo": 1}') == 1

    # The type annotation is ignored by mypy
    # (see https://github.com/python/mypy/issues/5485)
    # but it is not ignored by the IDE, which will warn us of a wrong annotation
    # when calling a constructor:
    #
    # >>> MySchemaF(Unknown)
    #
    # is valid, but the IDE will warn us that the

# Generated at 2022-06-23 16:50:21.159947
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import json
    import datetime
    class UserSchema(SchemaF[User]):
        id_int = fields.Integer(attribute='id')
        username = fields.Str()
        created_at = fields.DateTime(attribute='timestamp')
    u = User(1, 'foo', datetime.datetime.now())
    assert isinstance(UserSchema().dumps(u), str)
    assert u.id == 1
    assert u.name == 'foo'
    assert isinstance(u.timestamp, datetime.datetime)
    assert isinstance(json.loads(UserSchema().dumps(u)), dict)

if sys.version_info >= (3, 7):
    class MarshalF(typing.Generic[A]):
        """Lift Schema into a type constructor"""


# Generated at 2022-06-23 16:50:29.057530
# Unit test for function build_schema
def test_build_schema():
    from marshmallow.exceptions import ValidationError
    from marshmallow import fields
    from typing import Optional

    class MixedIn:
        def __init__(self):
            self.value = None

    @dataclass_json
    @dataclass
    class MyDataClass:
        value: str

    assert isinstance(build_schema(MyDataClass, None, None, None)().declared_fields['value'], fields.Str)



# Generated at 2022-06-23 16:50:38.118059
# Unit test for constructor of class SchemaF
def test_SchemaF():
    if sys.version_info >= (3, 7):
        class T1(typing.TypedDict, total=False):
            a: int

        class T2(typing.TypedDict, total=False):
            b: int

        T3 = typing.Union[T1, T2]

        @dataclass
        class T:
            a: T3

        class TestSchema(SchemaF[T]):
            pass

        assert TestSchema.__dict__['_declared_fields']['a'] == fields.Dict

    @dataclass
    class Test:
        x: typing.List[int]
        y: int

    class TestSchema(Schema):
        x = fields.List(fields.Int())
        y = fields.Int()

    m = TestSchema().dump

# Generated at 2022-06-23 16:50:38.780073
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass

# Generated at 2022-06-23 16:50:44.040393
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass
    class MyObject:
        pass

    schema = SchemaF[MyObject]  # type: ignore
    try:
        # should raise NotImplementedError because this class is helper only
        schema = SchemaF[MyObject]()  # type: ignore
        assert False
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:50:47.991689
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class User(SchemaF):
        name = fields.String()

    User.loads('{"name": "John"}')



# Generated at 2022-06-23 16:50:48.864810
# Unit test for constructor of class _UnionField
def test__UnionField():
    # TODO: Implement
    pass



# Generated at 2022-06-23 16:50:57.997232
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import Union
    from dataclasses_json import dataclass_json

    @dataclass(frozen=True)
    class A:
        a: int
        b: str

    @dataclass(frozen=True)
    class B:
        a: int
        b: str

    @dataclass(frozen=True)
    class C:
        a: Union[A, B]

    schema = dataclass_json.Schema.from_dataclass(C)
    assert isinstance(schema.declared_fields['a'], _UnionField)
    
    aschema = dataclass_json.Schema.from_dataclass(A)

# Generated at 2022-06-23 16:51:05.088940
# Unit test for constructor of class SchemaF
def test_SchemaF():
    # For test class with two schema fields
    @dataclasses.dataclass
    class A(SchemaF):
        a: int
        b: int

    @dataclasses.dataclass
    class B(A):
        c: int

    s = B(a=1, b=2, c=3)
    assert isinstance(s, B)
    s_serialized = s.dumps()
    assert isinstance(s_serialized, str)
    s_deserialized = s.loads(s_serialized)
    assert isinstance(s_deserialized, B)



# Generated at 2022-06-23 16:51:10.583545
# Unit test for function schema
def test_schema():
    import uuid
    class SchemaP(SchemaType):
        a = fields.UUID(data_key="b")
        b = fields.Int()
    assert isinstance(schema(SchemaP, Schema, False)["a"], fields.UUID)
    assert isinstance(schema(SchemaP, Schema, False)["b"], fields.Int)



# Generated at 2022-06-23 16:51:16.500069
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField.__init__.__annotations__ == {'self': _TimestampField, 'allow_none': bool, 'default': typing.Any, 'dump_only': bool, 'error': typing.Any, 'error_messages': typing.Any, 'load_only': bool, 'missing': typing.Any, 'required': bool, 'validate': typing.Any, 'validate_all': bool}


# Generated at 2022-06-23 16:51:23.736482
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    expected = datetime(2020, 8, 7, 1, 26, 49, 752863)
    assert _TimestampField()._deserialize(1596756009.752863) == expected
    assert _TimestampField()._deserialize(1596756009.752863) == _TimestampField()._serialize(expected)


# Generated at 2022-06-23 16:51:29.404609
# Unit test for constructor of class _UnionField
def test__UnionField():
    import datetime
    from dataclasses import dataclass

    class Color(Enum):
        red = 1
        green = 2
        blue = 3

    @dataclass
    class Data:
        name: str
        phone: int
        opt_phone: typing.Optional[int] = 123
        seq_phone: typing.Sequence[int] = (456,)

    @dataclass
    class Dc:
        field: typing.Union[int, str, Decimal, Data, Color, datetime.datetime]

    d = Dc(field=Data(name="name", phone=123))
    schema = _dc2schema(Dc)()
    data, error = schema.load(schema.dump(d))
    assert not error
    assert data.field.phone == 123


# Generated at 2022-06-23 16:51:34.038491
# Unit test for constructor of class _UnionField
def test__UnionField():
    class S1(Schema):
        a = fields.Int()
        b = fields.Str()
        c = fields.Float()

    class S2(Schema):
        a = fields.Int()
        b = fields.Str()
        d = fields.Float()

    class S3(Schema):
        a = fields.Int()
        b = fields.Str()
        e = fields.Float()

    tmp = _UnionField({int: S1, float: S2}, None, None)
    assert isinstance(tmp.desc, dict)
    assert tmp.field is None
    assert tmp.cls is None
    assert int in tmp.desc and float in tmp.desc
    assert issubclass(tmp.desc[int], Schema)
    assert issubclass(tmp.desc[float], Schema)


# Generated at 2022-06-23 16:51:37.494892
# Unit test for constructor of class _UnionField
def test__UnionField():
    a = _UnionField(None, None, None)
    # pylint: disable=protected-access
    assert a.desc is None
    assert a.cls == None
    assert a.field is None


# Generated at 2022-06-23 16:51:39.652212
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField().__class__ == fields.Field



# Generated at 2022-06-23 16:51:48.217113
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import fields

    class Foo:
        pass


    class Bar:
        pass


    class Test:
        def __init__(self, fld: typing.Union[int, float]):
            self.fld = fld


    class TestSchema(Schema):
        fld = _UnionField(desc={int: fields.Int(), float: fields.Float()},
                          cls=Test, field=dc_fields(Test)[0])


    exp = Test(fld=1)
    assert TestSchema().dump(exp) == {'fld': 1}
    assert TestSchema().load({'fld': 1}) == exp

    exp = Test(fld=1.5)
    assert TestSchema().dump(exp) == {'fld': 1.5}
    assert TestSche

# Generated at 2022-06-23 16:51:53.874299
# Unit test for constructor of class _TimestampField
def test__TimestampField():  
    tw = _TimestampField()
    assert tw.required == False
    assert tw._jsonschema_type_mapping == {'format':'date-time'}
    assert tw.attribute == None
    
    
    
    

# Generated at 2022-06-23 16:51:54.759758
# Unit test for function build_schema
def test_build_schema():
    assert build_schema(User, None, False, False)



# Generated at 2022-06-23 16:52:04.987509
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema

    class TestParentClass:
        pass

    class TestClass(TestParentClass):
        def __init__(self, value):
            self.value = value

    class TestSchema(Schema):
        type_ = fields.Field()

    my_dict = {'type_': 'TestClass', 'value': 'test_value'}

    union_field = _UnionField({
            TestClass: TestSchema()
        }, TestParentClass, None, required=True)
    # test deserialization
    assert isinstance(union_field._deserialize(my_dict, 'test_attr', 'test_data'), TestClass)
    # test serialization
    my_test_class = TestClass('test_value')

# Generated at 2022-06-23 16:52:14.849987
# Unit test for constructor of class SchemaF
def test_SchemaF():
    dataclass = typing.NewType('dataclass', int)

    @dataclasses.dataclass
    class SchemaTestType(SchemaF[dataclass]):
        val: dataclass = dataclasses.field(metadata={'marshmallow_field': fields.Int()})

    @dataclasses.dataclass
    class SchemaTestTypes(SchemaF[dataclass]):
        val: typing.List[dataclass] = dataclasses.field(metadata={'marshmallow_field': fields.List(fields.Int())})


# Generated at 2022-06-23 16:52:23.721922
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.Mapping[int, str],{},None,None,None)(None,{})==fields.Mapping()
    assert build_type(typing.Mapping[int, int],{},None,None,None)(None,{})==fields.Mapping()
    assert build_type(typing.MutableMapping[int, str],{},None,None,None)(None,{})==fields.Mapping()
    assert build_type(typing.MutableMapping[int, int],{},None,None,None)(None,{})==fields.Mapping()
    assert build_type(typing.List[int],{},None,None,None)(None,{})==fields.List()

# Generated at 2022-06-23 16:52:36.241990
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from datetime import datetime
    from dataclasses import dataclass, fields
    import typing
    import marshmallow as mm
    import marshmallow_enum as mm_enum
    import marshmallow_dataclass as mm_data
    import uuid
    import decimal
    @dataclass
    class SomeType:
        type_id: uuid.UUID

    @dataclass
    class SomeClass:
        some_type: SomeType
        dt: datetime
        sd: typing.List[str]
        dc: decimal.Decimal

    # TYPES[datetime] = _TimestampField
    # TYPES[uuid.UUID] = mm.fields.UUID
    # TYPES[typing.List[str]] = mm.fields.List
    # TYPES[decimal.Decimal]

# Generated at 2022-06-23 16:52:49.383454
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class SimpleUserSchema(SchemaF[SimpleUser]):
        name = fields.Str()
        age = fields.Int(validate=lambda x: 0 < x < 99)

        @post_load
        def make_user(self, data, **kwargs):
            return SimpleUser(**data)

    users = [SimpleUser('Eric', 74), SimpleUser('John', 68)]

    data, err = SimpleUserSchema().dump(users, many=True)

    assert data == [
        {
            'name': 'Eric',
            'age': 74
        },
        {
            'name': 'John',
            'age': 68
        }
    ]
    assert err == {}

    data, err = SimpleUserSchema().dump(users[0])


# Generated at 2022-06-23 16:53:01.554746
# Unit test for function build_type
def test_build_type():
    from marshmallow import post_load, fields
    from marshmallow_enum import EnumField
    import uuid
    import decimal
    import datetime
    from typing import List, Dict, Any

    from dataclasses import _MISSING_TYPE, dataclass
    from dataclasses_json import DataClassJsonMixin, config

    from .utils import _is_collection, _is_new_type, _get_type_origin

    from .core import _is_supported_generic
    from .core import _user_overrides_or_exts
    from .core import _is_optional
    from .core import _handle_undefined_parameters_safe

    class Foo:
        pass

    class Object:
        foo: int

    class Object2:
        param_1: int
        param_2: str
       

# Generated at 2022-06-23 16:53:05.127437
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class TestSchema:
        a: int

    assert build_schema(TestSchema,dataclass_json,True,True) is not None


# Generated at 2022-06-23 16:53:14.434787
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.fromisoformat("2020-02-02 02:02:02+09:00"), "attr", object(), missing=False) == 1583068122.0
    assert _TimestampField()._deserialize(1583068122.0, "attr", object(), missing=False) == datetime.fromisoformat("2020-02-02 02:02:02+09:00")
    assert _TimestampField()._serialize(None, "attr", object(), missing=False) is None
    assert _TimestampField()._deserialize(None, "attr", object(), missing=False) is None


# Generated at 2022-06-23 16:53:19.037030
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF[A]):
        pass

    s = S()
    a = s.dumps(dict())
    assert a == '{}'
    b = s.dumps([dict(), dict()])
    assert b == '[{},{}]'



# Generated at 2022-06-23 16:53:21.949426
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    request = SchemaF.load(data={}, many=False)
    assert isinstance(request, typing.Any)



# Generated at 2022-06-23 16:53:25.501662
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def test_method(schema, obj):
        pass

    test_method(typing.cast(SchemaF[None], None), None)



# Generated at 2022-06-23 16:53:30.558021
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(object):
        def __init__(self, a: int):
            self.a = a

    class A_Schema(SchemaF):
        a = fields.Int()

    schema = A_Schema()
    print(schema.dump([A(1), A(2)]))
    print(schema.dump(A(1)))
    print(schema.dumps([A(1), A(2)]))
    print(schema.dumps(A(1)))


# Generated at 2022-06-23 16:53:41.013839
# Unit test for function build_type
def test_build_type():
    class T(int):
        pass
    class Base():
        pass
    @dataclass_json
    @dataclass
    class A(Base):
        name: str = 'a'
    @dataclass_json
    @dataclass
    class B(Base):
        name: str = 'b'
    @dataclass_json
    @dataclass
    class U(Base):
        name: Union[A, B]
    @dataclass_json
    @dataclass
    class T(Base):
        name: T
    @dataclass_json
    @dataclass
    class L(Base):
        name: List[int]
    @dataclass_json
    @dataclass
    class D(Base):
        name: Dict[int, int]

# Generated at 2022-06-23 16:53:49.145405
# Unit test for function schema
def test_schema():
    import marshmallow as ma
    import dataclasses_json as dcj
    @dcj.dataclass_json(mm_field=ma.fields.String)
    @dcj.dataclass
    class A:
        a: str
    assert list(schema(A, None, False).keys()) == ['a']
    @dcj.dataclass_json(mm_field=ma.fields.Integer)
    @dcj.dataclass
    class B:
        b: int
    assert list(schema(B, None, False).keys()) == ['b']
    @dcj.dataclass_json(mm_field=ma.fields.List)
    @dcj.dataclass
    class C:
        c: list

# Generated at 2022-06-23 16:53:54.554859
# Unit test for constructor of class _UnionField
def test__UnionField():
    try:
        from typing_extensions import Literal
    except ImportError:
        from typing import Literal

    class Dummy(Enum):
        ONE = 1
        TWO = 2

    schema = Schema.from_dict({
        'number': _UnionField(
            desc={
                int: fields.Int,
                float: fields.Float,
                Literal[0]: fields.Int,
                Literal[1.0]: fields.Float,
                UUID: fields.UUID,
                Decimal: fields.Decimal,
                datetime: _TimestampField,
                Dummy: EnumField(Dummy),
            },
            cls=CatchAllVar,
            field=CatchAllVar,
            str='_UnionField_test',
            allow_none=True,
        ),
    })

   

# Generated at 2022-06-23 16:53:56.237387
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        instance = _TimestampField()
        assert True
    except:
        assert False


# Generated at 2022-06-23 16:54:06.967496
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # test that the first overload works with lists
    data = [1, 2, 3]
    schema = SchemaF[int].dump
    schema(data)
    # test that the second overload works with non-lists
    data = 1
    schema = SchemaF[int].dump
    schema(data)
    # test that the type var is not needed
    # This should work because the function should work with all types
    schema = SchemaF.dump
    schema(data)
    # test that ideally this fails
    # This is not implemented. See also https://github.com/marshmallow-code/marshmallow/issues/1160
    # data = [1, "2", 3]
    # schema = SchemaF[int].dump
    # schema(data)



# Generated at 2022-06-23 16:54:14.808263
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import typing
    import marshmallow_dataclass
    from dataclasses import dataclass

    @dataclass
    class Foo:
        x: str
        y: typing.List[int]

    schema = marshmallow_dataclass.class_schema(Foo)  # type: ignore
    result = schema.dump([{'x': 'foo', 'y': [1, 2, 3]}])  # type: ignore
    assert result == [{'x': 'foo', 'y': [1, 2, 3]}]


# Generated at 2022-06-23 16:54:20.971266
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.api import mm_field
    import typing as tp
    mm_field(tp.List[tp.List[int]])
    mm_field(tp.List[tp.Optional[int]])
    mm_field(tp.Union[tp.List[int], int])
    mm_field(tp.Optional[tp.Union[tp.List[int], int]])
    mm_field(tp.Any)



# Generated at 2022-06-23 16:54:23.924796
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()
    assert obj is not None
    assert obj.__class__ is _IsoField


# Generated at 2022-06-23 16:54:27.873652
# Unit test for function build_schema
def test_build_schema():
    DataClassSchema = build_schema(SimpleClass, None, None, None)
    assert DataClassSchema.__name__ == 'SimpleClassSchema'
    assert DataClassSchema.Meta.fields == ('a', 'b', 'c')



# Generated at 2022-06-23 16:54:39.370804
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List, Any
    from marshmallow import fields, Schema

    class A(object):
        def __init__(self, a: int, b: float):
            self.a = a
            self.b = b

    class A_Schema(Schema):
        a = fields.Int()
        b = fields.Float()

    A_Schema_f = SchemaF[A]  # type: ignore

    a_data: List[Any] = []
    data1 = {"a": 1, "b": 1.2}
    data2 = {"a": 2, "b": 2.3}

    # test if values are passed correctly

# Generated at 2022-06-23 16:54:50.426659
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestData:
        a: int
        b: str

    test_schema = build_schema(TestData,
                               mixin=None,
                               infer_missing=True,
                               partial=False)
    assert 'a' in test_schema._declared_fields.keys()
    assert 'b' in test_schema._declared_fields.keys()
    t = TestData(1, 'b')
    assert test_schema().dump(t, many=False) == {'a': 1, 'b': 'b'}



# Generated at 2022-06-23 16:54:52.504138
# Unit test for function build_type
def test_build_type():
    assert issubclass(build_type(typing.List[int],{},object,object,object), fields.List)



# Generated at 2022-06-23 16:55:05.347399
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema = SchemaF[A](strict=True)
    schema.dump(['a', 'b'])
    schema.dump(['a', 'b'], many=True)
    schema.dump('a')
    schema.dump('a', many=False)
    schema = SchemaF[A](strict=True)
    for value in [
            'a',
            (1,),
            {'a': 1},
            {'a', 1},
            1,
            1.0,
            True,
            (1,),
            {'a': 1},
            {'a', 1},
            test_SchemaF_dump
    ]:
        schema.dump([value])
        schema.dump([value], many=True)
        schema.dump(value)