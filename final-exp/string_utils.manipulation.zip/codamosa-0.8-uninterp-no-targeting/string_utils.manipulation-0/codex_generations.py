

# Generated at 2022-06-21 21:13:29.493617
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-21 21:13:33.716485
# Unit test for function compress
def test_compress():
    assert compress('test') == 'eJxLTEsNAQA='
    assert compress('test test') == 'eJwDTEsNjEwDTEsNjEw'
    assert compress(' ') == 'eJxLzg=='



# Generated at 2022-06-21 21:13:39.582581
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def run_test(input_value, expected_result):
        assert __StringFormatter(input_value).format() == expected_result

    # test all combinations of replacements with a simple input

# Generated at 2022-06-21 21:13:49.954781
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert(booleanize('True') == True)
    assert(booleanize('YES') == True)
    assert(booleanize('y') == True)
    assert(booleanize('1') == True)
    assert(booleanize('false') == False)
    assert(booleanize('0') == False)
    assert(booleanize('falso') == False)
    assert(booleanize('nope') == False)
    assert(booleanize('') == False)
    assert(booleanize('123') == False)

if __name__ == '__main__':
    test_booleanize()
    print('Test passed successfully')




# Generated at 2022-06-21 21:13:54.186527
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('test1 test2').format() == 'Test1 test2'
    assert __StringFormatter('test1   test2').format() == 'Test1 test2'
    assert __StringFormatter('  test1    test2  ').format() == 'Test1 test2'
    assert __StringFormatter(' test1   test2 test3 ').format() == 'Test1 test2 test3'
    assert __StringFormatter('  test1, test2  and   test3  ').format() == 'Test1, test2 and test3'
    assert __StringFormatter('  test1, test2(  and   test3  ').format() == 'Test1, test2 (and test3'

# Generated at 2022-06-21 21:14:01.510622
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('Result: <a href="foo/bar">Click here</a>', keep_tag_content=False) == 'Result: '
    assert strip_html('Result: <a href="foo/bar">Click here</a>', keep_tag_content=True) == 'Result: Click here'
    assert strip_html('Result: <div>hello world</div>', keep_tag_content=False) == 'Result: '
    assert strip_html('Result: <div>hello world</div>', keep_tag_content=True) == 'Result: hello world'
    assert strip_html('Result: <div>hello world</div><script>var foo=1;</script>', keep_tag_content=False) == 'Result: '

# Generated at 2022-06-21 21:14:04.081043
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('firstSecondTest') == 'first_second_test'
    assert camel_case_to_snake('firstSecondTest', '-') == 'first-second-test'



# Generated at 2022-06-21 21:14:13.010814
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'
    assert __RomanNumbers.__encode

# Generated at 2022-06-21 21:14:14.639065
# Unit test for function strip_margin
def test_strip_margin():
    # todo: implement
    pass



# Generated at 2022-06-21 21:14:18.632552
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert len(__StringCompressor.compress("Hello world!")) == 27
    assert __StringCompressor.decompress("eNpLTkLEtKjEtTS1Ny2lOzNKCjNzMtKzS7VxA==") == "Hello world!"


# PUBLIC API



# Generated at 2022-06-21 21:14:31.342460
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    comp = __StringCompressor()
    assert comp is not None


# PUBLIC API



# Generated at 2022-06-21 21:14:33.780823
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('world') == 'dlrow'
    assert reverse('unicode') == 'edocinu'
    try:
        reverse(3)
    except InvalidInputError:
        pass
    else:
        assert False, 'reverse does not raise an InvalidInputError for non strings'    



# Generated at 2022-06-21 21:14:43.125088
# Unit test for function slugify
def test_slugify():
    assert(slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs')
    assert(slugify('Mönstér Mägnët') == 'monster-magnet')
    assert(slugify('test?test...test') == 'test-test-test')
    assert(slugify('תנו שלום לעולם') == 'tnv-svlm-laolm')
    assert(slugify('测试') == 'ceshi')
    assert(slugify('✔') == '--')
    assert(slugify('!@#$%^&*()_+') == '-')
    assert(slugify('`~/\\|') == '-')

# Generated at 2022-06-21 21:14:45.366225
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        |line 1
                        |line 2
                        |line 3
                        |''') == '''line 1
line 2
line 3
'''
    assert strip_margin('''
    |line 1
    |line 2
    |line 3
    |''') == '''line 1
line 2
line 3
'''


# Generated at 2022-06-21 21:14:57.557470
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('CamelCaseTest') == 'camel_case_test'
    assert camel_case_to_snake('camelCaseTest') == 'camel_case_test'
    assert camel_case_to_snake('CamelCase') == 'camel_case'
    assert camel_case_to_snake('camelCase') == 'camel_case'
    assert camel_case_to_snake('') == ''
    try:
        camel_case_to_snake(None)
    except InvalidInputError as e:
        assert str(e.original) == 'None'

# Generated at 2022-06-21 21:15:02.889857
# Unit test for function reverse
def test_reverse():
    assert reverse('a') == 'a'
    assert reverse('abc') == 'cba'
    assert reverse('abcdefg') == 'gfedcba'
    assert reverse('abc defg') == 'gfed cba'
    assert reverse('hello') == 'olleh'
    assert reverse('Éric') == 'cirÉ'
    assert reverse('hello world') == 'dlrow olleh'



# Generated at 2022-06-21 21:15:07.028613
# Unit test for function strip_margin
def test_strip_margin():
    x = '''
        |foo
        |bar
        |baz
        '''.strip()
    assert strip_margin(x) == 'foo\nbar\nbaz\n'



# Generated at 2022-06-21 21:15:16.802297
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green.') == 'TheSnakeIsGreen.'
    assert snake_case_to_camel('the_snake_is_green.') != 'tHEsNAKEIsGreen.'
    assert snake_case_to_camel('the_snake_is_green.', False) == 'theSnakeIsGreen.'
    assert snake_case_to_camel('the-snake-is-green.', True, '-') == 'TheSnakeIsGreen.'
    assert snake_case_to_camel('the_snake_is_green.', False, '') == 'the_snake_is_green.'

test_snake_case_to_camel()


# Generated at 2022-06-21 21:15:25.690871
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('A man, a plan, a canal: Panama') == 'a-man-a-plan-a-canal-panama'
    assert slugify('✔✔✔✔✔✔✔✔✔✔✔') == 'x-x-x-x-x-x-x-x-x-x'
    assert slugify('') == ''



# Generated at 2022-06-21 21:15:38.135442
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode('1') == 'I'
    assert __RomanNumbers.encode('2') == 'II'
    assert __RomanNumbers.encode('3') == 'III'
    assert __RomanNumbers.encode('4') == 'IV'
    assert __RomanNumbers.encode('5') == 'V'
    assert __RomanNumbers.encode('6') == 'VI'
    assert __RomanNumbers.encode('7') == 'VII'
    assert __RomanNumbers.encode('8') == 'VIII'
    assert __RomanNumbers.encode('9') == 'IX'
    assert __RomanNumbers.encode('10') == 'X'
    assert __RomanNumbers.encode('11') == 'XI'
    assert __RomanNumbers.encode('12') == 'XII'
    assert __Roman

# Generated at 2022-06-21 21:15:54.115173
# Unit test for function roman_decode
def test_roman_decode():
    assert(roman_decode('I') == 1)
    assert(roman_decode('V') == 5)
    assert(roman_decode('X') == 10)
    assert(roman_decode('L') == 50)
    assert(roman_decode('C') == 100)
    assert(roman_decode('D') == 500)
    assert(roman_decode('M') == 1000)
    assert(roman_decode('VI') == 6)
    assert(roman_decode('IV') == 4)
    assert(roman_decode('XIV') == 14)
    assert(roman_decode('MDCCLXXVI') == 1776)
    assert(roman_decode('MCMXCIX') == 1999)
    assert(roman_decode('MM') == 2000)

# Generated at 2022-06-21 21:15:59.701596
# Unit test for function shuffle
def test_shuffle():
    input_string = 'xyz'
    shuffled_string = shuffle(input_string)
    assert is_string(shuffled_string)
    assert len(shuffled_string) == len(input_string)
    assert shuffled_string != input_string



# Generated at 2022-06-21 21:16:03.255392
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('abc') == 'cba'
    assert reverse('  abc') == 'cba  '
    assert reverse('  abc ') == ' cba  '
    assert reverse('  abc  ') == '  cba  '



# Generated at 2022-06-21 21:16:10.006148
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    return compressed



# Generated at 2022-06-21 21:16:13.560188
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:16:21.196088
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'
    assert slugify("Les Chants de Maldoror") == 'les-chants-de-maldoror'
    assert slugify("Für Elise") == 'fur-elise'
    assert slugify("Stave 1: Marley's Ghost") == 'stave-1-marley-s-ghost'
    assert slugify("Teddy's blues") == 'teddy-s-blues'
    assert slugify("Tom's Diner") == 'tom-s-diner'
    assert slugify("I’ve Seen Footage") == 'ive-seen-footage'

# Generated at 2022-06-21 21:16:25.211638
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == "XXXVII"
    assert roman_encode("2020") == "MMXX"
    assert roman_encode("4") == "IV"
    assert roman_encode("9") == "IX"
    assert roman_encode("40") == "XL"
    assert roman_encode("90") == "XC"
    assert roman_encode("400") == "CD"
    assert roman_encode("900") == "CM"
    assert roman_encode("2019") == "MMXIX"
    assert roman_encode("1") == "I"
    assert roman_encode("2") == "II"
    assert roman_encode("3") == "III"
    assert roman_encode("4") == "IV"

# Generated at 2022-06-21 21:16:29.025787
# Unit test for function compress
def test_compress():
    original = "A string with a lot of repetitive data in it, so it can be compressed. A string with a lot of repetitive \
                data in it, so it can be compressed."
    compressed = compress(original)

    assert compressed



# Generated at 2022-06-21 21:16:32.262976
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('123') == '321'



# Generated at 2022-06-21 21:16:36.740398
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:16:57.955725
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-21 21:17:05.472134
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7, "Roman VII should be decoded as 7"
    assert roman_decode('M') == 1000, "Roman M should be decoded as 1000"
    assert roman_decode('') == 0, "Empty string should be decoded as 0"
    assert roman_decode('CM') == 900, "Roman M should be decoded as 900"
    assert roman_decode('IX') == 9, "Roman IX should be decoded as 9"
    # Test the negative number converted the roman number
    roman_num = -4444
    assert roman_decode(roman_num) != -4, "Roman number should be decoded as positive number"
    # Test some special case

# Generated at 2022-06-21 21:17:06.532567
# Unit test for function reverse
def test_reverse():
    assert 'olleh' == reverse('hello')



# Generated at 2022-06-21 21:17:13.061991
# Unit test for function asciify
def test_asciify():
    assert asciify("nfkd") == "nfkd"
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE"
    assert asciify("✋✋✋✋✋") == "✋✋✋✋✋"
    #assert asciify("✋✋✋✋✋") == "?????"

test_asciify()

# Generated at 2022-06-21 21:17:24.250519
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', '-') == 'the_snake_is_green'
    assert snake_case_to_camel('thesnakeisgreen', separator='-') == 'Thesnakeisgreen'

test_snake_case_to_camel()


# Generated at 2022-06-21 21:17:36.586161
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('ab ab ab').format() == 'Ab Ab Ab'
    assert __StringFormatter('Ab Ab Ab').format() == 'Ab Ab Ab'
    assert __StringFormatter('Ab ab ab').format() == 'Ab Ab Ab'
    assert __StringFormatter('ab AB AB').format() == 'Ab Ab Ab'
    assert __StringFormatter('aB aB aB').format() == 'Ab Ab Ab'
    assert __StringFormatter('ab ab ab ABC abc').format() == 'Ab Ab Ab Abc Abc'
    assert __StringFormatter('ab ab ab abc 123').format() == 'Ab Ab Ab Abc 123'
    assert __StringFormatter('abc abc abc 123').format() == 'Abc Abc Abc 123'
    assert __StringFormatter('abc abc    abc 123').format

# Generated at 2022-06-21 21:17:39.767544
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("I") == 1
    assert roman_decode("IV") == 4
    assert roman_decode("X") == 10
    assert roman_decode("XL") == 40


# Generated at 2022-06-21 21:17:42.985681
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('HELLO') == 'OLLEH'



# Generated at 2022-06-21 21:17:51.459695
# Unit test for function slugify
def test_slugify():
    assert slugify('hello world') == 'hello-world'
    assert slugify('hello world', '_') == 'hello_world'
    assert slugify('My favorite food is #tiramisù and Yummy Pizza!!') == 'my-favorite-food-is-tiramisu-and-yummy-pizza'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'



# Generated at 2022-06-21 21:17:53.615368
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
test_roman_encode()

