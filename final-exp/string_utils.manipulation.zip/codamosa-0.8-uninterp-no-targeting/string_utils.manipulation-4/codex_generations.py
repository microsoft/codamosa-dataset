

# Generated at 2022-06-21 21:13:41.481423
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('') == ''
    assert strip_html('a') == 'a'
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'
    assert strip_html('<p>test <a href="foo/bar">click here</a> test</p>') == ''
    assert strip_html('<p>test <a href="foo/bar">click here</a> test</p>', keep_tag_content=True) == 'test click here test'
    assert strip_html('<p>test</p>') == ''
    assert strip_html('<p>test</p>', keep_tag_content=True) == 'test'

# Generated at 2022-06-21 21:13:43.309682
# Unit test for function decompress
def test_decompress():
    result = decompress(compress("Hello World"))

    assert result == "Hello World"

test_decompress()


# Generated at 2022-06-21 21:13:51.968834
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('') == ''
    assert strip_html('<p>foo</p>') == ''
    assert strip_html('<p>foo</p>', keep_tag_content=True) == 'foo'
    assert strip_html('<p>foo</p><p>bar</p>') == ''
    assert strip_html('<p>foo</p><p>bar</p>', keep_tag_content=True) == 'foobar'
    assert strip_html('<a href="hello">') == ''
    assert strip_html('<a href="hello">', keep_tag_content=True) == ''
    assert strip_html('<a href="hello">click here</a>') == ''
    assert strip_html('<a href="hello">click here</a>', keep_tag_content=True)

# Generated at 2022-06-21 21:13:57.862381
# Unit test for function decompress
def test_decompress():
    string = 'Lorem ipsum dolor sit amet'
    expected_result = 'Lorem ipsum dolor sit amet'
    result = decompress(compress(string))
    assert result == expected_result

test_decompress()



# Generated at 2022-06-21 21:13:59.397573
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'

# --



# Generated at 2022-06-21 21:14:08.594031
# Unit test for function compress
def test_compress():
    assert compress('Hello, World!') == 'eJxLycwtzU3MS8xIkZISW8Q'
    assert compress('Hello, World!') != 'eJxLycwtzU3MS8xIkZISW8Q=='
    assert compress('Hello, World!') != 'eJxLycwtzU3MS8xIkZISW8Q==='
    assert compress('Hello, World!') != 'eJxLycwtzU3MS8xIkZISW8Q===='
    assert compress('Hello, World!') != 'eJxLycwtzU3MS8xIkZISW8QUTFJ'



# Generated at 2022-06-21 21:14:17.323943
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('no-snake-here', separator='-') == 'no-snake-here'

# Generated at 2022-06-21 21:14:22.451862
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_b_c') == 'ABC'
    assert snake_case_to_camel('a_b_c', upper_case_first=False) == 'aBC'
    assert snake_case_to_camel('a_b_c', upper_case_first=False,
                               separator='-') == 'aBC'



# Generated at 2022-06-21 21:14:28.281504
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '



# Generated at 2022-06-21 21:14:30.449442
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    output_string = snake_case_to_camel(input_string)
    assert output_string == 'TheSnakeIsGreen'
    return True



# Generated at 2022-06-21 21:14:48.316365
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    assert compressed != original, "original string was NOT compressed"

    assert len(original) > len(compressed), "compressed string is longer than original"

    assert decompress(compressed) == original, "decompression didn't return the original string"


# Generated at 2022-06-21 21:14:50.714974
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                    line 1
                    line 2
                    line 3
                ''') == '''
line 1
line 2
line 3
'''

# Generated at 2022-06-21 21:15:03.019554
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('to be or not to be').format() == 'to be or not to be'
    assert __StringFormatter('to   be or not to   be').format() == 'to be or not to be'
    assert __StringFormatter('is  this  really  really really  really really really  really really really a test?').format() == 'is this really really really really really really really really really a test?'
    assert __StringFormatter('Don\'t you think that this is an ugly example, I mean really really really ugly?').format() == 'Don\'t you think that this is an ugly example, I mean really really really ugly?'

# Generated at 2022-06-21 21:15:05.196319
# Unit test for function decompress
def test_decompress():
    assert decompress('1:eJxTTMoPS+lJzMvMAIAYAA') == 'eJxTTMoPS+lJzMvMAIAYAA'



# Generated at 2022-06-21 21:15:15.764458
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # normal case
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'

    # case where the separator does not have to be "_"
    assert snake_case_to_camel('this_is_a_test', separator=' ') == 'ThisIsATest'

    # first letter is lowercase
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False) == 'thisIsATest'

    # first letter is lowercase and using a non standard separator
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False, separator='-') == 'thisIsATest'

    # invalid snake case

# Generated at 2022-06-21 21:15:17.136420
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII')==7

# Generated at 2022-06-21 21:15:19.394064
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize(True) == True
    assert booleanize(False) == False
    
test_booleanize()

# Generated at 2022-06-21 21:15:22.627458
# Unit test for function asciify
def test_asciify():
    s = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    o = asciify(s)
    assert o == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:15:26.460560
# Unit test for function asciify
def test_asciify():
  assert(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE")
  pass



# Generated at 2022-06-21 21:15:34.464167
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_data = ['the_snake_is_green', 'first_name', 'house_number', 'my_unique_identifier']
    expected = ['TheSnakeIsGreen', 'FirstName', 'HouseNumber', 'MyUniqueIdentifier']
    for i, inp in enumerate(input_data):
        assert snake_case_to_camel(inp, True) == expected[i]

test_snake_case_to_camel()


# Generated at 2022-06-21 21:15:46.463340
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World!'
    compressed_string = __StringCompressor.compress(input_string)
    assert compressed_string != input_string
    assert len(compressed_string) < len(input_string)
    output_string = __StringCompressor.decompress(compressed_string)
    assert output_string == input_string



# Generated at 2022-06-21 21:15:52.281814
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('') == ''
    assert asciify('test') == 'test'
    assert asciify('è') == 'e'
    assert asciify('\x80') == ''
    assert asciify('') == ''



# Generated at 2022-06-21 21:15:59.144987
# Unit test for function decompress
def test_decompress():
    assert(decompress('ZW1haWxAZXhhbXBsZS5jb209MTIzNDU=') == 'email@example.com=12345')
    assert(decompress('ZW1haWxAZXhhbXBsZS5jb20=') == 'email@example.com')
    assert(decompress(decompress('aW5wdXRfdHlwZT0iZW5jb2RlZCI='), 'utf-8') == 'input_type="encoded"')
    assert(decompress('5YW15pel5YyX5pyf5Y2K5biI6ICMwMDAwMDAg') == '输入颜色： #000000 ')

# Generated at 2022-06-21 21:16:09.871128
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test = __StringFormatter(input_string='foo bar')
    assert test.input_string == 'foo bar'

    out = test.format()
    assert out == 'Foo bar'

    test = __StringFormatter(input_string='foo bar baz')
    assert test.input_string == 'foo bar baz'

    out = test.format()
    assert out == 'Foo bar baz'

    test = __StringFormatter(input_string='foo bar baz qux banana')
    assert test.input_string == 'foo bar baz qux banana'

    out = test.format()
    assert out == 'Foo bar baz qux banana'

    test = __StringFormatter(input_string='foo foo foo')
    assert test.input_string == 'foo foo foo'

    out = test.format

# Generated at 2022-06-21 21:16:15.533749
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
   

# Generated at 2022-06-21 21:16:28.293911
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('some string').input_string == 'some string'
    assert __StringFormatter('  ').input_string == '  '
    assert __StringFormatter('').input_string == ''
    assert __StringFormatter('some string').input_string == 'some string'
    assert __StringFormatter('-some string').input_string == '-some string'
    assert __StringFormatter('some     string').input_string == 'some     string'
    assert __StringFormatter('und  das').input_string == 'und  das'
    assert __StringFormatter(' und das').input_string == ' und das'
    assert __StringFormatter('und das ').input_string == 'und das '

# Generated at 2022-06-21 21:16:31.192691
# Unit test for function strip_margin
def test_strip_margin():
    test_string = """
        line 1
        line 2
        line 3
        """
    
    assert strip_margin(test_string) == """
line 1
line 2
line 3
"""
    
test_strip_margin()

# Generated at 2022-06-21 21:16:39.624606
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    try:
        roman_encode('donkey')
    except (Exception) as exc:
        assert exc.__class__ == ValueError
    try:
        roman_encode('4000')
    except (Exception) as exc:
        assert exc.__class__ == ValueError



# Generated at 2022-06-21 21:16:48.407344
# Unit test for function asciify
def test_asciify():
    assert is_string(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('') == ''
    assert asciify('1') == '1'
    assert asciify('!') == '!'
    assert asciify(' ') == ' '
    assert asciify('à') == 'a'
    assert asciify('é') == 'e'
    assert asciify('è') == 'e'
    assert asciify('ì') == 'i'
   

# Generated at 2022-06-21 21:16:54.047123
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(100)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert len(compressed) < len(original)

test_compress()



# Generated at 2022-06-21 21:17:16.232456
# Unit test for function prettify
def test_prettify():
    print("Running test_prettify...")
    assert prettify("hello     world") == "Hello world"
    assert prettify("  foo?  bar?!  ") == "Foo? Bar?!"
    assert prettify("hello world. this is a test") == "Hello world. This is a test"
    assert prettify("this is a test") == "This is a test"
    assert prettify("    hello world") == "Hello world"
    assert prettify("hello world    ") == "Hello world"
    assert prettify("This is a test.It's very cool") == "This is a test. It's very cool"
    assert prettify("This is a test. It's very cool") == "This is a test. It's very cool"

# Generated at 2022-06-21 21:17:25.868794
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('V') == 5
    assert roman_decode('X') == 10
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('XI') == 11

# Generated at 2022-06-21 21:17:28.933752
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    with open('test_file_StringFormatter_format.txt') as f:
        lines = f.readlines()

    # print(lines)  # For debugging

    for i in range(len(lines)):
        test_data = lines[i].split('\t')

        # print(test_data)  # For debugging

        assert __StringFormatter(test_data[0]).format() == test_data[1].rstrip(), 'TEST #{} -> FAILED'.format(i)

# Generated at 2022-06-21 21:17:39.916993
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert (__StringFormatter('   A   b   c   d  ').format() == 'A b c d')
    assert (__StringFormatter('   a   b   c   d  ').format() == 'a b c d')
    assert (__StringFormatter('   email@email.com  ').format() == 'email@email.com')
    assert (__StringFormatter('   www.www.com  ').format() == 'www.www.com')
    assert (__StringFormatter('   https://www.www.com  ').format() == 'https://www.www.com')
    assert (__StringFormatter('   http://www.www.com  ').format() == 'http://www.www.com')

# Generated at 2022-06-21 21:17:44.285572
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                             line 1
                             line 2
                             line 3
                           ''') == '''
line 1
line 2
line 3
'''

# Generated at 2022-06-21 21:17:48.225854
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert not __StringFormatter(None)
    assert not __StringFormatter(False)
    assert not __StringFormatter(1)
    assert not __StringFormatter('')
    assert __StringFormatter('abc')


# Generated at 2022-06-21 21:17:59.311340
# Unit test for function prettify
def test_prettify():
    assert prettify('this is a test') == 'This is a test'
    assert prettify('   this         is      a    test      ') == 'This is a test'
    assert prettify('100%') == '100%'
    assert prettify('100 %') == '100%'
    assert prettify('100% is good') == '100% is good'
    assert prettify('100 % is good') == '100% is good'
    assert prettify('"this is a quote"') == '"This is a quote"'
    assert prettify('this is a (test)') == 'This is a (test)'
    assert prettify('foo&bar baz') == 'Foo & bar baz'
    assert prettify('foo!bar baz?') == 'Foo! Bar baz?'

# Generated at 2022-06-21 21:18:06.809180
# Unit test for function slugify
def test_slugify():
    # test "slug" generation
    assert slugify("Test Slugify") == 'test-slugify'
    assert slugify("Test Slugify", '_') == 'test_slugify'
    assert slugify("TEST,Slugify") == 'test-slugify'
    assert slugify("Test Slugify's") == 'test-slugifys'
    assert slugify("Test Slugify;") == 'test-slugify'
    assert slugify("Test Slugify!") == 'test-slugify'
    assert slugify("-Test Slugify-") == 'test-slugify'
    # test non-alphanumeric chars
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    # test non-ascii chars

# Generated at 2022-06-21 21:18:15.887037
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-case-string-test'
    assert camel_case_to_snake('thisisacamelstringtest') == 'thisisacamelstringtest'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('this Is A Camel String Test') == 'this is a camel string test'
    assert camel_case_to_snake('This is a camel string test') == 'this is a camel string test'
    assert camel_

# Generated at 2022-06-21 21:18:27.838715
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('1 2 3').format() == '1 2 3'
    assert __StringFormatter('1  2   3').format() == '1 2 3'
    assert __StringFormatter(' 1  2   3 ').format() == '1 2 3'
    assert __StringFormatter('a a a a').format() == 'a a a a'
    assert __StringFormatter('a a a a ').format() == 'a a a a'
    assert __StringFormatter('a-a-a-a').format() == 'a-a-a-a'
    assert __StringFormatter('a--a-a--a').format() == 'a-a-a-a'
    assert __StringFormatter('a:a:a:a').format() == 'a: a: a: a'
    assert __StringForm