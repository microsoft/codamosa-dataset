

# Generated at 2022-06-21 21:13:32.971441
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == shuffle('hello world')
    assert len(shuffle('hello world')) == len('hello world')
    assert not shuffle('hello world').startswith('hello world')



# Generated at 2022-06-21 21:13:40.692251
# Unit test for function compress
def test_compress():
    original = '1234123412341234123412341234123412341234123412341234123412341234'
    compressed = compress(original)
    print('Compressed string:')
    print(compressed)

    from collections import Counter as __Counter
    from collections import defaultdict as __defaultdict
    from toolz import groupby as __groupby
    from toolz import compose as __compose
    from toolz.functoolz import curry as __curry

    # Count each char occurrence in the original string
    counter = __Counter(original)

    # Sort the result by the number of occurrences (largest to smallest)
    counter_sorted = sorted(counter.items(), key=lambda kv: kv[1])[::-1]

    print(counter_sorted)

    # Count each

# Generated at 2022-06-21 21:13:48.122842
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest_WithUnderscore') == 'this_is_a_camel_string_test_with_underscore'
    assert camel_case_to_snake('this_is_not_a_camel_case') == 'this_is_not_a_camel_case'
    assert camel_case_to_snake('AMX') == 'amx'
    assert camel_case_to_snake('theUrlPath') == 'the_url_path'



# Generated at 2022-06-21 21:13:55.226777
# Unit test for function decompress
def test_decompress():
    my_list = {'list': ['1', '2']}
    my_list_json = str(my_list)
    compressed_my_list_json = compress(my_list_json)
    decompressed_my_list_json = decompress(compressed_my_list_json)
    assert my_list_json == decompressed_my_list_json



# Generated at 2022-06-21 21:13:55.908088
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert_new__StringFormatter()


# Generated at 2022-06-21 21:14:01.674930
# Unit test for function strip_html
def test_strip_html():
    input_string = '<a href="foo/bar">click here</a>'
    expected = '<a href="foo/bar">click here</a>'

    actual = strip_html(input_string)

    if actual != expected:
        print('FAILED: Expected "' + expected + '" but got "' + actual + '"')
    else:
        print('PASSED! Actual result is: "' + actual + '"')


test_strip_html()


# Generated at 2022-06-21 21:14:07.616439
# Unit test for function asciify
def test_asciify():
    assert asciify("Hello") == "Hello"
    assert asciify("HelloèéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "HelloeeuuooaaeynAAACIINOE"


# Generated at 2022-06-21 21:14:14.665015
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('not-valid-snake-case-input') == 'not-valid-snake-case-input'



# Generated at 2022-06-21 21:14:20.207093
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # standard string
    assert __StringFormatter('Dr. Jekyll').format() == 'Dr. Jekyll'
    assert __StringFormatter('This is a test string').format() == 'This is a test string'
    assert __StringFormatter('This is a   test  string').format() == 'This is a test string'
    assert __StringFormatter('This is   a test  string').format() == 'This is a test string'
    assert __StringFormatter('  This is a  test string ').format() == 'This is a test string'
    assert __StringFormatter('This  is a test string').format() == 'This is a test string'
    assert __StringFormatter('  This   is   a  test string ').format() == 'This is a test string'

# Generated at 2022-06-21 21:14:29.504648
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello') == 'Hello'
    assert snake_case_to_camel('hello', upper_case_first=False) == 'hello'
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'



# Generated at 2022-06-21 21:14:37.911963
# Unit test for function decompress
def test_decompress():
    assert isinstance(decompress('a'), str)
    assert decompress('a') == '' and decompress('') == ''



# Generated at 2022-06-21 21:14:42.042882
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('garçon') == 'garcon'
    assert asciify('ÅÀÁÇÌÍÑÓË') == 'AAACIINOE'
    assert asciify('jalapeño') == 'jalapeno'
    assert asciify('jalapeño jalapeño jalapeño jalapeño jalapeño jalapeño') == 'jalapeno jalapeno jalapeno jalapeno jalapeno jalapeno'
    assert asciify('læbiæ') == 'laebiae'
   

# Generated at 2022-06-21 21:14:43.462663
# Unit test for function decompress
def test_decompress():
    assert decompress(compress("Ciao")) == "Ciao"


# Generated at 2022-06-21 21:14:55.505699
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'

    assert __RomanNumbers.encode(5) == 'V'

    assert __RomanNumbers.encode(10) == 'X'

    assert __RomanNumbers.encode(50) == 'L'

    assert __RomanNumbers.encode(100) == 'C'

    assert __RomanNumbers.encode(500) == 'D'

    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(1999) == 'MCMXCIX'

    assert __RomanNumbers.decode('I') == 1

    assert __RomanNumbers.decode('V') == 5

    assert __RomanNumbers.decode('X') == 10

    assert __RomanNumbers.decode('L') == 50


# Generated at 2022-06-21 21:15:05.346018
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE"
    assert asciify("aé") == "ae"
    assert asciify("") == ""
    assert asciify("Yûn-fê") == "Yun-fe"
    assert asciify("AÅ") == "A"
    assert asciify("AÅA") == "AA"
    assert asciify("Dès ") == "Des "
    assert asciify("《") == ""
    assert asciify("　　　") == "    "
    assert asciify("　　　※") == "    "
    assert asci

# Generated at 2022-06-21 21:15:15.853886
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Make sure that the mappings are correctly defined with the right structure
    assert __RomanNumbers.__mappings == [
        {1: 'I', 5: 'V'},
        {1: 'X', 5: 'L'},
        {1: 'C', 5: 'D'},
        {1: 'M'}
    ]

    # Make sure that the reversed mappings are swapped and correctly defined
    assert __RomanNumbers.__reversed_mappings == [
        {'I': 1, 'V': 5},
        {'X': 1, 'L': 5},
        {'C': 1, 'D': 5},
        {'M': 1}
    ]

    # Make sure that the encode method works as expected for number 1
    assert __RomanNumbers.encode(1) == 'I'

    # Make sure that

# Generated at 2022-06-21 21:15:26.731109
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:15:28.229131
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        ''') == '''
line 1
line 2
'''



# Generated at 2022-06-21 21:15:39.702745
# Unit test for function asciify

# Generated at 2022-06-21 21:15:50.432681
# Unit test for function asciify

# Generated at 2022-06-21 21:15:58.347241
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    print('Test for function reverse has been passed!')



# Generated at 2022-06-21 21:16:03.319559
# Unit test for function decompress
def test_decompress():
    try:
            assert "value" == decompress(compress("value"), encoding="utf-8")
            assert "value" == decompress(compress("value"),
                                         encoding="utf-8")
            assert "value" == decompress(compress("value"),
                                         encoding="utf-8")
            assert "value" == decompress(compress("value"),
                                         encoding="utf-8")
            assert "value" == decompress(compress("value"),
                                         encoding="utf-8")

    except AssertionError as e:
        print("FAIL")
        raise(e)
    print("PASS")

if __name__ == "__main__":
    test_decompress()

# Generated at 2022-06-21 21:16:14.817969
# Unit test for function decompress
def test_decompress():
    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf'))
    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf', 'utf-8', 3))
    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf', 'utf-8', 1))
    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf', 'utf-8', 9))

    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf', 'utf-16', 9))
    #Test
    assert 'asdfasdf' == decompress(compress('asdfasdf', 'utf-16', 7))
    #Test

# Generated at 2022-06-21 21:16:16.689235
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('foobar') == 'raboof'

# Generated at 2022-06-21 21:16:29.233029
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('Hello world').format() == 'Hello world'
    assert __StringFormatter('hello world, hello').format() == 'Hello world, hello'
    assert __StringFormatter('hello world, Hello').format() == 'Hello world, hello'
    assert __StringFormatter('hello world, HELLO').format() == 'Hello world, hello'
    assert __StringFormatter('hello! world').format() == 'Hello world'
    assert __StringFormatter('hello: world').format() == 'Hello world'
    assert __StringFormatter('hello-world').format() == 'Hello world'
    assert __StringFormatter('hello,world').format() == 'Hello, world'
    assert __StringFormatter('hello, world').format() == 'Hello, world'

# Generated at 2022-06-21 21:16:34.921061
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'This is a test'
    compressed = __StringCompressor.compress(input_string)
    assert __StringCompressor.decompress(compressed) == input_string
    assert input_string == __StringCompressor.decompress(__StringCompressor.compress(input_string))

test___StringCompressor()



# Generated at 2022-06-21 21:16:45.713020
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter.__placeholder_key() not in __StringFormatter.__placeholder_key()
    assert __StringFormatter.__placeholder_key() not in __StringFormatter.__placeholder_key()
    assert __StringFormatter.__placeholder_key() not in __StringFormatter.__placeholder_key()
    assert __StringFormatter("ciao").format() == "Ciao"
    assert __StringFormatter("ciao come").format() == "Ciao come"
    assert __StringFormatter("ciao come va").format() == "Ciao come va"
    assert __StringFormatter("ciao come va ?").format() == "Ciao come va?"
    assert __StringFormatter("  ciao come va  ?").format() == "Ciao come va?"

# Generated at 2022-06-21 21:16:58.610718
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <script type="text/javascript">alert("test");</script>') == 'test: '
    assert strip_html('test: <script type="text/javascript">alert("test");</script>', keep_tag_content=True) == 'test: alert("test");'
    assert strip_html('test: <style type="text/css">body {color:red}</style>') == 'test: '

# Generated at 2022-06-21 21:17:03.835759
# Unit test for function prettify

# Generated at 2022-06-21 21:17:12.200709
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake__test', upper_case_first=False, separator='_') == 'thisIsASnakeTest'

    assert snake_case_to_camel('this_is_a_snake__test', upper_case_first=True) == 'ThisIsASnakeTest'

    assert snake_case_to_camel('this_is_a_snake__test', upper_case_first=True, separator='-') == 'This-Is-A-Snake--Test'

    assert snake_case_to_camel('this_is_a_snake__test', upper_case_first=False, separator='-') == 'this-is-a-snake-Test'



# Generated at 2022-06-21 21:17:27.214092
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 0) == ''
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'
    assert __RomanNumbers.__encode_digit(1, 0) == ''

# Generated at 2022-06-21 21:17:34.619946
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    compressed_string = __StringCompressor.compress("Test")
    assert compressed_string == "eNpLT0tJzMlNTS1J0k/JzM1J0M/MzElPzElOsk=", compressed_string
    decompressed_string = __StringCompressor.decompress(compressed_string)
    assert decompressed_string == "Test", decompressed_string

test___StringCompressor()

# PUBLIC API


# Generated at 2022-06-21 21:17:42.906044
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .testing import UnitTester
    tester = UnitTester()


# Generated at 2022-06-21 21:17:52.465420
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_case_string') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('this_is_a_snake_case_string', True) == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('this_is_a_snake_case_string', False, '-') == 'this-is-a-snake-case-string'
    assert snake_case_to_camel('thisIsNotASnakeCaseString') == 'ThisIsNotASnakeCaseString'



# Generated at 2022-06-21 21:18:02.457528
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter(' ')
    assert string_formatter.format() == ' '

    string_formatter = __StringFormatter('*    cut    *    me    *')
    assert string_formatter.format() == '* cut * me *'

    string_formatter = __StringFormatter('the url is http://www.example.com and the email is example@example.com')
    assert string_formatter.format() == 'the url is http://www.example.com and the email is example@example.com'

    string_formatter = __StringFormatter('  the    url    is    http://www.example.com   and   the   email   is   example@example.com  ')

# Generated at 2022-06-21 21:18:14.216272
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('aSuperCamelString') == 'a_super_camel_string'
    assert camel_case_to_snake('ThisIsAcamelStringTest') == 'this_is_acamel_string_test'
    assert camel_case_to_snake('ThisIsA_camelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelString2test') == 'this_is_a_camel_string2test'

# Generated at 2022-06-21 21:18:16.037617
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-21 21:18:27.881837
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('the other day i saw a really big   and\n   nice car')
    assert f.format() == 'The other day I saw a really big and nice car'

    f = __StringFormatter('this is a nice website : http://www.example.com')
    assert f.format() == 'This is a nice website: http://www.example.com'

    expected = 'People love to email me at: john.doe@gmail.com but do not use my work address: john.doe@work.it'
    assert __StringFormatter(
        'people love to email me at: john.doe@gmail.com  but do not use my work address     : john.doe@work.it'
    ).format() == expected


# Generated at 2022-06-21 21:18:29.546541
# Unit test for function roman_decode
def test_roman_decode():
    # Decode a roman value:
    assert(roman_decode('III') == 3)


# Generated at 2022-06-21 21:18:31.835968
# Unit test for function decompress
def test_decompress():
    assert decompress('eJzLKCkpKLbS18/Vy0oLKSlXSxufS8zKtfVyM/NzCvVyM/NzCvVyM/NzCvVyM/NzCvVyM/NzCvVyM/NzCvVyM/NzFQ9g==') == 'This is a sample string'


# Generated at 2022-06-21 21:18:47.421238
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode('2') == 'II'
    assert roman_encode(3.5) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode(6.0) == 'VI'
    assert roman_encode('7') == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode('9') == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode('13') == 'XIII'
    assert roman_encode(17) == 'XVII'

# Generated at 2022-06-21 21:18:56.144846
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Compress/decompress a random string in order to test that the base64 encoding/decoding and zlib compression/
    # decompression are ok and that encoded values are url safe
    random_string = uuid4().hex

    compressed_string = __StringCompressor.compress(random_string)
    decompressed_string = __StringCompressor.decompress(compressed_string)

    assert random_string == decompressed_string

    # Check that an InvalidInputError exception is raised with an invalid input
    try:
        __StringCompressor.compress(123)
        assert False
    except InvalidInputError as e:
        assert True

    # Check that if a string is empty, decode will fail with a ValueError exception

# Generated at 2022-06-21 21:19:02.372438
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode( 'IV' ) == 4
    assert roman_decode( 'XXX' ) == 30
    assert roman_decode( 'XXXVI' ) == 36
    assert roman_decode( 'MCMXCIX' ) == 1999
    assert roman_decode( 'MDCXCIX' ) == 2999

# Generated at 2022-06-21 21:19:05.763074
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    m_string_1 = 'ThisIsACamelStringTest'
    m_result_1 = camel_case_to_snake(m_string_1, '_')
    assert m_result_1 == "this_is_a_camel_string_test"

    m_string_2 = 'ThisIsACamelStringTest'
    m_result_2 = camel_case_to_snake(m_string_2, '-')
    assert m_result_2 == "this-is-a-camel-string-test"


# Generated at 2022-06-21 21:19:08.127393
# Unit test for function compress
def test_compress():
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(input_string)
    result = len(compressed) < len(input_string)
    print("Compression Test: " + str(result))
# Uncomment the line below to run compression test
# test_compress()



# Generated at 2022-06-21 21:19:21.016310
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>')  == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'

# test strip_html
print('\nTest strip_html')
try:
    strip_html(1)
except InvalidInputError as e:
    print(e)
else:
    print('Failed to raise InvalidInputError')
print('Expected: test: ', strip_html('test: <a href="foo/bar">click here</a>'))
print('Expected: test: click here', strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True))
# end of unit test for

# Generated at 2022-06-21 21:19:23.724827
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
test_booleanize()


# Generated at 2022-06-21 21:19:29.671570
# Unit test for function asciify
def test_asciify():
    """
    Test cases to ensure that function 'asciify' is working as expected

    >> test_asciify()
    """
    DEBUG = True


# Generated at 2022-06-21 21:19:40.956850
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    # assert __RomanNumbers.encode(2) == 'II'
    # assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __Roman

# Generated at 2022-06-21 21:19:44.974454
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('Reverse') == 'esreveR'
    assert reverse('.1a2b3c') == 'c3b2a1.'
    assert reverse('') == ''
    assert reverse(None) == None



# Generated at 2022-06-21 21:19:59.331469
# Unit test for function slugify
def test_slugify():
    print(slugify('This Is a Test Slugify: èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))
    print(slugify('This Is a Test Slugify: èéùúòóäåëýñÅÀÁÇÌÍÑÓË', '_'))
test_slugify()

#
# def __get_string_encoding(input_string: str) -> str:
#     """
#     Utility function to detect the given string encoding.
#     :param input_string: String to check
#     :return: String encoding (if detectable)
#     """
#     if not is_string(input_string):
#         raise InvalidInputError(input_string)

# Generated at 2022-06-21 21:20:10.388957
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('test this').format() == 'Test This'
    assert __StringFormatter('test; this').format() == 'Test; This'
    assert __StringFormatter('test: between: this').format() == 'Test: Between: This'
    assert __StringFormatter('test this     shit').format() == 'Test This Shit'
    assert __StringFormatter('  test  this    ').format() == 'Test This'
    assert __StringFormatter('this test  of  strictness').format() == 'This Test Of Strictness'
    assert __StringFormatter('this   test  of  strictness').format() == 'This Test Of Strictness'

# Generated at 2022-06-21 21:20:13.829562
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    class a:
        def __init__(self):
            self.x = "pippo"
    s = __StringFormatter(" ciaO a tutti ,    come stai? un po' meno bene oggi ")
    s = __StringFormatter(a())



# Generated at 2022-06-21 21:20:24.171222
# Unit test for function strip_html
def test_strip_html():
    """
    Test strip_html function
    """ 
    # print('TEST 1 strip_html')
    # # keep tag content is False, strip_html should remove tags and content
    # input_str = "test: <a href = 'foo/bar'> click here </a>"
    # expected_output = 'test: '
    # actual_output = strip_html(input_str)
    # assert actual_output == expected_output
    # print('Test passed!')
    
    # print('TEST 2 strip_html')
    # # keep tag content is True, strip_html should keep content but remove tags
    # input_str = "test: <a href = 'foo/bar'> click here </a>"
    # expected_output = 'test: click here'
    # actual_output = strip_html(input_str, True

# Generated at 2022-06-21 21:20:26.602888
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('  line 1\n  line 2\n  line 3') == 'line 1\nline 2\nline 3'

# Generated at 2022-06-21 21:20:30.128605
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') in ('he wdllorlo', 'hlwodl eorl', 'ldorw hlleo' 'hello world', 'lloor  lhwed', 'ohll wlredo')



# Generated at 2022-06-21 21:20:32.348500
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-21 21:20:37.136754
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    inputString = "  The &qUick <b> brown fox  Jumps.. Over > the  <i> lazy  dog </i> "
    string_formatter = __StringFormatter(inputString)
    print(string_formatter)


# Generated at 2022-06-21 21:20:44.864552
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert (camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test")
    assert (camel_case_to_snake("thisisacamelstringtest") == "thisisacamelstringtest")
    assert (camel_case_to_snake("this_is_a_camel_string_test") == "this_is_a_camel_string_test")
    assert (camel_case_to_snake("this is a camel string test") == "this is a camel string test")
    assert (camel_case_to_snake("ThisIsACamelStringTest", "-") == "this-is-a-camel-string-test")

# Generated at 2022-06-21 21:20:49.618912
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake') == 'Snake'
    assert snake_case_to_camel('snake', upper_case_first=False) == 'snake'
    assert snake_case_to_camel('snake_snake_snake', upper_case_first=False) == 'snakeSnakeSnake'



# Generated at 2022-06-21 21:20:56.931244
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('testing')



# Generated at 2022-06-21 21:20:58.488657
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert is_string(__StringFormatter("test").input_string)


# Generated at 2022-06-21 21:21:01.020647
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'



# Generated at 2022-06-21 21:21:04.729030
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:21:11.859900
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VI') == 6
    assert roman_decode('VIX') == 14
    assert roman_decode('LXXIX') == 79
    assert roman_decode('XIV') == 14
    assert roman_decode('LXIV') == 64
    assert roman_decode('MMXIV') == 2014
    assert roman_decode('MCMXCIV') == 1994



# Generated at 2022-06-21 21:21:13.724952
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'

# Generated at 2022-06-21 21:21:14.702701
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-21 21:21:18.386470
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert decompress(compressed) == original



# Generated at 2022-06-21 21:21:19.448800
# Unit test for function reverse
def test_reverse(): assert reverse('hello') == 'olleh'



# Generated at 2022-06-21 21:21:29.907530
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a href="foo/bar">foo</a>') == ''
    assert strip_html('<a href="foo/bar">foo</a>', keep_tag_content=True) == 'foo'
    assert strip_html('<a href="foo/bar">foo</a><br /><b>bar</b>') == ''
    assert strip_html('<a href="foo/bar">foo</a><br /><b>bar</b>', keep_tag_content=True) == 'foobar'

# Generated at 2022-06-21 21:21:45.598781
# Unit test for function asciify
def test_asciify():
    """
    Test fonction asciify

    :return: Test ok
    """
    try:
        test = asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')
        if test != "eeuuooaaeynAAACIINOE":
            return False
        test = asciify(5)
        return False
    except:
        return False

    return True



# Generated at 2022-06-21 21:21:49.460578
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('string with empty anchor <a> </a>') == 'string with empty anchor '
    assert strip_html('string with empty anchor <a> </a>', keep_tag_content=True) == 'string with empty anchor <a> </a>'



# Generated at 2022-06-21 21:22:00.294998
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # test for constructor of class __StringCompressor
    # which is a private class. It is not called by any exported method and is used only within this library.
    # We have to test it anyway because is the base of some public methods in the library.

    # test valid input

    # compress and decompress a valid string using default encoding
    encoded_string = __StringCompressor.compress('Hello')
    assert 'Hello' == __StringCompressor.decompress(encoded_string)

    # compress and decompress a valid string using custom encoding
    encoded_string = __StringCompressor.compress('Hello', 'latin1')
    assert 'Hello' == __StringCompressor.decompress(encoded_string, 'latin1')

    # test invalid input

    # An exception has to be raised for each invalid argument (Non-string input)


# Generated at 2022-06-21 21:22:05.176940
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert compressed == 'Phr9KfRa0T/TvcNhnsCCZEbJzfKZAtH0wQh/iJ/dGxtXJfVJ0o2+jKswG8I6lxU6nJU6'
    assert original == decompress(compressed)

# Generated at 2022-06-21 21:22:06.809042
# Unit test for function reverse
def test_reverse():
    assert reverse('abcde') == 'edcba'



# Generated at 2022-06-21 21:22:09.896351
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-21 21:22:20.473581
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:22:22.389792
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('yes')
    assert not booleanize('anythingelse')



# Generated at 2022-06-21 21:22:24.838249
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('this is a test')
    assert __StringFormatter('this is a test').input_string == 'this is a test'



# Generated at 2022-06-21 21:22:35.194367
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('arbitrary "string with\' escaped chars"') == 'arbitrary "string with\' escaped chars"'
    assert asciify('') == ''
    assert asciify('ààà') == 'aaa'
    assert asciify('1ààà') == '1aaa'
    assert asciify('ààà1') == 'aaa1'
    assert asciify('123456789') == '123456789'
    assert asciify('abcdefghijklmn') == 'abcdefghijklmn'

# Generated at 2022-06-21 21:22:56.328423
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
test_asciify()

# Generated at 2022-06-21 21:22:57.610830
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
# End of unit test



# Generated at 2022-06-21 21:23:04.686135
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    result = __StringFormatter("aBc").format()
    assert result == "Abc", "Error on line {}".format(lineno())

    result = __StringFormatter("Dr. John Doe's").format()
    assert result == "Dr. John Doe's", "Error on line {}".format(lineno())

    result = __StringFormatter("something@something.com").format()
    assert result == "something@something.com", "Error on line {}".format(lineno())

    result = __StringFormatter("mrs. jane doe").format()
    assert result == "Mrs. Jane Doe", "Error on line {}".format(lineno())

    result = __StringFormatter(" mr. john doe").format()
    assert result == "Mr. John Doe", "Error on line {}".format(lineno())
