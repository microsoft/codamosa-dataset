

# Generated at 2022-06-21 21:13:36.928885
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('“I was so shocked I’m still trying to recover.”') == '"I was so shocked I\'m still trying to recover."'
    assert asciify('I was so shocked I’m still trying to recover.') == 'I was so shocked I\'m still trying to recover.'
    assert asciify('一二三四五') == ''

# Generated at 2022-06-21 21:13:38.948017
# Unit test for function strip_margin
def test_strip_margin():
    input_string = strip_margin('''
        |line one
        |line two
        |line three
        ''')
    output_string = '''
line one
line two
line three
'''
    assert input_string == output_string

# Generated at 2022-06-21 21:13:41.641071
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    s = "Hello World!"
    c = __StringCompressor
    cs = c.compress(s)
    assert c.decompress(cs) == s
    assert c.decompress(s) == s



# Generated at 2022-06-21 21:13:48.700337
# Unit test for function prettify
def test_prettify():
    input_string = '  unprettified string ,, like this one,will be"prettified" .it\\'
    assert prettify(input_string) == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify(prettify(input_string)) == prettify(input_string)  # prettify of the prettified string is itself
    assert prettify(prettify(input_string + " it\\'s awesome!")) == prettify(input_string + " it\\'s awesome!")
    # assert prettify(prettify(input_string + " it\\'s awesome!")) == "Unprettified string, like this one, will be" \
    #                                                               " \"prettified\". It\'s awesome! it\'s awesome!"


# Generated at 2022-06-21 21:13:52.774435
# Unit test for function asciify
def test_asciify():
    utf8_string = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    result = asciify(utf8_string)
    expected = "eeuuooaaeynAAACIINOE"
    assert result == expected
    print("Teste ok")

# Generated at 2022-06-21 21:13:54.368600
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False

# Generated at 2022-06-21 21:13:55.591260
# Unit test for function slugify
def test_slugify():
    print (slugify('Top 10 Reasons To Love Dogs!!!'))
    print (slugify('Mönstér Mägnët'))


# Generated at 2022-06-21 21:13:58.528278
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()


# Generated at 2022-06-21 21:14:01.074680
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert(booleanize('YES') == True)
    assert(booleanize('nope') == False)

# Generated at 2022-06-21 21:14:04.726372
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-21 21:14:15.957247
# Unit test for function decompress
def test_decompress():
    """
    Test for stringcompressor.decompress()
    """
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    assert(decompress(compressed) == original)

# Generated at 2022-06-21 21:14:21.019619
# Unit test for function roman_decode

# Generated at 2022-06-21 21:14:31.996201
# Unit test for function slugify
def test_slugify():
    # Test: Only letters and numbers
    assert slugify('123abc') == '123abc'

    # Test: Only letters and numbers with spaces
    assert slugify('1 2 3 a b c') == '1-2-3-a-b-c'

    # Test: Empty string
    assert slugify('') == ''

    # Test: String starts with spaces
    assert slugify('  a') == 'a'

    # Test: String starts with a non-alphanumeric char
    assert slugify('-a') == 'a'

    # Test: String ends with spaces
    assert slugify('a  ') == 'a'

    # Test: String ends with a non-aplhanumeric char
    assert slugify('a  !') == 'a'

    # Test: Interspersed spaces

# Generated at 2022-06-21 21:14:44.104766
# Unit test for function decompress

# Generated at 2022-06-21 21:14:45.954839
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hi') == 'ih'
    assert reverse('') == ''
    assert reverse(' ') == ' '
    assert reverse('a') == 'a'



# Generated at 2022-06-21 21:14:51.117429
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    # "restored" will be equal to "original"
    restored = decompress(compressed)
    assert original == restored

# Generated at 2022-06-21 21:14:54.056009
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', separator='_') == 'monster_magnet'
    
test_slugify()


# Generated at 2022-06-21 21:14:56.753158
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    line 1
    line 2
    line 3
    ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-21 21:15:01.506915
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('hello') == 'hello'
    assert camel_case_to_snake('thisIsACamelString') == 'this_is_a_camel_string'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-21 21:15:05.420934
# Unit test for function prettify

# Generated at 2022-06-21 21:15:27.810966
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter("john doe's")
    string_formatter.format()


# Generated at 2022-06-21 21:15:39.217829
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert 'I' == __RomanNumbers.__encode_digit(0, 1)
    assert 'V' == __RomanNumbers.__encode_digit(0, 5)
    assert 'XIX' == __RomanNumbers.__encode_digit(1, 19)
    assert 'XXVI' == __RomanNumbers.__encode_digit(1, 26)
    assert 'XL' == __RomanNumbers.__encode_digit(1, 40)
    assert 'XC' == __RomanNumbers.__encode_digit(1, 90)

    assert 1 == __RomanNumbers.__reversed_mappings[0]['I']
    assert 5 == __RomanNumbers.__reversed_mappings[0]['V']
    assert 5 == __RomanNumbers.__reversed_mappings[1]['L']

# Generated at 2022-06-21 21:15:50.743979
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(38) == 'XXXVIII'
    assert roman_encode(39) == 'XXXIX'

# Generated at 2022-06-21 21:15:54.942211
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('y') == True
    assert booleanize('Yes') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('wrong') == False
    assert booleanize(None) == False

if __name__ == '__main__':
    test_booleanize()

# Generated at 2022-06-21 21:15:57.513099
# Unit test for function strip_html
def test_strip_html():
    input_string = 'test: <a href="foo/bar">click here</a>'
    output = strip_html(input_string)
    assert output == 'test: ', output

    output = strip_html(input_string, keep_tag_content=True)
    assert output == 'test: click here', output



# Generated at 2022-06-21 21:15:58.838845
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True


# Generated at 2022-06-21 21:16:00.699459
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify


# Generated at 2022-06-21 21:16:01.788255
# Unit test for function roman_encode
def test_roman_encode():
    assert (roman_encode(37)=='XXXVIII')
    assert (roman_encode('2020')=='MMXX')


# Generated at 2022-06-21 21:16:04.399422
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert len(original) > len(compressed)



# Generated at 2022-06-21 21:16:08.294074
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('someString') == 'some_string'
    assert camel_case_to_snake('someString', '-') == 'some-string'



# Generated at 2022-06-21 21:16:45.279416
# Unit test for function strip_html
def test_strip_html():
    # an empty string should be returned
    assert strip_html('') == ''

    # if input is not a string an exception should be raised
    with pytest.raises(InvalidInputError):
        strip_html(123)

    # test simple text
    assert strip_html('hello') == 'hello'

    # test html with no content
    assert strip_html('hello<br/>') == 'hello'

    # test html with content, but keep tag content flag disabled
    assert strip_html('hello<br/>there') == 'hellothere'

    # test html with content and keep tag content flag enabled
    assert strip_html('hello<br/>there', keep_tag_content=True) == 'hellothere'

    # test html with no tag, but keep tag content flag enabled

# Generated at 2022-06-21 21:16:58.129128
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:16:58.679493
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    pass

# Generated at 2022-06-21 21:17:01.559348
# Unit test for function decompress
def test_decompress():
    input_string = 'CgAMAAYAIABABgAgAEAAAAAIAAAAACAAgAEAAAAAABQAAAAAAAAAAAAAAAAAAAAAe6UGAAcHAQAACAk='
    original = decompress(input_string)
    expected = 'My name is Luo,Nice to meet you!'
    assert original == expected
test_decompress()

# Generated at 2022-06-21 21:17:12.844975
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-21 21:17:18.413554
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'A string that is long enough to test compression'
    compression = __StringCompressor.compress(input_string)
    decompression = __StringCompressor.decompress(compression)
    assert decompression == input_string

test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-21 21:17:26.734979
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __RomanNumbers.encode(14) == 'XIV'
    assert __RomanNumbers.encode(15) == 'XV'
    assert __

# Generated at 2022-06-21 21:17:38.749831
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(1, 5) == 'L'
    assert __RomanNumbers.__encode_digit(2, 5) == 'D'
    assert __RomanNumbers.__encode_digit(3, 5) == ''

    assert __RomanNumbers.__encode_digit(3, 9) == 'M'
    assert __RomanNumbers.__encode_digit(2, 9) == 'CM'
    assert __RomanNumbers.__encode_digit(1, 9) == 'XC'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'

    assert __RomanNumbers.__encode_digit(1, 4) == 'XL'
    assert __RomanNumbers.__encode_digit

# Generated at 2022-06-21 21:17:50.916502
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Test 1
    # Invalid input
    try:
        __StringFormatter([])
    except InvalidInputError:
        pass
    else:
        raise AssertionError("InvalidInputError not raised")

    # Test 2
    # input that does not need prettification
    input_string = "How are you today?"
    output = __StringFormatter(input_string).format()
    assert output == input_string

    # Test 3
    # input that does not need prettification
    input_string = "How are you today?"
    output = __StringFormatter(input_string).format()
    assert output == input_string

    # Test 4
    # input that need to have first char in uppercase
    input_string = "hello world"
    output = __StringFormatter(input_string).format()

# Generated at 2022-06-21 21:18:01.250118
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\\' s awesome! ') \
        == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('Unprettified string, like this one, will be "prettified". It\'s awesome!') \
        == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('Very good, Dave') == 'Very good, Dave'
    assert prettify('This is a "very" good example!') == 'This is a "very" good example!'
    assert prettify('This (is) a "very" good example!') == 'This (is) a "very" good example!'