

# Generated at 2022-06-21 21:13:28.281815
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('This is a test for prettify function, with some strange values:  some   , more@@@. ')
    assert sf.format() == 'This is a test for prettify function, with some strange values: some, more.'



# Generated at 2022-06-21 21:13:30.896389
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('ciao mondo') == 'ciao-mondo'



# Generated at 2022-06-21 21:13:32.440359
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XI') == 11


# Generated at 2022-06-21 21:13:38.115001
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('XIV') == 14
    assert roman_decode('CXXVIII') == 128
    assert roman_decode('MMXVII') == 2017
    assert roman_decode('Mil') == 1000
    assert roman_decode('MII') == 1002



# Generated at 2022-06-21 21:13:48.713507
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('SomeName') == 'some_name'
    assert camel_case_to_snake('SomeNameTest') == 'some_name_test'
    assert camel_case_to_snake('SomeNameTest', '-') == 'some-name-test'
    assert camel_case_to_snake('AnotherStringTest') == 'another_string_test'
    assert camel_case_to_snake('SomeName', '-') == 'some-name'
    assert camel_case_to_snake('SomeNameWithUppercase', '_') == 'some_name_with_uppercase'
    assert camel_case_to_snake('SomeNameWithUppercase', '-') == 'some-name-with-uppercase'



# Generated at 2022-06-21 21:13:52.663068
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    out = __StringFormatter(input_string='Hello, My name is david, I am a nice guy, please visit my website http://www.google.it or send me an email at  david@foo.com ')
    assert out.input_string == 'Hello, My name is david, I am a nice guy, please visit my website http://www.google.it or send me an email at  david@foo.com '


# Generated at 2022-06-21 21:13:54.738354
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    with pytest.raises(InvalidInputError):
        __StringFormatter('')

    with pytest.raises(InvalidInputError):
        __StringFormatter(1)

    __StringFormatter('a')



# Generated at 2022-06-21 21:13:58.465571
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(5) == 'V', 'Encoding of 5 failed.'
    assert __RomanNumbers.encode(10) == 'X', 'Encoding of 10 failed.'
    assert __RomanNumbers.encode(9) == 'IX', 'Encoding of 9 failed.'
    assert __RomanNumbers.encode(4) == 'IV', 'Encoding of 4 failed.'
    assert __RomanNumbers.encode(1954) == 'MCMLIV', 'Encoding of 1954 failed.'
    assert __RomanNumbers.encode(1990) == 'MCMXC', 'Encoding of 1990 failed.'
    assert __RomanNumbers.encode(2014) == 'MMXIV', 'Encoding of 2014 failed.'
    assert __RomanNumbers.decode('V') == 5, 'Decoding of V failed.'

# Generated at 2022-06-21 21:14:09.646941
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Hi').format() == 'Hi'
    assert __StringFormatter('Hi ').format() == 'Hi'
    assert __StringFormatter(' Hi').format() == 'Hi'
    assert __StringFormatter(' Hi ').format() == 'Hi'
    assert __StringFormatter(' Hi ').format() == 'Hi'
    assert __StringFormatter('thi s  is  a test').format() == 'Thi s is a test'
    assert __StringFormatter('this  is the  test').format() == 'This is the test'
    assert __StringFormatter('hello  world, this is the test').format() == 'Hello world, this is the test'
    assert __StringFormatter('http://www.google.com').format() == 'Http://www.google.com'

# Generated at 2022-06-21 21:14:15.645975
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('mysupertag') == 'mysupertag'
    assert strip_html('<p>Start</p>') == ''
    assert strip_html('<p class="myclass">Start</p>') == ''
    assert strip_html('<p id="myid">Start</p>') == ''
    assert strip_html('<p class="myclass">Start</p>', keep_tag_content=True) == 'Start'
    assert strip_html('<p class="myclass">Start <em>with</em> something</p>', keep_tag_content=True) == 'Start with something'

# Generated at 2022-06-21 21:14:26.531130
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('Y') == True
    assert booleanize('false') == False
    assert booleanize('nope') == False
    assert booleanize('foobar') == False


# Unit tests for function reverse

# Generated at 2022-06-21 21:14:31.450715
# Unit test for function slugify
def test_slugify():
    # Arrange
    _test_set = (
        ('Top 10 Reasons To Love Dogs!!!', 'top-10-reasons-to-love-dogs'),
        ('Mönstér Mägnët', 'monster-magnet'),
        ('Fooś bar', 'foo-bar'),
        ('全角ひらがなカタカナ漢字', '')
    )

    # Act
    _succeeded = True
    for input_string, expected_output in _test_set:
        output = slugify(input_string)
        if output != expected_output:
            _succeeded = False
            break

    # Assert
    assert _succeeded



# Generated at 2022-06-21 21:14:43.642922
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' Prova di lOrEm').format() == 'Prova di lorem'
    assert __StringFormatter('   Prova di lOrEm   ').format() == 'Prova di lorem'
    assert __StringFormatter('Prova,di,lOrEm').format() == 'Prova, di, lorem'
    assert __StringFormatter('Prova,di,lOrEm,').format() == 'Prova, di, lorem'
    assert __StringFormatter('http://www.prova.com').format() == 'http://www.prova.com'
    assert __StringFormatter('http://www.prova.com   ').format() == 'http://www.prova.com'

# Generated at 2022-06-21 21:14:47.674991
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    for i in range(100):
        original_string = str(uuid4())
        compressed_string = __StringCompressor.compress(original_string)
        assert original_string == __StringCompressor.decompress(compressed_string)


# PUBLIC API



# Generated at 2022-06-21 21:14:49.730788
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest', '') == 'thisisacamelstringtest'



# Generated at 2022-06-21 21:14:50.994880
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-21 21:15:01.146348
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Input: string to be compressed
    str_to_compress = 'Hello, World!'
    # Output: string after compression
    str_compressed = __StringCompressor.compress(str_to_compress)
    # Input: string after compression
    str_to_decompress = str_compressed
    # Output: string after decompression
    str_decompressed = __StringCompressor.decompress(str_to_decompress)

    # Check if output of compress and decompress are the same
    assert str_to_compress == str_decompressed


# PUBLIC API



# Generated at 2022-06-21 21:15:03.916473
# Unit test for function slugify
def test_slugify():

    test_cases = {
        'Top 10 Reasons To Love Dogs!!!': 'top-10-reasons-to-love-dogs',
        'Mönstér Mägnët': 'monster-magnet'
    }

    for input_string, expected_output in test_cases.items():
        out = slugify(input_string)
        assert out == expected_output



# Generated at 2022-06-21 21:15:06.735603
# Unit test for function strip_html
def test_strip_html():
    assert 'test: ' == strip_html('test: <a href="foo/bar">click here</a>')
    assert 'test: click here' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)


# Generated at 2022-06-21 21:15:09.274802
# Unit test for function roman_encode
def test_roman_encode():
    print('roman_encode() test')
    for i in range(1, 4000):
        print(roman_encode(i))



# Generated at 2022-06-21 21:15:22.055102
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(900) == 'CM'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(1004) == 'MIV'
    assert __RomanNumbers.encode(1006) == 'MVI'

# Generated at 2022-06-21 21:15:30.520455
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:15:40.900812
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'Hello, world ! \u2654'
    compressed_string = 'eJyr5iQolJQQDOIxAQAVeHwA'
    decoded_string = 'Hello, world ! ♔'

    assert __StringCompressor.decompress(__StringCompressor.compress(original_string)) == original_string
    assert __StringCompressor.compress(__StringCompressor.decompress(compressed_string)) == compressed_string
    assert __StringCompressor.decompress(__StringCompressor.compress(decoded_string)) == decoded_string
    assert __StringCompressor.compress(__StringCompressor.decompress(original_string)) == __StringCompressor.compress(original_string)


# PUBLIC API



# Generated at 2022-06-21 21:15:42.197036
# Unit test for function slugify
def test_slugify():
    assert('this-is-a-test' == slugify('This is   a tést'))
    assert('sara-ella' == slugify('Sara ELLA'))



# Generated at 2022-06-21 21:15:52.696414
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' abc ').format() == 'abc'
    assert __StringFormatter(' abc  ').format() == 'abc'
    assert __StringFormatter(' abc   ').format() == 'abc'
    assert __StringFormatter('  abc  ').format() == 'abc'
    assert __StringFormatter('  abc   ').format() == 'abc'
    assert __StringFormatter('   abc   ').format() == 'abc'
    assert __StringFormatter('abc').format() == 'abc'
    assert __StringFormatter('!abc!').format() == '!abc!'
    assert __StringFormatter('! abc !').format() == '! abc !'
    # ensure duplicate spaces are collapsed

# Generated at 2022-06-21 21:15:57.556387
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('test data') == 'eJyVUdFq2zAQB/Be8/wBZiU/ZtnEj7VYvY8uLsVjKiECm'
    assert __StringCompressor.decompress('eJyVUdFq2zAQB/Be8/wBZiU/ZtnEj7VYvY8uLsVjKiECm') == 'test data'

test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-21 21:15:58.488926
# Unit test for function slugify
def test_slugify():
    assert slugify("Hello world") == "hello-world"
# End of unit test for function slugify


# Generated at 2022-06-21 21:16:00.087357
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake(1234) == '1234'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-21 21:16:11.525975
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __RomanNumbers.encode(13) == 'XIII'
    assert __RomanNumbers.encode(14) == 'XIV'

# Generated at 2022-06-21 21:16:15.124400
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello worldd'
    assert shuffle('hello worlddd') != 'hello world'
    assert len(shuffle('hello world')) == len('hello world')

shuffle('hello world')



# Generated at 2022-06-21 21:16:22.129128
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(10)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert original == decompressed



# Generated at 2022-06-21 21:16:24.559541
# Unit test for function decompress
def test_decompress():
    s = compress("This is a test string")
    assert decompress(s) == "This is a test string"

test_decompress()



# Generated at 2022-06-21 21:16:25.725465
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('abc') != 'abc'



# Generated at 2022-06-21 21:16:28.749482
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
   assert __StringCompressor().__require_valid_input_and_encoding('\U0001f638', 'utf-8')


# PUBLIC API



# Generated at 2022-06-21 21:16:33.056586
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('Hi John, my email is john.pippo@example.com, please check http://www.john.com')
    assert f.format() == 'Hi John, my email is john.pippo@example.com, please check http://www.john.com'



# Generated at 2022-06-21 21:16:36.741817
# Unit test for function compress
def test_compress():
    original = 'My beautiful string'
    compressed = __StringCompressor.compress(original)
    assert __StringCompressor.decompress(compressed) == original


# Generated at 2022-06-21 21:16:44.814546
# Unit test for function asciify
def test_asciify():
    """
    Test if function asciify behaves as expected
    """
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ç') == 'c'
    assert asciify('Ç') == 'C'
    assert asciify('æ') == ''
    assert asciify('æÞþ') == ''
    assert asciify('') == ''
    
    

# Generated at 2022-06-21 21:16:48.673694
# Unit test for function prettify

# Generated at 2022-06-21 21:16:59.725350
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # test encode()
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'


# Generated at 2022-06-21 21:17:02.829165
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    import pytest

    assert isinstance(__StringCompressor, type)
    assert issubclass(__StringCompressor, object)

    # The constructor has to be protected and therefore cannot be called explicitly
    with pytest.raises(TypeError):
        __StringCompressor()


#
# PUBLIC API
#



# Generated at 2022-06-21 21:17:08.290368
# Unit test for function slugify
def test_slugify():
    # Assert on purpose
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-21 21:17:15.374860
# Unit test for function shuffle
def test_shuffle():
    chars = string.ascii_letters + string.digits
    input_string = ''.join([random.choice(chars) for _ in range(0, 10)])
    shuffled = shuffle(input_string)

    if len(input_string) != len(shuffled):
        raise AssertionError('Input and Shuffled strings have different lengths')

    if sorted(input_string) != sorted(shuffled):
        raise AssertionError('Input and Shuffled strings have different chars')



# Generated at 2022-06-21 21:17:25.615494
# Unit test for function roman_encode

# Generated at 2022-06-21 21:17:28.293723
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('foo  bar').format() == 'Foo bar'
# PUBLIC API



# Generated at 2022-06-21 21:17:39.626822
# Unit test for function slugify
def test_slugify():
    assert slugify('Viva la Bamba') == 'viva-la-bamba'
    assert slugify('Ce sku-ta la diabla') == 'ce-skuta-la-diabla'
    assert slugify('Rata Tatuta') == 'rata-tatuta'
    assert slugify('Ce sku-ta la diabla') == 'ce-skuta-la-diabla'
    assert slugify('Viva la Bamba') == 'viva-la-bamba'
    assert slugify('Ce sku-ta la diabla') == 'ce-skuta-la-diabla'
    assert slugify('Rata Tatuta') == 'rata-tatuta'

# Generated at 2022-06-21 21:17:51.837372
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'

# Generated at 2022-06-21 21:17:56.213244
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'




# Generated at 2022-06-21 21:18:04.772980
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('V') == 5
    assert roman_decode('X') == 10
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000
    assert roman_decode('VII') == 7
    assert roman_decode('XL') == 40
    assert roman_decode('IX') == 9
    assert roman_decode('XXIX') == 29
    try:
        roman_decode('a')
        assert False
    except InvalidRomanNumberError:
        assert True

# Generated at 2022-06-21 21:18:10.507393
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'

test_strip_html()


# Generated at 2022-06-21 21:18:14.215833
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-21 21:18:29.676251
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('V') == 5
    assert roman_decode('III') == 3
    assert roman_decode('MCMXCIX') == 1999
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('MDCCCXX') == 1820
    assert roman_decode('MMM') == 3000
    assert roman_decode('MCCCXXX') == 1330
    assert roman_decode('XVI') == 16
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000
    assert roman_decode('LXVII') == 67
    assert roman_decode('XXXIX') == 39
   

# Generated at 2022-06-21 21:18:37.202330
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __RomanNumbers

# Generated at 2022-06-21 21:18:47.663267
# Unit test for function roman_encode
def test_roman_encode():
    cases = [
        (0, None),
        (4000, None),
        (1, 'I'),
        (3, 'III'),
        (4, 'IV'),
        (5, 'V'),
        (9, 'IX'),
        (10, 'X'),
        (40, 'XL'),
        (50, 'L'),
        (90, 'XC'),
        (100, 'C'),
        (400, 'CD'),
        (500, 'D'),
        (900, 'CM'),
        (1000, 'M'),
        ('2020', 'MMXX'),
        ('3999', 'MMMCMXCIX'),
    ]

    for case in cases:
        input_number = case[0]
        expected = case[1]
        result = roman_encode(input_number)


# Generated at 2022-06-21 21:18:50.359926
# Unit test for function reverse
def test_reverse():
    assert reverse('Hello') == 'olleH'
    assert reverse('0') == '0'
    assert reverse('') == ''



# Generated at 2022-06-21 21:18:51.764295
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-21 21:18:58.230718
# Unit test for function booleanize
def test_booleanize():
    assert (booleanize('true') == True)
    assert (booleanize('TRUE') == True)
    assert (booleanize('True') == True)
    assert (booleanize('1') == True)
    assert (booleanize('yes') == True)
    assert (booleanize('y') == True)
    assert (booleanize('false') == False)
    assert (booleanize('False') == False)
    assert (booleanize('FALSE') == False)
    assert (booleanize('0') == False)
    assert (booleanize('no') == False)
    assert (booleanize('n') == False)
    assert (booleanize('nop') == False)
    assert (booleanize('nope') == False)
    assert (booleanize('yup') == False)

# Generated at 2022-06-21 21:19:00.722272
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter('one two    three')
    assert formatter.input_string == 'ONE two    three'


# Generated at 2022-06-21 21:19:01.653788
# Unit test for function compress
def test_compress():
    from .test_utils import TestUtils
    assert TestUtils.compress_test()

# Unit test

# Generated at 2022-06-21 21:19:10.110093
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('one two').format() == 'one two'
    assert __StringFormatter('one two Three four').format() == 'One Two Three Four'
    assert __StringFormatter('one two').format() == 'One Two'
    assert __StringFormatter('One two').format() == 'One Two'
    assert __StringFormatter('One Two').format() == 'One Two'
    assert __StringFormatter('One Two').format() == 'One Two'
    assert __StringFormatter('One Two three').format() == 'One Two Three'
    assert __StringFormatter('One Two Three').format() == 'One Two Three'
    assert __StringFormatter('one  two').format() == 'One Two'
    assert __StringFormatter('one two ').format() == 'One Two'

# Generated at 2022-06-21 21:19:15.868579
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('49') == 'XLIX'
    assert roman_encode('159') == 'CLIX'
    assert roman_encode('2010') == 'MMX'
    assert roman_encode(3901) == 'MMMCMI'



# Generated at 2022-06-21 21:19:36.132939
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('True') == True
    assert booleanize('YES') == True
    assert booleanize('y') == True
    assert booleanize('1') == True
    assert booleanize('false') == False
    assert booleanize('False') == False
    assert booleanize('NO') == False
    assert booleanize('n') == False
    assert booleanize('0') == False
    assert booleanize('YaY') == False


# Provided unit test
import unittest
import random
from functools import reduce


# Generated at 2022-06-21 21:19:41.458729
# Unit test for function prettify
def test_prettify():
    unpretty=' unprettified string ,, like this one,will be"prettified" .it\\'

    assert unpretty.prettify()=='Unprettified string, like this one, will be "prettified". It\\\'s'
    assert unpretty!=unpretty.prettify()
# End unit test for function prettify



# Generated at 2022-06-21 21:19:49.034404
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter(None)
    except InvalidInputError as e:
        assert str(e) == 'Input value must be a string'

    try:
        __StringFormatter(123)
    except InvalidInputError as e:
        assert str(e) == 'Invalid input: "123"'
    
    try:
        __StringFormatter([2, 3])
    except InvalidInputError as e:
        assert str(e) == 'Invalid input: "[2, 3]"'

    try:
        __StringFormatter({1: 0})
    except InvalidInputError as e:
        assert str(e) == 'Invalid input: "{1: 0}"'


# Generated at 2022-06-21 21:19:57.000628
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings[0][1] == 'I'
    assert __RomanNumbers.__mappings[0][5] == 'V'
    assert __RomanNumbers.__mappings[1][1] == 'X'
    assert __RomanNumbers.__mappings[1][5] == 'L'
    assert __RomanNumbers.__mappings[2][1] == 'C'
    assert __RomanNumbers.__mappings[2][5] == 'D'
    assert __RomanNumbers.__mappings[3][1] == 'M'


# Generated at 2022-06-21 21:20:07.991046
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    try:
        # make sure that method raises a ValueError when null value is provided
        __StringCompressor.compress(None)
        assert False

    except InvalidInputError:
        assert True

    try:
        # make sure that method raises a ValueError when empty string is provided
        __StringCompressor.compress('')
        assert False

    except ValueError:
        assert True

    try:
        # make sure that method raises a ValueError when invalid encoding type is provided
        __StringCompressor.compress('', 1)
        assert False

    except ValueError:
        assert True

test___StringCompressor() # run unit tests


# PUBLIC API



# Generated at 2022-06-21 21:20:15.767564
# Unit test for function strip_html
def test_strip_html():
    strings = ["<a href='#'>Some Link</a>", '<input value="some value"/>', '<div id="main"><span>within</span></div>']

    for s in strings:
        assert strip_html(s) == ''
        assert strip_html(s, keep_tag_content=True) == 'Some Link'
        assert strip_html(s, keep_tag_content=True) == 'some value'
        assert strip_html(s, keep_tag_content=True) == 'within'



# Generated at 2022-06-21 21:20:18.999757
# Unit test for function asciify
def test_asciify():
    print('asciifys')
    print(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')) # returns 'eeuuooaaeynAAACIINOE'

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


# Generated at 2022-06-21 21:20:31.765869
# Unit test for function decompress
def test_decompress():
    c = compress("")
    assert c == ""

    c = compress(" ", compression_level=6)
    assert c == " "

    c = compress("ciao", compression_level=6)
    assert c == "ciao"

    c = compress(" ", compression_level=0)
    assert c == " "

    c = compress("ciao", compression_level=0)
    assert c == "ciao"

    c = compress("ciao", compression_level=9)
    assert c == "ciao"

    c = compress("ciao", encoding="latin-1", compression_level=9)
    assert c == "ciao"

    c = compress(" ", encoding="latin-1", compression_level=9)
    assert c == " "

    c = compress(" ", compression_level=9)
    assert c

# Generated at 2022-06-21 21:20:37.006394
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'
    assert strip_html('<a href="foo/bar"><strong>click <span>here</span></strong></a>', keep_tag_content=True) \
        == 'click here'
    assert strip_html('<a href="foo/bar"><strong>click <span>here</span></strong></a>', keep_tag_content=False) == ''
    assert strip_html('This has no html') == 'This has no html'



# Generated at 2022-06-21 21:20:39.870415
# Unit test for function shuffle
def test_shuffle():
    for i in range(0, 100):
        should_be_equal(1, 1)
        should_not_be_equal(1, 2)
        should_not_be_equal(shuffle('Hello World'), 'Hello World')



# Generated at 2022-06-21 21:20:51.582977
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:20:53.182916
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
                    line 1
                    line 2
                    line 3
                    '''
    expected_string = '''
    line 1
    line 2
    line 3
    '''
    assert(strip_margin(input_string) == expected_string)



# Generated at 2022-06-21 21:20:58.594583
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999


# PUBLIC API



# Generated at 2022-06-21 21:21:08.132231
# Unit test for constructor of class __RomanNumbers

# Generated at 2022-06-21 21:21:12.484269
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])

    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    # decompress the compressed string (must be equal to the original)
    assert original == decompress(compressed)



# Generated at 2022-06-21 21:21:15.457998
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('') == ''
    assert reverse('e') == 'e'



# Generated at 2022-06-21 21:21:26.553925
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('1') == 'I'
    assert roman_encode('3') == 'III'
    assert roman_encode('4') == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode('9') == 'IX'
    assert roman_encode('10') == 'X'
    assert roman_encode('13') == 'XIII'
    assert roman_encode('14') == 'XIV'
    assert roman_encode('30') == 'XXX'
    assert roman_encode('40') == 'XL'
    assert roman_encode('90') == 'XC'
    assert roman_encode('100') == 'C'
    assert roman_encode('400') == 'CD'
   

# Generated at 2022-06-21 21:21:29.775586
# Unit test for function strip_margin
def test_strip_margin():
    lines = strip_margin('''
        |foo
        |bar
        |baz
        ''')
    lines.split('\n') == ['foo', 'bar', 'baz']


# Generated at 2022-06-21 21:21:35.192335
# Unit test for function compress
def test_compress():
    assert compress("test") == "eJzTZz00LslSz0ctJLSwMKEgqyU4MLE4NzNXSU5Iy85NFEtWjA5NzQtNc/PK2EuChWb"


# Generated at 2022-06-21 21:21:45.795512
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('truE') == True
    assert booleanize('TRue') == True
    assert booleanize('TRuE') == True
    assert booleanize('TRUe') == True
    assert booleanize('TRUe') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('Yes') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('no') == False
    assert booleanize('NO') == False
    assert booleanize('0') == False
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('FaLse') == False

# Generated at 2022-06-21 21:22:06.135131
# Unit test for function strip_html
def test_strip_html():
    assert(strip_html('test: <a href="foo/bar">click here</a>') == 'test: ')
    assert(strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here')



# Generated at 2022-06-21 21:22:17.775229
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    inputs = [
        'The game',
        ' the game Ohh ! ',
        'The God of War',
        'The Gods war',
        'The Gods\'s   war',
        'The Gods\'s-war',
        'The gods  @ war',
        'the.god@of.war',
        'https://github.com/psf/black',
        'https://github.com/tensorflow/tensorflow/blob/master/tensorflow/python/ops/rnn.py',
        '🍾  🍾',
        '  🍾  🍾  ',
        '  🍾  🍾  ',
    ]

# Generated at 2022-06-21 21:22:25.898935
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('my_string') == 'MyString'
    assert snake_case_to_camel('my_string', False) == 'myString'
    assert snake_case_to_camel('1_string') == '1String'
    assert snake_case_to_camel('1_string', False) == '1String'
    assert snake_case_to_camel('w/o_separator') == 'W/OSeparator'
    assert snake_case_to_camel('w/o_separator', False) == 'w/OSeparator'
    assert snake_case_to_camel('a_multi_word_string', separator='-') == 'AMultiWordString'

# Generated at 2022-06-21 21:22:32.790926
# Unit test for function booleanize
def test_booleanize():
    res = booleanize('true')
    assert res==True
    res = booleanize('1')
    assert res==True
    res = booleanize('yes')
    assert res==True
    res = booleanize('y')
    assert res==True
    res = booleanize('false')
    assert res==False
    res = booleanize('0')
    assert res==False
    res = booleanize('No')
    assert res==False
    res = booleanize('N')
    assert res==False

# Generated at 2022-06-21 21:22:39.245851
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():

    # testing compress()
    if 'foo' != __StringCompressor.decompress(__StringCompressor.compress('foo')):
        raise Exception('Constructor test for __StringCompressor failed')

    # testing decompress()
    if 'foo' != __StringCompressor.decompress(__StringCompressor.compress('foo')):
        raise Exception('Constructor test for __StringCompressor failed')


# PUBLIC API



# Generated at 2022-06-21 21:22:52.835170
# Unit test for function prettify

# Generated at 2022-06-21 21:23:03.670708
# Unit test for function booleanize
def test_booleanize():
    assert( booleanize('true') == True )
    assert( booleanize('yes') == True )
    assert( booleanize('y') == True )
    assert( booleanize('1') == True )

    
    assert( booleanize('true1') == False )
    assert( booleanize('yes1') == False )
    assert( booleanize('y1') == False )
    assert( booleanize('2') == False )
    assert( booleanize('no') == False )
    assert( booleanize('n') == False )
    assert( booleanize('false') == False )
    assert( booleanize('f') == False )

    assert( booleanize(['test']) == False )

    assert( booleanize('true') is True )
    assert( booleanize('no') is False )
    assert( booleanize('true1') is False )

# Generated at 2022-06-21 21:23:06.070491
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False

