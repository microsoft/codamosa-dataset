

# Generated at 2022-06-21 21:13:35.959086
# Unit test for function prettify

# Generated at 2022-06-21 21:13:43.402920
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('test1') == 'eNpVUdF6kzAMhe_iwKn8mBklVK7hjsKiU5z6Zu8lUxVxXfk6bRn7f1NthNllh7nPJNnZ3N_Z3d3ZxNDbyg-kv0Bj3H8qcTzaT2T2TtRl0tL8Jt_4A4P4oO4vsdggbSUoJIw0KE1DfLy1-aAQ8ZcPODoXeAa-LpJyKl8AAVWf78'

# Generated at 2022-06-21 21:13:47.461316
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    from .testing import assert_test_case_equals

    def __test(test_case):
        assert_test_case_equals(__StringFormatter(test_case['input']).format(), test_case['expected'])


# Generated at 2022-06-21 21:13:49.268272
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(__StringCompressor.compress('Hello world!')) == 'Hello world!'


# PUBLIC API



# Generated at 2022-06-21 21:13:51.139979
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'



# Generated at 2022-06-21 21:13:55.420818
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-21 21:13:58.195211
# Unit test for function compress
def test_compress():
    input_string=' '.join(['word n{}'.format(n) for n in range(20)])
    assert len(input_string) == 169
    assert len(compress(input_string)) == 88


# Generated at 2022-06-21 21:14:08.750737
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('', False) == ''
    assert snake_case_to_camel('', True) == ''
    assert snake_case_to_camel('the_snake') == 'TheSnake'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'The-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', True, ' ') == 'The snake is green'



# Generated at 2022-06-21 21:14:11.669707
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:14:16.741258
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!") == "top-10-reasons-to-love-dogs"
    assert slugify("Test - test") == "test-test"
    
if __name__ == "__main__":
    test_slugify()

# Generated at 2022-06-21 21:14:31.945221
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<a href="https://www.google.com">Google</a>', keep_tag_content=True) == 'Google'
    assert strip_html('<a href="https://www.google.com">Google</a>', keep_tag_content=False) == ''
    assert strip_html('<p>Hello world!</p>', keep_tag_content=True) == 'Hello world!'
    assert strip_html('<p>Hello world!</p>', keep_tag_content=False) == ''
    assert strip_html('<div style="color:blue">Hello world!</div>', keep_tag_content=True) == 'Hello world!'
    assert strip_html('<div style="color:blue">Hello world!</div>', keep_tag_content=False) == ''



# Generated at 2022-06-21 21:14:35.480193
# Unit test for function reverse
def test_reverse():
    try:
        reverse(None)
        assert False
    except InvalidInputError:
        assert True
    assert reverse('hello') == 'olleh'
    assert reverse('abc') == 'cba'



# Generated at 2022-06-21 21:14:43.889198
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-21 21:14:49.331797
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XXI') == 21
    assert roman_decode('XX') == 20
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13

# Generated at 2022-06-21 21:15:01.603016
# Unit test for function prettify
def test_prettify():
  # Test 1
  test_str1 = '  this,is a   test! string?with, \n\n errors   '
  sol1 = 'This, is a test! String? With, errors'
  assert (prettify(test_str1) == sol1)

  # Test 2
  test_str2 = 'this, is  a  test!\nstring?  with,\nerrors.  '
  sol2 = 'This, is a test! String? With, errors.'
  assert (prettify(test_str2) == sol2)

  # Test 3
  test_str3 = 'this, is  a  test!\nstring?  with,\nerrors.  '
  sol3 = 'This, is a test! String? With, errors.'

# Generated at 2022-06-21 21:15:08.208710
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('-ThisIsACamelStringTest') == '-this_is_a_camel_string_test'
    assert camel_case_to_snake('.ThisIsACamelStringTest') == '.this_is_a_camel_string_test'
    assert camel_case_to_snake('_ThisIsACamelStringTest') == '_this_is_a_camel_string_test'
    assert camel_case_to_snake('This Is A Camel String Test') == 'this is a camel string test'



# Generated at 2022-06-21 21:15:11.844498
# Unit test for function shuffle
def test_shuffle():
    input_string = 'hello world'
    shuffled_string = shuffle(input_string)
    if input_string == shuffled_string:
        print( 'Fail')
    else:
        print('Pass')

test_shuffle()


# Generated at 2022-06-21 21:15:21.845438
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from hypothesis import given, strategies as st
    from .validation import is_compressed

    @given(st.text())
    def test_compress(input_string):
        output = __StringCompressor.compress(input_string)

        assert is_compressed(output)
        assert input_string == __StringCompressor.decompress(output)

    @given(st.text(min_size=1))
    def test_decompress(input_string):
        original_string = __StringCompressor.decompress(input_string)

        assert is_full_string(original_string)
        assert input_string == __StringCompressor.compress(original_string)

    test_compress()
    test_decompress()


# PUBLIC API



# Generated at 2022-06-21 21:15:24.784280
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-21 21:15:29.880012
# Unit test for function decompress
def test_decompress():
    data = ' '.join(['word n{}'.format(n) for n in range(20)])
    res = decompress(compress(data))
    assert data == res

# Generated at 2022-06-21 21:15:39.221701
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello ') == ' olleh'
    assert reverse(' hello') == 'olleh '
    assert reverse(' hello ') == ' olleh '
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('hello world ') == ' dlrow olleh'
    assert reverse(' hello world') == 'dlrow olleh '
    assert reverse(' hello world ') == ' dlrow olleh '



# Generated at 2022-06-21 21:15:46.729691
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress("test string") == "eNpLS8svy08wzE0NTg1NDI2MjQ0TkzNTZfNy_MSgRINxMgKSs_IB1JSlA"
    assert __StringCompressor.decompress("eNpLS8svy08wzE0NTg1NDI2MjQ0TkzNTZfNy_MSgRINxMgKSs_IB1JSlA") == "test string"

# TEST

# Generated at 2022-06-21 21:15:48.692883
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-21 21:15:49.679173
# Unit test for function slugify
def test_slugify():
    out = slugify('Top 10 Reasons To Love Dogs!!!')
    print(out)



# Generated at 2022-06-21 21:15:52.659799
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    _in = 'aaaaa bbbbbb ccccccc'
    out = 'Aaaaa bBbbbbb cCcccccc'
    sf = __StringFormatter(_in)
    assert sf.format() == out


# Generated at 2022-06-21 21:15:56.606147
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('ThisIsACamelStringTest') == 'ThisIsACamelStringTest'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'The-Snake-Is-Green'



# Generated at 2022-06-21 21:16:02.505491
# Unit test for function compress
def test_compress():

    def test_compress_assert_that(compressed, expected):
        assert_that(compressed).is_equal_to(expected)

    def test_compress_throws_assert_that(value, expected):
        assert_that(calling(compress).with_args(value)).raises(expected)

    test_compress_assert_that(compress('test'), 'eJzT0M0RgzA0AJI_JhQrK0gH')
    test_compress_assert_that(compress('test', 'euc-kr'), 'eJzzS0s9S04zAKKpPgvL6w==')
    test_compress_throws_assert_that('', ValueError)
    test_compress_throws_assert_that(None, InvalidInputError)
    test

# Generated at 2022-06-21 21:16:14.009224
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True, 'Test 1 failed'
    assert booleanize('True') == True, 'Test 2 failed'
    assert booleanize('') == False, 'Test 3 failed'
    assert booleanize('TRUE') == True, 'Test 4 failed'
    assert booleanize('1') == True, 'Test 5 failed'
    assert booleanize('yes') == True, 'Test 6 failed'
    assert booleanize('YES') == True, 'Test 7 failed'
    assert booleanize('y') == True, 'Test 8 failed'
    assert booleanize('Y') == True, 'Test 9 failed'
    assert booleanize('0') == False, 'Test 10 failed'
    assert booleanize('no') == False, 'Test 11 failed'
    assert booleanize('n') == False, 'Test 12 failed'

# Generated at 2022-06-21 21:16:20.590123
# Unit test for function strip_html
def test_strip_html():
    test_cases = [
        ('test: <a href="foo/bar">click here</a>', 'test: '),
        ('test: <a href="foo/bar">click here</a>', 'test: click here', True),
        ('<p>this is a text</p>', 'this is a text', True),
        ('<p>this is a text</p>', ''),

    ]
    for t in test_cases:
        out = strip_html(t[0], t[2]) if len(t) == 3 else strip_html(t[0])
        assert out == t[1], 'Error while stripping html in "{}"'.format(t[0])



# Generated at 2022-06-21 21:16:31.133801
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode(1) == 'I'
    assert roman_encode(5) == 'V'
    assert roman_encode(10) == 'X'
    assert roman_encode(50) == 'L'
    assert roman_encode(100) == 'C'
    assert roman_encode(500) == 'D'
    assert roman_encode(1000) == 'M'
    assert roman_encode(4000) == 'IV'
    assert roman_encode(900) == 'CM'
    assert roman_encode(99) == 'XCIX'

# Generated at 2022-06-21 21:16:41.057666
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-21 21:16:43.658314
# Unit test for function prettify

# Generated at 2022-06-21 21:16:53.383379
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify('-') == ''
    assert slugify(' - ') == ''
    assert slugify('a') == 'a'
    assert slugify('a ') == 'a'
    assert slugify(' a') == 'a'
    assert slugify(' a ') == 'a'
    assert slugify('a-') == 'a'
    assert slugify('-a') == 'a'
    assert slugify('-a-') == 'a'
    assert slugify('-a-a-') == 'a-a'
    assert slugify('a b c') == 'a-b-c'
    assert slugify('a - b - c') == 'a-b-c'
    assert slugify('a - b - c -') == 'a-b-c'
   

# Generated at 2022-06-21 21:16:54.597470
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7


# Generated at 2022-06-21 21:17:01.172193
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIs_a_CamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-21 21:17:03.857601
# Unit test for function shuffle
def test_shuffle():
    sample_array = ['hello world','Hello World','1234567890']
    for s in sample_array:
        if(s == shuffle(s)):
            print("test failed")
            return
    print("test passed")
test_shuffle()



# Generated at 2022-06-21 21:17:07.476185
# Unit test for function strip_margin
def test_strip_margin():
    test_string = '''
               line 1
               line 2
               line 3
               '''
    expected_string = '''
line 1
line 2
line 3
'''

    assert expected_string == strip_margin(test_string)


# Generated at 2022-06-21 21:17:10.131581
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
test_camel_case_to_snake()



# Generated at 2022-06-21 21:17:13.539722
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings == [
        # units
        {1: 'I', 5: 'V'},
        # tens
        {1: 'X', 5: 'L'},
        # hundreds
        {1: 'C', 5: 'D'},
        # thousands
        {1: 'M'},
    ]


# Generated at 2022-06-21 21:17:19.712932
# Unit test for function roman_encode
def test_roman_encode():
  assert roman_encode('3') == 'III'
  assert roman_encode(2) == 'II'
  assert roman_encode(29) == 'XXIX'
  assert roman_encode(37) == 'XXXVII'
  assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-21 21:17:39.463088
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello   world ').format() == 'Hello world'
    assert __StringFormatter('Hello world!!').format() == 'Hello world!'
    assert __StringFormatter('Hello world, how are you?').format() == 'Hello world, how are you?'
    assert __StringFormatter('Hello world, how are you today??').format() == 'Hello world, how are you today?'
    assert __StringFormatter('i watched the new episode of the #gameofthrones...').format() == 'I watched the new episode of the #GameOfThrones...'
    assert __StringFormatter('i\'ve watched the new episode of the #gameofthrones...').format() == 'I\'ve watched the new episode of the #GameOfThrones...'
    assert __StringFormatter('it\'s friday and i\'m happy').format()

# Generated at 2022-06-21 21:17:47.365641
# Unit test for function slugify
def test_slugify():
    slugs = [
        ('The World according to Garp', 'the-world-according-to-garp'),
        ('Mönstér Mägnët', 'monster-magnet'),
        ('Top 10 Reasons To Love Dogs!!!', 'top-10-reasons-to-love-dogs'),
        ('!@#$%^&*()_+', '')
    ]

    for s in slugs:
        assert slugify(s[0]) == s[1]



# Generated at 2022-06-21 21:17:48.890312
# Unit test for function compress
def test_compress():
    assert compress('y') == 'eJwNAAAAAAAAAAAAAAAAAAAA'


# Generated at 2022-06-21 21:17:52.698777
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('blah <a href="foo/bar">click here</a>') == 'blah '
    assert strip_html('blah <a href="foo/bar">click here</a>', keep_tag_content=True) == 'blah click here'



# Generated at 2022-06-21 21:17:57.552892
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    """
    >>> test___RomanNumbers()
    """
    classname = '__RomanNumbers'

    # check if class has a proper name
    assert classname == __RomanNumbers.__name__, 'class does not have the proper name'

    # check if it is a public class
    assert classname[0] != '_', 'class is not public'

roman_encode = __RomanNumbers.encode
roman_decode = __RomanNumbers.decode


# PUBLIC API



# Generated at 2022-06-21 21:18:04.869202
# Unit test for function strip_html
def test_strip_html():
    input_string = 'test: <a href="foo/bar">click here</a>'
    result = strip_html('test: <a href="foo/bar">click here</a>')
    exp = 'test: '
    assert result == exp, 'Result: {} Expected: {}'.format(result, exp)
    input_string = 'test: <a href="foo/bar">click here</a>'
    result = strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)
    exp = 'test: click here'
    assert result == exp, 'Result: {} Expected: {}'.format(result, exp)
test_strip_html()



# Generated at 2022-06-21 21:18:08.921130
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37)    == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
test_roman_encode()



# Generated at 2022-06-21 21:18:15.830791
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELLO') == 'OLLEH'
    assert reverse('hEllO') == 'OlleH'
    assert reverse('01234') == '43210'
    assert reverse('abc-abc') == 'cba-cba'
    assert reverse('') == ''
    assert reverse('1') == '1'



# Generated at 2022-06-21 21:18:22.750346
# Unit test for function asciify
def test_asciify():
    print("Testing asciify_func...")
    assert(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE")
    print("Test passed")

test_asciify()

from unittest import TestCase
from unittest.mock import patch

# Generated at 2022-06-21 21:18:26.933154
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:18:45.546611
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true")
    assert booleanize("yes")
    assert booleanize("YES")
    assert not booleanize("blah")
    assert not booleanize("tr")
    assert not booleanize("yess")

test_booleanize()


# Generated at 2022-06-21 21:18:49.916828
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Given
    input_string = r"""
    this \₁is a test
    split
    on multiple lines
    """
    expected_output = r"""this is a test split on multiple lines"""

    # When
    actual_output = __StringFormatter(input_string).format()

    # Then
    assert actual_output == expected_output


# Generated at 2022-06-21 21:18:52.944799
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert original==decompressed



# Generated at 2022-06-21 21:19:05.156679
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Just a simple string to be prettified').format() == 'Just a simple string to be prettified'
    assert __StringFormatter('Just a sImple string to be prettIFied').format() == 'Just a simple string to be prettified'
    assert __StringFormatter('This is a test string and nothing more').format() == 'This is a test string and nothing more'
    assert __StringFormatter('This is a tesT string and nothing more').format() == 'This is a test string and nothing more'
    assert __StringFormatter('     Just a simple string to be prettified    ').format() == 'Just a simple string to be prettified'
    assert __StringFormatter('Just a simple string to be prettified     ').format() == 'Just a simple string to be prettified'

# Generated at 2022-06-21 21:19:06.356944
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-21 21:19:11.839797
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-21 21:19:16.022416
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-21 21:19:19.431377
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('YES') == True
    assert booleanize('y') == True
    assert booleanize('') == False
    assert booleanize('no') == False
    assert booleanize('f') == False
    assert booleanize(1) == False
    assert booleanize('hello') == False


# Generated at 2022-06-21 21:19:28.622985
# Unit test for function strip_html
def test_strip_html():
    test_data = [
        # test data [0] : input string
        # test data [1] : remove tag content?
        # test data [2] : expected output
        ['test: <a href="foo/bar">click here</a>', False, 'test: '],
        ['test: <a href="foo/bar">click here</a>', True, 'test: click here'],
        ['hello <b>world</b>, this is <em>italic</em>', False, 'hello world, this is italic'],
        ['<strong>This is a short <i>html</i> test</strong>. Remove <b>all tags</b> please.', False, 'This is a short html test. Remove all tags please.'],
    ]


# Generated at 2022-06-21 21:19:39.453705
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 0) == ''
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'

    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'

    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'

    assert __RomanNumbers.__encode_digit