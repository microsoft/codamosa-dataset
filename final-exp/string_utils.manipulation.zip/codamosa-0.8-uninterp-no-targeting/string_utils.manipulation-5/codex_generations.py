

# Generated at 2022-06-21 21:13:43.505910
# Unit test for function prettify
def test_prettify():
    assert prettify("unprettified string ,, like this one,will be\"prettified\" .it\'s awesome! ") == "Unprettified string, like this one, will be \"prettified\". It\'s awesome!"
    assert prettify("unprettified    string  like  this one  will  be  prettified  it\'s awesome") == "Unprettified string like this one will be prettified it\'s awesome"
    assert prettify("unprettified    string  like  this one  will  be  prettified  it\'s awesome!") == "Unprettified string like this one will be prettified it\'s awesome!"

# Generated at 2022-06-21 21:13:46.405495
# Unit test for function strip_margin
def test_strip_margin():
    assert (strip_margin('''
                line 1
                line 2
                line 3
                ''') == '''
line 1
line 2
line 3
''')



# Generated at 2022-06-21 21:13:55.055297
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(10) == 'X'
    assert roman_encode(50) == 'L'
    assert roman_encode(100) == 'C'
    assert roman_encode(500) == 'D'
    assert roman_encode(1000) == 'M'

    assert roman_encode(3) == 'III'
    assert roman_encode(33) == 'XXXIII'
    assert roman_encode(99) == 'XCIX'
    assert roman_encode(400) == 'CD'
    assert roman_encode(2999) == 'MMCMXCIX'

    assert roman_encode(4) == 'IV'

# Generated at 2022-06-21 21:13:59.514297
# Unit test for function shuffle
def test_shuffle():
    print('Testing function shuffle ...')
    assert shuffle('hello world') == 'helo wlrod', 'test failed!'
    print('Test passed.')
test_shuffle()



# Generated at 2022-06-21 21:14:10.640612
# Unit test for function booleanize
def test_booleanize():
    """
    Tests for function booleanize
    """
    test_input, test_output = "true", True
    assert booleanize(test_input) == test_output, "Should return True with input true"
    test_input, test_output = "TruE", True
    assert booleanize(test_input) == test_output, "Should return True with mixed case input true"
    test_input, test_output = "1", True
    assert booleanize(test_input) == test_output, "Should return True with input 1"
    test_input, test_output = "yes", True
    assert booleanize(test_input) == test_output, "Should return True with input yes"
    test_input, test_output = "y", True

# Generated at 2022-06-21 21:14:11.436055
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True


# Generated at 2022-06-21 21:14:13.802926
# Unit test for function asciify
def test_asciify():
        assert('eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))


# Generated at 2022-06-21 21:14:18.968609
# Unit test for function roman_encode
def test_roman_encode():
    assert 'I' == roman_encode(1)
    assert 'IV' == roman_encode(4)
    assert 'V' == roman_encode(5)
    assert 'MCMIII' == roman_encode(1903)
    assert 'MMXXXVIII' == roman_encode(2038)
# Unit test #1:
test_roman_encode()



# Generated at 2022-06-21 21:14:30.421165
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(16) == 'XVI'
    assert __RomanNumbers.encode(2300) == 'MMCCC'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'

    assert __RomanNumbers.decode('VI') == 6
    assert __RomanNumbers.decode('IX') == 9
    assert __RomanNumbers.decode('XVI') == 16
    assert __RomanNumbers.decode('MMCCC') == 2300
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999


# Generated at 2022-06-21 21:14:35.427975
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14

# Generated at 2022-06-21 21:15:07.416745
# Unit test for function asciify
def test_asciify():
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')
    assert(asciify('aaèÉùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'aaeeuuooaaeynAAACIINOE')
    assert(asciify('èÉùúòóäåëýñÅÀÁÇÌÍÑÓËaa') == 'eeuuooaaeynAAACIINOEaa')

# Generated at 2022-06-21 21:15:12.094355
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    s = __StringCompressor.compress("aeiou")
    assert(__StringCompressor.decompress(s) == "aeiou")
    assert( type(s) == str)

# PUBLIC API



# Generated at 2022-06-21 21:15:17.746733
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE"
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") != "eeuuooaaeynAAACIINOEË"

# Generated at 2022-06-21 21:15:22.954682
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)



# Generated at 2022-06-21 21:15:26.367439
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = __StringFormatter("  m  a  r  i  o  ")
    assert s.input_string == "  m  a  r  i  o  "



# Generated at 2022-06-21 21:15:38.593890
# Unit test for function prettify
def test_prettify():
    assert prettify(' foo') == 'Foo'
    assert prettify('foo ') == 'Foo'
    assert prettify(' foo ') == 'Foo'
    assert prettify('foo bar') == 'Foo bar'
    assert prettify('foo   bar') == 'Foo bar'
    assert prettify(' foo  bar') == 'Foo bar'
    assert prettify('foo  bar  ') == 'Foo bar'
    assert prettify('foo\nbar') == 'Foo bar'
    assert prettify('foo\n\nbar') == 'Foo bar'
    assert prettify('foo\r\nbar') == 'Foo bar'
    assert prettify('foo\r\n\r\nbar') == 'Foo bar'

# Generated at 2022-06-21 21:15:43.216226
# Unit test for function prettify

# Generated at 2022-06-21 21:15:46.690365
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed == original



# Generated at 2022-06-21 21:15:53.351599
# Unit test for function compress
def test_compress():
    """
    Test function compress
    """
    # Test with a random string
    random_string = text_utils.random_string(100)
    compressed_string = text_utils.compress(random_string)
    assert text_utils.decompress(compressed_string) == random_string
    # Test with a very long string
    long_string = text_utils.random_string(100000)
    compressed_string = text_utils.compress(long_string)
    assert text_utils.decompress(compressed_string) == long_string



# Generated at 2022-06-21 21:15:56.107238
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('y')
    assert not booleanize('no')
    assert not booleanize('0')
    assert not booleanize('false')


# Generated at 2022-06-21 21:16:25.482385
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('false') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    assert booleanize('something else') == False
    assert booleanize('') == False


# Generated at 2022-06-21 21:16:31.341283
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        line 1
        line 2
        line 3
        ''') == '''
    line 1
    line 2
    line 3
    '''
    assert strip_margin('one line') == 'one line'
    assert strip_margin('line 1\nline 2\nline 3') == 'line 1\nline 2\nline 3'
    assert strip_margin('line 1\n\nline 3') == 'line 1\n\nline 3'

# Generated at 2022-06-21 21:16:43.888223
# Unit test for function compress
def test_compress():
    """
    Test compress.
    :return:
    """
    import time
    import random
    import string

    # list of strings to test

# Generated at 2022-06-21 21:16:49.154027
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    |    # This is a comment
    |    # upon a
    |    # string
    |
    |    # The next line should be indented
    |  this_is_a_string''') == '''
    |# This is a comment
    |# upon a
    |# string
    |
    |# The next line should be indented
    |this_is_a_string'''

    assert strip_margin("this is a string") == 'this is a string'



# Generated at 2022-06-21 21:17:00.002534
# Unit test for function decompress
def test_decompress():
    """
    Test case for the function decompress.
    """

# Generated at 2022-06-21 21:17:12.213358
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # 1 => I, 5 => V
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 10) == ''
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'
   

# Generated at 2022-06-21 21:17:19.768235
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('The ``S.A.T. Scoring Scale``') == 'the-s-a-t-scoring-scale'
    #assert slugify('US President Donald J. Trump') == 'us-president-donald-j-trump'



# Generated at 2022-06-21 21:17:23.373405
# Unit test for function roman_encode
def test_roman_encode():
    assert (roman_encode(1) == 'I')
    assert (roman_encode('III') == 'III')
    assert (roman_encode(3999) == 'MMMCMXCIX')
    assert (roman_encode('77') == 'LXXVII')



# Generated at 2022-06-21 21:17:26.492552
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |''') == '''
line 1
line 2
'''



# Generated at 2022-06-21 21:17:38.546567
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])

# Generated at 2022-06-21 21:17:58.435825
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") == 'l wodheorll'



# Generated at 2022-06-21 21:18:01.998120
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-21 21:18:13.930153
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XXI') == 21
    assert roman_decode('XCIX') == 99
    assert roman_decode('MCMXC') == 1990
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('MMMCMXCIX') == 3999
    assert roman_decode('MCMLXXXIX') == 1989
    assert roman_decode('MCD') == 1400
    assert roman_decode('MMMCDXCIX') == 3499
    assert roman_decode('MMMMDCCLXXV') == 4775
    assert roman_decode('MMCMXCIX') == 2999
    assert roman_decode('MMDXCII') == 2592
    assert roman_decode('MMMMDCCLXXVII') == 4

# Generated at 2022-06-21 21:18:25.659779
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen', False, ' ') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the/snake/is/green', False, '/') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, ' ') == 'theSnakeIsGreen'

# Generated at 2022-06-21 21:18:29.498929
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2019) == 'MMXIX'
    assert roman_encode(4000) == 'ERR: Number 4000 is not valid'



# Generated at 2022-06-21 21:18:31.174529
# Unit test for function shuffle
def test_shuffle():
    if shuffle('hello world') != 'hello world':
        return False

    return True

# Generated at 2022-06-21 21:18:33.689887
# Unit test for function prettify
def test_prettify():
    input_string= "it\\' s awesome! "
    expected_output='It\'s awesome!'
    assert prettify(input_string)==expected_output
test_prettify()


# Generated at 2022-06-21 21:18:34.844885
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'hello world'



# Generated at 2022-06-21 21:18:47.380931
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "a b  c  d   e   f    g  h  i  j   k   l    m   n   o"
    expected_string = "A B C D E F G H I J K L M N O"
    assert __StringFormatter(input_string).format() == expected_string

    input_string = "  a  b  X  c  d   e   f    g  h  i  j   k   l    m   n   o"
    expected_string = "A b X c D e F G h I J K L M n O"
    assert __StringFormatter(input_string).format() == expected_string

    input_string = "a b X c d e f g h i j k l m n o"

# Generated at 2022-06-21 21:18:49.760958
# Unit test for function shuffle
def test_shuffle():
    _res = set()
    for _ in range(10):
        _res.add(shuffle('hello world'))
    assert len(_res) == 10

