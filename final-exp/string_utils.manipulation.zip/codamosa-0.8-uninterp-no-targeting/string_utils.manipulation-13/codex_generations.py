

# Generated at 2022-06-21 21:13:36.878581
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

# Generated at 2022-06-21 21:13:47.714905
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
test_camel_case_to_snake()




# Generated at 2022-06-21 21:13:53.115639
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings[0][1] == 'I'
    assert __RomanNumbers.__mappings[0][5] == 'V'
    assert __RomanNumbers.__mappings[1][1] == 'X'
    assert __RomanNumbers.__mappings[1][5] == 'L'
    assert __RomanNumbers.__mappings[2][1] == 'C'
    assert __RomanNumbers.__mappings[2][5] == 'D'
    assert __RomanNumbers.__mappings[3][1] == 'M'



# Generated at 2022-06-21 21:13:58.684554
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar"><b>click here</b></a>') == 'test: '
    assert strip_html('test: <a href="foo/bar"><b>click here</b></a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:14:09.792558
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Encoding and compression are not applied here.
    # We assume that input_string is already encoded using provided encoding and compressed using zlib.
    input_string = 'here-is-my-compressed-and-encoded-string'

    # Encoding and compression are applied here
    # We can assume that input_string, in this case, is not encoded and compressed.
    # In fact we assume that input_string is a string that needs to be compressed and encoded.
    input_string = __StringCompressor.compress(input_string)

    # Encoding and compression have already been applied on input_string therefore we only need to run a decode.
    input_string = __StringCompressor.decompress(input_string)


# PUBLIC API



# Generated at 2022-06-21 21:14:12.156431
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                        ''') == '''
                            line 1
                            line 2
                            line 3
                        '''

# Generated at 2022-06-21 21:14:18.311266
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest1') == 'this_is_a_camel_string_test1'
    assert camel_case_to_snake('ThisIsACamelStringTest1123') == 'this_is_a_camel_string_test1123'

# Generated at 2022-06-21 21:14:30.387623
# Unit test for function roman_encode

# Generated at 2022-06-21 21:14:33.516436
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'eeuuooaaeynAAACIINOE!'



# Generated at 2022-06-21 21:14:39.614033
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter()
    except Exception as err:
        if isinstance(err, InvalidInputError):
            assert isinstance(err.input, type(None)), \
                f"Got {err.input.__class__.__name__}, expected None"
            return
    assert False, f"Got {err.__class__.__name__}, expected InvalidInputError"


# Generated at 2022-06-21 21:14:48.679160
# Unit test for function prettify

# Generated at 2022-06-21 21:14:55.054713
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MM') == 2000
    assert roman_decode('MMCIV') == 2104
    assert roman_decode('LXIV') == 64
    assert roman_decode('DXXXIV') == 534
    assert roman_decode('CXXXIX') == 139
    assert roman_decode('CXXXIX') == 139
    assert roman_decode('MCMXC') == 1990
    assert roman_decode('MMVII') == 2007
    assert roman_decode('MMXVIII') == 2018
    assert roman_decode('MMLXXXII') == 2082
    assert roman_decode('MMXCVIII') == 2098
    assert roman_decode('MMMCMXCIX') == 3999

# Generated at 2022-06-21 21:14:57.646794
# Unit test for function asciify
def test_asciify():
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')



# Generated at 2022-06-21 21:15:06.563952
# Unit test for function roman_encode
def test_roman_encode():
    test_data = [
        (1, 'I'),
        (4, 'IV'),
        (5, 'V'),
        (6, 'VI'),
        (9, 'IX'),
        (10, 'X'),
        (40, 'XL'),
        (50, 'L'),
        (51, 'LI'),
        (90, 'XC'),
        (100, 'C'),
        (400, 'CD'),
        (500, 'D'),
        (501, 'DI'),
        (900, 'CM'),
        (1000, 'M'),
        (2020, 'MMXX'),
        (3999, 'MMMCMXCIX'),
        ('37', 'XXXVII'),
        ('2020', 'MMXX'),
        ('3999', 'MMMCMXCIX'),
    ]


# Generated at 2022-06-21 21:15:09.100130
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-21 21:15:18.720696
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # encode tests
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(30) == 'XXX'
   

# Generated at 2022-06-21 21:15:19.887467
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('Test') == 'test'



# Generated at 2022-06-21 21:15:24.642235
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    
test_slugify()
 


# Generated at 2022-06-21 21:15:28.137991
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELlo') == 'olleH'


# Generated at 2022-06-21 21:15:39.561337
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_str = """
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore 
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    """

    compressed_str = __StringCompressor.compress(original_str)

# Generated at 2022-06-21 21:15:49.703729
# Unit test for function strip_margin
def test_strip_margin():
    print("test_strip_margin")
    assert("line 1\nline 2\nline 3" == strip_margin("""
        |line 1
        |line 2
        |line 3
        |"""))
# end function test_strip_margin



# Generated at 2022-06-21 21:15:57.179795
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(1999) == 'MCMXCIX'
    assert __RomanNumbers.encode(49) == 'XLIX'
    assert __

# Generated at 2022-06-21 21:16:02.986150
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:16:07.642587
# Unit test for function decompress
def test_decompress():
    assert decompress('EAAoFQAAdWkxMAAAGXzAAGV4AACF0wABAAMAAA==')=='word n1'
    assert decompress('FAAoFQAAdWkxMAAAGXzAAGV4AACF0wABAAMAAg==')=='word n2'
    assert decompress('EAAoFQAAdWkxMAAAGXzAAGV4AACF0wABAAMAAQ==')=='word n0'
    assert decompress('EAAoFQAAdWkxMAAAGXzAAGV4AACF0wABAAMAAw==')=='word n3'

# Generated at 2022-06-21 21:16:14.531611
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I', 'Error 1'
    assert __RomanNumbers.encode(2) == 'II', 'Error 2'
    assert __RomanNumbers.encode(3) == 'III', 'Error 3'
    assert __RomanNumbers.encode(4) == 'IV', 'Error 4'
    assert __RomanNumbers.encode(5) == 'V', 'Error 5'
    assert __RomanNumbers.encode(6) == 'VI', 'Error 6'
    assert __RomanNumbers.encode(7) == 'VII', 'Error 7'
    assert __RomanNumbers.encode(8) == 'VIII', 'Error 8'
    assert __RomanNumbers.encode(9) == 'IX', 'Error 9'

# Generated at 2022-06-21 21:16:18.624763
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') 


# Generated at 2022-06-21 21:16:23.759731
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('') == False
    assert booleanize('true') == True
    assert booleanize('Yes') == True
    assert booleanize('1') == True
    assert booleanize('Y') == True
    assert booleanize('anything else') == False


# Generated at 2022-06-21 21:16:26.214890
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-21 21:16:34.182545
# Unit test for function prettify
def test_prettify():
    assert 'Unprettified string, like this one, will be "prettified". It\'s awesome!' == prettify(
        ' unprettified string ,, like this one,will be"prettified" .it\\\' s awesome! ')
    assert '- - -' == prettify('- - -')
    assert 'Hello World!' == prettify('Hello World!')
    assert 'Let\'s have a 100% match' == prettify('Let\'s have a 100 % match')
    assert '[too] weird' == prettify('[ too ]   weird')
    assert '«Hello»' == prettify('«  Hello  »')
    assert 'Hello «world»!' == prettify('Hello «  world  »!')
    assert 'Hello «world»!' == prettify('Hello «world  »!')

# Generated at 2022-06-21 21:16:35.855387
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'

