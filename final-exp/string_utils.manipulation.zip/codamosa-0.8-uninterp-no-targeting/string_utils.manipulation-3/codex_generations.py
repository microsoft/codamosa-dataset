

# Generated at 2022-06-21 21:13:33.535235
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c   ').format() == 'a b c'
    assert __StringFormatter('a  b c   ').format() == 'a b c'
    assert __StringFormatter('a  B  c   ').format() == 'a B c'
    assert __StringFormatter('a  B C   ').format() == 'a B C'
    assert __StringFormatter('a b c d e f g h j k l m n o p q r s t u v z a b   ').format() == 'a b c d e f g h j k l m n o p q r s t u v z a b'

# Generated at 2022-06-21 21:13:34.477229
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse(reverse('hello')) == 'hello'



# Generated at 2022-06-21 21:13:36.533691
# Unit test for function decompress
def test_decompress():
    return __StringCompressor.decompress("")

# Generated at 2022-06-21 21:13:45.282130
# Unit test for function prettify

# Generated at 2022-06-21 21:13:49.541386
# Unit test for function strip_margin
def test_strip_margin():
    test = '''
    |line 1
    |line 2
    |line 3
    '''
    expected = '''
    line 1
    line 2
    line 3
    '''
    assert strip_margin(test) == expected
    assert strip_margin('') == ''
    assert strip_margin('hello') == 'hello'
    assert strip_margin('hello world') == 'hello world'

# Generated at 2022-06-21 21:13:56.679385
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert is_string(compressed)
    assert len(compressed) < len(original)



# Generated at 2022-06-21 21:13:59.519563
# Unit test for function compress
def test_compress():
    assert compress('foo bar') == 'eNpLzs/PT8/P2izUFAlcB'


# Generated at 2022-06-21 21:14:10.114629
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(41) == 'XLI'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(900) == 'CM'
    assert __RomanNumbers

# Generated at 2022-06-21 21:14:11.333156
# Unit test for function shuffle
def test_shuffle():
    assert 'l wodheorll' == shuffle('hello world')



# Generated at 2022-06-21 21:14:22.768541
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('This is a text').format() == 'This is a text'
    assert __StringFormatter(' This  is  a  text').format() == 'This is a text'
    assert __StringFormatter('  This  is  a  text ').format() == 'This is a text'
    assert __StringFormatter('This  is\na text').format() == 'This is a text'
    assert __StringFormatter('This is a  text').format() == 'This is a text'
    assert __StringFormatter('This is a text  ').format() == 'This is a text'
    assert __StringFormatter('This is\n a text').format() == 'This is a text'
    assert __StringFormatter('\nThis is\n a text').format() == 'This is a text'
    assert __String

# Generated at 2022-06-21 21:14:34.375251
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    sc = __StringCompressor()
    assert sc is not None



# Generated at 2022-06-21 21:14:43.546866
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I')==1
    assert roman_decode('II')==2
    assert roman_decode('III')==3
    assert roman_decode('IV')==4
    assert roman_decode('V')==5
    assert roman_decode('VI')==6
    assert roman_decode('VII')==7
    assert roman_decode('VIII')==8
    assert roman_decode('IX')==9
    assert roman_decode('X')==10
    assert roman_decode('XIX')==19
    assert roman_decode('XX')==20
    assert roman_decode('XL')==40
    assert roman_decode('L')==50
    assert roman_decode('LXXX')==80
   

# Generated at 2022-06-21 21:14:49.819594
# Unit test for function compress
def test_compress():
    # this is a string with 169 chars
    original = ' '.join(['word n{}'.format(n) for n in range(20)])

    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert compressed == 'eJzLwcEKwCAQQGncoDOuoFz4QC1kY9svgHkPbJhKwHwBdZpP90iCg=='



# Generated at 2022-06-21 21:14:52.063929
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string = '   this   is   a   test   string   '
    expected_result = 'This Is A Test String'
    assert __StringFormatter(test_string).format() == expected_result



# Generated at 2022-06-21 21:15:03.657010
# Unit test for function roman_decode
def test_roman_decode():
  assert roman_decode('I') == 1
  assert roman_decode('III') == 3
  assert roman_decode('V') == 5
  assert roman_decode('X') == 10
  assert roman_decode('MCMXCIX') == 1999
  assert roman_decode('IV') == 4
  assert roman_decode('MMVIII') == 2008
  assert roman_decode('MMMCMXCIX') == 3999
  assert roman_decode('MMMM') == 4000
  assert roman_decode('LX') == 60
  assert roman_decode('LXX') == 70
  assert roman_decode('LXXX') == 80
  assert roman_decode('XC') == 90
  assert roman_decode('C') == 100

# Generated at 2022-06-21 21:15:14.794144
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():

    assert __StringCompressor.compress('Hello') == 'eJxLTEtNzs8tKq5OTk7O1QQA'
    assert __StringCompressor.compress('Hello', compression_level=6) == 'eJxLTEtNzs8tKq5OTk7O1QQA'
    assert __StringCompressor.compress('Hello', compression_level=1) == 'eJxLTMtUrSw0FAoA'
    assert __StringCompressor.compress('Hello', compression_level=0) == 'eJxLTMtUrSw0FAoA'
    assert __StringCompressor.compress('Hello', compression_level=9) == 'eJxLTEtNzs8tKq5OTk7O1QQA'

    assert __StringComp

# Generated at 2022-06-21 21:15:19.774453
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët') != 'monster-magnët'



# Generated at 2022-06-21 21:15:22.954682
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = uuid4().hex

    assert __StringCompressor.decompress(__StringCompressor.compress(original_string)) == original_string, \
        '__StringCompressor is not working as expected'


# PUBLIC API



# Generated at 2022-06-21 21:15:30.984558
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter

    # Uppercase first letter
    assert sf('a').format() == 'A'
    assert sf('a b c').format() == 'A b c'
    assert sf('a. b. c.').format() == 'A. b. c.'
    assert sf('a_b_c').format() == 'A_b_c'
    assert sf('a_b_c').format() == 'A_b_c'
    assert sf('ab c').format() == 'Ab c'
    assert sf('ab c').format() == 'Ab c'

    # Remove duplicates
    assert sf('a a').format() == 'A'
    assert sf('a. a.').format() == 'A.'

# Generated at 2022-06-21 21:15:42.036959
# Unit test for function roman_decode
def test_roman_decode():
    assert (roman_decode('V') == 5)
    assert (roman_decode('VI') == 6)
    assert (roman_decode('VII') == 7)
    assert (roman_decode('VIII') == 8)
    assert (roman_decode('IX') == 9)
    assert (roman_decode('X') == 10)
    assert (roman_decode('XI') == 11)
    assert (roman_decode('XII') == 12)
    assert (roman_decode('XIV') == 14)
    assert (roman_decode('XV') == 15)
    assert (roman_decode('XVI') == 16)
    assert (roman_decode('XVIII') == 18)
    assert (roman_decode('XIX') == 19)