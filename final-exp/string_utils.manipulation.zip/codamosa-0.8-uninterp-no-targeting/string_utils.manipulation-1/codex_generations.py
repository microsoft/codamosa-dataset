

# Generated at 2022-06-21 21:13:40.964268
# Unit test for constructor of class __StringFormatter

# Generated at 2022-06-21 21:13:50.899507
# Unit test for function roman_encode
def test_roman_encode():
  assert roman_encode(1) == 'I'
  assert roman_encode(2) == 'II'
  assert roman_encode(3) == 'III'
  assert roman_encode(4) == 'IV'
  assert roman_encode(5) == 'V'
  assert roman_encode(6) == 'VI'
  assert roman_encode(7) == 'VII'
  assert roman_encode(8) == 'VIII'
  assert roman_encode(9) == 'IX'
  assert roman_encode(10) == 'X'
  assert roman_encode(11) == 'XI'
  assert roman_encode(12) == 'XII'
  assert roman_encode(13) == 'XIII'


# Generated at 2022-06-21 21:13:56.197456
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-21 21:14:01.112135
# Unit test for function strip_margin
def test_strip_margin():
    string = '''
            line 1
            line 2
            line 3
            '''
    cleaned = '''
    line 1
    line 2
    line 3
    '''
    assert strip_margin(string) == cleaned

# Generated at 2022-06-21 21:14:11.074068
# Unit test for function asciify
def test_asciify():
    assert asciify('foo') == 'foo'
    assert asciify('fóó') == 'foo'
    assert asciify('fòò') == 'foo'
    assert asciify('ò') == 'o'
    assert asciify('ø') == 'o'
    assert asciify('π') == 'p'
    assert asciify('p') == 'p'
    assert asciify('èéùúòóäåëýñÅÀÁÇÈÌÍÑÓË') == 'eeuuooaaeynAAACIIINOE'
    assert asciify('èéùúñòóæåøôöÿ') == 'eeuunooaaooy'



# Generated at 2022-06-21 21:14:14.782738
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'

# Generated at 2022-06-21 21:14:16.681738
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7, "Decoding error at: VII"
    assert roman_decode('MCCXXXIV') == 1234, "Decoding error at: MCCXXXIV"


# Generated at 2022-06-21 21:14:25.997948
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-21 21:14:31.795665
# Unit test for function strip_html
def test_strip_html():
    if strip_html('test: <a href="foo/bar">click here</a>') != 'test: ':
        return False

    if strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) != 'test: click here':
        return False

    return True



# Generated at 2022-06-21 21:14:33.043622
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert len(shuffle('hello world')) == len('hello world')

# Generated at 2022-06-21 21:14:51.160925
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    s = __StringCompressor()
    assert s is not None

# PUBLIC API



# Generated at 2022-06-21 21:14:52.405871
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    
print("Tests passed")


# Generated at 2022-06-21 21:15:01.281428
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(141) == 'CXLI'
    assert __RomanNumbers.encode(2137) == 'MMCXXXVII'
    assert __RomanNumbers.decode('IV') == 4
    assert __RomanNumbers.decode('IX') == 9
    assert __RomanNumbers.decode('CXLI') == 141
    assert __RomanNumbers.decode('MMCXXXVII') == 2137

test___RomanNumbers()


# Generated at 2022-06-21 21:15:02.932160
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor is not None

test___StringCompressor()

# PUBLIC API



# Generated at 2022-06-21 21:15:06.445287
# Unit test for function prettify
def test_prettify():
    is_equal = prettify(' unprettified string ,, like this one,will be"prettified" .it\\\' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    print("Test prettify: " + ("OK" if is_equal else "FAILED"))



# Generated at 2022-06-21 21:15:11.600152
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:15:22.059458
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    _roman_convert = __RomanNumbers()
    assert _roman_convert.encode(1) == "I"
    assert _roman_convert.encode(2) == "II"
    assert _roman_convert.encode(3) == "III"
    assert _roman_convert.encode(4) == "IV"
    assert _roman_convert.encode(5) == "V"
    assert _roman_convert.encode(6) == "VI"
    assert _roman_convert.encode(7) == "VII"
    assert _roman_convert.encode(8) == "VIII"
    assert _roman_convert.encode(9) == "IX"
    assert _roman_convert.encode(10) == "X"
    assert _roman_con

# Generated at 2022-06-21 21:15:29.085588
# Unit test for function asciify
def test_asciify():
    expected_output = 'eeuuooaaeynAAACIINOE'
    input_string = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'

    output = asciify(input_string)

    if output == expected_output:
        print("Test for function asciify() PASSED")
    else:
        print("Test for function asciify() FAILED")



# Generated at 2022-06-21 21:15:30.912435
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'

# Generated at 2022-06-21 21:15:41.915819
# Unit test for function decompress

# Generated at 2022-06-21 21:15:57.844653
# Unit test for function prettify

# Generated at 2022-06-21 21:16:02.358899
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('ThisIsACamelStringTest')
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('thisIsACamelStringTest')
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('ThisIsACamelCase_stringTest')
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('thisIsACamelCase_stringTest')
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('ThisIsACamelCase_stringTest', separator='_')

# Generated at 2022-06-21 21:16:11.400381
# Unit test for function booleanize
def test_booleanize():
    temp_booleanize = {}
    temp_booleanize["true"] = True
    temp_booleanize["false"] = False
    temp_booleanize["1"] = True
    temp_booleanize["0"] = False
    temp_booleanize["yes"] = True
    temp_booleanize["no"] = False
    temp_booleanize["y"] = True
    temp_booleanize["n"] = False

    for string in temp_booleanize:
        assert temp_booleanize[string] == booleanize(string)


# Generated at 2022-06-21 21:16:13.875998
# Unit test for function slugify
def test_slugify():
    print(slugify('Top 10 Reasons To Love Dogs!!!'))
    print(slugify('Mönstér Mägnët'))


# Generated at 2022-06-21 21:16:18.364593
# Unit test for function compress
def test_compress():
    assert compress('edoardo') == 'eJxLyDg1Ok1QMVA0NDcwNz1O'
    assert compress('') == ''
    assert compress(PROGRAM_TEST_STRING) == 'eJxLxDg0AgLkNAF6AQACFQE9XCgBYQYBZQwBIA=='



# Generated at 2022-06-21 21:16:23.096929
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:16:27.103700
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_str = "the_snake_is_green"
    print("snake_case_to_camel({}) -> {}".format(input_str, snake_case_to_camel(input_str)))


# Generated at 2022-06-21 21:16:34.545747
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                          line 1
                          line 2
                          line 3
                          ''') == '''
line 1
line 2
line 3
'''
    assert strip_margin('''
                          line 1
                          line 2
                          line 3
''') == '''
line 1
line 2
line 3
'''
    assert strip_margin('''
                          line 1
                          line 2
                          line 3


''') == '''
line 1
line 2
line 3


'''
    assert strip_margin('''
                          line 1
                          line 2
                          line 3


                          ''') == '''
line 1
line 2
line 3


'''
    assert strip_margin('') == ''

# Generated at 2022-06-21 21:16:38.180110
# Unit test for function shuffle
def test_shuffle():
    my_string = "Hello World"
    original_string = my_string
    assert len(shuffle(original_string)) == len(original_string)

test_shuffle()



# Generated at 2022-06-21 21:16:41.092928
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
   assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-21 21:17:03.856907
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(176) == 'CLXXVI'
    assert __RomanNumbers.encode(77) == 'LXXVII'
    assert __RomanNumbers.encode(723) == 'DCCXXIII'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.decode('MMDCCLX') == 1760
    assert __RomanNumbers.decode('MDCCLX') == 1760
    assert __RomanNumbers.decode('MCMXC') == 1990
    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('IV') == 4
    assert __RomanNumbers.decode('CMXCIX') == 999
    assert __RomanNumbers.decode

# Generated at 2022-06-21 21:17:05.171213
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
hello
  world!
''') == '''
hello
world!
'''

# Generated at 2022-06-21 21:17:13.744201
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' this is a test ').format() == 'This is a test'
    assert __StringFormatter(' this is a test, my lord ').format() == 'This is a test, my lord'
    assert __StringFormatter(' this, is a test, my lord! ').format() == 'This, is a test, my lord!'
    assert __StringFormatter(' i.e.,this, is a test, my lord! ').format() == 'i.e., this, is a test, my lord!'
    assert __StringFormatter(' i.e., this, is a test, my lord! ').format() == 'i.e., this, is a test, my lord!'

# Generated at 2022-06-21 21:17:23.073216
# Unit test for function decompress
def test_decompress():
    initial_string = 'Hello World'
    assert(initial_string == decompress(compress(initial_string)))
    initial_string = '1234567890_!@#$%^&*'
    assert(initial_string == decompress(compress(initial_string)))
    initial_string = '1234567890_!@#$%^&*'
    assert(initial_string == decompress(compress(initial_string)))
    initial_string = '1234567890_!@#$%^&*'
    assert(initial_string == decompress(compress(initial_string)))
    

# Generated at 2022-06-21 21:17:25.775020
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'
# Test function
test_slugify()
 

# Generated at 2022-06-21 21:17:38.193418
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-21 21:17:45.024426
# Unit test for function decompress
def test_decompress():
    """
    Unit test for function decompress.
    """
    test_string = "This is a test string to be compressed."
    test_encoding = 'utf-8'
    test_level = 9

    compressed = compress(test_string, test_encoding, test_level)
    restored = decompress(compressed, test_encoding)

    assert restored == test_string, "String was not correctly restored."



# Generated at 2022-06-21 21:17:49.044441
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(9) == 'IX'
    assert roman_encode(14) == 'XIV'
    assert roman_encode(2017) == 'MMXVII'
    assert roman_encode(2090) == 'MMCMXC'



# Generated at 2022-06-21 21:17:57.252373
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:18:00.660765
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-21 21:18:13.256943
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'

# Generated at 2022-06-21 21:18:17.721826
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:18:22.650009
# Unit test for function strip_html
def test_strip_html():
    assert(strip_html('test: <a href="foo/bar">click here</a>') == 'test: ')
    assert(strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here')



# Generated at 2022-06-21 21:18:25.686865
# Unit test for function decompress
def test_decompress():
    """This is a test method to test decompress function."""
    # Create a test object
    test = 'Test decompression'

    # Create a compressed object
    compressed = compress(test)

    # Call decompress
    decompressed = decompress(compressed)

    # assertEqual
    assert decompressed == test



# Generated at 2022-06-21 21:18:30.561641
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") != "hello world"
    assert len(shuffle("hello world")) == len("hello world")
    assert len(shuffle("1234 5678")) == len("1234 5678")
    assert len(shuffle("!@#$ %&*")) == len("!@#$ %&*")


# Generated at 2022-06-21 21:18:33.488405
# Unit test for function compress
def test_compress():
    data = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(data)
    assert len(compressed) < len(data)
test_compress()



# Generated at 2022-06-21 21:18:39.807433
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake(None) is None
    assert camel_case_to_snake('NON_VALID_INPUT') == 'NON_VALID_INPUT'
    assert camel_case_to_snake('ThisIsACamelStringTestWith_,;?!.') == 'this_is_a_camel_string_test_with'

# Generated at 2022-06-21 21:18:43.414984
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)

    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print(compressed)
    # "decompressed" will be a string with 169 chars
    decompressed = decompress(compressed)
    print(decompressed)



# Generated at 2022-06-21 21:18:44.990814
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-21 21:18:46.837828
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') not in ('hello world', 'ehll owrdlo')

