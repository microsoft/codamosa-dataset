

# Generated at 2022-06-21 21:13:37.965300
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake") == "TheSnake"
    assert snake_case_to_camel("the_snake", False) == "theSnake"
    assert snake_case_to_camel("the_snake", False, "") == "theSnake"
    assert snake_case_to_camel("the_snake", True) == "TheSnake"
    assert snake_case_to_camel("the_snake", True, "") == "TheSnake"
    assert snake_case_to_camel("The_Snake") == "TheSnake"
    assert snake_case_to_camel("The_Snake", False) == "theSnake"
    assert snake_case_to_camel("The_Snake", False, "") == "theSnake"
    assert snake_case_to_

# Generated at 2022-06-21 21:13:40.426527
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('test').input_string == 'test'
    assert __StringFormatter(123).input_string == '123'

    try:
        __StringFormatter(None)
        assert False
    except InvalidInputError:
        assert True

    try:
        __StringFormatter([])
        assert False
    except InvalidInputError:
        assert True


# Generated at 2022-06-21 21:13:44.045384
# Unit test for function roman_decode
def test_roman_decode():
    assert 7 == roman_decode('VII')
    #assert not 7 == roman_decode('VIIIIIII')
    #assert not 7 == roman_decode('VVII')
    assert 7 == roman_decode('VVII')



# Generated at 2022-06-21 21:13:45.137521
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('Hello World!')) == 'Hello World!'



# Generated at 2022-06-21 21:13:48.214304
# Unit test for function reverse
def test_reverse():
    assert 'olleh' == reverse('hello')
    assert 'olle' == reverse('elol')
    assert '' == reverse('')
    assert 'a' == reverse('a')
# Unit test coverage (at least 80%)
test_reverse()



# Generated at 2022-06-21 21:13:57.789277
# Unit test for function roman_encode
def test_roman_encode():
    assert 'I' == roman_encode(1)
    assert 'XXIII' == roman_encode(23)
    assert 'MMXIII' == roman_encode(2013)
    assert 'MIM' == roman_encode(1999)
    assert 'MMMCMXCIX' == roman_encode(3999)
    assert 'II' == roman_encode(2)
    assert 'XXX' == roman_encode(30)
    assert 'MM' == roman_encode(2000)
    assert 'MIM' == roman_encode('1999')
    assert 'MMMCMXCIX' == roman_encode('3999')
    try:
        roman_encode(4000)
        assert False
    except Exception:
        assert True
test_roman_encode()

# Generated at 2022-06-21 21:14:02.002231
# Unit test for function shuffle
def test_shuffle():
    assert is_string(shuffle('hello world'))
    assert len(shuffle('hello world')) == len('hello world')
    assert shuffle('hello world') != 'hello world'
    assert not is_string(shuffle(None))


# Generated at 2022-06-21 21:14:09.642202
# Unit test for function strip_margin
def test_strip_margin():
    test_text = '''
                test 1
                test 2'''
    assert strip_margin(test_text) == 'test 1\ntest 2'
    assert strip_margin('test 1\n  test 2') == 'test 1\ntest 2'
    assert strip_margin('test 1\n  test 2\n    test3') == 'test 1\ntest 2\n  test3'


# Generated at 2022-06-21 21:14:14.424334
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true") == True
    assert booleanize("TRUE") == True
    assert booleanize("False") == False
    assert booleanize("FALSE") == False
    assert booleanize("1") == True
    assert booleanize("0") == False
    assert booleanize("yes") == True
    assert booleanize("no") == False
    assert booleanize("y") == True
    assert booleanize("n") == False
    assert booleanize("Y") == True
    assert booleanize("N") == False

# Generated at 2022-06-21 21:14:15.943239
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'

# Generated at 2022-06-21 21:14:26.075143
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-21 21:14:31.449536
# Unit test for function strip_margin
def test_strip_margin():
    text = '''
           |line1
           |line2
           |line3
    '''
    text_without_margin = '''
    line1
    line2
    line3
'''
    assert strip_margin(text) == text_without_margin
test_strip_margin()


# Generated at 2022-06-21 21:14:42.486504
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('false') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    try:
        assert booleanize('') == False
    except Exception as e:
        assert str(e) == 'InvalidInputError: input_string cannot be blank'
    try:
        assert booleanize(1) == False
    except Exception as e:
        assert str(e) == 'InvalidInputError: input_string: 1 is not a string'


# Generated at 2022-06-21 21:14:46.805915
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'Hello'
    compressed_string = __StringCompressor.compress(original_string)
    decompressed_string = __StringCompressor.decompress(compressed_string)
    assert original_string == decompressed_string


###############################################################################
# PUBLIC API
###############################################################################



# Generated at 2022-06-21 21:14:58.988160
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
  assert snake_case_to_camel('ciao') == 'Ciao'
  assert snake_case_to_camel('ciao', upper_case_first = False) == 'ciao'
  assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
  assert snake_case_to_camel('the_snake_is_green', upper_case_first = False) == 'theSnakeIsGreen'
  assert snake_case_to_camel('the_snake_is_green', upper_case_first = False, separator = '-') == 'theSnakeIsGreen'
  assert snake_case_to_camel('the snake is green', upper_case_first = False, separator = ' ') == 'theSnakeIsGreen'




# Generated at 2022-06-21 21:15:00.347459
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-21 21:15:08.869884
# Unit test for function compress
def test_compress():
    for compression_level in range(10):
        sample = ' '.join(['word n{}'.format(n) for n in range(20)])
        compressed = compress(sample, compression_level=compression_level)
        decompressed = decompress(compressed)
        assert len(compressed) <= len(decompressed)
        assert decompressed == sample



# Generated at 2022-06-21 21:15:12.975417
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()


# Generated at 2022-06-21 21:15:17.965336
# Unit test for function strip_margin
def test_strip_margin():
    print('Function: strip_margin')

    txt = '''
        |line 1
        |line 2
        |line 3
        |'''

    print(strip_margin(txt))

    txt = '''
    | line 1
    | line 2
     |line 3
    |'''

    print(strip_margin(txt))


# Generated at 2022-06-21 21:15:24.603634
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TruE') == True
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('Yes') == True
    assert booleanize('no') == False
    assert booleanize('y') == True
    assert booleanize('N') == False
    assert booleanize('yEs') == True
    assert booleanize('Nope') == False
    assert booleanize('TRUE') == True
    assert booleanize('yES') == True
    assert booleanize('Yes') == True
    assert booleanize('nope') == False
    assert booleanize('') == False


# Generated at 2022-06-21 21:15:42.906111
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('test', False) == 'test'



# Generated at 2022-06-21 21:15:45.551496
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'hello' or shuffle('hello') == 'oellh'



# Generated at 2022-06-21 21:15:47.425072
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-21 21:15:51.008488
# Unit test for function prettify
def test_prettify():
    input_string = ' unprettified string ,, like this one,will be"prettified" .it\' s awesome! '

    assert prettify(input_string) == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-21 21:15:57.396828
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    class __tester(__StringFormatter):
        def __init__(self, input_string):
            super(__tester, self).__init__(input_string)

        def __uppercase_first_char(self, regex_match):
            return '_'

        def __remove_duplicates(self, regex_match):
            return '_'

        def __uppercase_first_letter_after_sign(self, regex_match):
            return '_'

        def __ensure_right_space_only(self, regex_match):
            return '_'

        def __ensure_left_space_only(self, regex_match):
            return '_'

        def __ensure_spaces_around(self, regex_match):
            return '_'


# Generated at 2022-06-21 21:16:03.156077
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-21 21:16:11.017480
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print(compressed)
    decompressed = decompress(compressed)
    assert decompressed == original



# Generated at 2022-06-21 21:16:19.503442
# Unit test for function decompress

# Generated at 2022-06-21 21:16:30.707168
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('XV') == 15
    assert roman_decode('XXV') == 25
    assert roman_decode('XL') == 40
    assert roman_decode('LXX') == 70
    assert roman_decode('LXXXVIII') == 88
    assert roman_decode('CXXIX') == 129
    assert roman_decode('CCXXIX') == 229
    assert roman_decode('CCLXXXVIII') == 288
    assert roman_decode('CMXCIX') == 999
    assert roman_decode('MCCCXXIX') == 1329
    assert roman_decode('MCDXXXVIII') == 1438
    assert roman_decode('MDCCCXXIX') == 1829


# Generated at 2022-06-21 21:16:35.598622
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('y') == True
    assert booleanize('f') == False
    assert booleanize('0') == False
    assert booleanize('nope') == False
