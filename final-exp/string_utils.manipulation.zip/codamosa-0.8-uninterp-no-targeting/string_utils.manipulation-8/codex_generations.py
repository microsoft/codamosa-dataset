

# Generated at 2022-06-21 21:13:42.183778
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .testing import test

    try:
        __StringCompressor.compress('')
        test.fail('An exception was expected')
    except ValueError:
        pass

    try:
        __StringCompressor.compress('Hello World!', encoding=None)
        test.fail('An exception was expected')
    except ValueError:
        pass

    try:
        __StringCompressor.compress('Hello World!', compression_level=None)
        test.fail('An exception was expected')
    except ValueError:
        pass

    try:
        __StringCompressor.compress('Hello World!', compression_level=-1)
        test.fail('An exception was expected')
    except ValueError:
        pass


# Generated at 2022-06-21 21:13:42.740283
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers


# Generated at 2022-06-21 21:13:51.991328
# Unit test for function shuffle
def test_shuffle():
    # we have to test a random number of times (to have a better coverage)
    for _ in range(random.randint(1, 10)):
        length = random.randint(10, 100)
        out = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
        shuffled = shuffle(out)

        # assume each time that the shuffled string is not the same of the original one
        # (we assume that the random shuffle will work properly)
        assert out != shuffled

        # assume that the "shuffled" string contains all the same chars of the original one
        assert sorted(out) == sorted(shuffled)

        # assume that the "shuffled" string is not empty (even if input string was empty)
        assert len(shuffled) > 0

#

# Generated at 2022-06-21 21:13:53.327430
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert(booleanize('false') == False)



# Generated at 2022-06-21 21:14:02.670726
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'The-Snake-Is-Green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-Snake-Is-Green'



# Generated at 2022-06-21 21:14:05.515082
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == shuffle('hello world')


# Generated at 2022-06-21 21:14:12.916775
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(__StringCompressor.compress('a')) == 'a'
    assert __StringCompressor.decompress(__StringCompressor.compress('123')) == '123'
    assert __StringCompressor.decompress(__StringCompressor.compress('aaa')) == 'aaa'
    assert __StringCompressor.decompress(__StringCompressor.compress('aaa aaa')) == 'aaa aaa'
    assert __StringCompressor.decompress(__StringCompressor.compress('This is a long story')) == 'This is a long story'

# PUBLIC API



# Generated at 2022-06-21 21:14:14.147684
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('This is a unit test') != 'This is a unit test'
# End unit test



# Generated at 2022-06-21 21:14:24.002010
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I', '1 should be I'
    assert __RomanNumbers.encode(5) == 'V', '5 should be V'
    assert __RomanNumbers.encode(10) == 'X', '10 should be X'
    assert __RomanNumbers.encode(50) == 'L', '50 should be L'
    assert __RomanNumbers.encode(100) == 'C', '100 should be C'
    assert __RomanNumbers.encode(500) == 'D', '500 should be D'
    assert __RomanNumbers.encode(1000) == 'M', '1000 should be M'

    assert __RomanNumbers.encode(15) == 'XV', '15 should be XV'

# Generated at 2022-06-21 21:14:25.887181
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('MMXX') == 2020

test_roman_decode()
assert roman_decode('MM') == 2000
assert roman_decode('MMVIII') == 2008
assert roman_decode('MMXIX') == 2019
assert roman_decode('MCMXCIX') == 1999



# Generated at 2022-06-21 21:14:39.442636
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse('a') == 'a'

    try:
        reverse(1)
        raise AssertionError('Function must raise an error when the input is not a string')
    except InvalidInputError:
        pass



# Generated at 2022-06-21 21:14:47.539131
# Unit test for function shuffle
def test_shuffle():
    string1 = 'Hello World'
    string2 = 'I love Python'
    string3 = 'Hello World'
    string4 = 'I love Python'
    assert (string1 != shuffle(string1))
    assert (string2 != shuffle(string2))
    assert (string1 != shuffle(string2))
    assert (string1 != shuffle(string3))
    assert (string3 != shuffle(string3))
    assert (string3 != shuffle(string4))
test_shuffle()



# Generated at 2022-06-21 21:14:54.384571
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', False) == 'test'
    assert snake_case_to_camel('test', True, ' ') == 'Test'
    assert snake_case_to_camel('test', False, ' ') == 'test'
    assert snake_case_to_camel('test', True, ' ') == 'Test'
    assert snake_case_to_camel('test_something') == 'TestSomething'
    assert snake_case_to_camel('test_something_more') == 'TestSomethingMore'
    assert snake_case_to_camel('can_you_turn_this_into_camel_case', True, '_') == 'CanYouTurnThisIntoCamelCase'
    assert snake

# Generated at 2022-06-21 21:15:02.040493
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('TRUE') == True)
    assert(booleanize('1') == True)
    assert(booleanize('y') == True)
    assert(booleanize('yes') == True)
    assert(booleanize('TRUEx') == False)
    assert(booleanize('x1') == False)
    assert(booleanize('xY') == False)
    assert(booleanize('xYES') == False)
    assert(booleanize('') == False)
    assert(booleanize(None) == False)



# Generated at 2022-06-21 21:15:14.185835
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode('10') == 'X'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
   

# Generated at 2022-06-21 21:15:15.313582
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('VIIII') == 9

# Generated at 2022-06-21 21:15:16.764948
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
test_reverse()


# Generated at 2022-06-21 21:15:23.048433
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_case_str') == 'SnakeCaseStr'
    assert snake_case_to_camel('snake_case_str', upper_case_first = False) == 'snakeCaseStr'
    assert snake_case_to_camel('snake__case_str') == 'SnakeCaseStr'
    assert snake_case_to_camel('snake_case_str__') == 'SnakeCaseStr'



# Generated at 2022-06-21 21:15:28.767462
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('YeS') == True
    assert booleanize('y') == True
    test_booleanize()
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('0') == False
    assert booleanize('n') == False
    assert booleanize('nope') == False


# Generated at 2022-06-21 21:15:34.902585
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    return compressed



# Generated at 2022-06-21 21:15:48.120456
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!", separator='_') == "top_10_reasons_to_love_dogs"
    assert slugify("Mönstér Mägnët", separator="_") == "monster_magnet"
    assert slugify("Bä") == "ba"

# Call test cases
test_slugify()



# Generated at 2022-06-21 21:15:54.595412
# Unit test for function prettify
def test_prettify():
    before = 'foo,bar,baz'
    after = prettify(before)
    expected = 'Foo, bar, baz'
    if after != expected:
        print('Error in prettify()', file=sys.stderr)
        print('Input:', file=sys.stderr)
        print(before, file=sys.stderr)
        print('Expected:', file=sys.stderr)
        print(expected, file=sys.stderr)
        print('Got:', file=sys.stderr)
        print(after, file=sys.stderr)
        sys.exit(1)



# Generated at 2022-06-21 21:15:56.762807
# Unit test for function strip_margin
def test_strip_margin():
  expected = '\nline 1\nline 2\nline 3'
  input = '''\
      line 1
      line 2
      line 3
    '''
  assert strip_margin(input) == input.strip(), 'test_strip_margin failed'




# Generated at 2022-06-21 21:16:00.955458
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('this_is_a_camel_case_string_test') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('THIS_IS_A_CAMEL_CASE_STRING_TEST') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-21 21:16:07.132460
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'test'
    encoding = 'utf-8'
    compressed_string = __StringCompressor.compress(original_string, encoding)
    decompressed_string = __StringCompressor.decompress(compressed_string, encoding)

    assert(original_string == decompressed_string)


# PUBLIC API



# Generated at 2022-06-21 21:16:10.395429
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-21 21:16:18.806332
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('tHisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('tHis_IsACamelStringTest') == 't_his_is_a_camel_string_test'
    assert camel_case_to_snake('t_his_IsACamelStringTest') == 't_his_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-21 21:16:23.981299
# Unit test for function strip_margin
def test_strip_margin():
    result = strip_margin('''
        |line 1
        |line 2
        |line 3
    '''.strip())
    assert result == '''
        line 1
        line 2
        line 3
    '''.strip()

test_strip_margin()

# Generated at 2022-06-21 21:16:33.014326
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    rn = __RomanNumbers
    assert rn.encode(1) == 'I'
    assert rn.encode(4) == 'IV'
    assert rn.encode(5) == 'V'
    assert rn.encode(9) == 'IX'
    assert rn.encode(10) == 'X'
    assert rn.encode(40) == 'XL'
    assert rn.encode(50) == 'L'
    assert rn.encode(90) == 'XC'
    assert rn.encode(100) == 'C'
    assert rn.encode(400) == 'CD'
    assert rn.encode(500) == 'D'
    assert rn.encode(900) == 'CM'
    assert rn.encode(1000)

# Generated at 2022-06-21 21:16:36.736828
# Unit test for function asciify
def test_asciify():
    print(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))


# Generated at 2022-06-21 21:16:51.612684
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('y')

    assert not booleanize('false')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('n')


# Generated at 2022-06-21 21:17:01.231337
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='-') == 'The-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator=' ') == 'the snake is green'


# Generated at 2022-06-21 21:17:12.844993
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('AaBbCc').format() == 'Aa Bb Cc'
    assert __StringFormatter('aabbcc').format() == 'Aabbcc'
    assert __StringFormatter('aabbcc    ').format() == 'Aabbcc'
    assert __StringFormatter('    aabbcc    ').format() == 'Aabbcc'
    assert __StringFormatter('AAbbcc').format() == 'Aa Bbcc'
    assert __StringFormatter('òòòÃÃ').format() == 'Òòò ÃÃ'
    assert __StringFormatter('example@gmail.com').format() == 'Example@gmail.com'
    assert __StringFormatter('example.gmail.com').format() == 'Example.gmail.com'

# Generated at 2022-06-21 21:17:14.117928
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7


# Generated at 2022-06-21 21:17:17.172444
# Unit test for function roman_decode
def test_roman_decode():
    roman_decode(input_string)



# Generated at 2022-06-21 21:17:23.223878
# Unit test for function decompress
def test_decompress():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.extra.pytest import register_assert_rewrite

    register_assert_rewrite('string.hypothesis_support:assert_decompress')

    @given(text(min_size=1))
    def test_decompress_with_original(original):
        assert_decompress(original)

    test_decompress_with_original()


# Generated at 2022-06-21 21:17:32.062724
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönster Magnet  ') == 'monster-magnet'
    assert slugify('Mönster Magnet  ', 'XXX') == 'monsterXXXmagnet'
    assert slugify('  Mönster Magnet  ', 'XXX') == 'monsterXXXmagnet'
    assert slugify('   Mönster Magnet   ', 'XXX') == 'monsterXXXmagnet'



# Generated at 2022-06-21 21:17:41.104783
# Unit test for function strip_margin
def test_strip_margin():
    # remove white space and new line
    txt = '''\t\t\t\t\t\t\t\t\t\t\t\t
    \t\t\t\t\t\t\t\t\t\t\t\t
    \t\t\t\t\t\t\t\t\t\t\t\tHello World
    \t\t\t\t\t\t\t\t\t\t\t\t'''
    print(strip_margin(txt))
    assert strip_margin(txt) == 'Hello World\n'
    print("test_strip_margin success")
if __name__ == '__main__':
    test_strip_margin()


# Generated at 2022-06-21 21:17:52.812794
# Unit test for constructor of class __StringFormatter

# Generated at 2022-06-21 21:17:55.594447
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # call function
    result = snake_case_to_camel('the_snake_is_green')

    # check result
    assert result == 'TheSnakeIsGreen'
    assert isinstance(result, str)

