

# Generated at 2022-06-21 21:13:36.288716
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)




# Generated at 2022-06-21 21:13:37.526598
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'

# Generated at 2022-06-21 21:13:38.484969
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("Hello world") != "Hello world"



# Generated at 2022-06-21 21:13:42.923108
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:13:49.533694
# Unit test for function decompress
def test_decompress():

    try:
        __StringCompressor.compress(None, 'utf-8', 1)
        # Error: it must raise InvalidInputError with input_string=None
        print('InvalidInputError not raised with None as input_string')
        # return False
    except InvalidInputError:
        pass # it must raise InvalidInputError with input_string=None
    except Exception as e:
        # Error: it must raise InvalidInputError with input_string=None
        print('InvalidInputError not raised with None as input_string (raised {} instead)'.format(e.__class__.__name__))
        # return False


# Generated at 2022-06-21 21:14:02.566422
# Unit test for function decompress
def test_decompress():
    assert __StringCompressor.decompress('eJy2V1sOwjAMBdDvrNjR1nvPPX9JNl8qIqAuFj/sQsxwCAnJ4YmzIaLUSLnXbjFZSnIrSNE7VTH+cchhRY7nA==', encoding='utf-8') is ' '.join(['word n{}'.format(n) for n in range(20)])

# Generated at 2022-06-21 21:14:07.170189
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()


# Generated at 2022-06-21 21:14:10.711026
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsAStringTest') == 'this_is_a_string_test'
    assert camel_case_to_snake('ThisIsAnotherStringTest', '-') == 'this-is-another-string-test'
    assert camel_case_to_snake('ThisIsAStringTest', '!') == 'this!is!a!string!test'
    assert camel_case_to_snake('ThisIsAStringTest') != 'this!is!a!string!test'



# Generated at 2022-06-21 21:14:17.412829
# Unit test for function roman_encode
def test_roman_encode():
    """
    Unit test for function roman_encode
    """
    assert(roman_encode(37) == 'XXXVIII')
    assert(roman_encode('2020') == 'MMXX')
    assert(roman_encode(2020) == 'MMXX')
    assert(roman_encode(3999) == 'MMMCMXCIX')



# Generated at 2022-06-21 21:14:18.258305
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('cxx') == 120



# Generated at 2022-06-21 21:14:28.993658
# Unit test for function slugify
def test_slugify():
    assert(slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs')
    assert(slugify('Mönstér Mägnët') == 'monster-magnet')


# Generated at 2022-06-21 21:14:33.245410
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print(compressed)
    # assert True
test_compress()


# Generated at 2022-06-21 21:14:34.974946
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_camel_string_test' == camel_case_to_snake('ThisIsACamelStringTest')



# Generated at 2022-06-21 21:14:39.436411
# Unit test for function strip_html
def test_strip_html():
    assert is_string(strip_html('test: <a href="foo/bar">click here</a>'))
    assert is_string(strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True))


# Generated at 2022-06-21 21:14:50.734794
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('a_b_c_d_e_f') == 'ABCDEF'
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('this_is_not_a_snake') == 'ThisIsNotASnake'
    assert snake_case_to_camel('this_is_not_a_snake', False) == 'thisIsNotASnake'

# Generated at 2022-06-21 21:14:58.425008
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'test'
    compressed_string = __StringCompressor.compress(original_string)
    assert compressed_string is not None
    assert len(compressed_string) > 0
    decompressed_string = __StringCompressor.decompress(compressed_string)
    assert decompressed_string is not None
    assert len(decompressed_string) > 0


# PUBLIC API



# Generated at 2022-06-21 21:15:01.058251
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'

import unittest
from unittest.mock import patch



# Generated at 2022-06-21 21:15:04.585011
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    __StringFormatter('test')


# PUBLIC API



# Generated at 2022-06-21 21:15:15.330413
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # pylint: disable=W0612

    def assert_compress_decompress(input_string: str, encoding: str = 'utf-8'):
        compressed = __StringCompressor.compress(input_string, encoding)
        decompressed = __StringCompressor.decompress(compressed, encoding)
        assert decompressed == input_string

    assert_compress_decompress('hello world!')
    assert_compress_decompress('!£$%&/()=?^_ù*+@#-<>|\\ç^~[]{}àèéìòù')
    assert_compress_decompress('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert_compress_decompress

# Generated at 2022-06-21 21:15:20.984705
# Unit test for function booleanize
def test_booleanize():
    assert booleanize(None) == False
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('') == False

    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
test_booleanize()



# Generated at 2022-06-21 21:15:30.815553
# Unit test for function slugify
def test_slugify():
    input_string1 = "Top 10 Reasons To Love Dogs!!!"
    expected_result1 = "top-10-reasons-to-love-dogs"
    assert slugify(input_string1) == expected_result1

    input_string2 = "Mönstér Mägnët"
    expected_result2 = "monster-magnet"
    assert slugify(input_string2) == expected_result2
    
    print("test_slugify: test passed")
    
test_slugify()


# Generated at 2022-06-21 21:15:36.694562
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('tutti i capelli ai forti').input_string == 'tutti i capelli ai forti'
    assert __StringFormatter('tutti i capelli ai forti').input_string is not None
    assert __StringFormatter('tutti i capelli ai forti').input_string != ''


# Generated at 2022-06-21 21:15:47.702474
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'Hello world, how are you doing today?'
    encoding = 'utf-8'
    compression_level = 2

    compressed_string = __StringCompressor.compress(input_string, encoding=encoding, compression_level=compression_level)
    print('- compressed_string: "{}"'.format(compressed_string))

    decompressed_string = __StringCompressor.decompress(compressed_string, encoding=encoding)
    print('- decompressed_string: "{}"'.format(decompressed_string))

    assert input_string == decompressed_string


# PUBLIC API



# Generated at 2022-06-21 21:15:55.535177
# Unit test for function strip_html
def test_strip_html():
    assert strip_html("<html><body></body></html>") == ""
    assert strip_html("<html><body>hello</body></html>") == "hello"
    assert strip_html("<html><body>hello</body></html>", keep_tag_content=True) == "hello"
    assert strip_html("<html><body>hello\nworld</body></html>") == "helloworld"
    assert strip_html("<html><body>hello\n<br>world</body></html>") == "helloworld"
    assert strip_html("<html><body>hello<br>world</body></html>") == "helloworld"
    assert strip_html("<html><body>hello<br/>world</body></html>") == "helloworld"

# Generated at 2022-06-21 21:15:59.995850
# Unit test for function shuffle
def test_shuffle():
    # Arrange
    input_string = "hello world"
    expected_output = "lodrwheoll"

    # Act
    actual_output = shuffle(input_string)

    # Assert
    assert expected_output == actual_output



# Generated at 2022-06-21 21:16:01.383727
# Unit test for function roman_decode
def test_roman_decode():
    assert type(roman_decode('VII')) == int

# Generated at 2022-06-21 21:16:02.750664
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'heolld'



# Generated at 2022-06-21 21:16:07.346720
# Unit test for function decompress
def test_decompress():
    assert ' '.join(['word n{}'.format(n) for n in range(20)]) == decompress(compress(' '.join(['word n{}'.format(n) for n in range(20)])))
    assert 'Hello World' == decompress(compress('Hello World'))
    assert 'A' == decompress(compress('A'))
    assert 'BBBB' == decompress(compress('BBBB'))
    assert 'Hello World' == decompress('eJw5cGtcKKt3zc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc9YBAQCg==')

if __name__ == '__main__':
    test_decompress()



# Generated at 2022-06-21 21:16:09.216447
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-21 21:16:11.336577
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')=='eeuuooaaeynAAACIINOE'

test_asciify()



# Generated at 2022-06-21 21:16:27.530780
# Unit test for function shuffle
def test_shuffle():
    input_string = "hello"
    shuffled = shuffle(input_string)
    # join both strings into one, if the function works we will get a string of length 10
    # otherwise it means that the shuffled string is missing some chars from the original one
    if len(shuffled+input_string) == 10:
        print('Test for shuffle() successful!')
    else:
        print('Test for shuffle() failed!')



# Generated at 2022-06-21 21:16:33.386044
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_string = """
    Hey @guido, I have found this great article with a lot of useful info about regular expressions:
    'https://www.regular-expressions.info/email.html'.
    Check it out when you have some free time!
    """

    expected_output = """
    Hey @guido, I have found this great article with a lot of useful info about regular expressions:
    'https://www.regular-expressions.info/email.html'.
    Check it out when you have some free time!
    """

    assert __StringFormatter(input_string).format() == expected_output



# Generated at 2022-06-21 21:16:40.420569
# Unit test for function strip_margin
def test_strip_margin():
    # Arrange
    test_string = strip_margin('''
    line1
      line2
      line3
      ''')
    expected_string = '''
    line1
    line2
    line3
    '''
    # Act
    output = strip_margin(test_string)
    # Assert
    assert output == expected_string
test_strip_margin()

# Generated at 2022-06-21 21:16:44.937068
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '.') == 'TheSnakeIsGreen'



# Generated at 2022-06-21 21:16:50.601684
# Unit test for function strip_margin
def test_strip_margin():
    input_string = """
                    line 1
                    line 2
                    line 3
                    """
    expected_string = """
                    line 1
                    line 2
                    line 3
                    """
    assert(strip_margin(input_string) == expected_string)

# Generated at 2022-06-21 21:16:56.019090
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XXXVIII') == 38
    assert roman_decode('LXVII') == 67
    assert roman_decode('MMXX') == 2020
    assert roman_decode('MMMCMXCIX') == 3999
    
    
# Unit tests for function roman_encode

# Generated at 2022-06-21 21:16:58.761795
# Unit test for function strip_margin
def test_strip_margin():
    value = '''
                line 1
                line 2
                line 3
            '''
    assert strip_margin(value) == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-21 21:17:00.929676
# Unit test for function prettify
def test_prettify():
    # TODO: Looks more like an integration test, is that good?
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:17:12.844957
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != ''
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    try: 
        asciify(1)
        assert False
    except InvalidInputError:
        assert True
    
    


# Generated at 2022-06-21 21:17:14.164628
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'

