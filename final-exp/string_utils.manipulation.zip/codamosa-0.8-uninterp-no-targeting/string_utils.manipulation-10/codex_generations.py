

# Generated at 2022-06-21 21:13:37.674801
# Unit test for function asciify
def test_asciify():
    """
    Test for function asciify
    """

    # Test strings containing only ascii chars
    # (no chars should be lost while transcoding)
    assert asciify('foo') == 'foo'
    assert asciify('foo!') == 'foo!'
    assert asciify('123') == '123'

    # Test strings containing non ascii chars
    # (some/all chars may be lost while transcoding, it depends on the chars)
    assert asciify('éèà') == 'eea'
    assert asciify('ÉÈÀ') == 'EEE'
    assert asciify('$€') == '$'
    assert asciify('ç') == 'c'
    assert asciify('Ññ') == 'NN'

    # Test for encoding error
    # (the given string is

# Generated at 2022-06-21 21:13:39.158357
# Unit test for function shuffle
def test_shuffle():
    for i in range(100):
        assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-21 21:13:42.812491
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("thisIsACamelStringTest") == "this_is_a_camel_string_test"



# Generated at 2022-06-21 21:13:48.122122
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('420') == False
    assert booleanize('false') == False
    assert booleanize('False') == False
try:
    test_booleanize()
except Exception as e:
    print(e)



# Generated at 2022-06-21 21:13:55.031897
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(14) == 'XIV'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(969) == 'CMLXIX'
    assert __RomanNumbers.encode(1977) == 'MCMLXXVII'
    assert __RomanNumbers.encode(2599) == 'MMDXCIX'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'

    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('III') == 3
    assert __RomanNumbers.decode('IV')

# Generated at 2022-06-21 21:14:01.536295
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert original == decompressed


# Generated at 2022-06-21 21:14:12.640054
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == "I"
    assert __RomanNumbers.encode(5) == "V"
    assert __RomanNumbers.encode(10) == "X"
    assert __RomanNumbers.encode(15) == "XV"
    assert __RomanNumbers.encode(19) == "XIX"
    assert __RomanNumbers.encode(20) == "XX"
    assert __RomanNumbers.encode(27) == "XXVII"
    assert __RomanNumbers.encode(48) == "XLVIII"
    assert __RomanNumbers.encode(49) == "XLIX"
    assert __RomanNumbers.encode(50) == "L"
    assert __RomanNumbers.encode(51) == "LI"
    assert __RomanNumbers.encode(60) == "LX"


# Generated at 2022-06-21 21:14:23.466502
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''\
        |abc
        |def
        |ghi
        ''') == '''\
        abc
        def
        ghi
        '''
    assert strip_margin('''\
        |||abc
        |||def
        |||ghi
        ''') == '''\
        |abc
        |def
        |ghi
        '''
    assert strip_margin('''\
        |abc
        |||def
        |||ghi
        ''') == '''\
        abc
        |def
        |ghi
        '''
    assert strip_margin('''\
        |abc
        |||def
        |ghi
        ''') == '''\
        abc
        |||def
        ghi
        '''

# Generated at 2022-06-21 21:14:34.220829
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:14:43.422582
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from random import randint

    text = 'Hello World!'
    compressed_text = __StringCompressor.compress(text)
    decompressed_text = __StringCompressor.decompress(compressed_text)

    print('--- __StringCompressor ---')
    print('text:', text)
    print('compressed_text:', compressed_text)
    print('decompressed_text:', decompressed_text)

    for test in range(0, 10):
        max_length = randint(0, 100)

# Generated at 2022-06-21 21:15:01.556399
# Unit test for function booleanize
def test_booleanize():
    # Note that unittest is not used here so that the code coverage will be seperate for this unit test
    test_cases = {
        "False":False,
        "False1":False,
        "False1":False,
        "true":True,
        "True":True,
        "TRUE":True,
        "YES":True,
        "Yes":True,
        "YES1":True,
        "YEs":True,
        "Y":True,
        "y":True,
        "1":True,
        "1YES":True,
        "yes1":True,
        "1yes":True,
        "y1es":True,
        "11":True,
    }
    for test_string in test_cases:
        expected_value = test_cases[test_string]
        actual_

# Generated at 2022-06-21 21:15:08.592968
# Unit test for function asciify
def test_asciify():
    input_string = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    ascii_string = 'eeuuooaaeynAAACIINOE'
    assert asciify(input_string) == ascii_string



# Generated at 2022-06-21 21:15:19.862936
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .errors import InvalidInputError
    from .validation import is_string


# Generated at 2022-06-21 21:15:24.081243
# Unit test for function asciify
def test_asciify():
    bad_data = ['èéùúòóäåëýñÅÀÁÇÌÍÑÓË']
    good_data = 'eeuuooaaeynAAACIINOE'

    result = asciify(bad_data)

    if result == good_data:
        return True
    else:
        return False

test_asciify()


# Generated at 2022-06-21 21:15:27.888264
# Unit test for function strip_html
def test_strip_html():
    test_string = 'test: <a <a href="foo/bar">click here</a>'
    stripped = 'test: '
    try:
        assert strip_html(test_string) == stripped
    except AssertionError:
        if not strip_html(test_string) == stripped:
            print("test failed: strip_html")


# Generated at 2022-06-21 21:15:36.651791
# Unit test for function compress
def test_compress():
    assert compress('test') == 'test'
    assert compress('mytest') == 'mytest'
    assert compress('1234') == '1234'
    assert compress('with spaces') == 'with spaces'
    assert compress(' '.join(['word n{}'.format(n) for n in range(20)])) == 'word n0 word n1 word n2 word n3 word n4 word n5 word n6 word n7 word n8 word n9 word n10 word n11 word n12 word n13 word n14 word n15 word n16 word n17 word n18 word n19'


# Generated at 2022-06-21 21:15:47.151279
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel(' ') == ' '
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('-_-') == '-_-'

# Generated at 2022-06-21 21:15:51.927766
# Unit test for function decompress
def test_decompress():
    from pyss.utils import compress, decompress

    encoding = 'utf-8'
    original_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed_string = compress(original_string)
    decompressed_string = decompress(compressed_string)
    assert (decompressed_string == original_string)



# Generated at 2022-06-21 21:15:56.902865
# Unit test for function reverse
def test_reverse():
    assert reverse(input_string='hello') == 'olleh'
    assert reverse(input_string='HELLO') == 'OLLEH'
    assert reverse(input_string='   ') == '   '
    assert reverse(input_string='no need for an input') == 'tupni rof daene on'
    assert reverse(input_string='-&@*{}') == '}*@&-'
    assert reverse(input_string='') == ''
    assert type(reverse(input_string='hello')) == str



# Generated at 2022-06-21 21:16:01.496432
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(39) == 'XXXIX'
    assert roman_encode(40) == 'XL'
    assert roman_encode(49) == 'XLIX'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'
    assert roman_encode(99) == 'XCIX'

# Generated at 2022-06-21 21:16:08.806418
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') is not None
    assert len(shuffle('hello world')) == len('hello world')


# Generated at 2022-06-21 21:16:10.142736
# Unit test for function decompress
def test_decompress():
    assert (decompress(compress('test')) == 'test')



# Generated at 2022-06-21 21:16:11.385637
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
        assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-21 21:16:19.775552
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-21 21:16:25.069153
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('', separator='-') == ''
    assert camel_case_to_snake(' ') == ' '
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='') == 'thisisacamelstringtest'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator=None) == 'thisisacamelstringtest'
    assert camel_case_to_snake(None) == ''
    assert camel_case_to

# Generated at 2022-06-21 21:16:29.254656
# Unit test for function shuffle
def test_shuffle():
    t_string = 'hello world'
    t_string_result = shuffle(t_string)
    assert t_string_result != t_string
    assert len(t_string_result) == len(t_string)
    assert set(t_string_result) == set(t_string)
    


# Generated at 2022-06-21 21:16:41.830602
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('abc') is not None
    assert __StringFormatter('abc').input_string == 'abc'
    assert __StringFormatter('abc').__uppercase_first_char is not None
    assert __StringFormatter('abc').__remove_duplicates is not None
    assert __StringFormatter('abc').__uppercase_first_letter_after_sign is not None
    assert __StringFormatter('abc').__ensure_right_space_only is not None
    assert __StringFormatter('abc').__ensure_left_space_only is not None
    assert __StringFormatter('abc').__ensure_spaces_around is not None
    assert __StringFormatter('abc').__remove_internal_spaces is not None

# Generated at 2022-06-21 21:16:53.728017
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(56) == 'LVI'
    assert roman_encode('18') == 'XVIII'
    assert roman_encode(89) == 'LXXXIX'
    assert roman_encode('1') == 'I'
    assert roman_encode(19) == 'XIX'
    assert roman_encode('90') == 'XC'
    assert roman_encode(50) == 'L'
    assert roman_encode('4') == 'IV'
    assert roman_encode(33) == 'XXXIII'
    assert roman_encode('3999') == 'MMMCMXCIX'
    assert roman

# Generated at 2022-06-21 21:16:55.707078
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode(1) == 1



# Generated at 2022-06-21 21:16:57.106440
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh', 'Cannot reverse the string'


# Generated at 2022-06-21 21:17:11.044160
# Unit test for function decompress
def test_decompress():
    original_string = 'test 123'
    expected_string = original_string
    assert(decompress(compress(original_string)) == expected_string)


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# REGEX HELPERS


# Generated at 2022-06-21 21:17:13.327779
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'


# Generated at 2022-06-21 21:17:18.129231
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                            ''') == '''
line 1
line 2
line 3
'''

test_strip_margin()



# Generated at 2022-06-21 21:17:26.629670
# Unit test for function compress

# Generated at 2022-06-21 21:17:30.999819
# Unit test for function booleanize
def test_booleanize():
    assert not booleanize('')
    assert not booleanize('False')
    assert booleanize('true')
    assert booleanize('True')
    assert booleanize('yes')
    assert booleanize('1')
    assert booleanize('Y')


# Generated at 2022-06-21 21:17:38.503860
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"
    assert slugify("Mönstér Mägnët") == "monster-magnet"
    assert slugify("You're an idiot") == "youre-an-idiot"
    assert slugify("-youre-an-idiot-") == "youre-an-idiot"
    
test_slugify()

compress('some string to compress')


# Generated at 2022-06-21 21:17:44.235675
# Unit test for function prettify

# Generated at 2022-06-21 21:17:49.044633
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('??????') == ''
    assert slugify('    ') == ''



# Generated at 2022-06-21 21:17:52.135285
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed == original



# Generated at 2022-06-21 21:17:56.388113
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XX')==20
    assert roman_decode('xxx')==30
    assert roman_decode('l')==50
    assert roman_decode('cc')==200
    assert roman_decode('dm')==500
    assert roman_decode('m')==1000
    # Add your test here

# Generated at 2022-06-21 21:18:14.614889
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'

# Generated at 2022-06-21 21:18:19.971683
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs', "Incorrect function output"
    assert slugify('Mönstér Mägnët') == 'monster-magnet', "Incorrect function output"



# Generated at 2022-06-21 21:18:27.939807
# Unit test for function prettify

# Generated at 2022-06-21 21:18:36.136368
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-21 21:18:42.487434
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(4) == "IV"
    assert roman_encode(3999) == "MMMCMXCIX"
    assert roman_encode(140) == "CXL"
    assert roman_encode(310) == "CCCX"
    assert roman_encode(1000) == "M"

test_roman_encode()


# Generated at 2022-06-21 21:18:51.536877
# Unit test for function asciify
def test_asciify():
    ascii_string = 'Dogs like to play, but also like to eat.'
    non_ascii_string = '赤髪の女の子が私の友人だよ。チェスを一緒にプレイしたい。'

    assert ascii_string == ascii_string
    assert 'Dogsliketoplaybutalso liketoeat.' == asciify(ascii_string)
    assert 'Chesswolikeplay.' == asciify(non_ascii_string)
test_asciify()


# Generated at 2022-06-21 21:19:04.132057
# Unit test for function shuffle

# Generated at 2022-06-21 21:19:06.043719
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") != 'hello world'
    assert len(shuffle("hello world")) == len("hello world")
test_shuffle()



# Generated at 2022-06-21 21:19:12.180282
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello').input_string == 'hello'
    assert __StringFormatter('hello').__uppercase_first_char('hello') == 'Hello'
    assert __StringFormatter('hello').__remove_duplicates('hell') == 'hel'
    assert __StringFormatter('hello').__uppercase_first_letter_after_sign('-hello hello') == '-Hello hello'
    assert __StringFormatter('hello').__ensure_right_space_only('hello ') == 'hello '
    assert __StringFormatter('hello').__ensure_left_space_only(' hello') == ' hello'
    assert __StringFormatter('hello').__ensure_spaces_around(' hello ') == ' hello '

# Generated at 2022-06-21 21:19:14.499150
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('hello') == 'hello'
    assert camel_case_to_snake('HelloWorld') == 'hello_world'
    assert camel_case_to_snake('CamelCaseToSnake') == 'camel_case_to_snake'
    assert camel_case_to_snake('TestStringXYZ') == 'test_string_xyz'

