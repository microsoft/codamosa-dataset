

# Generated at 2022-06-21 21:13:32.377499
# Unit test for function roman_decode
def test_roman_decode():
    assert 7 == roman_decode('VII')
    assert 777 == roman_decode('DCCLXXVII')
    assert 2020 == roman_decode('MMXX')

# Generated at 2022-06-21 21:13:42.102062
# Unit test for function slugify
def test_slugify():
    assert slugify("A b c d e . . . . . . . . .") == 'a-b-c-d-e'
    assert slugify("Dogs are nice", "*") == "dogs*are*nice"
    assert slugify("Dogs,are  good.   .") == 'dogs-are-good'
    assert slugify("a * b * c") == "a-b-c"
    assert slugify("Mönstér Mägnët") == "monster-magnet"
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"

# Generated at 2022-06-21 21:13:42.825242
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert isinstance(__StringCompressor(), __StringCompressor)



# Generated at 2022-06-21 21:13:44.285594
# Unit test for function strip_margin
def test_strip_margin():
    multi_line_string = '''
                            line 1
                            line 2
                            line 3
                         '''
    stripped = '''
line 1
line 2
line 3
'''

    assert strip_margin(multi_line_string) == stripped

# Generated at 2022-06-21 21:13:49.208520
# Unit test for function decompress
def test_decompress():
    s = "https://www.googleapis.com/compute/v1/projects/test-infra-193903/zones/us-central1-a/instances?key=AIzaSyCBhf1N3DLeXe3qKs-sW2J8iKFvP11q3qM"
    compressed_string = compress(s)
    print(compressed_string)
    decompressed_string = decompress(compressed_string)
    print(decompressed_string)
    assert s == decompressed_string
test_decompress()


# Generated at 2022-06-21 21:13:53.296571
# Unit test for function slugify
def test_slugify():
    assert 'top-10-reasons-to-love-dogs' == slugify('Top 10 Reasons To Love Dogs!!!')
    assert 'monster-magnet' == slugify('Mönstér Mägnët')
    assert 'i-am-a-slug' == slugify('I am a slug.')
    assert 'super-mario-world-2' == slugify('Super Mario World 2: Yoshi\'s Island')



# Generated at 2022-06-21 21:14:00.470922
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter(' s   f ')

    # remove internal spaces
    actual = sf.format()
    assert actual == 's f', actual

    sf = __StringFormatter('   this is a string   ')

    # remove internal spaces
    actual = sf.format()
    assert actual == 'this is a string', actual

    # add spaces around
    actual = sf.format()
    assert actual == 'this is a string', actual

    sf = __StringFormatter('a:b:c:d:e:f:g:h')

    # spaces around
    actual = sf.format()
    assert actual == 'a : b : c : d : e : f : g : h', actual

    # add spaces around
    actual = sf.format()

# Generated at 2022-06-21 21:14:10.915804
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # generate a placeholder key string
    def placeholder(p=None):
        if p is None:
            p = __StringFormatter.__placeholder_key()
        return p

    # test a set of input strings against expected output
    def test(input_string, expected_output):
        out = __StringFormatter(input_string).format()
        assert out == expected_output, "expected '{}', got '{}'".format(expected_output, out)

    test('''this is\nnumber "1"''', 'This Is Number 1')
    test('This is number 1', 'This Is Number 1')
    test('This is number "1"', 'This Is Number 1')
    test('This is number 1', 'This Is Number 1')
    test('This is "number" 1', 'This Is Number 1')
   

# Generated at 2022-06-21 21:14:19.206325
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-21 21:14:28.197317
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .validation import is_base64_url_safe

    input_string = 'lorem ipsum dolor sit amet'
    expected_output = 'bG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQ='

    result = __StringCompressor.compress(input_string)

    assert is_base64_url_safe(result)
    assert result == expected_output
    assert __StringCompressor.decompress(result) == input_string



# Generated at 2022-06-21 21:14:35.050492
# Unit test for function compress
def test_compress():
    assert compress('') == __StringCompressor.compress('', compression_level=9)
    assert compress('asdfghj') == __StringCompressor.compress('asdfghj', compression_level=9)



# Generated at 2022-06-21 21:14:44.315022
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_snake_case_string') == 'ASnakeCaseString'
    assert snake_case_to_camel('a_snake_case_string', upper_case_first=False) == 'aSnakeCaseString'
    assert snake_case_to_camel('a_snake_case_string', separator='-') == 'a-snake-case-string'
    assert snake_case_to_camel('a-snake-case-string', separator='-') == 'ASnakeCaseString'



# Generated at 2022-06-21 21:14:50.357472
# Unit test for function asciify
def test_asciify():
    # Test 1: normal use
    try:
        assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    except Exception:
        print("Error in test_asciify: Test 1 failed")
    else:
        print("Success in test_asciify: Test 1 passed")

    # Test 2: empty string
    try:
        assert asciify('') == ''
    except Exception:
        print("Error in test_asciify: Test 2 failed")
    else:
        print("Success in test_asciify: Test 2 passed")

    # Test 3: invalid type

# Generated at 2022-06-21 21:15:02.682207
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # test for return type
    assert isinstance(__StringFormatter('foooooooo').format(), str)

    # test for handling empty input
    assert __StringFormatter('').format() == ''

    # test for handling None input
    try:
        __StringFormatter(None).format()
        raise Exception('Expected InvalidInputError to be raised')
    except InvalidInputError:
        pass

    # test for handling invalid input
    try:
        __StringFormatter(1).format()
        raise Exception('Expected InvalidInputError to be raised')
    except InvalidInputError:
        pass

    # test for uppercasing first word char
    assert __StringFormatter('foo').format() == 'Foo'

    # test for uppercasing first word char in a list

# Generated at 2022-06-21 21:15:05.778429
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    assert compressed != original
    assert len(compressed) < len(original)

    assert decompress(compressed) == original



# Generated at 2022-06-21 21:15:07.838553
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('abc')
    assert not __StringFormatter(123)


# Generated at 2022-06-21 21:15:17.960645
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    expected_output = 'TheSnakeIsGreen'

    assert snake_case_to_camel(input_string) == expected_output

    # check upper_case_first param
    assert snake_case_to_camel(input_string, upper_case_first=False) == 'theSnakeIsGreen'

    # check different separator
    assert snake_case_to_camel('separator-is-hyphen', separator='-') == 'SeparatorIsHyphen'
    assert snake_case_to_camel('separator_is_underscore', separator='_') == 'SeparatorIsUnderscore'

    # check invalid input
    assert snake_case_to_camel(input_string, '-') == input_string
    assert snake_case

# Generated at 2022-06-21 21:15:27.456610
# Unit test for function booleanize
def test_booleanize():
  assert booleanize('hello') == False
  assert booleanize('hello world') == False
  assert booleanize('') == False
  assert booleanize('True') == True
  assert booleanize('TRUE') == True
  assert booleanize('true') == True
  assert booleanize('True') == True
  assert booleanize('false') == False
  assert booleanize('0') == False
  assert booleanize('10') == False
  assert booleanize('1') == True
  assert booleanize('0') == False
  assert booleanize('yes') == True
  assert booleanize('no') == False
  assert booleanize('YES') == True
  assert booleanize('NO') == False
  assert booleanize('y') == True
  assert booleanize('n') == False



# Generated at 2022-06-21 21:15:37.467601
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert compressed == 'eJxVyjEKgzAQheGzMTCaUAUXZUeFA6DNbVkpTlyFHxTjnhT8TawgQ2DdewnKiXfW45sSBiKQByIIIa0G0Ie1wWkCgOmi33bEz1tM0mB09Mga/Jd7bePTiOy/R7w+/kf5/1Ei'



# Generated at 2022-06-21 21:15:48.190911
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('Test') == 'test'
    assert camel_case_to_snake('Test123') == 'test123'
    assert camel_case_to_snake('123Test') == '123_test'
    assert camel_case_to_snake('test') == 'test'
    assert camel_case_to_snake('test123') == 'test123'
    assert camel_case_to_snake('test12test') == 'test12test'