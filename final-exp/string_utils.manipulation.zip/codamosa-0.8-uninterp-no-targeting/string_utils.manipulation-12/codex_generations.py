

# Generated at 2022-06-21 21:13:35.274489
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_test' == camel_case_to_snake('thisIsATest')
    assert 'this_is_a_camel_case_test' == camel_case_to_snake('thisIsACamelCaseTest')
    assert 'this_is_a_mixed_case_test' == camel_case_to_snake('thisIsAMixedCaseTest')
    assert 'all_good' == camel_case_to_snake('AllGood')



# Generated at 2022-06-21 21:13:37.784138
# Unit test for function strip_margin
def test_strip_margin():
    test_value = '''
        |first line
        |second line
        |third line
        '''
    expected_value = '''
first line
second line
third line
'''
    assert strip_margin(test_value) == expected_value

# Generated at 2022-06-21 21:13:42.943844
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert original != compressed
    assert len(original) == 169
    assert len(compressed) == 88
    assert decompress(compressed) == original



# Generated at 2022-06-21 21:13:45.100085
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("True") == True
    assert booleanize("False") == False
    assert booleanize("true") == True
    assert booleanize("false") == False
    assert booleanize("N") == False


# Generated at 2022-06-21 21:13:53.224401
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('no') == False
    assert booleanize('NO') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    assert booleanize('truuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuue') == True
    assert booleanize('') == False



# Generated at 2022-06-21 21:14:05.062469
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('Кириллица') == 'Кириллица'
    assert asciify('Ä«īļņĚěšýžč') == 'Ä··········ý···'
    assert asciify('äëïöüÿÄËÏÖÜŸàâçèéêëîïôùûüÿ') == 'aeiouyAEIOUYaeceeeeiouuuy'

# Generated at 2022-06-21 21:14:06.393171
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('a').input_string == 'a'


# Generated at 2022-06-21 21:14:14.687786
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert(snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen')
    assert(snake_case_to_camel('TheSnakeIsGreen', upper_case_first=False) == 'TheSnakeIsGreen')
    assert(snake_case_to_camel('thisIsACamelCaseTest') == 'ThisIsACamelCaseTest')
    assert(snake_case_to_camel('thisIsACamelCaseTest', upper_case_first=False) == 'thisIsACamelCaseTest')

# Generated at 2022-06-21 21:14:16.183974
# Unit test for function decompress
def test_decompress():
    # Assert
    assert decompress("eJzTWkbNqy3JQXbMkigAABOhLgg=","utf-8") == "HelloWorld"


# Generated at 2022-06-21 21:14:28.657094
# Unit test for function prettify
def test_prettify():
    assert prettify('') == ''
    assert prettify(' test ') == 'test'
    assert prettify('test ') == 'test'
    assert prettify(' test') == 'test'
    assert prettify('     test     ') == 'test'
    assert prettify('test test') == 'test test'
    assert prettify('test.test') == 'Test.test'
    assert prettify('test.test') == 'Test.test'
    assert prettify('test!test') == 'Test!test'
    assert prettify('test?test') == 'Test?test'
    assert prettify('test test.test') == 'Test test.test'
    assert prettify('test.test    test') == 'Test.test test'
    assert prettify('test!test?test.') == 'Test!test?test.'


# Generated at 2022-06-21 21:14:37.130932
# Unit test for function decompress
def test_decompress():
    text = 'test'
    assert decompress(compress(text)) == 'test'


# Generated at 2022-06-21 21:14:48.723266
# Unit test for function prettify
def test_prettify():

    # Test uppercase_first_letter
    text = "hello world!"
    expected = "Hello world!"
    assert prettify(text) == expected

    # Test uppercase_first_letter after an exclamation mark
    text = "hello world!it's working!"
    expected = "Hello world! It's working!"
    assert prettify(text) == expected

    # Test uppercase_first_letter after a dot
    text = "hello world.it's working!"
    expected = "Hello world. It's working!"
    assert prettify(text) == expected

    # Test uppercase_first_letter after a question mark
    text = "Hello world?it's working!"
    expected = "Hello world? It's working!"
    assert prettify(text) == expected

    # Test uppercase_first_letter after a semi-col

# Generated at 2022-06-21 21:14:52.373796
# Unit test for function asciify
def test_asciify():
    a = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    b= 'eeuuooaaeynAAACIINOE'
    assert(asciify(a)==b),"Test Failed"
test_asciify()


# Generated at 2022-06-21 21:15:03.739843
# Unit test for function asciify
def test_asciify():
    assert is_string(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')) == True
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert is_string(asciify('èé')) == True
    assert asciify('èé') == 'ee'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'EEUUOOAAEEYNAAACIINOE'

# Generated at 2022-06-21 21:15:09.438795
# Unit test for function booleanize
def test_booleanize():
    assert not booleanize('')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('n')
    assert not booleanize('false')
    assert booleanize('true')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('y')


# Generated at 2022-06-21 21:15:11.710852
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-21 21:15:14.877385
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-21 21:15:26.086194
# Unit test for function slugify
def test_slugify():
    assert slugify("100%") == "100"
    assert slugify("The! Best-of10") == "the-best-of10"
    assert slugify("The! Best-of10") == "the-best-of10"
    assert slugify("This Is A Test!") == "this-is-a-test"
    assert slugify("Mönstér Mägnët") == "monster-magnet"
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"

# Generated at 2022-06-21 21:15:29.610740
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('FALSE') == False


# Generated at 2022-06-21 21:15:31.998684
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('    abc    ').input_string == '    abc    '



# Generated at 2022-06-21 21:15:46.992965
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-21 21:15:51.580411
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a href="foo/bar">1</a><a href="foo/bar">2</a>') == ''
    assert strip_html('<a href="foo/bar">1</a><a href="foo/bar">2</a>', keep_tag_content=True) == '12'
    assert strip_html('<a href="foo/bar">1<span>2</span>3</a><a href="foo/bar">4</a>') == '<span>2</span>'

# Generated at 2022-06-21 21:15:55.627901
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1  # test 1
    assert roman_decode('II') == 2  # test 2
    assert roman_decode('IIII') == 4  # test 3
    assert roman_decode('V') == 5  # test 4
    assert roman_decode('VIIII') == 9  # test 5
    assert roman_decode('X') == 10  # test 6
    assert roman_decode('XII') == 12  # test 7
    assert roman_decode('XVIIII') == 19  # test 8
    assert roman_decode('XX') == 20  # test 9
    assert roman_decode('XXXII') == 32  # test 10
    assert roman_decode('XL') == 40  # test 11
    assert roman_dec

# Generated at 2022-06-21 21:15:58.961681
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert len(shuffle('hello world')) == len('hello world')



# Generated at 2022-06-21 21:16:01.469260
# Unit test for function decompress
def test_decompress():
    # This test is needed because the decompress function uses the class variable _valid_compressed_string_cache
    # and this variable needs a reset to not be influenced by other tests.
    # It is unclear if this is a bug or by design.
    __StringCompressor._valid_compressed_string_cache.clear()
    assert __StringCompressor.decompress("smile") == 'smile'



# Generated at 2022-06-21 21:16:03.106913
# Unit test for function roman_decode
def test_roman_decode():
    roman_decode('xxx')
    assert roman_decode('xxx') == 30


# Generated at 2022-06-21 21:16:14.679363
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_test', True, '_') == 'ThisIsASnakeTest'
    assert snake_case_to_camel('this_is_a_snake_test', False, '_') == 'thisIsASnakeTest'
    assert snake_case_to_camel('this_is_a_snake_test', False, '-') == 'this-is-a-snake-test'
    assert snake_case_to_camel('this_is_a_snake_test', False, '@') == 'this@is@a@snake@test'
    assert snake_case_to_camel('this_is_a_snake_test', True, '-') == 'This-is-a-snake-test'



# Generated at 2022-06-21 21:16:19.003281
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<html><head><title>test</title></head><body>test</body></html>') == 'testtest'



# Generated at 2022-06-21 21:16:30.596539
# Unit test for function prettify

# Generated at 2022-06-21 21:16:43.181524
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('you&me').format() == 'you & me'
    assert __StringFormatter('you&&me').format() == 'you & me'
    assert __StringFormatter('you   &&   me').format() == 'you & me'
    assert __StringFormatter('You&ME').format() == 'You & ME'
    assert __StringFormatter('You&&ME').format() == 'You & ME'
    assert __StringFormatter(' You & ME').format() == 'You & ME'
    assert __StringFormatter('You & ME ').format() == 'You & ME'
    assert __StringFormatter('You&ME ').format() == 'You & ME'
    assert __StringFormatter(' You && ME ').format() == 'You & ME'
    assert __StringFormatter('http://test.com').format