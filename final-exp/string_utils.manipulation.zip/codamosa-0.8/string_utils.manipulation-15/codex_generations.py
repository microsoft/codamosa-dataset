

# Generated at 2022-06-12 07:12:25.875619
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:12:33.837549
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' tris').format() == 'Tris'
    assert __StringFormatter('fornelli').format() == 'Fornelli'
    assert __StringFormatter('izzo').format() == 'Izzo'
    assert __StringFormatter('izzo tris').format() == 'Izzo Tris'
    assert __StringFormatter('izzo Tris').format() == 'Izzo Tris'
    assert __StringFormatter('Izzo Tris').format() == 'Izzo Tris'
    assert __StringFormatter('Izzo tris').format() == 'Izzo Tris'
    assert __StringFormatter('izzo Tris').format() == 'Izzo Tris'
    assert __StringFormatter('4 ball').format() == '4 ball'

# Generated at 2022-06-12 07:12:36.949607
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('TEST') == 'test'
    assert camel_case_to_snake('test') == 'test'
    assert camel_case_to_snake('testTest') == 'test_test'
    assert camel_case_to_snake('TESTTEST') == 'testtest'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:12:45.570519
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print('_____TESTING METHOD___StringFormatter.format')
    
    assert __StringFormatter('    aa bb cc dd    ').format() == 'Aa bb cc dd'
    assert __StringFormatter('aa bb CC DD EE').format() == 'Aa bb CC DD EE'
    assert __StringFormatter('aa bb CC DD EE ff GG HH ii jj kk LL MM nn oo PP qq rr SS tt uu vv WW xx yy  ZZ').format() == 'Aa bb CC DD EE ff GG HH ii jj kk LL MM nn oo PP qq rr SS tt uu vv WW xx yy ZZ'

# Generated at 2022-06-12 07:12:48.655181
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    return camel_case_to_snake('ThisIsACamelStringTest') #returns 'this_is_a_camel_case_string_test'
#test_camel_case_to_snake()


# Generated at 2022-06-12 07:12:57.079963
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    '''
    test___StringFormatter_format unit test
    '''
    # initialize some test strings
    s1 = ''' 
        john & john    ltd.       - 
        (  
        U.K
        )
        '''
    s2 = 'john & john    ltd.       -  (   U.K )'

    # create an instance of __StringFormatter
    t = __StringFormatter(s2)

    # test the format method
    assert 'John & John Ltd. - UK' == t.format()



# Generated at 2022-06-12 07:13:07.964842
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   this   is a test   ').format() == 'This is a test'
    assert __StringFormatter('   this is  a test   ').format() == 'This is a test'
    assert __StringFormatter('   this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a  test   ').format() == 'This is a test'
    assert __StringFormatter('this   is a test  ').format() == 'This is a test'
    assert __StringFormatter('this   is   a test   ').format() == 'This is a test'
    assert __StringFormatter('   this   is  a  test  ').format() == 'This is a test'

# Generated at 2022-06-12 07:13:20.206764
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('HelloWorld') == 'hello_world')
    assert(camel_case_to_snake('helloWorld') == 'hello_world')
    assert(camel_case_to_snake('HelloWorld', separator='-') == 'hello-world')
    assert(camel_case_to_snake('ThisIsACamelStringTest', separator='_') == 'this_is_a_camel_string_test')
    assert(camel_case_to_snake('1ThisIsACamelStringTest', separator='_') == '1_this_is_a_camel_string_test')
    assert(camel_case_to_snake('ThisIsAnAccronymString', separator='_') == 'this_is_an_accronym_string')

# Generated at 2022-06-12 07:13:30.969406
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .test import assert_equal

    sf = __StringFormatter('  A test string.  ')
    assert_equal(sf.format(), 'A test string')

    sf = __StringFormatter('  This is a test  string  ')
    assert_equal(sf.format(), 'This is a test string')

    sf = __StringFormatter('  A test string, with duplicated  string  ')
    assert_equal(sf.format(), 'A test string, with duplicated string')

    sf = __StringFormatter('  The test string. With duplicated.  string  ')
    assert_equal(sf.format(), 'The test string. With duplicated. string')

    sf = __StringFormatter('  A test string, with duplicated.  string  ')

# Generated at 2022-06-12 07:13:41.941367
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # null string
    assert __StringFormatter('').format() is None

    # null input
    try:
        __StringFormatter(None).format()
    except InvalidInputError as e:
        assert e.input is None

    # integers input
    try:
        __StringFormatter(123).format()
    except InvalidInputError as e:
        assert e.input == 123

    # floats input
    try:
        __StringFormatter(123.5).format()
    except InvalidInputError as e:
        assert e.input == 123.5

    # list input
    try:
        __StringFormatter(['a', 'b', 'c']).format()
    except InvalidInputError as e:
        assert e.input == ['a', 'b', 'c']

    # tuple input

# Generated at 2022-06-12 07:13:53.821790
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('foo bar').format() == 'Foo bar'


# PUBLIC API



# Generated at 2022-06-12 07:14:01.134782
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello   world!  ').format() == 'Hello world!'
    assert __StringFormatter('Hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello-world!').format() == 'Hello-world!'
    assert __StringFormatter('hello world?url world!').format() == 'Hello world?url world!'
    assert __StringFormatter('hello world!url world!').format() == 'Hello world!url world!'
    assert __StringFormatter('hello world!url-world!').format() == 'Hello world!url-world!'
    assert __StringFormatter('Hello world!url world!').format() == 'Hello world!url world!'
    assert __StringFormatter('Hello world!url-world!').format

# Generated at 2022-06-12 07:14:13.481631
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .assertions import assert_that
    f = __StringFormatter("Mr  Foo Bar")
    assert_that(f.format()).is_equal_to("Mr Foo Bar")
    f = __StringFormatter("Mr. Foo Bar")
    assert_that(f.format()).is_equal_to("Mr. Foo Bar")
    f = __StringFormatter("mr.  Foo Bar")
    assert_that(f.format()).is_equal_to("Mr. Foo Bar")
    f = __StringFormatter("mr. Foo Bar: foo bar")
    assert_that(f.format()).is_equal_to("Mr. Foo Bar: foo bar")
    f = __StringFormatter("mr  Foo  Bar.")
    assert_that(f.format()).is_equal_to("Mr Foo Bar.")

# Generated at 2022-06-12 07:14:18.155930
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # arrange
    input_ = 'hello world !'
    expectedOutput = 'Hello world!'

    # act
    formatter = __StringFormatter(input_)
    output = formatter.format()

    # assert
    assert output == expectedOutput, 'Expected {}, got {}'.format(expectedOutput, output)
test___StringFormatter_format()


# PUBLIC API



# Generated at 2022-06-12 07:14:25.830841
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hey, ...').format() == 'Hey,...'
    assert __StringFormatter('hey,   ...').format() == 'Hey,...'
    assert __StringFormatter(' hey,.  ...').format() == 'Hey,...'
    assert __StringFormatter('  hey,....  ').format() == 'Hey,...'
    assert __StringFormatter('hey,  a  b  ...').format() == 'Hey, a b...'
    assert __StringFormatter('hey, a  b  c').format() == 'Hey, a b c'
    assert __StringFormatter('  hey, a  b  c').format() == 'Hey, a b c'
    assert __StringFormatter('hey   , a  b  c').format() == 'Hey, a b c'

# Generated at 2022-06-12 07:14:34.150303
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('    lorem    ipsum   ').format() == 'Lorem Ipsum'
    assert __StringFormatter('    lorem    ipsum   DOLOR!').format() == 'Lorem Ipsum Dolor!'
    assert __StringFormatter('    Lorem    ipsum   DOLOR!').format() == 'Lorem Ipsum Dolor!'
    assert __StringFormatter('    LOrem    ipsum   DOLOR!').format() == 'LOrem Ipsum Dolor!'
    assert __StringFormatter('    Lorem    ipsum   DOLOR!   ').format() == 'Lorem Ipsum Dolor!'
    assert __StringFormatter('    Lorem    ipsum   DOLOR!   ').format() == 'Lorem Ipsum Dolor!'

# Generated at 2022-06-12 07:14:45.262922
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # note: this is an integration test, it will check the correctness of the whole class and not
    # each private method

    # returns false if actual == expected is not true otherwise it returns true
    def assert__StringFormatter(actual, expected):
        return actual == expected

    assert assert__StringFormatter(
        __StringFormatter('  This  is  a  string that needs to be prettified..  ').format(),
        'This is a string that needs to be prettified.'
    )
    assert assert__StringFormatter(
        __StringFormatter('I like pizza pie').format(),
        'I like pizza pie'
    )

# Generated at 2022-06-12 07:14:56.643277
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # See "tests/functional/prettify.py" for a list of all the tests

    assert __StringFormatter('').format() == ''

    assert __StringFormatter('  Hello, World!  ').format() == 'Hello, world!'
    assert __StringFormatter('  Hello world!.  ').format() == 'Hello world!'
    assert __StringFormatter('  Hello world?  ').format() == 'Hello world?'
    assert __StringFormatter('  Hello, world.  ').format() == 'Hello, world.'
    assert __StringFormatter('  Hello, world?  ').format() == 'Hello, world?'
    assert __StringFormatter('  Hello, world!  ').format() == 'Hello, world!'
    assert __StringFormatter('  Hello, world!  ').format() == 'Hello, world!'

# Generated at 2022-06-12 07:15:09.264496
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('this is the first test')
    assert s.format() == 'This is the first test'

    s = __StringFormatter('test1 test2; test3, test4 test5')
    assert s.format() == 'Test1 test2; test3, test4 test5'

    s = __StringFormatter('this is a test with a URL: https://github.com/fabrizio2210/PyStUtils')
    assert s.format() == 'This is a test with a URL: https://github.com/fabrizio2210/PyStUtils'

    s = __StringFormatter('this is a test with a EMAIL: fabrizio2210@gmail.com')
    assert s.format() == 'This is a test with a EMAIL: fabrizio2210@gmail.com'

# Generated at 2022-06-12 07:15:18.408852
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:29.741003
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Input string
    test_string = "   Hello   my   dear friend,   what about you?   "

    sf = __StringFormatter(test_string)
    output = sf.format()
    print(output)


# Generated at 2022-06-12 07:15:34.558130
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_b_c') == 'ABC'
    assert snake_case_to_camel('a_b_c', False) == 'aBC'
    assert snake_case_to_camel('a_b_c', True, '-') == 'ABC'
    assert snake_case_to_camel('a_b_c', False, '-') == 'aBC'



# Generated at 2022-06-12 07:15:39.062639
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
line 1
line 2
line 3'''

    output_string = '''
line 1
line 2
line 3'''

    assert strip_margin(input_string) == output_string



# Generated at 2022-06-12 07:15:46.929289
# Unit test for function asciify
def test_asciify():
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')
    assert(asciify('èéùúòóäåëýñ') == 'eeuuooaaeyn')
    assert(asciify('èéùú') == 'eeuu')
    assert(asciify('èéùúòóäåëýñ') == 'eeuuooaaeyn')
    assert(asciify('èéùú') == 'eeuu')

# Generated at 2022-06-12 07:15:56.534773
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(22) == 'XXII'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(2222) == 'MMCCXXII'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('V') == 5
   

# Generated at 2022-06-12 07:16:04.710704
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-case-string-test'



# Generated at 2022-06-12 07:16:15.998849
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('2') is None
    assert roman_encode('0') is None
    assert roman_encode('4000') is None
    assert roman_encode(-1) is None
    assert roman_encode(2) is not None
    # ----------
    assert roman_encode(1) == 'I'
    assert roman_encode('5') == 'V'
    assert roman_encode(10) == 'X'
    assert roman_encode(18) == 'XVIII'
    assert roman_encode(50) == 'L'
    assert roman_encode(100) == 'C'
    assert roman_encode(500) == 'D'
    assert roman_encode(1000) == 'M'
    assert roman_en

# Generated at 2022-06-12 07:16:21.887236
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest', '_') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-12 07:16:26.948972
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-12 07:16:33.667346
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert compressed is 'eJyLUKgz9DAIQ_8vaZbBGoZs0s0uEwDCxV08yIWAOS0fB_FzTjCyMFQXrFt_rBUQQ'



# Generated at 2022-06-12 07:16:39.304891
# Unit test for function roman_encode
def test_roman_encode():
    if roman_encode(37) != 'XXXVIII' and roman_encode('2020') != 'MMXX':
        print("Roman encode does not pass testing")
    else:
        print("Roman encode pass testing")



# Generated at 2022-06-12 07:16:49.309429
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    # "decompressed" will be a string with 169 chars, 1 less than "original" (the space at the end is stripped out)
    decompressed = decompress(compressed)

    assert_equals("original and decompressed should match", original, decompressed)



# Generated at 2022-06-12 07:16:50.873866
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.__init__ is None


# Generated at 2022-06-12 07:17:01.008581
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_case') == 'SnakeCase'
    assert snake_case_to_camel('snake_case', upper_case_first=False) == 'snakeCase'
    assert snake_case_to_camel('snake_case', upper_case_first=False, separator='-') == 'snakeCase'
    assert snake_case_to_camel('snake-case') == 'SnakeCase'
    assert snake_case_to_camel('SnakeCase') == 'SnakeCase'
    assert snake_case_to_camel('snakeCase') == 'SnakeCase'
    assert snake_case_to_camel('hello_there') == 'HelloThere'

# Generated at 2022-06-12 07:17:08.616202
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
	assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
	assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
	assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
	assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:17:12.005094
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-12 07:17:15.002282
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    assert is_string(compressed) is True
    assert compressed != original

    # restore original string
    restored = __StringCompressor.decompress(compressed)

    assert restored == original



# Generated at 2022-06-12 07:17:21.012807
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    print('original')
    print(original)
    compressed = compress(original)
    print('compressed')
    print(compressed)
    decompressed = decompress(compressed)
    print('decompressed')
    print(decompressed)
    assert original == decompressed



# Generated at 2022-06-12 07:17:28.192252
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.en

# Generated at 2022-06-12 07:17:32.932106
# Unit test for function shuffle
def test_shuffle():
    test_strings = [
        ('', ''),
        ('hey', 'hey'),
        (' hey', ' hey'),
        ('hey ', 'hey '),
        (' hey ', ' hey '),
        ('3.4', '3.4'),
        ('3//4', '3//4'),
        ('34', '34'),
        ('hey there', 'theey rh'),
        ('heythere', 'yerehhet'),
        ('HERE', 'EREH'),
        ('HEre', 'ErEH'),
        ('HEERE', 'EErHE'),
    ]

    for input_value, expected_output in test_strings:
        output = shuffle(input_value)

        if output == expected_output:
            print('"{}" -> "{}" [OK]'.format(input_value, output))

# Generated at 2022-06-12 07:17:47.464173
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert not booleanize('False')
    assert booleanize('yes')
    assert not booleanize('no')
    assert booleanize('1')
    assert not booleanize('0')


# TODO: move this into a dedicated module and make it as external as possible (use module import or config)


# Generated at 2022-06-12 07:17:53.449606
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Èé,úùòó!   ') == 'ee-uuoo'



# Generated at 2022-06-12 07:18:06.183241
# Unit test for function prettify
def test_prettify():
    # Tests related to START/END
    assert prettify(' ') == ''
    assert prettify('a') == 'a'
    assert prettify(' a') == 'a'
    assert prettify('a ') == 'a'
    assert prettify('          ') == ''
    assert prettify('          a') == 'a'
    assert prettify('a          ') == 'a'
    assert prettify('          a          ') == 'a'

    # Tests related to FIRST LETTER
    assert prettify('foo') == 'Foo'
    assert prettify(' foo') == 'Foo'
    assert prettify('a foo') == 'A foo'
    assert prettify('a foo b') == 'A foo b'
    assert prettify('a foo b.') == 'A foo b.'

# Generated at 2022-06-12 07:18:08.444986
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
test_roman_decode()
test_roman_decode



# Generated at 2022-06-12 07:18:15.671929
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('True') == True
    assert booleanize('TRUE') == True
    assert booleanize('t') == False
    assert booleanize('1') == True
    assert booleanize('2') == False
    assert booleanize('yes') == True
    assert booleanize('No') == False
    assert booleanize('Y') == True
    assert booleanize('N') == False
    assert booleanize('foobar') == False



# Generated at 2022-06-12 07:18:19.113951
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse('a') == 'a'



# Generated at 2022-06-12 07:18:22.261648
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('-=hello world=-') == '=-dlrow olleh=-'



# Generated at 2022-06-12 07:18:24.496214
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    out = __StringFormatter("hello world").format()
    assert (out == "Hello world")


# Generated at 2022-06-12 07:18:29.993692
# Unit test for function asciify
def test_asciify():
   assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË")=="eeuuooaaeynAAACIINOE"


# Generated at 2022-06-12 07:18:34.110236
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello World, how   are you ?').input_string == 'hello World, how   are you ?'
    try:
        __StringFormatter(None)
        raise ValueError()
    except InvalidInputError:
        pass


# Generated at 2022-06-12 07:18:51.719013
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(80) == 'LXXX'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __Roman

# Generated at 2022-06-12 07:18:55.720489
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-12 07:19:03.400755
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='-') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:19:13.063585
# Unit test for function compress

# Generated at 2022-06-12 07:19:18.018601
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter
    assert __StringFormatter.__init__
    sf = __StringFormatter('Hello World')
    assert sf
    assert sf.input_string == 'Hello World'
    

# Generated at 2022-06-12 07:19:25.916304
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('  ') == '  '
    
    assert snake_case_to_camel('this_is_a_string') == 'ThisIsAString'
    assert snake_case_to_camel('ThisIsAString', upper_case_first=False) == 'thisIsAString'
    assert snake_case_to_camel('this_is_a_string', upper_case_first=False) == 'thisIsAString'
    assert snake_case_to_camel('this_is_a_string', separator='-') == 'ThisIsAString'
    assert snake_case_to_camel('this-is-a-string', separator='-') == 'ThisIsAString'
    assert snake_

# Generated at 2022-06-12 07:19:31.563403
# Unit test for function shuffle
def test_shuffle():
    failures = 0
    failures += run_test(shuffle(None), expected=None, test_name='shuffle(None)')
    failures += run_test(shuffle('abc'), expected=None, test_name='shuffle(abc)')
    return failures


# Generated at 2022-06-12 07:19:38.761138
# Unit test for function asciify
def test_asciify():
    test_value = "abcdefghilmnopqrstuvzABCDEFGHILMNOPQRSTUVZ0123456789!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ' "

# Generated at 2022-06-12 07:19:40.640474
# Unit test for function prettify

# Generated at 2022-06-12 07:19:43.366854
# Unit test for function compress
def test_compress():
    assert compress('this is a test') == compress('this is a test')
    assert compress('this is a test') != compress('this is another test')



# Generated at 2022-06-12 07:20:05.937072
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', upper_case_first=False) == 'helloWorld'
    assert snake_case_to_camel('hello_world', separator='-') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', upper_case_first=False, separator='-') == 'helloWorld'



# Generated at 2022-06-12 07:20:12.016032
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test <a href="foo/bar">click<strong> here</strong></a>', keep_tag_content=True) == 'test click here'



# Generated at 2022-06-12 07:20:15.581769
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_string') == 'ThisIsAString'
    assert snake_case_to_camel('this_is_a_string', upper_case_first=False) == 'thisIsAString'
    assert snake_case_to_camel('this__is_a_string_') == 'ThisIsAString'
    assert snake_case_to_camel('this-is-a-string', separator='-') == 'ThisIsAString'



# Generated at 2022-06-12 07:20:17.342299
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:20:20.111008
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-12 07:20:22.497736
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:20:25.414392
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    from .test_functions import test_invalid_input
    test_invalid_input(__RomanNumbers.encode)
    test_invalid_input(__RomanNumbers.decode)


# PUBLIC API



# Generated at 2022-06-12 07:20:37.320061
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    from .validation import is_string
    from .errors import InvalidInputError


# Generated at 2022-06-12 07:20:46.794447
# Unit test for function prettify

# Generated at 2022-06-12 07:20:51.026952
# Unit test for function compress
def test_compress():
    assert compress('1') == 'eNrzAAAAMAAJ'
    assert compress('') == ''



# Generated at 2022-06-12 07:21:22.000570
# Unit test for function asciify

# Generated at 2022-06-12 07:21:29.970928
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('hello') == 'olleh'
    assert reverse('012345') == '543210'
    assert reverse('~`!@#$%^&*()') == ')(*&^%$#@!`~'
    assert reverse('abcdeabcdeabcdeabcdeabcdeabcde') == \
           'edcbeadcbeadcbeadcbeadcbeadcbeadcba'
    assert reverse('ABCDEABCDEABCDEABCDEABCDEABCDE') == \
           'EDCBEADCBEADCBEADCBEADCBEADCBEADCBA'
    assert reverse('!@#$%^&*()_+-=[]{}\\|/?.,<>') == '>,.</?|\\}{]=-+_)(*&^%$#@!'


# Generated at 2022-06-12 07:21:40.286680
# Unit test for function booleanize
def test_booleanize():
    if not (booleanize('true')):
        raise AssertionError
    if not booleanize('True'):
        raise AssertionError
    if booleanize('false'):
        raise AssertionError
    if booleanize('anything else'):
        raise AssertionError
    if not (booleanize('YES')):
        raise AssertionError
    if not (booleanize('1')):
        raise AssertionError
    if booleanize('0'):
        raise AssertionError
    if not (booleanize('Y')):
        raise AssertionError
    if booleanize('N'):
        raise AssertionError
    if not (booleanize('yes')):
        raise AssertionError
    if not (booleanize('no')):
        raise AssertionError

test_

# Generated at 2022-06-12 07:21:42.269278
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-12 07:21:43.938152
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('II') == 2
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5

# Generated at 2022-06-12 07:21:50.557936
# Unit test for function compress
def test_compress():
    string_to_compress = "Is compressed by returning a shorter one that can be safely used in any context (like URL)."
    expected_compressed_string = 'x\x9c+\x0b\xc9K\xa4\x04\x00\x10R\x94h\x19\r\x0c\xc2\xb11\x82\xe8il\x0be\x12\x98H\x0eK\x84'
    compression_level = 5
    compression_encoding = 'utf-8'
    actual_compressed_string = compress(string_to_compress, compression_encoding, compression_level)
    if (actual_compressed_string != expected_compressed_string):
        raise Exception("Failed compress string test")



# Generated at 2022-06-12 07:22:00.537591
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("M") == 1000
    assert roman_decode('MDCLXVI') == 1666
    assert roman_decode('CXIX') == 119
    assert roman_decode('IX') == 9
    assert roman_decode('II') == 2
    assert roman_decode('IV') == 4
    assert roman_decode('VI') == 6
    assert roman_decode('MCMXCVIII') == 1998
    assert roman_decode('MM') == 2000
    assert roman_decode('DCCC') == 500
    assert roman_decode('CCCLXXXVIII') == 388
    assert roman_decode('CCCXC') == 390
    assert roman_decode('CCCC') == 400
    assert roman_decode('CXXX') == 130

# Generated at 2022-06-12 07:22:05.305155
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'this is a test'
    expected = 'dGhpcwBpcyBhIHRlc3Q='
    actual = __StringCompressor.compress(input_string)
    assert actual == expected, 'Compression failed'


# PUBLIC API



# Generated at 2022-06-12 07:22:12.752166
# Unit test for function compress
def test_compress():
    assert compress('ciao') == 'eNpLSUosTUhNyMnISUpXFVDNTZRUClRMTDY1jk0rvNIAAeaN1q'
    assert compress('ciao', compression_level=0) == 'eNpLSUosTUhNyMnISUpXFVDNTZRUClRMTDY1jk0rvNIAAeaN1q'
    assert compress('ciao', compression_level=1) == 'eNpLSUosTUhNyMnISUpXFVDNTZRUClRMTDY1jk0rvNIAAeaN1q'