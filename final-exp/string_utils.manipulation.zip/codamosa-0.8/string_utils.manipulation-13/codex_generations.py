

# Generated at 2022-06-12 07:12:32.529856
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:12:39.610289
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('CamelStringTest') == 'camel_string_test'
    assert camel_case_to_snake('Camel') == 'camel'
    assert camel_case_to_snake('camelStringTest') == 'camelstringtest'
    assert camel_case_to_snake('camelString123Test') == 'camel_string123_test'
    assert camel_case_to_snake('camelString123test') == 'camel_string123test'
    assert camel_case_to_snake('camelStringTest123') == 'camel_string_test123'

# Generated at 2022-06-12 07:12:47.510162
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello     world   :)').format() == 'Hello world :)'
    assert __StringFormatter('hello world...**').format() == 'Hello world...'
    assert __StringFormatter('https://hello world.com._.').format() == 'https://hello world.com'
    assert __StringFormatter('hello world@gmail.it').format() == 'hello world@gmail.it'
    assert __StringFormatter('http://hello world.com/my/path?foo=bar').format() == 'http://hello world.com/my/path?foo=bar'
    assert __StringFormatter('http://hello world.com/my/path////').format() == 'http://hello world.com/my/path'

# Generated at 2022-06-12 07:12:58.415588
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    #tests to check if the function is working properly
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake(1) == 1
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('123') == '123'
    assert camel_case_to_snake('ThisIsNotACamelStringTest') == 'this_is_not_a_camel_string_test'


# Generated at 2022-06-12 07:13:08.642928
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:20.369682
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    print("Testing camel_case_to_snake(input_string: str)...", end="")
    assert (camel_case_to_snake("", '_') == "")
    assert (camel_case_to_snake("a", '_') == "a")
    assert (camel_case_to_snake("a b", '_') == "a b")
    assert (camel_case_to_snake("xe2x80xa2") == "xe2x80xa2")
    assert (camel_case_to_snake("hello") == "hello")
    assert (camel_case_to_snake("hello world") == "hello world")
    assert (camel_case_to_snake("HELLO") == "HELLO")

# Generated at 2022-06-12 07:13:31.097807
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('')
    assert formatter.format() == ''
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b   c d').format() == 'A b c d'
    assert __StringFormatter('a b c d ').format() == 'A b c d'
    assert __StringFormatter(' a b c d').format() == 'A b c d'
    assert __StringFormatter('  a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d  ').format() == 'A b c d'
    assert __StringFormatter(' a b c d ').format() == 'A b c d'
   

# Generated at 2022-06-12 07:13:42.033997
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # test for empty string shall return an empty string
    assert __StringFormatter('').format() == ''

    # test for blank string shall return a blank string
    assert __StringFormatter(' ').format() == ' '

    # test for first letter upper-cased
    assert __StringFormatter('hello').format() == 'Hello'

    # test for duplicates removed
    assert __StringFormatter('hello hhh').format() == 'Hello h'
    assert __StringFormatter('hello heee').format() == 'Hello he'
    assert __StringFormatter('hello world').format() == 'Hello world'

    # test for left spaces cleaned
    assert __StringFormatter(' hello').format() == 'Hello'
    assert __StringFormatter('  hello').format() == 'Hello'

# Generated at 2022-06-12 07:13:44.601261
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('MyStringToTest') == 'my_string_to_test'



# Generated at 2022-06-12 07:13:46.856590
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('CamelCase') == 'camel_case'
test_camel_case_to_snake()


# Generated at 2022-06-12 07:14:01.908105
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import unittest

    class __Test(unittest.TestCase):
        def test_empty_input(self):
            fmt = __StringFormatter('')
            self.assertEqual(fmt.format(), '')

        def test_with_space_only(self):
            fmt = __StringFormatter('   ')
            self.assertEqual(fmt.format(), '')

        def test_with_non_ascii_characters(self):
            fmt = __StringFormatter('ùùù ààà ççç ééé èèè ëëë îîî ïïï ôôô üüü ÿÿÿ')

# Generated at 2022-06-12 07:14:13.980814
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("BASILIO") == "BASILIO"
    assert snake_case_to_camel("BASILIO-TEST") == "BASILIO-TEST"
    assert snake_case_to_camel("BASILIO_TEST") == "BasilioTest"
    assert snake_case_to_camel("_BASILIO_TEST") == "BasilioTest"
    assert snake_case_to_camel("BASILIO__TEST") == "BasilioTest"
    assert snake_case_to_camel("BASILIO_TEST_") == "BasilioTest"
    assert snake_case_to_camel("A_BASILIO_TEST") == "ABasilioTest"
    assert snake_case

# Generated at 2022-06-12 07:14:19.913092
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    assert(snake_case_to_camel("the_snake_is_green") == 'TheSnakeIsGreen')
    assert(snake_case_to_camel("the_snake_is_green", False) == 'theSnakeIsGreen')
    assert(snake_case_to_camel("the_snake_is_green", separator='-') == 'theSnakeIsGreen')
    try:
        snake_case_to_camel()
    except InvalidInputError:
        assert True
    except:
        assert False
    assert False
test_snake_case_to_camel()


# Generated at 2022-06-12 07:14:31.590742
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('boo', True) == 'Boo'
    assert snake_case_to_camel('boo', False) == 'boo'
    assert snake_case_to_camel('boo', True, '-') == 'Boo'
    assert snake_case_to_camel('-boo', False, '-') == '-boo'

# Generated at 2022-06-12 07:14:40.487839
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert_method_output(strings.snake_case_to_camel, 'this_is_a_snake_string', 'ThisIsASnakeString')
    assert_method_output(strings.snake_case_to_camel, 'this_is_a_snake_string', 'thisIsASnakeString', False)
    assert_method_output(strings.snake_case_to_camel, 'this-is-a-snake-string', 'ThisIsASnakeString', True, '-')
    assert_method_output(strings.snake_case_to_camel, 'this-is-a-snake-string', 'thisIsASnakeString', False, '-')



# Generated at 2022-06-12 07:14:43.400380
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    out = snake_case_to_camel('the_snake_is_green')
    assert out == 'TheSnakeIsGreen', 'The snake is green'



# Generated at 2022-06-12 07:14:54.621985
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello   world').format() == 'Hello world'
    assert __StringFormatter('hello,world').format() == 'Hello, world'
    assert __StringFormatter('hello , world').format() == 'Hello, world'
    assert __StringFormatter('hello ,  world').format() == 'Hello, world'
    assert __StringFormatter('hello!world').format() == 'Hello! World'
    assert __StringFormatter('hello!  world').format() == 'Hello! World'
    assert __StringFormatter('hello!!!world').format() == 'Hello! World'
    assert __StringFormatter('hello.world').format() == 'Hello. World'
    assert __StringFormatter('hello.  world').format() == 'Hello. World'

# Generated at 2022-06-12 07:15:07.215971
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'

# Generated at 2022-06-12 07:15:12.875527
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_string') == 'ThisIsASnakeString'
    assert snake_case_to_camel('this_is_a_snake_string', upper_case_first=False) == 'thisIsASnakeString'
    assert snake_case_to_camel('this_is_a_snake_string', upper_case_first=False, separator='-') == 'thisIsASnakeString'



# Generated at 2022-06-12 07:15:24.137557
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:36.417441
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Hello, world!').format() == 'Hello, world!'
    assert __StringFormatter('hello, world!').format() == 'Hello, world!'
    assert __StringFormatter('  Hello,      world! ').format() == 'Hello, world!'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello    world').format() == 'Hello world'
    assert __StringFormatter('hello  . . . . . . .  world').format() == 'Hello... world'
    assert __StringFormatter("hello,  it's... me!").format() == "Hello, it's... me!"
    assert __StringFormatter("hello,  it's... me!").format() == "Hello, it's... me!"

# Generated at 2022-06-12 07:15:46.609553
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo bar  ').format() == 'Foo bar'
    assert __StringFormatter('').format() == ''
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo  bar').format() == 'Foo bar'
    assert __StringFormatter('foo & bar').format() == 'Foo & bar'
    assert __StringFormatter('foo | bar').format() == 'Foo | bar'
    assert __StringFormatter('foo,  bar').format() == 'Foo, bar'
    assert __StringFormatter('foo!  bar').format() == 'Foo! bar'
    assert __StringFormatter('foo?  bar').format() == 'Foo? bar'

# Generated at 2022-06-12 07:15:56.464771
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('   this  is an EXAMPLE')
    assert sf.format() == 'This is an Example'

    sf = __StringFormatter(' this  is an EXAMPLE that I\'m using to test the functiON')
    assert sf.format() == 'This is an Example That I\'m Using to Test the Function'

    sf = __StringFormatter('after several calls, I do a check')
    assert sf.format() == 'After Several Calls, I Do a Check'

    sf = __StringFormatter('this is a url http://www.example.com and an email address to@example.com')
    assert sf.format() == 'This is a URL http://www.example.com and an Email Address to@example.com'


# Generated at 2022-06-12 07:16:08.275142
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' hello world! ').format() == "Hello world!"
    assert __StringFormatter(' hello world! ').format() == 'Hello world!'
    assert __StringFormatter(' hello! world! ').format() == 'Hello! World!'
    assert __StringFormatter('Hello world!').format() == 'Hello world!'
    assert __StringFormatter('  hello world! ').format() == "Hello world!"
    assert __StringFormatter(' hello  world! ').format() == "Hello world!"
    assert __StringFormatter(' hello, world! ').format() == "Hello, world!"
    assert __StringFormatter(' hello,  world! ').format() == "Hello, world!"
    assert __StringFormatter(" hello,  world! ").format() == "Hello, world!"

# Generated at 2022-06-12 07:16:18.116535
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c d 1 2 3').format() == 'A B C D 1 2 3'
    assert __StringFormatter('a b c d 1 2 3 ').format() == 'A B C D 1 2 3'
    assert __StringFormatter('    a b c d 1 2 3').format() == 'A B C D 1 2 3'
    assert __StringFormatter(' this is a long  string,     with a lot of    spaces ').format() == 'This is a long string, with a lot of spaces'
    assert __StringFormatter('this is a long  string,     with a lot of    spaces').format() == 'This is a long string, with a lot of spaces'

# Generated at 2022-06-12 07:16:19.585422
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' a  b ').format() == 'A b'



# Generated at 2022-06-12 07:16:29.259310
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Lorem ipsum DOLOR sit amet').format() == 'Lorem ipsum dolor sit amet'
    assert __StringFormatter(' , . . . . . . . . . . . . Lorem ipsum dolor sit amet, . . . . . . . . . . . . . . . . . . . . . . . . . . . '
							'. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ').format() == 'Lorem ipsum dolor sit amet'

# Generated at 2022-06-12 07:16:38.057350
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  1st test').format() == '1st test'
    assert __StringFormatter('2nd    test').format() == '2nd test'
    assert __StringFormatter('3rd test').format() == '3rd test'
    assert __StringFormatter('4th-test').format() == '4th-test'
    assert __StringFormatter('5th    -   test').format() == '5th - test'
    assert __StringFormatter('6th.test').format() == '6th.test'
    assert __StringFormatter('7th   .   test').format() == '7th.test'
    assert __StringFormatter('8th test').format() == '8th test'
    assert __StringFormatter('9th  test').format() == '9th test'
    assert __String

# Generated at 2022-06-12 07:16:44.268209
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:48.721270
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('  usa  india  russia  u.k.  brazil   germany  australia  ')
    assert formatter.format() == 'Usa India Russia U.K. Brazil Germany Australia'


# Generated at 2022-06-12 07:16:58.997671
# Unit test for function decompress
def test_decompress():
    import string
    import random
    # Generate random word of 4 characters
    random_data = ''.join(random.choice(string.ascii_letters) for x in range(random.randint(0, 100)))
    # Generate compressed version of this string
    compressed_random_data = compress(random_data)
    # Decompress compressed random data
    decompressed_random_data = decompress(compressed_random_data)
    assert (random_data == decompressed_random_data)


# Generated at 2022-06-12 07:17:06.926896
# Unit test for function booleanize
def test_booleanize():
  assert booleanize('yes') == True
  assert booleanize('true') == True
  assert booleanize('1') == True
  assert booleanize('y') == True
  assert booleanize('no') == False
  assert booleanize('false') == False
  assert booleanize('ciao') == False
  assert booleanize('0') == False
  assert booleanize('n') == False
  assert booleanize('ciao') == False
  assert booleanize('') == False


# Generated at 2022-06-12 07:17:11.416419
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False) == 'thisIsATest'



# Generated at 2022-06-12 07:17:20.552473
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('1') == True
    assert booleanize('y') == True

    assert booleanize('0') == False
    assert booleanize('1.1') == False
    assert booleanize('') == False
    assert booleanize('truee') == False
    assert booleanize('yesno') == False
    assert booleanize('other stuff') == False
    assert booleanize('2') == False



# Generated at 2022-06-12 07:17:28.437286
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:17:37.665029
# Unit test for function compress
def test_compress():
    assert compress('This is a test text') == 'eJzTBkEGcEAIA4AEl9oE20='
    assert compress('This is a test text') != 'eJzTBkEGcEAIA4AEl9oE21='
    assert compress('This is a test text') != 'eJzTTkEGcEAIA4AEl9oE20='
    assert compress('This is a test text') != 'eJzTkEGcEAIA4AEl9oE20='
    assert compress('This is a test text') != 'This is a test text'
    
    

# Generated at 2022-06-12 07:17:40.784184
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    try:
        __RomanNumbers()
        assert True
    except:
        assert False



# Generated at 2022-06-12 07:17:45.089343
# Unit test for function compress
def test_compress():

        s_start = ' '.join(['word n{}'.format(n) for n in range(20)])

        compressedData = compress(s_start)

        s_end = decompress(compressedData)

        assert (s_start == s_end)



# Generated at 2022-06-12 07:17:52.905340
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('hello') == 'olleh'
    assert reverse('barry') == 'yrrab'
    assert reverse('foo') == 'oof'
    assert reverse('123456789') == '987654321'
    assert reverse('I wanna be, I wanna be, I wanna be a rock star') == 'rats kcor a eb annaw I ,eb annaw I ,eb annaw I'



# Generated at 2022-06-12 07:17:57.749135
# Unit test for function shuffle
def test_shuffle():
    input_string = 'hello world'
    shuffled_string = shuffle(input_string)

    assert len(input_string) == len(shuffled_string)
    assert input_string != shuffled_string



# Generated at 2022-06-12 07:18:04.457263
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin(
        '''
            line 1
            line 2
            line 3
        ''') == '''
            line 1
            line 2
            line 3
        '''



# Generated at 2022-06-12 07:18:13.915207
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi'
    compressed = __StringCompressor.compress(input)

    assert input != compressed
    assert compressed == 'eNpjYBgxMA7V73JtHNdFVN3XN0B0VQNWhBNHc1MzQbLA5kSVMTKtDP0MtVzMtPDWOUgtFGzEtUTJTNokvMkW1R8nLyczMzEbMS3qMRVHWc_Qz1EuSc_Qz1kvSx5EA'
    assert __StringCompressor.decompress(compressed) == input


# CUSTOM API



# Generated at 2022-06-12 07:18:15.454202
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Generated at 2022-06-12 07:18:25.476092
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings[0][1] == 'I'
    assert __RomanNumbers.__mappings[0][5] == 'V'
    assert __RomanNumbers.__mappings[1][1] == 'X'
    assert __RomanNumbers.__mappings[1][5] == 'L'
    assert __RomanNumbers.__mappings[2][1] == 'C'
    assert __RomanNumbers.__mappings[2][5] == 'D'
    assert __RomanNumbers.__mappings[3][1] == 'M'
    assert __RomanNumbers.__reversed_mappings[0]['I'] == 1
    assert __RomanNumbers.__reversed_mappings[0]['V'] == 5
    assert __RomanNumbers.__reversed_mappings[1]['X'] == 1


# Generated at 2022-06-12 07:18:26.660124
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh', 'Invalid reverse function'
    assert reverse('') == '', 'Invalid reverse function'



# Generated at 2022-06-12 07:18:36.965314
# Unit test for function decompress

# Generated at 2022-06-12 07:18:46.128108
# Unit test for function strip_html
def test_strip_html():
    # remove html
    s = '<a href="foo/bar">click here</a>'
    assert strip_html(s) == ''

    # remove html with tag content
    s = '<div id="foo">bar</div>'
    assert strip_html(s) == ''

    # keep tag content
    s = '<a href="foo/bar">click here</a>'
    assert strip_html(s, keep_tag_content=True) == 'click here'
    s = '<div id="foo">bar</div>'
    assert strip_html(s, keep_tag_content=True) == 'bar'
test_strip_html()



# Generated at 2022-06-12 07:18:57.759255
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    t = __StringFormatter('hello world   , this is a     test, with  some values.   ok?')
    assert t.format() == 'Hello world, this is a test, with some values. Ok?'
    t = __StringFormatter('this is. a test, of: SAXON GENITIVE')
    assert t.format() == 'This is a test, of: Saxon genitive'
    t = __StringFormatter('http://www.google.it/')
    assert t.format() == 'http://www.google.it/'
    t = __StringFormatter('this is a test for @francesco.dalessandro@test.com email')
    assert t.format() == 'This is a test for francesco.dalessandro@test.com email'

# PUBLIC API



# Generated at 2022-06-12 07:19:03.077565
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    #print("original: " + original)
    #print("compressed: " + compressed)
    #print("original: " + original.__len__())
    #print("compressed: " + compressed.__len__())
    assert compressed.__len__() < original.__len__()


# Generated at 2022-06-12 07:19:07.582205
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<p>text</p>') == ''
    assert strip_html('<p>text</p>', keep_tag_content=True) == 'text'
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'



# Generated at 2022-06-12 07:19:22.770403
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(13) == 'XIII'
    assert __RomanNumbers.encode(1776) == 'MDCCLXXVI'
    assert __RomanNumbers.decode('MCMLXXXIX') == 1989
    assert __RomanNumbers.decode('XII') == 12
    assert __RomanNumbers.decode('IV') == 4
    assert __RomanNumbers.decode('XIX') == 19
    assert __RomanNumbers.decode('XXI') == 21
    assert __RomanNumbers.decode('XLIII') == 43
    assert __RomanNumbers.decode('DCCCLVII') == 857


# | >>> PUBLIC API <<< |


# | Regex |



# Generated at 2022-06-12 07:19:34.622916
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:19:38.844595
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True) == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:19:44.292535
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hell') == 'lleh'
    assert reverse('he') == 'eh'
    assert reverse('h') == 'h'
    assert reverse('hello') != 'hello'
    assert reverse('hello') != 'olhle'
    assert reverse('hello') != 'olle'
    assert reverse('hello') != 'helle'
    assert reverse('hello') != 'ol'



# Generated at 2022-06-12 07:19:53.141362
# Unit test for function slugify
def test_slugify():
    # Case 1: Convert a string into a "slug" using provided separator.
    print(slugify('Top 10 Reasons To Love Dogs!!!'))
    # Case 2: Replace any character that is NOT letter or number with spaces.
    print('\n')
    print(slugify('Top.10!Reasons.To.Love?Dogs'))
    # Case 3: Evaluate false cases
    print(slugify('Top 10 Reasons? To Love Dogs!!!'))
    print(slugify('Top & 10 Reasons To Love Dogs!!!'))
    print(slugify('Top !! 10 Reasons? To Love Dogs'))
    # Case 4: Evaluate edge cases
    print(slugify('Top '))
    print('\n')


# Generated at 2022-06-12 07:19:59.093619
# Unit test for function compress
def test_compress():
    # Test data
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    expected_output_string = 'eJyrVjJJU0lOLTIxBgC/IfpYpzE/jB/AHgD9KjI='
    assert(compress(input_string) == expected_output_string)



# Generated at 2022-06-12 07:20:04.810619
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    line 1
    line 2
    ''') == '''
line 1
line 2
'''
    assert strip_margin('''
        |line 1
        |line 2
    '''.strip('\n')) == '''
line 1
line 2
'''



# Generated at 2022-06-12 07:20:07.357455
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'


# Generated at 2022-06-12 07:20:09.979810
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    s = __StringCompressor()
# End of unit test for constructor of class __StringCompressor

# END OF PRIVATE API


# PUBLIC API



# Generated at 2022-06-12 07:20:14.887440
# Unit test for function prettify

# Generated at 2022-06-12 07:20:38.514398
# Unit test for function asciify

# Generated at 2022-06-12 07:20:41.500233
# Unit test for function asciify
def test_asciify():
    test_string = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    correct_ascii_string = 'eeuuooaaeynAAACIINOE'

    test_result = asciify(test_string)

    if test_result != correct_ascii_string:
        print("function asciify test failed: expecting %s, got %s" % (correct_ascii_string, test_result))
        exit()



# Generated at 2022-06-12 07:20:49.255099
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('test') == 'test'
    assert camel_case_to_snake('testString') == 'test_string'
    assert camel_case_to_snake('StringTest') == 'string_test'
    assert camel_case_to_snake('stringTest') == 'string_test'
    assert camel_case_to_snake('StringTestTEST') == 'string_test_test'
    assert camel_case_to_snake('StringTestTEST1213') == 'string_test_test1213'
    assert camel_case_to_snake('Test1213') == 'test1213'
    assert camel_case_to_snake('test1213') == 'test1213'
    assert camel_

# Generated at 2022-06-12 07:20:58.273550
# Unit test for function shuffle
def test_shuffle():
    s = "12345"
    assert(is_string(s) == True)
    assert(len(s) == 5)
    s_len = len(s)
    s_shuffled = shuffle(s)
    assert(is_string(s_shuffled) == True)
    assert(len(s_shuffled) == s_len)
    assert(s != s_shuffled)

    # various string
    s1 = "hello world"
    s2 = "my name is"
    s3 = "welcome to the jungle"
    s4 = "this is a pretty long string used to test a function"
    s5 = "this is a pretty long string used to test a function - part 2"
    s6 = "this is a pretty long string used to test a function - part 3"
    s7

# Generated at 2022-06-12 07:21:09.016471
# Unit test for function decompress
def test_decompress():
    assert decompress('eJybzc3q4z4gVLJLslRLCUvOzUwD1YvyE=', 'utf-8') == 'hello world'

# Generated at 2022-06-12 07:21:10.690839
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    pass


# Generated at 2022-06-12 07:21:13.353718
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
test_slugify()


# Generated at 2022-06-12 07:21:15.019694
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                 line 1
                 line 2
                 line 3''') =='''
line 1
line 2
line 3'''


# Generated at 2022-06-12 07:21:19.153418
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('àâáãäåæçèéêëìíîïðñòóôõöøùúûüýþÿßÀÂÁÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞ') == 'aaaeaaaeeeiiniiooooouuuuyyysAAAEAAAEEEIIIIIDNOOOOOUUUUYTH'

# Generated at 2022-06-12 07:21:20.734667
# Unit test for function booleanize
def test_booleanize():
        #test if the function booleanize work normally
        assert booleanize('true') == True
        assert booleanize('tru') == False

        #test if the function booleanize work normally    
        assert booleanize('YES') == True
        assert booleanize('nope') == False

# Generated at 2022-06-12 07:21:34.770598
# Unit test for function reverse
def test_reverse():
    assert reverse('Hello World') == 'dlroW olleH'
test_reverse()



# Generated at 2022-06-12 07:21:44.095962
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify(None) == ''

    assert slugify('This is a test') == 'this-is-a-test'
    assert slugify('This-is-a-test') == 'this-is-a-test'
    assert slugify('This_is_a_test') == 'this-is-a-test'

    assert slugify('123 This is a test') == '123-this-is-a-test'
    assert slugify('This is a test 123') == 'this-is-a-test-123'
    assert slugify('This is a 123 test') == 'this-is-a-123-test'

    assert slugify('This- is a test') == 'this-is-a-test'

# Generated at 2022-06-12 07:21:44.666540
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'helol'



# Generated at 2022-06-12 07:21:47.858566
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE', "First test failed"
    assert asciify('  ') == ' ', "Second test failed"



# Generated at 2022-06-12 07:21:57.291881
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''\t\t\t\t\t\tThis is a
\t\t\t\t\t\ttest''') == 'This is a\ntest'
    assert strip_margin('''
    \t\t\t\t\t\tThis is a
    \t\t\t\t\t\ttest''') == 'This is a\ntest'
    assert strip_margin('''
\t\t\t\t\t\tThis is a
\t\t\t\t\t\ttest''') == 'This is a\ntest'

# Generated at 2022-06-12 07:22:02.920539
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<html><body>test</body></html>') == ''
    assert strip_html('<html><body>test</body></html>', keep_tag_content=True) == 'test'
    assert strip_html('<div>text to keep <i>italic text</i></div>') == 'text to keep italic text'



# Generated at 2022-06-12 07:22:05.572365
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('YES')
    assert not booleanize('nope')

test_booleanize()



# Generated at 2022-06-12 07:22:12.844944
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'
