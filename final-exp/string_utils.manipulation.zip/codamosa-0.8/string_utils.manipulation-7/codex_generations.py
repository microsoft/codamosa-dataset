

# Generated at 2022-06-12 07:12:31.084251
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world') == 'helloWorld'
    assert snake_case_to_camel('camel_case') == 'camelCase'
    assert snake_case_to_camel('camel_case', True) == 'camelCase'
    assert snake_case_to_camel('camel_case', False) == 'camelcase'
    assert snake_case_to_camel('camel_case', False, '-') == 'camel_case'
    assert snake_case_to_camel('camel_case', False, '--') == 'camel_case'


# Generated at 2022-06-12 07:12:39.333355
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('PascalCaseStringTest') == 'pascal_case_string_test'
    assert camel_case_to_snake('string') == 'string'
    assert camel_case_to_snake('test') == 'test'
    assert camel_case_to_snake('test_test_test') == 'test_test_test'
    assert camel_case_to_snake('test_test') == 'test_test'
    assert camel_case_to_snake('test_test_test_test') == 'test_test_test_test'

# Generated at 2022-06-12 07:12:47.336815
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('abc  DEF').format()   == 'Abc def'
    assert __StringFormatter('abc--DEF').format()  == 'Abc def'
    assert __StringFormatter('abc DEF').format()   == 'Abc def'
    assert __StringFormatter('abc DEF').format()   == 'Abc def'
    assert __StringFormatter('abc,DEF').format()   == 'Abc def'
    assert __StringFormatter('abc,DEF').format()   == 'Abc def'
    assert __StringFormatter('ABC,def').format()   == 'Abc def'
    assert __StringFormatter('abc(DEF)').format()  == 'Abc def'
    assert __StringFormatter('abc(DEF)').format()  == 'Abc def'

# Generated at 2022-06-12 07:12:59.119861
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Test 1 - Input is a valid camel case string
    test_input = 'ThisIsACamelStringTest'
    assert camel_case_to_snake(test_input) == 'this_is_a_camel_string_test'
    # Test 2 - Input is an invalid string
    test_input = 'this is not a camel case string'
    assert camel_case_to_snake(test_input) == test_input
    # Test 3 - Input is a valid camel case string with no lower case char but first one
    test_input = 'IDontHaveLowerCase'
    assert camel_case_to_snake(test_input) == 'i_dont_have_lower_case'
    
    
    
    
    
    
    



# Generated at 2022-06-12 07:13:01.657317
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:13:10.175494
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '_ ') == 'this_ is_ a_ camel_ string_ test'
    assert camel_case_to_snake('AnotherTest') == 'another_test'
    assert camel_case_to_snake('AnotherTest', '-') == 'another-test'

# Generated at 2022-06-12 07:13:15.610043
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
# Test cases for function camel_case_to_snake
test_camel_case_to_snake()



# Generated at 2022-06-12 07:13:22.527888
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('aB') == 'a_b'
    assert camel_case_to_snake('aBc') == 'a_bc'
    assert camel_case_to_snake('ABC') == 'abc'



# Generated at 2022-06-12 07:13:32.510531
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('  ').format() == ''
    assert __StringFormatter('ab,cd').format() == 'Ab, cd'
    assert __StringFormatter("A '+' symbol").format() == "A '+' symbol"
    assert __StringFormatter("?to bike").format() == 'To bike'
    assert __StringFormatter("!Oranges are...").format() == 'Oranges are...'
    assert __StringFormatter("This? is THE ONE").format() == 'This is THE ONE'
    assert __StringFormatter("This is... the one").format() == 'This is the one'
    assert __StringFormatter("..this is the one").format() == 'This is the one'

# Generated at 2022-06-12 07:13:42.916769
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('This_Is_A_Camel_String_Test') == 'this_is_a_camel_string_test'

# Generated at 2022-06-12 07:13:56.444332
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('my_snake_case_string') == 'MySnakeCaseString'
    assert snake_case_to_camel('my_snake_case_string', upper_case_first=False) == 'mySnakeCaseString'
    assert snake_case_to_camel('my_snake_case_string', separator='-') == 'MySnakeCaseString'
    assert snake_case_to_camel('my-snake-case-string') == 'MySnakeCaseString'
    assert snake_case_to_camel('my-snake-case-string', separator='-') == 'MySnakeCaseString'
    assert snake_case_to_camel('my-snake-case-string', upper_case_first=False) == 'mySnakeCaseString'
    assert snake_case

# Generated at 2022-06-12 07:14:04.365290
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('lower_snake_case_string') == 'LowerSnakeCaseString'
    assert snake_case_to_camel('lower_snake_case_string', upper_case_first=False) == 'lowerSnakeCaseString'
    assert snake_case_to_camel('lower_snake_case_string', separator='-') == 'LowerSnakeCaseString'
    assert snake_case_to_camel('lower_snake_case_string', upper_case_first=False, separator='-') == 'lowerSnakeCaseString'



# Generated at 2022-06-12 07:14:15.960497
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import unittest

    class Test__StringFormatter(unittest.TestCase):
        def test_case_1(self):
            self.assertEqual(__StringFormatter('this is number ONE').format(), 'This is number One')

        def test_case_2(self):
            self.assertEqual(__StringFormatter('this is number 1').format(), 'This is number 1')

        def test_case_3(self):
            self.assertEqual(__StringFormatter('this is number ten').format(), 'This is number Ten')

        def test_case_4(self):
            self.assertEqual(__StringFormatter('This is number ten').format(), 'This is number Ten')


# Generated at 2022-06-12 07:14:24.649375
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:31.943545
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # Arrange
    input_string = 'lorem ipsum  dolor sit  amet, (consectetur...)'
    expected = "Lorem ipsum dolor sit amet, consectetur..."

    # Act
    result = __StringFormatter(input_string).format()

    # Assert
    assert result == expected


# Generated at 2022-06-12 07:14:42.679364
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = ' '
    assert __StringFormatter(s).format() == ''

    s = '  '
    assert __StringFormatter(s).format() == ''

    s = '\t'
    assert __StringFormatter(s).format() == ''

    s = '\t\t'
    assert __StringFormatter(s).format() == ''

    s = ' \t\t'
    assert __StringFormatter(s).format() == ''

    s = ' \t\t'
    assert __StringFormatter(s).format() == ''

    s = ' \t\t\n'
    assert __StringFormatter(s).format() == ''

    s = ' \t\t\n\t'
    assert __StringFormatter(s).format() == ''

    s = '\n'

# Generated at 2022-06-12 07:14:53.959486
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from prymatex.utils.testing import TestCase
    class TestCase(TestCase):
        def test__around_sign(self):
            input_string = 'john@example.com'
            expected_string = 'john @ example.com'

            self.assertEqual(input_string, __StringFormatter(input_string).format())

        def test__saxon_genitive(self):
            input_string = 'I love Apple\'s trademark'
            expected_string = 'I love Apple\'s trademark'

            self.assertEqual(expected_string, __StringFormatter(input_string).format())

        def test__left_space(self):
            input_string = 'hello world!'
            expected_string = 'hello world !'


# Generated at 2022-06-12 07:15:06.090398
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # if upper_case_first == False
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    # if upper_case_first == True
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True) == 'TheSnakeIsGreen'
    # if input_string is not camel case
    assert snake_case_to_camel('TheSnakeIsGreen', upper_case_first=True) == 'TheSnakeIsGreen'
    # if separator is not "_"
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=True, separator='-') == 'TheSnakeIsGreen'
    # if input_string is None

# Generated at 2022-06-12 07:15:14.369590
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('thisIsCased').format() == 'This Is Cased'
    assert __StringFormatter('thisIsCased   ').format() == 'This Is Cased'
    assert __StringFormatter('this  IsCased    ').format() == 'This Is Cased'
    assert __StringFormatter('this  IsCased    and also this').format() == 'This Is Cased And Also This'
    assert __StringFormatter('this  IsCased    with  duplicate  spaces').format() == 'This Is Cased With Duplicate Spaces'
    assert __StringFormatter('this  IsCased    with  lots of duplicate  spaces').format() == 'This Is Cased With Lots Of Duplicate Spaces'

# Generated at 2022-06-12 07:15:24.355935
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:34.332134
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_case_string') == 'SnakeCaseString'
    assert snake_case_to_camel('snake_ca_se_str_ing', upper_case_first=False) == 'snakeCaSeStrIng'
    assert snake_case_to_camel('snake-c-a-se-str-ing', separator='-') == 'SnakeCASeStrIng'
    assert snake_case_to_camel('snake_c_a_se_str_ing') == 'SnakeCaseString'



# Generated at 2022-06-12 07:15:45.350456
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # test basic use
    input_string = 'the_snake_is_green'
    expected_string = 'TheSnakeIsGreen'
    assert snake_case_to_camel(input_string) == expected_string

    # test if can keep first letter lowercase
    input_string = 'the_snake_is_green'
    expected_string = 'theSnakeIsGreen'
    assert snake_case_to_camel(input_string, upper_case_first=False) == expected_string

    # test if can use custom separator
    input_string = 'the-snake-is-green'
    expected_string = 'TheSnakeIsGreen'
    assert snake_case_to_camel(input_string, separator='-') == expected_string



# Generated at 2022-06-12 07:15:53.029977
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', separator='-') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', separator='-', upper_case_first=False) == 'thisIsATest'
    assert snake_case_to_camel('this_is_a_test', separator=' ', upper_case_first=False) == 'this is a test'



# Generated at 2022-06-12 07:15:58.252738
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('first_second_third') == 'FirstSecondThird'
    assert snake_case_to_camel('first_second_third', upper_case_first=False) == 'firstSecondThird'
    assert snake_case_to_camel('some-dashed-string', separator='-') == 'SomeDashedString'
    assert snake_case_to_camel('some-dashed-string', upper_case_first=False, separator='-') == 'someDashedString'



# Generated at 2022-06-12 07:16:09.671911
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'The-Snake-Is-Green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-Snake-Is-Green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'The-Snake-Is-Green'

# Generated at 2022-06-12 07:16:15.059269
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='') == 'the_snake_is_green'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN', upper_case_first=False) == 'tHE_SNAKE_IS_GREEN'



# Generated at 2022-06-12 07:16:24.622103
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', upper_case_first=False) == 'helloWorld'
    assert snake_case_to_camel('helloWorld') == 'HelloWorld'

# Generated at 2022-06-12 07:16:32.355233
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green') == 'The-snake-is-green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'

# Generated at 2022-06-12 07:16:42.492617
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False) == 'thisIsATest'
    assert snake_case_to_camel('this-is-a-test', separator='-') == 'ThisIsATest'
    assert snake_case_to_camel('this is a test') == 'ThisIsATest'
    assert snake_case_to_camel('this:is:a:test', separator=':') == 'ThisIsATest'
    assert snake_case_to_camel('this is a test', separator=' ') == 'ThisIsATest'



# Generated at 2022-06-12 07:16:48.766573
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_another_test') == 'ThisIsAnotherTest'
    assert snake_case_to_camel('this_is_another_test', upper_case_first=False) == 'thisIsAnotherTest'



# Generated at 2022-06-12 07:17:03.282476
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', False) == 'test'
    assert snake_case_to_camel('test_test') == 'TestTest'
    assert snake_case_to_camel('test_test', False) == 'testTest'
    assert snake_case_to_camel('test_test', True, '-') == 'TestTest'
    assert snake_case_to_camel('test_test', False, '-') == 'testTest'
    assert snake_case_to_camel('test_test_test') == 'TestTestTest'
    assert snake_case_to_camel('test_test_test', False) == 'testTestTest'

# Generated at 2022-06-12 07:17:08.942084
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    assert snake_case_to_camel('hello', False) == 'hello'
    assert snake_case_to_camel('hello') == 'Hello'
    assert snake_case_to_camel('hello_world', False) == 'helloWorld'
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', False) == 'thisIsATest'

test_snake_case_to_camel()

# Generated at 2022-06-12 07:17:22.061814
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='_') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the.net_developer.is_green', upper_case_first=True, separator='_') == 'TheNetDeveloperIsGreen'
    assert snake_case_to_camel('the-net-developer-is-green', upper_case_first=True, separator='-') == 'TheNetDeveloperIsGreen'
    assert snake_case_to_camel('the-net-developer-is-green', upper_case_first=False, separator='-') == 'theNetDeveloperIsGreen'

# Generated at 2022-06-12 07:17:28.969052
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_b') == 'AB'
    assert snake_case_to_camel('a_b', upper_case_first=False) == 'aB'
    assert snake_case_to_camel('a_b', separator='-') == 'A-B'
    assert snake_case_to_camel('a_b', upper_case_first=False, separator='-') == 'a-B'
    assert snake_case_to_camel('a__b', separator='__') == 'AB'
    assert snake_case_to_camel('a__b', upper_case_first=False, separator='__') == 'aB'
    assert snake_case_to_camel('a__b') == 'AB'
    assert snake_case_to_c

# Generated at 2022-06-12 07:17:32.505149
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:17:34.435909
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:17:38.009989
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='-') == 'TheSnakeIsGreen'
test_snake_case_to_camel()



# Generated at 2022-06-12 07:17:48.737660
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test_snake_case_to_camel', False, '_') == 'testSnakeCaseToCamel'
    assert snake_case_to_camel('test_snake_case_to_camel', True, '_') == 'TestSnakeCaseToCamel'
    assert snake_case_to_camel('test_snake_case_to_camel_with_one_single_character', True, '_') == 'TestSnakeCaseToCamelWithOneSingleCharacter'
    assert snake_case_to_camel('test_snake_case_to_camel_with_one_single_character', False, '_') == 'testSnakeCaseToCamelWithOneSingleCharacter'

# Generated at 2022-06-12 07:17:50.044581
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test_test') == 'TestTest'
    assert snake_case_to_camel('test_test', False) == 'testTest'


# Generated at 2022-06-12 07:17:52.857536
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("python_is_cool", True, "_") == "PythonIsCool"
