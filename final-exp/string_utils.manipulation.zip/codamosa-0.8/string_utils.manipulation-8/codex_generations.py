

# Generated at 2022-06-12 07:12:34.589843
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '#') == 'this#is#a#camel#string#test'



# Generated at 2022-06-12 07:12:40.213105
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this') == 'this'
    assert camel_case_to_snake('') == ''



# Generated at 2022-06-12 07:12:52.205376
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():

    # test simple camel case
    assert camel_case_to_snake('thisIsATest') == 'this_is_a_test'

    # test camel case with starting lower case
    assert camel_case_to_snake('thisIsATest') == 'this_is_a_test'

    # test camel case with starting upper case
    assert camel_case_to_snake('ThisIsATest') == 'this_is_a_test'

    # test empty string
    assert camel_case_to_snake('') == ''

    # test with separator
    assert camel_case_to_snake('ThisIsATest', separator='-') == 'this-is-a-test'

    # test with invalid string
    assert camel_case_to_snake('123') == '123'
    assert camel_case

# Generated at 2022-06-12 07:13:01.865088
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '_') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '_') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:11.554378
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('this_is_not_a_camel_case_string') == 'this_is_not_a_camel_case_string'
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake(' ') == ' '
    assert camel_case_to_snake(' - ') == ' - '
    assert camel_case_to_snake('123') == '123'



# Generated at 2022-06-12 07:13:16.528076
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='+') == 'this+is+a+camel+string+test'



# Generated at 2022-06-12 07:13:28.403623
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def assert_equals(input_string, expected_output_string):
        assert __StringFormatter(input_string).format() == expected_output_string


# Generated at 2022-06-12 07:13:35.124801
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:37.954184
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:13:49.037416
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format(): # -> None
    import unittest
    sf = __StringFormatter

# Generated at 2022-06-12 07:14:08.333287
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # given
    input_string = '    hello    I\'m  a test string with     duplicates  and  spaces !!!   '
    expected = 'Hello I\'m a test string with duplicates and spaces !!!'

    # when
    actual = __StringFormatter(input_string).format()

    # then
    assert actual == expected


# PUBLIC API



# Generated at 2022-06-12 07:14:17.864199
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('b a b').format() == 'B A b'
    assert __StringFormatter('b   a b').format() == 'B A b'
    assert __StringFormatter('b  a   b').format() == 'B A b'
    assert __StringFormatter('b a-b').format() == 'B A-b'
    assert __StringFormatter('b       a  -  b').format() == 'B A - b'
    assert __StringFormatter('b a-b      ').format() == 'B A-b'
    assert __StringFormatter(' b a-b      ').format() == 'B A-b'
    assert __StringFormatter(' b a-b      ').format() == 'B A-b'

# Generated at 2022-06-12 07:14:25.656599
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:37.522900
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:43.433598
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # given
    input_string = 'hello world.a b..hello world..hello-world!!!    hello-world-hello-world-hello-world'
    expected_string = 'Hello world. A b. Hello world. Hello World! Hello world hello world hello world'

    # when
    actual_string = __StringFormatter(input_string).format()

    # then
    assert expected_string == actual_string


# PUBLIC API



# Generated at 2022-06-12 07:14:54.616939
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_cases = []

    # test case 1
    test_case = {
        'description': 'Should correctly format string',
        'input': 'ThisIs a simple   string              with some *placeholders*',
        'expected': 'This is a simple string with some *placeholders*',
    }
    test_cases.append(test_case)

    # test case 2
    test_case = {
        'description': 'Should correctly format string with placeholders',
        'input': 'ThisIs a simple string with some placeholders like http://google.com/ or test@test.com',
        'expected': 'This is a simple string with some placeholders like http://google.com/ or test@test.com',
    }
    test_cases.append(test_case)

    # test case 3

# Generated at 2022-06-12 07:15:07.215839
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('    This is a TEST  to run.   ').format() == 'This is a TEST to run.'
    assert __StringFormatter('    This is a TEST  to run.   ').format() != 'This is a TEST  to run.'
    assert __StringFormatter('HEllo, thiS is a tesT TO RUN').format() == 'Hello, this is a test to run'
    assert __StringFormatter('This is a TEST to run. BuT it IS a test').format() == 'This is a test to run. But it is a test.'
    assert __StringFormatter('This is a TEST to run. BuT it IS a test').format() != 'This is a TEST to run. But it IS a test.'

# Generated at 2022-06-12 07:15:11.842424
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Check for invalid inputs
    assert __StringFormatter.format(None) is None
    # Check for empty input
    assert __StringFormatter.format('') == ''
    # Check for single word
    assert __StringFormatter.format('word') == 'Word'
    # Check for single word with leading and trailing spaces
    assert __StringFormatter.format(' word ') == 'Word'
    # Check for single word with mixed spaces and tabs
    assert __StringFormatter.format(' \tword\t ') == 'Word'
    # Check for single word with mixed spaces and tabs
    assert __StringFormatter.format(' \tword\t ') == 'Word'
    # Check for multiple words (eg: "foo bar", not separated by any space)
    assert __StringFormatter.format('foo bar') == 'Foo bar'


# Generated at 2022-06-12 07:15:18.963693
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # pre-conditions
    assert isinstance(__StringFormatter, type)
    assert hasattr(__StringFormatter, 'format')

    # any object not matching constraints fails
    with pytest.raises(AttributeError): # noqa
        __StringFormatter.format()

    # given

# Generated at 2022-06-12 07:15:30.743021
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:43.981096
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # given
    input_string = "  Hello  there!!\n :)  "
    expected_output = "Hello there! :)"

    # when
    output = __StringFormatter(input_string).format()

    # then
    assert output == expected_output


# PUBLIC API



# Generated at 2022-06-12 07:15:48.466733
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('python-string-library').format() == 'Python String Library'
    assert __StringFormatter('PythonStringLibrary').format() == 'Python String Library'
    assert __StringFormatter('python string library').format() == 'Python String Library'
    assert __StringFormatter('Python String Library').format() == 'Python String Library'
    assert __StringFormatter('Python_String_Library').format() == 'Python String Library'
    assert __StringFormatter('PYTHON STRING LIBRARY').format() == 'Python String Library'
    assert __StringFormatter('python_string_library').format() == 'Python String Library'
    assert __StringFormatter('Python-String-Library').format() == 'Python String Library'
    assert __StringFormatter('this is-a test').format() == 'This Is A Test'

# Generated at 2022-06-12 07:15:57.370956
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('    Test     Test     ').format() == 'Test Test'
    assert __StringFormatter('    Test    TestTest      Test   ').format() == 'Test Test Test'
    assert __StringFormatter('The quick brown fox jumps over the lazy dog').format() == 'The quick brown fox jumps over the lazy dog'
    assert __StringFormatter(' The quick brown\n fox jumps over     the lazy dog').format() == 'The quick brown fox jumps over the lazy dog'
    assert __StringFormatter('The quick\nbrown fox jumps\nover the lazy dog').format() == 'The quick brown fox jumps over the lazy dog'
    assert __StringFormatter('a b c').format() == 'a b c'
    assert __StringFormatter('a b b c').format() == 'a b c'

# Generated at 2022-06-12 07:16:08.678776
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter(' hello world!  ').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello   world').format() == 'Hello world'
    assert __StringFormatter('hello  -  world').format() == 'Hello - world'
    assert __StringFormatter('hello- -world').format() == 'Hello - world'
    assert __StringFormatter(' hello - world ').format() == 'Hello - world'
    assert __StringFormatter(' hello    world ').format() == 'Hello world'
    assert __StringFormatter(' hello https://www.example.com world ').format() == 'Hello https://www.example.com world'
    assert __StringForm

# Generated at 2022-06-12 07:16:18.116577
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:28.370066
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:37.415991
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = 'è\'a tràvea de tùtti i cieli\r\r\r  \n\nla valàntia di cor di martín pescatòre  \r\r\r \r      \r  \n\n\n\n\n...\n\n\n\n\n\n\n\n\n\n'
    expected_string = "È'a tràvea de tùtti i cieli la valàntia di cor di Martín Pescatòre. ..."
    sf = __StringFormatter(input_string)
    output_string = sf.format()
    print('input string : {}'.format(input_string))
    print('output string: {}'.format(output_string))
    assert output_string == expected

# Generated at 2022-06-12 07:16:43.811135
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Tests with text which contains unicode characters
    assert __StringFormatter('  abc  ').format() == 'Abc'
    assert __StringFormatter('  abc def  ').format() == 'Abc def'
    assert __StringFormatter('  abc def  ghi  ').format() == 'Abc def ghi'
    assert __StringFormatter('  abc def  ghi  jkl ').format() == 'Abc def ghi jkl'
    assert __StringFormatter('abc  def ghi  jkl').format() == 'Abc def ghi jkl'
    assert __StringFormatter('  abc,  def, ghi  jkl').format() == 'Abc, def, ghi jkl'

# Generated at 2022-06-12 07:16:47.422188
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("This is a test, but it is not the test")

    assert sf.format() == "This is a test but it is not the test"


# Generated at 2022-06-12 07:16:56.718886
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('  this is   a   test string ')
    assert formatter.format() == 'This is a test string'

    formatter = __StringFormatter('  this is   a   test string ')
    assert formatter.format() == 'This is a test string'

    formatter = __StringFormatter('this is a test string     ')
    assert formatter.format() == 'This is a test string'

    formatter = __StringFormatter('  this is a test string')
    assert formatter.format() == 'This is a test string'

    formatter = __StringFormatter('  this is a test string')
    assert formatter.format() == 'This is a test string'

    formatter = __StringFormatter('  this is a test string')

# Generated at 2022-06-12 07:17:42.842682
# Unit test for function roman_encode
def test_roman_encode():
    input_number = '2021'
    assert roman_encode(input_number) == 'MMXXI'


# Generated at 2022-06-12 07:17:44.443244
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\'s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

test_prettify()


# Generated at 2022-06-12 07:17:55.618266
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # assertion helper method
    def assert_that(input_string: str, output_expected: str):
        actual_output = __StringFormatter(input_string).format()
        assert actual_output == output_expected

    assert_that('', '')
    assert_that(' ', '')
    assert_that('  ', '')
    assert_that(' a', 'a')
    assert_that('a ', 'a')
    assert_that('     a     ', 'a')
    assert_that('a a a a a', 'a a a a a')
    assert_that('a a a\ta a', 'a a a a a')
    assert_that('a a a a\ra a', 'a a a a a')
    assert_that('a a a a\na a', 'a a a a a')
    assert_

# Generated at 2022-06-12 07:18:06.891152
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    import unittest

    class TestClass(unittest.TestCase):

        def test_compress(self):
            compressor = __StringCompressor

            self.assertEqual(compressor.compress('hi'), 'eNpLz8w')
            self.assertEqual(compressor.compress('hi there'), 'eNpLz8w0Kvz8w')

            with self.assertRaises(ValueError):
                compressor.compress('', compression_level=-1)

            with self.assertRaises(InvalidInputError):
                compressor.compress(None)

        def test_decompress(self):
            compressor = __StringCompressor

            self.assertEqual(compressor.decompress('eNpLz8w'), 'hi')

# Generated at 2022-06-12 07:18:11.509620
# Unit test for function compress
def test_compress():
    string = ' '.join(['word n{}'.format(n) for n in range(20)])
    origin_len = len(string)
    compressed = compress(string)
    assert(len(compressed) < origin_len)
    assert(string == decompress(compressed))

test_compress()



# Generated at 2022-06-12 07:18:23.740123
# Unit test for function roman_encode

# Generated at 2022-06-12 07:18:36.117059
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Some+Symbols@$%^=+?|./;&"#\'<>`!,{}[]:') == 'some-symbols'
    assert slugify('False & True: 123') == 'false-true-123'
    assert slugify('I ♥ Dogs') == 'i-love-dogs'
    assert slugify('中文') == 'chinese'
    assert slugify('简体 字') == 'simplified-chinese'
    assert slugify('Some(Brackets)Here') == 'some-brackets-here'

# Generated at 2022-06-12 07:18:46.790487
# Unit test for function strip_margin

# Generated at 2022-06-12 07:18:50.677935
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed == original

# Generated at 2022-06-12 07:19:01.668402
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('') == ''
    assert strip_html('test1') == 'test1'
    assert strip_html('test1<b>test1</b>') == 'test1'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click\nhere</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">\rclick here</a>') == 'test: '