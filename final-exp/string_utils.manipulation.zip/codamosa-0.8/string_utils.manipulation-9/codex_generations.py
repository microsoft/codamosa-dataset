

# Generated at 2022-06-12 07:12:57.441984
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('lorem ipsum dolor sit amet').format() == 'Lorem Ipsum Dolor Sit Amet'
    assert __StringFormatter('lorem ipsum dolor sit amet,').format() == 'Lorem Ipsum Dolor Sit Amet,'
    assert __StringFormatter('lorem ipsum dolor sit amet,').format() == 'Lorem Ipsum Dolor Sit Amet,'
    assert __StringFormatter('lorem ipsum dolor sit amet, https://www.google.com/').format() == 'Lorem Ipsum Dolor Sit Amet, https://www.google.com/'

# Generated at 2022-06-12 07:13:08.201010
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format(): # added by to test internal private method of the library
    print("### Unit test for __StringFormatter.format method ###\n")
    # method to test
    i = __StringFormatter.format # method to test
    # test table (input, expected output)

# Generated at 2022-06-12 07:13:20.241936
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('aaaaa').format() == 'Aaaaa'
    assert __StringFormatter('AAAAA').format() == 'Aaaaa'
    assert __StringFormatter('abc ABC abc').format() == 'Abc Abc Abc'
    assert __StringFormatter('abc ABC abc').format() == 'Abc Abc Abc'
    assert __StringFormatter('abc ABC Abc').format() == 'Abc Abc Abc'
    assert __StringFormatter('abc ABC Abc').format() == 'Abc Abc Abc'
    assert __StringFormatter(' abc ABC Abc  ').format() == 'Abc Abc Abc'
    assert __StringFormatter('abc ABC Abc ').format() == 'Abc Abc Abc'
    assert __StringFormatter(' abc ABC Abc').format()

# Generated at 2022-06-12 07:13:31.012604
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    t = __StringFormatter.__placeholder_key()
    assert '$' == t[0]
    assert '$' == t[-1]
    assert len(t) == 18
    assert t[1:-1] == t[1:-1].lower()
    assert len(t[1:-1]) == 16
    assert len({t: True for i in range(100)}) == 100

    assert __StringFormatter('  A  ').format() == 'A'
    assert __StringFormatter('  A .  ').format() == 'A.'
    assert __StringFormatter('  A..  ').format() == 'A.'
    assert __StringFormatter('A . . . B').format() == 'A...B'
    assert __StringFormatter('A . . . _B').format() == 'A...B'

# Generated at 2022-06-12 07:13:41.973352
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('foo    bar').format() == 'Foo bar'
    assert __StringFormatter('foo - bar').format() == 'Foo - Bar'
    assert __StringFormatter('foo, bar').format() == 'Foo, bar'
    assert __StringFormatter('foo: bar').format() == 'Foo: bar'
    assert __StringFormatter('foo; bar').format() == 'Foo; bar'
    assert __StringFormatter('foo! bar').format() == 'Foo! bar'
    assert __StringFormatter('foo? bar').format() == 'Foo? bar'
    assert __StringFormatter('foo. bar').format() == 'Foo. bar'
    assert __StringFormatter('foo) bar').format() == 'Foo) bar'

# Generated at 2022-06-12 07:13:51.392766
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:02.341386
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:14.341668
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('')
    assert s.format() == ''

    s = __StringFormatter('a')
    assert s.format() == 'A'

    s = __StringFormatter('  a')
    assert s.format() == 'A'

    s = __StringFormatter('a  ')
    assert s.format() == 'A'

    s = __StringFormatter('  a  ')
    assert s.format() == 'A'

    s = __StringFormatter('a a')
    assert s.format() == 'A a'

    s = __StringFormatter('a A a')
    assert s.format() == 'A a a'

    s = __StringFormatter('a AA a')
    assert s.format() == 'A a a'


# Generated at 2022-06-12 07:14:23.283127
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('hello world')
    assert string_formatter.format() == 'Hello world'

    string_formatter = __StringFormatter('hello   world')
    assert string_formatter.format() == 'Hello world'

    string_formatter = __StringFormatter('hELLO woRLD')
    assert string_formatter.format() == 'Hello world'

    string_formatter = __StringFormatter('HElLo WoRLd')
    assert string_formatter.format() == 'Hello world'

    string_formatter = __StringFormatter('HElLo WoRLd???')
    assert string_formatter.format() == 'Hello world?'

    string_formatter = __StringFormatter('HElLo WoRLd???!')

# Generated at 2022-06-12 07:14:29.148456
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Create a string that contains all the patterns to match
    input_string = "This is an input string with some (additional) text."

    # Create a instance of __StringFormatter
    formatter = __StringFormatter(input_string)

    # After apply format method the result should be equal to the expected string
    output_string = formatter.format()
    expected_string = "This is an input string with some additional text."

    assert output_string == expected_string

# Generated at 2022-06-12 07:14:45.440682
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print(__StringFormatter('  hello  ').format())
    print(__StringFormatter('  a    A  ').format())
    print(__StringFormatter('a:b:c:d:e').format())
    print(__StringFormatter('h e l l o').format())
    print(__StringFormatter('  h e l l o  ').format())
    print(__StringFormatter('andre@example.com').format())
    print(__StringFormatter('ciao come stai').format())
    print(__StringFormatter('ciao come     stai').format())
    print(__StringFormatter('ciao   come     stai').format())
    print(__StringFormatter('a b c d e').format())
    print(__StringFormatter('a  b    c d e ').format())

# Generated at 2022-06-12 07:14:56.808309
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # lowercase_first_char
    assert __StringFormatter.UPPERCASE_FIRST_CHAR_RE.sub(__StringFormatter.__uppercase_first_char, 'hello') == 'Hello'
    # duplicate chars
    assert __StringFormatter.DUPLICATES_RE.sub(__StringFormatter.__remove_duplicates, 'hheelllloo') == 'hello'
    assert __StringFormatter.DUPLICATES_RE.sub(__StringFormatter.__remove_duplicates, 'hheelllloo') == 'hello'
    assert __StringFormatter.DUPLICATES_RE.sub(__StringFormatter.__remove_duplicates, 'No!!') == 'No!'
    # right spaces

# Generated at 2022-06-12 07:15:09.393374
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('aaa aaa a').format() == 'Aaa aaa a'
    assert __StringFormatter('a a a a a').format() == 'A a a a a'
    assert __StringFormatter('a a a a-a').format() == 'A a a -a'
    assert __StringFormatter('a a a a   -a').format() == 'A a a -a'
    assert __StringFormatter('a.a.a.a   -a').format() == 'A.a.a -a'
    assert __StringFormatter('a.a.a.a  - a').format() == 'A.a.a -a'
    assert __StringFormatter('  a.a.a.a. a').format() == 'A.a.a. a'

# Generated at 2022-06-12 07:15:18.434411
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:30.121422
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('This is a stupid test').format() == 'This is a stupid test'
    assert __StringFormatter('This is a stupid    test').format() == 'This is a stupid test'
    assert __StringFormatter('    This is a stupid test   ').format() == 'This is a stupid test'
    assert __StringFormatter('    This is a stupid  test ').format() == 'This is a stupid test'
    assert __StringFormatter('This is a stupid  test ').format() == 'This is a stupid test'
    assert __StringFormatter('This is a stupid  test  ').format() == 'This is a stupid test'
    assert __StringFormatter('This is a stupid  test ').format() == 'This is a stupid test'
    assert __StringFormatter('This is a stupid  t   est').format

# Generated at 2022-06-12 07:15:37.859854
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:48.360601
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Common case
    assert __StringFormatter('This Is A Test').format() == 'This is a test'

    # Duplicate chars
    assert __StringFormatter('This is a teessst').format() == 'This is a test'

    # Left and right spaces
    assert __StringFormatter('This is a test ').format() == 'This is a test'
    assert __StringFormatter(' This is a test').format() == 'This is a test'
    assert __StringFormatter(' This is a test ').format() == 'This is a test'

    # Internal spaces
    assert __StringFormatter('This   is    a    test').format() == 'This is a test'

    # Capitalization rules
    assert __StringFormatter('this-is-a-test').format() == 'This-is-a-test'
    assert __

# Generated at 2022-06-12 07:15:57.307657
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # this test case is used to test un-escaped cases
    test_input_string = " a href=\"javascript:alert(document.cookie);\" xss=removed ";
    expect_output_string = "a href=\"javascript:alert(document.cookie);\" xss=\"removed\""
    actual_output_string = __StringFormatter(test_input_string).format()
    assert expect_output_string == actual_output_string

    # this test case is to test escaped cases
    test_input_string = " a href=\"javascript:alert(document.cookie);\" xss=\"removed\" ";
    expect_output_string = "a href=\"javascript:alert(document.cookie);\" xss=\"removed\""
    actual_output_string = __StringFormatter(test_input_string).format()
    assert expect_

# Generated at 2022-06-12 07:16:08.560549
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:12.843084
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .test_data.__StringFormatter_format import STRINGS, EXPECTED_VALUES
    for input_string, expected_value in zip(STRINGS, EXPECTED_VALUES):
        formatter = __StringFormatter(input_string)
        assert formatter.format() == expected_value


# PUBLIC API



# Generated at 2022-06-12 07:16:23.834863
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(0) == ''
    assert roman_encode('0') == ''

# Generated at 2022-06-12 07:16:25.899187
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert original == decompressed

test_decompress()


# Generated at 2022-06-12 07:16:27.059601
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
test_reverse()



# Generated at 2022-06-12 07:16:32.710656
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:16:33.565077
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs') == 'top-10-reasons-to-love-dogs'



# Generated at 2022-06-12 07:16:42.904019
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('YES') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('nope') == False
    assert booleanize('NOPE') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('') == False
    assert booleanize(None) == False
    assert booleanize('Null') == False
    assert booleanize('abc') == False
    assert booleanize('10') == False
    assert booleanize('0.0') == False
    assert booleanize('0.1') == False
    assert booleanize('0.01') == False
    assert booleanize('True') == False


# Generated at 2022-06-12 07:16:45.177027
# Unit test for function strip_html
def test_strip_html():
    assert(strip_html('test: <a href="foo/bar">click here</a>')) == "test: "
    assert(strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)) == "test: click here"



# Generated at 2022-06-12 07:16:49.534496
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '


# Generated at 2022-06-12 07:16:56.364574
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '+') == 'this+is+a+camel+string+test'
    assert camel_case_to_snake('this_is_a_snake_string_test') == 'this_is_a_snake_string_test'



# Generated at 2022-06-12 07:16:58.289809
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                line 1
                line 2
                line 3
            ''') == '''
                line 1
                line 2
                line 3
            '''
    return True

# Generated at 2022-06-12 07:17:15.127087
# Unit test for function decompress
def test_decompress():
    compress_string = 'string compression test'
    compress_string_decode = decompress(compress(compress_string))
    assert compress_string == compress_string_decode



# Generated at 2022-06-12 07:17:16.881273
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == -1

# Generated at 2022-06-12 07:17:26.556469
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    string = snake_case_to_camel('the_snake_is_green') # returns 'TheSnakeIsGreen'
    assert string == 'TheSnakeIsGreen'
    string = snake_case_to_camel('the_snake_is_green',upper_case_first=False) # returns 'theSnakeIsGreen'
    assert string == 'theSnakeIsGreen'
    string = snake_case_to_camel('the-snake-is-green', separator='-') # returns 'TheSnakeIsGreen'
    assert string == 'TheSnakeIsGreen'
    string = snake_case_to_camel('the-snake-is-green',upper_case_first=False, separator='-') # returns 'TheSnakeIsGreen'
    assert string == 'theSnakeIsGreen'
    string = snake_case_to_

# Generated at 2022-06-12 07:17:38.489812
# Unit test for function strip_html
def test_strip_html():
    test_strings = [
        'test: <a href="foo/bar">click here</a>',
        'test: <a href="foo/bar">click here</a>',
        'test: <a href="foo/bar">click here</a>',
    ]

    expected_results = [
        'test: ',
        'test: click here',
        'test: click here'
    ]

    for i, test_str in enumerate(test_strings):
        keep_content = i % 2 == 0

        res = strip_html(test_str, keep_tag_content=keep_content)

        assert res == expected_results[i], res

    try:
        strip_html('test', keep_tag_content=True)
    except InvalidInputError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-12 07:17:43.196644
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-12 07:17:45.259004
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter('hello world')
    # assert formatter.input_string == 'hello world'


# Generated at 2022-06-12 07:17:53.494875
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: &nbsp;') == 'test:  '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('<strong>test:</strong>') == 'test:'
    assert strip_html('') == ''



# Generated at 2022-06-12 07:18:06.273157
# Unit test for function roman_decode

# Generated at 2022-06-12 07:18:15.780224
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers

# Generated at 2022-06-12 07:18:25.658236
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_text = "Hello World"

    # out = __StringFormatter(input_text).format()
    # print(out)
    # print(input_text)
    # print(out == input_text)

    input_text = "Hello World, I've said\nHello World"
    # out = __StringFormatter(input_text).format()
    # print(out)
    # print(input_text)
    # print(out == input_text)

    input_text = "Hello World, I've said\nHello World"
    # out = __StringFormatter(input_text).format()
    # print(out)
    # print(input_text)
    # print(out == input_text)

    input_text = "Hello  World"
    # out = __StringFormatter(input_text).

# Generated at 2022-06-12 07:18:46.395553
# Unit test for function slugify

# Generated at 2022-06-12 07:18:58.076904
# Unit test for function strip_margin
def test_strip_margin():
    import unittest

    class TestStripMargin(unittest.TestCase):
        def test_indentation(self):
            test_string = '''
                Hello World
                How Are You?
            '''
            expected = '''
Hello World
How Are You?
'''

            self.assertEqual(strip_margin(test_string), expected)

        def test_indentation_using_tabs(self):
            test_string = '''
                Hello World
                How Are You?
            '''
            expected = '''
Hello World
How Are You?
'''

            self.assertEqual(strip_margin(test_string), expected)


# Generated at 2022-06-12 07:19:00.209694
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:19:02.871559
# Unit test for function compress
def test_compress():
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    original = 'string'
    compressed = compress(original)
    assert compressed == 'c3RyaW5n'


# Generated at 2022-06-12 07:19:04.440955
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_camel_case_string_test' == camel_case_to_snake('ThisIsACamelStringTest')



# Generated at 2022-06-12 07:19:06.470035
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-12 07:19:10.783480
# Unit test for function decompress
def test_decompress():
    # "original" will be a string with 169 chars
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    assert original == decompress(compressed)



# Generated at 2022-06-12 07:19:12.089704
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-12 07:19:14.771833
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7



# Generated at 2022-06-12 07:19:18.769412
# Unit test for function strip_html
def test_strip_html():
    # test with string containing html tags
    test_str = "test: <a href='foo/bar'>foo</a>"
    expected_result = "test: foo"
    assert strip_html(test_str, keep_tag_content=True) == expected_result, "Test failed"
    # test with string not containing html tags
    test_str = "test: foo"
    assert strip_html(test_str, keep_tag_content=True) == expected_result, "Test failed"



# Generated at 2022-06-12 07:19:45.333628
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-12 07:19:46.290059
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-12 07:19:51.199807
# Unit test for function compress
def test_compress():
    assert compress("This is a test string to be compressed") == "eNpdV+lu2zYQ/BVx5F18cRGfM+yBtJmIIiEhbKoXl+7aikqW/uBCkVdJpcRGWnDVywQrNrJNzNMX1+c=\n"



# Generated at 2022-06-12 07:19:58.101976
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test:<a href="foo/bar">click here</a>') == 'test:'
    assert strip_html('test:<a href="foo/bar">click here</a>', keep_tag_content=True) == 'test:click here'
    assert strip_html('test:<a href="foo/bar">click here</a>', keep_tag_content=False) == 'test:'

test_strip_html()



# Generated at 2022-06-12 07:20:02.719467
# Unit test for function slugify
def test_slugify():
    print(slugify('Top 10 Reasons To Love Dogs!!!'))
    print(slugify('Mönstér Mägnët'))

test_slugify()


# Generated at 2022-06-12 07:20:05.107069
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:20:09.998365
# Unit test for function strip_margin
def test_strip_margin():
    multi = """\
                    |This is a test
                    |
                    |    for strip margin
                    |    function
                    |
                    |    - it works?
                    |    - yes, it does!
                    |""".stripMargin

    assert inStrippedMargin(multi) == """\
|This is a test
|
|for strip margin
|function
|
|- it works?
|- yes, it does!
|""".stripMargin

# Generated at 2022-06-12 07:20:15.361772
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__reversed_mappings == [
        {'I': 1, 'V': 5},
        {'X': 1, 'L': 5},
        {'C': 1, 'D': 5},
        {'M': 1}
    ]


# Generated at 2022-06-12 07:20:18.395342
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse(' ') == ' '
    assert reverse('1234567890') == '0987654321'



# Generated at 2022-06-12 07:20:30.178391
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    res = __RomanNumbers
    assert res.decode(res.encode(1)) == 1
    assert res.decode(res.encode(5)) == 5
    assert res.decode(res.encode(10)) == 10
    assert res.decode(res.encode(15)) == 15
    assert res.decode(res.encode(20)) == 20
    assert res.decode(res.encode(25)) == 25
    assert res.decode(res.encode(30)) == 30
    assert res.decode(res.encode(35)) == 35
    assert res.decode(res.encode(40)) == 40
    assert res.decode(res.encode(45)) == 45
    assert res.decode(res.encode(50)) == 50
    assert res.dec