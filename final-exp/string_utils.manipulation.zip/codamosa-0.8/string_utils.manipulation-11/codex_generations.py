

# Generated at 2022-06-12 07:12:57.338184
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a   a').format() == 'A a'
    assert __StringFormatter('a . a').format() == 'A. A'
    assert __StringFormatter('a ... a').format() == 'A a'
    assert __StringFormatter('a - a').format() == 'A - A'
    assert __StringFormatter('a + a').format() == 'A + A'
    assert __StringFormatter('a / a').format() == 'A / A'
    assert __StringFormatter('a (a)').format() == 'A (A)'
    assert __StringFormatter('a(a)').format() == 'A (A)'
    assert __StringFormatter('a[a]').format() == 'A [A]'

# Generated at 2022-06-12 07:13:08.136729
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter
    assert formatter('test').format() == 'test'
    assert formatter('test test').format() == 'test test'
    assert formatter('test test test').format() == 'test test test'
    assert formatter('test  test  test').format() == 'test test test'
    assert formatter('test\ttest\ttest').format() == 'test test test'
    assert formatter('test\n\ntest\n\ntest').format() == 'test test test'
    assert formatter('test\r\n\r\ntest\r\n\r\ntest').format() == 'test test test'
    assert formatter('test test test').format() == 'test test test'

# Generated at 2022-06-12 07:13:20.241660
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:23.704407
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('my name Is  -Emilio-  ').format() == 'My Name is Emilio'



# Generated at 2022-06-12 07:13:33.105207
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def assert_returns(input_string, expected_output) -> None:
        actual_output = __StringFormatter(input_string).format()
        assert actual_output == expected_output

    assert_returns('', '')
    assert_returns(' ', '')
    assert_returns('     ', '')
    assert_returns('\t', '')
    assert_returns('\t\t\t', '')
    assert_returns(' \t ', '')
    assert_returns(' \t\t\t ', '')
    assert_returns('aaa', 'aaa')
    assert_returns('aaa bbb', 'aaa bbb')
    assert_returns('aaa bbb ', 'aaa bbb')
    assert_returns(' aaa bbb', 'aaa bbb')
    assert_returns

# Generated at 2022-06-12 07:13:40.160845
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
# End unit tests



# Generated at 2022-06-12 07:13:50.517198
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('The quick brown fox jumped over the lazy dog.').format() == 'The quick brown fox jumped over the lazy dog.'
    assert __StringFormatter('The     quick     brown     fox     jumped     over     the     lazy     dog.').format() == 'The quick brown fox jumped over the lazy dog.'
    assert __StringFormatter('Mr.Smith is a doctor.He works in a hospital.').format() == 'Mr. Smith is a doctor. He works in a hospital.'
    assert __StringFormatter('"Why do the trees have such long names?" I asked.').format() == '"Why do the trees have such long names?" I asked.'

# Generated at 2022-06-12 07:14:01.305363
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:08.022521
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # arrange
    input_string = 'sOme - sTring to. test,  this.function.    it is a   short.   one'
    expected = 'Some - String to. Test, this.function. It is a short. One'
    formatter = __StringFormatter(input_string)

    # act
    actual = formatter.format()

    # assert
    assert expected == actual



# Generated at 2022-06-12 07:14:17.684584
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('  this  is my   test string   ')
    assert s.format() == 'This is my test string'
    s = __StringFormatter('   this (is) my (test) string:)  ')
    assert s.format() == 'This (is) my (test) string:'
    s = __StringFormatter('  This  is my   Test String   ')
    assert s.format() == 'This is my Test String'
    s = __StringFormatter('  ThIS  is my   TEST stRing   ')
    assert s.format() == 'This is my Test String'
    s = __StringFormatter('  this is my test string!  ')
    assert s.format() == 'This is my test string!'

# Generated at 2022-06-12 07:14:37.161123
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('I am a string.').format() == 'I am a string.'
    assert __StringFormatter('I am a lots spaces string.').format() == 'I am a lots spaces string.'
    assert __StringFormatter('Iamoneofthoseemail@test.com').format() == 'I am one of those email@test.com'
    assert __StringFormatter('Iamoneofthoseemail@test.comLorem ipsum.').format() == 'I am one of those email@test.com Lorem ipsum.'
    assert __StringFormatter('Iamoneofthoseemail@test.com  Lorem ipsum.').format() == 'I am one of those email@test.com Lorem ipsum.'

# Generated at 2022-06-12 07:14:41.373461
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello') == 'Hello'
    assert snake_case_to_camel('hello', False) == 'hello'
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', False) == 'helloWorld'



# Generated at 2022-06-12 07:14:46.317505
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('my_snake_is_sweet', False) == 'mySnakeIsSweet'
    assert snake_case_to_camel('my_snake_is_green') == 'MySnakeIsGreen'
    assert snake_case_to_camel('this_is_not_a_snake', '-') == 'ThisIsNotASnake'



# Generated at 2022-06-12 07:14:57.075683
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   test  ').format() == 'Test'
    assert __StringFormatter('   test   test   ').format() == 'Test test'
    assert __StringFormatter('   test   test  test  ').format() == 'Test test test'
    assert __StringFormatter('   test   test  a   test  ').format() == 'Test test a test'

    assert __StringFormatter('the test').format() == 'The test'
    assert __StringFormatter('the   test').format() == 'The test'
    assert __StringFormatter('the   test   the').format() == 'The test the'
    assert __StringFormatter('   the   test   the').format() == 'The test the'

# Generated at 2022-06-12 07:15:03.147896
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('test snake_case_to_camel')
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:15:12.908654
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  asdfasdf ').format() == 'Asdfasdf'
    assert __StringFormatter('Asdfasdf').format() == 'Asdfasdf'
    assert __StringFormatter(' asdfasdf ').format() == 'Asdfasdf'
    assert __StringFormatter('asdfasdf asdfasdf').format() == 'Asdfasdf asdfasdf'
    assert __StringFormatter('asdfasdf asdfasdf asdfasdf').format() == 'Asdfasdf asdfasdf asdfasdf'
    assert __StringFormatter('asdfasdf    asdfasdf').format() == 'Asdfasdf asdfasdf'

# Generated at 2022-06-12 07:15:21.215041
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:15:23.917357
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    for expected, input_string in PRETTIFY_TEST_DATA.items():
        assert __StringFormatter(input_string).format() == expected

# PUBLIC API


# Generated at 2022-06-12 07:15:34.621601
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  mr   j.  l.   ').format() == 'Mr J. L.'
    assert __StringFormatter('').format() == ''
    assert __StringFormatter(' ').format() == ''
    assert __StringFormatter('  ').format() == ''
    assert __StringFormatter('  \t ').format() == ''
    assert __StringFormatter('  123   ').format() == '123'
    assert __StringFormatter('  16/06/2008   ').format() == '16/06/2008'
    assert __StringFormatter('  1.45   ').format() == '1.45'
    assert __StringFormatter('  -1.45   ').format() == '-1.45'
    assert __StringFormatter('  +1.45   ').format

# Generated at 2022-06-12 07:15:39.593210
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:52.850031
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('un   beau gros    mail:     www.google.fr@gmail.com')
    assert f.format() == 'Un beau gros mail: www.google.fr@gmail.com'
test___StringFormatter_format()


# Generated at 2022-06-12 07:15:59.767089
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('the  quick  brown      fox jumps  over the     lazy  dog').format() == 'the quick brown fox jumps over the lazy dog'
    assert __StringFormatter('The  QUICK  BrOwn      FoX Jumps  oVer The     LaZy  DoG').format() == 'The Quick Brown Fox Jumps Over The Lazy Dog'
    assert __StringFormatter('this is--a cool--example').format() == 'This Is A Cool Example'
    assert __StringFormatter('this is--a_cool--example').format() == 'This Is-A_Cool Example'
    assert __StringFormatter('this is--a cool--example@asd').format() == 'This Is A Cool Example'
    assert __StringFormatter('this is--a cool--example@asd').format() == 'This Is A Cool Example'


# Generated at 2022-06-12 07:16:10.763055
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('this is a test')
    assert f.format() == 'This is a test'

    f = __StringFormatter('This  is  a test?yes!!')
    assert f.format() == 'This is a test? Yes!!'

    f = __StringFormatter('This  is  a test?yes!!')
    assert f.format() == 'This is a test? Yes!!'

    f = __StringFormatter('This  is  a  test?yes!!')
    assert f.format() == 'This is a test? Yes!!'

    f = __StringFormatter('this  is  a  test?yes!!')
    assert f.format() == 'This is a test? Yes!!'

    f = __StringFormatter('http://hello.com')

# Generated at 2022-06-12 07:16:19.035930
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    class Test:
        def __init__(self, description: str, input: str, expected_output: str):
            self.description = description
            self.input = input
            self.expected_output = expected_output


# Generated at 2022-06-12 07:16:29.193474
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:38.024653
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    def test(actual, expected):
        assert actual == expected

    formatter = __StringFormatter('camelCase')
    test(formatter.format(), 'Camel case')

    formatter = __StringFormatter('snake_case')
    test(formatter.format(), 'Snake case')

    formatter = __StringFormatter('PascalCase')
    test(formatter.format(), 'Pascal case')

    formatter = __StringFormatter('Title Case')
    test(formatter.format(), 'Title case')

    formatter = __StringFormatter('kebab-case')
    test(formatter.format(), 'Kebab case')

    formatter = __StringFormatter('Sentence case.')
    test(formatter.format(), 'Sentence case.')


# Generated at 2022-06-12 07:16:44.223281
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('string test').format() == 'string test'
    assert __StringFormatter('string test string').format() == 'string test string'
    assert __StringFormatter('  string  test  string  ').format() == 'string test string'
    assert __StringFormatter('string testString test').format() == 'string test String test'
    assert __StringFormatter('string testString testString test').format() == 'string test String test String test'
    assert __StringFormatter('string testString testString testString test').format() == 'string test String test String test String test'
    assert __StringFormatter('string      test       string').format() == 'string test string'
    assert __StringFormatter('string test string').format() == 'string test string'

# Generated at 2022-06-12 07:16:55.460995
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('')


# Generated at 2022-06-12 07:16:57.363439
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('this should be formatted')

    assert f.format() == 'This should be formatted'



# Generated at 2022-06-12 07:17:06.314010
# Unit test for method format of class __StringFormatter