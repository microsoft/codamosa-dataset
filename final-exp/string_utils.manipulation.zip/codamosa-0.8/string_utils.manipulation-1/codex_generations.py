

# Generated at 2022-06-12 07:12:54.081351
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from random import randint
    from string import ascii_letters
    from unittest import TestCase

    class __StringFormatter_format__Test(TestCase):
        def test_random_input(self):
            for i in range(0, 1000):
                input_string = ''.join(ascii_letters[randint(0, len(ascii_letters) - 1)] for i in range(0, randint(10, 100)))
                formatter = __StringFormatter(input_string)
                self.assertEqual(formatter.format(), input_string)

    __StringFormatter_format__Test().test_random_input()

# Generated at 2022-06-12 07:13:05.292877
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    try:
        __StringFormatter('').format()
        raise AssertionError
    except ValueError:
        pass

    try:
        __StringFormatter(None).format()
        raise AssertionError
    except InvalidInputError:
        pass

    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world  ').format() == 'Hello world'
    assert __StringFormatter('  hello world').format() == 'Hello world'
    assert __StringFormatter('\thello world  ').format() == 'Hello world'
    assert __StringFormatter('\t  hello world  ').format() == 'Hello world'
    assert __StringFormatter('\t  Hello world  ').format() == 'Hello world'

# Generated at 2022-06-12 07:13:11.967514
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter(' random test ')
    assert sf.format() == 'Random test'
    sf = __StringFormatter(' random test 123')
    assert sf.format() == 'Random test 123'
    sf = __StringFormatter('random test 123 ')
    assert sf.format() == 'Random test 123'
    sf = __StringFormatter(' random test 123 ')
    assert sf.format() == 'Random test 123'
    sf = __StringFormatter('www.google.com')
    assert sf.format() == 'www.google.com'
    sf = __StringFormatter('http://www.google.com')
    assert sf.format() == 'http://www.google.com'
    sf = __StringFormatter('email@gmail.com')

# Generated at 2022-06-12 07:13:21.281470
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test data
    out = []
    s = ' '
    out.append({'in': 'a', 'out': 'A'})
    out.append({'in': 'ab', 'out': 'Ab'})
    out.append({'in': 'abc', 'out': 'Abc'})
    out.append({'in': 'a b', 'out': 'A b'})
    out.append({'in': 'a  b', 'out': 'A b'})
    out.append({'in': 'a   b', 'out': 'A b'})
    out.append({'in': '  a   b  ', 'out': 'A b'})
    out.append({'in': '  a   b   ', 'out': 'A b'})

# Generated at 2022-06-12 07:13:30.245414
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import pytest
    def test_format(input_string, expected_output):
        actual_output = __StringFormatter(input_string).format()

        assert actual_output == expected_output


# Generated at 2022-06-12 07:13:41.335716
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('this is an ugly formatted string').format() == 'This is an ugly formatted string'
    assert __StringFormatter(' this is an ugly formatted string ').format() == 'This is an ugly formatted string'
    assert __StringFormatter('this is an ugly formatted string this is an ugly formatted string ').format() == 'This is an ugly formatted string this is an ugly formatted string'
    assert __StringFormatter(' this is an ugly formatted string this is an ugly fo-rmat-ted string').format() == 'This is an ugly formatted string this is an ugly fo-rmat-ted string'

    assert __StringFormatter('this-is-a-test').format() == 'This-is-a-test'
    assert __StringFormatter('this- is-a-test').format() == 'This-is-a-test'
    assert __

# Generated at 2022-06-12 07:13:50.960490
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('I\'m an email: foo@bar.com').format() == 'I\'m an email: foo@bar.com'
    assert __StringFormatter('I\'m an url: https://www.google.com').format() == 'I\'m an url: https://www.google.com'
    assert __StringFormatter('I\'m an url http://www.google.com with a lot of leading white spaces  ').format() == \
        'I\'m an url http://www.google.com with a lot of leading white spaces'
    assert __StringFormatter('I\'m an url http://www.google.com with a lot of trailing white spaces ').format() == \
        'I\'m an url http://www.google.com with a lot of trailing white spaces'

# Generated at 2022-06-12 07:13:57.534434
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:03.283214
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:06.526325
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('    ThisIsAStringToPrettify?    ').format() == 'This Is A String To Prettify?'



# Generated at 2022-06-12 07:14:20.038531
# Unit test for function roman_encode

# Generated at 2022-06-12 07:14:28.468213
# Unit test for function roman_decode
def test_roman_decode():
    assert(roman_decode("VII") == 7)
    assert(roman_decode("XIX") == 19)
    assert(roman_decode("V") == 5)
    assert(roman_decode("MDCXV") == 1615)
    assert(roman_decode("MMDCXV") == 2615)
    assert(roman_decode("MMMDCCCXLV") == 3845)
    assert(roman_decode("mmmdcccxlv") == 3845)


# Generated at 2022-06-12 07:14:30.544897
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-12 07:14:40.651325
# Unit test for function slugify
def test_slugify():
	import unittest

	class TestSlugify(unittest.TestCase):
	    def test_empty_string_should_return_empty_string(self):
	        self.assertEqual('', slugify(''))

	    def test_none_string_should_return_empty_string(self):
	        self.assertEqual('', slugify(None))

	    def test_string_with_spaces_should_be_transformed_into_slug(self):
	        self.assertEqual('a-slug', slugify('a slug'))

	    def test_string_with_multiple_spaces_should_be_transformed_into_slug(self):
	        self.assertEqual('a-slug', slugify('a   slug'))


# Generated at 2022-06-12 07:14:42.213576
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    
    uncompressed = decompress(compressed)
    assert original == uncompressed
    
test_compress()

# Test for all functions

# Generated at 2022-06-12 07:14:46.536137
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
      line 1
      line 2
      line 3
    '''

    expected = '''
      line 1
      line 2
      line 3
    '''

    assert strip_margin(s) == expected



# Generated at 2022-06-12 07:14:48.164722
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
test_slugify()


# Generated at 2022-06-12 07:14:53.235109
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

if __name__ == '__main__':
    test_prettify()



# Generated at 2022-06-12 07:15:01.819795
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import re
    import pytest
    from .errors import InvalidInputError
    from .validation import is_integer


# Generated at 2022-06-12 07:15:12.540498
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" class="btn btn-danger">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" class="btn btn-danger" style="color: red">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('hello <br> world') == 'hello world'
    assert strip_html('hello <br/> world') == 'hello world'

# Generated at 2022-06-12 07:15:20.441993
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('I') == 1
    assert roman_decode('X') == 10
    assert roman_decode('XX') == 20
    assert roman_decode('MMXX') == 2020
    assert roman_decode('MMDXX') == 2520


# Generated at 2022-06-12 07:15:22.768429
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'


# Generated at 2022-06-12 07:15:33.840987
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-12 07:15:39.300409
# Unit test for function prettify

# Generated at 2022-06-12 07:15:41.400877
# Unit test for function booleanize
def test_booleanize():
    check(booleanize('true') == True)
    check(booleanize('nope') == False)
    check(booleanize('yeS') == True)
    
test_booleanize()



# Generated at 2022-06-12 07:15:51.703398
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # check if all possible cases are properly handled
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'

# Generated at 2022-06-12 07:15:58.806567
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Foo bar').format() == 'Foo bar'
    assert __StringFormatter(' foo bar ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('FOO bar').format() == 'Foo bar'
    assert __StringFormatter('FOO bar foo bar').format() == 'Foo bar Foo bar'
    assert __StringFormatter('FOO bar . foo bar').format() == 'Foo bar. Foo bar'
    assert __StringFormatter('FOO bar : foo bar').format() == 'Foo bar: Foo bar'
    assert __StringFormatter('FOO bar, foo bar').format() == 'Foo bar, Foo bar'

# Generated at 2022-06-12 07:16:02.081554
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('y') == True)
    assert(booleanize('true') == True)
    assert(booleanize('True') == True)
    assert(booleanize('yes') == True)
    assert(booleanize('1') == True)
    assert(booleanize('n') == False)
    assert(booleanize('f') == False)
    assert(booleanize('') == False)
    assert(booleanize(0) == False)
    assert(booleanize('False') == False)
test_booleanize()



# Generated at 2022-06-12 07:16:08.189383
# Unit test for function decompress
def test_decompress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    decompress(compressed)


# noinspection PyTypeChecker

# Generated at 2022-06-12 07:16:12.169583
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert len(original) > len(compressed)



# Generated at 2022-06-12 07:16:35.915216
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('')

    # Test 1: invalid input
    try:
        f.format()
        raise AssertionError()
    except InvalidInputError:
        pass

    # Test 2: ensure that uppercase the first char of the string
    f = __StringFormatter('test string')
    assert f.format() == 'Test string'

    # Test 3: ensure that uppercase the first char of each word, also with 2 consecutive spaces
    f = __StringFormatter('this is an     test string')
    assert f.format() == 'This is an test string'

    # Test 4: ensure that remove duplicated word separators
    f = __StringFormatter('this is an    test    string')
    assert f.format() == 'This is an test string'

    # Test 5: ensure that remove duplicated word

# Generated at 2022-06-12 07:16:38.547664
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('Aa') == 'aa'
    assert reverse('ab') == 'ba'
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-12 07:16:44.996543
# Unit test for function shuffle
def test_shuffle():
    # Given
    input_string = 'Il commissario Montalbano'
    expected_output = 'mI ebmrnommcoi ctii asobaa lnr'

    # When
    output = shuffle(input_string)

    # Then
    assert output == expected_output
test_shuffle()



# Generated at 2022-06-12 07:16:49.685172
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('hello world')) == 'hello world'
    assert decompress(compress('hello world', 'latin-1')) == 'hello world'
    assert decompress(compress('你好')) == '你好'

test_decompress()


# Generated at 2022-06-12 07:17:00.220303
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('This is A TEST')
    # formatter.input_string = 'This is A TEST'
    out = formatter.format()
    assert out == 'This is a test'

    formatter.input_string = 'This iS a test'
    out = formatter.format()
    assert out == 'This is a test'

    formatter.input_string = 'This I is a test'
    out = formatter.format()
    assert out == 'This i is a test'

    formatter.input_string = 'This I is a test'
    out = formatter.format()
    assert out == 'This i is a test'

    formatter.input_string = 'This is a test, ok'
    out = formatter.format()
    assert out == 'This is a test, ok'

# Generated at 2022-06-12 07:17:10.295590
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:17:22.612996
# Unit test for function shuffle
def test_shuffle():
    string_to_test1 = 'ciao come stai?'
    string_to_test2 = 'hello world!'
    string_to_test3 = 'foo bar'
    string_to_test4 = 'foo'
    string_to_test5 = 'foobar'
    shuffled_string1 = shuffle(string_to_test1)
    shuffled_string2 = shuffle(string_to_test2)
    shuffled_string3 = shuffle(string_to_test3)
    shuffled_string4 = shuffle(string_to_test4)
    shuffled_string5 = shuffle(string_to_test5)

# Generated at 2022-06-12 07:17:29.356112
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Encode test
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(900) == 'CM'


# Generated at 2022-06-12 07:17:30.589370
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:17:35.552574
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings == [
        {1: 'I', 5: 'V'},
        {1: 'X', 5: 'L'},
        {1: 'C', 5: 'D'},
        {1: 'M'},
    ]

