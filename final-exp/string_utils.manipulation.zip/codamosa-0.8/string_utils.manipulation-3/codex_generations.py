

# Generated at 2022-06-12 07:12:42.471866
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello WORLD').format() == 'Hello world'
    assert __StringFormatter('hello, WORLD').format() == 'Hello, world'
    assert __StringFormatter('*hello* WORLD').format() == '*Hello* world'
    assert __StringFormatter('The *hello* WORLD').format() == 'The *Hello* world'
    assert __StringFormatter('hello WORLD.').format() == 'Hello world.'
    assert __StringFormatter(' hello WORLD').format() == 'Hello world'
    assert __StringFormatter('hello WORLD ').format() == 'Hello world'
    assert __StringFormatter('hello  WORLD').format() == 'Hello world'
    assert __StringFormatter('hello WORLD  ').format() == 'Hello world'
    assert __StringFormatter(' hello WORLD ').format() == 'Hello world'
   

# Generated at 2022-06-12 07:12:47.996576
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:12:55.333834
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    t.eq_(snake_case_to_camel('the_snake_is_green'), 'TheSnakeIsGreen') 
    t.eq_(snake_case_to_camel('the_snake_is_green', False), 'theSnakeIsGreen')
    t.eq_(snake_case_to_camel('the_snake_is_green', True, '-'), 'TheSnakeIsGreen')

test_snake_case_to_camel()



# Generated at 2022-06-12 07:13:06.247775
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('aAa').format() == 'Aaa'
    assert __StringFormatter('a  b').format() == 'A b'
    assert __StringFormatter('  a  b').format() == 'A b'
    assert __StringFormatter('a b ').format() == 'A b'
    assert __StringFormatter('a b').format() == 'A b'
    assert __StringFormatter('  a b').format() == 'A b'
    assert __StringFormatter('a A b').format() == 'A A b'
    assert __StringFormatter('a  A b').format() == 'A A b'
    assert __StringFormatter('  a  A b').format() == 'A A b'
    assert __StringFormatter('  a  A  b').format() == 'A A b'

# Generated at 2022-06-12 07:13:13.141146
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    """
    Test function snake_case_to_camel
    """
    # Test case 1, to see if the function allows a snake case input with multiple separator
    # (we should see a camel case output with the first letter in uppercase)
    input_string = 'some_string_here'
    result = snake_case_to_camel(input_string)
    expected_result = 'SomeStringHere'
    assert result == expected_result

    # Test case 2, to see if the function allows a snake case input with a custom separator
    # in uppercase and the first letter of the output will be in lowercase
    input_string = 'some-string-here'
    result = snake_case_to_camel(input_string, upper_case_first = False, separator='-')

# Generated at 2022-06-12 07:13:18.400747
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Given
    input_string = 'lorem     ipsum dolor sit amet       consectetur adipiscing elit   .'
    expected = 'Lorem ipsum dolor sit amet consectetur adipiscing elit.'

    # When
    actual = __StringFormatter(input_string).format()

    # Then
    assert actual == expected

# Generated at 2022-06-12 07:13:29.902943
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('email@example.com')
    result = formatter.format()
    assert result == 'email@example.com'

    formatter = __StringFormatter('http://www.google.com')
    result = formatter.format()
    assert result == 'http://www.google.com'

    formatter = __StringFormatter('''  I'M a lIttle  tEa  pOt
        shorT and stouT
        hEre  is my hAndLe 
        hEre is my spout
      ''')
    result = formatter.format()
    assert result == "I'm a little tea pot short and stout here is my handle here is my spout"


# Generated at 2022-06-12 07:13:33.052308
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world',upper_case_first=False) == 'helloWorld'
    print("test_snake_case_to_camel passed.")
test_snake_case_to_camel()


# Generated at 2022-06-12 07:13:43.155853
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world', False) == 'helloWorld'
    assert snake_case_to_camel('hello_world', True) == 'HelloWorld'
    assert snake_case_to_camel('the_snake_is_green', True) == 'TheSnakeIsGreen'

    assert snake_case_to_camel('hello-world', False) == 'helloWorld'
    assert snake_case_to_camel('hello-world', True) == 'HelloWorld'
    assert snake_case_to_camel('the-snake-is-green', True) == 'TheSnakeIsGreen'

    assert snake_case_to_camel('hello_hello-world', False) == 'helloHelloWorld'

# Generated at 2022-06-12 07:13:51.759758
# Unit test for method format of class __StringFormatter