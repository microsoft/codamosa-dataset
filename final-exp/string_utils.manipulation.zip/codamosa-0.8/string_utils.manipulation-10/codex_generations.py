

# Generated at 2022-06-12 07:12:42.006827
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('This is a tesT')
    assert f.format() == 'This is a test'

    f = __StringFormatter('This    is    a    tesT')
    assert f.format() == 'This is a test'

    f = __StringFormatter('<p>This    is    a    tesT</p>')
    assert f.format() == 'This is a test'

    f = __StringFormatter('<p>This is</p> <p>a    tesT</p>')
    assert f.format() == 'This is a test'

    f = __StringFormatter('<BR/>This is<BR/>a    tesT<BR/>')
    assert f.format() == 'This is a test'


# Generated at 2022-06-12 07:12:55.546357
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    def run_test(input_string: str, expected_output: str):
        actual_output = __StringFormatter(input_string).format()
        assert actual_output == expected_output

    # check if the first char is uppercase
    run_test('my string', 'My string')

    # spaces inside and around should be removed
    run_test(' my string ', 'My string')

    # consecutive uppercase letters should be reduced to just one
    run_test('My String', 'My String')

    # consecutive lowercase letters should be reduced to just one
    run_test('my string', 'My string')

    # 's should be converted to 's (apostrophe followed by s)
    run_test('my string\'s', 'My string\'s')

    # a, the and other small words should not be uppercase


# Generated at 2022-06-12 07:13:06.370823
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen', 'test_snake_case_to_camel 1'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen', 'test_snake_case_to_camel 2'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen', 'test_snake_case_to_camel 3'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen', 'test_snake_case_to_camel 4'
    assert snake_case

# Generated at 2022-06-12 07:13:12.529831
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def test(input_string, expected):
        actual = __StringFormatter(input_string).format()
        assert expected == actual, (input_string, expected, actual)

    test('  aa  a bb', 'Aa a bb')
    test('  aa  a bb dddddd', 'Aa a bb dddddd')
    test('  aa  a bb    dddddd', 'Aa a bb dddddd')
    test('aa  a bb    dddddd', 'Aa a bb dddddd')
    test('"aaa a bb dddddd"', '"Aaa a bb dddddd"')
    test('\'aaa a bb dddddd\'', '\'Aaa a bb dddddd\'')


# Generated at 2022-06-12 07:13:20.690263
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('all is OK').format() == 'All is ok'
    assert __StringFormatter('it is an error').format() == 'It is an error'
    assert __StringFormatter('it is a new error').format() == 'It is a new error'
    assert __StringFormatter('it is a new error  on  this  economy').format() == 'It is a new error on this economy'
    assert __StringFormatter('it\'s an error').format() == "It's an error"
    assert __StringFormatter('It\'s  an  error').format() == "It's an error"
    assert __StringFormatter('It\'s an error it is').format() == "It's an error it is"

# Generated at 2022-06-12 07:13:31.012096
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello') == 'Hello'
    assert snake_case_to_camel('hello', upper_case_first=False) == 'hello'
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:37.724078
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:44.979232
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    assert snake_case_to_camel(input_string[0:1]) == 'T'
    assert snake_case_to_camel(input_string) == 'TheSnakeIsGreen'
    assert snake_case_to_camel(input_string, upper_case_first=False) == 'theSnakeIsGreen'

test_snake_case_to_camel()



# Generated at 2022-06-12 07:13:50.376301
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_val = " ALl'  ato di pAolo’s place  "
    expected_val = "All' ato di Paolo's place"

    actual_val = __StringFormatter(input_val).format()

    if actual_val != expected_val:
        print('test___StringFormatter_format: values are different: "{}" and "{}"'.format(expected_val, actual_val))
        return False
    else:
        return True


# Generated at 2022-06-12 07:14:00.678963
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Test for function snake_case_to_camel')
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '--') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '--') == 'theSnakeIsGreen'

# Generated at 2022-06-12 07:14:15.243723
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("hello_world") == "HelloWorld"
    assert snake_case_to_camel("hello_world", upper_case_first=False) == "helloWorld"
    assert snake_case_to_camel("hello", upper_case_first=True, separator="-") == "Hello"
    assert snake_case_to_camel("hello", upper_case_first=False, separator="-") == "hello"
    assert snake_case_to_camel("") == ""
    assert snake_case_to_camel("hello") == "Hello"
    assert snake_case_to_camel("1hello") == "1hello"


# Generated at 2022-06-12 07:14:21.246941
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test', True) == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', False) == 'thisIsATest'
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', separator='-') == 'this_is_a_test'
    assert snake_case_to_camel('this-is-a-test', True, '-') == 'ThisIsATest'

# Generated at 2022-06-12 07:14:31.917967
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Correct conversion
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-', upper_case_first=False) == 'theSnakeIsGreen'
    # Invalid input
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-12 07:14:34.652256
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:14:44.798516
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('snake_case') == 'SnakeCase'
    assert snake_case_to_camel('snake_case', False) == 'snakeCase'

# Generated at 2022-06-12 07:14:55.827453
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  Lorem ipsum dolor  sit  amet,   consectetur    adipiscing   elit.').format() == \
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert __StringFormatter('Lorem ipsum dolor sit amet, consectetur adipiscing elit.').format() == \
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'

# Generated at 2022-06-12 07:15:08.554024
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # tests must be called with ascii locale to ensure that unicode normalization works properly
    import locale
    locale.setlocale(locale.LC_ALL, 'ascii')


# Generated at 2022-06-12 07:15:18.015537
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:19.321704
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # TODO: write unit test please
    pass


# PUBLIC API



# Generated at 2022-06-12 07:15:31.154982
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("I’m not a bot").format() == "I'm not a bot"
    assert __StringFormatter("I don’t know").format() == "I don't know"
    assert __StringFormatter("I’ve seen").format() == "I've seen"
    assert __StringFormatter("I’d like").format() == "I'd like"
    assert __StringFormatter("I'll test").format() == "I'll test"
    assert __StringFormatter("I’ll test").format() == "I'll test"
    assert __StringFormatter("Apotheosis’").format() == "Apotheosis'"
    assert __StringFormatter("I’ll be back").format() == "I'll be back"

# Generated at 2022-06-12 07:15:43.025705
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = ('   foo bar baz \n eoieo foo \n\n\n\nfoo\n\n\n\n'
                    'foo foo foo foo\n a\n a\n a\n a\n a\n a\n a   \n a')
    expected = 'foo bar baz eoieo foo foo foo foo foo foo foo foo a a a a a a a a'
    formatter = __StringFormatter(input_string)
    assert formatter.format() == expected


# PUBLIC API



# Generated at 2022-06-12 07:15:51.786576
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False) == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", separator="-") == "The-Snake-Is-Green"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False, separator="-") == "the-Snake-Is-Green"
    
test_snake_case_to_camel()

# Generated at 2022-06-12 07:15:54.555091
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('asdfgh') == 'Asdfgh'
    assert snake_case_to_camel('my_test') == 'MyTest'
    assert snake_case_to_camel('my_test_string', upper_case_first=False, separator='_') == 'myTestString'



# Generated at 2022-06-12 07:16:06.101762
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:15.563613
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake') == 'ThisIsASnake'
    assert snake_case_to_camel('this_is_a_snake', True) == 'ThisIsASnake'
    assert snake_case_to_camel('this_is_a_snake', False) == 'thisIsASnake'
    assert snake_case_to_camel('this_is_a_snake', False, '-') == 'this-is-a-snake'
    assert snake_case_to_camel('this_is_a_snake', False, '_') == 'thisIsASnake'
    assert snake_case_to_camel('this_is_a_snake', True, '-') == 'This-is-a-snake'


# Generated at 2022-06-12 07:16:19.764667
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:16:24.589584
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_case_string') == 'SnakeCaseString'
    assert snake_case_to_camel('snake_case_string', False) == 'snakeCaseString'
    assert snake_case_to_camel('snake_case_string', True, '-') == 'SnakeCaseString'
    assert snake_case_to_camel('snake_case_string', False, '-') == 'snakeCaseString'



# Generated at 2022-06-12 07:16:35.150664
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'


# Generated at 2022-06-12 07:16:36.570753
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:16:40.476938
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    out = __StringFormatter('   look at   www my email com    and tell me  to  add  me  on https://www.facebook.com/john.smith?lol=123&yolo=456  ').format()

    assert 'Look at www.myemail.com and tell me to add me on https://www.facebook.com/john.smith?lol=123&yolo=456' == out



# Generated at 2022-06-12 07:16:57.602489
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('String to prettify').format() == 'String to prettify'
    assert __StringFormatter('String to prettify.').format() == 'String to prettify.'
    assert __StringFormatter(' string to prettify ').format() == 'string to prettify'
    assert __StringFormatter('   string   to   prettify   ').format() == 'string to prettify'
    assert __StringFormatter('   sTrInG   tO   pReTtIfY   ').format() == 'String to prettify'
    assert __StringFormatter('My  String  to  prettify').format() == 'My String to prettify'
    assert __StringFormatter('My  string  to  prettify').format() == 'My string to prettify'

# Generated at 2022-06-12 07:17:06.501797
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('user@example.com').format() == 'user@example.com'
    assert __StringFormatter('http://www.example.com').format() == 'http://www.example.com'

    assert __StringFormatter('this  is a \r\n test\t').format() == 'this is a test'
    assert __StringFormatter('  test  ').format() == 'test'
    assert __StringFormatter('text  text').format() == 'text text'

    assert __StringFormatter('  this  is the!end  ').format() == 'this is the!end'
    assert __StringFormatter('  text  .').format() == 'text .'

    assert __StringFormatter('   this is   the   test  ').format() == 'this is the test'
    assert __StringForm

# Generated at 2022-06-12 07:17:15.032489
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a Bcd efg hij-k').format() == 'A bcd efg hij-k'
    assert __StringFormatter('a?? Bcd efg hij**k').format() == 'A bcd efg hij-k'
    assert __StringFormatter('a?? Bcd efg hij**k').format() == 'A bcd efg hij-k'
    assert __StringFormatter('a?? Bcd efg hij**k').format() == 'A bcd efg hij-k'
    assert __StringFormatter('a?? Bcd efg hij**k').format() == 'A bcd efg hij-k'
    assert __StringFormatter('a?? Bcd efg hij**k').format() == 'A bcd efg hij-k'

# Generated at 2022-06-12 07:17:25.469630
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def run(input_: str, output: str):
        assert __StringFormatter(input_).format() == output

    run('''
@anonymous       hi !      lorem    ipsum james@my-mail.com
http://www.google.it?q=ciao&name=value
''', '''
@Anonymous Hi! Lorem Ipsum James@My-Mail.Com
Http://Www.Google.It?Q=Ciao&Name=Value
''')
    run('  http://www.example.com', 'Http://Www.Example.Com')
    run('http://www.example.com  ', 'Http://Www.Example.Com')
    run('http://www.example.com', 'Http://Www.Example.Com')

# Generated at 2022-06-12 07:17:30.773413
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from . import assert_equals

    def _test(input_string, expected_output):
        assert_equals(__StringFormatter(input_string).format(), expected_output)

    _test('This is a   test', 'This is a test')
    _test('this is a test', 'This is a test')
    _test('this; is a test', 'This; is a test')
    _test('this is a test, is a test', 'This is a test, is a test')
    _test('this is a test,  is a test', 'This is a test, is a test')
    _test('  this is a  test', 'This is a test')
    _test('this is a test  ', 'This is a test')
    _test('this, is a test', 'This, is a test')
   

# Generated at 2022-06-12 07:17:35.942676
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('ciao').format() == 'Ciao'
    assert __StringFormatter('ciao come va').format() == 'Ciao come va'
    assert __StringFormatter('ciao come va?!').format() == 'Ciao come va ? !'
    assert __StringFormatter('ciao, come va?!\n').format() == 'Ciao, come va ? !'
    assert __StringFormatter('ciao.come va?!\n').format() == 'Ciao. Come va ? !'
    assert __StringFormatter('ciao, cosa fai?\n').format() == 'Ciao, cosa fai ?'
    assert __StringFormatter('Ciao, cosa fai?\n').format() == 'Ciao, cosa fai ?'

# Generated at 2022-06-12 07:17:46.743402
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    input_string = 'this_is_a_test'
    assert snake_case_to_camel(input_string, True, '_') == 'ThisIsATest'

    input_string = 'this_is_a_test'
    assert snake_case_to_camel(input_string, False, '_') == 'thisIsATest'

    input_string = 'thisisatest'
    assert snake_case_to_camel(input_string, True, '_') == 'Thisisatest'

    input_string = 'thisisatest'
    assert snake_case_to_camel(input_string, False, '_') == 'thisisatest'

    input_string = 'THIS_IS_A_TEST'

# Generated at 2022-06-12 07:17:57.701861
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a bb  ccc  dddd     eeeee').format() == 'A bb ccc dddd eeeee'
    assert __StringFormatter('a bb  ccc  dddd     eeeee.').format() == 'A bb ccc dddd eeeee.'
    assert __StringFormatter('a bb  ccc  dddd     eeeee .').format() == 'A bb ccc dddd eeeee.'
    assert __StringFormatter('a bb  ccc  dddd     eeeee . ').format() == 'A bb ccc dddd eeeee.'
    assert __StringFormatter('a-bb  ccc  dddd     eeeee . ').format() == 'A-bb ccc dddd eeeee.'

# Generated at 2022-06-12 07:18:08.913523
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:18:16.708746
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Test for "snake_case_to_camel" function:')


# Generated at 2022-06-12 07:18:24.093974
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-12 07:18:33.069741
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('nice') == 'ecin'
    assert reverse('this is a test') == 'tset a si siht'
    assert reverse('ciao') == 'oaic'
    assert reverse('ciao a tutti') == 'ittut a oaic'
    assert reverse('ciao a tutti come va?') == '?av emoc ittut a oaic'

test_reverse()



# Generated at 2022-06-12 07:18:43.815022
# Unit test for function prettify

# Generated at 2022-06-12 07:18:54.636351
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'snakeCaseString' == snake_case_to_camel('snake_case_string')
    assert 'snakeCaseString' == snake_case_to_camel('snake-case-string', '-')
    assert 'snakeCaseString' == snake_case_to_camel('snake case string', ' ')
    assert 'snakeCaseString' == snake_case_to_camel('snake*case*string', '*')
    assert 'snakeCaseString' == snake_case_to_camel('snake\tcase\tstring', '\t')
    assert 'snakeCaseString' == snake_case_to_camel('snake\ncase\nstring', '\n')

# Generated at 2022-06-12 07:19:00.911322
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert isinstance(compressed,str) == True
    assert isinstance(compressed,str) == True
    assert len(original) > len(compressed) == True


# Generated at 2022-06-12 07:19:03.140482
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin("""
line1
line2
line3
line4
    """) == """
line1
line2
line3
line4
    """


# Generated at 2022-06-12 07:19:10.818712
# Unit test for function prettify

# Generated at 2022-06-12 07:19:15.062630
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # test with a non string input
    try:
        __StringFormatter(123)
        raise ValueError('Error: non string input was accepted')
    except InvalidInputError:
        pass

    # test with a valid string input
    if __StringFormatter('example').input_string != 'example':
        raise ValueError('Error: input string mismatch')

test___StringFormatter()


# PUBLIC API



# Generated at 2022-06-12 07:19:19.875610
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-12 07:19:23.173874
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    sf_hello_world = __StringFormatter("Hello World")
    assert(sf_hello_world.input_string == "Hello World")
    sf_000 = __StringFormatter("000")
    assert(sf_000.input_string == "000")


# Generated at 2022-06-12 07:19:48.506534
# Unit test for function slugify
def test_slugify():
    test_string = "ab cd ef gh"
    # expect_string = "ab-cd-ef-gh"
    expect_string = "ab_cd_ef_gh"

    out_string = slugify(test_string)
    print(out_string)
    print(expect_string)
    assert out_string == expect_string

test_slugify()


# Generated at 2022-06-12 07:19:51.165451
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'

    out = snake_case_to_camel(input_string)

    assert out == 'TheSnakeIsGreen'


# Generated at 2022-06-12 07:19:53.657404
# Unit test for function compress
def test_compress():
    assert compress("testo di prova") == "eJwDAAAAAAE=", "Test compress"
test_compress()


# Generated at 2022-06-12 07:19:56.548471
# Unit test for function strip_margin
def test_strip_margin():
    # GIVEN
    input_string = '''
    line 1
    line 2
    line 3
    '''
    expected = '''
line 1
line 2
line 3
'''

    # WHEN
    result = strip_margin(input_string)

    # THEN
    assert result == expected



# Generated at 2022-06-12 07:20:07.873187
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('fooùbaròó') == 'fooubaroo'
    assert asciify('fooùbaròó') != 'fooubarooo'

# Generated at 2022-06-12 07:20:09.743224
# Unit test for function strip_html
def test_strip_html():
    print(strip_html('test: <a href="foo/bar">click here</a>'))

# Generated at 2022-06-12 07:20:11.261574
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('a')



# Generated at 2022-06-12 07:20:16.899274
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_my_string') == 'ThisIsMyString'
    assert snake_case_to_camel('this_is_my_string', upper_case_first=False) == 'thisIsMyString'
    assert snake_case_to_camel('this_is_my_string', separator='-') == 'ThisIsMyString'
    assert snake_case_to_camel('this-is-my-string') == 'ThisIsMyString'
    assert snake_case_to_camel('this-is-my-string', separator='-') == 'ThisIsMyString'
    assert snake_case_to_camel('this-is-my-string', separator='_') == 'ThisIsMyString'

# Generated at 2022-06-12 07:20:22.924605
# Unit test for function prettify
def test_prettify():
    """
    Unit test for function prettify.
    prettify() takes a string and modify it to follow some basic grammar rules (see function documentation for more info)
    """
    prettify_test_string = "   foo   's    string.it' s \"prettified\"..it's \n\nanother\nline.     "
    expected = 'Foo\'s string. It\'s "prettified". It\'s another line.'
    actual = prettify(prettify_test_string)

    assert actual == expected, f'Expected prettify({prettify_test_string}) to return "{expected}", ' \
                              f'but it returned "{actual}"'



# Generated at 2022-06-12 07:20:28.665287
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'

# Pending test for function camel_case_to_snake
# def test_camel_case_to_snake():
#    assert camel_case_to_snake() == ''
