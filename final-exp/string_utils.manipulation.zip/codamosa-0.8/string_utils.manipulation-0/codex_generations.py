

# Generated at 2022-06-12 07:12:33.867129
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamel_CaseStringTest') == 'this_is_a_camel_case_string_test'

    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelCaseStringTest', separator='-') == 'this-is-a-camel-case-string-test'
    assert camel_case_to_sn

# Generated at 2022-06-12 07:12:40.934635
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert is_snake_case(camel_case_to_snake('CamelCase'))
    assert is_snake_case(camel_case_to_snake('camelCase'))
    assert is_snake_case(camel_case_to_snake('CamelCaseTest'))
    assert is_snake_case(camel_case_to_snake('CamelCaseTestCase'))
    assert is_snake_case(camel_case_to_snake('CamelCaseTestCaseCase'))
    assert is_snake_case(camel_case_to_snake('CamelCaseTestCaseCaseCase'))
    assert is_snake_case(camel_case_to_snake('CamelCaseTestCaseCaseCaseCase'))

# Generated at 2022-06-12 07:12:48.346163
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'



# Generated at 2022-06-12 07:12:54.742428
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '@') == 'this@is@a@camel@case@string@test'
    assert camel_case_to_snake('invalid_string') == 'invalid_string'



# Generated at 2022-06-12 07:13:00.754791
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('test') == 'test'



# Generated at 2022-06-12 07:13:03.140615
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:13:08.166086
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test')



# Generated at 2022-06-12 07:13:20.246168
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('camelCase') == 'camel_case'
    assert camel_case_to_snake('testCamelCase') == 'test_camel_case'
    assert camel_case_to_snake('testCamelCase123') == 'test_camel_case123'
    assert camel_case_to_snake('testCamelCase123Test') == 'test_camel_case123_test'
    assert camel_case_to_snake('TestCamelCase123Test') == 'test_camel_case123_test'

# Generated at 2022-06-12 07:13:27.492878
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTEST') == 'this_is_a_camel_string_t_e_s_t'



# Generated at 2022-06-12 07:13:33.331300
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-12 07:13:41.868470
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('                                                                                                                                                            ') == ''
    assert asciify('                                                                                                                                                            ') == ''
    assert asciify('                                                                                                                                                            ') == ''



# Generated at 2022-06-12 07:13:47.918305
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:13:55.771027
# Unit test for function booleanize
def test_booleanize():
	assert booleanize('true') == True
	assert booleanize('false') == False
	assert booleanize('1') == True
	assert booleanize('0') == False
	assert booleanize('yes') == True
	assert booleanize('no') == False
	assert booleanize('y') == True
	assert booleanize('n') == False
	assert booleanize('yes, please') == False
	assert booleanize(2) == False
	assert booleanize(0) == False
	assert booleanize(1) == False
	assert booleanize('YES') == True
	assert booleanize('no') == False

# Generated at 2022-06-12 07:13:58.911354
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    romanNumbers = __RomanNumbers()
    assert(romanNumbers.__encode_digit(0, 3) == 'III')
    assert(romanNumbers.__encode_digit(2, 5) == 'D')


# Generated at 2022-06-12 07:14:04.703986
# Unit test for function reverse
def test_reverse():
    assert reverse('ciao') == 'oaic'
    assert reverse('') == ''
    assert reverse('Hello World!') == '!dlroW olleH'
    assert reverse('  Hello World!  ') == '  !dlroW olleH  '
    assert reverse('  Hello   World!  ') == '  !dlroW   olleH  '



# Generated at 2022-06-12 07:14:11.621379
# Unit test for function slugify
def test_slugify():
    print('test slugify')
    assert_equal(slugify('Top 10 Reasons To Love Dogs!!!'), 'top-10-reasons-to-love-dogs')
    assert_equal(slugify('Mönstér Mägnët'), 'monster-magnet')
    assert_equal(slugify('Mönstér Mägnët ', '_'), 'monster_magnet')
    print('OK\n')


# Generated at 2022-06-12 07:14:16.610210
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('12345') == '54321'
    assert reverse('     ') == '     '
    assert reverse('H1!!') == '!!1H'

    try:
        reverse(12345)
        raise RuntimeError("Should have raised InvalidInputError")
    except InvalidInputError as _:
        pass



# Generated at 2022-06-12 07:14:22.009359
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('0') == ''
    assert roman_encode('4000') == ''
    assert roman_encode('-1') == ''
    assert roman_encode('-123') == ''
    assert roman_encode('1') == 'I'
    assert roman_encode('2') == 'II'
    assert roman_encode('3') == 'III'
    assert roman_encode('4') == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode('6') == 'VI'
    assert roman_encode('7') == 'VII'
    assert roman_encode('8') == 'VIII'
    assert roman_encode('9') == 'IX'

# Generated at 2022-06-12 07:14:28.388773
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    random_string = str(uuid4())
    input_string = '<html><head><title>Title me</title></head><body><p>This is a crazy world</p></body></html>'
    compressed = __StringCompressor.compress(input_string)
    assert compressed != input_string
    assert __StringCompressor.decompress(compressed) == input_string

test___StringCompressor()


# PUBLIC API


# Generated at 2022-06-12 07:14:38.103974
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('FALSE') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize('Y') == True
    assert booleanize('N') == False
    assert booleanize('TRUE') == True
    assert booleanize('FALSE') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    assert booleanize('Yes') == True
    assert booleanize('No') == False
    assert booleanize('YEs') == True
    assert booleanize('NO') == False
# End unit test
