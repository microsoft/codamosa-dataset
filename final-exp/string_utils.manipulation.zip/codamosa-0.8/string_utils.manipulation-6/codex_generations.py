

# Generated at 2022-06-12 07:12:37.298106
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_is_green', upper_case_first=True, separator='_') == 'SnakeIsGreen'
    assert snake_case_to_camel('snake_is_green', upper_case_first=False, separator='_') == 'snakeIsGreen'

    assert snake_case_to_camel('snake-is-green', upper_case_first=True, separator='-') == 'SnakeIsGreen'
    assert snake_case_to_camel('snake-is-green', upper_case_first=False, separator='-') == 'snakeIsGreen'

    assert snake_case_to_camel('snake_is_green', upper_case_first=True) == 'SnakeIsGreen'

# Generated at 2022-06-12 07:12:40.503487
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Testing correct conversion of snake_case to camelCase')
    assert snake_case_to_camel('snake_case_to_camel') == 'SnakeCaseToCamel' , 'Correct conversion of snake_case_to_camel'
    print('Successfully passed!')
test_snake_case_to_camel()


# Generated at 2022-06-12 07:12:52.835177
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    assert snake_case_to_camel('empty') == 'Empty'
    assert snake_case_to_camel('empty', upper_case_first=False) == 'empty'
    assert snake_case_to_camel('empty_string') == 'EmptyString'
    assert snake_case_to_camel('empty_string', upper_case_first=False) == 'emptyString'
    assert snake_case_to_camel('string_with_spaces') == 'StringWithSpaces'
    assert snake_case_to_camel('string_with_spaces', upper_case_first=False) == 'stringWithSpaces'
    assert snake_case_to_camel('string_with_spaces_and_spaces', separator=' ') == 'StringWithSpacesAndSpaces'
    assert snake_case_

# Generated at 2022-06-12 07:13:04.339985
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('THISIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTestXXX') == 'this_is_a_camel_string_test_xxx'

# Generated at 2022-06-12 07:13:09.096176
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:20.427952
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    print("Test 1: 'ThisIsACamelStringTest' -> 'this_is_a_camel_string_test'", end='')
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    print(' ✓')

    print("Test 2: 'thisIsACamelStringTest' -> 'this_is_a_camel_string_test'", end='')
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    print(' ✓')

    # single letter should be uppercased
    print("Test 3: 'thisisacamelstringtest' -> 'thisisacamelstringtest'", end='')
    assert camel_case_to_snake

# Generated at 2022-06-12 07:13:31.136884
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('upper_case_first') == 'UpperCaseFirst'
    assert snake_case_to_camel('lower_case_first', upper_case_first=False) == 'lowerCaseFirst'
    assert snake_case_to_camel('test__test', separator='__') == 'TestTest'
    assert snake_case_to_camel('test__test', upper_case_first=False, separator='__') == 'testTest'
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', upper_case_first=False) == 'test'
    assert snake_case_to_camel('Test') == 'Test'

# Generated at 2022-06-12 07:13:41.791061
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_SNake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-', upper_case_first=True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:45.138731
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-12 07:13:54.951596
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTestWithALongNameThatShouldBeSplit') == 'this_is_a_camel_string_test_with_a_long_name_that_should_be_split'

# Generated at 2022-06-12 07:14:10.407382
# Unit test for function asciify
def test_asciify():
    assert('eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))
    assert('eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))
    assert('uuuuuuuuuuuuu' == asciify('üüüüüüüüüüüüüüü'))
    assert('aaeeeuueee' == asciify('äáéèëüééé'))
    assert('aaeeeuueee' == asciify('äáéèëüééé'))

# Generated at 2022-06-12 07:14:11.820958
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-12 07:14:16.224303
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
test_roman_encode()


# Generated at 2022-06-12 07:14:18.256363
# Unit test for function compress
def test_compress():
    assert compress('test') == "eJwLJicnAAsvIzs="


# Generated at 2022-06-12 07:14:26.179214
# Unit test for function shuffle
def test_shuffle():
    assert shuffle(None) == None
    assert shuffle('') == ''
    assert shuffle(' ') == ' '
    assert is_shuffled_string('abcdefghijklmnopqrstvwxyz', 'zyxwtvrsqponmlkjihgfedcba')
    assert is_shuffled_string('abcdefghijklmnopqrstvwxyz', shuffle('abcdefghijklmnopqrstvwxyz'))



# Generated at 2022-06-12 07:14:34.375250
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('a string with some  \n empty lines\nand trailing spaces ') == 'A string with some empty lines and' \
                                                                                ' trailing spaces'

# Generated at 2022-06-12 07:14:37.936662
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
        line 1
        line 2
        line 3
    '''
    strip_margin(s)
    assert True

# Generated at 2022-06-12 07:14:39.224002
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('TestCamelCase') == 'test_camel_case'



# Generated at 2022-06-12 07:14:45.811083
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('ii') == 2
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('xxxix') == 39
    assert roman_decode('MMMCMXCIX') == 3999
    with pytest.raises(InvalidInputError):
        roman_decode(' ')
    with pytest.raises(InvalidInputError):
        roman_decode('')
    with pytest.raises(InvalidInputError):
        roman_decode('M-')

# Generated at 2022-06-12 07:14:48.645071
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(__StringCompressor.compress('hello world')) == 'hello world'



# Generated at 2022-06-12 07:14:57.337413
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('XIV') == 14
    assert roman_decode('MDCCCXCIV') == 1894
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('MCDXXXVII') == 1437
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('DCCCLXXXVIII') == 888
    assert roman_decode('MCDLXXXII') == 1482
    assert roman_decode('CDXLIV') == 444
    assert roman_decode('MMMCMXCIX') == 3999
    assert roman_decode('MMMCMXCI') == 3990
    assert roman_decode('MMMCMXC') == 3900
    
test

# Generated at 2022-06-12 07:14:59.868158
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-12 07:15:01.256178
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'hello world'



# Generated at 2022-06-12 07:15:02.286464
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") == "hello world"
# function shuffle

# Generated at 2022-06-12 07:15:03.476619
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .test.class_string_compressor_test import ClassStringCompressorTest
    ClassStringCompressorTest.test_compressor()



# Generated at 2022-06-12 07:15:07.397272
# Unit test for function booleanize
def test_booleanize():
  assert booleanize('true') == True
  assert booleanize('YES') == True
  assert booleanize('nope') == False

if __name__ == '__main__':
  # Unit test
  test_booleanize()

# Generated at 2022-06-12 07:15:13.686808
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'



# Generated at 2022-06-12 07:15:15.321183
# Unit test for function compress
def test_compress():
    s = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(s)
    decompressed = decompress(compressed)

    assert(decompressed == s)



# Generated at 2022-06-12 07:15:17.035838
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert hasattr(__RomanNumbers, '__init__')
    __RomanNumbers()


# Generated at 2022-06-12 07:15:28.151699
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # encode()
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode('1') == 'I'
    assert __RomanNumbers.encode('3') == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode('9') == 'IX'
    assert __RomanNumbers.encode(39) == 'XXXIX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(49) == 'XLIX'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'


# Generated at 2022-06-12 07:15:36.697178
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-12 07:15:41.517311
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14

# Generated at 2022-06-12 07:15:51.944249
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:53.597338
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    obj = __RomanNumbers()
    assert(isinstance(obj, __RomanNumbers))



# Generated at 2022-06-12 07:16:04.364470
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from nose.tools import assert_equal
    from nose.tools import assert_not_equal

    assert_equal(__StringFormatter('   test   ').format(), 'test')
    assert_equal(__StringFormatter('hello there,    how are you, to day ?').format(), 'Hello there, how are you, to day?')
    assert_equal(__StringFormatter('https://www.test.com/test').format(), 'https://www.test.com/test')
    assert_equal(__StringFormatter('https://www.test.com/test').format(), 'https://www.test.com/test')
    assert_equal(__StringFormatter('Hello there, I think j.      bond is a good guy').format(), 'Hello there, I think J. Bond is a good guy')

# Generated at 2022-06-12 07:16:15.927211
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('<p>test</p>') == ''
    assert strip_html('<p>test</p><p>ing</p>') == ''
    assert strip_html('<p>test</p><p>ing</p>', keep_tag_content=True) == 'testing'
    assert strip_html('<p>te<a href="foo/bar">st</a></p>') == '<a href="foo/bar"></a>'
    assert strip_html('<p>test<a href="foo/bar">ing</a></p>') == '<a href="foo/bar"></a>'

# Generated at 2022-06-12 07:16:19.952368
# Unit test for function shuffle
def test_shuffle():
    # Test case 01
    print('Test case #01')
    print('Input: hello world')
    print('Expected: a unique shuffled string')
    print('Actual:   {}'.format(shuffle('hello world')))
    print()

    # Test case 02
    print('Test case #02')
    print('Input: 0123456789')
    print('Expected: a unique shuffled string')
    print('Actual:   {}'.format(shuffle('0123456789')))
    print()

    # Test case 03
    print('Test case #03')
    print('Input: example string')
    print('Expected: a unique shuffled string')
    print('Actual:   {}'.format(shuffle('example string')))
    print()

    # Test case 04

# Generated at 2022-06-12 07:16:21.713628
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('') == ''
    assert asciify(1) == ''



# Generated at 2022-06-12 07:16:26.195246
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!')=='top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët')=='monster-magnet'
# test_slugify()



# Generated at 2022-06-12 07:16:30.286314
# Unit test for function asciify
def test_asciify():
    print(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË"))
    print(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓËé"))
    print(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓËéè"))
    print(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓËéèé"))

# Generated at 2022-06-12 07:16:51.967445
# Unit test for function prettify
def test_prettify():
    # Testing some common cases
    assert prettify("This is a test") == "This is a test"
    assert prettify("This is a test.") == "This is a test."
    assert prettify("This is a test? I don't think so!") == "This is a test? I don't think so!"
    assert prettify("I'll be back in 5 minutes.") == "I'll be back in 5 minutes."
    assert prettify("\"I'll be back in 5 minutes.\"") == "\"I'll be back in 5 minutes.\""
    assert prettify("This is a Yes/No question, isn't it?") == "This is a Yes/No question, isn't it?"

# Generated at 2022-06-12 07:17:02.045947
# Unit test for function prettify

# Generated at 2022-06-12 07:17:10.918569
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(13) == 'XIII'
    assert __RomanNumbers.encode(14) == 'XIV'
    assert __RomanNumbers.encode(15) == 'XV'
    assert __RomanNumbers.encode(18) == 'XVIII'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(23) == 'XXIII'
   

# Generated at 2022-06-12 07:17:22.756852
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('True') == True
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('False') == False
    assert booleanize('t') == True
    assert booleanize('T') == True
    assert booleanize('f') == False
    assert booleanize('F') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('Nope') == False
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('n') == False

# Generated at 2022-06-12 07:17:28.382672
# Unit test for function prettify
def test_prettify():
    assert prettify(' Hello     world ') == 'Hello world'
    assert prettify(' Hello world, how are you?') == 'Hello world, how are you?'
    assert prettify(' Hello World, How Are You?') == 'Hello World, How Are You?'
    assert prettify(' Hello        \n\n  World, !    \nHow Are You?') == 'Hello World, ! How Are You?'
    assert prettify(' Hello World, ! How Are You?') == 'Hello World, ! How Are You?'
    assert prettify('unprettified string ,, like this one,will be"prettified" .it\\'
                    's awesome!') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

# Generated at 2022-06-12 07:17:29.700697
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:17:31.157164
# Unit test for function decompress
def test_decompress():
    input_string='test'
    encoding='utf-8'
    decompress(input_string, encoding)
    #assert decompress(input_string, encoding) == 'test'


# Generated at 2022-06-12 07:17:33.501581
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
# test function call
test_reverse()



# Generated at 2022-06-12 07:17:35.676389
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:17:37.414473
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    if camel_case_to_snake('CamelCaseString') != 'camel_case_string':
        print('camel_case_to_snake() failed')



# Generated at 2022-06-12 07:17:57.068744
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") in ["l wodheorll","l wroholeld","lloworh del", "loorld hwle", "o wdlloerhl", "o delhlrwol", "lwlheodorl", "orlwl hlode", "w delorlhlo", "owle ldhrlo", "hwrodd elol", "rldo llewh", "wrd eolollh", "dewolrh ll", "eooodlr wlh", "lhderl loow", "llwoe hdlor", "d lhwrleloo"]
    assert shuffle("hello world") != "hello world"
test_shuffle()


# Generated at 2022-06-12 07:18:08.283335
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("I") == 1
    assert roman_decode("V") == 5
    assert roman_decode("X") == 10
    assert roman_decode("L") == 50
    assert roman_decode("C") == 100
    assert roman_decode("D") == 500
    assert roman_decode("M") == 1000
    assert roman_decode("CD") == 400
    assert roman_decode("IV") == 4
    assert roman_decode("IX") == 9
    assert roman_decode("XL") == 40
    assert roman_decode("XC") == 90
    assert roman_decode("CM") == 900
    assert roman_decode("") == 0
    assert roman_decode("IIII") == 4
    assert r

# Generated at 2022-06-12 07:18:11.580487
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:18:13.974276
# Unit test for function reverse
def test_reverse():
    test = "abc123"
    assert reverse(test) == "321cba"


# Generated at 2022-06-12 07:18:16.212147
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    sc = __StringCompressor()
    assert sc is not None

# PUBLIC API


# Generated at 2022-06-12 07:18:17.634978
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
# Test function
test_camel_case_to_snake()



# Generated at 2022-06-12 07:18:23.485842
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'


# Generated at 2022-06-12 07:18:30.104745
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'this is a test'

    # encode/compress/decode/decompress input
    encoded = __StringCompressor.compress(input_string)
    decoded = __StringCompressor.decompress(encoded)

    assert decoded == input_string


# PUBLIC API



# Generated at 2022-06-12 07:18:31.130618
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'hello'
    assert shuffle('a') == 'a'
    assert shuffle('') == ''



# Generated at 2022-06-12 07:18:34.159604
# Unit test for function compress
def test_compress():
    compressed = compress('')
    assert compressed is None
    count = 0
    for string in ["1", "net", "testing", "testnet"]:
        newS = compress(string)
        if (decompress(newS) != string):
            count += 1
    assert count == 0



# Generated at 2022-06-12 07:19:03.248945
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'test' == snake_case_to_camel('test')
    assert 'notValid' == snake_case_to_camel('not_valid')
    assert 'ThisIsASnakeCaseTest' == snake_case_to_camel('this_is_a_snake_case_test')
    assert 'ThisIsASnakeCaseTest' == snake_case_to_camel('this_is_a_snake_case_test')
    assert 'thisIsASnakeCaseTest' == snake_case_to_camel('this_is_a_snake_case_test', upper_case_first=False)
    assert 'InDiaNaiL' == snake_case_to_camel('india_nai_l', separator='-')
    assert 'InDiaNaiL' == snake_case

# Generated at 2022-06-12 07:19:04.738641
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.__module__ == 'pytool_collection.string_tool'


# Generated at 2022-06-12 07:19:06.519997
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('test').__init__('test') == None


# Generated at 2022-06-12 07:19:07.908351
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-12 07:19:13.945432
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("XXV") == 25
    assert roman_decode("I") == 1
    assert roman_decode("MMMCDXLI") == 3341
    assert roman_decode("MCMXCIX") == 1999
    assert roman_decode("MMMMCMXCIX") == 4999
    assert roman_decode("D") == 500
    assert roman_decode("MMMDCCCLXXXVIII") == 3888
    assert roman_decode("MMMCM") == 3900
    assert roman_decode("MMCDXCVIII") == 2498
    try:
        roman_decode("XXC")
    except InvalidRomanNumeralError:
        pass
    else:
        assert False, "Should raise InvalidRomanNumeralError"

# Generated at 2022-06-12 07:19:18.068238
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '+') == 'this+is+a+camel+string+test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='+') == 'this+is+a+camel+string+test'



# Generated at 2022-06-12 07:19:21.470575
# Unit test for function prettify
def test_prettify():
    INPUT_STRING = 'prettify. test, this string (\"now\")'
    EXPECTED_STRING = 'Prettify. Test, this string ("now")'
    assert prettify(INPUT_STRING) == EXPECTED_STRING

test_prettify()



# Generated at 2022-06-12 07:19:33.924805
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # test function snake_case_to_camel
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('a_green_snake', upper_case_first=False) == 'aGreenSnake'
    assert snake_case_to_camel('a-green-snake', separator='-') == 'AGreenSnake'
    assert snake_case_to_camel('a green snake') == 'a green snake'
    assert snake_case_to_camel('TheSnakeIsGreen') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green_') == 'TheSnakeIsGreen'

# Generated at 2022-06-12 07:19:38.312877
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-12 07:19:40.512149
# Unit test for function strip_margin
def test_strip_margin():
    string = '''
    line 1
      line 2
      line 3
    '''
    stripped = strip_margin(string)

    assert stripped.startswith('line 1')



# Generated at 2022-06-12 07:20:06.479471
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = "the_snake_is_green"
    output = snake_case_to_camel(input_string)
    # The first letter of the output should be uppercase
    assert output[0].isupper()
    # The first letter of the input string should be lowercase because we don't specify
    assert input_string[0].islower()
    assert output == "TheSnakeIsGreen"


# Generated at 2022-06-12 07:20:11.725222
# Unit test for function strip_html
def test_strip_html():
    html_code = '<a href="https://www.google.com">Google</a><br>'
    expected_result1 = 'Google'
    expected_result2 = 'Google<br>'
    assert strip_html(html_code) == expected_result1
    assert strip_html(html_code, keep_tag_content=True) == expected_result2



# Generated at 2022-06-12 07:20:21.916991
# Unit test for function compress
def test_compress():
    def compress_test(input_string, expected, encoding='utf-8', compression_level=9):
        compressed = compress(input_string, encoding, compression_level)
        assert compressed == expected, "Error for input_string=%s, encoding=%s, compression_level=%s: Expected %s, got %s" % \
                                       (input_string, encoding, compression_level, expected, compressed)

    compress_test(
        ' '.join(['word n{}'.format(n) for n in range(20)]),
        'eJzLL9YK0lLUcrsvMzW0sy8xMyw0zDTSKc/PTEzLT8AAQAAhQ==')
    compress_test(
        'lol',
        'eJwF7AP/Ng==')
   

# Generated at 2022-06-12 07:20:22.550388
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    pass

# Generated at 2022-06-12 07:20:24.692873
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'



# Generated at 2022-06-12 07:20:36.798146
# Unit test for function asciify

# Generated at 2022-06-12 07:20:46.369277
# Unit test for function prettify
def test_prettify():
    def test_case(original_string, expected):
        output = prettify(original_string)
        if output == expected:
            print('Test passed')
        else:
            print('Test failed')
            print('Input: "' + original_string + '"')
            print('Expected: "' + expected + '"')
            print('Output: "' + output + '"')
    test_case('   The house of Jack  "  is on "   fire. it\'s  burning! The   alarm    has been  sounded  .  ',
              'The house of Jack "is on" fire. It\'s burning! The alarm has been sounded.')

# Generated at 2022-06-12 07:20:50.651279
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh', '"hello" is not successfully reversed'


# Generated at 2022-06-12 07:20:55.031349
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:20:57.416955
# Unit test for function slugify
def test_slugify():
    assert 'top-10-reasons-to-love-dogs' == slugify('Top 10 Reasons To Love Dogs!!!')
    assert 'monster-magnet' == slugify('Mönstér Mägnët')

