

# Generated at 2022-06-12 07:12:57.284315
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:02.944286
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', '-') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:13:12.446727
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test for default parameters
    assert snake_case_to_camel('a_snake_is_small') == 'ASnakeIsSmall'
    # Test when upper_case_first is set to False
    assert snake_case_to_camel('a_snake_is_small', upper_case_first=False) == 'aSnakeIsSmall'
    # Test when separator is set to hyphen instead of underscore
    assert snake_case_to_camel('a-snake-is-small', separator='-') == 'ASnakeIsSmall'
    # Test when separator is set to pipe instead of underscore
    assert snake_case_to_camel('a|snake|is|small', separator='|') == 'ASnakeIsSmall'
    # Test when the input string is not a snake case string

# Generated at 2022-06-12 07:13:17.325526
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('camel_snake_pig_cow') == 'CamelSnakePigCow'
    assert snake_case_to_camel('camel_snake_pig_cow', upper_case_first=False) == 'camelSnakePigCow'
    assert snake_case_to_camel('camel_snake_pig_cow', upper_case_first=True, separator='-') == 'CamelSnakePigCow'

    assert snake_case_to_camel('camel_snake_pig_cow') != 'camelSnakePigCow'
    assert snake_case_to_camel('camel_snake_pig_cow') != 'CamelSnakePigCow'

# Generated at 2022-06-12 07:13:28.802088
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('nope') == 'Nope'
    assert snake_case_to_camel('nope', False) == 'nope'
    assert snake_case_to_camel('nope', False, '-') == 'nope'
    assert snake_case_to_camel('the-snake-is-green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False) == 'theSnakeIsGreen'


# Generated at 2022-06-12 07:13:37.344090
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen', separator='') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen', upper_case_first=False, separator='') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:48.775029
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:58.609145
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    assert __StringFormatter('a b c.d,e').format() == 'A b c.D,e'
    assert __StringFormatter('a b c d.e,f,g').format() == 'A b c d.E,f,g'
    assert __StringFormatter('a.b-c,d  e').format() == 'A.b-c,d e'
    assert __StringFormatter('  a b-c.d  ').format() == 'A b-c.D'
    assert __StringFormatter('a b-c.d ').format() == 'A b-c.D'
    assert __StringFormatter('http://foo.bar.com').format() == 'Http://foo.bar.com'
    assert __StringFormatter('http://foo.bar.com:80/index.html').format

# Generated at 2022-06-12 07:14:10.701153
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world') == "HelloWorld"
    assert snake_case_to_camel('hello_world', upper_case_first=False) == "helloWorld"
    assert snake_case_to_camel('hello_world', upper_case_first=True, separator='-') == "HelloWorld"
    assert snake_case_to_camel('', upper_case_first=True, separator='-') == ""
    assert snake_case_to_camel('', upper_case_first=False, separator='-') == ""
    assert snake_case_to_camel('hello-world', upper_case_first=False, separator='-') == "helloWorld"

# Generated at 2022-06-12 07:14:14.605093
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('test for unit testing of class StringFormatter')
    assert string_formatter.format() == 'Test for unit testing of class StringFormatter'
    print('test___StringFormatter_format passed')



# Generated at 2022-06-12 07:14:19.736245
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen"



# Generated at 2022-06-12 07:14:24.707823
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('  test  ').format() == 'test'
    assert __StringFormatter('test    test  ').format() == 'test test'
    assert __StringFormatter('  test  test    test    ').format() == 'test test test'
    assert __StringFormatter('tEst tEst TeSt TeSt TeSt teSt').format() == 'Test test test test test test'
    assert __StringFormatter('test,test').format() == 'test,test'
    assert __StringFormatter('test,test test').format() == 'test,test test'
    assert __StringFormatter('test,test test test').format() == 'test,test test test'

# Generated at 2022-06-12 07:14:36.840095
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert(snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green')
    assert(snake_case_to_camel('TheSnakeIsGreen', upper_case_first=False) == 'TheSnakeIsGreen')
    assert(snake_case_to_camel(' the_snake_is_green ') == 'TheSnakeIsGreen')


# Generated at 2022-06-12 07:14:40.446012
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '_') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:14:42.721871
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:14:53.959155
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # TEST No.1
    # INPUT:
    # TITLE:    'multiple spaces/tabs/new-lines'
    #          'INPUT STRING'
    # EXPECTED: 'Input String'
    input_string = '    multiple spaces/tabs/new-lines\t\r\nINPUT STRING'
    expected = 'Input String'
    sf = __StringFormatter(input_string)
    out = sf.format()
    assert out == expected

    # TEST No.2
    # INPUT:
    # TITLE:    'Uppercase first letter'
    #          'input string'
    # EXPECTED: 'Input string'
    input_string = 'input string'
    expected = 'Input string'
    sf = __StringFormatter(input_string)
    out = s

# Generated at 2022-06-12 07:15:06.091346
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test') == 'test'
    assert snake_case_to_camel('test', upper_case_first=False) == 'test'
    assert snake_case_to_camel('test_test') == 'TestTest'
    assert snake_case_to_camel('test_test', upper_case_first=False) == 'testTest'
    assert snake_case_to_camel('Test_test') == 'TestTest'
    assert snake_case_to_camel('Test_test', upper_case_first=False) == 'testTest'
    assert snake_case_to_camel('test_test', separator='-') == 'TestTest'

# Generated at 2022-06-12 07:15:08.704690
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('hello_what_s_up', False) == 'helloWhatSUp'
    assert snake_case_to_camel('a_snake_with_dashes', True, '-') == 'ASnakeWithDashes'


# Generated at 2022-06-12 07:15:10.886758
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input = 'the_snake_is_green'
    output = 'TheSnakeIsGreen'

    assert snake_case_to_camel(input) == output



# Generated at 2022-06-12 07:15:18.659925
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('abc').format() == 'Abc'
    assert __StringFormatter('abC').format() == 'Ab c'
    assert __StringFormatter('ABc').format() == 'ABc'
    assert __StringFormatter('Abc').format() == 'Abc'
    assert __StringFormatter('Abc def').format() == 'Abc def'
    assert __StringFormatter('ABc DEF').format() == 'ABc DEF'
    assert __StringFormatter('ABc DEF efg').format() == 'ABc DEF Efg'
    assert __StringFormatter('A_bC-D E-F G').format() == 'A bC-D E-F G'

# Generated at 2022-06-12 07:15:25.760220
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # example input for function
    input_string = 'the_snake_is_green'
    # expected output from function
    output = 'TheSnakeIsGreen'
    # execute function
    assert snake_case_to_camel(input_string) == output



# Generated at 2022-06-12 07:15:35.515359
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-12 07:15:40.277976
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Upper case first test
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    # Lower case first test
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    # Custom separator test
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:15:44.441937
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_snake_case') == 'ASnakeCase'
    assert snake_case_to_camel('a_snake_case', False) == 'aSnakeCase'
    assert snake_case_to_camel('a_snake_case', True, '-') == 'ASnake-Case'
    assert snake_case_to_camel('a_snake_case', False, '-') == 'aSnake-Case'
    assert snake_case_to_camel('a_snake_case', False, '-') == 'aSnake-Case'



# Generated at 2022-06-12 07:15:52.491684
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    if snake_case_to_camel("the_snake_is_green") != "TheSnakeIsGreen":
        raise Exception("wrong output")
    if snake_case_to_camel("the_snake_is_green", False) != "theSnakeIsGreen":
        raise Exception("wrong output")
    if snake_case_to_camel("snake_is_green", separator="_") != "SnakeIsGreen":
        raise Exception("wrong output")
    if snake_case_to_camel("theSnakeIsGreen") == "TheSnakeIsGreen":
        raise Exception("wrong output")



# Generated at 2022-06-12 07:16:01.133496
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('foo')
    assert sf.format() == 'Foo'

    sf = __StringFormatter(' foo')
    assert sf.format() == 'Foo'

    sf = __StringFormatter('foo ')
    assert sf.format() == 'Foo'

    sf = __StringFormatter(' fOo ')
    assert sf.format() == 'Foo'

    sf = __StringFormatter('S.P.A.    ')
    assert sf.format() == 'S.p.a.'

    sf = __StringFormatter('S.P.A.foo  ')
    assert sf.format() == 'S.p.a. Foo'

    sf = __StringFormatter('foo-bar')

# Generated at 2022-06-12 07:16:11.837506
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    INVALID_INPUTS = [1, 1.1, True, None]

# Generated at 2022-06-12 07:16:22.115294
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Testing lowercase first letter
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen', 'Lowercase works'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green', 'Lowercase works with - separator'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator=' ') == 'the snake is green', 'Lowercase works with space separator'
    assert snake_case_to_camel('theSnakeIsGreen', upper_case_first=False) == 'theSnakeIsGreen', 'Lowercase works without separator'
    assert snake_case_

# Generated at 2022-06-12 07:16:33.539682
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' hello,  world  ').format() == 'Hello, world'
    assert __StringFormatter('@helloWorld').format() == '@helloWorld'
    assert __StringFormatter('A123456B').format() == 'A123456B'
    assert __StringFormatter('A1a2b3c4D').format() == 'A1A2B3C4D'
    assert __StringFormatter('hello.world@gmail.com').format() == 'hello.world@gmail.com'
    assert __StringFormatter('hello world@myemail.com').format() == 'hello world@myemail.com'
    assert __StringFormatter('stackoverflow.com').format() == 'stackoverflow.com'

# Generated at 2022-06-12 07:16:36.134500
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    out = snake_case_to_camel('lorem')
    assert out == 'Lorem'
    return out

# Generated at 2022-06-12 07:16:46.201899
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('helloWorld') == 'hello_world'
    assert camel_case_to_snake('helloworld') == 'helloworld'
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('hELLO') == 'h_e_l_l_o'

# Generated at 2022-06-12 07:16:49.791586
# Unit test for function reverse
def test_reverse():
    # given
    s = 'hello'
    # when
    result = reverse(s)
    # then
    assert result == 'olleh'


# Generated at 2022-06-12 07:16:51.557297
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert isinstance(__StringFormatter(""), __StringFormatter)


# Generated at 2022-06-12 07:16:54.212881
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-12 07:16:56.164114
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = __StringFormatter('this is a double-double string with underscores')
    return isinstance(s, __StringFormatter)


# Generated at 2022-06-12 07:16:59.313981
# Unit test for function prettify

# Generated at 2022-06-12 07:17:00.922912
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('Hello') == 'olleH'



# Generated at 2022-06-12 07:17:03.248157
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello, world!') != 'hello, world!'
    assert len(shuffle('hello, world!')) == len('hello, world!')



# Generated at 2022-06-12 07:17:07.107972
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    test_string = 'ThisIsACamelStringTest'
    expected_string = 'this_is_a_camel_string_test'
    assert camel_case_to_snake(test_string) == expected_string
# Test function camel_case_to_snake
test_camel_case_to_snake()



# Generated at 2022-06-12 07:17:10.630681
# Unit test for function strip_margin
def test_strip_margin():
    sample = strip_margin('''
    |line 1
    |line2
    ''')
    assert sample == 'line 1\nline2'



# Generated at 2022-06-12 07:17:18.583216
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ÑÓË') == 'NOE'


# Generated at 2022-06-12 07:17:21.488617
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    try:
        __StringCompressor()
    except Exception as e:
        pass
    else:
        assert False, 'Expected __StringCompressor to have a private constructor'


# PUBLIC API



# Generated at 2022-06-12 07:17:24.334542
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
        line 1
        line 2
        line 3
    '''
    out = strip_margin(input_string)
    expected = '''
line 1
line 2
line 3
'''
    assert out == expected, 'assertion failed'

# Generated at 2022-06-12 07:17:25.969717
# Unit test for function roman_encode
def test_roman_encode():
    """
    Tests for function roman_encode
    """
    assert roman_encode(2) == 'II'

# Generated at 2022-06-12 07:17:38.453883
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .test_helper import assert_equals


# Generated at 2022-06-12 07:17:46.593099
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('1') == True
    assert booleanize('nope') == False
    assert booleanize('False') == False
    assert booleanize('no') == False
    assert booleanize('0') == False

if __name__ == "__main__":
    test_booleanize()
    # print("Test passed")

# Generated at 2022-06-12 07:17:57.558687
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    class __RomanNumbersTest:
        def __init__(self, testcase_name, value, expected):
            self.value = value
            self.expected = expected
            self.testcase_name = testcase_name

        def run(self):
            encode_result = __RomanNumbers.encode(self.value)
            decode_result = __RomanNumbers.decode(self.expected)
            assert encode_result == self.expected
            assert decode_result == self.value, 'Decode failed for value {}'.format(
                self.value)


# Generated at 2022-06-12 07:18:01.553385
# Unit test for function decompress
def test_decompress():
    assert decompress('eJwLwTENACAIBtIfATzm-kWt9gKjEiTtTg=') == ''.join(['word n{}'.format(n) for n in range(20)])

# Generated at 2022-06-12 07:18:05.562112
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('1')) == '1'
    assert decompress(compress('12345')) == '12345'
    assert decompress(compress('1234567890')) == '1234567890'
    assert decompress(compress('1 2 3 4 5 6 7 8 9 0')) == '1 2 3 4 5 6 7 8 9 0'
    assert decompress(compress('1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0')) \
        == '1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0'

# Generated at 2022-06-12 07:18:08.558258
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter('    this is a test string  ')
    result = formatter.format()
    assert result == 'This is a test string'


# PUBLIC API

# Generated at 2022-06-12 07:18:24.633476
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(4) == 'IV'
    assert roman_encode(1954) == 'MCMLIV'
    assert roman_encode(1990) == 'MCMXC'
    assert roman_encode(2014) == 'MMXIV'
    assert roman_encode(400) == 'CD'
    assert roman_encode(900) == 'CM'
    assert roman_encode(40) == 'XL'
    assert roman_encode(90) == 'XC'



# Generated at 2022-06-12 07:18:31.862493
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('this_is_another_test', True, ' ') == 'ThisIsAnotherTest'



# Generated at 2022-06-12 07:18:34.412776
# Unit test for function shuffle
def test_shuffle():
    input = 'hello world'
    output = shuffle(input)

    assert(len(output) == len(input))
    assert(input != output)



# Generated at 2022-06-12 07:18:39.688225
# Unit test for function strip_margin
def test_strip_margin():
    test_string = '''


                line 1
                line 2
                line 3
                '''
    result_string = '''


line 1
line 2
line 3
            '''
    assert strip_margin(test_string) == result_string

test_strip_margin()

# Generated at 2022-06-12 07:18:42.145243
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '



# Generated at 2022-06-12 07:18:45.549160
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert len(shuffle('hello world')) == len('hello world')
    assert shuffle('hello world').split() == 'hello world'.split()

test_shuffle()
shuffle('hello world')


# Generated at 2022-06-12 07:18:48.843251
# Unit test for function shuffle
def test_shuffle():
    test_array = []

    for i in range(0, 10):
        test_array.append(shuffle('hello world'))

    assert test_array == ['lllhedorow','wllleoohd','elohowdrl','lwhoreodl','olwdlhroe','eohldorwl','wlloerohd','wolrlehod','owrleohdl','rdlohloew']

test_shuffle()

# Generated at 2022-06-12 07:19:00.000684
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str = __StringFormatter('hello').format()
    assert str == 'hello'

    str = __StringFormatter(' hello ').format()
    assert str == 'hello'

    str = __StringFormatter(' hello world ').format()
    assert str == 'hello world'

    str = __StringFormatter(' hello world ').format()
    assert str == 'hello world'

    str = __StringFormatter('Hello world').format()
    assert str == 'Hello world'

    str = __StringFormatter('helloWorld').format()
    assert str == 'Hello world'

    str = __StringFormatter('hello world // ...').format()
    assert str == 'Hello world...'

    str = __StringFormatter('HELLO world').format()
    assert str == 'Hello world'


# Generated at 2022-06-12 07:19:08.654536
# Unit test for function snake_case_to_camel

# Generated at 2022-06-12 07:19:16.942114
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman