

# Generated at 2022-06-12 07:12:42.123800
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    
    assert not is_empty_string(snake_case_to_camel('the_snake_is_green', True,'_'))
    assert snake_case_to_camel('the_snake_is_green', True,'_') == 'TheSnakeIsGreen'
    assert not is_empty_string(snake_case_to_camel('the_snake_is_green', False,'_'))
    assert snake_case_to_camel('the_snake_is_green', False,'_') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:12:54.191876
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green')
    assert 'TheSnakeIsGreen' == snake_case_to_camel('The_Snake_is_Green')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=False)
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the-snake-is-green', separator='-')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-')



# Generated at 2022-06-12 07:12:58.957016
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello') == 'Hello'
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', upper_case_first=False) == 'helloWorld'



# Generated at 2022-06-12 07:13:00.910202
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green')



# Generated at 2022-06-12 07:13:09.865042
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert(snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen')
    assert(snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', False, separator='-') == 'theSnakeIsGreen')
    assert(snake_case_to_camel('the_snake_is_green', False, separator='-') == 'theSnakeIsGreen')
    assert(snake_case_to_camel('the snake is green') == 'TheSnakeIsGreen')

# Generated at 2022-06-12 07:13:20.786747
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_string', False) == 'thisisasnakestring'
    assert snake_case_to_camel('THIS_IS_ANOTHER_SNAKE_STRING') == 'ThisIsAnotherSnakeString'
    assert snake_case_to_camel('this_is_an_all_lower_case_string') == 'ThisIsAnAllLowerCaseString'
    assert snake_case_to_camel('this_is_an_all_upper_case_string') == 'ThisIsAnAllUpperCaseString'
    assert snake_case_to_camel('this_is_a_mixed_case_string') == 'ThisIsAMixedCaseString'

# Generated at 2022-06-12 07:13:25.050108
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen') == 'TheSnakeIsGreen'



# Generated at 2022-06-12 07:13:31.933936
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-12 07:13:42.603130
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a_b_c') == 'ABC', \
        'Test 1: Expected ABC, but got: {}'.format(snake_case_to_camel('a_b_c'))
    assert snake_case_to_camel('a_b_c', upper_case_first=False) == 'aBC', \
        'Test 1: Expected aBC, but got: {}'.format(snake_case_to_camel('a_b_c', upper_case_first=False))
    assert snake_case_to_camel('a_b_c', separator='-') == 'ABC', \
        'Test 1: Expected ABC, but got: {}'.format(snake_case_to_camel('a_b_c', separator='-'))

# Generated at 2022-06-12 07:13:49.509165
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-Snake-Is-Green'
    assert snake_case_to_camel('foo') == 'Foo'
