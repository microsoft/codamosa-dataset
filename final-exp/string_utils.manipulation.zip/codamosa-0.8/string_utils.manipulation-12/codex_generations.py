

# Generated at 2022-06-12 07:12:43.123706
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('  TESt  sTaRTiNG    foo     and      ending   foo    ')
    assert sf.format() == 'Test starting foo and ending foo'

    sf = __StringFormatter('Lorem ipsum dolor sit AMET, consectetur adipiscing elit')
    assert sf.format() == 'Lorem ipsum dolor sit Amet, consectetur adipiscing elit'

    sf = __StringFormatter('test@testmail.com')
    assert sf.format() == 'test@testmail.com'

    sf = __StringFormatter('this http://www.test.com is a test')
    assert sf.format() == 'this http://www.test.com is a test'


# Generated at 2022-06-12 07:12:55.703631
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!').format() != 'hello world!'
    assert __StringFormatter('hello  world!').format() != 'hello  world!'
    assert __StringFormatter('hello -- world!').format() != 'hello -- world!'
    assert __StringFormatter('hello -- world!').format() == 'Hello -- world!'
    assert __StringFormatter('hello—world!').format() == 'Hello—world!'
    assert __StringFormatter('hello—world!').format() != 'hello—world!'
    assert __StringFormatter('hello ,world!').format() == 'Hello, world!'
    assert __StringFormatter('hello ,world!').format() != 'hello ,world!'
    assert __StringFormatter('hello, world! ').format

# Generated at 2022-06-12 07:13:06.526763
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import random
    import unittest
    import warnings

    class StringFormatterUnitTests(unittest.TestCase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.__messages = {
                'invalid_input': 'Invalid input',
                'incorrect_output': 'Invalid output, expected "{expected}", got "{output}"'
            }

        def __assertEqualAndRaiseMessage(self, expected, output):
            return self.assertEqual(expected, output, self.__messages['incorrect_output'].format(expected=expected, output=output))


# Generated at 2022-06-12 07:13:14.485409
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('   this is MY text and my EMAIL is fF@fff.com   and my website is http://www.my-domain.com')
    result = string_formatter.format()
    assert result == 'This is my text and my email is fF@fff.com and my website is http://www.my-domain.com'


# PUBLIC API



# Generated at 2022-06-12 07:13:26.807287
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:34.515411
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('test test').format() == 'test test'
    assert __StringFormatter('test  test').format() == 'test test'
    assert __StringFormatter('t e s t  test').format() == 't e s t test'
    assert __StringFormatter('test test ').format() == 'test test'
    assert __StringFormatter(' test test').format() == 'test test'
    assert __StringFormatter(' test test ').format() == 'test test'
    assert __StringFormatter('test test test').format() == 'test test test'
    assert __StringFormatter('test test  test').format() == 'test test test'

# Generated at 2022-06-12 07:13:43.379828
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:13:51.828921
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:02.496034
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Test test test').format() == 'Test test test'
    assert __StringFormatter('TestTestTest').format() == 'Test test test'
    assert __StringFormatter('Test test test.').format() == 'Test test test.'
    assert __StringFormatter('Test test test.').format() == 'Test test test.'
    assert __StringFormatter('Test test test.').format() == 'Test test test.'
    assert __StringFormatter('Test test test test').format() == 'Test test test test'
    assert __StringFormatter('Test test test test ').format() == 'Test test test test'
    assert __StringFormatter('Test test test test test').format() == 'Test test test test test'
    assert __StringFormatter('Test test test test test ').format() == 'Test test test test test'

# Generated at 2022-06-12 07:14:14.473549
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:14:24.289162
# Unit test for function compress
def test_compress():
    # setup
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # execute
    compressed = compress(original)
    # assert
    assert original == decompress(compressed)



# Generated at 2022-06-12 07:14:27.917572
# Unit test for function slugify
def test_slugify():
  assert slugify('top 10 reasons to love dogs') == 'top-10-reasons-to-love-dogs'



# Generated at 2022-06-12 07:14:38.888183
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('THE_snake_is_gREEN') == 'THEsnakeisgREEN'
    assert snake_case_to_camel('THE_snake_is_gREEN', upper_case_first=False) == 'tHEsnakeisgREEN'
    assert snake_case_to_camel('THE_snake_is_gREEN', separator='-') == 'THE-snake-is-gREEN'

# Generated at 2022-06-12 07:14:41.703585
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    sf = __StringFormatter("a-a a b,c:d")
    sf.format()
    return True

# PUBLIC API



# Generated at 2022-06-12 07:14:46.692216
# Unit test for function decompress
def test_decompress():
    st = 'words: word n0 word n1 word n2 word n3 word n4 word n5 word n6 word n7 word n8 word n9 word n10 word n11 word n12 word n13 word n14 word n15 word n16 word n17 word n18 word n19'
    compressed = compress(st)
    result = decompress(compressed)
    assert st == result

test_decompress()



# Generated at 2022-06-12 07:14:50.550998
# Unit test for function prettify
def test_prettify():
    prettyfied_string = prettify(' unprettified string ,, like this one,will be"prettified" .it\'s awesome! ')
    assert prettyfied_string == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-12 07:14:58.750743
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # This function is not a standalone function, so it does not need a unit test.
    # It just calls the function that is in the regex module
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisisacamelstringtest') == 'thisisacamelstringtest'
    assert camel_case_to_snake('This') == 'this'
    assert camel_case_to_snake('tHIs') == 'th_is'



# Generated at 2022-06-12 07:15:01.910526
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('helllo') == 'ollleh'
    assert reverse('helllllo') == 'ollllleh'



# Generated at 2022-06-12 07:15:03.878945
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    compressed2 = compress(original)
    original2 = decompress(compressed)
    assert original == original2
    assert compressed == compressed2



# Generated at 2022-06-12 07:15:10.630155
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I', 'Unit test for static __RomanNumbers.encode() failed'
    assert __RomanNumbers.encode(2) == 'II', 'Unit test for static __RomanNumbers.encode() failed'
    assert __RomanNumbers.encode(3) == 'III', 'Unit test for static __RomanNumbers.encode() failed'
    assert __RomanNumbers.encode(4) == 'IV', 'Unit test for static __RomanNumbers.encode() failed'
    assert __RomanNumbers.encode(5) == 'V', 'Unit test for static __RomanNumbers.encode() failed'
    assert __RomanNumbers.encode(9) == 'IX', 'Unit test for static __RomanNumbers.encode() failed'

# Generated at 2022-06-12 07:15:20.920554
# Unit test for function strip_margin
def test_strip_margin():
    assert (
        strip_margin(
            '''
            |        line 1
            |        line 2
            |        line 3
            |''') == '''
            |line 1
            |line 2
            |line 3
            |''')

    assert (
        strip_margin("""
                    |        line 1
                    |        line 2
                    |        line 3
                    |""") == """
                    |line 1
                    |line 2
                    |line 3
                    |""")

    assert (
        strip_margin("""
        |        line 1
        |        line 2
        |            line 3
        |""") == """
        |line 1
        |line 2
            line 3
        |""")


if __name__ == '__main__':
    print("""
    input:
    |""")
    print

# Generated at 2022-06-12 07:15:22.873084
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse(123) == '321'



# Generated at 2022-06-12 07:15:25.159569
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(50)])
    compressed = compress(original)
    assert(compressed != original)
    assert(is_string(compressed))
    print("test_compress")
test_compress()


# Generated at 2022-06-12 07:15:28.780217
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñ') == 'eeuuooaaeyn'
    assert asciify('ÅÀÁÇÌÍÑÓË') == 'AAAACIINOE'

# public api

# Generated at 2022-06-12 07:15:31.793940
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("I") == 1
    assert roman_decode("V") == 5
    assert roman_decode("X") == 10
    assert roman_decode("L") == 50
    assert roman_decode("C") == 100
    assert roman_decode("D") == 500
    assert roman_decode("M") == 1000
    assert roman_decode("MMXVII") == 2017
    assert roman_decode("MMMCMXCIV") == 3994

# Generated at 2022-06-12 07:15:44.263704
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert is_string(__StringFormatter.__placeholder_key())
    assert __StringFormatter.__placeholder_key() != __StringFormatter.__placeholder_key()
    assert __StringFormatter('Hello World!').format() == 'Hello World!'
    assert __StringFormatter('I like      dogs    and  cats.').format() == 'I like dogs and cats.'
    assert __StringFormatter('  I like dogs  and   cats.   ').format() == 'I like dogs and cats.'
    assert __StringFormatter('I like dogs & cats.').format() == 'I like dogs & cats.'
    assert __StringFormatter('  I like      dogs    and  cats.  ').format() == 'I like dogs and cats.'

# Generated at 2022-06-12 07:15:47.282950
# Unit test for function asciify
def test_asciify():
    print(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË"))

test_asciify()


# Generated at 2022-06-12 07:15:51.187691
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print('original: %s' % original)
    print('compressed: %s' % compressed)



# Generated at 2022-06-12 07:15:58.942400
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(1, 3) == 'XXX'
    assert __RomanNumbers.__encode_digit(3, 1) == 'M'
    assert __RomanNumbers.__encode_digit(3, 2) == 'MM'

    assert __RomanNumbers.__index_for_sign('M') == 3
    assert __RomanNumbers.__index_for_sign('D') == 2
    assert __RomanNumbers.__index_for_sign('L') == 1
    assert __RomanNumbers.__index_for_sign('C') == 2

    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode('999')

# Generated at 2022-06-12 07:16:01.005047
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-12 07:16:13.755569
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('') == False

# Generated at 2022-06-12 07:16:15.562616
# Unit test for function decompress
def test_decompress():
    return __StringCompressor.test_decompress()



# Generated at 2022-06-12 07:16:24.942082
# Unit test for function prettify
def test_prettify():
    """
    Unit test for function prettify.
    """
    assert prettify("'a'") == "'a'"
    assert prettify("hello ") == "hello"
    assert prettify(" 'hello'") == "'hello'"
    assert prettify("'hello '") == "'hello'"
    assert prettify("  hello") == "hello"
    assert prettify("hello  ") == "hello"
    assert prettify("hello  this is\n    a test") == "hello this is a test"
    assert prettify("hello  this is\n    a test") == "hello this is a test"
    assert prettify("hello,world") == "hello, world"
    assert prettify("hello.world") == "hello. world"
    assert prettify("hello?world") == "hello? world"

# Generated at 2022-06-12 07:16:27.583959
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'ThisIsANewString' == snake_case_to_camel('this_is_a_new_string')
    assert 'thisIsANewString' == snake_case_to_camel('this_is_a_new_string', False)
    assert 'thisIsANewString' == snake_case_to_camel('this-is-a-new-string', False, '-')



# Generated at 2022-06-12 07:16:34.135181
# Unit test for function compress
def test_compress():
    if not is_string(input_string):
        raise InvalidInputError(input_string)

    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert original == decompress(compressed), "Compression Failed"


# Generated at 2022-06-12 07:16:41.666260
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    class__RomanNumbers = __RomanNumbers()
    assert class__RomanNumbers.__encode_digit(0, 1) == 'I'
    assert class__RomanNumbers.__encode_digit(0, 2) == 'II'
    assert class__RomanNumbers.__encode_digit(0, 3) == 'III'
    assert class__RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert class__RomanNumbers.__encode_digit(0, 5) == 'V'
    assert class__RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert class__RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert class__RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert class__RomanNumbers.__encode_

# Generated at 2022-06-12 07:16:46.251873
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # arrange
    input_string = 'let\'s test this class "constructor"'

    # act
    formatter = __StringFormatter(input_string)

    # assert
    assert formatter.input_string == input_string


# Generated at 2022-06-12 07:16:51.540298
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('a1') == 'I'
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    print('Test method "roman_encode" passed successfully.')

test_roman_encode()



# Generated at 2022-06-12 07:16:54.472675
# Unit test for function strip_margin
def test_strip_margin():

    result = strip_margin('''
        | line 1
        |  line 2
        |   line 3
    ''')
    assert result == '''
line 1
 line 2
  line 3
'''



# Generated at 2022-06-12 07:16:58.693610
# Unit test for function prettify