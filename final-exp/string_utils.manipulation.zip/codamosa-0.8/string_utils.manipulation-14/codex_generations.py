

# Generated at 2022-06-12 07:12:30.917805
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert ('ciao' == __StringFormatter('ciao').format())
    assert ('ciao' == __StringFormatter('   ciao    ').format())
    assert ('ciao mondo' == __StringFormatter('   ciao    mondo  ').format())
    assert ('ciao mondo' == __StringFormatter(' ciao mondo    ').format())
    assert ('ciao mondo' == __StringFormatter(' ciao  mondo    ').format())
    assert ('ciao mondo' == __StringFormatter(' ciao mondo ').format())
    assert ('ciao mondo' == __StringFormatter(' ciao mondo     ').format())
    assert ('ciao mondo' == __StringFormatter('     ciao mondo ').format())

# Generated at 2022-06-12 07:12:32.435011
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-12 07:12:36.352979
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('will_fail') == 'will_fail'
    assert snake_case_to_camel('hallo_welt') == 'HalloWelt'
    assert snake_case_to_camel('camel_case_to_snake') == 'CamelCaseToSnake'
    assert snake_case_to_camel('snake_case_to_camel') == 'SnakeCaseToCamel'
    assert snake_case_to_camel('the_snake_case_to_camel') == 'TheSnakeCaseToCamel'

# Generated at 2022-06-12 07:12:39.544211
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
test_camel_case_to_snake()



# Generated at 2022-06-12 07:12:50.496871
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("123dasd") == "123dasd"
    assert camel_case_to_snake("dasd123") == "dasd123"
    assert camel_case_to_snake("dasdDisd") == "dasd_disd"
    assert camel_case_to_snake("DasdDisd") == "dasd_disd"
    assert camel_case_to_snake("Dasd") == "dasd"
    assert camel_case_to_snake("Dasd123Disd") == "dasd123_disd"
    assert camel_case_to_snake("DasdDisd123") == "dasd_disd123"
    assert camel_case_to_snake("dasddisD")

# Generated at 2022-06-12 07:12:54.191842
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest')=='this_is_a_camel_string_test')
test_camel_case_to_snake()



# Generated at 2022-06-12 07:12:56.469558
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('InputString') == 'input_string'



# Generated at 2022-06-12 07:13:07.574030
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake(' thisIsACamelStringTest ') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest ') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake(' thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('THIS_IS_A_CAMEL_STRING_TEST')

# Generated at 2022-06-12 07:13:20.171923
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # given
    exp = 'Anil Jain'
    # and
    inp = 'Anil jain'

    # when
    out = __StringFormatter(inp).format()

    # then
    assert out == exp

    # given
    exp = 'Tomasz Jóżwiak'
    # and
    inp = 'Tomasz Jóżwiak'

    # when
    out = __StringFormatter(inp).format()

    # then
    assert out == exp

    # given
    exp = 'Tomasz Jóżwiak'
    # and
    inp = 'toMasz   jóźWiaK'

    # when
    out = __StringFormatter(inp).format()

    # then
    assert out == exp

    # given
    exp

# Generated at 2022-06-12 07:13:28.415601
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    input_string='ThisIsACamelStringTest'
    expected_string='this_is_a_camel_case_string_test'
    output_string=camel_case_to_snake(input_string) # returns 'this_is_a_camel_case_string_test'
    if output_string == expected_string:
        print("camel_case_to_snake function works fine")
    else:
        print("camel_case_to_snake function needs to be fixed")
test_camel_case_to_snake()



# Generated at 2022-06-12 07:13:43.751966
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test 1
    input_string = 'the_snake_is_green'
    expected_result = 'TheSnakeIsGreen'
    assert snake_case_to_camel(input_string) == expected_result, 'TEST 1 FAILED: ' + input_string + ' => ' + snake_case_to_camel(input_string) + ', expected: ' + expected_result

    # Test 2
    input_string = 'the snake is green'
    expected_result = 'TheSnakeIsGreen'
    assert snake_case_to_camel(input_string) == expected_result, 'TEST 2 FAILED: ' + input_string + ' => ' + snake_case_to_camel(input_string) + ', expected: ' + expected_result

    # Test 3

# Generated at 2022-06-12 07:13:51.364866
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_case_string') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('this_is_a_snake_case_string', upper_case_first=False) == 'thisIsASnakeCaseString'
    assert snake_case_to_camel('this-is-a-snake-case-string', separator='-') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('!') == '!'
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel(None) == None



# Generated at 2022-06-12 07:13:52.815764
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    pass


# PUBLIC API



# Generated at 2022-06-12 07:14:03.363057
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Tests for snake case to camel case conversion
    assert snake_case_to_camel('my_first_string') == 'MyFirstString'
    assert snake_case_to_camel('my-first-string') == 'MyFirstString'
    assert snake_case_to_camel('MyFirstString') == 'MyFirstString'
    assert snake_case_to_camel('my_first_string', upper_case_first=False) == 'myFirstString'
    assert snake_case_to_camel('my_first_string', separator='-') == 'MyFirstString'
    assert snake_case_to_camel('my-first-string', separator='-') == 'MyFirstString'
    assert snake_case_to_camel('my-first-string', separator='_') == 'MyFirstString'

# Generated at 2022-06-12 07:14:15.160848
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def _test(expected, input_string):
        assert expected == __StringFormatter(input_string).format()

    _test('Alfa', 'Alfa')
    _test('Alfa Bravo', 'ALFA BRAVO')
    _test('Alfa Bravo', 'ALFA  BRAVO')
    _test('Alfa Bravo', 'ALFA   BRAVO')
    _test('Alfa Bravo', 'alfa bravo')
    _test('Alfa Bravo', 'alfa  bravo')
    _test('Alfa Bravo', 'alfa   bravo')
    _test('Alfa Bravo', 'ALFA bRaVo')
    _test('Alfa Bravo', 'ALFA  bRaVo')
    _test('Alfa Bravo', 'ALFA   bRaVo')

# Generated at 2022-06-12 07:14:24.030698
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('lorem ipsum').format() == 'Lorem ipsum'
    assert __StringFormatter('what\'s this').format() == "What's this"
    assert __StringFormatter('hello, world!').format() == 'Hello, world!'
    assert __StringFormatter('lorem-ipsum').format() == 'Lorem-ipsum'
    assert __StringFormatter('what\'s this?').format() == "What's this?"
    assert __StringFormatter('hello (world)').format() == 'Hello (world)'
    assert __StringFormatter('lorem[ipsum]').format() == 'Lorem[ipsum]'

# Generated at 2022-06-12 07:14:36.931726
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('   this   is a simple test     with     some     spaces      ')
    assert s.format() == 'This is a simple test with some spaces'

    # always capitalize first letter
    s = __StringFormatter('   this   is a second simple test     with     some     spaces      ')
    assert s.format() == 'This is a second simple test with some spaces'

    # remove duplicates
    s = __StringFormatter('   this   is a  second  second  test     with     some     spaces      ')
    assert s.format() == 'This is a second test with some spaces'

    # ensure right space only
    s = __StringFormatter('   this   is a second simple test     with     some     spaces     and     no     left     space      ')

# Generated at 2022-06-12 07:14:46.364979
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # ensure conversion is successful
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'

    # ensure conversion is successful with lower case first letter
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'

    # ensure conversion is successful with a different separator
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'

    # ensure conversion is successful with lowered first letter and different separator
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

    # ensure original string is returned in case of invalid input

# Generated at 2022-06-12 07:14:54.257744
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:06.563106
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:15:18.638070
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter(' one two   three four  five  six   seven   eight     ')
    assert formatter.format() == 'One two three four five six seven eight'

    formatter = __StringFormatter('one , two , three,four,five, six,   seven,eight ')
    assert formatter.format() == 'One, two, three, four, five, six, seven, eight'

    formatter = __StringFormatter('one and two')
    assert formatter.format() == 'One and two'

    formatter = __StringFormatter('one; two/three:four?five[six]seven{eight}nine(ten)eleven-twelve')
    assert formatter.format() == 'One; two/three:four?five[six]seven{eight}nine(ten)eleven-twelve'



# Generated at 2022-06-12 07:15:30.453094
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("hello world").format() == "Hello world"
    assert __StringFormatter("hello   world").format() == "Hello world"
    assert __StringFormatter("HeLLo    WoRld").format() == "Hello world"
    assert __StringFormatter("Hello   World!").format() == "Hello world!"
    assert __StringFormatter("Hello   World? ").format() == "Hello world?"
    assert __StringFormatter("Hello   World? ").format() == "Hello world?"
    assert __StringFormatter("hello-world? ").format() == "Hello world?"
    assert __StringFormatter("hello-world ,is it me you are looking for?").format() == "Hello world, is it me you are looking for?"

# Generated at 2022-06-12 07:15:42.369068
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('This is a test').format() == 'This is a test'
    assert __StringFormatter(' string with spaces...  ').format() == 'string with spaces...'
    assert __StringFormatter('  string with spaces...  ').format() == 'string with spaces...'
    assert __StringFormatter('string with spaces...  ').format() == 'string with spaces...'
    assert __StringFormatter('string with spaces...  ').format() == 'string with spaces...'
    assert __StringFormatter('This is a (example).').format() == 'This is a (example).'
    assert __StringFormatter('This is a test')\
        .format() == 'This is a test'

# Generated at 2022-06-12 07:15:46.441206
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # arrange
    input_string = '!test_test test-test "test test" test test'

    # act
    output = __StringFormatter(input_string).format()

    # assert
    assert output == 'Test test Test test "Test test" test test'


# PUBLIC API



# Generated at 2022-06-12 07:15:56.337467
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print('Testing __StringFormatter.format')


# Generated at 2022-06-12 07:16:08.145476
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:18.089203
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:28.370513
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:16:37.422109
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Ciao a tutti, come va?').format() == 'Ciao a tutti, come va?'
    assert __StringFormatter('Ciao a tutti,  come va?').format() == 'Ciao a tutti, come va?'
    assert __StringFormatter(' Ciao a tutti, come va? ').format() == 'Ciao a tutti, come va?'
    assert __StringFormatter('Ciao a tutti, come va? ').format() == 'Ciao a tutti, come va?'
    assert __StringFormatter('  Ciao a tutti, come va?  ').format() == 'Ciao a tutti, come va?'
    assert __StringFormatter('  ciao a tutti, come va?  ').format() == 'Ciao a tutti, come va?'
    assert __String

# Generated at 2022-06-12 07:16:43.810794
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green_') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('_the_snake_is_green_') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-', upper_case_first=False) == 'theSnakeIsGreen'

# Generated at 2022-06-12 07:16:59.600434
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('')
    out = sf.format()
    assert out is not None
    assert out == ''

    sf = __StringFormatter(' ')
    out = sf.format()
    assert out is not None
    assert out == ''

    sf = __StringFormatter('    ')
    out = sf.format()
    assert out is not None
    assert out == ''

    sf = __StringFormatter('  hello  ')
    out = sf.format()
    assert out is not None
    assert out == 'Hello'

    sf = __StringFormatter('hello')
    out = sf.format()
    assert out is not None
    assert out == 'Hello'

    sf = __StringFormatter('Hello')
    out = sf.format()


# Generated at 2022-06-12 07:17:07.791208
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # Test 1
    input = 'abcdefghilmnopqrstuvzXYZ'
    expected = 'Abcdefghilmnopqrstuvz x y z'
    actual = __StringFormatter(input).format()
    assert actual == expected

    # Test 2
    input = 'aBc   deFgHILM noPQrSTUVZ xYz'
    expected = 'A Bc defg hilm no Pqr Stu Vz x y z'
    actual = __StringFormatter(input).format()
    assert actual == expected

    # Test 3
    input = 'aBc d eFgHILM noPQrSTUVZ xYz'
    expected = 'A Bc d efg hilm no Pqr Stu Vz x y z'

# Generated at 2022-06-12 07:17:16.131168
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    out = __StringFormatter('a b c d e f').format()
    assert out == 'A b c d e f'

    out = __StringFormatter(' a b c d e f').format()
    assert out == 'A b c d e f'

    out = __StringFormatter('\n\ta b c d e f ').format()
    assert out == 'A b c d e f'

    out = __StringFormatter('a b cc d ee fff').format()
    assert out == 'A b cc d ee fff'

    out = __StringFormatter('a b c, d e f').format()
    assert out == 'A b c, d e f'

    out = __StringFormatter('a b c; d e f').format()
    assert out == 'A b c; d e f'

   

# Generated at 2022-06-12 07:17:21.406441
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = '  abcd efg,  hijk- lmn   opqr stuv: wxyz, blah blah blah blah blah blah blah blah blah blah blah blah blah blah'
    assert __StringFormatter(s).format() == 'Abcd efg, hijk - lmn opqr stuv: wxyz, blah blah blah blah blah blah blah blah blah blah blah blah blah blah'


# Generated at 2022-06-12 07:17:28.484138
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:17:39.412238
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # given
    f = __StringFormatter

# Generated at 2022-06-12 07:17:49.171458
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_format = __StringFormatter.format

    # test multiple cases of upper case first letter
    assert test_format('john doe') == 'John Doe'
    assert test_format('john-doe') == 'John-Doe'
    assert test_format('JOHN DOE') == 'John Doe'
    assert test_format('J. O. H. N. D. O. E.') == 'J. O. H. N. D. O. E.'

    # test removal of duplicate spaces
    assert test_format('Hello  World') == 'Hello World'
    assert test_format('Hello World') == 'Hello World'
    assert test_format('Hello   World') == 'Hello World'

    # test handling of right spaces
    assert test_format('Hello World ') == 'Hello World'

# Generated at 2022-06-12 07:17:58.819005
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:18:09.836032
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .testing import run_tests

    def __test(input_string, expected_output):
        formatter = __StringFormatter(input_string)
        output = formatter.format()
        assert output == expected_output


# Generated at 2022-06-12 07:18:23.125602
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # noinspection PyUnusedLocal
    def __assert(input_string, expected):
        formatter = __StringFormatter(input_string)
        actual = formatter.format()
        assert actual == expected

    # noinspection SpellCheckingInspection
    __assert('lo rem ipsum   dolor', 'Lo rem ipsum dolor')
    # noinspection SpellCheckingInspection
    __assert('lo  REM ipsum   dolor', 'Lo rem ipsum dolor')
    # noinspection SpellCheckingInspection
    __assert('Lo  REM ipsum   dolor', 'Lo rem ipsum dolor')
    # noinspection SpellCheckingInspection
    __assert('Lo rem ipsum   dolor', 'Lo rem ipsum dolor')
    # noinspection SpellCheckingInspection

# Generated at 2022-06-12 07:18:34.560422
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    for f in PRETTIFY_TEST_CASES:
        assert __StringFormatter(f[0]).format() == f[1]


# PUBLIC API


# aliases
strip_margin = strip_margin
compress = __StringCompressor.compress
decompress = __StringCompressor.decompress



# Generated at 2022-06-12 07:18:46.207961
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert(__StringFormatter('  Test ').format() == 'Test')
    assert(__StringFormatter('  Test. ').format() == 'Test.')
    assert(__StringFormatter('  Test   Test ').format() == 'Test Test')
    assert(__StringFormatter('  Test   Test   Test ').format() == 'Test Test Test')
    assert(__StringFormatter('  Test   Test   Test   Test ').format() == 'Test Test Test Test')
    assert(__StringFormatter('  Test . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ').format() == 'Test.')

# Generated at 2022-06-12 07:18:50.696093
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:18:55.826476
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print('#### TEST ####\n')
    i = ' hello-world,    this    is    a    test IT\'S     '
    print('# INPUT\n{}'.format(i))
    p = __StringFormatter(i)
    print('# OUTPUT\n{}'.format(p.format()))

# Generated at 2022-06-12 07:19:04.358479
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def func(input_string, expected):
        actual = __StringFormatter(input_string).format()
        assert expected == actual

    # lowercase
    func('lorem ipsum dolor sit amet', 'Lorem ipsum dolor sit amet')
    # uppercase
    func('LOREM IPSUM DOLOR SIT AMET', 'Lorem ipsum dolor sit amet')
    # capitalized
    func('Lorem Ipsum Dolor Sit Amet', 'Lorem ipsum dolor sit amet')
    # uppercase with duplicates
    func('LeTTeR     sPsCIERlErDUPOlICATI    DOLOR', 'Letter special duplicate dolor')
    # uppercase with duplicates

# Generated at 2022-06-12 07:19:11.664833
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello World'
    assert __StringFormatter('hello world').format() == 'Hello World'
    assert __StringFormatter('Hello World').format() == 'Hello World'
    assert __StringFormatter('hello  world').format() == 'Hello World'
    assert __StringFormatter(' Hello World').format() == 'Hello World'
    assert __StringFormatter('Hello World ').format() == 'Hello World'
    assert __StringFormatter('Hello  World').format() == 'Hello World'
    assert __StringFormatter('Hello  World  ').format() == 'Hello World'
    assert __StringFormatter('Hello World!').format() == 'Hello World!'
    assert __StringFormatter('Hello World ?').format() == 'Hello World?'

# Generated at 2022-06-12 07:19:23.430934
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:19:35.017615
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-12 07:19:45.223731
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'
    assert __StringFormatter('  this IS a   TEST ').format() == 'This is a test'

# Generated at 2022-06-12 07:19:54.102004
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('    this is a test    ')
    assert s.format() == 'This is a test'

    s = __StringFormatter('  this     is   a   test  ')
    assert s.format() == 'This is a test'

    s = __StringFormatter(" this-is/a\ntest   ")
    assert s.format() == 'This is a test'

    s = __StringFormatter(" this-is/a\ntest   ")
    assert s.format() == 'This is a test'

    s = __StringFormatter("this's' a test")
    assert s.format() == "This's a test"

    s = __StringFormatter(" this 'is' a test")
    assert s.format() == "This 'is' a test"

    s = __String

# Generated at 2022-06-12 07:20:14.745048
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # compressed = compress(original)
    print(original)
    print(compressed)

# Generated at 2022-06-12 07:20:17.944206
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = 'emails:user@domain.com,otheruser@domain.com'
    o = __StringFormatter(s)
    assert o.input_string == s


# Generated at 2022-06-12 07:20:22.181378
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # instances of class __RomanNumbers
    # noinspection PyTypeChecker
    __RomanNumbers.encode(100).should.be.equal('C')
    # noinspection PyTypeChecker
    __RomanNumbers.decode('CX').should.be.equal(110)



# Generated at 2022-06-12 07:20:23.515420
# Unit test for function roman_decode
def test_roman_decode():
    """
    Check if the function roman_decode works properly
    """
    assert roman_decode('VII')==7
test_roman_decode()



# Generated at 2022-06-12 07:20:25.917361
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(__StringCompressor.compress("Hello world!")) == "Hello world!"


# PUBLIC API



# Generated at 2022-06-12 07:20:37.543721
# Unit test for function slugify
def test_slugify():
    assert slugify('Test string') == 'test-string'
    assert slugify('Test ùñìçóðè-string') == 'test-uncod-string'
    assert slugify('Test string', separator='_') == 'test_string'
    assert slugify('Test string', separator='-') == 'test-string'
    assert slugify('Test string', separator='!') == 'test!string'
    assert slugify('Test string') == 'test-string'
    assert slugify('Test string!') == 'test-string'
    assert slugify('Test string!') == 'test-string'
    assert slugify('Test string?') == 'test-string'
    assert slugify('Test string...') == 'test-string'
    assert slugify('Test string.') == 'test-string'
   

# Generated at 2022-06-12 07:20:43.226759
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('yes') == True
    assert booleanize('nope') == False
    assert booleanize('NOPE') == False
    assert booleanize('NOPe') == False
test_booleanize()


# Generated at 2022-06-12 07:20:46.072520
# Unit test for function booleanize
def test_booleanize():
    """
    Unit test for function booleanize
    
    >>> test_booleanize()
    True
    """
    assert booleanize('true')
    assert booleanize('YES')
    assert not booleanize('nope')


# Run unit tests

# Generated at 2022-06-12 07:20:47.539078
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'

# Generated at 2022-06-12 07:20:53.265239
# Unit test for function strip_margin
def test_strip_margin():
    input_string='''|    line 1
                     |    line 2
                     |    line 3'''
    expected_result=''' line 1
                        line 2
                        line 3'''
    assert(strip_margin(input_string)==expected_result)
    
test_strip_margin()
 