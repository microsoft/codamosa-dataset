

# Generated at 2022-06-18 03:43:06.632479
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'



# Generated at 2022-06-18 03:43:13.617685
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:43:23.429251
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', separator=' ') == 'TheSnakeIsGreen'

# Generated at 2022-06-18 03:43:35.043821
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:43:46.078325
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # test with a simple string
    assert __StringFormatter('hello world').format() == 'Hello world'

    # test with a string containing a url
    assert __StringFormatter('hello world http://www.google.com').format() == 'Hello world http://www.google.com'

    # test with a string containing an email
    assert __StringFormatter('hello world test@test.com').format() == 'Hello world test@test.com'

    # test with a string containing a url and an email
    assert __StringFormatter('hello world http://www.google.com test@test.com').format() == 'Hello world http://www.google.com test@test.com'

    # test with a string containing a url and an email

# Generated at 2022-06-18 03:43:56.623272
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c a').format() == 'A b c a'
    assert __StringFormatter('a b c a b').format() == 'A b c a b'
    assert __StringFormatter('a b c a b c').format() == 'A b c a b c'
    assert __StringFormatter('a b c a b c a').format() == 'A b c a b c a'
    assert __StringFormatter('a b c a b c a b').format() == 'A b c a b c a b'
    assert __StringFormatter('a b c a b c a b c').format() == 'A b c a b c a b c'

# Generated at 2022-06-18 03:44:04.985756
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:44:09.906895
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:44:19.631036
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:44:29.934809
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:44:49.237535
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:44:51.230479
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert len(shuffle('hello world')) == len('hello world')
    assert shuffle('hello world').lower() == 'hello world'.lower()



# Generated at 2022-06-18 03:45:01.954496
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').input_string != 'hello world!'
    assert __StringFormatter('hello world').input_string != 'hello world '
    assert __StringFormatter('hello world').input_string != ' hello world'
    assert __StringFormatter('hello world').input_string != 'hello  world'
    assert __StringFormatter('hello world').input_string != 'hello world  '
    assert __StringFormatter('hello world').input_string != '  hello world'
    assert __StringFormatter('hello world').input_string != 'hello  world  '
    assert __StringFormatter('hello world').input_string != '  hello  world  '
    assert __StringFormatter('hello world').input_string != '  hello  world'

# Generated at 2022-06-18 03:45:06.128257
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:45:15.712142
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('òóäåëýñÅÀÁÇÌÍÑÓË') == 'ooaaeynAAACIINOE'
    assert asciify('òóäåëýñÅÀÁÇÌÍÑÓË') == 'ooaaeynAAACIINOE'
    assert asciify('òóäåëýñÅÀÁÇÌÍÑÓË') == 'ooaaeynAAACIINOE'

# Generated at 2022-06-18 03:45:18.587040
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
    ''') == '''
        line 1
        line 2
        line 3
    '''



# Generated at 2022-06-18 03:45:24.801645
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'The-Snake-Is-Green'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'the-Snake-Is-Green'



# Generated at 2022-06-18 03:45:32.066894
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MMXX') == 2020
    assert roman_decode('MMMMCMXCIX') == 4999
    assert roman_decode('MMMMM') == 5000
    assert roman_decode('MMMMMM') == 6000
    assert roman_decode('MMMMMMM') == 7000
    assert roman_decode('MMMMMMMM') == 8000
    assert roman_decode('MMMMMMMMM') == 9000
    assert roman_decode('MMMMMMMMMM') == 10000
    assert roman_decode('MMMMMMMMMMM') == 11000
    assert roman_decode('MMMMMMMMMMMM') == 12000
    assert roman_decode('MMMMMMMMMMMMM') == 13000

# Generated at 2022-06-18 03:45:37.473495
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(1) == 'I'
    assert roman_encode(0) == ''
    assert roman_encode(4000) == ''
    assert roman_encode('4000') == ''
    assert roman_encode('0') == ''
    assert roman_encode('-1') == ''
    assert roman_encode('-2020') == ''
    assert roman_encode('-3999') == ''
    assert roman_encode('-4000') == ''
    assert roman_encode('-0') == ''

# Generated at 2022-06-18 03:45:44.372615
# Unit test for function prettify

# Generated at 2022-06-18 03:45:51.841980
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
        |''') == '''
        line 1
        line 2
        line 3
        '''



# Generated at 2022-06-18 03:45:55.478944
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:46:03.309385
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello')
    assert __StringFormatter('hello world')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')
    assert __StringFormatter('hello world!')

# Generated at 2022-06-18 03:46:14.779961
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '_') == 'this_is_a_camel_string_test'

# Generated at 2022-06-18 03:46:23.445707
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:46:25.255141
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-18 03:46:28.773498
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-18 03:46:31.040487
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-18 03:46:39.052411
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'

# Generated at 2022-06-18 03:46:46.170055
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('this_is_a_snake_string_test') == 'this_is_a_snake_string_test'



# Generated at 2022-06-18 03:47:06.505811
# Unit test for function prettify

# Generated at 2022-06-18 03:47:17.658365
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '   ') == 'this   is   a   camel   string   test'

# Generated at 2022-06-18 03:47:26.746094
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-18 03:47:34.909361
# Unit test for function prettify

# Generated at 2022-06-18 03:47:40.236609
# Unit test for function prettify

# Generated at 2022-06-18 03:47:50.636826
# Unit test for function compress
def test_compress():
    assert compress('test') == 'eJwLAA=='
    assert compress('test', compression_level=0) == 'eJwLAA=='
    assert compress('test', compression_level=9) == 'eJwLAA=='
    assert compress('test', compression_level=1) == 'eJwLAA=='
    assert compress('test', compression_level=8) == 'eJwLAA=='
    assert compress('test', compression_level=2) == 'eJwLAA=='
    assert compress('test', compression_level=7) == 'eJwLAA=='
    assert compress('test', compression_level=3) == 'eJwLAA=='
    assert compress('test', compression_level=6) == 'eJwLAA=='

# Generated at 2022-06-18 03:48:02.291206
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('hello world!') == '!dlrow olleh'
    assert reverse('hello world! ') == ' !dlrow olleh'
    assert reverse(' hello world! ') == ' !dlrow olleh '
    assert reverse(' hello world!') == '!dlrow olleh '
    assert reverse('hello world! ') == ' !dlrow olleh'
    assert reverse(' hello world!') == '!dlrow olleh '
    assert reverse(' hello world! ') == ' !dlrow olleh '
    assert reverse(' hello world!') == '!dlrow olleh '
    assert reverse('hello world! ') == ' !dlrow olleh'
    assert reverse

# Generated at 2022-06-18 03:48:04.265595
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('hello world!') == '!dlrow olleh'



# Generated at 2022-06-18 03:48:12.015413
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').input_string != 'hello world!'
    assert __StringFormatter('hello world').input_string != 'hello world '
    assert __StringFormatter('hello world').input_string != ' hello world'
    assert __StringFormatter('hello world').input_string != 'hello  world'
    assert __StringFormatter('hello world').input_string != 'hello world.'
    assert __StringFormatter('hello world').input_string != 'hello world,'
    assert __StringFormatter('hello world').input_string != 'hello world;'
    assert __StringFormatter('hello world').input_string != 'hello world:'
    assert __StringFormatter('hello world').input_string != 'hello world?'

# Generated at 2022-06-18 03:48:13.092597
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-18 03:48:32.460133
# Unit test for function prettify

# Generated at 2022-06-18 03:48:34.905696
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-18 03:48:38.999852
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert len(compressed) < len(original)
    assert original == decompress(compressed)



# Generated at 2022-06-18 03:48:48.062673
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('nope') == False
    assert booleanize('yep') == False
    assert booleanize('yess') == False
    assert booleanize('yesss') == False
    assert booleanize('yessss') == False
    assert booleanize('yesssss') == False
    assert booleanize('yessssss') == False
    assert booleanize('yesssssss') == False
    assert booleanize('yessssssss') == False

# Generated at 2022-06-18 03:48:57.192711
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '

# Generated at 2022-06-18 03:49:05.172047
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:49:14.861649
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('False') == False
    assert booleanize('false') == False
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('YES') == True
    assert booleanize('Y') == True
    assert booleanize('y') == True
    assert booleanize('yes') == True
    assert booleanize('0') == False
    assert booleanize('NO') == False
    assert booleanize('no') == False
    assert booleanize('FALSE') == False
    assert booleanize('false') == False
    assert booleanize('2') == False

# Generated at 2022-06-18 03:49:24.243632
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MMXX') == 2020
    assert roman_decode('MMMMCMXCIX') == 4999

# Generated at 2022-06-18 03:49:34.468135
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-18 03:49:37.696750
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'


# Generated at 2022-06-18 03:50:15.096997
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'

# Generated at 2022-06-18 03:50:24.159021
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('this_is_a_snake_string_test') == 'this_is_a_snake_string_test'

# Generated at 2022-06-18 03:50:34.405224
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '

# Generated at 2022-06-18 03:50:41.723100
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:50:51.525745
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'

    assert __RomanNumbers.__encode

# Generated at 2022-06-18 03:50:59.804397
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '') == 'monstermagnet'
    assert slugify('Mönstér Mägnët', '123') == 'monster123magnet'
    assert slugify('Mönstér Mägnët', '123456789')

# Generated at 2022-06-18 03:51:10.994265
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').input_string != 'hello world!'
    assert __StringFormatter('hello world').input_string != 'hello world '
    assert __StringFormatter('hello world').input_string != ' hello world'
    assert __StringFormatter('hello world').input_string != ' hello world '
    assert __StringFormatter('hello world').input_string != 'hello world  '
    assert __StringFormatter('hello world').input_string != '  hello world'
    assert __StringFormatter('hello world').input_string != '  hello world  '
    assert __StringFormatter('hello world').input_string != 'hello world  '
    assert __StringFormatter('hello world').input_string != 'hello  world'
    assert __

# Generated at 2022-06-18 03:51:22.047016
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:51:26.342180
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('hello world')) == 'hello world'
    assert decompress(compress('hello world', 'utf-16')) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', 1)) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', 9)) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', 0)) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', -1)) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', 10)) == 'hello world'
    assert decompress(compress('hello world', 'utf-16', 1)) == 'hello world'

# Generated at 2022-06-18 03:51:35.539844
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'