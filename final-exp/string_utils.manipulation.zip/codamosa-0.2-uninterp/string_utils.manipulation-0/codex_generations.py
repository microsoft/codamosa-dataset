

# Generated at 2022-06-18 03:43:23.534690
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:43:35.263799
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'eeuuooaaeynAAACIINOE'

# Generated at 2022-06-18 03:43:43.192651
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'

# Generated at 2022-06-18 03:43:48.738952
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MMXX') == 2020
    assert roman_decode('MMMMCMXCIX') == 4999
    assert roman_decode('MMMMMMCMXCIX') == 5999

# Generated at 2022-06-18 03:43:55.229252
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '') == 'monstermagnet'
    assert slugify('Mönstér Mägnët', '--') == 'monster--magnet'

# Generated at 2022-06-18 03:44:06.517712
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(14) == 'XIV'
    assert __RomanNumbers.encode(19) == 'XIX'
    assert __RomanNumbers

# Generated at 2022-06-18 03:44:16.282472
# Unit test for function prettify

# Generated at 2022-06-18 03:44:28.147302
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('test')) == 'test'
    assert decompress(compress('test', 'utf-8', 1)) == 'test'
    assert decompress(compress('test', 'utf-8', 9)) == 'test'
    assert decompress(compress('test', 'utf-8', 0)) == 'test'
    assert decompress(compress('test', 'utf-8', -1)) == 'test'
    assert decompress(compress('test', 'utf-8', 10)) == 'test'
    assert decompress(compress('test', 'utf-8', 'a')) == 'test'
    assert decompress(compress('test', 'utf-8', '1')) == 'test'
    assert decompress(compress('test', 'utf-8', '9')) == 'test'


# Generated at 2022-06-18 03:44:40.276014
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XV') == 15
    assert roman_decode('XX') == 20
    assert roman_decode('XXV') == 25
    assert roman_decode('XXX') == 30
    assert roman_decode('XXXV') == 35
    assert roman_decode('XL') == 40
    assert roman_decode('L') == 50
    assert roman_decode('LX') == 60
    assert roman_decode('LXX') == 70
    assert roman_decode('LXXX') == 80
    assert roman_decode('XC') == 90
    assert roman_decode('C')

# Generated at 2022-06-18 03:44:52.223994
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=False) == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=False) == ''

# Generated at 2022-06-18 03:45:01.564760
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert len(compressed) < len(original)
    assert original == decompress(compressed)



# Generated at 2022-06-18 03:45:12.589704
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'

# Generated at 2022-06-18 03:45:15.960800
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-18 03:45:25.045743
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:45:35.705339
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-18 03:45:43.884987
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('No') == False
    assert booleanize('n') == False
    assert booleanize('Y') == True
    assert booleanize('1') == True
    assert booleanize('TRUE') == True
    assert booleanize('Yes') == True
    assert booleanize('N') == False
    assert booleanize('FALSE') == False
    assert booleanize('NO') == False
    assert booleanize('0') == False
    assert booleanize('y') == True
    assert booleanize('NOPE') == False
    assert booleanize('fAlSe') == False
    assert booleanize('yEs') == True

# Generated at 2022-06-18 03:45:49.009322
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

# Generated at 2022-06-18 03:45:56.318690
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'

# Generated at 2022-06-18 03:46:02.244305
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest', ' ') == 'this is a camel string test'

# Generated at 2022-06-18 03:46:04.056608
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-18 03:46:15.749361
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').input_string != 'hello world!'
    assert __StringFormatter('hello world').input_string != 'hello world?'
    assert __StringFormatter('hello world').input_string != 'hello world.'
    assert __StringFormatter('hello world').input_string != 'hello world,'
    assert __StringFormatter('hello world').input_string != 'hello world;'
    assert __StringFormatter('hello world').input_string != 'hello world:'
    assert __StringFormatter('hello world').input_string != 'hello world\''
    assert __StringFormatter('hello world').input_string != 'hello world"'
    assert __StringFormatter('hello world').input_string != 'hello world-'

# Generated at 2022-06-18 03:46:22.246781
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAAACIINOE'
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAAACIINOE'

# Generated at 2022-06-18 03:46:33.564578
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != 'hello world'

# Generated at 2022-06-18 03:46:39.856516
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14
    assert roman_decode('XV') == 15
    assert roman_decode('XVI') == 16
    assert roman_decode('XVII') == 17
    assert roman_decode('XVIII') == 18
    assert roman_decode('XIX') == 19
    assert roman_decode('XX') == 20
    assert roman_decode('XXI') == 21
    assert roman_decode('XXII') == 22
    assert roman_

# Generated at 2022-06-18 03:46:42.779455
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('no') == False
    assert booleanize('n') == False


# Generated at 2022-06-18 03:46:49.415621
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '') == 'monstermagnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', '+-') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', '+-*')

# Generated at 2022-06-18 03:47:00.455310
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:47:06.447837
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('IV') == 4
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14
    assert roman_decode('XV') == 15
    assert roman_decode('XVI') == 16
    assert roman_decode('XVII') == 17
    assert roman_decode('XVIII') == 18
    assert roman_decode('XIX') == 19
    assert roman_decode('XX') == 20
    assert roman_decode

# Generated at 2022-06-18 03:47:11.170161
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'

# Generated at 2022-06-18 03:47:20.991756
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '') == 'monstermagnet'
    assert slugify('Mönstér Mägnët', '__') == 'monster__magnet'

# Generated at 2022-06-18 03:47:34.754437
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '

# Generated at 2022-06-18 03:47:40.100896
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '

# Generated at 2022-06-18 03:47:50.476280
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:48:02.239657
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(0) == 'I'
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
   

# Generated at 2022-06-18 03:48:10.466386
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode('3999') == 'MMMCMXCIX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'

# Generated at 2022-06-18 03:48:14.866266
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest', ' ') == 'this is a camel string test'

# Generated at 2022-06-18 03:48:20.771185
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('test') == 'eNpLT0svy0xNU_PT8_Pz9fX19f'
    assert __StringCompressor.decompress('eNpLT0svy0xNU_PT8_Pz9fX19f') == 'test'


# PUBLIC API



# Generated at 2022-06-18 03:48:30.729159
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('hello world!') == '!dlrow olleh'
    assert reverse('hello world! ') == ' !dlrow olleh'
    assert reverse(' hello world! ') == ' !dlrow olleh '
    assert reverse(' hello world!') == '!dlrow olleh '
    assert reverse('hello world! ') == ' !dlrow olleh'
    assert reverse(' hello world!') == '!dlrow olleh '
    assert reverse(' hello world! ') == ' !dlrow olleh '
    assert reverse('hello world!') == '!dlrow olleh'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('hello')

# Generated at 2022-06-18 03:48:37.620088
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('1') == True
    assert booleanize('y') == True
    assert booleanize('yes') == True
    assert booleanize('True') == True
    assert booleanize('TRUE') == True
    assert booleanize('Y') == True
    assert booleanize('YES') == True
    assert booleanize('YEs') == True
    assert booleanize('YeS') == True
    assert booleanize('yES') == True
    assert booleanize('yEs') == True
    assert booleanize('yes') == True
    assert boolean

# Generated at 2022-06-18 03:48:42.579225
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'

