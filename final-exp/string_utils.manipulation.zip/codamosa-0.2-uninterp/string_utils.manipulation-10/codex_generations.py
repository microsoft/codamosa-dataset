

# Generated at 2022-06-18 03:43:13.002553
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:43:23.734696
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:43:32.099069
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter('hello  world').format() == 'Hello world'
    assert __StringFormatter('hello  world ').format() == 'Hello world'
    assert __StringFormatter(' hello  world').format() == 'Hello world'
    assert __StringFormatter(' hello  world ').format() == 'Hello world'
    assert __StringFormatter('hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __String

# Generated at 2022-06-18 03:43:41.556250
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator=' ') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='.') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:43:48.252886
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:43:59.830038
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:44:09.649632
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:44:18.630833
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:44:21.743992
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:44:31.183816
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:44:52.223987
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:45:02.787025
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:45:13.300691
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'

# Generated at 2022-06-18 03:45:24.057566
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:45:33.687357
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:45:42.633574
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:45:53.810203
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('a a').format() == 'A a'
    assert __StringFormatter('a a a').format() == 'A a a'
    assert __StringFormatter('a a a a').format() == 'A a a a'
    assert __StringFormatter('a a a a a').format() == 'A a a a a'
    assert __StringFormatter('a a a a a a').format() == 'A a a a a a'
    assert __StringFormatter('a a a a a a a').format() == 'A a a a a a a'
    assert __StringFormatter('a a a a a a a a').format() == 'A a a a a a a a'

# Generated at 2022-06-18 03:46:02.084976
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'
    assert __StringFormatter('  a  b  c  ').format() == 'A B C'

# Generated at 2022-06-18 03:46:13.401383
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!!!').format() == 'Hello world!'
    assert __String

# Generated at 2022-06-18 03:46:23.405498
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a  b  c').format() == 'A b c'
    assert __StringFormatter('a b c ').format() == 'A b c'
    assert __StringFormatter('a b c  ').format() == 'A b c'
    assert __StringFormatter('  a b c').format() == 'A b c'
    assert __StringFormatter('  a b c  ').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d ').format() == 'A b c d'
