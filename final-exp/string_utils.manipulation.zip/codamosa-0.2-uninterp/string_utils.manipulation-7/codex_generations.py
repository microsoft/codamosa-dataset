

# Generated at 2022-06-18 03:43:09.644492
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '') == 'thisisacamelstringtest'

# Generated at 2022-06-18 03:43:18.151801
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:43:28.765305
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a b c d e f g h i j k l m n o p q r s t u v w x y z  ').format() == 'A b c d e f g h i j k l m n o p q r s t u v w x y z'
    assert __StringFormatter('  a b c d e f g h i j k l m n o p q r s t u v w x y z  ').format() == 'A b c d e f g h i j k l m n o p q r s t u v w x y z'

# Generated at 2022-06-18 03:43:35.248917
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:43:46.076614
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'

# Generated at 2022-06-18 03:43:50.797753
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'

# Generated at 2022-06-18 03:44:03.103180
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:44:11.629251
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
   

# Generated at 2022-06-18 03:44:17.780537
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '_') == 'this_is_a_camel_string_test'

# Generated at 2022-06-18 03:44:22.748526
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '   ') == 'this   is   a   camel   string   test'

# Generated at 2022-06-18 03:44:39.345789
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:44:51.246352
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:45:01.997662
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:45:12.680947
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, ' ') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, ' ') == 'theSnakeIsGreen'
    assert snake_case_to_c

# Generated at 2022-06-18 03:45:24.014832
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:45:33.588476
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:45:42.572358
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:45:45.467213
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:45:50.872186
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:45:57.724207
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'
    assert snake_case_to_

# Generated at 2022-06-18 03:46:11.663142
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-snake-is-green'



# Generated at 2022-06-18 03:46:18.290034
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator=' ') == 'the_snake_is_green'

# Generated at 2022-06-18 03:46:28.189443
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:46:36.807211
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:46:47.922262
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:46:56.999555
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:47:09.286235
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('a b').format() == 'A b'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'

# Generated at 2022-06-18 03:47:19.537418
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('a  b  c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c ').format() == 'A b c'
    assert __StringFormatter('  a b c').format() == 'A b c'
    assert __StringFormatter('  a b c ').format() == 'A b c'
    assert __StringFormatter('a b c  ').format() == 'A b c'
    assert __StringFormatter('  a b c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c').format() == 'A b c'


# Generated at 2022-06-18 03:47:25.148506
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('a  b  c').format() == 'A b c'
    assert __StringFormatter('a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringForm

# Generated at 2022-06-18 03:47:34.277465
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '.') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '.') == 'theSnakeIsGreen'
    assert snake_case_to_c

# Generated at 2022-06-18 03:47:52.294164
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:48:03.415780
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:48:11.292388
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
   

# Generated at 2022-06-18 03:48:15.955338
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:48:22.530445
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:48:32.553603
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  ').format() == 'foo'
    assert __StringFormatter('  foo  bar  ').format() == 'foo bar'
    assert __StringFormatter('  foo  bar  baz  ').format() == 'foo bar baz'
    assert __StringFormatter('  foo  bar  baz  qux  ').format() == 'foo bar baz qux'
    assert __StringFormatter('  foo  bar  baz  qux  quux  ').format() == 'foo bar baz qux quux'
    assert __StringFormatter('  foo  bar  baz  qux  quux  quuz  ').format() == 'foo bar baz qux quux quuz'

# Generated at 2022-06-18 03:48:41.185886
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
    assert __StringFormatter('   Hello   World   ').format() == 'Hello World'
   

# Generated at 2022-06-18 03:48:47.055594
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:48:53.763531
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:49:01.870620
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:49:38.199916
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'

# Generated at 2022-06-18 03:49:47.131347
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:49:54.095661
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:50:02.359409
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c ').format() == 'A b c'
    assert __StringFormatter(' a b c').format() == 'A b c'
    assert __StringFormatter(' a b c ').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d ').format() == 'A b c d'
    assert __StringFormatter(' a b c d').format() == 'A b c d'
    assert __StringFormatter(' a b c d ').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __

# Generated at 2022-06-18 03:50:11.659717
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:50:21.746888
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a b c ').format() == 'A b c'
    assert __StringFormatter('  a b c d e f g h i j k l m n o p q r s t u v w x y z ').format() == 'A b c d e f g h i j k l m n o p q r s t u v w x y z'

# Generated at 2022-06-18 03:50:29.350910
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:50:38.596785
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  d  ').format() == 'A b c d'
    assert __StringFormatter('  a  b  c  d  e  ').format() == 'A b c d e'
    assert __StringFormatter('  a  b  c  d  e  f  ').format() == 'A b c d e f'
    assert __StringFormatter('  a  b  c  d  e  f  g  ').format() == 'A b c d e f g'
    assert __StringFormatter('  a  b  c  d  e  f  g  h  ').format() == 'A b c d e f g h'
    assert __String

# Generated at 2022-06-18 03:50:44.030544
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:50:53.087342
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'