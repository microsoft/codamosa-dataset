

# Generated at 2022-06-18 03:43:11.809145
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '') == 'thisisacamelstringtest'

# Generated at 2022-06-18 03:43:21.326081
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'

# Generated at 2022-06-18 03:43:27.052031
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:43:38.444362
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:43:49.008766
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '_') == 'this_is_a_camel_string_test'

# Generated at 2022-06-18 03:43:55.253297
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:44:06.519017
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '   ') == 'this   is   a   camel   string   test'

# Generated at 2022-06-18 03:44:13.847196
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green'
    assert snake_case_to_

# Generated at 2022-06-18 03:44:25.439412
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:44:36.424112
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-case-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel case string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  case  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '   ') == 'this   is   a   camel   case   string   test'

# Generated at 2022-06-18 03:44:51.425579
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:45:01.668597
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('a a').format() == 'A a'
    assert __StringFormatter('a a a').format() == 'A a a'
    assert __StringFormatter('a a a a').format() == 'A a a a'
    assert __StringFormatter('a a a a a').format() == 'A a a a a'
    assert __StringFormatter('a a a a a a').format() == 'A a a a a a'
    assert __StringFormatter('a a a a a a a').format() == 'A a a a a a a'
    assert __StringFormatter('a a a a a a a a').format() == 'A a a a a a a a'

# Generated at 2022-06-18 03:45:11.099343
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green') == 'The snake is green'



# Generated at 2022-06-18 03:45:18.030357
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:45:26.883893
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format() == 'A b c'
    assert __StringFormatter('  a b c   ').format

# Generated at 2022-06-18 03:45:37.436175
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:45:41.241095
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:45:52.680879
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:46:00.073254
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:46:11.301454
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:46:26.466169
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'
    assert __StringFormatter('foo bar').format() == 'Foo bar'

# Generated at 2022-06-18 03:46:35.811233
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'

# Generated at 2022-06-18 03:46:47.157975
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:46:57.308172
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'

# Generated at 2022-06-18 03:47:09.620039
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter

# Generated at 2022-06-18 03:47:17.467442
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:47:26.066441
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:47:34.308729
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:47:41.889157
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:47:49.582864
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'The-Snake-Is-Green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the-Snake-Is-Green'



# Generated at 2022-06-18 03:48:16.237990
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:48:26.886355
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest', ' ') == 'this is a camel string test'

# Generated at 2022-06-18 03:48:28.018636
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-18 03:48:38.488847
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:48:42.886471
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') != 'eeuuooaaeynAAACIINOE'

# Generated at 2022-06-18 03:48:54.974171
# Unit test for constructor of class __StringCompressor

# Generated at 2022-06-18 03:48:57.347276
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-18 03:48:58.983302
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-18 03:49:08.288342
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'

# Generated at 2022-06-18 03:49:19.220727
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ') == 'AAAAAAACEEEEIIIIDNOOOOOOUUUUYBsaaaaaaaceeeeiiiidnoooooouuuuyty'

# Generated at 2022-06-18 03:49:43.864019
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-18 03:49:51.320727
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').input_string != 'hello world!'
    assert __StringFormatter('hello world').input_string != 'hello world '
    assert __StringFormatter('hello world').input_string != ' hello world'
    assert __StringFormatter('hello world').input_string != 'hello  world'
    assert __StringFormatter('hello world').input_string != 'hello world  '
    assert __StringFormatter('hello world').input_string != '  hello world'
    assert __StringFormatter('hello world').input_string != 'hello  world  '
    assert __StringFormatter('hello world').input_string != '  hello  world  '
    assert __StringFormatter('hello world').input_string != '  hello  world'

# Generated at 2022-06-18 03:49:59.992418
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAAACIINOE'
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAAACIINOE'

# Generated at 2022-06-18 03:50:09.960679
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world')
    assert __StringFormatter('hello world').input_string == 'hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world').format() == 'Hello world'

# Generated at 2022-06-18 03:50:13.601266
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'


# Generated at 2022-06-18 03:50:14.893840
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
        |''') == '''
        line 1
        line 2
        line 3
        '''



# Generated at 2022-06-18 03:50:24.151265
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('2') == False
    assert booleanize('3') == False
    assert booleanize('4') == False
    assert booleanize('5') == False
    assert booleanize('6') == False
    assert booleanize('7') == False
    assert booleanize('8') == False
    assert booleanize('9') == False
    assert booleanize('10') == False

# Generated at 2022-06-18 03:50:26.936187
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-18 03:50:31.094366
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', '.') == 'monster.magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '') == 'monstermagnet'

# Generated at 2022-06-18 03:50:35.162397
# Unit test for function prettify

# Generated at 2022-06-18 03:51:22.167441
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-18 03:51:31.130681
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=False) == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=False) == ''

# Generated at 2022-06-18 03:51:35.281477
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '.') == 'monster.magnet'
    assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    assert slugify('Mönstér Mägnët', '*') == 'monster*magnet'
    assert slugify('Mönstér Mägnët', ' ') == 'monster magnet'
    assert slugify('Mönstér Mägnët', '  ')

# Generated at 2022-06-18 03:51:43.900941
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'

# Generated at 2022-06-18 03:51:53.189426
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'
    assert roman_encode(100) == 'C'

# Generated at 2022-06-18 03:52:00.992145
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Arrange
    input_string = 'Hello world'
    encoding = 'utf-8'
    compression_level = 9

    # Act
    output = __StringCompressor.compress(input_string, encoding, compression_level)

    # Assert

# Generated at 2022-06-18 03:52:09.890071
# Unit test for function decompress

# Generated at 2022-06-18 03:52:20.720605
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'

# Generated at 2022-06-18 03:52:31.101484
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '   ') == 'this   is   a   camel   string   test'

# Generated at 2022-06-18 03:52:32.218243
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''
