

# Generated at 2022-06-18 03:43:10.215696
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:43:19.356676
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:43:29.637748
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   a   b   c   ').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'

# Generated at 2022-06-18 03:43:38.794725
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:43:44.926684
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:43:54.964453
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'
    assert __StringFormatter('a b c d e f g h i j').format() == 'A b c d e f g h i j'
    assert __StringForm

# Generated at 2022-06-18 03:44:06.296460
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  ').format() == 'A b'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  d  ').format() == 'A b c d'
    assert __StringFormatter('  a  b  c  d  e  ').format() == 'A b c d e'
    assert __StringFormatter('  a  b  c  d  e  f  ').format() == 'A b c d e f'
    assert __StringFormatter('  a  b  c  d  e  f  g  ').format() == 'A b c d e f g'

# Generated at 2022-06-18 03:44:13.152012
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:44:19.169347
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator=' ') == 'the_snake_is_green'

# Generated at 2022-06-18 03:44:27.009842
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format()

# Generated at 2022-06-18 03:44:40.008603
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator=' ') == 'the snake is green'



# Generated at 2022-06-18 03:44:51.915157
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a  b  c').format() == 'A b c'
    assert __StringFormatter('a b c ').format() == 'A b c'
    assert __StringFormatter(' a b c').format() == 'A b c'
    assert __StringFormatter(' a b c ').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d ').format() == 'A b c d'
    assert __StringFormatter(' a b c d').format() == 'A b c d'
    assert __StringFormatter(' a b c d ').format() == 'A b c d'
    assert __StringForm

# Generated at 2022-06-18 03:45:02.487061
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:45:12.990448
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator=' ') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:45:21.582109
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:45:28.981494
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:45:39.496997
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:45:44.583052
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:45:55.626695
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:46:01.835686
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:46:14.335361
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:46:21.355748
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:46:32.024885
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', separator=' ') == 'TheSnakeIsGreen'

# Generated at 2022-06-18 03:46:39.471250
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_c

# Generated at 2022-06-18 03:46:49.358493
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:46:55.432583
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'
    assert __StringFormatter('  a  b  c  ').format() == 'A b c'

# Generated at 2022-06-18 03:47:07.587297
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:47:18.607690
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_c

# Generated at 2022-06-18 03:47:25.799700
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:47:34.696192
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:47:46.288986
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:47:51.679320
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'



# Generated at 2022-06-18 03:48:03.006826
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  ').format() == 'a'
    assert __StringFormatter('  a  b  ').format() == 'a b'
    assert __StringFormatter('  a  b  c  ').format() == 'a b c'
    assert __StringFormatter('  a  b  c  d  ').format() == 'a b c d'
    assert __StringFormatter('  a  b  c  d  e  ').format() == 'a b c d e'
    assert __StringFormatter('  a  b  c  d  e  f  ').format() == 'a b c d e f'
    assert __StringFormatter('  a  b  c  d  e  f  g  ').format() == 'a b c d e f g'
    assert __

# Generated at 2022-06-18 03:48:11.055690
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the_snake_is_green'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-18 03:48:17.290620
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'

# Generated at 2022-06-18 03:48:27.262939
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:48:38.314535
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:48:47.967347
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-18 03:48:57.644088
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format() == 'Foo bar'
    assert __StringFormatter('  foo  bar  ').format

# Generated at 2022-06-18 03:49:00.932963
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Arrange
    input_string = '  this is a test  '
    expected_output = 'This is a test'
    sut = __StringFormatter(input_string)

    # Act
    output = sut.format()

    # Assert
    assert output == expected_output



# Generated at 2022-06-18 03:49:31.904374
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter

# Generated at 2022-06-18 03:49:42.534161
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:49:50.860827
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'

# Generated at 2022-06-18 03:49:56.705771
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  lorem ipsum  dolor sit amet  ').format() == 'Lorem ipsum dolor sit amet'
    assert __StringFormatter('  lorem ipsum  dolor sit amet  ').format() == 'Lorem ipsum dolor sit amet'
    assert __StringFormatter('  lorem ipsum  dolor sit amet  ').format() == 'Lorem ipsum dolor sit amet'
    assert __StringFormatter('  lorem ipsum  dolor sit amet  ').format() == 'Lorem ipsum dolor sit amet'
    assert __StringFormatter('  lorem ipsum  dolor sit amet  ').format() == 'Lorem ipsum dolor sit amet'

# Generated at 2022-06-18 03:50:03.971071
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a').format() == 'A'
    assert __StringFormatter('a b').format() == 'A b'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'

# Generated at 2022-06-18 03:50:12.626738
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
    assert __StringFormatter('  hello  world  ').format() == 'Hello world'
   

# Generated at 2022-06-18 03:50:22.969286
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a b c d e').format() == 'A b c d e'
    assert __StringFormatter('a b c d e f').format() == 'A b c d e f'
    assert __StringFormatter('a b c d e f g').format() == 'A b c d e f g'
    assert __StringFormatter('a b c d e f g h').format() == 'A b c d e f g h'
    assert __StringFormatter('a b c d e f g h i').format() == 'A b c d e f g h i'
    assert __StringFormatter('a b c d e f g h i j').format() == 'A b c d e f g h i j'
    assert __StringForm

# Generated at 2022-06-18 03:50:33.301131
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello  world').format() == 'Hello world'
    assert __StringFormatter('hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello world ').format() == 'Hello world'
    assert __StringFormatter(' hello  world ').format() == 'Hello world'
    assert __StringFormatter(' hello  world  ').format() == 'Hello world'
    assert __StringFormatter(' hello  world  ').format() == 'Hello world'
    assert __StringFormatter(' hello  world  ').format() == 'Hello world'
    assert __StringFormatter(' hello  world  ').format() == 'Hello world'
    assert __StringFormatter(' hello  world  ').format() == 'Hello world'

# Generated at 2022-06-18 03:50:41.042248
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!').format() == 'Hello world!'
    assert __StringFormatter('hello world!!!!!!!!!').format() == 'Hello world!'

# Generated at 2022-06-18 03:50:51.468703
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'
    assert __StringFormatter('  this is a test  ').format() == 'This is a test'