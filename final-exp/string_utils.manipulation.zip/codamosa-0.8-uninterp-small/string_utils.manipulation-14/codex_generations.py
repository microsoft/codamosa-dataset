

# Generated at 2022-06-26 01:42:07.264487
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('this IS A tEsT')
    assert string_formatter.format() == 'This is a test'

# PUBLIC API



# Generated at 2022-06-26 01:42:19.531996
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string_0 = '   a string   '
    assert __StringFormatter(input_string_0).format() == 'A string'

    input_string_1 = '   thiS   is   a   string   with   duplicaTe   spaces   '
    assert __StringFormatter(input_string_1).format() == 'This is a string with duplicate spaces'

    input_string_2 = '   thiS   is   a   string   with   duplicaTe   spaces   '
    assert __StringFormatter(input_string_2).format() == 'This is a string with duplicate spaces'

    input_string_3 = '   a string   with   spaces   at the right   '
    assert __StringFormatter(input_string_3).format() == 'A string with spaces at the right'

    input_string_4

# Generated at 2022-06-26 01:42:28.771659
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter(
        "This is a test. This Is a SeCond Test.THIS IS A THIRD TEST.This is a test. This Is a SeCond Test.THIS IS A THIRD TEST.This is a test. This Is a SeCond Test.THIS IS A THIRD TEST.This is a test. This Is a SeCond Test.THIS IS A THIRD TEST.This is a test. This Is a SeCond Test.THIS IS A THIRD TEST.")
    string_formatter_0.format()


# PUBLIC API



# Generated at 2022-06-26 01:42:42.314113
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('this is a test').format() == 'This is a test'
    assert __StringFormatter('thisIsATest').format() == 'This is a test'
    assert __StringFormatter('T H I S I S A T E S T').format() == 'This is a test'
    assert __StringFormatter('this is a test.').format() == 'This is a test.'
    assert __StringFormatter('this is a test.').format() == 'This is a test.'
    assert __StringFormatter('this is a test .').format() == 'This is a test.'
    assert __StringFormatter('this is a test .').format() == 'This is a test.'
    assert __StringFormatter('this-is-a-test').format() == 'This is a test'

# Generated at 2022-06-26 01:42:54.364673
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # assert __StringFormatter('hello world').format() == 'Hello world'
    # assert __StringFormatter('hello  world').format() == 'Hello world'
    # assert __StringFormatter('hello  world  !!').format() == 'Hello world ! !'
    assert __StringFormatter('ciao  Mondo').format() == 'Ciao mondo'
    assert __StringFormatter('ciao  Mondo   !!!').format() == 'Ciao mondo ! ! !'
    # assert __StringFormatter('hello   World   !!!').format() == 'Hello world ! ! !'
    # assert __StringFormatter('hello   World   !!!').format() == 'Hello world ! ! !'
    # assert __StringFormatter('hello   World   !!!').format() == 'Hello world ! ! !'
    # assert __StringForm

# Generated at 2022-06-26 01:43:02.830825
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    cases = {
        # General cases
        "Animal hospital 'la gattara'": "Animal hospital 'La Gattara'",
        "Animal hospital â€˜la gattaraâ€™": "Animal hospital 'La Gattara'",
        "Animal hospital 'la''gattara'": "Animal hospital 'La' 'Gattara'",
        "Animal hospital 'la\"gattara'": "Animal hospital 'La' 'Gattara'",
        "Animal hospital \"la gattara\"": "Animal hospital 'La Gattara'",
        "Animal hospital 'la gattara' ": "Animal hospital 'La Gattara'",
        " Animal hospital 'la gattara'": "Animal hospital 'La Gattara'"
    }
    for string_0 in cases.keys():
        formatter_0 = __StringFormatter

# Generated at 2022-06-26 01:43:11.363724
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string_0 = 'just a test  string'
    test_string_1 = 'just a. test  string'
    test_string_2 = 'just a. test string'
    test_string_3 = 'just a test string.'
    test_string_4 = 'just a test   string'
    test_string_5 = ' just a test string  '
    test_string_6 = 'just a test string '
    test_string_7 = ' just a test string'
    test_string_8 = 'just a test string'
    test_string_9 = 'just a test string'
    test_string_10 = 'just a test string. Here is a new sentence.'
    test_string_11 = 'just a test string., here is a new sentence.'

# Generated at 2022-06-26 01:43:22.772252
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:34.594517
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter.format("THE HOUSE ON MANGO STREET")
    assert string_formatter_0 == "The House on Mango Street"
    
    string_formatter_1 = __StringFormatter.format("THE HOUSE ON MANGO STREET BY SANDRA CRENSHAW")
    assert string_formatter_1 == "The House on Mango Street by Sandra Crenshaw"
    
    string_formatter_2 = __StringFormatter.format("THE HOUSE ON MANGO STREET BY SANDRA CRENSHAW VINTAGE CONTEMPORARIES")
    assert string_formatter_2 == "The House on Mango Street by Sandra Crenshaw Vintage Contemporaries"
    

# Generated at 2022-06-26 01:43:37.016459
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('a')

    assert formatter.format() == 'A'


# Generated at 2022-06-26 01:43:53.404082
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test case 0:
    input_string0 = 'Come bella cosa  e´  l´amore!    '
    string_formatter_0 = __StringFormatter(input_string0)
    expected_result = 'Come bella cosa è l\'amore!'
    assert string_formatter_0.format() == expected_result

    # Test case 1:
    input_string1 = 'Come bella cosa  e´  l´amore!    '
    string_formatter_1 = __StringFormatter(input_string1)
    expected_result = 'Come bella cosa è l\'amore!'
    assert string_formatter_1.format() == expected_result

    # Test case 2:

# Generated at 2022-06-26 01:44:06.801754
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter("test")
    assert string_formatter_0.format() == "test"
    string_formatter_1 = __StringFormatter("test test")
    assert string_formatter_1.format() == "test test"
    string_formatter_2 = __StringFormatter("test test test")
    assert string_formatter_2.format() == "test test test"
    string_formatter_3 = __StringFormatter("test test test test")
    assert string_formatter_3.format() == "test test test test"
    string_formatter_4 = __StringFormatter("test test test test test")
    assert string_formatter_4.format() == "test test test test test"

# Generated at 2022-06-26 01:44:13.020002
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('foo bar  baz')
    print('--- EXPECTED ---')
    print('Foo bar baz')
    print('--- ACTUAL ---')
    print(string_formatter_0.format())
    assert string_formatter_0.format() == 'Foo bar baz'

    string_formatter_1 = __StringFormatter('')
    print('--- EXPECTED ---')
    print('')
    print('--- ACTUAL ---')
    print(string_formatter_1.format())
    assert string_formatter_1.format() == ''

    string_formatter_2 = __StringFormatter('   foo bar baz        ')
    print('--- EXPECTED ---')
    print('Foo bar baz')

# Generated at 2022-06-26 01:44:22.284540
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string_0 = '   das   ist  ein  beispiel   '
    expected_result_0 = 'Das ist ein Beispiel'

    input_string_1 = '   DAS   IST  EIN  BEISPIEL   '
    expected_result_1 = 'Das ist ein Beispiel'

    input_string_2 = '   das   ist  ein  beispiel,   '
    expected_result_2 = 'Das ist ein Beispiel,'

    input_string_3 = '   das   ist  ein  beispiel.   '
    expected_result_3 = 'Das ist ein Beispiel.'

    input_string_4 = '   das   ist  ein  beispiel;   '


# Generated at 2022-06-26 01:44:27.005040
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Creates a string formatter
    try:
        string_formatter_0 = __StringFormatter("the quick brown fox jumps over the lazy dog")
    except:
        print("Error: could not create an instance of __StringFormatter (class)")
        return False

    # Calls internal method format()
    try:
        output = string_formatter_0.format()
    except:
        print("Error: could not call __StringFormatter.format()")
        return False

    # Check the output value
    if output != "The quick brown fox jumps over the lazy dog":
        print("Error: __StringFormatter.format() failed. Got wrong result.")
        return False

    print("__StringFormatter.format() passed its test")
    return True



# Generated at 2022-06-26 01:44:28.288445
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    output = __StringFormatter('  1 2 3 4   ').format()
    assert output == '1 2 3 4'


# Generated at 2022-06-26 01:44:34.297524
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test 0
    input_string = "nokia."
    string_formatter_0 = __StringFormatter(input_string)
    assert (string_formatter_0.format() == "Nokia."), "format at line 0, should be \"Nokia.\""
    # Test 1
    input_string = "und.mehr.muster.druck.technik@googlemail.com"
    string_formatter_1 = __StringFormatter(input_string)
    assert (string_formatter_1.format() == "Und.mehr.muster.druck.technik@googlemail.com"), "format at line 1, should be \"Und.mehr.muster.druck.technik@googlemail.com\""
    # Test 2
    input_string = "media@airgram.com"
    string

# Generated at 2022-06-26 01:44:36.048480
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # TODO write some unit tests here
    pass


# Generated at 2022-06-26 01:44:45.475608
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test 0: plain string
    string_formatter_0 = __StringFormatter(input_string='hi')
    assert string_formatter_0.format() == 'hi'

    # Test 1: duplicates
    string_formatter_1 = __StringFormatter(input_string='hi     hi')
    assert string_formatter_1.format() == 'hi hi'

    # Test 2: uppercase first letter
    string_formatter_11 = __StringFormatter(input_string='hi my name is andrea')
    assert string_formatter_11.format() == 'Hi my name is Andrea'

    # Test 3: uppercase first letter after sign
    string_formatter_111 = __StringFormatter(input_string='hi my name is o\'andrea')

# Generated at 2022-06-26 01:44:48.304485
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 =  __StringFormatter("hello world")
    return string_formatter_0.format()


# Generated at 2022-06-26 01:44:56.125705
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)



# Generated at 2022-06-26 01:44:58.085792
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    string_compressor = __StringCompressor()
    test_case_1()


# Generated at 2022-06-26 01:45:08.826323
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    str_0 = 'http://example.com?key=value'
    # - test class method compress
    str_1 = __StringCompressor.compress(str_0)
    str_2 = 'https://example.com/?key=value'
    str_3 = 'https://example.com/file.pdf?key=value&another_key=other_value'
    str_4 = 'https://example.com/api/v1/?key=value&another_key=other_value'
    str_5 = __StringCompressor.compress(str_2)
    str_6 = __StringCompressor.compress(str_3)
    str_7 = __StringCompressor.compress(str_4)
    str_8 = __StringCompressor.decompress(str_1)
    str_9 = __String

# Generated at 2022-06-26 01:45:17.775281
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    str_0 = 'Hello World'
    print('Original String: ' + str_0).encode()
    str_1 = __StringCompressor.compress(str_0)
    print('Compressed String: ' + str_1)

    # Decompress this string
    str_2 = __StringCompressor.decompress(str_1).encode('utf-8')
    print('Decompressed String: ' + str_2)

    return 0


# Generated at 2022-06-26 01:45:21.745345
# Unit test for function shuffle
def test_shuffle():
    a_str = 'ABCDEFG'
    b_str = shuffle(a_str)
    b_lst = list(b_str)
    a_lst = list(a_str)
    a_lst.sort()
    b_lst.sort()
    for i in range(len(a_lst)):
        if a_lst[i] != b_lst[i]:
            print('#FAILED#: shuffle function failed')
            return
    print('#PASSED#: shuffle function passed')

# TODO

# Generated at 2022-06-26 01:45:27.802619
# Unit test for function reverse
def test_reverse():
    str_0 = '-tSu@]Jz*"Il\t@`\rv'
    str_1 = 'v\r`@\tIl"*zJ]@uSt-'
    # str_2 = reverse(str_0)
    # str_3 = reverse(str_1)
    # assert str_0 == str_1


# Generated at 2022-06-26 01:45:29.571379
# Unit test for function prettify

# Generated at 2022-06-26 01:45:41.496127
# Unit test for function prettify
def test_prettify():
    str_1 = prettify("   A:(   ")
    expected_res = "A:("
    if str_1 == expected_res:
        print("Test case 1 passed.")
    else:
        print("Test case 1 failed: " + str_1 + " vs. " + expected_res)

    str_2 = prettify("   A:(   ")
    expected_res = "A:("
    if str_2 == expected_res:
        print("Test case 2 passed.")
    else:
        print("Test case 2 failed: " + str_2 + " vs. " + expected_res)

    str_3 = prettify(" ! ? !")
    expected_res = "! ?"
    if str_3 == expected_res:
        print("Test case 3 passed.")

# Generated at 2022-06-26 01:45:43.160056
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # test_case_0()
    test_case_1()


# Generated at 2022-06-26 01:45:53.422824
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    snake_case_list = ['this_is_a_snake_case_string', 'this__is_also_valid']
    camel_case_list = ['ThisIsASnakeCaseString', 'ThisIsAlsoValid']
    # second test with "_" as separator
    snake_case_list_2 = ['this_is_a_snake_case_string', 'this_is_also_valid']
    camel_case_list_2 = ['ThisIsASnakeCaseString', 'ThisIsAlsoValid']

    for s, c in zip(snake_case_list, camel_case_list):
        assert snake_case_to_camel(s) == c


# Generated at 2022-06-26 01:46:02.739176
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    pass


# Generated at 2022-06-26 01:46:04.126167
# Unit test for function strip_margin
def test_strip_margin():
    str_0 = '''
                line 1
                line 2
                line 3
        '''
    str_1 = strip_margin(str_0)
    print(str_1)


# Generated at 2022-06-26 01:46:14.471148
# Unit test for function strip_html
def test_strip_html():
    str_0 = 'test: <a href="foo/bar">click here</a>'
    str_1 = 'test: click here'
    str_2 = 'click here'

    # Test with keep_tag_content=True
    assert strip_html(str_0, True)==str_1

    # Test with keep_tag_content=False
    assert strip_html(str_0)==str_2


if __name__ == '__main__':
    test_case_0()
    test_strip_html()

# Generated at 2022-06-26 01:46:24.002780
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('666€€€333') == '666eur333'
    assert asciify('ärgerlich') == '‚rgerlich'
    assert asciify('¤¤¤¤¤') == '¤¤¤¤¤'
    assert asciify('1€') == '1€'
    assert asciify('èéùúòóâåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynaaacicinoë'

# Generated at 2022-06-26 01:46:32.465369
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    # Test for bound-ary cases
    assert roman_encode(0) == None
    assert roman_encode(4000) == None
    # Test for special cases
    assert roman_encode(-1) == None
    assert roman_encode(3.14) == None
    # Test for empty string
    assert roman_encode("") == None
    try:
        roman_encode("")
    except:
        assert True
    else:
        assert False
    # Test for exception
    try:
        roman_encode("abc")
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:46:40.147635
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('III') == 3
    assert roman_decode('X') == 10
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000
    assert roman_decode('XXIV') == 24
    assert roman_decode('MDCCCCX') == 1910
    assert roman_decode('MDCCCCLXXXXVII') == 1977
    assert roman_decode('MCDLXXXII') == 1482
    assert roman_decode('MCMXCVIII') == 1998
    assert roman_decode('MCMLXXXIV') == 1984

# Generated at 2022-06-26 01:46:43.938497
# Unit test for function asciify
def test_asciify():
    str_0 = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    str_1 = asciify(str_0)
    assert str_1 == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-26 01:46:45.393783
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    __StringFormatter('input_string')


# Generated at 2022-06-26 01:46:50.835938
# Unit test for function decompress
def test_decompress():
    """ Unit tests for function decompress """
    str_0 = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z!'
    str_1 = compress(str_0)
    str_2 = decompress(str_1)
    assert str_0 == str_2, 'Unit test failed'
    

# Generated at 2022-06-26 01:46:58.929422
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize('Y') == True
    assert booleanize('n') == False
    assert booleanize('ok') == False
    assert booleanize('Ok') == False
    assert booleanize('Ok') == False


# Generated at 2022-06-26 01:47:17.556783
# Unit test for function asciify
def test_asciify():
    input_string = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    print(asciify(input_string))


# Generated at 2022-06-26 01:47:27.007191
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = '   It’s    a    beautiful    day    '
    formatter = __StringFormatter(str_0)
    f_str_0 = formatter.format()

    str_1 = '   It’s a beautiful day    '
    formatter = __StringFormatter(str_1)
    f_str_1 = formatter.format()

    str_2 = 'It’s a beautiful day    '
    formatter = __StringFormatter(str_2)
    f_str_2 = formatter.format()

    str_3 = 'It’s a beautiful day '
    formatter = __StringFormatter(str_3)
    f_str_3 = formatter.format()

    str_4 = '   It’s a beautiful day'
    formatter = __StringForm

# Generated at 2022-06-26 01:47:28.952388
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    str_0 = "test"
    str_1 = __StringCompressor.compress(str_0)


# Generated at 2022-06-26 01:47:31.147060
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('123456789') == '987654321'


# Generated at 2022-06-26 01:47:34.966036
# Unit test for function shuffle
def test_shuffle():
    # Create random string
    rand_str = ''.join([random.choice(string.ascii_letters) for _ in range(1000)])

    # Check if shuffling string is different from original string
    assert(rand_str != shuffle(rand_str))


# Generated at 2022-06-26 01:47:44.878293
# Unit test for function strip_html
def test_strip_html():
    str_0 = '-tSu@]Jz*"Il\t@`\rv'
    str_1 = roman_encode(str_0)
    str_2 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
    str_3 = 'Duis vitae imperdiet lorem. Maecenas a risus leo. '
    str_4 = 'Aliquam quis sodales lacus. Cras elementum erat a arcu varius finibus. '
    str_5 = 'In neque ligula, ullamcorper sed nisi nec, vestibulum pulvinar nisl. '

# Generated at 2022-06-26 01:47:47.966042
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('t') == False
    assert booleanize('T') == False
    assert booleanize(1) == False
    assert booleanize(True) == False


# Generated at 2022-06-26 01:47:53.376670
# Unit test for function asciify
def test_asciify():
    str_0 = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    str_1 = asciify(str_0)
    assert str_1 == 'eeuuooaaeynAAACIINOE'


# Generated at 2022-06-26 01:47:56.596041
# Unit test for function strip_html
def test_strip_html():
    str_0 = '<a href="foo/bar">click here</a>'
    str_1 = strip_html(str_0)

    assert str_1 == ''


# Generated at 2022-06-26 01:48:03.582402
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(2903) == 'MMCMIII', print('__RomanNumbers.encode failed')
    assert __RomanNumbers.decode('MMCMIII') == 2903, print('__RomanNumbers.decode failed')
