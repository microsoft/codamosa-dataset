

# Generated at 2022-06-26 01:41:56.897197
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # TODO
    pass


# Generated at 2022-06-26 01:41:59.373670
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter("string@oracle.com")
    formatter_0.format()


# Generated at 2022-06-26 01:42:08.217990
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print("\nUnit test for method format of class __StringFormatter")
    arg_0 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
    arg_1 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
    arg_2 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."

# Generated at 2022-06-26 01:42:13.851812
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    try:
        __StringFormatter('test').format()
    except InvalidInputError:
        pass
    else:
        raise Exception()
    try:
        __StringFormatter(None).format()
    except InvalidInputError:
        pass
    else:
        raise Exception()



# Generated at 2022-06-26 01:42:17.659509
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = 'Spaces in it, redundancy (duplicated words) and some weird characters like: &< >,....'
    out = __StringFormatter(input_string).format()
    assert out == 'Spaces in it, redundancy and some weird characters like: &< >,.'


# Generated at 2022-06-26 01:42:29.791520
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:42:43.001205
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # test 1
    string_formatter_01 = __StringFormatter('hello world   1')
    result_01 = string_formatter_01.format()

    assert result_01 == 'Hello world 1'

    # test 2
    string_formatter_02 = __StringFormatter('hello World   1')
    result_02 = string_formatter_02.format()

    assert result_02 == 'Hello world 1'

    # test 3
    string_formatter_03 = __StringFormatter('hello World... 1')
    result_03 = string_formatter_03.format()

    assert result_03 == 'Hello world... 1'

    # test 4
    string_formatter_04 = __StringFormatter(' hello World   1 ')
    result_04 = string_formatter_04.format()

    assert result_04

# Generated at 2022-06-26 01:42:46.568607
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter(' Beautiful   World! ')
    print(s.format())
    s = __StringFormatter(' Beautiful   World. ')
    print(s.format())


# Generated at 2022-06-26 01:42:48.033734
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:00.044990
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('abc')
    formatted_string_0 = string_formatter_0.format()
    expected_string_0 = 'Abc'
    assert formatted_string_0 == expected_string_0

    string_formatter_1 = __StringFormatter('-   - abc    def')
    formatted_string_1 = string_formatter_1.format()
    expected_string_1 = '- abc def'
    assert formatted_string_1 == expected_string_1

    string_formatter_2 = __StringFormatter('http://www.abc.it')
    formatted_string_2 = string_formatter_2.format()
    expected_string_2 = 'Http://www.abc.it'
    assert formatted_string_2 == expected_string_2

    string_

# Generated at 2022-06-26 01:43:06.709559
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    result = snake_case_to_camel(input_string, upper_case_first=True, separator='_')
    print('Result: {}'.format(result))
    assert result == 'TheSnakeIsGreen'



# Generated at 2022-06-26 01:43:19.756144
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    out_0 = 'TheSnakeIsGreen'
    assert snake_case_to_camel(str_0) == out_0
    print('Test 0 success: ' + str_0 + ' -> ' + out_0)

    str_1 = 'test_test_test'
    out_1 = 'TestTestTest'
    assert snake_case_to_camel(str_1) == out_1
    print('Test 1 success: ' + str_1 + ' -> ' + out_1)

    str_2 = 'camel_is_cool'
    out_2 = 'camelIsCool'
    assert snake_case_to_camel(str_2, upper_case_first=False) == out_2

# Generated at 2022-06-26 01:43:31.253733
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False) == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False, separator="-") == "theSnakeIsGreen"
    assert snake_case_to_camel("start_with_a_number1") == "StartWithANumber1"
    assert snake_case_to_camel("special-characters_should_be_ok-") == "SpecialCharactersShouldBeOk"
    assert snake_case_to_camel("special-characters-should-be-ok2") == "SpecialCharactersShouldBeOk2"


# Generated at 2022-06-26 01:43:36.574644
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test 1
    input_string = "this_is_a_string"
    expected_string = "ThisIsAString"
    output_string = snake_case_to_camel(input_string)
    if output_string != expected_string:
        print("test_snake_case_to_camel_test_1: expected: " + expected_string + ", actual: " + output_string)
        raise Exception("test_snake_case_to_camel_test_1 failed")

    # Test 2
    input_string = "thisIsAString"
    expected_string = "thisIsAString"
    output_string = snake_case_to_camel(input_string)

# Generated at 2022-06-26 01:43:43.935973
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("this_is_a_test", True, '_') == "ThisIsATest"
    assert snake_case_to_camel("this_is_another_test", False, '_') == "thisIsAnotherTest"
    assert snake_case_to_camel("this_is_another_test_2", True, '_') == "ThisIsAnotherTest2"
    assert snake_case_to_camel("this_is_another_test_2", True, '-') == "this_is_another_test_2"
    assert snake_case_to_camel("this_is_a_test", True, '-') == "This-Is-A-Test"

# Generated at 2022-06-26 01:43:56.003159
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake_is_green") == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", False) == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", True, ".") == "theSnakeIsGreen"
    assert snake_case_to_camel("invalid_snake_case_string") == "invalid_snake_case_string"
    assert snake_case_to_camel("invalid_snake_case_string", False, ".") == "invalid_snake_case_string"
    assert snake_case_to_camel("invalid_snake_case_string", True, "") == "invalid_snake_case_string"

# Generated at 2022-06-26 01:44:08.826402
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    snake_case_0 = 'this_is_a_snake_case_string'
    camel_case_0 = snake_case_to_camel(snake_case_0)
    assert(camel_case_0) == 'ThisIsASnakeCaseString'
    camel_case_1 = snake_case_to_camel(snake_case_0, upper_case_first=False)
    assert(camel_case_1) == 'thisIsASnakeCaseString'
    snake_case_1 = 'the_snake_is_green'
    camel_case_2 = snake_case_to_camel(snake_case_1)
    assert(camel_case_2) == 'TheSnakeIsGreen'

# Generated at 2022-06-26 01:44:19.688876
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test case 1:
    snake_0 = "the_snake_is_green"
    camel_0 = snake_case_to_camel(snake_0)
    assert camel_0 == "TheSnakeIsGreen"
    # Test case 2:
    snake_1 = "we_dont_care_about_this_one"
    camel_1 = snake_case_to_camel(snake_1)
    assert camel_1 == "WeDontCareAboutThisOne"
    # Test case 3:
    snake_2 = "this_will_not_work"
    camel_2 = snake_case_to_camel(snake_2)
    assert camel_2 != "ThisWillNotWork"
    # Test case 4:
    snake_3 = ""
    camel_3 = snake_case_to_

# Generated at 2022-06-26 01:44:27.188431
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    if snake_case_to_camel('the_snake_is_green') != 'TheSnakeIsGreen':
        print('test_snake_case_to_camel failed!')
    elif snake_case_to_camel('the_snake_is_green', False) != 'theSnakeIsGreen':
        print('test_snake_case_to_camel failed!')
    elif snake_case_to_camel('this_is_a_test', False, '_') != 'thisIsATest':
        print('test_snake_case_to_camel failed!')
    elif snake_case_to_camel('this_is_a_test', False, '-') != 'this-is-a-test':
        print('test_snake_case_to_camel failed!')

# Generated at 2022-06-26 01:44:33.222161
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = '_'
    str_1 = 'camel_'
    str_2 = 'camel___'
    str_3 = '1camel'
    str_4 = 'camel_case3'
    str_5 = 'camel_case_3'
    str_6 = 'camel_case_'
    str_7 = 'camel_'
    str_8 = '__camel_'
    str_9 = 'camel_case__'
    str_10 = '_camel_case'
    str_11 = 'camel_case_'
    str_12 = 'case_camel'
    str_13 = 'camel_Case'
    str_14 = 'case_Camel'
    str_15 = 'camel_Case_'

# Generated at 2022-06-26 01:44:43.199579
# Unit test for function strip_html
def test_strip_html():
    html_string = '<html><body><h1>Title</h1><p>Hello</p></body></html>'
    text_string = 'TitleHello'
    assert strip_html(html_string) == text_string




# Generated at 2022-06-26 01:44:45.565126
# Unit test for function slugify
def test_slugify():
    str_0 = "hello'world,àlìènò&\"bèstìà"
    str_1 = slugify(str_0)
    str_2 = r"hello-world-a-l-i-e-n-o--b-e-s-t-i-a"
    assert str_1 == str_2,"expected " + str_2 + " got " + str_1
    

# Generated at 2022-06-26 01:44:46.376771
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'ellh olordw'


# Generated at 2022-06-26 01:44:56.481590
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "  Hello!  My name is :   Massimo,  and I'm a  senior  Python  \n  programmer. I like very much  python-string-utils... and  I  love  my  wife  !"
    output_string = "Hello! My name is: Massimo, and I'm a senior Python programmer. I like very much Python-String-Utils... and I love my wife!"

    output = __StringFormatter(input_string).format()
    if output == output_string:
        print('Test passed')
    else:
        print('Test failed')


# Generated at 2022-06-26 01:44:58.593474
# Unit test for function shuffle
def test_shuffle():
    mylist = list(range(0,5))
    shuffle(mylist)
    assert all(isinstance(x, int) for x in mylist)
    assert True == (5 == len (mylist))
    assert True == (x in mylist for x in range(0,5))

# Unit test function to test function roman_encode

# Generated at 2022-06-26 01:44:59.608088
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    __RomanNumbers()


# Generated at 2022-06-26 01:45:05.911166
# Unit test for function strip_html
def test_strip_html():
    str = '<div class="plainlinks hlist navbar mini"><div style="float:'
    str += 'right; margin-right: 13px; font-size: 85%;">'
    str += '<span class="plainlinksneverexpand"><b>[[File:'
    str += 'Wfn-vogtland2.svg|15px|link=|alt=]]</b>&#160;<a '
    str += 'href="//www.voigtlaender.de/hilfe/vogtland.htm"><span '
    str += 'style="color: white;">Quelle: <span style="white-space:'
    str += 'nowrap; background-color:#FF0000">'

# Generated at 2022-06-26 01:45:06.847444
# Unit test for function booleanize
def test_booleanize():
    print(booleanize('true'))

# Generated at 2022-06-26 01:45:10.087676
# Unit test for function decompress
def test_decompress():
    try:
        string_0 = roman_encode(int(5))
    except Exception:
        print("Exception was raised when calling decompress")


# Generated at 2022-06-26 01:45:11.666994
# Unit test for function strip_margin
def test_strip_margin():
    expected = '''
line 1
line 2
line 3
'''
    input = '''
                                                line 1
                                                line 2
                                                line 3
'''
    assert expected == strip_margin(input)
