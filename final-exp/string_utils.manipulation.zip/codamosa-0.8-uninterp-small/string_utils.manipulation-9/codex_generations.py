

# Generated at 2022-06-26 01:42:03.408182
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('A CASO').format() == 'A caso'
    assert __StringFormatter('the   the').format() == 'the the'
    assert __StringFormatter('THE the').format() == 'The the'
    assert __StringFormatter('a   THE caso').format() == 'A the caso'
    assert __StringFormatter('the   the').format() == 'the the'
    assert __StringFormatter('the the the').format() == 'The the the'
    assert __StringFormatter('Email: giuseppe.bacchi@gmail.com URL: https://www.google.com').format() == 'Email: giuseppe.bacchi@gmail.com URL: https://www.google.com'

# Generated at 2022-06-26 01:42:05.716577
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('This Is a Test String')
    assert string_formatter_0.format() is not None


# Generated at 2022-06-26 01:42:08.835319
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('this is a   string     with     a lot      of    problems')
    string_formatter.format()
    test_string_formatter = __StringFormatter('this is a   string     with     a lot      of    problems')
    test_string_formatter.format()


# Generated at 2022-06-26 01:42:17.482717
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print('\nUnit test for method format of class __StringFormatter')
    test_string0 = ' la bùbbolìnA !   '
    result_string = 'La bubbolina !'
    test_class_0 = __StringFormatter(test_string0)
    result_class_0 = test_class_0.format()
    print('Result: ', test_string0, '->', result_class_0)
    if result_string == result_class_0:
        print('Unit test passed!')
    else:
        print('Unit test NOT passed!')


# Generated at 2022-06-26 01:42:23.469563
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    #string_formatter = __StringFormatter('')
    string_formatter = __StringFormatter('this is a test')
    #string_formatter = __StringFormatter('this   is a test')
    string_formatter.format()


# Generated at 2022-06-26 01:42:27.825417
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_case_1_0()
    test_case_1_1()
    test_case_1_2()
    test_case_1_3()
    test_case_1_4()
    test_case_1_5()
    test_case_1_6()
    test_case_1_7()
    test_case_1_8()
    test_case_1_9()
    test_case_1_10()



# Generated at 2022-06-26 01:42:35.467410
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter("  I'm  a  string  full  of  spaces     and    with    capitals    !!   ")
    res_formatter_0 = formatter_0.format()
    assert res_formatter_0 == "I'm a string full of spaces and with capitals !!"

test_case_0()
test___StringFormatter_format()


# PUBLIC API



# Generated at 2022-06-26 01:42:36.830178
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    assert(True == True)


# Generated at 2022-06-26 01:42:40.108443
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_formatter_0 = __StringFormatter('test string')
    print('Result of format: ' + str_formatter_0.format())


# Generated at 2022-06-26 01:42:49.022483
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('hello')
    assert string_formatter.format() == 'Hello'
    string_formatter = __StringFormatter('hello   ')
    assert string_formatter.format() == 'Hello'
    string_formatter = __StringFormatter('hello,    ')
    assert string_formatter.format() == 'Hello,'
    string_formatter = __StringFormatter('   hello,    ')
    assert string_formatter.format() == 'Hello,'
    string_formatter = __StringFormatter('world()')
    assert string_formatter.format() == 'World()'
    string_formatter = __StringFormatter('world    ()')
    assert string_formatter.format() == 'World()'
    string_formatter = __StringFormatter('andré')

# Generated at 2022-06-26 01:42:55.013204
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_String=test_case_0()
    test__StringFormatter=__StringFormatter(input_String)
    assert test__StringFormatter.input_string==test_case_0()


# Generated at 2022-06-26 01:43:08.047361
# Unit test for function slugify
def test_slugify():
    # Test if the function can convert "normal" strings
    assert (slugify('Hello World') == 'hello-world' and
        slugify('I love my dog') == 'i-love-my-dog' and
        slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs' and
        slugify('Mönstér Mägnët') == 'monster-magnet')

    # Test if the function can correctly handle empty values
    for empty_value in [None, '']:
        assert slugify(empty_value) == ''

    # Test if the function can handle separators
    assert slugify('Hello World', '_') == 'hello_world'
    assert slugify('Hello World', r'$%') == 'hello$%world'

    # Test if the function can handle non-

# Generated at 2022-06-26 01:43:10.323096
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    str_0 = 'ThisIsACamelStringTest'
    str_1 = camel_case_to_snake(str_0)
    print(str_1)


# Generated at 2022-06-26 01:43:22.621565
# Unit test for function prettify
def test_prettify():
    # test case 1
    str_1 = '     foo     '
    expected_1 = 'foo'
    actual_1 = prettify(str_1)

    assert expected_1 == actual_1, f"expected {expected_1}, actual {actual_1}"

    # test case 2
    str_2 = '      '
    expected_2 = ''
    actual_2 = prettify(str_2)

    assert expected_2 == actual_2, f"expected {expected_2}, actual {actual_2}"

    # test case 3
    str_3_1 = 'foo.'
    str_3_2 = 'bar!'
    str_3_3 = 'baz?'
    str_3 = str_3_1 + str_3_2 + str_3_3

# Generated at 2022-06-26 01:43:32.639002
# Unit test for function roman_encode
def test_roman_encode():
    # Positive test case 1
    int_1 = 2074
    str_1 = roman_encode(int_1)
    print(str_1)

    # Positive test case 2
    int_2 = 2020
    str_2 = roman_encode(int_2)
    print(str_2)
    
    # Negative test case 1
    int_3 = 0
    try:
        str_3 = roman_encode(int_3)
    except:
        print("Input 0 is not valid Roman number")

    # Negative test case 2
    int_4 = 4000
    try:
        str_4 = roman_encode(int_4)
    except:
        print("Input 4000 is not valid Roman number")


# Generated at 2022-06-26 01:43:37.752734
# Unit test for function compress
def test_compress():

    str_0 = compress('A'*100)
    str_1 = compress('A'*100000)

    str_2 = compress('A'*100, encoding='latin-1')


# Generated at 2022-06-26 01:43:41.363398
# Unit test for function reverse
def test_reverse():
    input_strings = ['hello', 'house', 'macho', 'pippo']
    for input_string in input_strings:
        reversed_output = reverse(input_string)
        assert(reverse(reversed_output) == input_string)


# Generated at 2022-06-26 01:43:48.883247
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    str_0 = "Http://www.google.com?q=googlenewwindow"
    compress_str_0 = __StringCompressor.compress(str_0)
    decompress_str_0 = __StringCompressor.decompress(compress_str_0)
    print(str_0)
    print(compress_str_0)
    print(decompress_str_0)
    assert str_0 == decompress_str_0


# Generated at 2022-06-26 01:43:51.955845
# Unit test for function slugify
def test_slugify():
    str_0 = "top 10 reasons to love dogs!!!"
    str_1 = slugify(str_0)
    print(str_1)
    assert(str_1 == "top-10-reasons-to-love-dogs")


# Generated at 2022-06-26 01:43:53.189426
# Unit test for function strip_margin
def test_strip_margin():
    input_string = strip_margin('''
        |line 1
        |line 2
        |line 3
        |''')
    print(input_string)



# Generated at 2022-06-26 01:44:05.934479
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELLO') == 'OLLEH'
    assert reverse('123') == '321'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse('Hello World') == 'dlroW olleH'


# Generated at 2022-06-26 01:44:10.332806
# Unit test for function strip_margin
def test_strip_margin():
    string_0 = '''    line 1
    line 2
    line 3
    '''
    string_1 = strip_margin(string_0)
    print(string_1)

if __name__ == '__main__':
    test_case_0()
    test_strip_margin()

# Generated at 2022-06-26 01:44:12.268204
# Unit test for function slugify
def test_slugify():
    str_0 = "Top 10 Reasons To Love Dogs!!!"
    str_1 = "Mönstér Mägnët"

    print(slugify(str_0))
    print(slugify(str_1))

if __name__ == '__main__':
    test_case_0()
    test_slugify()

# Generated at 2022-06-26 01:44:15.510523
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    print(__RomanNumbers.__mappings)
    print(__RomanNumbers.__reversed_mappings)

test_case_0()
test___RomanNumbers()

# Generated at 2022-06-26 01:44:18.744218
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    for i in range(-1, 4000):
        str_0 = roman_encode(i)
        i_0 = roman_decode(str_0)
        assert(i_0 == i)

# Unit Test for roman_encode

# Generated at 2022-06-26 01:44:20.530789
# Unit test for function shuffle
def test_shuffle():
    str_0 = "Hello World!"
    str_1 = shuffle(str_0)
    str_2 = shuffle(str_1)
    assert str_1 != str_0
    assert str_2 != str_0
    assert str_2 != str_1


# Generated at 2022-06-26 01:44:31.809022
# Unit test for function roman_encode
def test_roman_encode():
    print('Testing roman_encode... ', end='')
    assert(roman_encode(1) == 'I')
    assert(roman_encode(2) == 'II')
    assert(roman_encode(3) == 'III')
    assert(roman_encode(4) == 'IV')
    assert(roman_encode(5) == 'V')
    assert(roman_encode(9) == 'IX')
    assert(roman_encode(10) == 'X')
    assert(roman_encode(11) == 'XI')
    assert(roman_encode(24) == 'XXIV')
    assert(roman_encode(39) == 'XXXIX')
    assert(roman_encode(40) == 'XL')
    assert(roman_encode(49) == 'XLIX')

# Generated at 2022-06-26 01:44:32.589055
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    obj_0 = __RomanNumbers


# Generated at 2022-06-26 01:44:44.163708
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("XXI") == 21
    assert roman_decode("XIV") == 14
    assert roman_decode("XXII") == 22
    assert roman_decode("XXVII") == 27
    assert roman_decode("VIII") == 8
    assert roman_decode("CXXX") == 130
    assert roman_decode("LXXXI") == 81
    assert roman_decode("IV") == 4
    assert roman_decode("XIV") == 14
    assert roman_decode("MCMLXXXIX") == 1989
    assert roman_decode("MCMXC") == 1990
    assert roman_decode("MMXVIII") == 2018
    assert roman_decode("XCVIII") == 98

# Generated at 2022-06-26 01:44:48.841739
# Unit test for function strip_margin
def test_strip_margin():
    str_0 = '''
    line 0
    line 1
    line 2
    '''
    str_1 = '''
    line 0
    line 1
    line 2
    '''
    str_2 = '''
    line 0
    line 1
    line 2
    '''
    str_3 = '''
    line 0
    line 1
    line 2
    '''
    str_4 = '''
    line 0
    line 1
    line 2
    '''
    str_5 = '''
    line 0
    line 1
    line 2
    '''
    str_6 = '''
    line 0
    line 1
    line 2
    '''
    str_7 = '''
    line 0
    line 1
    line 2
    '''