

# Generated at 2022-06-26 01:42:06.048341
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(str_0)
    str_2 = snake_case_to_camel(str_0, upper_case_first=False)
    str_3 = snake_case_to_camel(str_0, upper_case_first=True, separator='-')
    try:
        snake_case_to_camel(str_0, 123)
        # raise ValueError('upper_case_first must be boolean')
    except ValueError as e:
        pass
    try:
        snake_case_to_camel(str_0, upper_case_first=True, separator=123)
        # raise ValueError('separator must be string')
    except ValueError as e:
        pass
   

# Generated at 2022-06-26 01:42:12.018012
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Case 0
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == 'Erxb"@Cb \tg.:*h'

    # Case 1
    str_0 = '    snOw ?  --   WHitE  '
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == '    Snow ?  --   White  '

    # Case 2
    str_0 = ' EAST   O f  the   sUN '
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == ' East O f the Sun '

    # Case 3

# Generated at 2022-06-26 01:42:14.560962
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_formatter = __StringFormatter('test')
    str_formatter.format()
    return 0
# PUBLIC API



# Generated at 2022-06-26 01:42:18.610721
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Setup fixture
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    # Exercise SUT
    str_1 = 'Erxb#>"@Cb g.:*h'
    # Verify
    assert str_1 == __StringFormatter(str_0).format()


# public api implementations

# Generated at 2022-06-26 01:42:24.629548
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    str_0 = 'ThisIsACamelStringTest'
    str_1 = 'this_is_a_camel_string_test'
    assert(camel_case_to_snake(str_0)==str_1)


# Generated at 2022-06-26 01:42:27.289003
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input = '  the quick brown fox '
    output = __StringFormatter(input).format()
    assert output == "The quick brown fox"


# Generated at 2022-06-26 01:42:30.693880
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = camel_case_to_snake(str_0)
    assert str_0 == str_1


# Generated at 2022-06-26 01:42:36.831498
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)

    if is_camel_case(str_1):
        print(1)
    else:
        print(0)


# Generated at 2022-06-26 01:42:47.374287
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def test_(input_string, expected_output):
        output = __StringFormatter(input_string).format()
        assert (output == expected_output), "expected output is %s and real output is %s" % (expected_output, output)

    test_('This is an    example', 'This is an example')
    test_('thisIsAnExample', 'This is an example')
    test_('Got It From Your Page ... Hope', 'Got it from your page hope')
    test_('This -- is a test', 'This is a test')
    test_('This - is a - test', 'This is a test')
    test_('This - is a -- test', 'This is a test')
    test_('This  is a test', 'This is a test')
    test_('This is a test.', 'This is a test')

# Generated at 2022-06-26 01:42:59.615351
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:06.443834
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str0 = 'hello '
    str1 = __StringFormatter(str0).format()
    if str1 != 'Hello':
        raise ValueError
    return True

# Generated at 2022-06-26 01:43:10.916867
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(str_0)
    assert str_1 == 'TheSnakeIsGreen'
    print('Function snake_case_to_camel works fine.')



# Generated at 2022-06-26 01:43:17.157818
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # new test case
    str_2 = 'these are words with a lot of spaces'
    sf_2 = __StringFormatter(str_2)
    assert sf_2.format() == 'These are words with a lot of spaces'


# Generated at 2022-06-26 01:43:21.695086
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    str_2 = 'Erxb#>"@Cb    g.:*H'
    str_3 = __StringFormatter(str_2).format()
    assert str_1 == str_3


# Generated at 2022-06-26 01:43:23.716521
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_ = 'ERXB#>"@Cb \tg.:*h'
    f = __StringFormatter(str_)
    f.format()


# Generated at 2022-06-26 01:43:35.671567
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  This is   a test   string').format() == 'This is a test string'
    assert __StringFormatter('Bonjour,  mon  amie!').format() == 'Bonjour, mon amie!'
    assert __StringFormatter(' ciao come stai ').format() == 'Ciao come stai'
    assert __StringFormatter('drs. van dam, jr.').format() == 'Drs. van Dam, Jr.'
    assert __StringFormatter('Here is a link: http://test.com').format() == 'Here is a link: http://test.com'
    assert __StringFormatter('Here is a mail: mail@test.com').format() == 'Here is a mail: mail@test.com'

# Generated at 2022-06-26 01:43:47.474330
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    str_2 = str_1.capitalize()

    str_3 = '<div><p>hello</p><p>world</p></div>'
    str_4 = strip_html(str_3)
    str_5 = str_4.capitalize()

    str_6 = 'ERXB#>"@Cb       \tg.:*h'
    str_7 = str_6.replace(' ', '')
    str_8 = str_7.capitalize()

    str_9 = '<div>  <p>   hello </p>    <p>world </p> </div>'
    str_10 = strip_html(str_9)

# Generated at 2022-06-26 01:43:49.635852
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = '  <p>hello world</p> '
    str_1 = __StringFormatter(str_0).format()


# Generated at 2022-06-26 01:44:01.914063
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # test_case_1
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = 'Erxb"@Cb \tg.:*h'
    str_2 = __StringFormatter(str_0).format()

    # test_case_2
    str_0 = 'John Doe     '
    str_1 = 'John Doe'
    str_2 = __StringFormatter(str_0).format()

    # test_case_3
    str_0 = '   John Doe     '
    str_1 = 'John Doe'
    str_2 = __StringFormatter(str_0).format()

    # test_case_4
    str_0 = '   John Doe       '
    str_1 = 'John Doe'

# Generated at 2022-06-26 01:44:08.016179
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'test_test_test  test.'
    str_1 = 'Test test test test.'
    str_2 = __StringFormatter(str_0).format()
    print(str_2)
    print('str_1 =', str_1)
    print('str_2 =', str_2)
    print(str_1 == str_2)


# Generated at 2022-06-26 01:44:21.553520
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    str_2 = 'Yb_Hk_Tp_wix_sftl_fj_hwt'
    str_3 = snake_case_to_camel(str_2)
    str_4 = ''
    str_5 = snake_case_to_camel(str_4)
    str_6 = 'This_is_a_string__'
    str_7 = camel_case_to_snake(str_1)
    str_8 = '-This-is--a---string----'
    str_9 = camel_case_to_snake(str_1, '-')
    str_10 = '@'
    str

# Generated at 2022-06-26 01:44:25.625722
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test 1:
    try:
        snake_case_to_camel(None)
    except InvalidInputError:
        print('Test 1 passed')
    else:
        print('Test 1 failed')

    # Test 2:
    try:
        snake_case_to_camel(123)
    except InvalidInputError:
        print('Test 2 passed')
    else:
        print('Test 2 failed')

    # Test 3:
    if snake_case_to_camel('hello_world') == 'helloWorld':
        print('Test 3 passed')
    else:
        print('Test 3 failed')

    # Test 4:
    if snake_case_to_camel('hello_world', upper_case_first=False) == 'helloWorld':
        print('Test 4 passed')

# Generated at 2022-06-26 01:44:31.659305
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test case0
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    if not (str_1 == 'Erxb#>"@Cb \tg.:*h'):
        print('Test case0 failed')
        return
    # Test case1
    str_0 = '#'
    str_1 = snake_case_to_camel(str_0)
    if not (str_1 == '#'):
        print('Test case1 failed')
        return
    # Test case2
    str_0 = 'a'
    str_1 = snake_case_to_camel(str_0)
    if not (str_1 == 'A'):
        print('Test case2 failed')
        return

# Generated at 2022-06-26 01:44:35.120475
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Testing function snake_case_to_camel')
    input_string = 'i_like_pizza'
    expected = 'ILikePizza'
    output = snake_case_to_camel(input_string)
    print('Expected: ' + expected)
    print('Output:   ' + output)

    if expected != output:
        raise Exception('snake_case_to_camel test failed')


# Generated at 2022-06-26 01:44:36.505752
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test case 0
    try:
        test_case_0()
        print('Test case 0 passed')
    except:
        print('Test case 0 failed')



# Generated at 2022-06-26 01:44:42.542161
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print(snake_case_to_camel('the_snake_is_green'))
    print('TheSnakeIsGreen')
    print(snake_case_to_camel('the_snake_is_green', upper_case_first=False))
    print('theSnakeIsGreen')
    print(snake_case_to_camel('the_snake_is_green', separator='-'))
    print('TheSnakeIsGreen')

if __name__ == '__main__':
    num = 1000000000
    result = camel_case_to_snake('ThisIsACamelStringTest')
    print(result)
    # test_case_0()
    # test_snake_case_to_camel()

# Generated at 2022-06-26 01:44:45.895312
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Running test snake_case_to_camel')
    try:
        test_case_0()
        print('Test Success!')
    except:
        print('Test Failed!')


# Generated at 2022-06-26 01:44:58.362862
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'this_is_a_snake_string_test'
    str_1 = 'T_hisIsASnakeStringTest'
    str_2 = 't_his_is_a_snake_string_test'
    str_3 = ''
    str_4 = 'input'
    str_5 = 'ThisIsACamelStringTest'
    str_6 = 'snake_case_to_camel_'

    assert snake_case_to_camel(str_0) == 'ThisIsASnakeStringTest'
    assert snake_case_to_camel(str_1) == 'ThisIsASnakeStringTest'
    assert snake_case_to_camel(str_2) == 'ThisIsASnakeStringTest'

# Generated at 2022-06-26 01:45:09.081999
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    str_2 = snake_case_to_camel(str_1)

    assert str_0 == str_2

    str_3 = snake_case_to_camel(str_1, upper_case_first=False)
    str_4 = snake_case_to_camel(str_3)

    assert str_1 == str_4

    str_5 = snake_case_to_camel('', upper_case_first=True)

    assert str_5 == ''

    str_6 = snake_case_to_camel(str_0, separator='|')

    assert str_6 != str_0
    assert str_6 == str_

# Generated at 2022-06-26 01:45:11.549631
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'ERXB#>"@Cb \tg.:*h'
    str_1 = snake_case_to_camel(str_0)
    assert str_1 == 'Erxb#>"@Cb \tg.:*h'

