

# Generated at 2022-06-26 01:42:04.152871
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    str_0 = 'ThisIsACamelStringTest'
    str_1 = camel_case_to_snake(str_0)
    str_2 = 'this_is_a_camel_string_test'
    assert str_1 == str_2, 'The string not convert to snake string correctly'

# Generated at 2022-06-26 01:42:10.712309
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('HelloWorld') == 'hello_world'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsAString') == 'this_is_a_string'
    assert camel_case_to_snake('thisIsAString') == 'this_is_a_string'
    assert camel_case_to_snake('thisIsAString', '-') == 'this-is-a-string'
    #assert camel_case_to_snake(None) == None
    #assert camel_case_to_snake('') == ''


# Generated at 2022-06-26 01:42:13.547891
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test')



# Generated at 2022-06-26 01:42:15.983764
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    test_case_0()



# Generated at 2022-06-26 01:42:20.325526
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    words = [
    'These  words    should       be$ $formatted as   follows.   ',
    'N.B.:      URL http://www.example.com      should remain unchanged.',
    'Email address hello@example.com should   also remain   unchanged',
    'You should take care of Saxon genitives like Smith\'s',
    'Name: Jefferson, Last name: Michael, Born on: 1743-04-13'
    ]

    assert __StringFormatter(words[0]).format() == 'These words should be formatted as follows.'
    assert __StringFormatter(words[1]).format() == 'N.B.: URL http://www.example.com should remain unchanged.'
    assert __StringFormatter(words[2]).format() == 'Email address hello@example.com should also remain unchanged'

# Generated at 2022-06-26 01:42:23.946947
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Test Cases
    test_case_0()
    test_case_1()
    
    

# Generated at 2022-06-26 01:42:32.569934
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("HelloWorld") == "hello_world"
    assert camel_case_to_snake("hello") == "hello"
    assert camel_case_to_snake("Hello") == "hello"
    assert camel_case_to_snake("HelloWorld") == "hello_world"
    assert camel_case_to_snake("HELLOWORLD") == "hello_world"
    assert camel_case_to_snake("123hello") == "123hello"
    assert camel_case_to_snake("Hello123") == "hello123"
    assert camel_case_to_snake("hello_world") == "hello_world"
    assert camel_case_to_snake("HelloWorld1") == "hello_world1"

# Generated at 2022-06-26 01:42:44.350931
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    if camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test':
        print('test_case_1 is passed')
    else:
        print('test_case_1 is failed')
    if camel_case_to_snake('AABBCC') == 'aabbcc':
        print('test_case_2 is passed')
    else:
        print('test_case_2 is failed')
    if camel_case_to_snake(None) == '':
        print('test_case_3 is passed')
    else:
        print('test_case_3 is failed')
    if camel_case_to_snake('') == '':
        print('test_case_4 is passed')

# Generated at 2022-06-26 01:42:53.329305
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test')
    assert(camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test')
    assert(camel_case_to_snake('ThisIsANullString', separator='_') == 'this_is_a_null_string')
    assert(camel_case_to_snake('') == None)
    assert(camel_case_to_snake(None) == None)



# Generated at 2022-06-26 01:43:00.258810
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    str_0 = 'ThisIsACamelStringTest'
    str_1 = 'this_is_a_camel_string_test'
    if not camel_case_to_snake(str_0) == str_1:
        raise AssertionError
    # extra test
    str_0 = None
    #str_1 = 'this_is_a_camel_string_test_'
    with pytest.raises(InvalidInputError) as excinfo:
        test_case_0()
    assert "Invalid input: " in str(excinfo.value)



# Generated at 2022-06-26 01:43:08.293269
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='_') == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:43:09.509013
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('lorem ipsum')



# Generated at 2022-06-26 01:43:14.930014
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # assert return value of function camel_case_to_snake
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-26 01:43:20.015127
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    string_compressor_0 = __StringCompressor()
    temp_string = "the_snake_is_green"
    temp_string_1 = "TheSnakeIsGreen"
 
    object_0 = string_compressor_0.snake_case_to_camel(input_string=temp_string)

    assert object_0 == temp_string_1


# Generated at 2022-06-26 01:43:28.791368
# Unit test for function booleanize
def test_booleanize():
    string_compressor_1 = __StringCompressor()
    assert string_compressor_1.booleanize('true') == True
    assert string_compressor_1.booleanize('yes') == True
    assert string_compressor_1.booleanize('false') == False
    assert string_compressor_1.booleanize('FALSe') == False
    assert string_compressor_1.booleanize('0') == False
    assert string_compressor_1.booleanize('1') == False


# Generated at 2022-06-26 01:43:38.815094
# Unit test for function compress
def test_compress():
    # In this test we will check if a normal text can be compressed, then decompressed correctly
    # and if the compressed text can be compressed again
    test_string = 'abcdefghijklmnopqrstuvwxyz'
    compress_string = compress(test_string)
    print('\nCompressed string:')
    print(compress_string)
    decompress_string = decompress(compress_string)
    print('\nDecompressed string:')
    print(decompress_string)
    compress_again_string = compress(compress_string)
    print('\nCompress again:')
    print(compress_again_string)


# Generated at 2022-06-26 01:43:41.051912
# Unit test for function shuffle
def test_shuffle():

    assert shuffle("abcd efgh ijkl mnop") == "fhbgp ci ojnakldem"


# Generated at 2022-06-26 01:43:45.213480
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3999) == 'MMMCMXCIX'

# Generated at 2022-06-26 01:43:50.607344
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
    line 1
    line 2
    line 3
    '''
    output_string = strip_margin(input_string)
    print(output_string)
    assert output_string == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-26 01:43:51.677840
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    test_case_0()


# Generated at 2022-06-26 01:43:58.344709
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    string_compressor_0 = __StringCompressor()
    assert camel_case_to_snake( 'ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake( 'ThisIsACamelStringTest', '^') == 'this^is^a^camel^string^test'




# Generated at 2022-06-26 01:44:00.023866
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    snake_case_0 = camel_case_to_snake("camelCase")
    return (snake_case_0 == "camel_case") and (type(snake_case_0) is str)


# Generated at 2022-06-26 01:44:11.950445
# Unit test for function booleanize
def test_booleanize():
    # Tests to be passed
    print("test_booleanize:", end=" ")
    test_outputs = [True, True, True, True, True, True, True, True, True, True, True, True, True, True,
                    True, True, True, True, False, False, False, False, False, False, False, False, False, False, False,
                    False, False, False, False, False, False, False, False, False, False, False, False, False, False,
                    False, False, False, False, False, False, False, False, False, False, False, False, False, False,
                    False, False, False, False, False, False, False, False, False, False, False, False, False, False,
                    False]

# Generated at 2022-06-26 01:44:16.192971
# Unit test for function strip_html
def test_strip_html():
    input_string = \
        '<p>Python does not have the support for the Databases built-in. But it has the <b>sqlite3</b> module to connect with the SQLite database. We can use the <b>execute()</b> method of the <b>MySQLCursor</b> class, to execute any MySQL query statements. We can use the <b>fetchall()</b> method to fetch all rows at once, fetchone() method reads only one row, and <b>fetchmany()</b> method reads one or more rows. To update data we use the <b>execute()</b> method with the <b>UPDATE</b> query statement.</p>\n'
    print('TestCase 0: Input String = ')
    print(input_string)
    output_string = strip_html(input_string)


# Generated at 2022-06-26 01:44:24.625759
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    tests = [('snake_is_green', 'snakeIsGreen', False),
             ('the_snake_is_green', 'TheSnakeIsGreen', True),
             ('the__snake_is_green', 'TheSnakeIsGreen', True),
             ('the_snake_is_green__', 'TheSnakeIsGreen', True),
             ('the_snake_is_green_', 'TheSnakeIsGreen', True),
             ('the _snake_is_green', 'TheSnakeIsGreen', True)
             ]

    for test in tests:
        message = 'Error in test_snake_case_to_camel. Expected "{}" but got "{}"'.format(test[1], snake_case_to_camel(test[0]))

# Generated at 2022-06-26 01:44:28.074599
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter("This is just a string")
    assert __StringFormatter("123")
    assert not __StringFormatter(123)
    try:
        __StringFormatter(123)
    except InvalidInputError as err:
        assert str(err) == 'Invalid input: expected "str", got "int"'
    assert not __StringFormatter(None)
    try:
        __StringFormatter(None)
    except InvalidInputError as err:
        assert str(err) == 'Invalid input: expected "str", got "NoneType"'


# Generated at 2022-06-26 01:44:30.632521
# Unit test for function shuffle
def test_shuffle():
    # test with empty string
    assert shuffle("") == "", "Empty string test"

    # test with string with only one char
    assert shuffle("t") == "t", "One char string test"

    # test with string with only two chars
    assert shuffle("tt") != "tt", "Two chars string test"

    # test with string with more than two chars
    assert shuffle("tester") != "tester", "More than two chars string test"


# Generated at 2022-06-26 01:44:31.331770
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    __StringFormatter("SAM")


# Generated at 2022-06-26 01:44:35.382347
# Unit test for function strip_margin
def test_strip_margin():
    # Test case #0
    print("Test case #0:")
    expected_output = "\n" + "line 1" + "\n" + "line 2" + "\n" + "line 3" + "\n"

    margin = "\n" + "    "
    input_string = "    line 1" + margin + "    line 2" + margin + "    line 3" + margin
    print("Input string: " + input_string)
    print("Expected output: " + expected_output)

    output = strip_margin(input_string)
    print("Output: " + output)

    if output == expected_output:
        print("PASSED")
    else:
        print("FAILED")
        print("Expected: " + expected_output)
        print("Output: " + output)


# Generated at 2022-06-26 01:44:42.780272
# Unit test for function roman_decode
def test_roman_decode():
    # Test 1: expected output 2000
    input_string_roman_decode = "MM"
    output_roman_decode = roman_decode(input_string_roman_decode)
    print("\nValue: ", output_roman_decode)

    # Test 2: expected output -1
    input_string_roman_decode = "VV"
    output_roman_decode = roman_decode(input_string_roman_decode)
    print("\nValue: ", output_roman_decode)


# Generated at 2022-06-26 01:44:53.613330
# Unit test for function reverse
def test_reverse():
    # 1 test cases
    assert (reverse('0') == '0')  # 1st test case


# Generated at 2022-06-26 01:44:57.895918
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '*') == 'this*is*a*camel*string*test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '') == 'thisisaCamelStringTest'
    assert camel_case_to_snake('ThisIsACamelStringTest', '  ') == 'this  is  a  camel  string  test'
    assert camel_case_to_snake(123, '*') == '123'



# Generated at 2022-06-26 01:45:03.467419
# Unit test for function slugify
def test_slugify():
    input_string_0 = 'Top 10 Reasons To Love Dogs!!!'
    expected_output_0 = 'top-10-reasons-to-love-dogs'
    output_0 = slugify(input_string_0)
    print("input_string_0: " + input_string_0)
    print("output_0: " + output_0)
    print("expected_output_0: " + expected_output_0)

    input_string_1 = 'Mönstér Mägnët'
    expected_output_1 = 'monster-magnet'
    output_1 = slugify(input_string_1)
    print("input_string_1: " + input_string_1)
    print("output_1: " + output_1)

# Generated at 2022-06-26 01:45:07.265911
# Unit test for function decompress
def test_decompress():
    assert 'test' == decompress(compress('test'))
    assert 'test test' == decompress(compress('test test'))
    assert 'test test test' == decompress(compress('test test test'))


# Generated at 2022-06-26 01:45:12.518254
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print("Test Case: snake_case_to_camel")
    string_compressor_0 = __StringCompressor()
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'


# Generated at 2022-06-26 01:45:13.314522
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'd rhllelowo'


# Generated at 2022-06-26 01:45:25.742161
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('1.    http://www.google.it   ').format() == '1. http://www.google.it'
    assert __StringFormatter('2.test@test.test       ').format() == '2.test@test.test'
    assert __StringFormatter('3.: )').format() == '3.: )'
    assert __StringFormatter('4.: ( : : : :     ').format() == '4.: (:):::'
    assert __StringFormatter('5.     ').format() == '5.'
    assert __StringFormatter('5.     go home').format() == '5.go home'
    assert __StringFormatter('6.    go    home').format() == '6.go home'

# Generated at 2022-06-26 01:45:27.408005
# Unit test for function roman_encode
def test_roman_encode():

    # Test string
    test_string = '2020'

    #Test expected value
    expected_value = 'MMXX'
    assert roman_encode(test_string) == expected_value


# Generated at 2022-06-26 01:45:39.628648
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert 'MMMCMXCIX' == __RomanNumbers.encode(3999)
    assert 3999 == __RomanNumbers.decode('MMMCMXCIX')

    try:
        __RomanNumbers.encode('invalid')
        raise AssertionError('Should not reach this line')
    except ValueError as e:
        assert 'Invalid input, only strings or integers are allowed' == str(e)

    try:
        __RomanNumbers.encode(4000)
        raise AssertionError('Should not reach this line')
    except ValueError as e:
        assert 'Input must be >= 1 and <= 3999' == str(e)


# Generated at 2022-06-26 01:45:45.149121
# Unit test for function shuffle
def test_shuffle():
    try:
        print(shuffle('hello world'))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_shuffle()
    exit(0)

# Generated at 2022-06-26 01:46:03.555191
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("XIV") == 14


# Generated at 2022-06-26 01:46:12.088305
# Unit test for function reverse
def test_reverse():
    # test case 1
    input_string_1 = "abcdef"
    expected_output_1 = "fedcba"
    actual_output_1 = reverse(input_string_1)
    print("test case 1:", end='')
    print("pass" if actual_output_1 == expected_output_1 else "fail")

    # test case 2
    input_string_2 = "zyxwvutsrqponmlkjihgfedcba"
    expected_output_2 = "zyxwvutsrqponmlkjihgfedcba"
    actual_output_2 = reverse(input_string_2)
    print("test case 2:", end='')
    print("pass" if actual_output_2 == expected_output_2 else "fail")


# Generated at 2022-06-26 01:46:15.136297
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('Hello world') != 'Hello world'
    assert is_string(shuffle('Hello world'))
    print('shuffle: pass')

test_shuffle()


# Generated at 2022-06-26 01:46:26.752008
# Unit test for function prettify
def test_prettify():
    # Input strings
    test_string_0 = "unprettified string ,, like this one,will be\"prettified\" .it\' s awesome! "
    test_string_1 = " unprettified string ,, like this one,will be\"prettified\" .it\' s awesome! "
    test_string_2 = "unprettified - string ,, like this one,will be\"prettified\" .it\' s awesome! "
    test_string_3 = "unprettified+string ,, like this one,will be\"prettified\" .it\' s awesome! "
    test_string_4 = "unprettified_string ,, like this one,will be\"prettified\" .it\' s awesome! "

# Generated at 2022-06-26 01:46:31.738709
# Unit test for function slugify
def test_slugify():
    '''
    Unit test for function slugify

    Sample usage:
        >>> test_slugify() # ->
        1 tests passed
        0 tests failed
    '''
    print("Testing function slugify...")

    tests_passed = 0
    tests_failed = 0

    if slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs':
        tests_passed += 1
    else:
        tests_failed += 1

    if slugify("Mönstér Mägnët") == 'monster-magnet':
        tests_passed += 1
    else:
        tests_failed += 1

    print("{} tests passed".format(tests_passed))
    print("{} tests failed".format(tests_failed))


# Generated at 2022-06-26 01:46:34.703849
# Unit test for function roman_encode
def test_roman_encode():
    try:
        assert (roman_encode(37) == "XXXVII"), "37 fails roman_encode"
        assert (roman_encode("2020") == "MMXX"), "2020 fails roman_encode"
        assert (roman_encode("0") == "")
        print("Test cases for roman_encode passed")
    except AssertionError as e:
        print("Test cases for roman_encode failed")
        print(e)


# Generated at 2022-06-26 01:46:37.505005
# Unit test for function decompress
def test_decompress():
    string = "A simple string"
    compressed_string = compress(string)
    decompressed_string = decompress(compressed_string)
    assert(string == decompressed_string)


# Generated at 2022-06-26 01:46:38.556485
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1


# Generated at 2022-06-26 01:46:41.217946
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    string_formatter_0 = __StringFormatter("")
    string_formatter_1 = __StringFormatter("hello")
    string_formatter_2 = __StringFormatter("hello world")



# Generated at 2022-06-26 01:46:43.977965
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter("not a valid string")
    except Exception as e:
        assert type(e) == InvalidInputError
    assert __StringFormatter("String Formatter")


# Generated at 2022-06-26 01:47:26.318238
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Test case for when the input_string is empty
    if camel_case_to_snake('') != '':
        print('Failed test case 0 for function camel_case_to_snake')
        return
    # Test case for when the input_string is not camel case
    if camel_case_to_snake('This is a camel string test') != 'This is a camel string test':
        print('Failed test case 1 for function camel_case_to_snake')
        return
    # Test case for when the input_string is camel case
    if camel_case_to_snake('ThisIsACamelStringTest') != 'this_is_a_camel_string_test':
        print('Failed test case 2 for function camel_case_to_snake')
        return
    # Test case for when the input_

# Generated at 2022-06-26 01:47:36.421746
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    test_case_0()
    # Test cases for snake_case_to_camel
    print("\nTest Cases for function snake_case_to_camel")
    string_compressor_0 = __StringCompressor()
    print("\tThe snake case string 'the_snake_is_green' is converted to the camel case string 'TheSnakeIsGreen'")
    if string_compressor_0.snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen':
        print("\tTest case 0: PASS")
    else:
        print("\tTest case 0: FAIL")
    print("\tThe snake case string 'the_snake_is_green' is converted to the camel case string 'TheSnakeIsGreen'")

# Generated at 2022-06-26 01:47:46.039531
# Unit test for function slugify
def test_slugify():
    test_case = [
        ("Top 10 Reasons To Love Dogs!!!", "top-10-reasons-to-love-dogs"),
        ("Mönstér Mägnët", "monster-magnet"),
        ("    space", "space"),
        ("1.2.3.4", "1.2.3.4"),
        ("test", "test"),
        ("1.test", "1.test"),
        ("test.", "test"),
        ("test ", "test")
    ]
    for input_string, expected in test_case:
        result = slugify(input_string)
        assert result == expected, "Failed for input={}".format(input_string)
    print("Test case for function slugify passed")


# Generated at 2022-06-26 01:47:55.552876
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    string_compressor = __StringCompressor()
    string_compressor_0 = __StringCompressor()
    result1 = camel_case_to_snake('ThisIsACamelStringTest')
    result2 = camel_case_to_snake('ThisIsCamel1And2Snakes')
    result3 = camel_case_to_snake('ThisIsCamel1And2Snakes3')
    assert result1 == 'this_is_a_camel_string_test'
    assert result2 == 'this_is_camel1_and2_snakes'
    assert result3 == 'this_is_camel1_and2_snakes3'



# Generated at 2022-06-26 01:47:57.469820
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    test_case_0()


# PUBLIC FUNCTIONS


# Generated at 2022-06-26 01:48:10.428993
# Unit test for function decompress

# Generated at 2022-06-26 01:48:25.656216
# Unit test for function strip_html
def test_strip_html():
    # Test 1 of strip_html
    xml_string = '''<book store="amazon">
  <title lang="it" originalLang="us" language="english">
    <h1>Test title</h1>
    <h2>Test subtitle</h2>
  </title>
  <author>
    <first-name>Mark</first-name>
    <last-name>Twain</last-name>
  </author>
</book>
'''
    string_compressor_0 = __StringCompressor()
    string_compressor_0_output_string = string_compressor_0.decompress(string_compressor_0.compress(xml_string))
    assert string_compressor_0_output_string == xml_string, 'Expected: ' + xml_string + '. Received: ' + string

# Generated at 2022-06-26 01:48:34.925153
# Unit test for function prettify
def test_prettify():
    # Test 1
    test_str_1 = 'unprettified string ,, like this one,will be"prettified" .it\\' "s awesome! "

    # Test 2
    test_str_2 = 'unprettified string ,, like this one,will "be"prettified" .it\\' "s awesome! "

    # Test 3
    test_str_3 = 'unprettified  string ,, like this one,will "be" prettified" .it\\' "s awesome! "

    # Test 4
    test_str_4 = 'unprettified  string ,, like this one,will "be" prettified".it\\' "s awesome! "

    # Test 5
    test_str_5 = 'prettified string ? is it really ?'

    # Test 6
    test_str

# Generated at 2022-06-26 01:48:36.913587
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter("pippo")
    except Exception as exc:
        print(exc)



# Generated at 2022-06-26 01:48:42.573669
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'

