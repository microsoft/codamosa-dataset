

# Generated at 2022-06-26 01:42:00.627940
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(input_string = str_0, upper_case_first = True, separator = '_')
    assert str_1 == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:42:09.017982
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:42:19.271071
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Running Unit Test for function snake_case_to_camel')
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('1') == '1'
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', False) == 'test'
    assert snake_case_to_camel('this_snake_case_string', True, '_') == 'ThisSnakeCaseString'
    assert snake_case_to_camel('this_snake_case_string', False, '_') == 'thisSnakeCaseString'
    assert snake_case_to_camel('this_snake_case_string', True, '-') == 'ThisSnakeCaseString'
    assert snake_case_to_camel

# Generated at 2022-06-26 01:42:23.378208
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='|') == 'the_snake_is_green'
    assert snake_case_to_camel('TheSnakeIsGreen', separator='|') == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:42:28.771942
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'a string with    some spaces  and  duplicates'
    str_1 = 'A string with some spaces and duplicates'

    sf = __StringFormatter(str_0)
    str_2 = sf.format()
    if str_2 != str_1:
        raise Exception('Formatted value does not match expected value', str_1, str_2)


# Generated at 2022-06-26 01:42:42.311390
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('a') == 'A'  # Boundary Case 1
    assert snake_case_to_camel('ab') == 'Ab' # Boundary Case 2
    assert snake_case_to_camel('abc') == 'Abc' # Boundary Case 3
    assert snake_case_to_camel('abC') == 'AbC' # Boundary Case 4
    assert snake_case_to_camel('aBc') == 'ABc' # Boundary Case 5
    assert snake_case_to_camel('aBC') == 'ABC' # Boundary Case 6
    assert snake_case_to_camel('a_bc') == 'ABc' # Boundary Case 7

# Generated at 2022-06-26 01:42:44.835774
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(str_0)
    print(str_1)


# Generated at 2022-06-26 01:42:52.312812
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Function arguments
    str_0 = 'the_snake_is_green'
    str_1 = 'TheSnakeIsGreen'
    str_2 = 'The_snake_is_green'
    str_3 = 'the_snake_is_green'
    str_4 = 'the_snake_Is_green'

    # Call function
    str_5 = snake_case_to_camel(str_0)
    str_6 = snake_case_to_camel(str_0, upper_case_first=False)
    str_7 = snake_case_to_camel(str_0, upper_case_first=True, separator='-')
    str_8 = snake_case_to_camel(str_0, upper_case_first=False, separator='-')
    str_

# Generated at 2022-06-26 01:42:57.890812
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:43:05.390643
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:19.047163
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # For example the string 
    #     the  "  the the "hello" (world)
    # will be transformed into
    #     The "the the" "hello" (world)
    str_ = "the  'the the' \"hello\" (world)"
    assert __StringFormatter(str_).format() == "The 'the the' \"hello\" (world)"


# Generated at 2022-06-26 01:43:26.998683
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test case 0
    str_0 = '^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$'
    str_1 = slugify(str_0)
    str_2 = __StringFormatter(str_1).format()

    if str_2 != '^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$':
        raise ValueError("Unexpected output of method __StringFormatter.format, method result is: " + str_2)

    # Test case 1
    str_0 = 'ab  c  d'
    str_1 = __StringFormatter(str_0).format()


# Generated at 2022-06-26 01:43:39.182046
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    input_string = '    hello, this is a test. i hope it works!... :) 12345'
    expected_string = 'Hello, this is a test. I hope it works!... :) 12345'
    assert expected_string == __StringFormatter(
        input_string).format()

    input_string = 'this is a test - i hope   it  works!... :) @ ttt@test.tt  ' \
                   'https://hello.my-domain.com/my/path?param1=test:test&test=test#test'
    expected_string = 'This is a test - I hope it works!... :) @ ttt@test.tt ' \
                      'https://hello.my-domain.com/my/path?param1=test:test&test=test#test'

# Generated at 2022-06-26 01:43:53.036122
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:58.374079
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    testcases = {
        'test_case_0': test_case_0,
    }

    import timeit
    for key in testcases:
        print(key, '\n', timeit.timeit(stmt=testcases[key], number=100))
    # out = __StringFormatter('test case 5').format()
    # print(out)



# Generated at 2022-06-26 01:44:03.256857
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('one two'              ).format() == 'One two'
    assert __StringFormatter('ONE two'              ).format() == 'One two'
    assert __StringFormatter('ONE TWO'              ).format() == 'One two'
    assert __StringFormatter('ONE two THREE'        ).format() == 'One two three'
    assert __StringFormatter('ONE two THREE FOUR'   ).format() == 'One two three four'
    assert __StringFormatter('ONE two  THREE'       ).format() == 'One two three'
    assert __StringFormatter(' ONE two'             ).format() == 'One two'
    assert __StringFormatter('ONE two '             ).format() == 'One two'
    assert __StringFormatter(' ONE two 123-456-789' ).format() == 'One two 123-456-789'


# Generated at 2022-06-26 01:44:07.300690
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_00 = 'Teddy''s Bear          '
    str_01 = 'Teddy''s Bear'
    str_10 = __StringFormatter(str_00).format()
    assert str_00 == str_10

# Generated at 2022-06-26 01:44:10.279852
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    obj_strFormatter = __StringFormatter("IPv4 with four decimal integers, from 0 to 255, separated by periods (example: 192.168.1.1)")
    obj_strFormatter.format()


# Generated at 2022-06-26 01:44:15.733104
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    with open(__file__, "r") as f:
        content = f.read()
        out = __StringFormatter(content).format()
        # print(out)
    # assert len(out) > 0
    # assert len(out) == len(content)


# PUBLIC API



# Generated at 2022-06-26 01:44:24.234828
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:44:36.868995
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'test'
    str_1 = '  test '
    str_2 = ' test  '
    str_3 = '  test  '
    str_4 = '  t  e s t  '
    str_5 = 'tEst'
    str_6 = 'Test'
    str_7 = 'test test'
    str_8 = 'test test '
    str_9 = ' test test'
    str_10 = ' test test '
    str_11 = ' test  test '
    str_12 = ' test  test  '
    str_13 = ' test  test   test'
    str_14 = '  test  test   test  '
    str_15 = '  test  test   test   test  '
    str_16 = '  test  test     test   test  '


# Generated at 2022-06-26 01:44:40.524321
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'Hello world'
    str_1 = __StringFormatter(str_0).format()
    str_2 = 'Hello world'
    assert str_1 == str_2


# Generated at 2022-06-26 01:44:47.374151
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # 1
    str_1 = '!@#$%^&*()_+1234567890- ={}[]\|;:\'"<>?,./`~asdferteg'
    str_2 = ' ! @ # $ % ^ & * ( ) _ + 1234567890 - = {   } [   ]         ; \ : \ \'   " < > ? , . / ` ~ asdferteg '
    str_1 = __StringFormatter(str_1).format()
    assert str_1 == str_2
    # 2
    str_1 = 'ciao  come stai?'
    str_2 = 'Ciao come stai ?'
    str_1 = __StringFormatter(str_1).format()
    assert str_1 == str_2
    # 3

# Generated at 2022-06-26 01:44:53.362703
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'a simple sentence with  ,  duplicates &^*%$#@!"£$%^&*()   ,   and special characters'
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == 'A simple sentence with, duplicates, and special characters'


# PUBLIC API



# Generated at 2022-06-26 01:45:05.461196
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:45:11.556296
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0="""
    -The quick brown fox
    jumps over the lazy dog
    ."""
    str_1= __StringFormatter(str_0).format()
    str_2 = """The quick brown fox jumps over the lazy dog."""

    assert str_1 == str_2
    #print(str_1)



# Generated at 2022-06-26 01:45:22.874793
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = '<div ><b><a title="a&amp;b" href="https://www.a.it">a&b</a></b></div>'
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == '<div><b><a title="a&b" href="https://www.a.it">a&b</a></b></div>'

    str_0 = '<a title="a&amp;b" href="https://www.a.it">a&b</a>'
    str_1 = __StringFormatter(str_0).format()
    assert str_1 == '<a title="a&b" href="https://www.a.it">a&b</a>'


# Generated at 2022-06-26 01:45:32.690704
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:45:42.331904
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # out_0 should be equal to out_2
    out_0 = __StringFormatter(' abc  def   ghi ').format()
    out_1 = __StringFormatter(' abc  def   ghi').format()
    str_out_1 = 'abc def ghi'
    out_2 = __StringFormatter('abc def ghi').format()
    out_3 = __StringFormatter(' abc  def  -  ghi ').format()
    str_out_3 = 'abc def - ghi'
    out_4 = __StringFormatter(' abc  def-  ghi ').format()
    str_out_4 = 'abc def- ghi'
    out_5 = __StringFormatter(' abc  def  -ghi ').format()

# Generated at 2022-06-26 01:45:52.867457
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_0 = 'I am a  string'
    str_1 = '+39-345-0000001'
    str_2 = 'https://github.com'
    str_3 = 'https://github.com/sadjad'
    str_4 = 'https://github.com/sadjad/pytoolbox'
    str_5 = 'https://github.com/sadjad/pytoolbox '
    str_6 = '  https://github.com/sadjad/pytoolbox'
    str_7 = 'https://github.com/sadjad/pytoolbox'
    str_8 = ' http://github.com/sadjad/pytoolbox '
    str_9 = 'I am a  string'
    str_10 = 'I am a string'

# Generated at 2022-06-26 01:46:13.550926
# Unit test for function reverse
def test_reverse():
    string_to_reverse = "hello"
    assert reverse(string_to_reverse) == "olleh", "Error in function reverse"


# Generated at 2022-06-26 01:46:22.399591
# Unit test for function roman_decode
def test_roman_decode():
    roman_numbers_1 = __RomanNumbers()
    roman_numbers_1.decode('XXXVII')
    roman_numbers_1.decode('MMMM')
    roman_numbers_1.decode('C')
    roman_numbers_1.decode('CCCC')
    roman_numbers_1.decode('CCCCL')
    roman_numbers_1.decode('CCCCC')
    roman_numbers_1.decode('CCCCD')
    roman_numbers_1.decode('I')
    roman_numbers_1.decode('II')
    roman_numbers_1.decode('III')
    roman_numbers_1.decode('IIII')
    roman_numbers_1.decode

# Generated at 2022-06-26 01:46:23.866635
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7


# Generated at 2022-06-26 01:46:29.509599
# Unit test for function shuffle
def test_shuffle():
    string_1 = 'hello world'
    list_1 = list(string_1)
    list_2 = shuffle(string_1)
    assert list_1 is not  list_2


# Generated at 2022-06-26 01:46:36.577907
# Unit test for function strip_html
def test_strip_html():
    input_string = "This is a <a href='www.google.com'>test</a>"
    result = strip_html(input_string)
    assert result == "This is a "

    input_string = "This is a <a href='www.google.com'>test</a>"
    result = strip_html(input_string,keep_tag_content=True)
    assert result == "This is a test"


# Generated at 2022-06-26 01:46:39.551792
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    print("Unit test for function camel_case_to_snake is PASSED")

test_camel_case_to_snake()



# Generated at 2022-06-26 01:46:42.862870
# Unit test for function prettify

# Generated at 2022-06-26 01:46:51.386981
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    if not snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen":
        return False
    if not snake_case_to_camel("the_snake_is_green", False) == "theSnakeIsGreen":
        return False
    if not snake_case_to_camel("the-snake-is-green", False, "-") == "theSnakeIsGreen":
        return False
    if not snake_case_to_camel("the-snake-is-green", False, "_-") == "TheSnakeIsGreen":
        return False

    return True


# Generated at 2022-06-26 01:46:58.719168
# Unit test for function booleanize
def test_booleanize():
    assert_equal(booleanize('true'), True)
    assert_equal(booleanize('TRUE'), True)
    assert_equal(booleanize('1'), True)
    assert_equal(booleanize('yes'), True)
    assert_equal(booleanize('Y'), True)
    assert_equal(booleanize('Nope'), False)
    try:
        booleanize(12)
    except TypeError:
        pass




# Generated at 2022-06-26 01:47:05.109880
# Unit test for function strip_html
def test_strip_html():
    print(strip_html('<p>Test</p>'))
    print(strip_html('<p>Test</p>', True))
    print(strip_html('<p>Test</p><div> <a href="foo/bar">click here</a> </div>', True))
    print(strip_html('<p>Test</p><div> <a href="foo/bar">click here</a> </div>', False))
    print(strip_html('<p>Test</p><div> <a href="foo/bar">click here</a> </div>'))
    print(strip_html('<p>Test</p><div> <a href="foo/bar">click here</a> </div>'))


# Generated at 2022-06-26 01:47:34.885496
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_string = '---Test_String--'
    __StringFormatter(input_string)


# Generated at 2022-06-26 01:47:38.324799
# Unit test for function roman_encode
def test_roman_encode():
    # Zero is rejected
    try:
        roman_encode(0)
    except ValueError:
        pass
    # 4000 is rejected
    try:
        roman_encode(4000)
    except ValueError:
        pass
    # String conversion
    assert roman_encode('3') == 'III'
    # String with spaces
    assert roman_encode('   3') == 'III'
    # Test with negative number
    try:
        roman_encode(-3)
    except ValueError:
        pass
    # Test with float
    try:
        roman_encode(2.2)
    except ValueError:
        pass

# Generated at 2022-06-26 01:47:40.056813
# Unit test for function decompress
def test_decompress():
    string = "Yoann"
    assert(decompress(compress(string)) == string)


# Generated at 2022-06-26 01:47:41.679043
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''


# Generated at 2022-06-26 01:47:43.673490
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    str_compressor_0 = __StringCompressor()

# Unit tests for methods encode() and decode() of class __RomanNumbers

# Generated at 2022-06-26 01:47:50.490790
# Unit test for function roman_encode
def test_roman_encode():
    """
    *Tests*
    - test all numbers from 1-3999
    - test all exceptions
    :return:
    """
    # test all numbers from 1-3999
    for i in range(1,4000):
        exp_result = __RomanNumbers.encode(i)
        act_result = i.to_roman_numbers()
        assert exp_result == act_result
    # test all exceptions
    with pytest.raises(InvalidInputError):
        __RomanNumbers.encode(0)
    with pytest.raises(InvalidInputError):
        __RomanNumbers.encode(4000)
    with pytest.raises(InvalidInputError):
        __RomanNumbers.encode('asd')



# Generated at 2022-06-26 01:48:04.408381
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    string_formatter1 = __StringFormatter('this is a test')
    string_formatter2 = __StringFormatter('another test')
    string_formatter3 = __StringFormatter('A nymber of cases')
    string_formatter4 = __StringFormatter('Abbreviations like: E.T.A.')
    string_formatter5 = __StringFormatter('We are a team of developers')
    string_formatter6 = __StringFormatter('Test for double spaces')
    string_formatter7 = __StringFormatter('Test for single characters separated by spaces')
    string_formatter8 = __StringFormatter('Multiple spaces')
    string_formatter9 = __StringFormatter('Saxon genitive')
    string_formatter10 = __StringFormatter('Another Saxon genitive')

# Generated at 2022-06-26 01:48:12.950166
# Unit test for function reverse
def test_reverse():
    # Test 1
    assert reverse('hello') == 'olleh'
    # Test 2
    assert reverse('abcd') == 'dcba'
    # Test 3
    assert reverse('12345') == '54321'
    # Test 4
    assert reverse('hello, world') == 'dlrow ,olleh'
    # Test 5
    assert reverse('hello, world!') == '!dlrow ,olleh'
    # Test 6
    assert reverse('abcdefg') == 'gfedcba'
    # Test 7
    assert reverse('abcdefghij') == 'jihgfedcba'
    # Test 8
    assert reverse('abcd efgh ijkl mnop') == 'ponm lkji hgfe dcba'
    # Test 9

# Generated at 2022-06-26 01:48:14.199057
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-26 01:48:19.037357
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor() is not None
