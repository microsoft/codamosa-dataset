

# Generated at 2022-06-26 01:42:08.557796
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('  aB   C d e F g H i    ')
    string_formatter_0.format()

# PUBLIC API



# Generated at 2022-06-26 01:42:19.705447
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter("foo")
    assert("Foo" == string_formatter_0.format())

    string_formatter_1 = __StringFormatter("foo bar")
    assert("Foo Bar" == string_formatter_1.format())

    string_formatter_2 = __StringFormatter("foo bar&")
    assert("Foo Bar&" == string_formatter_2.format())

    string_formatter_3 = __StringFormatter("foo bar!")
    assert("Foo Bar!" == string_formatter_3.format())

    string_formatter_4 = __StringFormatter("foo bar?")
    assert("Foo Bar?" == string_formatter_4.format())

    string_formatter_5 = __StringFormatter("foo,bar")

# Generated at 2022-06-26 01:42:31.353859
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    """
    Unit test for the method format of class __StringFormatter

    Returns:
        None
    """
    print("\nTesting __StringFormatter.format\n")
    print('\n-- Test case 0 (empty string)')
    try:
        print('\n--- Running main test\n')
        test_string_formatter_0 = __StringFormatter('')
    except InvalidInputError as e:
        print('InputError: ' + str(e))
    except:
        print('UnknownError')

    print('\n-- Test case 1 (non empty string)')

# Generated at 2022-06-26 01:42:43.926066
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string_0 = """   mr smith &  dr.fred   brown   """
    test_string_1 = """   MRS    BONNIE  WELLS-BROWN &  dr.fred   brown   """
    test_string_2 = """   MRS    BONNIE  WELLS-BROWN &  dr.fred   brown   """
    test_string_3 = """   MRS    BONNIE  WELLS-BROWN &  DR.FRED   brown   """
    test_string_4 = """   MR   "DAVID"  SMITH    &  DR.FRED   brown   """
    test_string_5 = """   MR   "DAVID"  SMITH    &  DR.FRED   BROWN   """

# Generated at 2022-06-26 01:42:55.970391
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print("\n--- Test method format of class __StringFormatter ---")
    class_obj = __StringFormatter("This is a Test1")
    out = class_obj.format()
    print("Input string: " + "This is a Test1")
    print("Output string: " + out)
    class_obj = __StringFormatter("This     is    a Test2")
    out = class_obj.format()
    print("Input string: " + "This     is    a Test2")
    print("Output string: " + out)
    class_obj = __StringFormatter("This is   a Test3")
    out = class_obj.format()
    print("Input string: " + "This is   a Test3")
    print("Output string: " + out)

# Generated at 2022-06-26 01:43:08.363147
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('ciao').format() == 'Ciao'
    assert __StringFormatter('storia della musica').format() == 'Storia della musica'
    assert __StringFormatter('"La mia fantasia è più folle di una  storia di flipper"').format() == '"La mia fantasia è più folle di una storia di flipper"'
    assert __StringFormatter('pettini e    trombe').format() == 'Pettini e trombe'
    assert __StringFormatter('i cieli ombrosi').format() == 'I cieli ombrosi'
    assert __StringFormatter('è il merlo   canterino').format() == 'È il merlo canterino'

# Generated at 2022-06-26 01:43:09.930133
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("    hello    world    ").format() == "Hello World"



# Generated at 2022-06-26 01:43:22.175194
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('A test string').format() == 'A test string'
    assert __StringFormatter('the string').format() == 'The string'
    assert __StringFormatter('The string').format() == 'The string'
    assert __StringFormatter('the string?').format() == 'The string?'
    assert __StringFormatter('the string!').format() == 'The string!'
    assert __StringFormatter('the string.').format() == 'The string.'
    assert __StringFormatter('the string!').format() == 'The string!'
    assert __StringFormatter('Ending with blank space ').format() == 'Ending with blank space'
    assert __StringFormatter('ending with a blank space ').format() == 'Ending with a blank space'
    assert __StringFormatter('starting with a blank space ').format()

# Generated at 2022-06-26 01:43:33.692431
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Setup
    input_string_0 = 'the $quick   brown fox jumps over the lazy dog ...'

# Generated at 2022-06-26 01:43:44.132469
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:44:07.256921
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test 1
    test_string_1 = "facebook inc."
    test_string_1_expected_output = "Facebook Inc."
    string_formatter_1 = __StringFormatter(test_string_1)
    string_formatter_1_output = string_formatter_1.format()
    if string_formatter_1_output != test_string_1_expected_output:
        raise ValueError("Bad test 1 result: " + string_formatter_1_output)
    # Test 2
    test_string_2 = "---   t  h   i   s  is  a   t e   s   t  ---"
    test_string_2_expected_output = "This is a test"
    string_formatter_2 = __StringFormatter(test_string_2)
    string_formatter_2

# Generated at 2022-06-26 01:44:11.798314
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string_0 = '$A$A$'
    test_obj_0 = __StringFormatter(input_string_0)
    out_0 = test_obj_0.format()
    assert out_0 == '$A$A$'
    input_string_1 = ' $Aa$a!!$'
    test_obj_1 = __StringFormatter(input_string_1)
    out_1 = test_obj_1.format()
    assert out_1 == '$Aa$a$'


# PUBLIC API



# Generated at 2022-06-26 01:44:22.018360
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    a = '  asd   Vvvv   adf   werew     asdf'
    b = __StringFormatter(a)
    c = b.format()

    print(a)
    print(c)

    a = '   <    ht    t    p    :    /    /    w    w    w    .     g    o    o    gl    e    .    c    o    m    /    >'
    b = __StringFormatter(a)
    c = b.format()

    print(a)
    print(c)

    a = '    as    d    V    v    v    v    a    d    f    w    e    r    e    w    a    s    d    f'
    b = __StringFormatter(a)
    c = b.format()


# Generated at 2022-06-26 01:44:27.118138
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string_0 = __StringFormatter('  my name is lorenzo  gasparini .  this is a test .   ')
    test_string_1 = __StringFormatter('my name is lorenzo gasparin. this is a test.')
    test_string_2 = __StringFormatter('my name is lorenzo gasparini. this is a test.')
    test_string_3 = __StringFormatter('my name is lorenzo gasparini. this is a test. A good test!')
    test_string_4 = __StringFormatter('my name is lorenzo gasparini. this is a test. A good test! [email@email.com] [http://google.com]')

    assert test_string_0.format() == 'My name is Lorenzo Gasparini. This is a test.'
   

# Generated at 2022-06-26 01:44:33.166507
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  i  am a    test   case with   an   example   ').format() == 'I am a test case with an example'
    assert __StringFormatter('i       am a. test case.with an,example').format() == 'I am a. test case.with an,example'
    assert __StringFormatter('iamatestcase witanexample').format() == 'Iamatestcase witanexample'
    assert __StringFormatter('i\'amd ap test case withan example').format() == 'I\'am a p test case with an example'
    assert __StringFormatter('this is a test\'s case').format() == 'This is a test\'s case'
    assert __StringFormatter('thisisatestcase').format() == 'Thisisatestcase'

# Generated at 2022-06-26 01:44:35.699004
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # TODO: implement unit tests for this method
    sf = __StringFormatter('ciao bello')
    sf.format()

# TESTING
#if __name__ == '__main__':
#    __create_lookup_tables()
#    __create_translation_tables()
#    test()

# PUBLIC API


# Generated at 2022-06-26 01:44:45.255166
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:44:57.648830
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")

# Generated at 2022-06-26 01:45:07.903349
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # Test scenario 1: test normal function
    string_formatter_1 = __StringFormatter('O\'Hara')
    print('unit test: normal function, input \"O\'Hara\", output \"' + string_formatter_1.format() + '\"')

    # Test scenario 2: test for empty string
    string_formatter_2 = __StringFormatter('')
    print('unit test: empty string, input \"\", output \"' + string_formatter_2.format() + '\"')

    # Test scenario 3: test for None input
    string_formatter_3 = __StringFormatter(None)
    print('unit test: None input, output \"' + string_formatter_3.format() + '\"')




# Generated at 2022-06-26 01:45:18.242819
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('Treat your-selF')
    string_formatter_1 = __StringFormatter('Not A Proper-sentence.')
    string_formatter_2 = __StringFormatter('The CD-rom is not a hard disk')

    assert string_formatter_0.format() == 'Treat your-selF'
    assert string_formatter_1.format() == 'Not a proper-sentence.'
    assert string_formatter_2.format() == 'The CD-rom is not a hard disk'
