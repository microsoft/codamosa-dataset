

# Generated at 2022-06-26 01:42:06.276063
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    out = __StringFormatter('Più fatti che parole, amico mio.').format()
    assert out == 'Più fatti che parole, amico mio.'
    out = __StringFormatter('Più fatti, che parole, amico mio.').format()
    assert out == 'Più fatti, che parole, amico mio.'
    out = __StringFormatter('Più fatti, che parole. amico mio.').format()
    assert out == 'Più fatti, che parole. Amico mio.'
    out = __StringFormatter('Più fatti, che parole: amico mio.').format()
    assert out == 'Più fatti, che parole: Amico mio.'

# Generated at 2022-06-26 01:42:10.945475
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    a = 'I love my job and I love that when I hear the word “terminator”, it means friend to some, and foe to others.'
    b = 'I love my job and I love that when I hear the word “Terminator”, it means friend to some, and foe to others.'
    c = 'I like reading books and books written in English.'

    t = __StringFormatter(a)
    assert t.format() == b
    assert __StringFormatter(c).format() == 'I like reading books and books written in English.'

# PUBLIC API



# Generated at 2022-06-26 01:42:18.048704
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    result = __StringFormatter("Hello.\n\tHow are you?\nI'm fine. Thank you\n\tand you?\nWell, I'm fine.. thanks\n").format()
    if result != "Hello. How are you? I'm fine. Thank you and you? Well, I'm fine.. thanks":
        print("Test failed at test___StringFormatter_format")

if __name__ == "__main__":
    test_case_0()
    test___StringFormatter_format()

# PUBLIC API



# Generated at 2022-06-26 01:42:24.716174
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test"
    assert camel_case_to_snake("this_is_a_camel_string_test") == "this_is_a_camel_string_test"


# Generated at 2022-06-26 01:42:30.669423
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    result = __StringFormatter('      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus lorem ipsum,  eget facilisis quis, efficitur quis dolor...').format()
    assert result == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus lorem ipsum, eget facilisis quis, efficitur quis dolor...'


# Generated at 2022-06-26 01:42:38.972580
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Test case n0
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'

    # Test case n1
    assert camel_case_to_snake('AABBCC') == 'aabbcc'

if __name__ == '__main__':
    test_case_0()
    test_camel_case_to_snake()


# Generated at 2022-06-26 01:42:48.413447
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Test 0:
    if camel_case_to_snake('ThisIsACamelStringTest') != 'this_is_a_camel_string_test':
        print('test_camel_case_to_snake(): test 0 failed')
        return
    # Test 1:
    if camel_case_to_snake('ThisIsACamelStringTest', ' ') != 'this is a camel string test':
        print('test_camel_case_to_snake(): test 1 failed')
        return
    # Test 2:
    if camel_case_to_snake('ThisIsACamelStringTest', '-') != 'this-is-a-camel-string-test':
        print('test_camel_case_to_snake(): test 2 failed')
        return
    # Test 3:

# Generated at 2022-06-26 01:42:54.961253
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '  Il   più grande dj del mondo non è mai stato osservato di persona.  '
    expected = 'Il più grande dj del mondo non è mai stato osservato di persona.'
    actual = __StringFormatter(input_string).format()
    
    assert expected == actual, 'test___StringFormatter_format failed'


# PUBLIC API



# Generated at 2022-06-26 01:43:00.316341
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    input_string = 'ThisIsACamelStringTest'
    actual_value = camel_case_to_snake(input_string)

    expected_value = 'this_is_a_camel_string_test'

    if actual_value != expected_value:
        raise Exception('Test failed')
    else:
        print('Test passed')

# Test case for function camel_case_to_snake

# Generated at 2022-06-26 01:43:08.207105
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('camelCaseTest') == 'camel_case_test'
    assert camel_case_to_snake('camelStringTest,no hyphen') == 'camel_string_test,no_hyphen'
    assert camel_case_to_snake('camelStringTest,no hyphen', '-') == 'camel-string-test,no-hyphen'

test_camel_case_to_snake()



# Generated at 2022-06-26 01:43:19.533635
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '-benvenuto Hello ! &lt;hello@world.me&gt; di là dal lago http://www.example.com/homepage/'

    output = __StringFormatter(input_string).format()

    assert output == 'Benvenuto Hello! <hello@world.me> di là dal lago http://www.example.com/homepage/'


# Generated at 2022-06-26 01:43:22.733693
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
  string_formatter_0 = __StringFormatter('salam doste aziz')
  format_result = string_formatter_0.format()

"""
    Utility functions to work with strings.

    .. testsetup::

        >>> from pydash.strings import *
"""


# Generated at 2022-06-26 01:43:25.186954
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('This@email.addresses.is@valid.com')
    result = string_formatter.format()
    assert result == 'this@email.addresses.is@valid.com'


# Generated at 2022-06-26 01:43:26.428627
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('  hello  ')
    sf.format()


# PUBLIC API



# Generated at 2022-06-26 01:43:35.360342
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    roman_numbers_0 = __RomanNumbers()
    input_string_0 = '     test     '
    string_formatter_0 = __StringFormatter(input_string_0)
    string_formatter_0.format()
    input_string_1 = '     test     '
    string_formatter_1 = __StringFormatter(input_string_1)
    string_formatter_1.format()


# PUBLIC API


# Generated at 2022-06-26 01:43:37.910191
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('testunit')
    assert string_formatter_0.format() == 'Testunit'



# Generated at 2022-06-26 01:43:43.093449
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter(
        '   A   M  S     D  O  M  I  N  I  C  A  N  O   B  E  N  E  D  I  C  T  I  N  E   '
    )
    assert string_formatter.format() == 'A M S D O M I N I C A N O B E N E D I C T I N E'


# Generated at 2022-06-26 01:43:54.567761
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("To Be OR NOT to   Be" ).format() == "To be or not to be"
    assert __StringFormatter("  To Be OR NOT to   Be ! " ).format() == "To be or not to be!"
    assert __StringFormatter("To   Be OR NOT to   Be ! " ).format() == "To be or not to be!"
    assert __StringFormatter("To   Be OR NOT to  Be ! " ).format() == "To be or not to be!"
    assert __StringFormatter("  To   Be OR NOT to Be ! " ).format() == "To be or not to be!"
    assert __StringFormatter("  To   Be OR NOT to Be ! " ).format() == "To be or not to be!"

# Generated at 2022-06-26 01:44:07.701063
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake_is-green') == 'The-snakeIs-green'
    assert snake_case_to_camel('the-snake_is-green', False) == 'the-snakeIs-green'

# Generated at 2022-06-26 01:44:18.539109
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False) == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=False, separator="-") == "theSnakeIsGreen"
    assert snake_case_to_camel("the_snake_is_green", upper_case_first=True, separator="-") == "TheSnakeIsGreen"
    assert snake_case_to_camel("camel_case_test") == "CamelCaseTest"


if __name__ == '__main__':
    test_case_0()
    test_snake_case

# Generated at 2022-06-26 01:44:28.077927
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode('2019') == 'MMXIX'


# Generated at 2022-06-26 01:44:29.382319
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-26 01:44:33.694140
# Unit test for function reverse
def test_reverse():
    assert reverse('') == '', "Error on reverse empty string"
    assert reverse('A') == 'A', "Error on reverse A"
    assert reverse('AB') == 'BA', "Error on reverse BA"
    assert reverse('ABC') == 'CBA', "Error on reverse CBA"
    assert reverse('ab') == 'ba', "Error on reverse ba"
    assert reverse('abcd') == 'dcba', "Error on reverse dcba"
    assert reverse('abcd1') == '1dcba', "Error on reverse 1dcba"


# Generated at 2022-06-26 01:44:39.878287
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # constructor requires a string as input, therefore it's not unexpected
    # to have a InvalidInputError since the input is an integer
    try:
        __StringFormatter(1)
    except InvalidInputError:
        pass
    else:
        raise AssertionError('Constructor of class __StringFormatter should raise InvalidInputError')

    __StringFormatter('test')



# Generated at 2022-06-26 01:44:45.610203
# Unit test for function asciify
def test_asciify():
    input_string = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    ascii_string = asciify(input_string)
    result = 'eeuuooaaeynAAACIINOE'
    if result == ascii_string:
        print ("Unit test for asciify. The method is correct" )
    else:
        print("Unit test for asciify. The method is NOT correct")



# Generated at 2022-06-26 01:44:53.000599
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter("my,name is d'artagnan, i'm 23 and my email is d'artagnan@three-musketeers.com")
    if formatter_0.format() != "My name is D'artagnan, I'm 23 and my email is d'artagnan@three-musketeers.com":
        print("Error in test___StringFormatter_format")


# Generated at 2022-06-26 01:44:54.377361
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    sc = __StringCompressor()

# Generated at 2022-06-26 01:44:56.906129
# Unit test for function shuffle
def test_shuffle():
    test_list = ['hello', 'world']
    for word in test_list:
        print('----> test for string ', word)
        shuffled = shuffle(word)
        if (shuffled == word):
            print(' Failed in test case')

#test_shuffle()
test_case_0()
# __RomanNumbers.encode(input_number)
# __RomanNumbers.decode(input_string)

# Generated at 2022-06-26 01:45:02.767483
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    """
    repeat `dir(__StringFormatter)`
    """
    repeat_dir = lambda _: dir(__StringFormatter)
    fmt = __StringFormatter('foo')
    assert set(repeat_dir(1)) == set(repeat_dir(2))
    assert fmt.format() == 'Foo'


# Generated at 2022-06-26 01:45:05.150892
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    sc = __StringCompressor()

test_case_0()
test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-26 01:45:21.618108
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  some  string with     lots     of   spaces   ').format() == 'Some string with lots of spaces'
    assert __StringFormatter('some  string with lots of duplicate    chars    chars').format() == 'Some string with lots of duplicate chars chars'
    assert __StringFormatter('some string that end  with  a  space').format() == 'Some string that end with a space'
    assert __StringFormatter('  some  string   that   start     with     a     space').format() == 'Some string that start with a space'
    assert __StringFormatter('some  string  that  end  with  a  space  ').format() == 'Some string that end with a space'
    assert __StringFormatter('some  string  with  spaces  around  ').format() == 'Some string with spaces around'
   

# Generated at 2022-06-26 01:45:27.528338
# Unit test for function roman_decode
def test_roman_decode():
    roman_numbers_1 = __RomanNumbers()
    assert roman_decode("I") == 1
    assert roman_decode("V") == 5
    assert roman_decode("X") == 10
    assert roman_decode("L") == 50
    assert roman_decode("C") == 100
    assert roman_decode("D") == 500
    assert roman_decode("M") == 1000
    assert roman_decode("II") == 2
    assert roman_decode("III") == 3
    assert roman_decode("IV") == 4
    assert roman_decode("VI") == 6
    assert roman_decode("VII") == 7
    assert roman_decode("VIII") == 8
    assert roman_decode("IX") == 9

# Generated at 2022-06-26 01:45:29.127937
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('a not')
    assert s.format() == 'A not'


# Generated at 2022-06-26 01:45:37.168949
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('123') != 7
    assert roman_decode('M') == 1000
    assert roman_decode('MMMM') == 4000
    assert roman_decode('MMMM') != 3999
    assert roman_decode('1') != True
    assert roman_decode('MMMMM') == False

# Generated at 2022-06-26 01:45:49.272538
# Unit test for function asciify
def test_asciify():
    input_0 = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    output_0 = 'eeuuooaaeynAAACIINOE'
    test_0 = (input_0, output_0)
    tests = [test_0]
    for test in tests:
        result = asciify(test[0])
        if result != test[1]:
            print('Test failed: \n\tinput: ' + test[0] + '\n\texpected: ' + test[1] + '\n\tactual: ' + result)
            break
    print('All tests passed!')


# Generated at 2022-06-26 01:45:52.298344
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    print("Test function \"__RomanNumbers\" Start!")

    # Test 0
    roman_numbers_0 = __RomanNumbers()
    assert true

    print("Test function \"__RomanNumbers\" End!")



# Generated at 2022-06-26 01:45:56.460021
# Unit test for function slugify
def test_slugify():
    input_string = "Top 10 Reasons To Love Dogs!!!"
    output_string = slugify(input_string, separator = '-')
    assert is_string(output_string)
    assert output_string == "top-10-reasons-to-love-dogs"


# Generated at 2022-06-26 01:45:59.397127
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    stringCompressor = __StringCompressor()


# PUBLIC API



# Generated at 2022-06-26 01:46:10.197762
# Unit test for function decompress

# Generated at 2022-06-26 01:46:15.002258
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print("CASE 1: 'the_snake_is_green', upper_case_first=True, separator='_'")
    print("Result == 'TheSnakeIsGreen': ", snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen')

    print("CASE 2: 'the_snake_is_green', upper_case_first=False, separator='_'")
    print("Result == 'theSnakeIsGreen': ", snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen')

    print("CASE 3: 'the-snake-is-green', upper_case_first=False, separator='-'")

# Generated at 2022-06-26 01:46:29.630259
# Unit test for function asciify
def test_asciify():
    unicode_string = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË!'
    ascii = asciify(unicode_string)
    expected_ascii = 'eeuuooaaeynAAACIINOE!'
    if ascii != expected_ascii:
        print("Error: bad result for asciify()")
        print(ascii+" != "+expected_ascii)
    print("test_asciify passed")


# Generated at 2022-06-26 01:46:39.882807
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter("a b c")
    string_formatter_1 = __StringFormatter("a  b c")
    string_formatter_2 = __StringFormatter("a b  c")
    string_formatter_3 = __StringFormatter("  a  b    c   ")
    string_formatter_4 = __StringFormatter("a b c d e f")
    string_formatter_5 = __StringFormatter("")
    assert string_formatter_0.format() == "A b c"
    assert string_formatter_1.format() == "A b c"
    assert string_formatter_2.format() == "A b c"
    assert string_formatter_3.format() == "A b c"

# Generated at 2022-06-26 01:46:41.785471
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = __StringCompressor.compress(original)
    # print(original)
    # print(compressed)


# Generated at 2022-06-26 01:46:42.671664
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-26 01:46:43.938498
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    stringCompressor_0 = __StringCompressor()


# Generated at 2022-06-26 01:46:45.612993
# Unit test for function slugify
def test_slugify():
    assert "hello_world" == slugify("Hello   World")
    assert "hello-world" == slugify("Hello   World", separator="-")

    # Test for a bug, now fixed
    assert "hello-world" == slugify("Hello -- World")



# Generated at 2022-06-26 01:46:51.149698
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('LXVII') == 67
    assert roman_decode('MMXX') == 2020
    assert roman_decode('VIII') == 8
    assert roman_decode('XIX') == 19

    try:
        roman_decode('IIII')
        assert False
    except RomanNumberException:
        assert True


# Generated at 2022-06-26 01:46:54.222600
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers() is not None, "Error in __RomanNumbers.__init__()"
    print("test__RomanNumbers() passed.")


# Generated at 2022-06-26 01:46:57.548215
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    out = __StringFormatter(" a  b'c-d'e/f  ").format()
    assert out == "A  b'c-d'e/f"


# Generated at 2022-06-26 01:46:58.587701
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers()


# Generated at 2022-06-26 01:47:14.538688
# Unit test for function reverse
def test_reverse():
    assert reverse("hello") == "olleh"


# Generated at 2022-06-26 01:47:16.112633
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    snake_case_to_camel('the_snake_is_green')
    return True


# Generated at 2022-06-26 01:47:17.317865
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers



# Generated at 2022-06-26 01:47:20.279157
# Unit test for function strip_margin
def test_strip_margin():
    n = strip_margin('''
                                            1
                                            2
                                            3
                                            ''')
    assert n == '''
                                            1
                                            2
                                            3
                                            '''

    n = strip_margin('''
                                            1
                                            2
                                            3
                                            ''')
    assert n == '''
                                            1
                                            2
                                            3
                                            '''


# Generated at 2022-06-26 01:47:24.721907
# Unit test for function prettify
def test_prettify():
    # Prettyfying a simple string
    assert prettify('1234567890') == '1234567890'

    # Prettyfying a string with mistakes
    assert prettify('unprettified string ,, like this one,will be"prettified" .it\\\' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

    # Prettyfying a string with a URL
    assert prettify('Visit https://www.google.com/ for more info') == 'Visit https://www.google.com/ for more info'

    # Prettyfying a string with a Email address
    assert prettify('Send an email to paul.klee@gmail.com for more info') == 'Send an email to paul.klee@gmail.com for more info'

# Generated at 2022-06-26 01:47:34.804540
# Unit test for function strip_html
def test_strip_html():
    test_case_0 = 'test: <a href="foo/bar">click here</a>'
    expected_0_only_tag = 'test: '
    expected_0_with_contents = 'test: click here'
    
    test_case_1 = 'test: <img src="img.png" />'
    expected_1_only_tag = 'test: '
    expected_1_with_contents = 'test: '
    
    test_case_2 = 'test: <input type="text" value="foo" />'
    expected_2_only_tag = 'test: '
    expected_2_with_contents = 'test: '
    
    test_case_3 = 'test: <p style="color: red">an example</p>'

# Generated at 2022-06-26 01:47:38.709470
# Unit test for function decompress
def test_decompress():
    test_string = "test string with spaces"
    execute_string = __StringCompressor.decompress(__StringCompressor.compress(test_string))

    return test_string == execute_string

test_case_0()
print(test_decompress())

# Generated at 2022-06-26 01:47:41.759460
# Unit test for function slugify
def test_slugify():
    print("\n**** Test function slugify ****")
    print("Output: ", slugify("Top 10 Reasons To Love Dogs!!!"))
    print("Output: ", slugify("Top 10 Reasons To Love Dogs!!!"))
    

# Generated at 2022-06-26 01:47:53.335319
# Unit test for function compress
def test_compress():
    n = 0
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    # "uncompressed" will be the same 169 chars string of the original one
    uncompressed = __StringCompressor.decompress(compressed)
    print(original)
    print(compressed)
    print(uncompressed)
    assert original == uncompressed
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    print(original)
    compressed = compress(original)
    print(compressed)
    uncompressed = __StringCompressor.decompress(compressed)

# Generated at 2022-06-26 01:47:57.241560
# Unit test for function booleanize
def test_booleanize():
    print("Test booleanize with true value 'yes':")
    if booleanize('yes'):
        print("Test passed :)")
    else:
        print("Test failed :(")
    print("Test booleanize with false value 'no':")
    if not booleanize('no'):
        print("Test passed :)")
    else:
        print("Test failed :(")
    print("Test booleanize with true value 1:")
    if booleanize('1'):
        print("Test passed :)")
    else:
        print("Test failed :(")
    print("Test booleanize with false value '0':")
    if not booleanize('0'):
        print("Test passed :)")
    else:
        print("Test failed :(")
