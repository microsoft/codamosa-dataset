

# Generated at 2022-06-26 01:42:00.943538
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'a_long_snake_case_string'
    str_1 = snake_case_to_camel(str_0)
    str_2 = snake_case_to_camel(str_1)

    print(str_0)
    print(str_1)
    print(str_2)



# Generated at 2022-06-26 01:42:08.446695
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # str_0 = input('Please input your string: ')
    str_0 = "the_snake_is_green"
    str_1 = snake_case_to_camel(str_0)
    print(str_1)
    # print('the_snake_is_green' == str_0)
    # print(type(str_0))
    assert str_1 == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:42:18.439430
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # test conditions:
    snake_case_str_empty    = ""
    snake_case_str_valid    = "the_snake_is_green"
    snake_case_str_invalid  = "the snake is green"

    # test returns:
    assert str(snake_case_to_camel(snake_case_str_valid))       == "TheSnakeIsGreen"
    assert snake_case_to_camel(snake_case_str_invalid)          == snake_case_str_invalid
    assert snake_case_to_camel(snake_case_str_empty)            == snake_case_str_empty
    assert snake_case_to_camel(snake_case_str_valid,False)      == "theSnakeIsGreen"


# Generated at 2022-06-26 01:42:19.966147
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'my_string'
    str_1 = snake_case_to_camel(str_0, upper_case_first=True, separator='_')
    print(str_1)


# Generated at 2022-06-26 01:42:23.343116
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(str_0)
    if str_1 != 'TheSnakeIsGreen':
        raise AssertionError()
    str_2 = snake_case_to_camel(str_0, False)
    if str_2 != 'theSnakeIsGreen':
        raise AssertionError()
    test_case_0()


# Generated at 2022-06-26 01:42:26.294330
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'



# Generated at 2022-06-26 01:42:32.840907
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'the_snake_is_green'
    str_1 = snake_case_to_camel(str_0, upper_case_first=True, separator='_')
    str_2 = 'TheSnakeIsGreen'
    print('snake_case_to_camel: ', str_1, str_2)
    assert (str_1 == str_2)
    print('Pass')


# Generated at 2022-06-26 01:42:37.248217
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    str_0 = 'user_id'
    str_1 = snake_case_to_camel(str_0)
    if str_1 != 'UserId':
        raise Exception("Conversion failed!")
    return True



# Generated at 2022-06-26 01:42:46.519596
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test case 1
    str_0 = 'snake_case'
    str_1 = snake_case_to_camel(str_0)

    if not is_string(str_1):
        return 'Fail'
    if str_1 != 'SnakeCase':
        return 'Fail'

    # Test case 2
    str_2 = 'snake_case_str_2'
    str_3 = snake_case_to_camel(str_2)

    if not is_string(str_3):
        return 'Fail'
    if str_3 != 'SnakeCaseStr2':
        return 'Fail'

    return 'Pass'


# Generated at 2022-06-26 01:42:52.045555
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    x = 'the_snake_is_green'
    x_1 = snake_case_to_camel(x)
    x_2 = snake_case_to_camel(x, False)
    assert x_1 == 'TheSnakeIsGreen'
    assert x_2 == 'theSnakeIsGreen'
    xx = '123_snake_is_green'
    xx_1 = snake_case_to_camel(xx)
    xx_2 = snake_case_to_camel(xx, False)
    assert xx_1 == '123SnakeIsGreen'
    assert xx_2 == '123snakeIsGreen'


# Generated at 2022-06-26 01:43:05.424150
# Unit test for function shuffle
def test_shuffle():
    # Test input case 0
    input_0 = ""
    if shuffle(input_0) != "":
        raise TestFailure("Failure in test_case_0")
    # Test input case 1
    input_1 = "a"
    if shuffle(input_1) != "a":
        raise TestFailure("Failure in test_case_1")
    # Test input case 2
    input_2 = "ab"
    if shuffle(input_2) == "ab" or shuffle(input_2) == "ba":
        pass
    else:
        raise TestFailure("Failure in test_case_2")
    # Test input case 3
    input_3 = "abc"
    if shuffle(input_3) == "abc":
        pass
    elif shuffle(input_3) == "acb":
        pass

# Generated at 2022-06-26 01:43:07.023582
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test_case_0()

# PUBLIC API



# Generated at 2022-06-26 01:43:20.103516
# Unit test for function decompress
def test_decompress():
    # Test compression of string "Hello World!"
    test_string = "Hello World!"
    expected_compressed_string = "eJwFwQEAAAAA/PM="
    test_compressed_string = compress(test_string)
    # Test decompression of string "Hello World!"
    expected_decompressed_string_0 = "Hello World!"
    test_decompressed_string_0 = decompress(expected_compressed_string)
    # Test decompression of string "eJwFwQEAAAAA/PM="
    expected_decompressed_string_1 = "Hello World!"
    test_decompressed_string_1 = decompress(test_compressed_string)
    # Compare expected and tested strings

# Generated at 2022-06-26 01:43:31.473272
# Unit test for function booleanize
def test_booleanize():
    #test input
    # testcase
    input_1 = "true"
    input_2 = "True" 
    input_3 = "1"
    input_4 = "YES"
    input_5 = "y"
    input_6 = "nope"
    #expected output
    expect_output_1 = True
    expect_output_2 = True
    expect_output_3 = True
    expect_output_4 = True
    expect_output_5 = True
    expect_output_6 = False
    
    #actual output
    actual_output_1 = booleanize(input_1)
    actual_output_2 = booleanize(input_2)
    actual_output_3 = booleanize(input_3)
    actual_output_4 = booleanize(input_4)

# Generated at 2022-06-26 01:43:35.037331
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-26 01:43:38.713555
# Unit test for function reverse
def test_reverse():
    reverse_test_cases = ["hello", "world"]
    for test_case in reverse_test_cases:
        assert reverse(test_case) == test_case[::-1]


# Generated at 2022-06-26 01:43:42.606415
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    for x in range(1, 4000):
        try:
            assert __RomanNumbers.decode(__RomanNumbers.encode(x)) == x
        except AssertionError:
            print(__RomanNumbers.encode(x))
            print(__RomanNumbers.decode(x))
            print(x)
            raise

# PUBLIC API



# Generated at 2022-06-26 01:43:43.522677
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-26 01:43:54.567538
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:43:55.600814
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-26 01:44:02.580837
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_camel_case_string_test' == \
        camel_case_to_snake('ThisIsACamelStringTest'), "Test camel_case_to_snake failed"
    assert 'this_is_a_camel_case_string_test' == \
        camel_case_to_snake('thisIsACamelStringTest'), "Test camel_case_to_snake failed"
    assert 'test_test' == \
        camel_case_to_snake('TestTest'), "Test camel_case_to_snake failed"
    assert 'test_test' == \
        camel_case_to_snake('testTest'), "Test camel_case_to_snake failed"

# Generated at 2022-06-26 01:44:04.065526
# Unit test for function slugify
def test_slugify():
    print()
    print(slugify(input_string='Top 10 Reasons To Love Dogs!!!', separator=' '))
    print(slugify(input_string='Mönstér Mägnët', separator='-'))

# Generated at 2022-06-26 01:44:09.129601
# Unit test for function asciify
def test_asciify():
    s = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    s_ascii = 'eeuuooaaeynAAACIINOE'
    assert asciify(s) == s_ascii


# Generated at 2022-06-26 01:44:12.443097
# Unit test for function booleanize
def test_booleanize():
    result_1 = booleanize("true")
    assert result_1 == True
    result_2 = booleanize("nope")
    assert result_2 == False



# Generated at 2022-06-26 01:44:13.161529
# Unit test for function decompress
def test_decompress():
    assert(decompress('MII=') == 'ol')



# Generated at 2022-06-26 01:44:21.787608
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Check that input value must be a string
    try:
        snake_case_to_camel(None)
        assert False
    except:
        assert True

    # Check that the original string is returned in case of invalid snake case input
    assert 'abcTest' == snake_case_to_camel('abcTest')

    # Check that the lowercase first letter can be preserved
    assert 'abcTest' == snake_case_to_camel('abc_test', upper_case_first=False)

    # Check that a custom separator can be specified
    assert 'AbcTest' == snake_case_to_camel('abc~test', separator='~')


test_case_0()
test_snake_case_to_camel()

# Generated at 2022-06-26 01:44:26.840052
# Unit test for function slugify
def test_slugify():
    test_string0 = 'åtop 10 Reasons To Love Dogs!!!'
    test_string1 = 'Mönstér Mägnët'
    test_string2 = 'åtop-10-Reasons-To-Love-Dogs!!!'
    test_string3 = 'Mönstér-Mägnët'

    test_expected_string0 = 'a-top-10-reasons-to-love-dogs'
    test_expected_string1 = 'monster-magnet'
    test_expected_string2 = 'a-top-10-reasons-to-love-dogs'
    test_expected_string3 = 'monster-magnet'

    if test_expected_string0 != slugify(test_string0):
        print('Test 1 is False')
    else:
        print('Test 1 is Successful')



# Generated at 2022-06-26 01:44:28.433018
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("1234567890") != "1234567890" and len(shuffle("1234567890")) == len("1234567890") and len(shuffle("")) == 0 and shuffle("abcdefghijkl") != "abcdefghijkl"


# Generated at 2022-06-26 01:44:30.215893
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    pretty_output = __StringFormatter('This is an exampe of a good forum post').format()
    assert pretty_output == 'This is an example of a good forum post'


# PUBLIC API


# Generated at 2022-06-26 01:44:31.627839
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('  test  hello  ')
    assert sf.format() == 'Test hello'


# Generated at 2022-06-26 01:44:43.514950
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '"\'\n\tOne Two   three.  Four, five(six)seven  eight. nine-ten; eleven: \n\tTwelve, thirteen. Fourteen " '
    expected_string = '"\' One Two three. Four, five(six) seven eight. nine- ten; eleven: Twelve, thirteen. Fourteen "'
    actual_string = __StringFormatter(input_string).format()

    print("test___StringFormatter_format: " + "PASSED" if actual_string == expected_string else "FAILED", end='\n')


# Run all unit test

# Generated at 2022-06-26 01:44:44.709510
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-26 01:44:45.979420
# Unit test for function reverse
def test_reverse():
    assert(reverse('hello') == 'olleh')
    return True


# Generated at 2022-06-26 01:44:58.409483
# Unit test for function roman_decode
def test_roman_decode():
    assert(roman_decode('III') == 3)
    assert(roman_decode('IV') == 4)
    assert(roman_decode('V') == 5)
    assert(roman_decode('VIII') == 8)
    assert(roman_decode('IX') == 9)
    assert(roman_decode('X') == 10)
    assert(roman_decode('XI') == 11)
    assert(roman_decode('XIII') == 13)
    assert(roman_decode('XIV') == 14)
    assert(roman_decode('XX') == 20)
    assert(roman_decode('XXII') == 22)
    assert(roman_decode('XXIV') == 24)
    assert(roman_decode('XXVI') == 26)

# Generated at 2022-06-26 01:45:00.914605
# Unit test for function shuffle
def test_shuffle():
    # The test will fail if shuffled strings are not different and are not the same length as the original ones
    some_strings = [
        '',
        'test',
        'another test',
        'the big brown fox'
    ]

    for s in some_strings:
        shuffled = shuffle(s)
        not_equal(s, shuffled)
        equal(len(s), len(shuffled))


# Generated at 2022-06-26 01:45:10.464743
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'

    assert roman_encode(11) == 'XI'
    assert roman_encode(25) == 'XXV'
    assert roman_encode(53) == 'LIII'


# Generated at 2022-06-26 01:45:12.731563
# Unit test for function booleanize
def test_booleanize():
    input_string1 = 'nope'
    input_string2 = 'yes'
    if booleanize(input_string1) == True or booleanize(input_string2) == False:
        print('function booleanize is not working')
    else:
        print('function booleanize is working')


# Generated at 2022-06-26 01:45:16.749640
# Unit test for function roman_encode
def test_roman_encode():
    # using default roman number mapper
    roman_numbers_0 = __RomanNumbers()
    expected_encoding_0 = 'XXXVI'
    actual_encoding_0 = roman_numbers_0.encode(36)
    assert expected_encoding_0 == actual_encoding_0

    # using a custom mapper
    roman_numbers_1 = __RomanNumbers(__roman_number_mapper_1)
    expected_encoding_1 = 'XVIII'
    actual_encoding_1 = roman_numbers_1.encode(18)
    assert expected_encoding_1 == actual_encoding_1

    # input is a string
    expected_encoding_2 = 'MMXX'
    actual_encoding_2 = __RomanNumbers.encode('2020')

# Generated at 2022-06-26 01:45:18.481367
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-26 01:45:22.504373
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode("13") == "XIII"
    assert roman_encode("199") == "CXCIX"
    assert roman_encode("1299") == "MCCXCIX"
    assert roman_encode("13") == "XIII"
    assert roman_encode("199") == "CXCIX"
    assert roman_encode("1299") == "MCCXCIX"
    assert roman_encode("1999") == "MCMXCIX"
    assert roman_encode("2020") == "MMXX"
    assert roman_encode("2222") == "MMCCXXII"
    assert roman_encode("2424") == "MMCDXXIV"
    assert roman_encode("2626") == "MMDCCXXVI"

# Generated at 2022-06-26 01:45:41.462448
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14
    assert roman_decode('XV') == 15
    assert roman_decode('XVI') == 16

# Generated at 2022-06-26 01:45:44.495171
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    roman_numbers_0 = __RomanNumbers()

# Unit tests for method 'encode' of class __RomanNumbers

# Generated at 2022-06-26 01:45:46.236966
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('This is a TEST')
    print(sf.format())

# PUBLIC API



# Generated at 2022-06-26 01:45:56.879431
# Unit test for function prettify
def test_prettify():
    print("\nUnit test for function prettify")
    # test_case 1
    print("\nTest case 1")
    test_str_1 = " unprettified string ,, like this one,will be\"prettified\" .it\\' s awesome! "
    print("before prettify:", test_str_1)
    res = prettify(test_str_1)
    print("after prettify:", res)
    print("expected:", 'Unprettified string, like this one, will be "prettified". It\'s awesome!')
    print("result:", 'True' if res == 'Unprettified string, like this one, will be "prettified". It\'s awesome!' else 'False')
    print('')

    # test_case 2
    print("\nTest case 2")
    test

# Generated at 2022-06-26 01:45:59.575012
# Unit test for function strip_margin
def test_strip_margin():
    print("*Test function strip_margin:")
    test_string = '''
	line 1
	line 2
	line 3'''
    print_string = strip_margin(test_string)
    print("\tStrip margin: " + print_string)
    if print_string == 'line 1\nline 2\nline 3':
        print("\t\tstrip margin test case 0 passed!")
    else:
        print("\t\tstrip margin test case 0 failed!")


# Generated at 2022-06-26 01:46:00.846188
# Unit test for function slugify
def test_slugify():
    print(slugify("Top 10 Reasons To Love Dogs!!!"))
    print(slugify("Mönstér Mägnët"))


# Generated at 2022-06-26 01:46:10.719318
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("AZZ")
    assert (sf.format() == "Azz")

    sf = __StringFormatter("Azz")
    assert (sf.format() == "Azz")

    sf = __StringFormatter("   AZZ   ")
    assert (sf.format() == "Azz")

    sf = __StringFormatter("   Azz   ")
    assert (sf.format() == "Azz")

    sf = __StringFormatter("A Z Z")
    assert (sf.format() == "A Z Z")

    sf = __StringFormatter("A z z")
    assert (sf.format() == "A z z")

    sf = __StringFormatter("A ZZ")
    assert (sf.format() == "A Zz")

    sf = __

# Generated at 2022-06-26 01:46:14.351876
# Unit test for function slugify
def test_slugify():
    assert slugify("@Bruno# de") == "bruno-de"
    assert slugify("@Bruno# de (test)") == "bruno-de-test"


# Generated at 2022-06-26 01:46:18.572581
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    estring = snake_case_to_camel('the_snake_is_green')
    assert estring == 'TheSnakeIsGreen', 'test_snake_case_to_camel failed'
    print('test_snake_case_to_camel passed')


# Generated at 2022-06-26 01:46:31.008778
# Unit test for function strip_margin
def test_strip_margin():
    line3 = '  line 3'
    line2 = '  line 2'
    line1 = '  line 1'
    line0 = ' '

# Generated at 2022-06-26 01:46:52.470453
# Unit test for function asciify
def test_asciify():
    test_string0 = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    test_string0_result = 'eeuuooaaeynAAACIINOE'

    if test_string0_result != asciify(test_string0):
        print('asciify() test failed')
        return 1
    else:
        return 0


# Generated at 2022-06-26 01:46:55.482612
# Unit test for function roman_decode
def test_roman_decode():
    roman_numbers_0 = __RomanNumbers()
    temp_0 = roman_numbers_0.decode('IIIV')


# Generated at 2022-06-26 01:46:59.970705
# Unit test for function prettify

# Generated at 2022-06-26 01:47:03.002132
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    uncompressed = decompress(compressed)
    if original == uncompressed:
        print('Compression and decompression working')
    else:
        print('Compression and decompression error')


# Generated at 2022-06-26 01:47:04.549031
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    string_formatter = __StringFormatter("")

# PUBLIC API
# ----------------------------------------------------------------------------------------------------------------------



# Generated at 2022-06-26 01:47:05.632510
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('MMCMXCIX') == 2999, "decode test failed"


# Generated at 2022-06-26 01:47:10.750804
# Unit test for function asciify
def test_asciify():
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')
    assert(asciify('This is ASCII') == 'This is ASCII')
    assert(asciify('Müller ÁÇÌÍÑÓË') == 'Mller ACINOE')


# Generated at 2022-06-26 01:47:20.353661
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('数学与物理') == 'shùxuèyǔwùlǐ'
    assert asciify('テスト') == 'tesuto'
    assert asciify('испытание') == 'ispytanie'

# Generated at 2022-06-26 01:47:22.473629
# Unit test for function roman_encode
def test_roman_encode():
    s = 'abc'
    assert roman_encode(s) == 'ABC', 'Expected "ABC", but got {}'.format(roman_encode(s))
    s = 'def'
    assert roman_encode(s) == 'DEF', 'Expected "DEF", but got {}'.format(roman_encode(s))


# Generated at 2022-06-26 01:47:26.914094
# Unit test for function booleanize
def test_booleanize():
    boolean_0 = booleanize("true")
    boolean_1 = booleanize("True")
    boolean_2 = booleanize("TRUE")
    boolean_3 = booleanize("1")
    boolean_4 = booleanize("yes")
    boolean_5 = booleanize("YES")
    boolean_6 = booleanize("Y")
    boolean_7 = booleanize("y")
    boolean_8 = booleanize("no")
    boolean_9 = booleanize("false")

    print(boolean_0, boolean_1, boolean_2, boolean_3, boolean_4, boolean_5, boolean_6, boolean_7, boolean_8, boolean_9)
    assert boolean_0 == True, "True string doesn't return a true boolean"
    assert boolean_1 == True, "True string doesn't return a true boolean"
    assert boolean_2

# Generated at 2022-06-26 01:48:10.705633
# Unit test for function decompress
def test_decompress():
    roman_numbers_0 = __RomanNumbers()
    roman_numbers_0.from_string('LIX')

# Generated at 2022-06-26 01:48:25.657027
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True, separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', upper_case_first=False, separator=' ') == 'the snake is green'

# Generated at 2022-06-26 01:48:36.913045
# Unit test for function prettify
def test_prettify():
    print('Hello')
    # Test case 1

# Generated at 2022-06-26 01:48:40.443371
# Unit test for function asciify
def test_asciify():
    input_asciify = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    expected_output_asciify = 'eeuuooaaeynAAACIINOE'

    output_asciify = asciify(input_asciify)

    assert output_asciify == expected_output_asciify

    print('\n')
    print(output_asciify)


if __name__ == '__main__':
    test_asciify()
    test_case_0()

# Generated at 2022-06-26 01:48:47.014826
# Unit test for function booleanize
def test_booleanize():
    input_bool = "True"
    input_bool1 = "true"
    input_bool2 = "False"
    input_bool3 = "1"
    input_bool4 = "0"
    input_bool5 = "yes"
    input_bool6 = "nope"
    input_bool7 = "y"
    input_bool8 = "No"
    print(booleanize(input_bool))
    print(booleanize(input_bool1))
    print(booleanize(input_bool2))
    print(booleanize(input_bool3))
    print(booleanize(input_bool4))
    print(booleanize(input_bool5))
    print(booleanize(input_bool6))
    print(booleanize(input_bool7))

# Generated at 2022-06-26 01:48:57.034063
# Unit test for function decompress
def test_decompress():
    fname = "test_output.txt"
    test_str = "This is a test string"
    test_str = compress(test_str)
    with open(fname, 'w') as f:
        f.write(str(len(test_str)) + '\n')
        f.write(test_str + '\n')
    with open(fname, 'r') as f:
        line = f.readline()
        str_len = int(line)
        line = f.readline()
        test_str = line
        test_str = test_str[0:str_len]
    test_str = decompress(test_str)
    assert test_str == 'This is a test string'
    print("Test Passed!")

# Generated at 2022-06-26 01:49:01.907674
# Unit test for function reverse
def test_reverse():
    print("\nUnit test for function reverse")
    print(reverse('hello'))
    print(reverse('olleh'))
    print(reverse('123456789'))
    print(reverse('987654321'))
    try:
        print(reverse(123))
    except Exception as e:
        print(e)
    except:
        print('Unknown exception caught')



# Generated at 2022-06-26 01:49:04.319772
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh', 'Test case 0 failed.'
    print('All tests passed.')

test_reverse()


# Generated at 2022-06-26 01:49:08.333139
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars

    compressed = compress(original)

    print("Original: ", original)
    print("Compressed: ", compressed)

    # roman_numbers_0 = __RomanNumbers()
    #
    # roman_numbers_0.to_int("I")
    # roman_numbers_0.to_int("II")
    # roman_numbers_0.to_int("III")
    # roman_numbers_0.to_int("IV")
    # roman_n

# Generated at 2022-06-26 01:49:09.701175
# Unit test for function reverse
def test_reverse():
    print("Test case 0: Test reverse")
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 01:49:38.219444
# Unit test for function strip_margin
def test_strip_margin():
    import doctest

    print("\n*** strip_margin ***")
    doctest.testmod(verbose=True)


# Generated at 2022-06-26 01:49:40.815494
# Unit test for function reverse
def test_reverse():
  assert reverse("test") == "tset"
  assert reverse("hello") == "olleh"

test_case_0()
test_reverse()


# Generated at 2022-06-26 01:49:45.795095
# Unit test for function roman_encode
def test_roman_encode():
    test_0 = "MMM"
    test_1 = "III"
    test_2 = "VII"
    test_3 = "VIII"
    test_4 = "XXXVII"
    test_5 = "LXVIII"
    test_6 = "MCMXXIV"
    test_7 = "MCMLIV"

    assert(roman_encode(3000) == test_0)
    assert(roman_encode(3) == test_1)
    assert(roman_encode(7) == test_2)
    assert(roman_encode(8) == test_3)
    assert(roman_encode(37) == test_4)
    assert(roman_encode(68) == test_5)
    assert(roman_encode(1924) == test_6)

# Generated at 2022-06-26 01:49:55.477284
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # common case
    snake_case_str = 'the_snake_is_green'
    camel_str = snake_case_to_camel(snake_case_str)
    assert camel_str == 'TheSnakeIsGreen'

    # corner case
    snake_case_str = 'the_snake_is_green_'
    camel_str = snake_case_to_camel(snake_case_str)
    assert camel_str == 'TheSnakeIsGreen_'

    # corner case
    snake_case_str = '_the_snake_is_green'
    camel_str = snake_case_to_camel(snake_case_str)
    assert camel_str == '_TheSnakeIsGreen'

    # common case

# Generated at 2022-06-26 01:49:57.024458
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    try:
        test_case_0()
    except Exception:
        return False
    return True



# Generated at 2022-06-26 01:50:00.253060
# Unit test for function shuffle
def test_shuffle():
    input_string = "abcdefgh"
    random_string = shuffle(input_string)
    assert input_string is not random_string


# Generated at 2022-06-26 01:50:04.360691
# Unit test for function slugify
def test_slugify():
    # Test strings
    test_string0_in = "This is a test string"
    test_string0_out = "this-is-a-test-string"
    test_string1_in = "Top 10 Reasons To Love Dogs!!!"
    test_string1_out = "top-10-reasons-to-love-dogs"
    test_string2_in = "Mönstér Mägnët"
    test_string2_out = "monster-magnet"
    test_string3_in = "To be or Not to Be: That is the Question!"
    test_string3_out = "to-be-or-not-to-be-that-is-the-question"
    test_string4_in = "Never gonna give you up"

# Generated at 2022-06-26 01:50:05.323796
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-26 01:50:06.217370
# Unit test for function decompress
def test_decompress():
    test_decompress_0()


# Generated at 2022-06-26 01:50:08.130115
# Unit test for function reverse
def test_reverse():
    assert reverse('abc') == 'cba'
    assert reverse('dog') == 'god'
    assert reverse('') == ''


# Generated at 2022-06-26 01:50:36.455822
# Unit test for function slugify
def test_slugify():
    assert slugify('Word to be slugified') == 'word-to-be-slugified'


# Generated at 2022-06-26 01:50:44.795011
# Unit test for function strip_margin
def test_strip_margin():
    test_cases = [
        """
            line 1
            line 2
            line 3
            """,
        """
            line 1
            line 2
            line 3
            """
    ]
    results = [
        """
        line 1
        line 2
        line 3
        """,
        """
        line 1
        line 2
        line 3
        """
    ]
    for i, test_case in enumerate(test_cases):
        result = strip_margin(test_case)
        if not (result == results[i]):
            return False
    return True

# Generated at 2022-06-26 01:50:49.180428
# Unit test for function asciify
def test_asciify():
    test_string_0 = 'èéùúòóäåëýñöÖÅÀÁÇÌÍÑÓË'
    expected_0 = 'eeuuooaaeynOOAAACIINOE'

    assert asciify(test_string_0) == expected_0


# Generated at 2022-06-26 01:50:53.271696
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisDoesNotStartWithALowerCase') == 'this_does_not_start_with_a_lower_case'
    assert camel_case_to_snake('thisDoesNotStartWithALowerCase') == 'this_does_not_start_with_a_lower_case'
    assert camel_case_to_snake('doesNotEndWithUpperCase') == 'does_not_end_with_upper_case'
    assert camel_case_to_snake('alphaBravo') == 'alpha_bravo'

# Generated at 2022-06-26 01:50:55.228822
# Unit test for function decompress
def test_decompress():

    X = 'a' * 100
    Y = compress(X)
    Z = decompress(Y)
    print(Z)


# Generated at 2022-06-26 01:50:57.558256
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original_0 = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed_0 = compress(original_0)
    print(compressed_0)
    print(len(compressed_0))
    print(original_0)
    # print(original)

# Generated at 2022-06-26 01:51:01.499248
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test')
    assert(camel_case_to_snake('ThisIsACamelStringTest', '!') == 'this!is!a!camel!string!test')
    assert(camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test')
    assert(camel_case_to_snake('ThisisACamelStringTest') == 'thisis_a_camel_string_test')
    assert(camel_case_to_snake('thisisACamelStringTest') == 'thisis_a_camel_string_test')



# Generated at 2022-06-26 01:51:10.071936
# Unit test for function strip_html
def test_strip_html():

    # test null input
    input_string = ''
    try:
        strip_html(input_string, keep_tag_content=True)
        assert False, '#1 Null input string should raise exception'
    except InvalidInputError:
        pass

    try:
        strip_html(input_string, keep_tag_content=False)
        assert False, '#2 Null input string should raise exception'
    except InvalidInputError:
        pass

    # test simple input
    input_string = 'test: <a href="foo/bar">click here</a>'
    output_string = strip_html(input_string)
    assert output_string == 'test: ', '#1 Wrong output string: ' + output_string

    # test input with empty tag

# Generated at 2022-06-26 01:51:14.053036
# Unit test for function asciify
def test_asciify():
    input_string = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    print("input_string = %s", input_string)
    output_string = asciify(input_string)
    print("output_string = %s", output_string)
    assert output_string == 'eeuuooaaeynAAACIINOE'


if __name__ == "__main__":

    #test_case_0()
    test_asciify()

# Generated at 2022-06-26 01:51:15.684658
# Unit test for function strip_html
def test_strip_html():
    s0 = strip_html("This is a text with <p class='foo'></p>")
    s1 = strip_html("This is a text with <p class='foo'></p>", True)
    print(s0)
    print(s1)
