

# Generated at 2022-06-26 01:42:11.709463
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_demo') == 'SnakeDemo'
    assert snake_case_to_camel('snake_demo','_') == 'SnakeDemo'
    assert snake_case_to_camel('snake_demo', True, '_') == 'SnakeDemo'
    assert snake_case_to_camel('snake_demo', False, '_') == 'snakeDemo'
    assert snake_case_to_camel('snake_demo', True, ' ') == 'SnakeDemo'
    assert snake_case_to_camel('snake_demo', False, ' ') == 'snakeDemo'
    assert snake_case_to_camel('snake_demo') != 'snake_demo'
    assert snake_case

# Generated at 2022-06-26 01:42:17.632782
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    out = snake_case_to_camel("the_snake_is_green")
    assert out == "TheSnakeIsGreen", "Failed unit test for function snake_case_to_camel"
    print("Function snake_case_to_camel passed all unit tests")


# Generated at 2022-06-26 01:42:21.415953
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Test snake_case_to_camel')
    assert snake_case_to_camel('camel_case') == 'CamelCase'
    assert snake_case_to_camel('camel_case', upper_case_first=False) == 'camelCase'
    assert snake_case_to_camel('camel_case', upper_case_first=False, separator='-') == 'camel-case'


# Generated at 2022-06-26 01:42:23.157394
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print(snake_case_to_camel('test_33', separator='_'))
    print(snake_case_to_camel('test_33', separator='-'))


# Generated at 2022-06-26 01:42:25.699254
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    string_0 = 'the_snake_is_green'
    separator_0 = '_'
    result_0 = snake_case_to_camel(string_0)
    print('test_snake_case_to_camel: ' + 'result_0 = ' + str(result_0))



# Generated at 2022-06-26 01:42:37.000961
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('host_name') == 'HostName'
    assert snake_case_to_camel('host_name', True) == 'HostName'
    assert snake_case_to_camel('host_name', True, '-') == 'HostName'
    assert snake_case_to_camel('host_name', upper_case_first=True) == 'HostName'
    assert snake_case_to_camel('host_name', True, separator='-') == 'HostName'
    assert snake_case_to_camel('host_name', upper_case_first=True, separator='-') == 'HostName'
    assert snake_case_to_camel('host_name', False) == 'hostName'

# Generated at 2022-06-26 01:42:47.469048
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
     
    # Test case 1
    snake_case_1 = 'the_snake_is_green'
    camel_case_1 = 'TheSnakeIsGreen'
    result = snake_case_to_camel(snake_case_1)
    assert(result == camel_case_1)

    # Test case 2
    snake_case_2 = 'hello_world_from_python'
    camel_case_2 = 'HelloWorldFromPython'
    result = snake_case_to_camel(snake_case_2)
    assert(result == camel_case_2)

    # Test case 3
    snake_case_3 = 'python'
    camel_case_3 = 'Python'
    result = snake_case_to_camel(snake_case_3)

# Generated at 2022-06-26 01:42:51.474887
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # case to test
    str0 = 'apples_bananas_oranges'

    print(str0)
    print(snake_case_to_camel(str0))
    print(snake_case_to_camel(str0, False))
    print(snake_case_to_camel(str0, False, '-'))
    print(snake_case_to_camel(str0, True, '-'))



# Generated at 2022-06-26 01:43:00.258580
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print("\nUnit test for function snake_case_to_camel")
    if snake_case_to_camel('green_snake') != 'GreenSnake':
        return False
    if snake_case_to_camel('green_snake', separator='$') != 'green_snake':
        return False
    if snake_case_to_camel('_green_snake', separator='_') != '_green_snake':
        return False
    if snake_case_to_camel('green_snake_', separator='_') != 'green_snake_':
        return False
    if snake_case_to_camel('_green_snake_', separator='_') != '_green_snake_':
        return False

# Generated at 2022-06-26 01:43:06.526307
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    try:
        snake_case_to_camel("The_snake_is_green")
    except NameError:
        raise Exception("The_snake_is_green does not match the required pattern")
    try:
        snake_case_to_camel("the_snake_is_green")
    except NameError:
        raise Exception("the_snake_is_green does not match the required pattern")
    #test with all legal separators
    try:
        snake_case_to_camel("the_snake_is_green", True, "-")
    except NameError:
        raise Exception("the_snake_is_green does not match the required pattern")

# Generated at 2022-06-26 01:43:17.108006
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    if snake_case_to_camel('this_is_a_test') == 'ThisIsATest':
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-26 01:43:21.456821
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    string_to_be_used = 'the_snake_is_green'
    print(snake_case_to_camel(string_to_be_used, upper_case_first = False))


# Generated at 2022-06-26 01:43:29.646998
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('another-string-to-test', True, '-') == 'AnotherStringToTest'


# Generated at 2022-06-26 01:43:35.330191
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    snake_cases = {
        'the_snake_is_green': ('TheSnakeIsGreen', 'thesnakeisgreen'),
        'the_snake_is_green_but_the_frog_is_blue': ('TheSnakeIsGreenButTheFrogIsBlue', 'thesnakeisgreenbutthefrogisblue')
    }

    for s in snake_cases:
        expected_default = snake_cases[s][0]
        expected_lower_case = snake_cases[s][1]

        assert snake_case_to_camel(s) == expected_default
        assert snake_case_to_camel(s, upper_case_first=False) == expected_lower_case


# Generated at 2022-06-26 01:43:41.953577
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    snake_case = "the_snake_is_green"
    snake_case_1 =  "the_snake_is_green_1"
    expected_camel = "theSnakeIsGreen"
    expected_camel_1 = "theSnakeIsGreen_1"
    actual_camel = snake_case_to_camel(snake_case, True)
    actual_camel_1 = snake_case_to_camel(snake_case_1, True)
    assert(expected_camel == actual_camel)
    assert(expected_camel_1 == actual_camel_1)



# Generated at 2022-06-26 01:43:50.557411
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_case_string', True, '_') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('This_Is_A_Snake_Case_String', False, '_') == 'thisIsASnakeCaseString'
    assert snake_case_to_camel('this_is_a_snake_case_string', True, '-') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('this-is-a-snake-case-string', True, '-')  == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('thisIsASnakeCaseString', True, '_') == 'ThisIsASnakeCaseString'
    assert snake_

# Generated at 2022-06-26 01:43:57.909650
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('The_Snake_Is_Green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'


# Generated at 2022-06-26 01:44:07.611425
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake-is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake-is_green', False, separator='-') == 'theSnakeIsGreen'


# Generated at 2022-06-26 01:44:18.457630
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("green_snake", True, "_") == "GreenSnake"
    assert snake_case_to_camel("green_snake", False, "_") == "greenSnake"
    assert snake_case_to_camel("green_snake", True, "") == "GreenSnake"
    assert snake_case_to_camel("green_snake", False, "") == "greenSnake"

    assert snake_case_to_camel("green_snake", True, ".") == "GreenSnake"
    assert snake_case_to_camel("green_snake", False, ".") == "greenSnake"
    assert snake_case_to_camel("green_snake", True, "") == "GreenSnake"

# Generated at 2022-06-26 01:44:26.376997
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    function_name = "snake_case_to_camel"

    # Test case 0
    input_string_0 = "snake_is_green"
    expected_result_0 = "SnakeIsGreen"
    actual_result_0 = snake_case_to_camel(input_string_0)
    print("test_case_0() for: {}".format(function_name))
    print("\tinput_string_0:\t{}".format(input_string_0))
    print("\texpected_result_0:\t{}".format(expected_result_0))
    print("\tactual_result_0:\t{}".format(actual_result_0))
    print("\tare_equal_0:\t\t{}".format(expected_result_0 == actual_result_0))



# Generated at 2022-06-26 01:44:36.498272
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter('string')
    assert isinstance(formatter, __StringFormatter)


# Generated at 2022-06-26 01:44:38.743173
# Unit test for function asciify
def test_asciify():
    s = asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË")
    print("test_asciify: " + s)
    assert(s == "eeuuooaaeynAAACIINOE")



# Generated at 2022-06-26 01:44:40.675779
# Unit test for function strip_html
def test_strip_html():
    input_string = '<p><a href="example.com">Example</a></p>'
    output_string = strip_html(input_string, False)
    print(output_string)
    output_string = strip_html(input_string, True)
    print(output_string)

test_case_0()
test_strip_html()

# Generated at 2022-06-26 01:44:42.849481
# Unit test for function decompress
def test_decompress():
    print('Decompressing')
    print('--------------')

    test_string = "Hello World"

    print('Original: ' + test_string)

    c1 = compress(test_string)
    print('Compressed: ' + c1)

    d1 = decompress(c1)
    print('Decompressed: ' + d1)


# Generated at 2022-06-26 01:44:55.587610
# Unit test for function roman_decode

# Generated at 2022-06-26 01:45:00.756278
# Unit test for function strip_html
def test_strip_html():

    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <foo><bar>foobar</bar></foo>') == 'test: '
    assert strip_html('test: <foo><bar>foobar</bar></foo>', keep_tag_content=True) == 'test: foobar'
    assert strip_html('test: <foo><bar foo="bar">foobar</bar></foo>') == 'test: '
    assert strip_html('test: <foo><bar foo="bar">foobar</bar></foo>', keep_tag_content=True) == 'test: foobar'

# Generated at 2022-06-26 01:45:02.358052
# Unit test for function reverse
def test_reverse():
    assert (reverse('') == '')
    assert (reverse('hello') == 'olleh')
    assert (reverse('a b c d e') == 'e d c b a')



# Generated at 2022-06-26 01:45:06.931367
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XXXVIII') == 38
    assert roman_decode('XXVI') == 26
    assert roman_decode('IV') == 4
    assert roman_decode('I') == 1
    assert roman_decode('LXXXIX') == 89
    assert roman_decode('CXXIII') == 123

# Generated at 2022-06-26 01:45:13.388318
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # test the constructor with valid input
    test__StringFormatter_input_string = __StringFormatter("ciao")
    print(test__StringFormatter_input_string)

    # test the constructor with invalid input
    test__StringFormatter_input_string = __StringFormatter(0)
    print(test__StringFormatter_input_string)



# Generated at 2022-06-26 01:45:20.437100
# Unit test for function slugify
def test_slugify():
    # sth from arg
    # e.g.
    print(slugify('Top 10 Reasons To Love Dogs!!!'))
    assert(slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'), print('slugify failed')
    assert(slugify('Mönstér Mägnët') == 'monster-magnet'), print('slugify failed')


# Generated at 2022-06-26 01:45:36.849568
# Unit test for function strip_html
def test_strip_html():
    string_html = '<br/><a href="https://www.example.com">Click here</a>'

    result_0 = strip_html(string_html)
    result_1 = strip_html(string_html, keep_tag_content=True)

    assert result_0 == 'Click here'
    assert result_1 == 'Click here'

# Run unit test
test_strip_html()


# Generated at 2022-06-26 01:45:43.999447
# Unit test for function roman_decode
def test_roman_decode():
    assert 7 == roman_decode('VII')
    assert 4 == roman_decode('IV')
    assert 3300 == roman_decode('MMMCCC')
    assert 3301 == roman_decode('MMMCCCI')
    assert 3302 == roman_decode('MMMCCCII')
    assert 3303 == roman_decode('MMMCCCIII')
    assert 3304 == roman_decode('MMMCCCIV')
    assert 3305 == roman_decode('MMMCCCV')
    assert 3306 == roman_decode('MMMCCCVI')
    assert 3307 == roman_decode('MMMCCCVII')
    assert 3308 == roman_decode('MMMCCCVIII')
    assert 3309 == roman_decode('MMMCCCIX')

# Generated at 2022-06-26 01:45:50.774784
# Unit test for function roman_decode
def test_roman_decode():
    # Test Case 0:
    roman_numbers_0 = __RomanNumbers()
    try:
        int_0 = roman_numbers_0.decode("VI")
        assert int_0 == 6
    except Exception as e:
        print("test_case_0:", e)
    # Test Case 1:
    roman_numbers_1 = __RomanNumbers()
    try:
        int_1 = roman_numbers_1.decode("XXXII")
        assert int_1 == 32
    except Exception as e:
        print("test_case_1:", e)
    # Test Case 2:
    roman_numbers_2 = __RomanNumbers()

# Generated at 2022-06-26 01:45:51.984400
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    roman_numbers_0 = __RomanNumbers()


# Generated at 2022-06-26 01:45:57.131537
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true") == True
    assert booleanize("1") == True
    assert booleanize("yes") == True
    assert booleanize("y") == True
    assert booleanize("nope") == False

#test_case_0()
#test_booleanize()

# Generated at 2022-06-26 01:45:59.189962
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("aa") == 'aa'
    assert camel_case_to_snake("aAa") == 'aa'
    assert camel_case_to_snake("aaB") == 'aa_b'
 

# Generated at 2022-06-26 01:46:10.008121
# Unit test for function prettify
def test_prettify():
    string = ' unprettified string ,, like this one,will be"prettified" .it\\' \
              's awesome! '
    output = prettify(string)
    correct_output = 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert output == correct_output, 'prettify test case 0 failed'

    string = '5.5 +5.5*5.5 -5.5 /5.5'
    output = prettify(string)
    correct_output = '5.5 + 5.5*5.5 - 5.5 / 5.5'
    assert output == correct_output, 'prettify test case 1 failed'

    string = '5.5+5.5*5.5-5.5/5.5'
    output = prettify

# Generated at 2022-06-26 01:46:11.116719
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    test_case_0()


# PRIVATE API



# Generated at 2022-06-26 01:46:14.250513
# Unit test for function booleanize
def test_booleanize():
    if not booleanize("true") or not booleanize("1") or not booleanize("yes") or not booleanize("y"):
        raise Exception("Error in booleanize test")
    if booleanize("false") or booleanize("0") or booleanize("no") or booleanize("n"):
        raise Exception("Error in booleanize test")

#Unit test for function strip_html

# Generated at 2022-06-26 01:46:23.886245
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test 0
    print(snake_case_to_camel('the_snake_is_green'))
    # --> TheSnakeIsGreen

    # Test 1
    print(snake_case_to_camel('hello'))
    # --> Hello

    # Test 2
    print(snake_case_to_camel('the_snake_is_green', upper_case_first=False))
    # --> theSnakeIsGreen

    # Test 3
    print(snake_case_to_camel('hello', upper_case_first=False))
    # --> hello

    # Test 4
    print(snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-'))
    # --> theSnakeIsGreen

    # Test 5

# Generated at 2022-06-26 01:46:50.048145
# Unit test for function shuffle
def test_shuffle():
    shuffled_str = shuffle('helloworld')
    assert len(shuffled_str) == len('helloworld')
    assert shuffled_str != 'helloworld'


# Generated at 2022-06-26 01:47:01.172220
# Unit test for function reverse
def test_reverse():
    # testing that a string with just one char returns the same string
    assert reverse('a') == 'a'

    # testing simple strings
    assert reverse('ab') == 'ba'
    assert reverse('abc') == 'cba'
    assert reverse('abcd') == 'dcba'

    # testing roman numbers
    assert reverse('V') == 'V'
    assert reverse('X') == 'X'
    assert reverse('L') == 'L'
    assert reverse('C') == 'C'
    assert reverse('D') == 'D'
    assert reverse('M') == 'M'

    assert reverse('IV') == 'VI'
    assert reverse('IX') == 'XI'
    assert reverse('XL') == 'LX'
    assert reverse('XC') == 'CX'
    assert reverse('CD') == 'DC'

# Generated at 2022-06-26 01:47:07.393463
# Unit test for function roman_encode
def test_roman_encode():
    # Checking empty case
    print("Testing roman_encode('') - Empty test")
    result = roman_encode('')
    assert result == ''
    print("PASSED")
    # Checking integer limits
    print("Testing roman_encode(-1) - Lower limit test")
    result = roman_encode(-1)
    assert result == ''
    print("PASSED")
    print("Testing roman_encode(0) - Lower limit test")
    result = roman_encode(0)
    assert result == ''
    print("PASSED")
    print("Testing roman_encode(4000) - Upper limit test")
    result = roman_encode(4000)
    assert result == ''
    print("PASSED")

# Generated at 2022-06-26 01:47:16.498686
# Unit test for function compress

# Generated at 2022-06-26 01:47:20.949224
# Unit test for function prettify
def test_prettify():
    test_strings = [
        '100% foo bar baz !!!',
        ' foo(bar)bar(baz)   baz (foo)',
        ' foo.bar?baz.foo!!!  ',
        'test: <a href="foo/bar">click here</a>',
        ' foo.bar?baz.foo!!!  ',
        ' foo+ bar- baz * foo= bar  ',
        ' foo/ bar\\ baz   ',
        ' foo  foo     foo     foo     foo     foo ',
        '',
        'foo',
        '" foo bar baz "   foo',
        "' foo bar baz '   foo",
        '" foo bar baz "   foo',
        '" foo bar baz "   foo'
    ]


# Generated at 2022-06-26 01:47:22.176435
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    string_formatter = __StringFormatter(" ")


# Generated at 2022-06-26 01:47:25.127234
# Unit test for function strip_html
def test_strip_html():
    string_no_html = strip_html("""<b>This text is bold</b> and this text is normal""")
    assert string_no_html == "This text is bold and this text is normal"


# Generated at 2022-06-26 01:47:25.675521
# Unit test for function roman_decode
def test_roman_decode():
    test_case_0()

# Generated at 2022-06-26 01:47:28.306206
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    str_formatter = __StringFormatter("""some very bad formatted string, with a lot of duplicated, wrong and useless
    spaces inside, like "this".
    """
                                     )

# Generated at 2022-06-26 01:47:31.070272
# Unit test for function roman_decode
def test_roman_decode():
    # Positive test case
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('IV') == 4
    assert roman_decode('LXV') == 65
    assert roman_decode('MMCMLXXXII') == 2982
    assert roman_decode('MMMCMXCIX') == 3999


    # Negative test case
    assert roman_decode('IIII') == None
    assert roman_decode('') == None

