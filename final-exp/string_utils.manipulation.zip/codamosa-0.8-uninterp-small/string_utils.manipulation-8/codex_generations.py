

# Generated at 2022-06-26 01:42:03.694912
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('Test') == 'test'
    assert camel_case_to_snake('-_test') == '-_test'
    assert camel_case_to_snake('test_test_test') == 'test_test_test'
    return


# Generated at 2022-06-26 01:42:08.896216
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') ==  'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') ==  'this_is_a_camel_string_test'
    assert camel_case_to_snake('SSSSSSSSSSSSSSSSSSSSSS') ==  'ssssssssssssssssssssss'
    test_camel_case_to_snake()


# Generated at 2022-06-26 01:42:19.766081
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:42:31.351870
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:42:34.781344
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-26 01:42:41.277703
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("helloWorld") == "hello_world" 
    assert camel_case_to_snake("HelloWorld") == "hello_world" 
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test" 


# Generated at 2022-06-26 01:42:46.570362
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'

test_case_0()
test_camel_case_to_snake()


# Generated at 2022-06-26 01:42:49.862915
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    if camel_case_to_snake('ThisIsACamelStringTest') != 'this_is_a_camel_string_test':
        return False

    return True



# Generated at 2022-06-26 01:42:54.724620
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('  aBcDef  ghIJkLmNoPqRsTuVwXyZ.   AbCdEf   aBcD  ')
    out = sf.format()
    assert out == 'Abcdef ghijklmnopqrstuvwxyz. Abcdef abcd'


# Generated at 2022-06-26 01:42:57.827297
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    ret = camel_case_to_snake("ThisIsACamelStringTest")
    print("test_camel_case_to_snake")
    print("Expected: this_is_a_camel_case_string_test")
    print("Actual: ", ret)



# Generated at 2022-06-26 01:43:11.227226
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # test case 0
    formatter_0 = __StringFormatter("")
    assert formatter_0.format() == ""
    # test case 1
    formatter_1 = __StringFormatter("     a     B   c d   e   ")
    assert formatter_1.format() == "A B C D E"
    # test case 2
    formatter_2 = __StringFormatter("     a     B   c d   e   f g h i j k l m n o p q r s t u v w x y z")
    assert formatter_2.format() == "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
    # test case 3

# Generated at 2022-06-26 01:43:22.772253
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test case 0
    string_format_0 = __StringFormatter("Bruno's Apple  is  on  the  table!")
    string_format_0.format()
    # Test case 1
    string_format_1 = __StringFormatter("Spaghetti ai frutti di mare")
    string_format_1.format()
    # Test case 2
    string_format_2 = __StringFormatter("Aidan O'Riley's Ferrari")
    string_format_2.format()
    # Test case 3
    string_format_3 = __StringFormatter("The F-16's 30-mm M61 gun system")
    string_format_3.format()
    # Test case 4
    string_format_4 = __StringFormatter("Bruno@gmail.com")
    string_format_4.format

# Generated at 2022-06-26 01:43:34.595077
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter('   Ciao   mondo   ')
    assert formatter.format() == 'Ciao mondo'
    formatter = __StringFormatter('WOW!!!')
    assert formatter.format() == 'WOW!!!'
    formatter = __StringFormatter('  WOW!!!wow!!! ')
    assert formatter.format() == 'WOW!!! wow!!!'
    formatter = __StringFormatter('  WOW!!!  wow!!! ')
    assert formatter.format() == 'WOW!!! wow!!!'
    formatter = __StringFormatter('palazzo')
    assert formatter.format() == 'Palazzo'
    formatter = __StringFormatter('palazzo del mare')
    assert formatter.format() == 'Palazzo del mare'
    formatter = __String

# Generated at 2022-06-26 01:43:45.440070
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf0 = __StringFormatter("")    
    sf0_res = sf0.format()
    sf1 = __StringFormatter("prova")    
    sf1_res = sf1.format()
    sf2 = __StringFormatter("p.r.o.v.a")    
    sf2_res = sf2.format()
    sf3 = __StringFormatter("  P.R.O.V.A  ")    
    sf3_res = sf3.format()
    sf4 = __StringFormatter("Mr. and Mrs. Smith went to Washington. n.d.")    
    sf4_res = sf4.format()
    sf5 = __StringFormatter("This is an example, really.")    
    sf5_res = sf

# Generated at 2022-06-26 01:43:58.574553
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    errors_count_0 = 0
    errors_count_1 = 0
    total_count_0 = 0
    total_count_1 = 0
    string_formatter_0 = __StringFormatter("John Smith")
    if string_formatter_0.format() != "John Smith":
        print("ERROR   test___StringFormatter_format at line 34   Expected: John Smith, Got: ", string_formatter_0.format())
        errors_count_0+=1
    total_count_0+=1
    string_formatter_1 = __StringFormatter("john smith")
    if string_formatter_1.format() != "John Smith":
        print("ERROR   test___StringFormatter_format at line 35   Expected: John Smith, Got: ", string_formatter_1.format())
        errors_count_0

# Generated at 2022-06-26 01:44:03.914085
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'


# Generated at 2022-06-26 01:44:16.117307
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True) == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green_and_yellow', upper_case_first=True, separator='-') == 'TheSnakeIsGreenAndYellow'
    assert snake_case_to_camel('the_snake_is_green_and_yellow', upper_case_first=True) == 'TheSnakeIsGreenAndYellow'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=True) == 'TheSnakeIsGreen'

# Generated at 2022-06-26 01:44:19.515964
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("Universita' Bocconi , D.O.C.  ( Doctor Of Comerce )")
    sf.format()

# Mixer unit test for method __uppercase_first_char of class __StringFormatter

# Generated at 2022-06-26 01:44:21.470685
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'


# Generated at 2022-06-26 01:44:28.289507
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Arrange
    input_string1 = 'lorem   ipsum    dolor    sin   '
    input_string2 = 'lorem ipsum    dolor sin'
    input_string3 = '   lorem ipsum dolor sin   '
    input_string4 = '  lorem ipsum    dolor   sin   '
    input_string5 = 'LoreM ipsum Dolor sin'
    input_string6 = 'Lorem Ipsum Dolor Sin'
    input_string7 = 'lorem ipsum dolor sin si...'
    input_string8 = 'lorem ipsum dolor sin si e vai, e vai!'
    input_string9 = 'lorem ipsum dolor sin si  e vai, e vai!'

# Generated at 2022-06-26 01:44:40.296279
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter('!@#$%^&*()_+_|{}:"<>?~`-=[]\;\'./@!#$%^&*()_+}{":?><    abc')
    assert s.format() == 'Abc'


# Generated at 2022-06-26 01:44:42.359195
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('hello world')
    string_formatter_0.format()

# PUBLIC API

# Generated at 2022-06-26 01:44:48.240820
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("")
    assert(sf.format() == "")
    sf = __StringFormatter("Il signore degli anelli")
    assert(sf.format() == "Il Signore Degli Anelli")
    sf = __StringFormatter("1, 2, 3, 4, 5")
    assert(sf.format() == "1, 2, 3, 4, 5")
    sf = __StringFormatter("https://www.google.it")
    assert(sf.format() == "https://www.google.it")
    sf = __StringFormatter("https://www.google.it/test?test=test1&test2=test2")
    assert(sf.format() == "https://www.google.it/test?test=test1&test2=test2")
    sf

# Generated at 2022-06-26 01:45:00.123536
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('in  the  middle      of the night').format() == 'In the middle of the night'
    assert __StringFormatter('a   b   c   d').format() == 'A b c d'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('A   b   c   d').format() == 'A b c d'
    assert __StringFormatter('A b c d').format() == 'A b c d'
    assert __StringFormatter('A:B:C:D').format() == 'A: B: C: D'
    assert __StringFormatter('A-B-C-D').format() == 'A-B-C-D'

# Generated at 2022-06-26 01:45:03.816223
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("this is a simple test. this is   another  test. Did  you  like it?")
    sf.format()


# PUBLIC API


# Generated at 2022-06-26 01:45:11.631703
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    _StringFormatter = __StringFormatter
    assert _StringFormatter('test').format() == 'test'
    assert _StringFormatter('test test').format() == 'test test'
    assert _StringFormatter('test test test').format() == 'test test test'
    assert _StringFormatter(' test test test').format() == 'test test test'
    assert _StringFormatter('test test test ').format() == 'test test test'
    assert _StringFormatter(' test test test ').format() == 'test test test'
    assert _StringFormatter('test  test  test').format() == 'test test test'
    assert _StringFormatter('test test test test').format() == 'test test test test'
    assert _StringFormatter('test test test test ').format() == 'test test test test'
    assert _StringForm

# Generated at 2022-06-26 01:45:22.953717
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test 1
    formatter = __StringFormatter('  calme   et   attentif  comme   une   grenouille  . . . ')
    assert formatter.format() == 'Calme et attentif comme une grenouille...'

    # Test 2
    formatter.input_string = '  Calme   et   attentif  comme   une   grenouille  . . . '
    assert formatter.format() == 'Calme et attentif comme une grenouille...'

    # Test 3
    formatter.input_string = '  cAlme   et   attentif  comme   une   grenouille  . . . '
    assert formatter.format() == 'CAlme et attentif comme une grenouille...'

    # Test 4

# Generated at 2022-06-26 01:45:32.720828
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:45:42.323727
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    __test_inputs = []
    __test_outputs = []

    # test input 1
    __test_inputs.append('"The "quick" brown fox jumps over the lazy dog!"')
    __test_outputs.append('"The quick brown fox jumps over the lazy dog!"')

    # test input 2
    __test_inputs.append('John \'s Smith\'s')
    __test_outputs.append('John Smith\'s')

    # test input 3
    __test_inputs.append('www.google.com')
    __test_outputs.append('www.google.com')

    # test input 4
    __test_inputs.append('mailto:me@googlegroups.com')
    __test_outputs.append('mailto:me@googlegroups.com')

    # test

# Generated at 2022-06-26 01:45:46.297230
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = 'Kaffe is Swedish for "coffee".'

    expected = 'Kaffe is Swedish for "coffee".'

    result = __StringFormatter(input_string).format()
    assert expected == result


# Generated at 2022-06-26 01:45:56.928781
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    str_f = __StringFormatter('###oieuf# $- old_boy!')
    print(str_f.format())


# Generated at 2022-06-26 01:46:09.431130
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Unit test for class __StringFormatter()
    # Correctness for method format:
    formatter = __StringFormatter(" ASDFASDF   A aSDFSDF  Adfs+ - _  aSDF  ASDFASDF   A aSDFSDF  Adfs+ - _ ")
    print("Correctness for method format")
    print("Before: ASDFASDF   A aSDFSDF  Adfs+ - _  aSDF  ASDFASDF   A aSDFSDF  Adfs+ - _  ")
    print("After:  " + formatter.format())
    print("")

    # Correctness for method format:

# Generated at 2022-06-26 01:46:21.183814
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # Create instance of __StringFormatter
    string_0 = 'abc'
    string_formatter_0 = __StringFormatter(string_0)

    # test group of simple lowercase letters
    retval = string_formatter_0.format()
    assert retval == 'Abc'

    string_1 = 'a b c'
    string_formatter_1 = __StringFormatter(string_1)

    # test group of lowercase letters with space
    retval = string_formatter_1.format()
    assert retval == 'A b c'

    string_2 = 'abcabcabcabc'
    string_formatter_2 = __StringFormatter(string_2)

    # test group of lowercase letters with double
    retval = string_formatter_2.format()

# Generated at 2022-06-26 01:46:35.040411
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test case #0 
    to_be_prettyfied_0 = "Maurice Ravel"
    sf_0 = __StringFormatter(to_be_prettyfied_0)
    prettyfied_string_0 = sf_0.format()
    assert prettyfied_string_0 == 'Maurice Ravel'

    # Test case #1 
    to_be_prettyfied_1 = "  Maurice Ravel    "
    sf_1 = __StringFormatter(to_be_prettyfied_1)
    prettyfied_string_1 = sf_1.format()
    assert prettyfied_string_1 == 'Maurice Ravel'

    # Test case #2 
    to_be_prettyfied_2 = "  Maurice Ravel     "
    sf_

# Generated at 2022-06-26 01:46:42.041005
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_0 = 'S0nc3 L1th1um'
    assert __StringFormatter(string_0).format() == 'S0nc3 L1th1um'

    string_1 = 's0nc3 l1th1um'
    assert __StringFormatter(string_1).format() == 'S0nc3 L1th1um'

    string_2 = '!@#$%^ &*()-_+='
    assert __StringFormatter(string_2).format() == '!@#$%^ &*()-_+='

    string_3 = '! @ # $ % ^ & * ( ) - _ + ='
    assert __StringFormatter(string_3).format() == '! @ # $ % ^ & * ( ) - _ + ='


# Generated at 2022-06-26 01:46:52.388857
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter("<p>Hi, I'm cool!</p>")
    out = string_formatter.format()
    out1 = "Hi, I'm cool!"

    if not out.__eq__(out1):
        print("not out.__eq__(out1)")
        return False

    string_formatter = __StringFormatter("  <p> Hi, I'm cool!</p>")
    out = string_formatter.format()
    out1 = "Hi, I'm cool!"

    if not out.__eq__(out1):
        print("not out.__eq__(out1)")
        return False

    string_formatter = __StringFormatter("<p> Hi, I'm cool!</p>")
    out = string_formatter.format()
    out

# Generated at 2022-06-26 01:47:02.979289
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # This test case checks the formatting of a string.
    # The input string is fed to the method format which will update it according to rules written in
    # __StringFormatter class.
    # The output string of the method format must be equals to the expected output string.
    input_string_0 = 'one   TWO  five ANTHONY  THREE  '
    output_string_0 = 'One  Two Five Anthony Three '
    __string_formatter_0 = __StringFormatter(input_string_0)
    assert __string_formatter_0.format() == output_string_0

    # This test case checks the formatting of a string.
    # The input string is fed to the method format which will update it according to rules written in
    # __StringFormatter class.
    # The output string of the method format must be equals to the expected output string

# Generated at 2022-06-26 01:47:04.512516
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("this is a test  ")
    sf.format()


# Generated at 2022-06-26 01:47:09.634037
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '     This- (is: a, test);   for;   format()   '
    target_string = 'This is a test for format'
    formatter = __StringFormatter(input_string)
    actual_string = formatter.format()
    if actual_string != target_string:
        raise Exception('Actual string does not match target string')

test___StringFormatter_format()


# PUBLIC API



# Generated at 2022-06-26 01:47:19.200998
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:47:40.943701
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    #print("original string:")
    #print(original)
    #print("compressed string:")
    #print(compressed)
    decompressed = decompress(compressed)
    #print("decompressed string:")
    #print(decompressed)


# Generated at 2022-06-26 01:47:52.049373
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   my  text   is   cool   ').format() == 'My text is cool'
    assert __StringFormatter('my_text_is_cool').format() == 'My text is cool'
    assert __StringFormatter('my-text-is-cool').format() == 'My text is cool'
    assert __StringFormatter('myTextIsCool').format() == 'My text is cool'
    assert __StringFormatter('my text is cool!!@@').format() == 'My text is cool!'
    assert __StringFormatter('my text is cool!').format() == 'My text is cool!'
    assert __StringFormatter('my text is cool.').format() == 'My text is cool.'
    assert __StringFormatter('my text is cool').format() == 'My text is cool'

# Generated at 2022-06-26 01:47:58.096970
# Unit test for function slugify
def test_slugify():
    print("Testing SLUGIFY()")
    result = slugify("Top 10 Reasons To Love Dogs!!!")
    expected = "top-10-reasons-to-love-dogs"
    if result == expected:
        print("Nice SLUGIFY! You passed the test!\n")
    else:
        print("Uh... Something was wrong. Check your function again!\n")

# Generated at 2022-06-26 01:48:04.202326
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = "Hello"
    encoding = 'utf-8'
    __StringCompressor.__require_valid_input_and_encoding(input_string, encoding)


# Generated at 2022-06-26 01:48:10.470921
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('abc') == 'cba'
    assert reverse('abcd') == 'dcba'
    assert reverse('abcde') == 'edcba'
    assert reverse('abcdef') == 'fedcba'
    assert reverse('abcdefg') == 'gfedcba'
    assert reverse('abcdefgh') == 'hgfedcba'


# Generated at 2022-06-26 01:48:13.786941
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'


# Generated at 2022-06-26 01:48:18.427909
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __test_stringCompressor = __StringCompressor()


# PUBLIC API



# Generated at 2022-06-26 01:48:22.645059
# Unit test for function slugify

# Generated at 2022-06-26 01:48:29.850423
# Unit test for function booleanize
def test_booleanize():
    boolean_test_set = [('true', True), ('1', True), ('yes', True), ('y', True), ('false', False), ('0', False),
                        ('no', False), ('n', False), ('YA', False)]
    for test_case in boolean_test_set:
        assert booleanize(test_case[0]) == test_case[1], test_case[0]


# Generated at 2022-06-26 01:48:43.835233
# Unit test for function strip_margin
def test_strip_margin():
    expected_result0 = '''
line 1
line 2
line 3
'''
    input_string0 = '''
    line 1
    line 2
    line 3
'''

    actual_result0 = strip_margin(input_string0)

    print('test_strip_margin 0: expected =', expected_result0)
    print('test_strip_margin 0: actual   =', actual_result0)
    assert actual_result0 == expected_result0

    expected_result1 = '''
line 1
line 2
line 3
'''
    input_string1 = '''
    line 1
line 2
    line 3
'''

    actual_result1 = strip_margin(input_string1)

    print('test_strip_margin 1: expected =', expected_result1)

# Generated at 2022-06-26 01:49:08.679068
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("I") == 1
    assert roman_decode("II") == 2
    assert roman_decode("III") == 3
    assert roman_decode("IV") == 4
    assert roman_decode("V") == 5
    assert roman_decode("VI") == 6
    assert roman_decode("VII") == 7
    assert roman_decode("VIII") == 8
    assert roman_decode("IX") == 9
    assert roman_decode("X") == 10
    assert roman_decode("XI") == 11
    assert roman_decode("XII") == 12
    assert roman_decode("XIII") == 13
    assert roman_decode("XIV") == 14

# Generated at 2022-06-26 01:49:13.000937
# Unit test for function asciify
def test_asciify():
    par1 = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    par2 = 'eeuuooaaeynAAACIINOE'
    res = asciify(par1)
    assert (res == par2)


# Generated at 2022-06-26 01:49:14.724492
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('str', compression_level=9)) == 'str'


# Generated at 2022-06-26 01:49:19.007304
# Unit test for function prettify
def test_prettify():
    input = ' unprettified string ,, like this one,will be"prettified" .it\\'    
    op = 's awesome! '
    output = 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    expected = prettify(input + op)
    assert expected == output


# Generated at 2022-06-26 01:49:22.784968
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('S') == 's'
    assert camel_case_to_snake('ab') == 'ab'
    assert camel_case_to_snake('Ab') == 'ab'
    assert camel_case_to_snake('AB') == 'ab'
    assert camel_case_to_snake('AbC') == 'ab_c'
    assert camel_case_to_snake('AbCd') == 'ab_cd'
    assert camel_case_to_snake('AbCdE') == 'ab_cde'


# Generated at 2022-06-26 01:49:27.249704
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test = __StringFormatter("This is my test")
    assert test.input_string == "This is my test", 'fail'


# Generated at 2022-06-26 01:49:35.498969
# Unit test for function strip_html
def test_strip_html():
    input_string = '<b>test:</b> <a href="foo/bar">click here</a>'
    keep_tag_content = True
    out = strip_html(input_string, keep_tag_content)
    assert out == 'test: click here', 'test_strip_html should return: test: click here'

    input_string = '<b>test:</b> <a href="foo/bar">click here</a>'
    keep_tag_content = False
    out = strip_html(input_string, keep_tag_content)
    assert out == 'test: ', 'test_strip_html should return: test: '

    input_string = '<b>test:</b> <a href="foo/bar">click here</a>'
    keep_tag_content = True

# Generated at 2022-06-26 01:49:47.664882
# Unit test for function booleanize
def test_booleanize():
    # Define input variables
    test_input_0 = 'true'
    test_input_1 = 'YES'
    test_input_2 = 'nope'

    # Get the expected output
    output_expected_0 = True
    output_expected_1 = True
    output_expected_2 = False

    # Get the actual output
    output_actual_0 = booleanize(test_input_0)
    output_actual_1 = booleanize(test_input_1)
    output_actual_2 = booleanize(test_input_2)

    # Compare the expected output with the actual one and print out the result

# Generated at 2022-06-26 01:49:51.689667
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    result = snake_case_to_camel('the_snake_is_green')
    assert result == 'TheSnakeIsGreen'


if __name__ == '__main__':
    test_case_0()
    test_snake_case_to_camel()

# Generated at 2022-06-26 01:49:54.043413
# Unit test for function reverse
def test_reverse():
    if reverse('hello') != 'olleh':
        print('reverse test failed')
        exit(-1)
    print('reverse test passed')


# Generated at 2022-06-26 01:50:28.744948
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    print('Test __StringFormatter class constructor')
    try:
        s = __StringFormatter('test_pwd')
        print(s.format())
    except Exception as e:
        print('Constructor error: ' + str(e))
        exit(1)
    print('Constructor OK')


# Generated at 2022-06-26 01:50:32.317305
# Unit test for function booleanize
def test_booleanize():
    roman_numbers_1 = __RomanNumbers()
    #TODO it is not clear why these are correct.
    assert True == booleanize('True')
    assert False == booleanize('False')


# Generated at 2022-06-26 01:50:35.213314
# Unit test for function asciify
def test_asciify():
    # Test Case I
    input_string_0 = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    output_string_0 = asciify(input_string_0)
    expected_string_0 = "eeuuooaaeynAAACIINOE"
    if output_string_0 == expected_string_0:
        print("Test Case I: OK")
    else:
        print("Test Case I: FAILED")


# Generated at 2022-06-26 01:50:37.926951
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test')


# Generated at 2022-06-26 01:50:40.135281
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("yes") == True
    assert booleanize("YES") == True
    assert booleanize("hello") == False
    assert booleanize("1") == True


# Generated at 2022-06-26 01:50:44.248355
# Unit test for function strip_html
def test_strip_html():
    # Simple HTML structure
    str1 = r'<a href="site.com">visit us</a>'
    assert strip_html(str1,keep_tag_content=True) == "visit us"
    assert strip_html(str1) == ""

    # Complex HTML structure
    str2 = r'<ul><li><a href="site.com">visit us</a></li></ul>'
    assert strip_html(str2,keep_tag_content=True) == "visit us"
    assert strip_html(str2) == ""

    # Incomplete HTML structure
    str3 = r'<ul><li><a href="site.com">visit us</a></ul>'
    assert strip_html(str3,keep_tag_content=True) == "visit us"
    assert strip_

# Generated at 2022-06-26 01:50:48.819557
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    print(snake_case_to_camel('the_snake_is_green'))
    print(snake_case_to_camel('_the_snake_is_green_'))
    print(snake_case_to_camel('the_ number_is_5'))
    print(snake_case_to_camel('the-number-is-5'))
    print(snake_case_to_camel('the-number-is-5', False))

    #this is not a valid snake case, therefore the original string is returned
    print(snake_case_to_camel('TheSnakeIsGreen'))


# Generated at 2022-06-26 01:50:52.352299
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('test'), encoding='ascii') == 'test'
    assert decompress(compress('test')) == 'test'
    assert decompress(compress('éàù')) == 'éàù'


# Generated at 2022-06-26 01:50:58.310020
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "Lorem ipsum dolor sit amet,   consetetur  sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua."
    string_formatter = __StringFormatter(input_string)
    out = string_formatter.format()


# Generated at 2022-06-26 01:50:59.508792
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    constr = __StringFormatter("test_input")
