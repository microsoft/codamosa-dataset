

# Generated at 2022-06-26 01:42:06.200912
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # check for non string input
    with pytest.raises(InvalidInputError):
        snake_case_to_camel(input_string=1)

    # check for invalid input
    assert snake_case_to_camel(input_string='?*&%$') == '?*&%$'

    # validate
    assert snake_case_to_camel('a_string') == 'AString'
    assert snake_case_to_camel('a_string', separator='-') == 'AString'
    assert snake_case_to_camel('a_string', upper_case_first=False) == 'aString'
    assert snake_case_to_camel('a_str_ing', separator='_') == 'AStrIng'

# Generated at 2022-06-26 01:42:08.493049
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test"

# Performance test for function camel_case_to_snake

# Generated at 2022-06-26 01:42:13.850646
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    try:
        testcase = __StringFormatter("")
        result = testcase.format()
        return True
    except Exception as e:
        print("Exception in: test___StringFormatter_format [Exception message: " + str(e) + "]")
        return False


# Generated at 2022-06-26 01:42:15.939472
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-26 01:42:23.370019
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('XIV') == 'xiv'
    assert camel_case_to_snake('CDV') == 'cdv'
    assert camel_case_to_snake('IV') == 'iv'


# Generated at 2022-06-26 01:42:33.084664
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='.') == 'this.is.a.camel.string.test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator=' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='\n') == 'this\nis\na\ncamel\nstring\ntest'

# Generated at 2022-06-26 01:42:37.505683
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Define input parameters values
    input_string = 'ThisIsACamelStringTest'
    separator = '_'

    # Execute function
    camel_case_to_snake(input_string, separator)



# Generated at 2022-06-26 01:42:47.785310
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('THISISACAMELSTRINGTEST') == 'thisisacamelstringtest'
    assert camel_case_to_snake('thisIsACamelStringTest', '+') == 'this+is+a+camel+string+test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'

# Generated at 2022-06-26 01:42:52.476713
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    print("Test for function camel_case_to_snake")
    assert(camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test')
    print("Test for function camel_case_to_snake: Passed")
    return


# Generated at 2022-06-26 01:42:55.928639
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-26 01:43:02.110353
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("         un test bla bla         ")
    sf.format()



# Generated at 2022-06-26 01:43:09.765443
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    test_case_0()
    test0 = snake_case_to_camel("the_snake_is_green")
    print(test0)
    print()
    assert test0 == 'TheSnakeIsGreen'
    test1 = snake_case_to_camel("_the_snake_is_green_")
    print(test1)
    print()
    assert test1 == '_TheSnakeIsGreen_'
    test2 = snake_case_to_camel("abc")
    print(test2)
    print()
    assert test2 == 'Abc'
    test3 = snake_case_to_camel("abc",upper_case_first=False)
    print(test3)
    print()
    assert test3 == 'abc'

# Generated at 2022-06-26 01:43:14.330111
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string = __StringFormatter("This is a test string.")
    assert test_string.format() == "This is a test string."


# Generated at 2022-06-26 01:43:17.287830
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test__StringFormatter = __StringFormatter('this is a Test string...')
    assert test__StringFormatter.format() == 'This is a test string'


# Generated at 2022-06-26 01:43:25.478992
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_case_0()
    string_format_0 = __StringFormatter("")
    # Test 0
    assert string_format_0.format() == "", 'Test 0 failed'
    string_format_1 = __StringFormatter("    bar    ")
    # Test 1
    assert string_format_1.format() == "bar", 'Test 1 failed'
    string_format_2 = __StringFormatter("foo bar")
    # Test 2
    assert string_format_2.format() == "foo bar", 'Test 2 failed'
    string_format_3 = __StringFormatter("foo-bar")
    # Test 3
    assert string_format_3.format() == "foo bar", 'Test 3 failed'
    string_format_4 = __StringFormatter("foo-bar-baz")
    # Test 4


# Generated at 2022-06-26 01:43:37.621659
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter('this is a test          it is')
    assert (formatter_0.format() == "This is a test it is")

    formatter_1 = __StringFormatter('this one    is   a test')
    assert(formatter_1.format() == 'This one is a test')

    formatter_2 = __StringFormatter('this is   a    test')
    assert(formatter_2.format() == 'This is a test')

    formatter_3 = __StringFormatter('this is a test')
    assert(formatter_3.format() == 'This is a test')

    formatter_4 = __StringFormatter('this -is a test')
    assert(formatter_4.format() == 'This -is a test')


# Generated at 2022-06-26 01:43:44.147436
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # test input_string
    assert snake_case_to_camel('The_snake_is_green') == 'TheSnakeIsGreen'
    # test upper_case_first
    assert snake_case_to_camel('The_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    # test separator
    assert snake_case_to_camel('The_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    # test hybrid
    assert snake_case_to_camel('The-snake_is-green', separator='-', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-26 01:43:56.349863
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake') == 'Snake'
    assert snake_case_to_camel('snake', upper_case_first=False) == 'snake'
    assert snake_case_to_camel('the_snake_is_green', separator='_') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the/snake/is/green', separator='/') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'

# Generated at 2022-06-26 01:44:09.163763
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'theSnakeIsGreen' == snake_case_to_camel('the_snake_is_green')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the-snake-is-green')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the snake is green', separator=' ')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the.snake.is.green', separator='.')
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=True)
    assert 'TheSnakeIsGreen' == snake_case_to_camel('The_snake_is_green', upper_case_first=True)

# Generated at 2022-06-26 01:44:20.004213
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    # test that checks if __uppercase_first_char handles appropriately a given input
    def test_case_1():
        assert __StringFormatter('').__uppercase_first_char('a') == 'A'

    # test that checks if __remove_duplicates handles appropriately a given input
    def test_case_2():
        assert __StringFormatter('').__remove_duplicates('the ba') == 'b'

    # test that checks if __uppercase_first_letter_after_sign handles appropriately a given input
    def test_case_3():
        assert __StringFormatter('').__uppercase_first_letter_after_sign(' ein') == 'Ein'

    # test that checks if __ensure_right_space_only handles appropriately a given input

# Generated at 2022-06-26 01:44:28.711204
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    stringFormatter_0 = __StringFormatter('3  <> 3')
    str = stringFormatter_0.format()
    # print(str)
    # stringFormatter_0 = __StringFormatter('  <>   ')
    # str = stringFormatter_0.format()
    # print(str)
    # stringFormatter_0 = __StringFormatter('  :)   ')
    # str = stringFormatter_0.format()
    # print(str)
    # stringFormatter_0 = __StringFormatter('  x   ')
    # str = stringFormatter_0.format()
    # print(str)
    # stringFormatter_0 = __StringFormatter('  <3   ')
    # str = stringFormatter_0.format()
    # print(str)
    # string

# Generated at 2022-06-26 01:44:30.044414
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('Hello, world')
    assert string_formatter.format() == 'Hello, World'


# Generated at 2022-06-26 01:44:31.454503
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter("This IS a RAnD oM STRInG to prettify!!")
    s.format()


# Generated at 2022-06-26 01:44:33.608839
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('')
    formatted = string_formatter.format()
    assert formatted == '', "Passed"
    print("Passed")

test___StringFormatter_format()


# Generated at 2022-06-26 01:44:38.852767
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    t1 = __StringFormatter('').format()
    assert t1 == ''

    t2 = __StringFormatter(' ').format()
    assert t2 == ' '

    t3 = __StringFormatter(' hello world   ').format()
    assert t3 == 'hello world'

    t4 = __StringFormatter(' hello world   ').format()
    assert t4 == 'hello world'

    t5 = __StringFormatter(' hello world   ').format()
    assert t5 == 'hello world'

    t6 = __StringFormatter('hello    world ').format()
    assert t6 == 'hello world'

    t7 = __StringFormatter('hello world Very Nice').format()
    assert t7 == 'hello world very nice'

    t8 = __StringFormatter('abc 123').format()
    assert t8

# Generated at 2022-06-26 01:44:43.150744
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    __StringFormatter('john-doe').format()
    __StringFormatter('').format()

    try:
        __StringFormatter(None)
        # If the above line doesn't raise an error, the test has failed.
        raise Exception('Failed unit test')
    except InvalidInputError:
        pass


# Generated at 2022-06-26 01:44:44.776414
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    x = __StringFormatter('a string')
    #y = x.format()
    z = x.format()


# Generated at 2022-06-26 01:44:57.016922
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf_0 = __StringFormatter("hello world")
    assert(sf_0.format() == "Hello world")

    sf_1 = __StringFormatter("how are you?")
    assert(sf_1.format() == "How are you?")

    sf_2 = __StringFormatter("hello. how are you?")
    assert(sf_2.format() == "Hello. How are you?")

    sf_3 = __StringFormatter("hello? how are you?")
    assert(sf_3.format() == "Hello? How are you?")

    sf_4 = __StringFormatter("hello... can you hear me?")
    assert(sf_4.format() == "Hello... Can you hear me?")

    sf_5 = __StringFormatter("hello!!! can you hear me?")

# Generated at 2022-06-26 01:45:00.123022
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '____ ____'
    #expected = '_ _'
    expected = '_ _'
    assert __StringFormatter(input_string).format() == expected, 'Format not working'


# Generated at 2022-06-26 01:45:10.210755
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:45:29.983621
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:45:41.462581
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter("This     is a test!")
    assert string_formatter_0.format() == "This is a test!"

    string_formatter_1 = __StringFormatter("This is just a test https://www.google.com?")
    assert string_formatter_1.format() == "This is just a test https://www.google.com ?"

    string_formatter_2 = __StringFormatter("This is the test for https://www.open-mpi.org/projects/hwloc/doc/v1.11.8/a00017.php#ga2a6f0d0c1b6aec17f3c3c647b924e2b6")

# Generated at 2022-06-26 01:45:45.253657
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('I love this  place, ')
    result = sf.format()
    expected_result = 'I love this place, '
    assert result == expected_result


# Generated at 2022-06-26 01:45:54.467999
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "autem eiusmod  sunt   laboris velit reprehenderit cillum  cillum ut tempor enim do labore ardua excepteur  eiusmod  consectetur    reprehenderit  dolor   labore   sint  sunt elit  eiusmod irure         culpa             proident     dolore      minim dolor in  ut pariatur  irure    incididunt anim dolor in  culpa  magna amet pariatur."

    string_formatter = __StringFormatter(input_string)
    output_string = string_formatter.format()
    print(output_string)



# PUBLIC API


# converts camelCase to snake_case

# Generated at 2022-06-26 01:45:57.155222
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter_0 = __StringFormatter('this is a string')
    string_formatter_result_0 = string_formatter_0.format()


# Generated at 2022-06-26 01:45:59.939476
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print("Start test__StringFormatter_format")
    sf = __StringFormatter("  My String to be    Formatted    in a better uppercase way.  ")
    result = sf.format()
    assert result == "My string to be formatted in a better uppercase way."
    print("End test__StringFormatter_format")


# Generated at 2022-06-26 01:46:04.051166
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Unit test for method format of class __StringFormatter
    formatter_0 = __StringFormatter("Le meilleur c'est les cèpes")

    formatter_0.format()


# Generated at 2022-06-26 01:46:18.146158
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print('\nUnit test for method format of class __StringFormatter')

    # test case 0
    try:
        # initialize the object
        s = __StringFormatter('')
    except:
        print('test case 0 KO')
        raise
    else:
        print('test case 0 OK')

    # test case 1
    try:
        # initialize the object
        s = __StringFormatter(None)
    except InvalidInputError as e:
        print('test case 1 KO')
    else:
        print('test case 1 OK')

    # test case 2
    try:
        # initialize the object
         s = __StringFormatter(123)
    except InvalidInputError as e:
        print('test case 2 KO')
    else:
        print('test case 2 OK')

    # test case 3

# Generated at 2022-06-26 01:46:30.840492
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:46:32.994003
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Init object __StringFormatter
    input_string = "  qwe'rty (asd)   :"
    __StringFormatter_test = __StringFormatter(input_string)

    # Call method format of __StringFormatter_test
    __StringFormatter_test.format()


# Generated at 2022-06-26 01:47:03.369965
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .strings import prettify
    
    # TEST 1
    str_in = 'ciao Ciao cIao ciaO CIAO   '
    str_out = 'Ciao ciao cIao ciaO CIaO'
    str_out_prettify = prettify(str_in, {'space_out': True})
    assert(str_out_prettify == str_out)
    print('test___StringFormatter_format: OK, TEST 1')
    print('----> str_in = "%s", str_out = "%s"' % (str_in, str_out))
    print('----> str_out_prettify = "%s"' % (str_out_prettify))
    
    # TEST 2

# Generated at 2022-06-26 01:47:12.201789
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    strs = [
        '   this is a test        ',
        'This is a test!!',
        'tHiS iS a TeSt!!',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is test&&&',
        'is    test&&&',
        'is test&&&    ',
        'is    test&&&    ',
        'Where\xE2\x80\x99s my money?',
        'jojo\'s Bizarre adventure',
    ]

    for s in strs:
        f = __StringFormatter(s)

# Generated at 2022-06-26 01:47:15.428838
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_0 = __StringFormatter("a. bcd. efg. hijk")
    string_0.format()
    string_1 = __StringFormatter("a. bcd. efg. hijk")
    string_1.format()


# Generated at 2022-06-26 01:47:16.355587
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_case_0()


# Generated at 2022-06-26 01:47:20.586344
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('  This  is  a  test  text  ')
    out = sf.format()
    if out != 'This is a test text':
        raise Exception('[__StringFormatter_format] expected "', out, '" but got "This is a test text"')


# Generated at 2022-06-26 01:47:30.421346
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Test for invalid input
    try:
        sformatter = __StringFormatter(123)
        assert False
    except InvalidInputError:
        assert True

    # Test 1
    sformatter = __StringFormatter("@abc,def@ghi.JKL?mno:pqr;stu~vwx[yz]")
    out = sformatter.format()

    assert out == "@Abc, def@ghi.jkl?mno:pqr;stu~vwx[yz]"

    # Test 2
    sformatter = __StringFormatter("@abc,def@ghi.JKL?mno:pqr;stu~vwx[yz]@abc,def@ghi.JKL?mno:pqr;stu~vwx[yz]")

# Generated at 2022-06-26 01:47:38.946038
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "Anna Maria Malaparté, who lived at Via de 'Tornabuoni, Paris, was the daughter of the wealthy Marquis Lamberto Malaparté, who had taken the name of Comte de Douard after his father's death."
    expected_output_string = "Anna Maria Malaparte, who lived at Via de Tornabuoni, Paris, was the daughter of the wealthy Marquis Lamberto Malaparte, who had taken the name of Comte de Douard after his father's death."
    instance = __StringFormatter(input_string)
    output_string = instance.format()
    assert output_string == expected_output_string


# PUBLIC API



# Generated at 2022-06-26 01:47:40.604728
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    s = __StringFormatter.format(' tony   stark   hulk   ')
    print(s)


# Generated at 2022-06-26 01:47:45.818440
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert(__StringFormatter('Foo bar baz').format() == 'Foo bar baz')
    assert(__StringFormatter('Foo bar baz').format() != 'FooBarBaz')
    assert(__StringFormatter('FooBarBaz').format() == 'Foo Bar Baz')
    # TODO: Add more test case


# Generated at 2022-06-26 01:47:48.200674
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    #setup
    sf = __StringFormatter("hello world")

    # verify
    assert sf.format() == "Hello World"


# Generated at 2022-06-26 01:48:10.385671
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = "My  Name  is   Anthony   Zin"
    f = __StringFormatter(input_string)
    assert f.format() == "My Name Is Anthony Zin"


# Generated at 2022-06-26 01:48:12.836198
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter("hello WORLD")
    sf.format()


# Generated at 2022-06-26 01:48:21.585888
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    example_input = '  this is a+   test { } \n\n\n\n\t. <>$";\n[]:;@()=~!#~`*|%&\n\r  '
    expected_output = 'This is a test.'
    output = __StringFormatter(example_input).format()
    assert output == expected_output


# Generated at 2022-06-26 01:48:32.674540
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter('  ciao\t ciao, ciao  \t \tciao. ciao\t ciao    , ciao \t \t \t ciao\t ciao \t ciao\t ciao\t ciao\t ciao\t ciao\t ciao')
    output_0 = formatter_0.format()
    assert output_0 == 'Ciao ciao, ciao ciao. Ciao ciao, ciao ciao ciao ciao ciao ciao ciao ciao ciao.'


# Generated at 2022-06-26 01:48:44.239762
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:48:46.117588
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter('this is a   test  ')
    output = string_formatter.format()
    assert output == "This is a test"


# Generated at 2022-06-26 01:48:56.524448
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    fmt = __StringFormatter('this is a test')
    assert fmt.format() == 'This is a test'
    
    fmt = __StringFormatter('This is a test')
    assert fmt.format() == 'This is a test'
    
    fmt = __StringFormatter('this, is a test')
    assert fmt.format() == 'This, is a test'
    
    fmt = __StringFormatter('this is, a test')
    assert fmt.format() == 'This is, a test'
    
    fmt = __StringFormatter('this is a test,')
    assert fmt.format() == 'This is a test,'
    
    fmt = __StringFormatter('this is a test.  ')
    assert fmt.format() == 'This is a test.'
    

# Generated at 2022-06-26 01:49:06.215009
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello').format() == 'Hello'
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('Hello World').format() == 'Hello world'
    assert __StringFormatter('Hello World!').format() == 'Hello world!'
    assert __StringFormatter('Hello World !').format() == 'Hello world !'
    assert __StringFormatter('Hello World ! ').format() == 'Hello world !'
    assert __StringFormatter(' Hello World ! ').format() == 'Hello world !'
    assert __StringFormatter('Hello world ! ').format() == 'Hello world !'
    assert __StringFormatter('Hello world !').format() == 'Hello world !'
    assert __StringFormatter('Hello world ! ').format() == 'Hello world !'
    assert __String

# Generated at 2022-06-26 01:49:11.624600
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    original_string = 'This, is -- a  test   String: w/o- any  :  pretty format.   it´s  very  awful!'
    output_string = __StringFormatter(original_string).format()

    expected_output_string = 'This is a test string without any pretty format. It\'s very awful!'
    if(output_string != expected_output_string):
        raise Exception('Test failed')


# Generated at 2022-06-26 01:49:13.833515
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter('hello  World')
    assert formatter_0.format() == 'Hello World'


# Generated at 2022-06-26 01:50:21.248523
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter_0 = __StringFormatter('')
    assert formatter_0.format() == ''

    formatter_1 = __StringFormatter('hello, world')
    assert formatter_1.format() == 'Hello, World'

    formatter_2 = __StringFormatter('hello, world...!!!!')
    assert formatter_2.format() == 'Hello, World!'

    formatter_3 = __StringFormatter('hello, world!!!')
    assert formatter_3.format() == 'Hello, World!'

    formatter_4 = __StringFormatter('hello, world')
    assert formatter_4.format() == 'Hello, World'

    formatter_5 = __StringFormatter('i am going to test this function')
    assert formatter_5.format() == 'I am going to test this function'

    form

# Generated at 2022-06-26 01:50:32.753471
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    format_0 = __StringFormatter.__uppercase_first_char("MARCOS")
    format_1 = __StringFormatter.__remove_duplicates("ANANTTIO")
    format_2 = __StringFormatter.__uppercase_first_letter_after_sign("hello,my friend")
    format_3 = __StringFormatter.__ensure_right_space_only("hello,")
    format_4 = __StringFormatter.__ensure_left_space_only("hello,")
    format_5 = __StringFormatter.__ensure_spaces_around("hello,")
    format_6 = __StringFormatter.__remove_internal_spaces("hello,    world")
    format_7 = __StringFormatter.__fix_saxon_genitive("mr peter")
    __String

# Generated at 2022-06-26 01:50:33.590972
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_case_0()


# Generated at 2022-06-26 01:50:44.402265
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    roman_numbers_0 = __RomanNumbers()
    roman_numbers_0.format('1')
    roman_numbers_0.format('123')
    roman_numbers_0.format('1234')
    roman_numbers_0.format('12345')
    roman_numbers_0.format('123456')
    roman_numbers_0.format('1234567')
    roman_numbers_0.format('12345678')
    roman_numbers_0.format('123456789')
    roman_numbers_0.format('1234567890')
    roman_numbers_0.format('-1234567890')
    roman_numbers_0.format('-1')

# Generated at 2022-06-26 01:50:46.267139
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_formatter = __StringFormatter("this is a test string")
    res = test_formatter.format()
    assert res == " This is a test string "


# Generated at 2022-06-26 01:50:56.977869
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-26 01:50:59.536985
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    topic_0 = __StringFormatter('Jean-Michel      IMBERT    ')
    # topic_0.format()

# public api

# convert snake_case to camelCase

# Generated at 2022-06-26 01:51:04.100702
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    stringFormatter = __StringFormatter('   this is a string with  some duplicates and with some emails@gmail.com to   format  ')
    assert stringFormatter.format() == 'This is a string with some duplicates and with some emails@gmail.com to format'


# UNIT TEST


# Generated at 2022-06-26 01:51:06.815168
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_formatter = __StringFormatter("  YO  ,  THIS    IS    A  TEST  !  ")
    print('Final value: ' + string_formatter.format())

# PUBLIC API

# Generated at 2022-06-26 01:51:13.478621
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    test_string_0 = "  some  input  "
    test_string_1 = "  some  -  input  "
    test_string_2 = "  some  -  INPUT  "
    test_string_3 = "  some  -  input  -  some  "
    test_string_4 = "  some  -  input  -  some  -  some  "
    test_string_5 = "  some  -  input  -  some  -  some  -  some  "
    test_string_6 = "  some  -  Input  -  some  -  some  -  some  "
    test_string_7 = "  some  -  input  -  some  -  some  -  some  "