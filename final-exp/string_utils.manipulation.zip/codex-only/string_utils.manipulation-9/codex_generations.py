

# Generated at 2022-06-24 02:09:21.312287
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('I') == 1
    assert roman_decode('X') == 10
    assert roman_decode('M') == 1000
    assert roman_decode('MM') == 2000
    assert roman_decode('MMM') == 3000
    assert roman_decode('MMMCMXCIX') == 3999


# Generated at 2022-06-24 02:09:33.822263
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('ab_cd') == 'AbCd'
    assert snake_case_to_camel('ab_cd', False) == 'abCd'
    assert snake_case_to_camel('ab_cd', separator='-') == 'AbCd'
    assert snake_case_to_camel('ab_cd', False, separator='-') == 'abCd'
    assert snake_case_to_camel('abcd') == 'Abcd'
    assert snake_case_to_camel('abcd', False) == 'abcd'
    assert snake_case_to_camel('') == ''
    assert snake_case_to_camel('', False) == ''
    assert snake_case_to_camel('a', False) == 'a'

# Generated at 2022-06-24 02:09:45.073177
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .errors import InvalidInputError, ValueError
    from .validation import is_string, is_integer

    # test invalid input
    for input_type in [None, True, False, [], [1, 2], (1, 2), {}, {'a': 2}, {'a': 'b'}, 1, 2.1]:
        try:
            __StringFormatter(input_type).format()
            assert False, 'InvalidInputError not raised'
        except InvalidInputError as e:
            assert str(e) == 'Invalid input, "{}" is not a string'.format(input_type), 'Error message does not match'

    # test empty string

# Generated at 2022-06-24 02:09:57.273589
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('') == ''

    input_string = 'My random string'

    assert __StringCompressor.compress(input_string) == __StringCompressor.compress(input_string, 'utf-8')

    assert __StringCompressor.compress(input_string, 'utf-8') != __StringCompressor.compress(input_string, 'latin-1')
    assert __StringCompressor.compress(input_string, 'latin-1') != __StringCompressor.compress(input_string, 'us-ascii')

    assert __StringCompressor.compress(input_string) == __StringCompressor.decompress(__StringCompressor.compress(input_string))
    assert __StringCompressor.compress(input_string, 'latin-1') == __String

# Generated at 2022-06-24 02:10:06.348410
# Unit test for function decompress
def test_decompress():
    # Test 1
    n = 0
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    # expected output
    original = input_string
    # actual output
    dec = decompress(compress(input_string))
    print(dec)
    # check test 1
    if dec == original:
        print('Test 1 is passed.')
    else:
        print('Test 1 is failed.')
    # Test 2
    # expected output
    original = 'hello world'
    # actual output
    dec = decompress(compress(original))
    print(dec)
    # check test 2
    if dec == original:
        print('Test 2 is passed.')
    else:
        print('Test 2 is failed.')
    # Test 3
    # expected output

# Generated at 2022-06-24 02:10:17.441470
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:10:21.831626
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:10:26.007842
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
    |line 1
    |line 2
    |
    |line 3
    '''
    s = strip_margin(s)
    print(s)
    assert s == '''
line 1
line 2

line 3
'''



# Generated at 2022-06-24 02:10:32.770985
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    value = __RomanNumbers.encode(1)
    assert value == 'I'

    value = __RomanNumbers.encode(3999)
    assert value == 'MMMCMXCIX'

    value = __RomanNumbers.decode('I')
    assert value == 1

    value = __RomanNumbers.decode('MMMCMXCIX')
    assert value == 3999


# PUBLIC API



# Generated at 2022-06-24 02:10:40.285809
# Unit test for function strip_html
def test_strip_html():
    inp = '<a href="foo/bar">click here</a>'
    assert strip_html(inp) == 'click here'
    inp = '<a href="foo/bar">click here</a>'
    assert strip_html(inp, keep_tag_content=True) == '<a href="foo/bar">click here</a>'
    return True



# Generated at 2022-06-24 02:10:41.439908
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') in ['l wodheorll', 'd ohwlleorl', ' leollwodhr']



# Generated at 2022-06-24 02:10:48.680981
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    n = 0 # <- fix for Pycharm
    print(compressed)
    assert original == decompress(compressed)



# Generated at 2022-06-24 02:10:53.703126
# Unit test for function strip_html
def test_strip_html():
    assert strip_html("<somestring>this text should be ignored</somestring>") == 'this text should be ignored'
    assert strip_html("<somestring>this text should be ignored</somestring>", keep_tag_content=True) == 'this text should be ignored'
    assert strip_html("&lt;somestring&gt;this text should be ignored&lt;/somestring&gt;") == 'this text should be ignored'
    assert strip_html("&lt;somestring&gt;this text should be ignored&lt;/somestring&gt;", keep_tag_content=True) == 'this text should be ignored'

# Generated at 2022-06-24 02:10:59.994950
# Unit test for function strip_margin
def test_strip_margin():
    str = '''
            line 1
            line 2
            line 3
        '''
    expected_str = '''
line 1
line 2
line 3
'''
    result_str = strip_margin(str)
    assert(result_str==expected_str)

test_strip_margin()



# Generated at 2022-06-24 02:11:04.763812
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''\
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:11:15.998264
# Unit test for function decompress
def test_decompress():
    def assert_equal(x, y, msg='', skip_if_none=False):
        if skip_if_none and (x is None or y is None):
            return
        assert x == y, msg

    assert_equal(decompress(None), '', skip_if_none=True)
    assert_equal(decompress(''), '')
    assert_equal(decompress('dGVzdA=='), 'test')
    assert_equal(decompress('dGVzdA==', 'ascii'), 'test')
    assert_equal(decompress(compress('test')), 'test')
    assert_equal(decompress(compress('test', compression_level=4)), 'test')
    assert_equal(decompress(compress('test', 'ascii')), 'test')


# Generated at 2022-06-24 02:11:17.835204
# Unit test for function decompress
def test_decompress():
    input_string = "asd"
    assert decapitalize(input_string) == "asd"



# Generated at 2022-06-24 02:11:28.820875
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # test compress
    string_to_compress = 'The quick brown fox jumps over the lazy dog'
    compressed = __StringCompressor.compress(string_to_compress)
    decompressed = __StringCompressor.decompress(compressed)
    assert string_to_compress == decompressed

    # test encoding
    string_to_compress = 'äöüß'
    with pytest.raises(UnicodeDecodeError):
        compressed = __StringCompressor.compress(string_to_compress)
    compressed = __StringCompressor.compress(string_to_compress, 'utf-8')
    decompressed = __StringCompressor.decompress(compressed, 'utf-8')
    assert string_to_compress == decompressed

    # test non-string input

# Generated at 2022-06-24 02:11:34.977403
# Unit test for function strip_margin
def test_strip_margin():
    margin_string = '''
        line 1
        line 2
        line 3
    '''
    expected_string = '''
    line 1
    line 2
    line 3
    '''
    assert(strip_margin(margin_string) == expected_string)


# Generated at 2022-06-24 02:11:35.748799
# Unit test for function roman_encode
def test_roman_encode():
    roman_encode(2)

# Generated at 2022-06-24 02:11:41.515618
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-24 02:11:42.764280
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') is not 'hello world'
test_shuffle()


# Generated at 2022-06-24 02:11:44.575401
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:11:46.351592
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify("ÄË") == "AE"
    return True


# Generated at 2022-06-24 02:11:49.284261
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('VII') != 8
    assert roman_decode('VII') != '7'
    assert roman_decode('VII') != 9
    assert isinstance(roman_decode('VII'), int)
# Test for roman_decode
test_roman_decode()


# Generated at 2022-06-24 02:11:52.974618
# Unit test for function booleanize
def test_booleanize():
    assert not booleanize('false')
    assert booleanize('true')
    assert booleanize('True')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('y')
    assert not booleanize('nope')
    assert not booleanize('')
    assert not booleanize('0')
    assert not booleanize('no')


if __name__ == '__main__':
    import doctest

    print('Running tests...')
    doctest.testmod()

    print('All tests done!')

# Generated at 2022-06-24 02:11:58.886552
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    initial_string = 'my test string'
    encoding = 'utf-8'
    my_compressor = __StringCompressor()
    compressed_string = my_compressor.compress(initial_string, encoding)
    decompressed_string = my_compressor.decompress(compressed_string, encoding)
    assert initial_string == decompressed_string


# Generated at 2022-06-24 02:12:03.943626
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
# coverage testing
#test_camel_case_to_snake()



# Generated at 2022-06-24 02:12:14.455023
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:12:20.182275
# Unit test for function asciify
def test_asciify():
    inp="€èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    outp="eeuuooaaeynAAACIINOE"
    if asciify(inp) != outp:
        return False
    return True



# Generated at 2022-06-24 02:12:21.771873
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    upper_case_first = True
    separator = '_'
    return     snake_case_to_camel(input_string) == 'TheSnakeIsGreen'


# Generated at 2022-06-24 02:12:23.571343
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', True) == 'test: click here'

test_strip_html()



# Generated at 2022-06-24 02:12:28.130424
# Unit test for function strip_margin
def test_strip_margin():
    line1 = '    line 1'
    line2 = '    line 2'
    line3 = '    line 3'
    multiline = line1 + '\n' + line2 + '\n' + line3
    assert strip_margin(multiline) == 'line 1\nline 2\nline 3'

# Generated at 2022-06-24 02:12:32.716656
# Unit test for function slugify
def test_slugify():
    assert slugify('100%') == '100'
    assert slugify('<script>') == 'script'
    assert slugify('Can\'t') == 'cant'
    assert slugify('Betty-Sue') == 'betty-sue'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-24 02:12:41.229927
# Unit test for function prettify

# Generated at 2022-06-24 02:12:50.285291
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('abc  def').format() == 'abc def'
    assert __StringFormatter('abc def').format() == 'abc def'
    assert __StringFormatter('abc  def ghi ').format() == 'abc def ghi'
    assert __StringFormatter(' abc def ').format() == 'abc def'
    assert __StringFormatter('  abc   def   ghi   ').format() == 'abc def ghi'
    assert __StringFormatter('  abc   def  ghi  ').format() == 'abc def ghi'
    assert __StringFormatter('((abc))').format() == '( ( abc ) )'
    assert __StringFormatter('((abc), def)').format() == '( ( abc ), def )'
    assert __StringFormatter('((abc) def)').format()

# Generated at 2022-06-24 02:12:52.627450
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:13:01.550761
# Unit test for function decompress
def test_decompress():
    # test 1
    s = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus velit sit amet tempor pellentesque. ' \
        'Aliquam eget venenatis risus. Donec felis turpis, tincidunt sit amet euismod eu, molestie id nisl. ' \
        'Nulla nec tincidunt lacus, vel dictum libero. Sed ut turpis sodales, consectetur risus ac, interdum dui.'
    compressed = compress(s, 'utf-8', 3)
    assert decompress(compressed, 'utf-8') == s
    # test 2
    s = ''
    compressed = compress(s, 'utf-8', 3)

# Generated at 2022-06-24 02:13:13.022229
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = __StringFormatter('Sássari (Sassari in italiano; Sassari in sassarese e campidanese) è un comune italiano di 67.868 abitanti, capoluogo della provincia omonima in Sardegna. È sede arcivescovile dal 1617, nonché metropoli della Sardegna e sede vescovile dei Vescovi sassaresi dal 1620.')
    out = s.format()

# Generated at 2022-06-24 02:13:14.526505
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:13:22.442600
# Unit test for function roman_encode
def test_roman_encode():
    assert (roman_encode(14) == 'XIV')
    assert (roman_encode(3999) == 'MMMCMXCIX')
    assert (roman_encode(0) == '')
    assert (roman_encode(4000) == '')
    assert (roman_encode('12') == 'XII')
    assert (roman_encode('-1') == '')
    assert (roman_encode('12a') == '')
    assert (roman_encode('') == '')
    assert (roman_encode(None) == '')


# Generated at 2022-06-24 02:13:29.374066
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', '.') == 'this.is.a.camel.case.string.test'



# Generated at 2022-06-24 02:13:30.723500
# Unit test for function compress
def test_compress():
    assert is_equal(compress(''), '')


# Generated at 2022-06-24 02:13:35.017300
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'

test_asciify()


# Generated at 2022-06-24 02:13:46.906426
# Unit test for function roman_encode
def test_roman_encode():
    for input in [0, 4000]:
        try:
            roman_encode(input)
            assert False
        except ValueError:
            pass
    assert roman_encode(-42) == '-XLII'
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'

# Generated at 2022-06-24 02:13:48.870268
# Unit test for function asciify
def test_asciify():
    assert 'eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')

test_asciify()



# Generated at 2022-06-24 02:13:54.317268
# Unit test for function slugify
def test_slugify():
    if slugify("Top 10 Reasons To Love Dogs!!!") != "top-10-reasons-to-love-dogs":
        return False
    if slugify("Mönstér Mägnët") != "monster-magnet":
        return False
    return True
print("test_slugify:", test_slugify())


# Generated at 2022-06-24 02:14:02.767937
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' foo ').format() == 'foo'
    assert __StringFormatter('foo ').format() == 'foo'
    assert __StringFormatter(' foo ').format() == 'foo'
    assert __StringFormatter('foo bar').format() == 'foo bar'
    assert __StringFormatter('foo bar baz').format() == 'foo bar baz'
    assert __StringFormatter('foo bar baz ').format() == 'foo bar baz'
    assert __StringFormatter('foo,   bar, baz').format() == 'foo, bar, baz'
    assert __StringFormatter('foo,  -   bar, baz').format() == 'foo, - bar, baz'
    assert __StringFormatter('foo,   bar -   baz').format() == 'foo, bar - baz'


# Generated at 2022-06-24 02:14:11.778400
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<a></a>') == ''
    assert strip_html('<a href="foo"></a>') == ''
    assert strip_html('<a href="foo">bar</a>') == ''
    assert strip_html('<a href="foo">bar</a>', True) == 'bar'
    assert strip_html('<a href="foo" class="abc">bar</a>', True) == 'bar'



# Generated at 2022-06-24 02:14:18.808977
# Unit test for function slugify
def test_slugify():
    input_output={
        'Top 10 Reasons To Love Dogs!!!': 'top-10-reasons-to-love-dogs',
        'Mönstér Mägnët': 'monster-magnet'
    }
    for inp,output in input_output.items():
        assert slugify(inp)==output, 'incorrect output for input "%s"'%inp
        
test_slugify()


# Generated at 2022-06-24 02:14:30.317782
# Unit test for function shuffle

# Generated at 2022-06-24 02:14:39.554363
# Unit test for function strip_html
def test_strip_html():
    def helper(input_string, expected, keep_tag_content, replace_with):
        out = strip_html(input_string, keep_tag_content=keep_tag_content, replace_with=replace_with)
        assert out == expected
        assert isinstance(out, str)

    helper('', '', False, '')
    helper('a', 'a', False, '')
    helper('a', 'a', True, '')

    helper('a<b>c</b>d', 'ad', False, '')
    helper('a<b>c</b>d', 'acd', True, '')
    helper('a<b>c</b>d', 'aXd', False, 'X')



# Generated at 2022-06-24 02:14:53.116537
# Unit test for function shuffle
def test_shuffle():
    # Test with valid input
    for try_number in range(1, 100):
        in_string = str(random.randint(1, 1000))
        out_string = shuffle(in_string)

        # Check that input and output are not the same
        if in_string == out_string:
            return False

        # Check that input and output have the same length
        if len(in_string) != len(out_string):
            return False

        # Check that in_string and out_string have the same chars
        for char in in_string:
            if not is_full_string(char):
                return False

            if char not in out_string:
                return False

    # Test with invalid input

# Generated at 2022-06-24 02:15:01.903406
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Test encode()
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(400) == 'CD'


# Generated at 2022-06-24 02:15:10.017269
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('test1: <a href="foo/bar">click here</a>') == 'Test1: <a href="foo/bar">click here</a>'
    assert prettify('test2: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'Test2: click here'
    assert prettify('test3: <a href="foo/bar">click here</a>') == 'Test3: <a href="foo/bar">click here</a>'

# Generated at 2022-06-24 02:15:18.067997
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    assert isinstance(compressed, str) # compressed string is a string
    assert len(compressed) < len(original) # compressed string is shorter than original string



# Generated at 2022-06-24 02:15:20.626961
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('VI') == 6
    assert roman_decode('MMXIX') == 2019

test_roman_decode()
print('test_roman_decode() passed')


# Generated at 2022-06-24 02:15:21.925625
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
        line 1
        line 2
        line 3
        '''
    assert(strip_margin(s) == '''
line 1
line 2
line 3
''')



# Generated at 2022-06-24 02:15:30.193332
# Unit test for function prettify
def test_prettify():
    s = ' unprettified string ,, like this one,will be"prettified" .it\\'
    s += s + s
    s += s + s
    s += s + s
    s += s + s
    s += s
    s += 's awesome! '
    f = prettify(s)
    assert isinstance(f, str)



# Generated at 2022-06-24 02:15:35.980954
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    # TODO: write more tests



# Generated at 2022-06-24 02:15:40.099583
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test"



# Generated at 2022-06-24 02:15:44.568176
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != shuffle('hello world')
    assert len(shuffle('hello world')) == len('hello world')
    assert len(shuffle('hello world')) == len(shuffle('hello world'))


# Generated at 2022-06-24 02:15:55.292364
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('my name is...  ').format() == 'My name is...'
    assert __StringFormatter('a wall of..,   text.').format() == 'A wall of..,   text.'
    assert __StringFormatter('  GOOGLE.com').format() == '  GOOGLE.com'
    assert __StringFormatter('  GOOGLE.COM').format() == '  GOOGLE.COM'
    assert __StringFormatter('  GOOGLE.COM ').format() == '  GOOGLE.COM'
    assert __StringFormatter('  GOOGLE.COM').format() == '  GOOGLE.COM'
    assert __StringFormatter('google.com').format() == 'Google.com'

# Generated at 2022-06-24 02:15:59.182982
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELLO') == 'OLLEH'
    assert reverse('hello world') == 'dlrow olleh'
    assert reverse(' hello world ') == ' dlrow olleh '
    assert reverse(' ') == ' '
    assert reverse('') == ''
    assert reverse('HAL 9000') == '000L AH'



# Generated at 2022-06-24 02:16:01.015932
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test"
test_camel_case_to_snake()


# Generated at 2022-06-24 02:16:06.444465
# Unit test for function shuffle
def test_shuffle():
    str_test='test'
    str_test=shuffle(str_test);
    print(str_test)

    str_test1='test1'
    str_test1=shuffle(str_test1);
    print(str_test1)

# test_shuffle()



# Generated at 2022-06-24 02:16:12.546792
# Unit test for function slugify
def test_slugify():
    assert 'top-10-reasons-to-love-dogs' == slugify('Top 10 Reasons To Love Dogs!!!')
    assert 'monster-magnet' == slugify('Mönstér Mägnët')
    assert 'foobar' == slugify('foobar')
    assert 'foo-bar' == slugify('FOO BAR')
    assert 'foo-bar' == slugify('FoO-bAr')
    assert 'foo-bar' == slugify('FOO, BAR')
    assert 'foo-bar' == slugify('Foo - Bar')
    assert 'foo-bar' == slugify('Foo,Bar')
    assert 'foo-bar' == slugify('Foo , Bar')



# Generated at 2022-06-24 02:16:21.811458
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # empty string return empty string
    assert snake_case_to_camel('') == ''

    # returns the same string if is not a valid snake case string
    assert snake_case_to_camel('aValidSnake_CaseString') == 'aValidSnake_CaseString'
    assert snake_case_to_camel('an-invalid-snake-case-string') == 'an-invalid-snake-case-string'
    assert snake_case_to_camel('Another invalid snake case String') == 'Another invalid snake case String'
    assert snake_case_to_camel('_not_valid') == '_not_valid'
    assert snake_case_to_camel('not_valid_') == 'not_valid_'

    # returns a valid string without changing first letter case
    assert snake_case_to_

# Generated at 2022-06-24 02:16:34.451561
# Unit test for function decompress

# Generated at 2022-06-24 02:16:43.804365
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ascii') == 'ascii'

# Generated at 2022-06-24 02:16:55.270803
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        line 1
        line 2
        line 3
        ''') == '''
        line 1
        line 2
        line 3'''

    assert strip_margin('''
        line 1
            line 2
            line 3
        ''') == '''
        line 1
        line 2
        line 3'''

    assert strip_margin('''
        line 1
                line 2
                        line 3
        ''') == '''
        line 1
        line 2
        line 3'''

    assert strip_margin('''
        line 1
    line 2
        line 3
        ''') == '''
        line 1
        line 2
        line 3'''


# Generated at 2022-06-24 02:16:59.436457
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'This is a long string that needs to be compressed and then expanded'
    result = __StringCompressor.compress(input_string)
    assert __StringCompressor.decompress(result) == input_string
    print('__StringCompressor tests passed!')



# Generated at 2022-06-24 02:17:10.279576
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("a") == "a"
    assert shuffle("") == ""
    assert shuffle("abc") in ("abc", "acb", "bac", "bca", "cab", "cba")
    assert shuffle("ABC") in ("ABC", "ACB", "BAC", "BCA", "CAB", "CBA")
    assert shuffle("ABc") in ("ABc", "AcB", "BAc", "BCa", "CAc", "cAB")
    assert shuffle("1ABc") in ("1ABc", "1AcB", "B1Ac", "Bc1A", "CB1a", "cB1A")

# Generated at 2022-06-24 02:17:15.130171
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', False) == 'helloWorld'



# Generated at 2022-06-24 02:17:24.191160
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello world'
    assert __StringFormatter('Hello world').format() == 'Hello world'

    assert __StringFormatter('hello world!!!').format() == 'Hello world!'
    assert __StringFormatter('Hello world!!!').format() == 'Hello world!'

    assert __StringFormatter('hello     world').format() == 'Hello world'
    assert __StringFormatter('     Hello     world     ').format() == 'Hello world'

    assert __StringFormatter('hello-world').format() == 'Hello-world'
    assert __StringFormatter('hello - world').format() == 'Hello-world'
    assert __StringFormatter('hello    -    world').format() == 'Hello-world'
    assert __StringFormatter('hello:world').format() == 'Hello:world'

# Generated at 2022-06-24 02:17:31.456085
# Unit test for function strip_html
def test_strip_html():
    test_string = '<html> test: <a href="foo/bar">click here</a> </html>'
    test_string_tag_content = '<html> test: click here </html>'
    assert strip_html(test_string) == ' test: '
    assert strip_html(test_string, keep_tag_content=True) == ' test: click here '
    assert strip_html(test_string_tag_content, keep_tag_content=True) == ' test: click here '
test_strip_html()



# Generated at 2022-06-24 02:17:41.544770
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # normal test
    assert snake_case_to_camel("the_snake_is_green", True, '_') == "TheSnakeIsGreen"

    # test with all parameters
    assert snake_case_to_camel("the_snake_is_green", False, '_') == "theSnakeIsGreen"

    # test with just the string
    assert snake_case_to_camel("the_snake_is_green") == "TheSnakeIsGreen"

    # test with not snake case string
    assert snake_case_to_camel("ThisIsACamelStringTest") == "ThisIsACamelStringTest"

test_snake_case_to_camel()


# Generated at 2022-06-24 02:17:52.270133
# Unit test for function prettify
def test_prettify():
    """
    Test prettify function
    """
    from src.com.jalasoft.search.utils.constants import prettify_test_file_path
    with open(prettify_test_file_path, 'r', encoding='utf-8') as file:
        lines = file.read().splitlines()
        for line in lines:
            no_blank_line = len(line) != 0
            if no_blank_line:
                if '->' in line:
                    result = line.split("->")
                    input = result[0].strip()
                    expect = result[1].strip()
                    assert prettify(input) == expect, 'prettify({}) returned "{}" instead of "{}"'.format(input, prettify(input), expect)

test_prettify()



# Generated at 2022-06-24 02:18:00.683912
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string') == 'Unprettified string'
    assert prettify(' ,, like this one,will be"prettified" .it\\' "s awesome! ") == "Like this one, will be \"prettified\". It's awesome!"
    assert prettify('') == ''
    assert prettify('#') == '#'
    assert prettify('# ') == '#'
    assert prettify('@') == '@'
    assert prettify(' @') == '@'
    assert prettify(' !') == '!'
    assert prettify('! ') == '!'
    assert prettify(' ?') == '?'
    assert prettify('? ') == '?'
    assert prettify('   ') == ''
    assert prettify('  # ') == '#'
    assert prett

# Generated at 2022-06-24 02:18:10.030199
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    """
    Test function camel_case_to_snake
    """
    # Assertions
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('a') == 'a'
    assert camel_case_to_snake('aB') == 'a_b'
    assert camel_case_to_snake('helloWorLd') == 'hello_wor_ld'
    assert camel_case_to_snake('OneTwo3Four5') == 'one_two3_four5'
    assert camel_case_to_snake('iLoveCamelCase') == 'i_love_camel_case'
    assert camel_case_to_snake('ILoveCamelCase') == 'i_love_camel_case'
    assert camel_case_to

# Generated at 2022-06-24 02:18:14.517368
# Unit test for function reverse
def test_reverse():
    assert reverse('123') == '321'
    assert reverse('') == ''


# Generated at 2022-06-24 02:18:16.700236
# Unit test for function decompress
def test_decompress():
    input_string = "hello"
    encoding = "utf-8"
    output_string = __StringCompressor.decompress(input_string, encoding)
    print(output_string)



# Generated at 2022-06-24 02:18:19.730693
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    print('Testing __StringFormatter class constructor')
    try:
        __StringFormatter(None)
    except InvalidInputError as e:
        assert str(e) == 'Parameter <input_string> is not of type <str>'



# Generated at 2022-06-24 02:18:26.570243
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter(' a    b    c ').format() == 'A B C'
    assert __StringFormatter('a  b c').format() == 'A B C'
    assert __StringFormatter('  a  b c  ').format() == 'A B C'
    assert __StringFormatter('  a  BC c  ').format() == 'A BC C'
    assert __StringFormatter('  a  b c  C  ').format() == 'A B C C'
    assert __StringFormatter('  a  b c  C  ').format() == 'A B C C'
    assert __StringFormatter('  a  b c  C  ').format() == 'A B C C'
    assert __StringFormatter('  a  b c  C  ').format() == 'A B C C'

# Generated at 2022-06-24 02:18:28.238458
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.__init__ is not None
    __StringCompressor.__init__()


# Generated at 2022-06-24 02:18:29.831404
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
                    line 1
                    line 2
                    line 3
                   '''
    expected_string = '''line 1
                    line 2
                    line 3'''
    assert (strip_margin(input_string) == expected_string)



# Generated at 2022-06-24 02:18:34.624842
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('AnInvalidString') == 'anInvalidString'
    assert camel_case_to_snake(None) == None



# Generated at 2022-06-24 02:18:41.726058
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print("original length: {}, compressed length: {}".format(len(original), len(compressed)))
    # Test case
    if compressed is None: print("Test failed")



# Generated at 2022-06-24 02:18:47.990137
# Unit test for function prettify
def test_prettify():
    assert prettify('the dog is brown') == 'The dog is brown'
    assert prettify('the camelCase is crazy!') == 'The camelCase is crazy!'

# Generated at 2022-06-24 02:18:57.281518
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:19:06.450757
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # Given
    str1 = 'my string   to be     prettified !'
    str2 = 'How are you?'
    str3 = 'I\'m good, And you?'

# Generated at 2022-06-24 02:19:16.519403
# Unit test for function decompress
def test_decompress():
    assert decompress('eJx9kN0KgDAMBdAjO8wV-0ZRJEg7QOfFbKj-7HgfJajrWH7_qjK8lVyiGn5Zmof5m5xHp-XKj5cJRg') == 'Testo da comprimere'
    assert decompress("The object should not be empty or None") == "The object should not be empty or None"
    assert not decompress("The object should not be empty or None") == "The object is empty or None"
