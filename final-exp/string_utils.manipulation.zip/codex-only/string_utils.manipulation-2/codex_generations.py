

# Generated at 2022-06-24 02:09:24.061872
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('"hello".! "world"    http://www.facebook.com  a.b@c.it   fred - jane    H. P. Lovecraft')
    assert sf.format() == '"Hello".! "World" http://www.facebook.com a.b@c.it Fred - Jane H. P. Lovecraft'


# PUBLIC API



# Generated at 2022-06-24 02:09:34.198222
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('th1s1sACamelStr1ngTest') == 'th1s1s_a_camel_str1ng_test'
    assert camel_case_to_snake('th1s1sA_CamelStr1ngTest') == 'th1s1s_a_camel_str1ng_test'

# Generated at 2022-06-24 02:09:38.459478
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'
# /Unit test for function reverse



# Generated at 2022-06-24 02:09:42.675349
# Unit test for function compress
def test_compress():

    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    uncompressed = decompress(compressed)

    assert isinstance(compressed, str)
    assert len(compressed) < len(original)
    assert original == uncompressed



# Generated at 2022-06-24 02:09:45.683278
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('foo bar').input_string == 'foo bar'
    assert __StringFormatter('foo-bar').input_string == 'foo-bar'


# PUBLIC API



# Generated at 2022-06-24 02:09:51.619672
# Unit test for function strip_margin
def test_strip_margin():
    str1 = '''
                line 1
                line 2
                line 3
                '''

    str2 = '''
            line 1
            line 2
            line 3
            '''
    assert strip_margin(str1) == str2




# Generated at 2022-06-24 02:09:54.938665
# Unit test for function shuffle
def test_shuffle():
    s = 'hello world'

    output = shuffle(s)

    assert output != s

    chars = list(s)
    assert sorted(output) == sorted(chars)



# Generated at 2022-06-24 02:09:57.362698
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('test') != 'test'
    assert shuffle('test') in ['estt', 'etts', 'tets', 'tste', 'tets', 'tets']



# Generated at 2022-06-24 02:10:06.268510
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # test wrong input
    if __RomanNumbers.encode(0) is not None:
        raise Exception('Expected exception to be thrown')

    if __RomanNumbers.encode(4000) is not None:
        raise Exception('Expected exception to be thrown')

    if __RomanNumbers.encode(-10) is not None:
        raise Exception('Expected exception to be thrown')

    if __RomanNumbers.encode('test') is not None:
        raise Exception('Expected exception to be thrown')

    if __RomanNumbers.decode('') is not None:
        raise Exception('Expected exception to be thrown')

    if __RomanNumbers.decode('test') is not None:
        raise Exception('Expected exception to be thrown')


# Generated at 2022-06-24 02:10:12.362829
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse('!') == '!'
    assert reverse(' ') == ' '



# Generated at 2022-06-24 02:10:15.451167
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('hello world')) == 'hello world'
    assert decompress(compress('simple test')) == 'simple test'
    assert decompress(compress('random text with spaces')) == 'random text with spaces'
    assert decompress(compress('this is a test')) == 'this is a test'
    assert decompress(compress('simple')) == 'simple'
    assert decompress(compress('another one')) == 'another one'
    assert decompress(compress('another')) == 'another'



# Generated at 2022-06-24 02:10:20.598597
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('  \t hello ') == ' olleh\t  '
    assert reverse(' ') == ' '
    assert reverse('Hello, world!') == '!dlrow ,olleH'
    assert reverse('') == ''
    assert reverse(123) == ''
    assert reverse(None) == ''
    assert reverse([1, 2, 3]) == ''



# Generated at 2022-06-24 02:10:21.683741
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == shuffle('hello world')



# Generated at 2022-06-24 02:10:31.672226
# Unit test for function strip_html
def test_strip_html():
    assert 'test: ' == strip_html('test: <a href="foo/bar">click here</a>')
    assert 'test: click here' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)
    assert '<a href="foo/bar">click here</a>' == strip_html('<a href="foo/bar">click here</a>')
    assert 'test: ' == strip_html('test: <a>click here</a>')
    assert 'hello <strong>world</strong>' == strip_html('hello <strong>world</strong>')
    assert '' == strip_html('<strong></strong>')
    assert '' == strip_html('')
# Test ends

test_strip_html()



# Generated at 2022-06-24 02:10:43.171053
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:10:47.032715
# Unit test for function slugify
def test_slugify():
    print(slugify('Top 10 Reasons To Love Dogs!!!')) # returns: 'top-10-reasons-to-love-dogs'
    print(slugify('Mönstér Mägnët')) # returns 'monster-magnet'
    return
#test_slugify()
# Example of input string that is not a valid URL
#example_string_invalid_url = 'nota url'

# Example of input string that is  a valid URL
example_string_valid_url = 'https://www.example.org'


# Function is_url

# Generated at 2022-06-24 02:10:50.137759
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    print('Testing __StringFormatter class...', end=" ")
    assert __StringFormatter('Test phrase') is not None
    assert __StringFormatter('Test phrase') is not None
    assert __StringFormatter('Test phrase').format() == 'Test phrase'
    print('PASSED!')


# PUBLIC FUNCTIONS



# Generated at 2022-06-24 02:10:53.574381
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1000) == 'M'
    assert roman_encode(10) == 'X'
    assert roman_encode(1) == 'I'
    assert roman_encode(2009) == 'MMIX'



# Generated at 2022-06-24 02:11:01.496473
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:11:04.924750
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)


# Generated at 2022-06-24 02:11:07.868859
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_camel_case_string_test' == \
    camel_case_to_snake('ThisIsACamelStringTest')


# Generated at 2022-06-24 02:11:17.150513
# Unit test for function strip_html
def test_strip_html():
    assert strip_html(None) == ''
    assert strip_html('') == ''

    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', True) == 'click here'

    assert strip_html('<a href="foo/bar">click here</a> lorem ipsum') == ' lorem ipsum'
    assert strip_html('<a href="foo/bar">click here</a> lorem ipsum', True) == 'click here lorem ipsum'

    assert strip_html('something else') == 'something else'



# Generated at 2022-06-24 02:11:28.525593
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('идти удалить город') == 'идтиудалитьгород'
    assert asciify('상세하게 계획하는 것이 중요합니다') == '상세하게계획하는것이중요합니다'

# Generated at 2022-06-24 02:11:38.897683
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  aBc  ').format() == 'Abc'
    assert __StringFormatter('a b c').format() == 'a b c'
    assert __StringFormatter('a.b.c').format() == 'a. b. c'
    assert __StringFormatter('aB-c').format() == 'a B-c'
    assert __StringFormatter('aB-c.').format() == 'a B-c.'
    assert __StringFormatter('a B-c.').format() == 'a B-c.'
    assert __StringFormatter('  a B-c. ').format() == 'a B-c.'
    assert __StringFormatter('  a  B-c  . ').format() == 'a B-c.'

# Generated at 2022-06-24 02:11:46.623610
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert original == decompress(compressed), 'compressed and decompressed strings must be equals'



# Generated at 2022-06-24 02:11:49.148448
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:11:51.336163
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello') is not None



# Generated at 2022-06-24 02:11:58.421699
# Unit test for function strip_margin
def test_strip_margin():
    s = strip_margin('''
                    line 1
                    line 2
                    line 3
                    ''')
    assert s == '''
line 1
line 2
line 3
'''
    print('strip_margin test passed')
# Call unit tests for this file
test_strip_margin()


# Generated at 2022-06-24 02:12:09.187472
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Generated at 2022-06-24 02:12:12.824665
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test') == 'test'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:12:24.506615
# Unit test for function asciify
def test_asciify():
    import unittest

    class TestAsciify(unittest.TestCase):
        def test_basic(self):
            self.assertEqual(asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË'), 'EEUUOOAAEYNAAACIINOE')

        def test_string(self):
            self.assertEqual(asciify('èéùúòóäåëýñåàáçìíñóë'), 'eeuuooaaeynaaaciinoe')

        def test_return_type(self):
            self.assertIsInstance(asciify('str'), str)
            self.assertIsInstance(asciify(123), str)


# Generated at 2022-06-24 02:12:26.190685
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    roman_number = __RomanNumbers()
    assert roman_number is not None


# Generated at 2022-06-24 02:12:29.871618
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify(' !!!èéùúòóäåëýñÅÀÁÇÌÍÑÓË !!! ') == ' !!!eeuuooaaeynAAACIINOE !!! '
    assert asciify('€') == ''


# Generated at 2022-06-24 02:12:31.985967
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'



# Generated at 2022-06-24 02:12:33.338749
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(0) == 'N/A'


# Generated at 2022-06-24 02:12:42.695411
# Unit test for function prettify

# Generated at 2022-06-24 02:12:53.939432
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAAACIINOE'
    assert asciify('EÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓËe') == 'EeeuuooaaeeynaaaciinoeE'

# Generated at 2022-06-24 02:13:04.525781
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('True')
    assert booleanize('TRUE')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('YES')
    assert booleanize('Yes')
    assert booleanize('y')
    assert booleanize('Y')
    assert booleanize('YES')
    assert booleanize(' yes')
    assert booleanize('yes ')
    assert booleanize(' yes ')
    assert not booleanize('false')
    assert not booleanize('False')
    assert not booleanize('FALSE')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('No')
    assert not booleanize('NO')
    assert not booleanize('n')
    assert not booleanize('N')
    assert not booleanize('no ')


# Generated at 2022-06-24 02:13:08.649653
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter(input_string=" ")
    assert formatter
    formatter = __StringFormatter(input_string="")
    assert formatter
    formatter = __StringFormatter(input_string=" hello  ")
    assert formatter


# Generated at 2022-06-24 02:13:18.160633
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # testing encode()
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(13) == 'XIII'

# Generated at 2022-06-24 02:13:22.802635
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") == "dhlrowolle"
    assert shuffle("hello world") == "lwol dhrolee"
    assert shuffle("hello world") == "l hodolrewl"

test_shuffle()



# Generated at 2022-06-24 02:13:34.050774
# Unit test for function slugify
def test_slugify():

    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'

    assert slugify('Mönstér Mägnët') == 'monster-magnet'

    assert slugify('Top 10 Reasons To Love Dogs', '+') == 'top+10+reasons+to+love+dogs'

    assert slugify('') == ''

    assert slugify('    ') == ''

    assert slugify(None) == ''

    assert slugify(123) == ''

    assert slugify(12.34) == ''

    assert slugify(True) == ''

# Test the behavior of the function
test_slugify()



# Generated at 2022-06-24 02:13:34.907047
# Unit test for function compress
def test_compress():
    assert compress('') == ''



# Generated at 2022-06-24 02:13:37.899038
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('VII') != 8
    assert roman_decode('VII') != 6
    assert roman_decode('VII') != 0
    raise Exception('Test fails')

# Generated at 2022-06-24 02:13:41.989067
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('false') == False
    assert booleanize('True') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('nope') == False



# Generated at 2022-06-24 02:13:44.273936
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'

# Generated at 2022-06-24 02:13:47.481977
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
                line 1
                line 2
                line 3
                '''



# Generated at 2022-06-24 02:13:54.131331
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    f = __StringFormatter('john doe')
    assert f.input_string == 'john doe'

    f = __StringFormatter('')
    assert f.input_string == ''

    from lotus_validations.validation import is_int
    assert is_int(__StringFormatter('123')) is False



# Generated at 2022-06-24 02:13:56.601838
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'hello'
    assert ''.join(sorted(shuffle('hello world'))) == ' ' + ''.join(sorted('hello world'))



# Generated at 2022-06-24 02:14:01.574140
# Unit test for function decompress
def test_decompress():
    pass
    # print(st_utils.decompress("wAAAZA8ABgAAoAQQo0AAA=="))



# Generated at 2022-06-24 02:14:09.319211
# Unit test for function compress
def test_compress():
    n = 0 # <- fix for PyCharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    # noinspection SpellCheckingInspection
    assert compressed == 'eJxLTEsNzs0T1M9XTMwv0gsKlpWwQQQ'



# Generated at 2022-06-24 02:14:12.814354
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    's awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

test_prettify()


# Generated at 2022-06-24 02:14:15.048405
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:14:21.565345
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter("this is a test").input_string == "this is a test"
    try:
        __StringFormatter(69)
        assert False
    except InvalidInputError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 02:14:22.435476
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:14:25.506408
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode('1990') == 'MCMXC'
    assert roman_encode(1999) == 'MCMXCIX'

test_roman_encode()



# Generated at 2022-06-24 02:14:39.628880
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-24 02:14:51.956500
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:15:00.420542
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    if __RomanNumbers.__encode_digit(0, 5) != 'V' or \
            __RomanNumbers.__encode_digit(0, 10) != 'X' or \
            __RomanNumbers.__encode_digit(0, 15) != 'XV':
        raise ValueError('Invalid enumeration')

    if __RomanNumbers.__index_for_sign('V') != 0 or \
            __RomanNumbers.__index_for_sign('X') != 1 or \
            __RomanNumbers.__index_for_sign('D') != 2:
        raise ValueError('Invalid index')

# PUBLIC API


# TODO: add further tests

# Generated at 2022-06-24 02:15:04.654593
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:15:06.703299
# Unit test for function shuffle
def test_shuffle():
    in_str = 'hello world'
    out_str = shuffle(in_str)
    assert out_str != in_str



# Generated at 2022-06-24 02:15:09.197171
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:15:19.509453
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify('   ') == ''
    assert slugify('  test  ') == 'test'
    assert slugify('  test  ', separator=' ') == 'test'
    assert slugify('  test  ', separator='.') == 'test'
    assert slugify('double  spaces') == 'double-spaces'
    assert slugify('0numbers') == '0numbers'
    assert slugify('0numbers and spaces') == '0numbers-and-spaces'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Generated at 2022-06-24 02:15:23.704264
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ℝ⟮⟯') == ''
    assert asciify('föò®†ÑÐê') == 'fooRNDe'



# Generated at 2022-06-24 02:15:28.385675
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_string = 'one tWo   three'
    out = __StringFormatter(input_string).format()
    if out != 'One two three':
        print('FAILED TEST one tWo   three: ' + out)
    input_string = 'one (1) tWo (2)   three (3)'
    out = __StringFormatter(input_string).format()
    if out != 'One (1) two (2) three (3)':
        print('FAILED TEST one (1) tWo (2)   three (3): ' + out)
    input_string = 'one (1)  (2) two (2)   three (3)'
    out = __StringFormatter(input_string).format()

# Generated at 2022-06-24 02:15:35.631406
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<p>This is a test</p>') == ''
    assert strip_html('<p>This is a test</p>', True) == 'This is a test'
    assert strip_html('<p class="test">This is a test</p>') == ''
    assert strip_html('<p class="test">This is a test</p>', True) == 'This is a test'
    assert strip_html('<p>This is a test<br/>And this is another one<br/></p>') == ''
    assert strip_html('<p>This is a test<br/>And this is another one<br/></p>', True) == 'This is a testAnd this is another one'



# Generated at 2022-06-24 02:15:36.797040
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('abc') == 'cba'



# Generated at 2022-06-24 02:15:45.218536
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    expected = 'TheSnakeIsGreen'
    # Test with default value
    actual = snake_case_to_camel('the_snake_is_green')
    assert actual == expected, 'Expected {}, but got {}'.format(expected, actual)

    # Test with first letter lowercase
    actual = snake_case_to_camel('the_snake_is_green', upper_case_first=False)
    assert actual == 'theSnakeIsGreen', 'Expected {}, but got {}'.format('theSnakeIsGreen', actual)

    # Test with custom separator
    actual = snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-')

# Generated at 2022-06-24 02:15:48.463836
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
        line 1
        line 2
        line 3
    '''
    assert strip_margin(input_string) == '''
line 1
line 2
line 3
'''

    # invalid input
    with pytest.raises(InvalidInputError):
        strip_margin('')



# Generated at 2022-06-24 02:15:49.284511
# Unit test for function compress
def test_compress():
    assert is_string(compress('test'))



# Generated at 2022-06-24 02:15:50.513632
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    print(__StringFormatter('abc'))



# Generated at 2022-06-24 02:15:54.285883
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed == original

# Generated at 2022-06-24 02:16:00.017864
# Unit test for function prettify
def test_prettify():
    assert prettify('Unprettified string, like this one, will be "prettified". It\'s awesome!') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-24 02:16:05.617061
# Unit test for function compress
def test_compress():
    # content of a 160 characters string
    s = ' '.join(['word n{}'.format(n) for n in range(20)])

    # compress string and see how many chars are left
    compressed = compress(s)

    # should be less than 160
    return len(compressed) < 160



# Generated at 2022-06-24 02:16:09.695511
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert compressed == 'eJxLyc3Pz8svycw0TUoKScytTUvNTi1Rc1JzUsoz1SvLABAB'

test_compress()



# Generated at 2022-06-24 02:16:13.002255
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'


# Generated at 2022-06-24 02:16:18.941872
# Unit test for function shuffle
def test_shuffle():
    string_to_shuffle = 'hello world'
    result = shuffle(string_to_shuffle)
    assert(len(result) == len(string_to_shuffle))
    assert(result != string_to_shuffle)
    assert(not result.islower())
# test_shuffle()



# Generated at 2022-06-24 02:16:31.735858
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print(snake_case_to_camel('s'))
    print(snake_case_to_camel('s_'))
    print(snake_case_to_camel('_s_'))
    print(snake_case_to_camel('s_s'))
    print(snake_case_to_camel('_'))
    print(snake_case_to_camel('_s'))
    print(snake_case_to_camel('the_snake_is_green'))
    print(snake_case_to_camel('the_snake_is_green', upper_case_first=True))
    print(snake_case_to_camel('the_snake_is_green', upper_case_first=False))



# Generated at 2022-06-24 02:16:35.542814
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert is_string(__StringFormatter('toto').input_string)

    try:
        __StringFormatter()
    except Exception as e:
        assert str(e) == 'Invalid input, it must be a string'


# appends new chunk at the end of list

# Generated at 2022-06-24 02:16:44.956116
# Unit test for function strip_html
def test_strip_html():
    print('Testing function strip_html()')
    print('Testing 1/5')
    input_string = '<b>Bold</b> <span class="italic">Italic</span> <p>No attributes</p>'
    expected_output_first = ' Bold   Italic   No attributes '
    expected_output_second = 'BoldItalicNo attributes'
    output_first = strip_html(input_string)
    output_second = strip_html(input_string, keep_tag_content=True)
    if output_first != expected_output_first:
        print('Error in function strip_html(): expected "{0}", got "{1}"'.format(expected_output_first, output_first))

# Generated at 2022-06-24 02:16:52.552321
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'

test_snake_case_to_camel()



# Generated at 2022-06-24 02:17:00.912683
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('test') == 'tset'
    assert reverse('test1') == '1tset'
    assert reverse('test12') == '21tset'
    assert reverse('test123') == '321tset'
    assert reverse('test1234') == '4321tset'
    assert reverse('test12345') == '54321tset'
    assert reverse('test123456') == '654321tset'
    assert reverse('test1234567') == '7654321tset'
    assert reverse('test12345678') == '87654321tset'
    assert reverse('test123456789') == '987654321tset'

# Generated at 2022-06-24 02:17:08.369725
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert compressed == 'eJwLiooOvyElf0tKycnMkFQtAupBRUhJT1tJIUi1FA=='
    assert original == decompress(compressed)



# Generated at 2022-06-24 02:17:16.970610
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be' \
                                        ' "prettified". It\'s awesome!'

    assert prettify('hello') == 'Hello'
    assert prettify('hello     world') == 'Hello world'
    assert prettify('hello world, how are you?') == 'Hello world, how are you?'
    assert prettify('hello world , how are you?') == 'Hello world, how are you?'
    assert prettify('hello world, how are you?     ') == 'Hello world, how are you?'
    assert prettify('  hello world, how are you? ') == 'Hello world, how are you?'

# Generated at 2022-06-24 02:17:28.222209
# Unit test for function roman_decode

# Generated at 2022-06-24 02:17:35.947636
# Unit test for function prettify

# Generated at 2022-06-24 02:17:40.185538
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'

# Generated at 2022-06-24 02:17:46.220894
# Unit test for function decompress
def test_decompress():
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(input_string)
    decompressed = decompress(compressed)

    if input_string == decompressed:
        print('SUCCESS')
    else:
        print('FAIL')

if __name__ == '__main__':
    test_decompress()


# Generated at 2022-06-24 02:17:52.748087
# Unit test for function slugify
def test_slugify():
    """
    Test to verify if the function slugify returns the same result for each output
    :return: True if all results are the same
    """
    i = 0
    while i < 5:
        assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
        assert slugify('Mönstér Mägnët') == 'monster-magnet'
        i += 1



# Generated at 2022-06-24 02:17:58.652627
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('')) == ''
    assert decompress(compress('hello')) == 'hello'
    assert decompress(compress('hello my friend')) == 'hello my friend'
    assert decompress(compress('The quick brown fox jumps over the lazy dog')) == 'The quick brown fox jumps over the lazy dog'

# Generated at 2022-06-24 02:18:02.202063
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:18:05.747692
# Unit test for function strip_margin
def test_strip_margin():
    
    assert strip_margin('''
    | line 1
    | line 2
    | line 3
    ''') == '''
    line 1
    line 2
    line 3
    '''



# Generated at 2022-06-24 02:18:16.619920
# Unit test for function prettify
def test_prettify():
    assert prettify(' there are   tabs and spaces ') == 'There are tabs and spaces'
    assert prettify('there are   tabs and spaces') == 'There are tabs and spaces'
    assert prettify(' yet another  string.') == 'Yet another string.'
    assert prettify('yet another  string.') == 'Yet another string.'
    assert prettify(' yet another  string. ') == 'Yet another string.'
    assert prettify('yet another  string. ') == 'Yet another string.'
    assert prettify(' yet another  string.  ') == 'Yet another string.'
    assert prettify('yet another  string.  ') == 'Yet another string.'

# Generated at 2022-06-24 02:18:19.935885
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true") == True
    assert booleanize("false") == False
    assert booleanize("1") == True
    assert booleanize("0") == False
    assert booleanize("yes") == True
    assert booleanize("no") == False
    assert booleanize("y") == True
    assert booleanize("n") == False
    assert booleanize("on") == True
    assert booleanize("off") == False


# Generated at 2022-06-24 02:18:22.131134
# Unit test for function strip_margin
def test_strip_margin():
    """
    Simple unit test for function strip_margin
    """
    input_string = '''\
      line 1
      line 2
      line 3
      '''
    expected_string = '''\
line 1
line 2
line 3
'''
    assert strip_margin(input_string) == expected_string



# Generated at 2022-06-24 02:18:25.389963
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # arrange
    input_string = 'test   .'
    expected_output = 'Test .'

    # act
    output = __StringFormatter(input_string).format()

    # assert
    assert output == expected_output, 'Expected {}, got {}'.format(expected_output, output)
# end unit test for __StringFormatter.format()


# PUBLIC API



# Generated at 2022-06-24 02:18:29.173651
# Unit test for function slugify
def test_slugify():
    # given string 'Top 10 Reasons To Love Dogs!!!' should return: 'top-10-reasons-to-love-dogs'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    # given string 'Mönstér Mägnët' should return: 'monster-magnet'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-24 02:18:40.437884
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-24 02:18:45.403765
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                          line 1
                          line 2
                          line 3
                       ''') == '''
    line 1
    line 2
    line 3
    '''



# Generated at 2022-06-24 02:18:49.164135
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-24 02:18:51.939900
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'


# Generated at 2022-06-24 02:18:54.270419
# Unit test for function slugify
def test_slugify():
    s = slugify('Top 10 Reasons To Love Dogs!!!')
    assert s == "top-10-reasons-to-love-dogs"
    s = slugify('Mönstér Mägnët')
    assert s == 'monster-magnet'

test_slugify()

import re


# Generated at 2022-06-24 02:19:05.922000
# Unit test for function strip_margin
def test_strip_margin():
    print('test strip_margin()')
    assert strip_margin('''
line 1
line 2
line 3
''') == 'line 1\nline 2\nline 3\n'
    assert strip_margin('''
    line 1
    line 2
    line 3
    ''') == 'line 1\nline 2\nline 3\n'
    assert strip_margin('''
        line 1
        line 2
        line 3
        ''') == 'line 1\nline 2\nline 3\n'
    assert strip_margin('''
line 1
            line 2
line 3''') == 'line 1\n            line 2\nline 3'
    assert strip_margin('''
line 1
    line 2
line 3''') == 'line 1\n    line 2\nline 3'
   

# Generated at 2022-06-24 02:19:07.684831
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-24 02:19:18.078317
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<h2>title</h2>', True) == 'title'
    assert strip_html('<h2>title</h2>') == ''
    assert strip_html('<h2 class="test" id="test">title</h2>', True) == 'title'
    assert strip_html('<h2 class="test" id="test">title</h2>') == ''
    assert strip_html('<h2 class="test" id="test">title<b>bold</b></h2>', True) == 'titlebold'
    assert strip_html('<h2 class="test" id="test">title<b>bold</b></h2>') == ''
