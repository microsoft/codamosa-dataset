

# Generated at 2022-06-24 02:09:25.888193
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    org_str = 'hello world'
    compress_str = __StringCompressor.compress(org_str)
    decompress_str = __StringCompressor.decompress(compress_str)
    assert org_str == decompress_str


# PUBLIC API


# PUBLIC API --------------------------------------------------------------------


# Generated at 2022-06-24 02:09:28.629529
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-24 02:09:33.634896
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print(compressed)

    assert compressed is not None

test_compress()


# Generated at 2022-06-24 02:09:38.579738
# Unit test for function prettify
def test_prettify():
    test_string = []
    expected_string = []

    test_string.append(' unprettified string ,, like this one,will be"prettified" .it\\\' s awesome! ')
    expected_string.append('Unprettified string, like this one, will be "prettified". It\'s awesome!')

    test_string.append('''
    "Line 1"

     "Line 2"

    "Line 3"
    ''')
    expected_string.append('"Line 1"\n\n"Line 2"\n\n"Line 3"')

    test_string.append('"num ( % )" .% .foo.bar .baz.  foo\\\' s bar.com.foo,bar')

# Generated at 2022-06-24 02:09:43.906246
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test_string_1 = 'hello this is a test string full of words!.'
    test_string_2 = 'J. R. R. Tolkien (1892 - 1973)'

    sf_1 = __StringFormatter(test_string_1)
    sf_2 = __StringFormatter(test_string_2)

    assert sf_1.input_string == test_string_1
    assert sf_2.input_string == test_string_2


# Generated at 2022-06-24 02:09:47.268295
# Unit test for function prettify

# Generated at 2022-06-24 02:09:51.799762
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
# End of Unit test for function camel_case_to_snake



# Generated at 2022-06-24 02:09:53.636903
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
test_reverse()



# Generated at 2022-06-24 02:09:57.053336
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

# Generated at 2022-06-24 02:10:01.363221
# Unit test for function strip_margin
def test_strip_margin():
    multiline_str = '''
        line 1
        line 2
        line 3
        '''

    expected = '''
line 1
line 2
line 3
'''
    assert(strip_margin(multiline_str) == expected)



# Generated at 2022-06-24 02:10:11.678226
# Unit test for function decompress
def test_decompress():
    import pytest

    # "original" will be a string with 169 chars
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    # assert that the compressed string is actually shorter than the original one
    assert len(compressed) < len(original)

    # assert that the restored string is equal to the original one
    assert decompress(compressed) == original

    # assert that an exception is raised if trying to restore a string that is not compressed
    with pytest.raises(ValueError):
        decompress(original)



# Generated at 2022-06-24 02:10:17.066739
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    return

test_slugify()


# Generated at 2022-06-24 02:10:26.959913
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter(u'  the  quick brown fox jumps over the lazy dog  ').format()
    assert f == 'The quick brown fox jumps over the lazy dog'

    f = __StringFormatter(u'  the  quick brown fox jumps over the lazy dog  http://www.google.com  ').format()
    assert f == 'The quick brown fox jumps over the lazy dog http://www.google.com'

    f = __StringFormatter(u'  the  quick brown fox jumps over the lazy dog  http://www.google.com  ciao@example.com  ').format()
    assert f == 'The quick brown fox jumps over the lazy dog http://www.google.com ciao@example.com'


# Generated at 2022-06-24 02:10:33.474296
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('a', True) == 'A'
    assert snake_case_to_camel('  a  ', True) == 'A'
    assert snake_case_to_camel('a', False) == 'a'

# Generated at 2022-06-24 02:10:40.318957
# Unit test for function asciify
def test_asciify():
    s ='èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    s_a = asciify(s)
    assert(s_a == 'eeuuooaaeynAAACIINOE')



# Generated at 2022-06-24 02:10:41.407165
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    line1
    line2
    line3
    ''') == '''
line1
line2
line3
'''



# Generated at 2022-06-24 02:10:50.576053
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    f = __StringFormatter('a    b    .c .d!   (e)  ')
    assert f.format() == 'A b. C. D! (E)'

    f = __StringFormatter('  hello  ')
    assert f.format() == 'Hello'

    f = __StringFormatter('  hello:  ')
    assert f.format() == 'Hello:'

    f = __StringFormatter('  hello!  ')
    assert f.format() == 'Hello!'

    f = __StringFormatter('  hello (world)  ')
    assert f.format() == 'Hello (World)'

    f = __StringFormatter('  hello (world)  ')
    assert f.format() == 'Hello (World)'


# Generated at 2022-06-24 02:11:01.730570
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('A b c').format() == 'A b c'
    assert __StringFormatter('a b c').format() == 'A b c'
    assert __StringFormatter('a-b-c').format() == 'A-b-c'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a b c d').format() == 'A b c d'
    assert __StringFormatter('a   b  c  d').format() == 'A b c d'
    assert __StringFormatter('  a   b  c  d   ').format() == 'A b c d'

# Generated at 2022-06-24 02:11:12.971832
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) != 'test:clickhere'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) != 'test:clickhere'
# End unit test



# Generated at 2022-06-24 02:11:25.538942
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("thisIsASnakeCaseTest") == "this_is_a_snake_case_test"
    assert camel_case_to_snake("thisIsASnakeCaseTest", separator='-') == "this-is-a-snake-case-test"
    assert camel_case_to_snake("thisIsNotASnakeCaseTest") == "thisIsNotASnakeCaseTest"
    assert camel_case_to_snake("this_is_a_snake_case_test") == "this_is_a_snake_case_test"
    assert camel_case_to_snake("") == ""
    assert camel_case_to_snake("thisIsAString", 1) == "this_is_a_string"
    assert camel_case_to_

# Generated at 2022-06-24 02:11:28.561459
# Unit test for function decompress
def test_decompress():
    assert is_string(decompress('eNpL01cuyi8S'))
    assert is_string(decompress('eNqLcz4uyi8S'))
    assert is_string(decompress('eNpLTTyc5Koi8S'))


# Generated at 2022-06-24 02:11:36.304577
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<p>hello <b>world</b></p>') == '<p>hello <b>world</b></p>'
    assert strip_html('<p>hello <b>world</b></p>', keep_tag_content=True) == 'helloworld'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" class="btn btn-small">click here</a>') == 'test: '

# Generated at 2022-06-24 02:11:44.071886
# Unit test for function slugify
def test_slugify():
	input_string1 = "Top 10 Reasons To Love Dogs!!!"
	input_string2 = "Mönstér Mägnët"
	output1 = slugify(input_string1)
	output2 = slugify(input_string2)
	expected1 = "top-10-reasons-to-love-dogs"
	expected2 = "monster-magnet"
	if output1 == expected1 and output2 == expected2:
		print("Test passed!")
	else:
		print("Test failed!")



# Generated at 2022-06-24 02:11:51.096393
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'

# Generated at 2022-06-24 02:11:57.998120
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse(23) == 23
    assert reverse('') == ''
    assert reverse(None) is None
    assert reverse([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 02:12:06.324303
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('this Is A tESt').format() == 'This is a test'
    assert __StringFormatter('USING TOO MUCH CAPI\'TA''L LETTERS').format() == 'Using too much capital letters'
    assert __StringFormatter('test@test.test').format() == 'test@test.test'
    assert __StringFormatter('m@test.test').format() == 'm@test.test'
    assert __StringFormatter('http://test@test.test').format() == 'http://test@test.test'
    assert __StringFormatter('http://test@test.test/test').format() == 'http://test@test.test/test'
    assert __StringFormatter('http:///test').format() == 'http:///test'

# Generated at 2022-06-24 02:12:07.468070
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                                line 1
                                line 2
                                line 3''') == '''
line 1
line 2
line 3'''


# Generated at 2022-06-24 02:12:19.987132
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode('5') == 'V'
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(-1) == '-I'
    assert roman_encode(-37) == '-XXXVII'
    assert roman_encode(-2020) == '-MMXX'
    assert roman_encode(-3999) == '-MMMCMXCIX'

# Generated at 2022-06-24 02:12:26.453701
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('1') == True

    assert booleanize('false') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('0') == False



# Generated at 2022-06-24 02:12:30.995960
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert decompress(compressed) == original



# Generated at 2022-06-24 02:12:33.255201
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:12:45.990736
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('123') == 'CXXIII'
    assert roman_encode(1) == 'I'
    assert roman_encode(4) == 'IV'
    assert roman_encode(1999) == 'MCMXCIX'
    assert roman_encode(0) == ''
    assert roman_encode(-10) == ''
    assert roman_encode(-10.1) == ''
    assert roman_encode('-10') == ''
    assert roman_encode(10000) == 'MMMMMMMMMM'
    assert roman_encode(4444) == 'MMMMCDXLIV'
    assert roman_encode(7777) == 'MMMMMMMMDCCLXXVII'
    assert roman_encode('s') == ''
    assert r

# Generated at 2022-06-24 02:12:48.520717
# Unit test for function prettify

# Generated at 2022-06-24 02:12:53.669508
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XII') == 12
    assert roman_decode('XIV') == 14
    assert roman_decode('XV') == 15
    assert roman_decode('XIX') == 19
    assert roman_decode('XX') == 20
    assert roman_decode('XXX') == 30

# Generated at 2022-06-24 02:13:01.753485
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(1, 10) == 'X'
    assert __RomanNumbers.__encode_digit(1, 50) == 'L'
    assert __RomanNumbers.__encode_digit(2, 100) == 'C'
    assert __RomanNumbers.__encode_digit(2, 500) == 'D'
    assert __RomanNumbers.__encode_digit(3, 1000) == 'M'

    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_

# Generated at 2022-06-24 02:13:07.654005
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:13:13.974443
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('mcmxcviii') == 1998
    assert roman_decode('MCMXCIX') == 1999
    assert roman_decode('m_m_x_c_ix') == 1999

test_roman_decode()

# Generated at 2022-06-24 02:13:22.568780
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = "They are not just bad; they are totally incompetent. Just incompetent people"
    compressed_string = __StringCompressor.compress(input_string)
    assert compressed_string == 'eNrNV2lsNgkAIwFJ1RHPWtT8Q09xDq3AnoX9BJW1Z8kvUIKfHwgi7VnhWcKg7VHBxYJHgQABiQgKFUDIGVDRDQ='
    assert __StringCompressor.decompress(compressed_string) == input_string


# PUBLIC API



# Generated at 2022-06-24 02:13:29.726889
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert 'some string' == __StringFormatter("some string").input_string
    assert 'some string' == __StringFormatter("some string").input_string

    assert 'some string' == __StringFormatter("some string").input_string
    assert 'some string' == __StringFormatter("some string").input_string


# Generated at 2022-06-24 02:13:33.928642
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓËabcdefg'") == "eeuuooaaeynAAACIINOEabcdefg'"



# Generated at 2022-06-24 02:13:35.588322
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:13:37.817189
# Unit test for function strip_html
def test_strip_html():
    test_input = "hello <a href='foo/bar'>link</a>"
    expected_result = "hello link"
    successful = strip_html(test_input, True) == expected_result
    print('strip_html: ', 'pass' if successful else 'fail')



# Generated at 2022-06-24 02:13:47.159353
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('X') == 10
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000

    assert roman_decode('XV') == 15
    assert roman_decode('XX') == 20
    assert roman_decode('XXX') == 30
    assert roman_decode('XL') == 40
    assert roman_decode('LX') == 60
    assert roman_decode('LXX') == 70
    assert roman_decode('LXXX') == 80


# Generated at 2022-06-24 02:13:49.638459
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello, world') == 'dlrow ,olleh'
    assert reverse('/d/s/f') == '/f/s/d'
    assert reverse('') == ''



# Generated at 2022-06-24 02:13:59.327040
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    try:
        __StringCompressor.compress('')
        assert (False)
    except ValueError:
        assert (True)
    try:
        __StringCompressor.compress('abc', compression_level=10)
        assert (False)
    except ValueError:
        assert (True)
    try:
        __StringCompressor.compress('abc', compression_level=-1)
        assert (False)
    except ValueError:
        assert (True)
    try:
        __StringCompressor.decompress('abc')
        assert (False)
    except ValueError:
        assert (True)

# Generated at 2022-06-24 02:14:06.638095
# Unit test for function decompress

# Generated at 2022-06-24 02:14:12.009558
# Unit test for function asciify
def test_asciify():
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')


# Generated at 2022-06-24 02:14:13.676987
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-24 02:14:19.651461
# Unit test for function decompress
def test_decompress():
    text = "Hello world!"
    text_compressed = 'eJxLTEsL9MgDf1j96DA=='
    compressed = decompress(text_compressed, 'utf-8')
    assert compressed == text



# Generated at 2022-06-24 02:14:27.241611
# Unit test for function prettify
def test_prettify():
    assert prettify('test') == 'test'
    assert prettify('test:') == 'Test:'
    assert prettify('% test') == '% test'
    assert prettify('%test') == '%test'
    assert prettify('(test)') == '(test)'
    assert prettify('( test)') == '(test)'
    assert prettify(' bad    text    with   "   "   "  "  "  "     "') == 'Bad text with "" "" "" "" ""'
    assert prettify(' bad    text    with   -   -   =   =    =    =     =') == 'Bad text with - - = = = = = ='
    assert prettify(' foo-bar-baz') == 'Foo-bar-baz'

# Generated at 2022-06-24 02:14:34.755037
# Unit test for function strip_html
def test_strip_html():
    test_str = "test: <a href='foo/bar'>click here</a>"
    assert strip_html(test_str) == 'test: '
    assert strip_html(test_str, keep_tag_content=True) == 'test: click here'

# Testing for function strip_html
test_strip_html()


# Generated at 2022-06-24 02:14:45.077340
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='') == 'thisisacamelstringtest'

# Generated at 2022-06-24 02:14:51.337398
# Unit test for function decompress
def test_decompress():
    """
    Test for function decompress
    """
    test_list=["é"]
    for elem in test_list:
        compressed = compress(elem)
        assert decompress(compressed) == elem,"decompress(compress) not identity"

if __name__ == '__main__':
    test_decompress()
    # print(compress("é"))

# Generated at 2022-06-24 02:14:54.502306
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<h1>Title<h1>') == 'Title'
    assert strip_html('Salut les <b>gens</b>') == 'Salut les gens'
    assert strip_html('Salut les gens', True) == 'Salut les <b>gens</b>'
    assert strip_html('Salut les <a href="b">gens</b></a></a>', True) == 'Salut les <a href="b">gens</a>'



# Generated at 2022-06-24 02:14:59.140737
# Unit test for function booleanize
def test_booleanize():
    # Test the function with the examples given in the docstring
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    # Test the function with another example
    assert booleanize('0') == False
    # Test the function with ''
    assert booleanize('') == False
    # Test the function with 'False'
    assert booleanize('False') == False
    # Test the function with None
    assert booleanize(None) == False
    # Test the function with 0
    with pytest.raises(InvalidInputError):
        booleanize(0)
    # Test the function with False
    with pytest.raises(InvalidInputError):
        booleanize(False)
    # Test the function with 'a string'

# Generated at 2022-06-24 02:15:09.169968
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('abcd') != 'abcd'
    assert len(shuffle('abcd')) == len('abcd')
    assert len(set(shuffle('abcd'))) == len(set('abcd'))
    assert len(set(shuffle('abcd'))) == len(set(shuffle('abcd')))
    assert len(set(shuffle('abcd'))) == len(set(shuffle('abcd')))
    assert len(set(shuffle('abcd'))) == len(set(shuffle('abcd')))
    assert len(set(shuffle('abcd'))) == len(set(shuffle('abcd')))
    assert len(set(shuffle('abcd'))) == len(set(shuffle('abcd')))
    assert type(shuffle('abcd')) == str
test

# Generated at 2022-06-24 02:15:14.469488
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Declare a new instance of __StringCompressor class
    t_StringCompressor = __StringCompressor()
    # get the intance type
    assert type(t_StringCompressor)
    # get the class type
    assert type(t_StringCompressor) == __StringCompressor



# Generated at 2022-06-24 02:15:18.034311
# Unit test for function strip_html
def test_strip_html():
    html = '<html><body>footer: <img src="/img/footer.jpg"/></body></html>'
    stripped1 = strip_html(html)
    stripped2 = strip_html(html, keep_tag_content=True)
    assert stripped1 == ''
    assert stripped2 == 'footer: '



# Generated at 2022-06-24 02:15:23.098510
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', False, '-') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:15:32.208313
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # The constructor of the class __StringFormatter should accept only strings
    # It should raise an exception if we try to pass an integer or a float
    try:
        __StringFormatter(2)
        assert False, 'The constructor of the class __StringFormatter should accept only strings.'
    except InvalidInputError:
        assert True

    try:
        __StringFormatter(2.3)
        assert False, 'The constructor of the class __StringFormatter should accept only strings.'
    except InvalidInputError:
        assert True


# Generated at 2022-06-24 02:15:34.097741
# Unit test for function decompress
def test_decompress():
    input_string = "br"
    encoding = "utf-8"
    print(decompress(input_string, encoding))



# Generated at 2022-06-24 02:15:43.116815
# Unit test for function roman_encode
def test_roman_encode():
    # Test with different numeric representations
    assert roman_encode(1) == 'I'
    assert roman_encode('2') == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode('7') == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    # Test with empty string
   

# Generated at 2022-06-24 02:15:54.900286
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('This is a Test!').format() == 'This is a test!'
    assert __StringFormatter('heLLo WOrld').format() == 'Hello world'
    assert __StringFormatter('-.-This is a Test!-.-').format() == '-.-This is a test!-.-'
    assert __StringFormatter('  -.-This    is a   Test!-.-      ').format() == '-.-This is a test!-.-'
    assert __StringFormatter('the best way to do it   is to  do it').format() == 'The best way to do it is to do it'
    assert __StringFormatter('hello!! world?').format() == 'Hello world?'
    assert __StringFormatter('hello. world').format() == 'Hello world'

# Generated at 2022-06-24 02:16:06.487800
# Unit test for function strip_margin

# Generated at 2022-06-24 02:16:16.725056
# Unit test for function strip_margin
def test_strip_margin():
    input = '''
        line 1
        line 2
        line 3
    '''
    expected_output = '''
line 1
line 2
line 3
'''
    actual_output = strip_margin(input)
    if actual_output != expected_output:
        print("ERROR: expected output: " + expected_output)
        print("ERROR: actual   output: " + actual_output)

test_strip_margin()
# This is a test suite for the stringr string manipulation functions

# Test basic string functions

import unittest

# Test the strip_margin function

# Generated at 2022-06-24 02:16:21.812265
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .crypto import md5

    # decompress a compressed string
    assert __StringCompressor.decompress(__StringCompressor.compress('Hello world!!'), 'utf-8') == 'Hello world!!'

    # compress a large string
    text = '\n'.join(['Lorem ipsum dolor sit amet, consectetur adipiscing elit.'] * 100)
    assert md5(__StringCompressor.decompress(__StringCompressor.compress(text), 'utf-8')) == md5(text)



# Generated at 2022-06-24 02:16:34.452401
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert (__StringFormatter('').format() is '')
    assert (__StringFormatter(' ').format() is '')
    assert (__StringFormatter('  ').format() is '')
    assert (__StringFormatter('   ').format() is '')
    assert (__StringFormatter('a').format() is 'A')
    assert (__StringFormatter('  a  ').format() is 'A')
    assert (__StringFormatter('  a  b  ').format() is 'A B')
    assert (__StringFormatter('  a  b  c  ').format() is 'A B C')
    assert (__StringFormatter('  a  b  c  d  ').format() is 'A B C D')

# Generated at 2022-06-24 02:16:38.571741
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    obj = __StringCompressor
    assert '__require_valid_input_and_encoding' in dir(obj)
    assert 'compress' in dir(obj)
    assert 'decompress' in dir(obj)


# Generated at 2022-06-24 02:16:45.408283
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    print('\n*** Starting test_to_snake_case ***')
    input_string = 'thisIsACamelStringTest'
    print('Camel case: ', input_string)
    print('Snake case: ', camel_case_to_snake(input_string))
    print('*** Finished test_to_snake_case ***')

test_camel_case_to_snake()



# Generated at 2022-06-24 02:16:52.947390
# Unit test for function shuffle
def test_shuffle():
    test_dict = {
        'empty': '',
        'one_char': 'a',
        'valid': 'hello world',
    }

    for k in test_dict:
        try:
            shuffle(test_dict[k])
        except:
            raise AssertionError('test_shuffle: "{k}" failed'.format(k=k))
        else:
            print('test_shuffle: "{k}" passed'.format(k=k))



# Generated at 2022-06-24 02:17:04.180110
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import unittest
    from .errors import ConversionError

    def __test_case(input, expected):
        sf = __StringFormatter(input)
        actual = sf.format()

        assert actual == expected, 'Assertion failed: {} != {}'.format(actual, expected)

    class TestMethods:
        def test_simple_string(self):
            input = '  test   to   prettify '
            expected = 'Test to prettify'
            __test_case(input, expected)

        def test_punctuation_and_symbols(self):
            input = '  test   ' + '  !~!@#$%^&*()-_+=-~`\\\":\';\\/.,<>?[]}{ ' + 'to prettify'

# Generated at 2022-06-24 02:17:06.677454
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
    return

# Generated at 2022-06-24 02:17:16.081059
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('  a  b  c  d  e  ').format() == 'A B C D E'
    assert __StringFormatter('  a  b  b  c  d  e  ').format() == 'A B B C D E'
    assert __StringFormatter('  a  b  c  d  d  e  ').format() == 'A B C D D E'
    assert __StringFormatter('  a b c d e ').format() == 'A B C D E'
    assert __StringFormatter('a b c d e').format() == 'A B C D E'
    assert __StringFormatter('a b c d e ').format() == 'A B C D E'
    assert __StringFormatter(' a b c d e').format() == 'A B C D E'
   

# Generated at 2022-06-24 02:17:20.645124
# Unit test for function roman_encode
def test_roman_encode():
    if str(roman_encode(37)) != 'XXXVIII':
        raise ValueError()
    if str(roman_encode('2020')) != 'MMXX':
        raise ValueError()
test_roman_encode()



# Generated at 2022-06-24 02:17:26.388405
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('!@#$%^&*()') == ')(*&^%$#@!'
    assert reverse(' ') == ' '
    assert reverse('') == ''



# Generated at 2022-06-24 02:17:35.515602
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # Testing different scenarios
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', separator='+') == 'this+is+a+camel+string+test'
    assert camel_case_to_snake('hello') == 'hello'
# END unit test for function camel_case_to_snake



# Generated at 2022-06-24 02:17:46.571630
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Valid string
    inputString1 = "This is a test string"
    outputString1 = "This is a test string"
    assert __StringFormatter.__init__(inputString1) == outputString1

    # Invalid string
    inputString2 = ["The", "following", "is", "a", "list"]
    outputString2 = "Input must be a non empty string"
    #assert __StringFormatter.__init__(inputString2) == outputString2

    # Empty string
    inputString3 = ""
    outputString3 = "Input must be a non empty string"
    #assert __StringFormatter.__init__(inputString3) == outputString3



# Generated at 2022-06-24 02:17:57.989137
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green-now', separator='-') == 'TheSnakeIsGreenNow'
    assert snake_case_to_camel('the-snake-is-green-now', False, '-') == 'theSnakeIsGreenNow'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'


# Generated at 2022-06-24 02:18:08.091824
# Unit test for function decompress
def test_decompress():
    """
    Unit test for function decompress
    """
    assert decompress(compress('test')) == 'test'
    # list of test cases

# Generated at 2022-06-24 02:18:10.541585
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:18:17.125413
# Unit test for function prettify
def test_prettify():
    original = 'test-test TEST-TEST     foo     bar     foo     bar   foo   bar   foo   bar, foo.bar! foo?  bar '
    expected = 'Test-test Test-test Foo bar Foo bar Foo bar Foo bar, foo. Bar! Foo? Bar'
    assert prettify(original) == expected



# Generated at 2022-06-24 02:18:27.538330
# Unit test for function decompress
def test_decompress():
    """
    Test for the function "decompress".
    """


# Generated at 2022-06-24 02:18:34.443198
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('tRUE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('no') == False
    assert booleanize('0') == False
    assert booleanize('') == False
    assert booleanize(None) == False
    assert booleanize('n') == False
    assert booleanize('nope') == False
    assert booleanize(0) == False
    assert booleanize(1) == False


# Generated at 2022-06-24 02:18:40.012283
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print(compressed)
    print(len(compressed))

if __name__ == '__main__':
    test_compress()

# Generated at 2022-06-24 02:18:51.546002
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert 'Abc def' == __StringFormatter('abc def').format()
    assert 'Abc def' == __StringFormatter(' Abc def ').format()
    assert 'Abc def' == __StringFormatter('  Abc def  ').format()
    assert 'Abc def' == __StringFormatter(' abc Def  ').format()
    assert "Abc's def" == __StringFormatter('abc\'s def').format()
    assert "Abc's def" == __StringFormatter('abc\'s Def').format()
    assert 'Abc de f' == __StringFormatter('Abc  de  f').format()
    assert 'Abc de f' == __StringFormatter('Abc de f').format()
    assert 'Abc de f' == __StringFormatter('  Abc   de   f ').format

# Generated at 2022-06-24 02:19:01.825561
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('All of the     spaces will be removed') == 'all-of-the-spaces-will-be-removed'
    assert slugify('All of the     spaces will be removed', '|') == 'all|of|the|spaces|will|be|removed'
    assert slugify('All of the     spaces will be removed', '+') == 'all+of+the+spaces+will+be+removed'
    assert slugify('All of the     spaces will be removed', '!') == 'all!of!the!spaces!will!be!removed'

# Generated at 2022-06-24 02:19:07.628212
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    c = __StringCompressor()
    input_string = '0123456789' * 10

    compressed_str = c.compress(input_string)
    assert c.decompress(compressed_str) == input_string

    compressed_str = c.compress(input_string, compression_level=0)
    assert c.decompress(compressed_str) == input_string

    compressed_str = c.compress(input_string, compression_level=1)
    assert c.decompress(compressed_str) == input_string

    compressed_str = c.compress(input_string, compression_level=9)
    assert c.decompress(compressed_str) == input_string


# PUBLIC API



# Generated at 2022-06-24 02:19:18.717080
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():

    from .assertions import assert_equal


# Generated at 2022-06-24 02:19:27.877770
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('How  are you? me too, thanks').format() == 'How are you? Me, too, thanks'
    assert __StringFormatter('How    are    you?    me    too,    thanks').format() == 'How are you? Me, too, thanks'
    assert __StringFormatter('1 How  are you? me too, thanks').format() == '1. How are you? Me, too, thanks'
    assert __StringFormatter('1. How,are:you? me,too,thanks').format() == '1. How, are: you? Me, too, thanks'
    assert __StringFormatter('https://www.google.com').format() == 'https://www.google.com'
    assert __StringFormatter('http://www.google.com').format() == 'http://www.google.com'
