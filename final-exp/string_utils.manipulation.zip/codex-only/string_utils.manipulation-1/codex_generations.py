

# Generated at 2022-06-24 02:09:23.405364
# Unit test for function shuffle
def test_shuffle():
    assert_true(shuffle('hello world') != 'hello world')



# Generated at 2022-06-24 02:09:31.652454
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:09:41.585592
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello').format() == 'Hello'
    assert __StringFormatter('hello     world').format() == 'Hello World'
    assert __StringFormatter('hello    world').format() == 'Hello World'
    assert __StringFormatter('hello world     ').format() == 'Hello World'
    assert __StringFormatter('hello world    ').format() == 'Hello World'
    assert __StringFormatter('  hello world    ').format() == 'Hello World'
    assert __StringFormatter('  hello world   ').format() == 'Hello World'
    assert __StringFormatter('hello    world    and    again').format() == 'Hello World And Again'
    assert __StringFormatter('hello world and again').format() == 'Hello World And Again'

# Generated at 2022-06-24 02:09:43.724822
# Unit test for function shuffle
def test_shuffle():
    out = shuffle('hello world')
    assert len(out) == len('hello world')
    assert not out == 'hello world'



# Generated at 2022-06-24 02:09:47.339176
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    input_string = 'ThisIsACamelStringTest'
    res = camel_case_to_snake(input_string)
    assert res == 'this_is_a_camel_case_string_test'
# /Unit test for function camel_case_to_snake



# Generated at 2022-06-24 02:09:53.704858
# Unit test for function decompress

# Generated at 2022-06-24 02:09:54.359603
# Unit test for function decompress
def test_decompress():
    assert decompress('big') == 'big'


# Generated at 2022-06-24 02:10:02.378651
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("VII") == 7
    assert roman_decode("IX") == 9
    assert roman_decode("XXV") == 25
    assert roman_decode("XLIX") == 49
    assert roman_decode("CCCLXXXV") == 385
    assert roman_decode("MMXIX") == 2019
    assert roman_decode("MMDCCCLXXXVIII") == 2888
    assert roman_decode("MMMMCMXCV") == 4995
    assert roman_decode("MMI") == 2001

test_roman_decode()

# Generated at 2022-06-24 02:10:07.878808
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                line 1
                line 2
                line 3
                ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:10:09.257044
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:10:12.619249
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'

# Generated at 2022-06-24 02:10:19.316499
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    print(original, compressed)
    return [original, compressed]

# Generated at 2022-06-24 02:10:27.193781
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('ěščřžýáíéúůďťňÝÁÍÉÚŮŇÝÁÍÉÚŮŇó') == 'escrzyaieuuidtnyAIEUUYAIEUUON'



# Generated at 2022-06-24 02:10:31.628301
# Unit test for function compress
def test_compress():
    """Test for the compress function."""
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert isinstance(compressed, str)



# Generated at 2022-06-24 02:10:34.010394
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor


# PUBLIC API



# Generated at 2022-06-24 02:10:38.586853
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'

# Generated at 2022-06-24 02:10:40.682831
# Unit test for function roman_encode
def test_roman_encode():

    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-24 02:10:47.467814
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    fmt = __StringFormatter("hello")
    assert (fmt.input_string == "hello")
    fmt = __StringFormatter('   hello     ')
    assert (fmt.input_string == '   hello     ')
    try:
        __StringFormatter(123456)
        raise Exception("not valid test")
    except InvalidInputError as e:
        pass


# Generated at 2022-06-24 02:10:51.728918
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" title>click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" title>click here</a>') == 'test: '



# Generated at 2022-06-24 02:10:54.108657
# Unit test for function roman_decode
def test_roman_decode():
    """
    Test function roman_decode.
    """

    assert roman_decode('VII') == 7


# Generated at 2022-06-24 02:10:57.794278
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# PUBLIC API

# Generated at 2022-06-24 02:11:05.263466
# Unit test for function slugify
def test_slugify():
    print("Unit test for slugify")

    # Test case 1
    print("Test case 1 - Normal string")
    print("Input: Top 10 Reasons To Love Dogs!!!")
    print("Expected output: top-10-reasons-to-love-dogs")
    print("Actual output:", slugify("Top 10 Reasons To Love Dogs!!!"))

    # Test case 2
    print("Test case 2 - Non-English string")
    print("Input: Mönstér Mägnët")
    print("Expected output: monster-magnet")
    print("Actual output:", slugify("Mönstér Mägnët"))

    # Test case 3
    print("Test case 3 - Non-ASCII string")
    print("Input: 我是法国人")

# Generated at 2022-06-24 02:11:16.231447
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-24 02:11:21.413011
# Unit test for function slugify
def test_slugify():
    try:
        assert slugify('Top 10 Reasons To Love Dogs!!!', '_') == 'top_10_reasons_to_love_dogs'
        assert slugify('Mönstér Mägnët') == 'monster-magnet'
        assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
        assert slugify('Mönstér Mägnët', '/') == 'monster/magnet'
        assert slugify('Mönstér Mägnët', '') == 'monstermagnet'
        print('slugify test passed')
    except:
        print('slugify test failed')


# Generated at 2022-06-24 02:11:26.916335
# Unit test for function asciify
def test_asciify():
    assert asciify('lorem ìpsum èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'lorem ipsum eeuuuooaaeynAAACIINOE'
    assert asciify('') == ''
    assert asciify(None) == ''



# Generated at 2022-06-24 02:11:35.537346
# Unit test for function booleanize
def test_booleanize():
    """ Tests the booleanize function to see if it is working properly"""
    # Test 1: checks if the booleanize function returns a boolean
    assert isinstance(booleanize("true"), bool)
    # Test 2: checks if the function is functional
    assert booleanize("true")
    # Test 3: checks if case insensitive
    assert booleanize("True")
    # Test 4: checks if it catches non-boolean string
    assert not booleanize("Bob")



# Generated at 2022-06-24 02:11:38.580454
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)



# Generated at 2022-06-24 02:11:39.739115
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == "XXXVII"
    assert roman_encode('2020') == 'MMXX'


# Generated at 2022-06-24 02:11:44.363390
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'lleoh'
    assert shuffle('hello world') == 'l worldoeh'
    assert shuffle('hello world') == ' llhrdeeowo'



# Generated at 2022-06-24 02:11:58.975031
# Unit test for function decompress

# Generated at 2022-06-24 02:12:01.784116
# Unit test for function shuffle
def test_shuffle():
    test_string = 'hello world'
    shuffled = shuffle(test_string)
    assert(len(shuffled) == len(test_string)), 'The shuffled string doesn''t have the same length as the original one'
    assert(shuffled != test_string), 'The shuffled string cannot be equal to the original one'

test_shuffle()



# Generated at 2022-06-24 02:12:05.705213
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'

test_strip_html()



# Generated at 2022-06-24 02:12:08.217480
# Unit test for function shuffle
def test_shuffle():
    random.seed(1)  # using a fixed seed to ensure the same output
    assert shuffle('hello world') == 'd lwlherloo'
    assert shuffle('hello world') == shuffle('hello world')

# Generated at 2022-06-24 02:12:14.167080
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the') == 'The'



# Generated at 2022-06-24 02:12:16.442634
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("VII") == 7
test_roman_decode()



# Generated at 2022-06-24 02:12:23.194310
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('<p> the slug is: foo-bar <p>') == 'the-slug-is-foo-bar'
    assert slugify('Pure Python 3!') == 'pure-python-3'



# Generated at 2022-06-24 02:12:33.169341
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sample = """

This is a     Sample:
        sample          !
    """
    assert __StringFormatter(sample).format() == 'This is a Sample: sample!'

    sample = 'This is a sample: Sample!'
    assert __StringFormatter(sample).format() == 'This is a Sample: Sample!'

    sample = 'This is a sample: sample!'
    assert __StringFormatter(sample).format() == 'This is a Sample: sample!'

    sample = 'This is a Sample: sample!'
    assert __StringFormatter(sample).format() == 'This is a Sample: sample!'

    sample = 'This is a  Sample: sample!'
    assert __StringFormatter(sample).format() == 'This is a Sample: sample!'

    sample = 'This is a Sample: sample! (music)'

# Generated at 2022-06-24 02:12:45.910731
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true") == True, "true"
    assert booleanize("True") == True, "True"
    assert booleanize("tRue") == True, "tRue"
    assert booleanize("1") == True, "1"
    assert booleanize("yes") == True, "yes"
    assert booleanize("YES") == True, "YES"
    assert booleanize("y") == True, "y"
    assert booleanize("Y") == True, "Y"

    assert booleanize("false") == False, "false"
    assert booleanize("False") == False, "False"
    assert booleanize("fAlse") == False, "fAlse"
    assert booleanize("2") == False, "2"
    assert booleanize("No") == False, "No"

# Generated at 2022-06-24 02:12:57.324361
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisisACamelStringTest', '>') == 'thisis>a>camel>string>test'



# Generated at 2022-06-24 02:13:00.429650
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
        line 1
        line 2
        line 3
    '''
    expected_output = '''
    line 1
    line 2
    line 3
    '''
    assert(strip_margin(input_string) == expected_output)



# Generated at 2022-06-24 02:13:07.811579
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelString') == 'this_is_a_camel_string'
    assert camel_case_to_snake('thisIsACamelString') == 'this_is_a_camel_string'
    assert camel_case_to_snake('ThisIsACamel') == 'this_is_a_camel'
    assert camel_case_to_snake('thisIsACamel') == 'this_is_a_camel'

# Generated at 2022-06-24 02:13:18.110757
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.decode('M') == 1000
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.decode('C') == 100
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.decode('X') == 10
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.encode(9999) == 'MMMMMMMMMCMXCIX'
    assert __RomanNumbers.decode('MMMMMMMMMCMXCIX') == 9999
    try:
        __RomanNumbers.encode(0)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 02:13:23.232685
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
                 line 1
                 line 2
                 line 3
                 '''
    expected_output_string = '''
line 1
line 2
line 3
'''
    assert(expected_output_string == strip_margin(input_string))

# Generated at 2022-06-24 02:13:35.298562
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('camel_case_string_test') == 'CamelCaseStringTest'
    assert snake_case_to_camel('camel_case_string_test', upper_case_first=False) == 'camelCaseStringTest'
    assert snake_case_to_camel('camel_case_string_test', upper_case_first=False, separator='-') == 'camelCaseStringTest'
    assert snake_case_to_camel('camel_case_string_test', upper_case_first=False, separator=' ') == 'camel case string test'
    assert snake_case_to_camel('camel-case-string-test', upper_case_first=False, separator='-') == 'camelCaseStringTest'
    assert snake_case_to

# Generated at 2022-06-24 02:13:46.977932
# Unit test for function booleanize
def test_booleanize():
    # true
    assert booleanize('true') is True, 'Failed to convert "true" to boolean (true)'
    assert booleanize('True') is True, 'Failed to convert "True" to boolean (true)'
    assert booleanize('1') is True, 'Failed to convert "1" to boolean (true)'
    assert booleanize('YES') is True, 'Failed to convert "YES" to boolean (true)'
    assert booleanize('y') is True, 'Failed to convert "y" to boolean (true)'
    assert booleanize('Y') is True, 'Failed to convert "Y" to boolean (true)'
    # false
    assert booleanize('false') is False, 'Failed to convert "false" to boolean (false)'
    assert booleanize('False') is False, 'Failed to convert "False" to boolean (false)'

# Generated at 2022-06-24 02:13:49.067191
# Unit test for function asciify
def test_asciify():
    asciifed = asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')
    print("asciifed = " + asciifed)
    assert asciifed == 'eeuuooaaeynAAACIINOE'
test_asciify()


# Generated at 2022-06-24 02:13:51.784914
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-24 02:13:56.718631
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-24 02:14:06.495364
# Unit test for function roman_encode
def test_roman_encode():
    # testing invalid input
    with pytest.raises(InvalidInputError):
        roman_encode(None)
    with pytest.raises(InvalidInputError):
        roman_encode({})
    with pytest.raises(InvalidInputError):
        roman_encode(-1)
    with pytest.raises(InvalidInputError):
        roman_encode(0)
    with pytest.raises(InvalidInputError):
        roman_encode(4000)
    with pytest.raises(InvalidInputError):
        roman_encode('hello')
    with pytest.raises(InvalidInputError):
        roman_encode('-20')

    # testing valid input
    assert roman_encode(1) == 'I'

# Generated at 2022-06-24 02:14:09.261018
# Unit test for function shuffle
def test_shuffle():
    # test with common string
    s = '12345'
    l = list(s)
    random.shuffle(l)
    assert ''.join(l) != s
    assert shuffle(s) != s

test_shuffle()


# Generated at 2022-06-24 02:14:14.578301
# Unit test for function prettify
def test_prettify():
    source = """
            #include <iostream>
            #include <string>
        
            using namespace std;
            int main()
            {
                int number = 12.23423;
                int number = 12.1;
                int number = 41642;
                string str = "text that could be \"prettified\"!";
                cout << str << endl;
                return 0;
            }
             """
    print(prettify(source))

test_prettify()


# Generated at 2022-06-24 02:14:24.682748
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'Hello world'
    expected_compressed_string = 'eJwLr6rOwzAIt_dWxcbV2xcbF1dai6rGgA'
    expected_decompressed_string = 'Hello world'

    compressed_string = __StringCompressor.compress(input_string)
    assert compressed_string == expected_compressed_string, 'Compression failed'

    decompressed_string = __StringCompressor.decompress(compressed_string)
    assert decompressed_string == expected_decompressed_string, 'Decompression failed'


# PUBLIC API


# Generated at 2022-06-24 02:14:28.635097
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("XX") == 20
    assert roman_decode("XIV") == 14
    assert roman_decode("LVIII") == 58
    assert roman_decode("MCMXCIV") == 1994
    assert roman_decode("MMMCMXCIX") == 3999


# Generated at 2022-06-24 02:14:34.747257
# Unit test for function booleanize
def test_booleanize():
    assert booleanize("true") == True
    assert booleanize("1") == True
    assert booleanize("yes") == True
    assert booleanize("y") == True
    assert booleanize("nope") == False


# Generated at 2022-06-24 02:14:38.537313
# Unit test for function reverse
def test_reverse():
    from .test import execute_test

    execute_test(reverse, [
        ('hello', 'olleh'),
        ('world', 'dlrow'),
    ])

# Generated at 2022-06-24 02:14:44.129659
# Unit test for function shuffle
def test_shuffle():
    """
    Test that shuffled string contains the same chars (maybe in a different order)
    """
    import random

    for i in range(0, 100):
        original = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        shuffled = shuffle(original)

        assert shuffled != original and sorted(original) == sorted(shuffled)



# Generated at 2022-06-24 02:14:47.138448
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:14:58.215401
# Unit test for function slugify
def test_slugify():
    #Test 1
    if slugify("Top 10 Reasons To Love Dogs!!!")!="top-10-reasons-to-love-dogs":
        print("error test 1")
    #Test 2
    if slugify("Mönstér Mägnët")!="monster-magnet":
        print("error test2")
    #Test 3
    if slugify("[)(!@£$%^&*($%^)|]@€")!="":
        print("error test3")
    #Test 4
    if slugify("")!="":
        print("error test4")
    #Test 5

# Generated at 2022-06-24 02:15:05.923157
# Unit test for function booleanize
def test_booleanize():
    cases = {
    'true': True,
    'True': True,
    'yes': True,
    'Yes': True,
    'y': True,
    'Y': True,
    '1': True,
    '0': False,
    'foo': False,
}
    for testcase in cases:
        assert booleanize(testcase) == cases[testcase]
    pass


# Generated at 2022-06-24 02:15:16.431049
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    import pytest

    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'

    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'

    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'

# Generated at 2022-06-24 02:15:22.982816
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    print("\n=== test___StringFormatter_format ===")

# Generated at 2022-06-24 02:15:26.563092
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-24 02:15:37.763230
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("").format() == ""
    assert __StringFormatter("a").format() == "A"
    assert __StringFormatter("a a").format() == "A a"
    assert __StringFormatter("a a a").format() == "A a a"
    assert __StringFormatter("a a a a").format() == "A a a a"
    assert __StringFormatter("1 and a 2").format() == "1 and a 2"
    assert __StringFormatter("a a- a a").format() == "A a- a a"
    assert __StringFormatter(" a ").format() == "A"
    assert __StringFormatter("a a   a  a").format() == "A a a a"
    assert __StringFormatter("a a - a a").format() == "A a - a a"

# Generated at 2022-06-24 02:15:39.682136
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
test_camel_case_to_snake()



# Generated at 2022-06-24 02:15:41.920850
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") in ['l wodheorll', 'heoworldl l', 'loelhwlodr']



# Generated at 2022-06-24 02:15:51.766857
# Unit test for function compress
def test_compress():
    assert compress("Hello World") == "eJwBgQAAAD2AQAAAQAAbWV0YQ=="
    assert compress("") == "eJwBgQAAADwAQAAAQAAbWV0YQ=="
    assert compress(" ") == "eJwBgQAAADwAQAAAQAAbWV0YQ=="
    assert compress("\n") == "eJwBgQAAADwAQAAAQAAbWV0YQ=="
    assert compress("\t") == "eJwBgQAAADwAQAAAQAAbWV0YQ=="
    assert compress(" \n\t") == "eJwBgQAAADwAQAAAQAAbWV0YQ=="

# Generated at 2022-06-24 02:15:59.654537
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a cd e').format() == 'A cd e'
    assert __StringFormatter('a cd<>e').format() == 'A cd e'
    assert __StringFormatter('  a cd e').format() == 'A cd e'
    assert __StringFormatter('a cd   e').format() == 'A cd e'
    assert __StringFormatter('a cd   e    ').format() == 'A cd e'
    assert __StringFormatter('a cd   e    f').format() == 'A cd e f'
    assert __StringFormatter('a.cd e').format() == 'A.cd e'
    assert __StringFormatter('http://url.com').format() == 'http://url.com'
    assert __StringFormatter('a b c d').format() == 'A b c d'


# Generated at 2022-06-24 02:16:04.258708
# Unit test for function slugify
def test_slugify():
    assert_equal(slugify("Top 10 Reasons To Love Dogs!!!"),"top-10-reasons-to-love-dogs") # test1
    assert_equal(slugify("Mönstér Mägnët"), "monster-magnet") # test2
    assert_equal(slugify("%cassandra%"),"cassandracassandra") # test3
    assert_equal(slugify(""), "") # test4
    print("Test function passed")

# test_slugify()



# Generated at 2022-06-24 02:16:07.427634
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    return True



# Generated at 2022-06-24 02:16:10.666598
# Unit test for function compress
def test_compress():
    input_string = "test"
    result = compress(input_string)
    assert result == "eJwBAAAACAIAAACpWAAApVg=="


# Generated at 2022-06-24 02:16:21.127053
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello').format() == 'Hello'
    assert __StringFormatter('1 foo').format() == '1 Foo'
    assert __StringFormatter('foo 123').format() == 'Foo 123'
    assert __StringFormatter('foo-bar').format() == 'Foo Bar'
    assert __StringFormatter('foo_bar').format() == 'Foo Bar'
    assert __StringFormatter('foo-bar-baz').format() == 'Foo Bar Baz'
    assert __StringFormatter('foo----bar').format() == 'Foo Bar'
    assert __StringFormatter('foo  bar').format() == 'Foo Bar'
    assert __StringFormatter('foo  bar  baz').format() == 'Foo Bar Baz'

# Generated at 2022-06-24 02:16:23.671331
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == 'eeuuooaaeynAAACIINOE'
    return 'test_asciify passed'

print(test_asciify())


# Generated at 2022-06-24 02:16:29.254455
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:16:38.447206
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('III') == 3
    assert roman_decode('VI') == 6
    assert roman_decode('MCMXCVIII') == 1998
    assert roman_decode('MMDCCLXXVII') == 2777
    assert roman_decode('MMCMXCIX') == 2999
    assert roman_decode('MMMCCCXXXIII') == 3333
    assert roman_decode('MMMCDXXXV') == 3435
    assert roman_decode('MMMCDXLV') == 3445
    assert roman_decode('MMMCDL') == 3450
    assert roman_decode('MMMCDLXI') == 3461

# Generated at 2022-06-24 02:16:45.169302
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click <b>here</b></a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<p>test:</p> <a href="foo/bar">click <b>here</b></a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:16:47.164231
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = __StringFormatter('This is a string')
    assert (s is not None)


# Generated at 2022-06-24 02:16:58.554386
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    input_string = 'thisIsACamelStringTest'
    assert camel_case_to_snake(input_string, separator='_') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake(input_string, separator=' ') == 'this is a camel string test'
    assert camel_case_to_snake(" CamelCaseAbcDefGhiJkl") == ' camel_case_abc_def_ghi_jkl'
    assert camel_case_to_snake(" CamelCaseAbcDefGhiJkl ") == ' camel_case_abc_def_ghi_jkl '
    assert camel_case_to_snake(" CamelCaseAbcDefGhiJkl") == ' camel_case_abc_def_ghi_jkl'
    assert camel_

# Generated at 2022-06-24 02:17:02.113905
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor() is __StringCompressor()


# Generated at 2022-06-24 02:17:12.575589
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode(0) == 'I'
    assert roman_decode(1) == 'II'
    assert roman_decode(2) == 'III'
    assert roman_decode(3) == 'IV'
    assert roman_decode(4) == 'V'
    assert roman_decode(5) == 'VI'
    assert roman_decode(6) == 'VII'
    assert roman_decode(7) == 'VIII'
    assert roman_decode(8) == 'IX'
    assert roman_decode(9) == 'X'
    assert roman_decode(10) == 'XI'
    assert roman_decode(11) == 'XII'
    assert roman_decode(12) == 'XIII'


# Generated at 2022-06-24 02:17:17.418541
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TruE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('Y') == True
    assert booleanize('no') == False
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('0') == False
    assert booleanize('n') == False
    assert booleanize('N') == False


# Generated at 2022-06-24 02:17:22.461118
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'


# Generated at 2022-06-24 02:17:33.322692
# Unit test for function prettify
def test_prettify():
    assert prettify("hello world") == "Hello world"
    assert prettify("this is    a  test") == "This is a test"
    assert prettify("this is    a  test") == "This is a test"
    assert prettify("this is not a test.") == "This is not a test."
    assert prettify("100 % test") == "100% test"
    assert prettify("foo\"bar\"baz") == "Foo \"bar\" baz"
    assert prettify("foo(bar )baz") == "Foo (bar) baz"
    assert prettify("foo (bar )baz") == "Foo (bar) baz"
    assert prettify("foo( bar )baz") == "Foo (bar) baz"

# Generated at 2022-06-24 02:17:45.723211
# Unit test for function compress
def test_compress():
    assert compress('') == ''
    assert compress('test') == 'test'
    assert compress('0123456789') == '0123456789'
    assert compress('!@#$%^&*()') == '!@#$%^&*()'
    assert compress('Čář-Ěščěšří-ěščř') == 'Čář-Ěščěšří-ěščř'
    assert compress('word ' * 200) != 'word ' * 200
    assert compress('word ' * 100) != 'word ' * 100
    assert compress('word ' * 50) != 'word ' * 50
    assert compress('word ' * 20) != 'word ' * 20

# Generated at 2022-06-24 02:17:47.693700
# Unit test for function shuffle
def test_shuffle():
    actual = shuffle('hello world')
    assert len(actual) == len('hello world')
    print(actual)
test_shuffle()



# Generated at 2022-06-24 02:17:59.048533
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify('test without spaces') == 'test-without-spaces'
    assert slugify(' test with left  space') == 'test-with-left-space'
    assert slugify('test with right space ') == 'test-with-right-space'
    assert slugify('test with both    spaces  ') == 'test-with-both-spaces'
    assert slugify('test with right and left spaces ') == 'test-with-right-and-left-spaces'
    assert slugify('test.with.many.dots') == 'test-with-many-dots'
    assert slugify(' test.with.many.dots.and.spaces ') == 'test-with-many-dots-and-spaces'

# Generated at 2022-06-24 02:18:03.503664
# Unit test for function slugify
def test_slugify():
    print(slugify('Mönstér Mägnët'))
    print(slugify('Top 10 Reasons To Love Dogs!!!', '+'))


# Generated at 2022-06-24 02:18:10.964366
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('True')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('Yes')
    assert booleanize('y')
    assert booleanize('Y')
    assert not booleanize('false')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('N')
    assert not booleanize('nope')
    assert not booleanize('')


# MAIN

if __name__ == '__main__':
    print('Tests')
    print('=====')

    test_booleanize()
    test_snake_case_to_camel()
    test_camel_case_to_snake()
    test_strip_html()
    test_prettify()
    test_asci

# Generated at 2022-06-24 02:18:16.175854
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("snake_test") == "SnakeTest"
    assert snake_case_to_camel("snake_test", False) == "snakeTest"
    assert snake_case_to_camel("snake-test") == "SnakeTest"
    assert snake_case_to_camel("snake-test", False) == "snakeTest"
    assert snake_case_to_camel("snake_test-1") == "SnakeTest-1"
    assert snake_case_to_camel("snake_test-1", False) == "snakeTest-1"
    assert snake_case_to_camel("snake_test-1", True, '-') == "SnakeTest-1"

# Generated at 2022-06-24 02:18:22.891029
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # We are going to test that we can perform compress/decompress roundtrip and that output is the same as input
    original_string = 'Hello world'
    compressed_string = __StringCompressor.compress(original_string)
    decompressed_string = __StringCompressor.decompress(compressed_string)

    assert decompressed_string == original_string


# Exported public API


# Generated at 2022-06-24 02:18:26.430309
# Unit test for function roman_encode
def test_roman_encode():
    assertEqual(roman_encode(1), 'I')
    assertEqual(roman_encode(2020), 'MMXX')
    assertEqual(roman_encode(37), 'XXXVII')
    assertEqual(roman_encode(4999), 'MMMMCMXCIX')
    assertEqual(roman_encode(3920), 'MMMCMXX')
# Test cases
test_roman_encode()

# Generated at 2022-06-24 02:18:37.763628
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Encode test
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'

# Generated at 2022-06-24 02:18:45.448046
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    rn = __RomanNumbers
    assert rn.encode(123) == 'CXXIII'
    assert rn.encode(3999) == 'MMMCMXCIX'
    assert rn.decode('MMMCMXCIX') == 3999
    assert rn.decode('CXXIII') == 123


# API


# Generated at 2022-06-24 02:18:53.868595
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('abc') == 'cba'
    assert reverse('abcd') == 'dcba'
    assert reverse('abcdefghijklmnopqrstuvwxyz') == 'zyxwvutsrqponmlkjihgfedcba'



# Generated at 2022-06-24 02:19:00.240332
# Unit test for function slugify
def test_slugify():
    assert slugify('Mönstér Mägnët') == 'monster-magnet',  "Not passing test 1"
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs',"Not passing test 2"



# Generated at 2022-06-24 02:19:03.856417
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(2020) == 'MMXX'


# Generated at 2022-06-24 02:19:10.337591
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    tests = [
        ('abc', 'abc'),
        ('abc', 'abc'),
        ('abcD', 'abc_d'),
        ('abcDE', 'abc_d_e'),
        ('abcDEF', 'abc_def'),
        ('abcDEFG', 'abc_defg'),
        ('abcDEFGH', 'abc_defgh'),
        ('abcDEFGHI', 'abc_defghi'),
        ('abcDEFGHIJ', 'abc_defghij'),
        ('abcDEFGHIJK', 'abc_defghijk'),
    ]
    for sample, expected in tests:
        assert camel_case_to_snake(sample) == expected



# Generated at 2022-06-24 02:19:19.773616
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'

# Generated at 2022-06-24 02:19:27.054638
# Unit test for function strip_margin
def test_strip_margin():
    test_string = '''
                    line 1
                    line 2
                    line 3
                 '''
    expected_string = '''
line 1
line 2
line 3
'''
    # Test case 1:
    print("Test case 1:")
    output_string = strip_margin(test_string)
    assert output_string == expected_string, "Test failed."
    print("Test passed.")
    print("")
    # Test case 2:
    print("Test case 2:")
    try:
        strip_margin(1)
        print("Test failed.")
        assert False
    except InvalidInputError:
        print("Test passed.")
    print("")
