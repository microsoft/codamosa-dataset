

# Generated at 2022-06-24 02:09:22.840843
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'hello'



# Generated at 2022-06-24 02:09:27.050277
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Io sono una frase!') == 'io-sono-una-frase'



# Generated at 2022-06-24 02:09:31.440258
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)



# Generated at 2022-06-24 02:09:37.828581
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings == [{1: 'I', 5: 'V'}, {1: 'X', 5: 'L'}, {1: 'C', 5: 'D'}, {1: 'M'}]
    assert __RomanNumbers.__reversed_mappings == [{'I': 1, 'V': 5}, {'I': 1, 'X': 5, 'L': 10}, {'I': 1, 'C': 5, 'D': 10}, {'I': 1, 'M': 5}]


# Generated at 2022-06-24 02:09:41.837535
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')=='eeuuooaaeynAAACIINOE'
test_asciify()


# Generated at 2022-06-24 02:09:42.777001
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter



# Generated at 2022-06-24 02:09:44.072737
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'  # test basic usage



# Generated at 2022-06-24 02:09:55.877355
# Unit test for function prettify

# Generated at 2022-06-24 02:10:03.347622
# Unit test for function prettify
def test_prettify():
  input_string = 'Helloworld! I am pretty sure that\'s amazing! let\'s "start" the test;) so '
  output_string = 'Hello world! I am pretty sure that\'s amazing! Let\'s "start" the test;) So '
  assert output_string == prettify(input_string)



# Generated at 2022-06-24 02:10:04.427748
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '


# Generated at 2022-06-24 02:10:06.329940
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-24 02:10:17.112329
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('foo') == 'foo'
    assert strip_html('<p>foo</p>') == ''
    assert strip_html('<p>foo</p>', True) == 'foo'
    assert strip_html('<p><a href="foo/bar">click here</a></p>') == ''
    assert strip_html('<p><a href="foo/bar">click here</a></p>', True) == 'click here'
    assert strip_html('<p>foo <a href="foo/bar">click here</a></p>', True) == 'foo click here'
    assert strip_html('<script>lol</script>') == ''
    assert strip_html('<script>lol</script>', True) == 'lol'



# Generated at 2022-06-24 02:10:20.306187
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    result = camel_case_to_snake('ThisIsACamelStringTest')
    expected = 'this_is_a_camel_case_string_test'
    assert result == expected, "%s != %s" % (result, expected)



# Generated at 2022-06-24 02:10:30.038706
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Test 1: input string is not a string
    with pytest.raises(InvalidInputError):
        __StringCompressor.compress(123)

    # Test 2: input string is an empty string
    with pytest.raises(ValueError):
        __StringCompressor.compress('')

    # Test 3: encoding is not a string
    with pytest.raises(ValueError):
        __StringCompressor.compress('Hello', 123)
    
    # Test 4: input string is not a string
    with pytest.raises(InvalidInputError):
        __StringCompressor.decompress(123)

    # Test 5: input string is an empty string
    with pytest.raises(ValueError):
        __StringCompressor.decompress('')

    # Test 6: encoding is not a string
   

# Generated at 2022-06-24 02:10:35.061325
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('test').input_string == 'test'
    assert __StringFormatter(None) == InvalidInputError
    assert __StringFormatter(8) == InvalidInputError


# Generated at 2022-06-24 02:10:43.595235
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('Hello World').input_string == 'Hello World'
    try:
        __StringFormatter('')
        assert False
    except InvalidInputError:
        assert True
    try:
        __StringFormatter(1)
        assert False
    except InvalidInputError:
        assert True
    try:
        __StringFormatter(['Hello', 'World'])
        assert False
    except InvalidInputError:
        assert True
    assert type(__StringFormatter('Hello World')) == __StringFormatter



# Generated at 2022-06-24 02:10:50.736358
# Unit test for function strip_html
def test_strip_html():
    # TODO: Test function parameters
    if strip_html('test: <a href="foo/bar">click here</a>') != 'test: ':
        raise Exception('strip_html test 1 failed')
    if strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) != 'test: click here':
        raise Exception('strip_html test 2 failed')
    if strip_html('test: <a href="foo/bar">click here</a> <img src="bar/foo">', keep_tag_content=False) != 'test: ':
        raise Exception('strip_html test 3 failed')



# Generated at 2022-06-24 02:10:52.760764
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_case_string_test"


# Generated at 2022-06-24 02:10:58.104819
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)

    assert original == decompressed



# Generated at 2022-06-24 02:11:00.608104
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
    ''') == '''
        line 1
        line 2
        line 3
    '''



# Generated at 2022-06-24 02:11:08.246333
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-24 02:11:20.034243
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(12) == 'XII'
    assert roman_encode(4) == 'IV'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode('3001') == 'MMMI'
    assert roman_encode('3999') == 'MMMCMXCIX'

    # assert that an error is raised when passing an invalid value
    try:
        roman_encode('boh')
        raise Exception('Test failed: expected an error but got nothing')
    except InvalidInputError:
        pass

    try:
        roman_encode(-1)
        raise Exception('Test failed: expected an error but got nothing')
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:11:24.923746
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
        assert snake_case_to_camel("the_snake_is_green", False) == "theSnakeIsGreen"
        assert snake_case_to_camel("the_snake_is_green", True) == "TheSnakeIsGreen"
        


# Generated at 2022-06-24 02:11:33.878968
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', False) == 'thisIsATest'
    assert snake_case_to_camel('thisIsATest', True, '_') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', True, '*') == 'this_is_a_test'
    assert snake_case_to_camel('this*is*a*test', True, '*') == 'ThisIsATest'



# Generated at 2022-06-24 02:11:39.833742
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('True') == True
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('Yes') == True
    assert booleanize('yes') == True
    assert booleanize('Y') == True
    assert booleanize('y') == True
    assert booleanize('False') == False
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('No') == False
    assert booleanize('no') == False
    assert booleanize('N') == False
    assert booleanize('n') == False


# Generated at 2022-06-24 02:11:41.831820
# Unit test for function asciify
def test_asciify():
    assert 'eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')



# Generated at 2022-06-24 02:11:49.159988
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('1') == 'I'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode('2019') == 'MMXIX'
    assert roman_encode('3999') == 'MMMCMXCIX'
    assert roman_encode('0') == ''
    assert roman_encode('4000') == ''
    assert roman_encode('-1') == ''
    assert roman_encode('-37') == ''
    assert roman_encode('abcd') == ''
    assert roman_encode('True') == ''
    assert roman_encode('M') == ''
    assert roman_encode(' ') == ''

# Generated at 2022-06-24 02:11:50.783952
# Unit test for function decompress
def test_decompress():
    assert 'Hello' == decompress('eJx1TdjLUu7MtTm1MdC0pjYwNTC7VXACSLizsDA4Ki4=')

# Generated at 2022-06-24 02:11:55.429894
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:12:05.477500
# Unit test for function prettify
def test_prettify():
    test_data = [
        ('hello world', 'Hello world'),
        ('unprettified string ,, like this one,will be"prettified" .it\\\'s awesome!',
         'Unprettified string, like this one, will be "prettified". It\'s awesome!'),
        ('one+   one =   two', 'One + one = two'),
        ('surprising -  100%', 'Surprising - 100%'),
        ('ten divided by 5 is 2 (5\\\'s go into 10 twice)', 'Ten divided by 5 is 2 (5\'s go into 10 twice)'),
        ('\\nthis is\\n\\n\\nan invalid string\\n\\noh well\\n\\n', 'This is an invalid string oh well')
    ]

    for example, expected_output in test_data:
        output = prett

# Generated at 2022-06-24 02:12:10.171972
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert(booleanize('TRUE') == True)
    assert(booleanize('1') == True)
    assert(booleanize('yes') == True)
    assert(booleanize('YES') == True)
    assert(booleanize('y') == True)
    assert(booleanize('Y') == True)
    assert(booleanize('false') == False)
    assert(booleanize('FALSE') == False)
    assert(booleanize('0') == False)
    assert(booleanize('n') == False)
    assert(booleanize('N') == False)
    assert(booleanize('no') == False)
    assert(booleanize('NO') == False)
    assert(booleanize('whatever') == False)

# Generated at 2022-06-24 02:12:12.968638
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')  == True
    assert booleanize('yes')   == True
    assert booleanize('y')     == True
    assert booleanize('1')     == True
    assert booleanize('false') == False
    assert booleanize('no')    == False
    assert booleanize('N')     == False
    assert booleanize('0')     == False
    assert booleanize('t420')  == False
    assert booleanize('no')    == False
test_booleanize()



# Generated at 2022-06-24 02:12:16.432647
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'

test_slugify()

# Generated at 2022-06-24 02:12:21.437880
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:12:32.131928
# Unit test for function shuffle

# Generated at 2022-06-24 02:12:44.571724
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='#') == 'this#is#a#camel#string#test'
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('HelloWorld') == 'hello_world'
    assert camel_case_to_snake('helloWorld') == 'hello_world'
    assert camel_case_to_snake('Hello_world') == 'hello_world'
    assert camel_case_to_snake('HelloWorld', separator='##') == 'hello##world'

# Generated at 2022-06-24 02:12:46.220346
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    obj = __StringFormatter
    assert obj.__init__('test')



# Generated at 2022-06-24 02:12:48.856111
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'

# Generated at 2022-06-24 02:12:53.396617
# Unit test for function compress
def test_compress():
    """
    Small number of test among several possible cases.
    """
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(input_string)
    restored = decompress(compressed)

    assert input_string == restored



# Generated at 2022-06-24 02:13:01.633163
# Unit test for function strip_html
def test_strip_html():
    def strip(s, keep_tag_content=False, expected=None):
        if expected is None:
            expected = s

        assert strip_html(s, keep_tag_content) == expected

    strip('test: <a href="foo/bar">click here</a>', False, 'test: ')
    strip('test: <a href="foo/bar">click here</a>', True, 'test: click here')
    strip('<html><body>Hello world</body></html>', False, '')
    strip('<html><body>Hello world</body></html>', True, 'Hello world')



# Generated at 2022-06-24 02:13:07.156158
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify(' ék   ár  ') == 'ek-ar'
    assert slugify('My åwësome string!') == 'my-awesome-string'
    assert slugify('Lorem ipsum dolor sit amet') == 'lorem-ipsum-dolor-sit-amet'

test_slugify()



# Generated at 2022-06-24 02:13:12.978324
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse('ciao') == 'oaic'
    assert reverse('hello world') == 'dlrow olleh'



# Generated at 2022-06-24 02:13:23.588503
# Unit test for function decompress
def test_decompress():
    # Arrange
    compressed = 'H4sIAAAAAAAAA62TbW/cOhDE71Nt+z2HvjEZCma8OeOIp0T55TTrgjycWtLTRI1Hhdxe51QvNKZiJW8' \
                 'ykVZlxLx24jE8JCFD0nd7LoGngpZfE7n8PX9YnGmJcCuUMU5zVU2mDhPzVw5ZoHMg/N8bXHlN7lQ2' \
                 'G/1ce4HfhLq/9PTDRnsS7SJ6kzZbERkZq3hqb4f4+OaFgEAAIAAAA='

# Generated at 2022-06-24 02:13:31.434589
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify(u'èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'


    

# Generated at 2022-06-24 02:13:33.618218
# Unit test for function roman_encode
def test_roman_encode():
  return roman_encode(37) == 'XXXVIII'



# Generated at 2022-06-24 02:13:36.082407
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed==original

# Generated at 2022-06-24 02:13:41.335093
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original,'utf-8',0)
    assert isinstance(compressed,str)


# Generated at 2022-06-24 02:13:49.049443
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == 'eeuuooaaeynAAACIINOE'
    assert asciify("This is a test") == 'This is a test'
    assert asciify("こんにちは") == 'こんにちは'
    assert asciify("This is a test こんにちは") == 'This is a test こんにちは'
    assert asciify("你好") == '你好'

# Generated at 2022-06-24 02:14:00.321933
# Unit test for function prettify
def test_prettify():
    import unittest

    class TestPrettify(unittest.TestCase):

        def setUp(self):
            self.input_string = \
                '   unprettified string ,, like this one,will be"prettified" .it\\' \
                ' s awesome! '

        def test_prettify(self):
            # first test to check that function exists
            global prettify
            self.assertTrue(is_function(prettify))
            try:
                prettify(self.input_string)
            except InvalidInputError:
                self.fail('prettify method should accept a string as parameter')


# Generated at 2022-06-24 02:14:06.899057
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    try:
        __StringFormatter('').format()
        assert False, 'Empty string was not rejected'
    except:
        pass

    try:
        __StringFormatter(123).format()
        assert False, 'non string input was not rejected'
    except:
        pass

    s = __StringFormatter("    \t\n\t  hey  man  !  \n\n\t  how is  it   going?  \t\tok?  \r\r\n  \r\r\r  ")
    assert s.format() == 'Hey man! How is it going? Ok?'


# Generated at 2022-06-24 02:14:09.513219
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
        line 1
        line 2
        line 3
        line 4
        '''
    assert strip_margin(s) == '''
line 1
line 2
line 3
line 4
'''


# Generated at 2022-06-24 02:14:13.488771
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    required_output = 'Hello World'
    string_formatter = __StringFormatter(' hello   world ')
    actual_output = string_formatter.format()

    assert actual_output == required_output, 'Output mismatch: required: {}, actual: {}'.format(
        required_output,
        actual_output
    )

# Generated at 2022-06-24 02:14:14.689322
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:14:25.981178
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter(input_string=0)
        assert False
    except InvalidInputError:
        pass

    expected = 'I am'
    actual = __StringFormatter(input_string='i am').input_string
    assert expected == actual
    expected = 'I am'
    actual = __StringFormatter(input_string=' I am ').input_string
    assert expected == actual
    expected = 'I am'
    actual = __StringFormatter(input_string=' I     am ').input_string
    assert expected == actual
    expected = 'I am'
    actual = __StringFormatter(input_string=' I ---    am ').input_string
    assert expected == actual
    expected = 'I am'
    actual = __StringFormatter(input_string=' I ---    am |||').input_string

# Generated at 2022-06-24 02:14:34.900588
# Unit test for function prettify

# Generated at 2022-06-24 02:14:36.900057
# Unit test for function decompress
def test_decompress():
    original = "test"
    compressed = compress(original)
    assert original == decompress(compressed)
    assert is_empty(decompress("")) == True


# Generated at 2022-06-24 02:14:40.434278
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!')=='top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët')=='monster-magnet'
if __name__ == '__main__':
    test_slugify()
    print("Unit test for function slugify: success")

# Generated at 2022-06-24 02:14:44.400718
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                        ''') == '''
    line 1
    line 2
    line 3
    '''



# Generated at 2022-06-24 02:14:47.683070
# Unit test for function asciify
def test_asciify():
    assert asciify('òàéèù') == 'oeue'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:14:58.332628
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelString') == 'this_is_a_camel_string'
    assert camel_case_to_snake('thisIsACamelString') == 'this_is_a_camel_string'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisisacamelstringtest') == 'thisisacamelstringtest'
    assert camel_case_to_snake('ThisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:15:00.757759
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:15:05.511225
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert isinstance(__StringFormatter("Hello World"), __StringFormatter)
    assert isinstance(__StringFormatter("Hello World"), str)
    assert __StringFormatter("Hello World").format() == __StringFormatter("Hello World").format()
    

# Generated at 2022-06-24 02:15:16.405024
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('a b C d a').format() == 'A B C D a'

# Generated at 2022-06-24 02:15:23.342244
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'

    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode(13) == 'XIII'


# Generated at 2022-06-24 02:15:26.560126
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('k')==False

# Generated at 2022-06-24 02:15:34.659548
# Unit test for function slugify
def test_slugify():
    assert slugify('- : Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('2012年12月京都市役所') == '201212yue-jing-du-shi-yue-shu'
    assert slugify('ab\t cd') == 'ab-cd'
    assert slugify('123^&*()!_') == '123'
    assert slugify('           ') == ''

test_slugify()

# Generated at 2022-06-24 02:15:38.561861
# Unit test for function compress
def test_compress():
    assert compress('some_string') != 'some_string'
    assert len(compress('some_string')) < len('some_string')
    assert compress(compress('some_string')) == compress('some_string')
    assert is_string(compress('some_string'))
    assert is_base64(compress('some_string'))
    assert compress('') == ''
    assert compress(None) is None
    assert compress('') == ''



# Generated at 2022-06-24 02:15:40.504462
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert decompressed == original

# Generated at 2022-06-24 02:15:52.078394
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .random import random_string
    from .time import Timer

    random_str = random_string()

    with Timer() as t:
        compressed_str = __StringCompressor.compress(random_str)

    print('Compression took %.03f sec.' % t.interval)

    print('Compression rate: %.01f%%' % (len(compressed_str) / len(random_str) * 100))

    with Timer() as t:
        decompressed_str = __StringCompressor.decompress(compressed_str)
        assert decompressed_str == random_str

    print('Decompression took %.03f sec.' % t.interval)

# END Unit test for constructor of class __StringCompressor


# PUBLIC API



# Generated at 2022-06-24 02:15:53.675450
# Unit test for function slugify
def test_slugify():
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Generated at 2022-06-24 02:15:57.305031
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('foo bar') == 'eJxLyc5JzEwMTAwMDByVAgA'
    assert __StringCompressor.decompress('eJxLyc5JzEwMTAwMDByVAgA') == 'foo bar'

test___StringCompressor()



# Generated at 2022-06-24 02:16:05.617719
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('abcdefghilmnopqrstuvz') == 'eJwLTE1PgADS8pJzc1M_PTMx'
    assert __StringCompressor.decompress('eJwLTE1PgADS8pJzc1M_PTMx') == 'abcdefghilmnopqrstuvz'


# PUBLIC API



# Generated at 2022-06-24 02:16:07.158326
# Unit test for function prettify

# Generated at 2022-06-24 02:16:14.109950
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify(' ') == ''
    assert slugify(' !@#^*&$ ') == ''
    assert slugify('hello') == 'hello'
    assert slugify(' hello ') == 'hello'
    assert slugify(' hello !! ') == 'hello'
    assert slugify('hello world') == 'hello-world'
    assert slugify('hello world!!!') == 'hello-world'
    assert slugify('hello!!world') == 'hello-world'
    assert slugify('hello world!!! foo bar!') == 'hello-world-foo-bar'
    assert slugify('hello world!!! foo bar!', '+') == 'hello+world+foo+bar'
    assert slugify('hello world!!! foo bar!', '-') == 'hello-world-foo-bar'

# Generated at 2022-06-24 02:16:21.159476
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    text = "Hello, World!"
    compressed = __StringCompressor.compress(text)
    assert compressed == "eJyrVkpKLc1JzUvKjEtLtyvJT8xL1Uq1BQjKVc5JzEvOTUwJyU3LVYq1KpVLzgvNSosLxtUVCiXAAA="
    decompressed = __StringCompressor.decompress(compressed)
    assert decompressed == text


# PUBLIC API


RomanNumbers = __RomanNumbers


StringCompressor = __StringCompressor



# Generated at 2022-06-24 02:16:33.856121
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I', '1'
    assert roman_encode(2) == 'II', '2'
    assert roman_encode(3) == 'III', '3'
    assert roman_encode(4) == 'IV', '4'
    assert roman_encode(5) == 'V', '5'
    assert roman_encode(6) == 'VI', '6'
    assert roman_encode(7) == 'VII', '7'
    assert roman_encode(8) == 'VIII', '8'
    assert roman_encode(9) == 'IX', '9'
    assert roman_encode(10) == 'X', '10'
    assert roman_encode(11) == 'XI', '11'

# Generated at 2022-06-24 02:16:38.208097
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        |line 1
                        |line 2
                        |line 3
                        ''').strip() == '''
                        line 1
                        line 2
                        line 3
                        '''.strip()
    assert strip_margin('''
                         line 1
                         line 2
                         line 3
                         ''').strip() == '''
                         line 1
                         line 2
                         line 3
                         '''.strip()


# Generated at 2022-06-24 02:16:51.003878
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |                line 1
        |                line 2
        |                line 3
        ''') == '''line 1
line 2
line 3
'''
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
        ''') == '''line 1
line 2
line 3
'''
    assert strip_margin('''
        |                line 1
        |                line 2
        |                line 3
        ''') == '''line 1
line 2
line 3
'''
    assert strip_margin('''
        |                line 1
        |                line 2
        |                line 3
        ''') == '''line 1
line 2
line 3
'''

# Generated at 2022-06-24 02:17:01.185797
# Unit test for function strip_html
def test_strip_html():
    # Asserts
    
    # Asserts that 'test: <a href="foo/bar">click here</a>' stripped equals to 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    
    # Asserts that 'test: <a href="foo/bar">click here</a>' stripped with keep_tag_content=True equals to 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:17:11.882678
# Unit test for function prettify

# Generated at 2022-06-24 02:17:14.257685
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test", "Should return 'this_is_a_camel_string_test'"
test_camel_case_to_snake()



# Generated at 2022-06-24 02:17:21.085812
# Unit test for function decompress
def test_decompress():
    import string
    import random
    string_size = 30000
    random_string = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(string_size)])
    compressed = compress(random_string)
    decompressed = decompress(compressed)
    assert random_string == decompressed



# Generated at 2022-06-24 02:17:25.281758
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: foo<br /><br>bar') == 'test: foobar'
    assert strip_html('test: foo<br /><br>bar', keep_tag_content=True) == 'test: foo<br /><br>bar'
    assert strip_html('') == ''
    assert strip_html(None) == ''



# Generated at 2022-06-24 02:17:34.012458
# Unit test for function prettify

# Generated at 2022-06-24 02:17:38.309653
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('!@#$%^&*()') == ')(*&^%$#@!'
    assert reverse('12345') == '54321'



# Generated at 2022-06-24 02:17:45.483495
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñ') == 'eeuuooaaeyn'
    assert asciify('ÅÀÁÇÌÍÑÓË') == 'AAACIINOE'
    assert asciify('láòúê') == 'laoe'
    assert asciify('hello') == 'hello'
    assert asciify('hello ') == 'hello'



# Generated at 2022-06-24 02:17:57.853417
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('a') == 'A'
    assert snake_case_to_camel('A') == 'A'
    assert snake_case_to_camel('a_b') == 'AB'
    assert snake_case_to_camel('a_b_c') == 'ABC'
    assert snake_case_to_camel('A_B_C') == 'ABC'
    assert snake_case_to_camel('A_b_c') == 'Abc'
    assert snake_case_to_camel('a_B_C') == 'ABc'
    assert snake_case_to_camel('a_B', upper_case_first=False) == 'aB'

# Generated at 2022-06-24 02:18:03.382548
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                            line 1
                            line 2
                            line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:18:10.909479
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert(camel_case_to_snake('') == '')
    assert(camel_case_to_snake('camel') == 'camel')
    assert(camel_case_to_snake('camelCase') == 'camel_case')
    assert(camel_case_to_snake('CamelCase') == 'camel_case')
    assert(camel_case_to_snake('camelCaseString') == 'camel_case_string')
    assert(camel_case_to_snake('CamelCaseString') == 'camel_case_string')
    assert(camel_case_to_snake('camelCase*String') == 'camel_case*_string')

# Generated at 2022-06-24 02:18:15.837080
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yeS') == True
    assert booleanize('no') == False
    assert booleanize('whatever') == False



# Generated at 2022-06-24 02:18:20.501517
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("I") == 1
    assert roman_decode("X") == 10
    assert roman_decode("V") == 5

# Generated at 2022-06-24 02:18:23.839508
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('    line 1\n'
                        '    line 2\n'
                        '    line 3\n') == 'line 1\nline 2\nline 3\n'
    assert strip_margin('    line 1\n'
                        '\tline 2\t\n'
                        '    line 3\n') == 'line 1\nline 2\nline 3\n'



# Generated at 2022-06-24 02:18:30.673499
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert compressed == 'eJyFMePzEI/MbD8xBxCZKiImJlwuFhYWF6U='

test_compress()



# Generated at 2022-06-24 02:18:34.005576
# Unit test for function asciify
def test_asciify():
    # èéùúòóäåëýñÅÀÁÇÌÍÑÓË
    original_string = 'eeuuooaaeynAAACIINOE'
    assert asciify(original_string) == original_string



# Generated at 2022-06-24 02:18:41.915976
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __RomanNumbers.encode(500) == 'D'

# Generated at 2022-06-24 02:18:45.612760
# Unit test for function decompress
def test_decompress():
    original = 'word n{}'
    n = 20
    original = ' '.join([original.format(i) for i in range(n)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    print("Original string: " + original)
    print("Compressed string: " + compressed)
    print("Decompressed string: " + decompressed)

test_decompress()

# Generated at 2022-06-24 02:18:48.657584
# Unit test for function asciify
def test_asciify():
    assert 'eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')


# Generated at 2022-06-24 02:18:52.504555
# Unit test for function decompress
def test_decompress():
    import random, string
    input_string = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(random.randint(1, 100)))
    assert input_string == decompress(compress(input_string))
    print('tests for function decompress passed.')

test_decompress()


# Generated at 2022-06-24 02:18:56.371476
# Unit test for function shuffle
def test_shuffle():
    import random
    import string

    alpha_num = string.ascii_lowercase + string.digits

    for i in range(20):
        # fill list with random chars
        test_array = []
        for i in range(20):
            test_array.append(random.choice(alpha_num))

        input_string = ''.join(test_array)

        # compute shuffled string
        shuffled_string = shuffle(input_string)

        # all chars must be found, but not necessarily in the same order
        for char in alpha_num:
            assert char in shuffled_string, 'char "{}" is missing'.format(char)



# Generated at 2022-06-24 02:19:07.615765
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    def check_format(input_string: str, expected_result: str):
        assert __StringFormatter(input_string).format() == expected_result

    # basic strings
    check_format('', '')
    check_format('      ', '')
    check_format('abc', 'abc')
    check_format('abc ', 'abc')
    check_format(' abc', 'abc')
    check_format(' abc       ', 'abc')
    check_format('   abc   ', 'abc')
    check_format('   abc  def  ghi  ', 'abc def ghi')
    check_format(' a  b  c  d  e  f  ', 'a b c d e f')

    # uppercase rule
    check_format(' abc', 'Abc')

# Generated at 2022-06-24 02:19:11.868382
# Unit test for function prettify
def test_prettify():
    test_string = "this function is sooo useful!!without it we\\'d be forced to write\\'code that is unreadable\\'"
    print(prettify(test_string))

test_prettify()

# End of unit test


# Generated at 2022-06-24 02:19:20.242909
# Unit test for function compress