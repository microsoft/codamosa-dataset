

# Generated at 2022-06-24 02:09:22.434956
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
        '''.strip()) == '''
        line 1
        line 2
        line 3
        '''.strip()



# Generated at 2022-06-24 02:09:28.818838
# Unit test for function compress
def test_compress():
    print("test compress")
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print("Original ", len(original), original)
    print("Compressed ", len(compressed), compressed)



# Generated at 2022-06-24 02:09:37.080541
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') is True
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('TRUE') is True
    assert booleanize('1') == True
    assert booleanize('1') is True
    assert booleanize('yes') is True
    assert booleanize('YES') is True
    assert booleanize('y') is True
    assert booleanize('Y') is True
    assert booleanize('0') is False
    assert booleanize('no') is False
    assert booleanize('n') is False
    assert booleanize('NOPE') is False
    assert booleanize('NO') is False
    assert booleanize('NOPE') is False
    assert booleanize('fasle') is False
    assert booleanize('False') is False
    assert booleanize('FALSE') is False

# Generated at 2022-06-24 02:09:39.276107
# Unit test for function prettify

# Generated at 2022-06-24 02:09:43.141594
# Unit test for function strip_html
def test_strip_html():
    # Remove HTML and return content
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    # Remove HTML and return content
    assert strip_html('test: <a href="foo/bar">click here</a>', True) == 'test: click here'



# Generated at 2022-06-24 02:09:45.490162
# Unit test for function prettify
def test_prettify():
    pfunc = prettify
    assert pfunc(' foo (bar) baz ') == 'Foo (bar) baz'
    assert pfunc(' foo (bar "baz") ') == 'Foo (bar "baz")'



# Generated at 2022-06-24 02:09:47.796811
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert_that(__StringFormatter('s'), is_(instance_of(__StringFormatter)))



# Generated at 2022-06-24 02:09:49.093897
# Unit test for function compress
def test_compress():
    assert compress('') == ''



# Generated at 2022-06-24 02:09:53.637816
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                 line 1
                 line 2
                 line 3
    ''') == '''
line 1
line 2
line 3
    '''

# Generated at 2022-06-24 02:09:58.115276
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # test forward conversion
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'


# Generated at 2022-06-24 02:10:00.875723
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-24 02:10:06.561056
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<a href="foo/bar">click here</a>') == ''
    assert strip_html('<a href="foo/bar">click here</a>', keep_tag_content=True) == 'click here'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a href="foo/bar" style="border: none;">link</a>') == ''
    assert strip_html('<a href="foo/bar" style="border: none;">link</a>', keep_tag_content=True) == 'link'

# Generated at 2022-06-24 02:10:13.323187
# Unit test for function roman_decode
def test_roman_decode():
    """Unit test for function roman_decode"""
    assert roman_decode('CXXXVII') == 137
    assert roman_decode('XVII') == 17
    assert roman_decode('VI') == 6


# Generated at 2022-06-24 02:10:19.072339
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():  # pragma: no cover
    original_string = 'aaaaaaaaaaaaaaaa'
    compressed_string = __StringCompressor.compress(original_string)
    decompressed_string = __StringCompressor.decompress(compressed_string)
    return original_string == decompressed_string

# PUBLIC API



# Generated at 2022-06-24 02:10:20.817384
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:10:30.525353
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('word with some  spaces   inside').format() == 'word with some spaces inside'
    assert __StringFormatter('word  with  some  spaces   inside').format() == 'word with some spaces inside'
    assert __StringFormatter('word with some  spaces   inside  ').format() == 'word with some spaces inside'
    assert __StringFormatter('word with some 300 spaces   inside  ').format() == 'word with some 300 spaces inside'
    assert __StringFormatter('word with some 300 spaces   inside  .').format() == 'word with some 300 spaces inside.'
    assert __StringFormatter('word with some 300 spaces   inside  ,').format() == 'word with some 300 spaces inside,'
    assert __StringFormatter('word with some 300 spaces   inside  ?').format() == 'word with some 300 spaces inside?'
   

# Generated at 2022-06-24 02:10:34.502481
# Unit test for function compress
def test_compress():
    assert compress('') == ''
    assert compress(' ') == ' '
    assert compress('a') == 'a'
    assert compress('ab') == 'ab'
    assert compress('a ') == 'a '
    assert compress(' a') == ' a'
    assert compress('a b') == 'a b'
    assert compress(' a ') == ' a '
    assert compress('a  b') == 'a  b'
    assert compress('a b ') == 'a b '
    assert compress(' a b') == ' a b'
    assert compress(' a b ') == ' a b '
    assert compress(' a  b') == ' a  b'
    assert compress('a  b ') == 'a  b '
    assert compress(' a  b ') == ' a  b '

# Generated at 2022-06-24 02:10:41.251756
# Unit test for function asciify
def test_asciify():
    assert(asciify('Hello') == 'Hello')
    assert(asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE')
    assert(asciify('') == '')



# Generated at 2022-06-24 02:10:50.318540
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'the_snake_is_green'
    result = snake_case_to_camel(input_string)
    assert result == 'TheSnakeIsGreen'
    result = snake_case_to_camel(input_string, upper_case_first=False)
    assert result == 'theSnakeIsGreen'
    input_string = 'this_is_not_a_snake_string'
    result = snake_case_to_camel(input_string, separator=' ')
    assert result == input_string
    input_string = 'this_is_a_snake_string'
    result = snake_case_to_camel(input_string, separator=' ')
    assert result == 'ThisIsASnakeString'



# Generated at 2022-06-24 02:11:00.800315
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # 1/4 - replaces excessive spaces with just one space
    input_str = '    a    b    '
    expected = 'a b'
    actual = __StringFormatter(input_str).format()
    assert actual == expected

    # 2/4 - ensure the first char is uppercase
    input_str = 'my string'
    expected = 'My string'
    actual = __StringFormatter(input_str).format()
    assert actual == expected

    # 3/4 - ensure one space before and after each sign
    input_str = 'my string, a string'
    expected = 'My string, a string'
    actual = __StringFormatter(input_str).format()
    assert actual == expected

    # 4/4 - ensure one space before and after each sign
    input_str = 'my string, a string'
   

# Generated at 2022-06-24 02:11:06.480736
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''



# Generated at 2022-06-24 02:11:11.580302
# Unit test for function slugify
def test_slugify():
    # Results from http://slugify.net/
    assert slugify('') == ''
    assert slugify('top 10 reasons to love dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('"hello world": the title') == 'hello-world-the-title'
    assert slugify('\"hello world\": the title') == 'hello-world-the-title'
    assert slugify('\"hello world\': the title') == 'hello-world-the-title'
    assert slugify('\"hello world!"') == 'hello-world'

# Generated at 2022-06-24 02:11:24.541527
# Unit test for function strip_html
def test_strip_html():
    assert(strip_html("This is a <b>string</b> with a <a href='foo'>link</a> in it") == "This is a string with a  in it")
    assert(strip_html("This is a <b>string</b> with a <a href='foo'>link</a> in it", True) == "This is a string with a link in it")
    assert(strip_html("This is a <b>string</b>") == "This is a ")
    assert(strip_html("This is a <b>string</b>", True) == "This is a string")
    assert(strip_html("This is a <b>string", True) == "This is a ")
    assert(strip_html("This is a <b>string") == "This is a ")

# Generated at 2022-06-24 02:11:28.416936
# Unit test for function reverse
def test_reverse():
    assert('olleh' == reverse('hello'))
    assert('1234' == reverse('4321'))



# Generated at 2022-06-24 02:11:38.897981
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(18) == 'XVIII'
    assert __RomanNumbers.encode(19) == 'XIX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(41) == 'XLI'
    assert __RomanNumbers.encode(47) == 'XLVII'
    assert __RomanNumbers.encode(49) == 'XLIX'

# Generated at 2022-06-24 02:11:48.896349
# Unit test for function decompress
def test_decompress():
    """
    Test function 'decompress'.
    """

# Generated at 2022-06-24 02:11:57.130128
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('A B C D E F').input_string == 'A B C D E F'
    try:
        assert __StringFormatter('')
    except Exception as E:
        assert isinstance(E, InvalidInputError)
    try:
        assert __StringFormatter(None)
    except Exception as E:
        assert isinstance(E, InvalidInputError)
    try:
        assert __StringFormatter(123)
    except Exception as E:
        assert isinstance(E, InvalidInputError)


# Generated at 2022-06-24 02:11:58.497786
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'



# Generated at 2022-06-24 02:12:03.502475
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()


# Generated at 2022-06-24 02:12:13.762660
# Unit test for function prettify
def test_prettify():
    test_input_string_1 = '$100%  0.95 , of the children\'  s  teddy   bears  have  been sold<br>\n' \
                          ' $100%  0.95, of the children\' s teddy bears have been sold'
    test_output_string_1 = '$100% 0.95, of the children\'s teddy bears have been sold'
    assert (prettify(test_input_string_1) == test_output_string_1)

    test_input_string_2 = ' $100%  0.95 , of the children\'  s  teddy   bears  have  been sold<br>\n' \
                          '<b> $100%  0.95, of the children\' s teddy bears have been sold</b>'
    test_output_string

# Generated at 2022-06-24 02:12:18.829979
# Unit test for function strip_html
def test_strip_html():
    print(strip_html('test: <a href="foo/bar">click here</a>'))
    print(strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True))

# Generated at 2022-06-24 02:12:26.324889
# Unit test for function reverse
def test_reverse():
    output = reverse('hello')
    assert output == 'olleh'
    output = reverse('Goodbye!')
    assert output == '!eybdooG'
    output = reverse('1!7ë')
    assert output == 'ë7!1'
    output = reverse('$@1')
    assert output == '1@$'



# Generated at 2022-06-24 02:12:37.193451
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Test decode()
    # Test a simple 1 (I)
    assert __RomanNumbers.decode('I') == 1
    # Test a simple 5 (V)
    assert __RomanNumbers.decode('V') == 5
    # Test a simple 10 (X)
    assert __RomanNumbers.decode('X') == 10
    # Test a simple 50 (L)
    assert __RomanNumbers.decode('L') == 50
    # Test a simple 100 (C)
    assert __RomanNumbers.decode('C') == 100
    # Test a simple 500 (D)
    assert __RomanNumbers.decode('D') == 500
    # Test a simple 1000 (M)
    assert __RomanNumbers.decode('M') == 1000
    # Test 4 (IV)
    assert __RomanNumbers.decode('IV') == 4
    # Test

# Generated at 2022-06-24 02:12:41.050786
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Invalid input parameter
    try:
        __StringFormatter(1)

    except InvalidInputError:
        pass

    else:
        raise AssertionError('InvalidInputError not raised')



# Generated at 2022-06-24 02:12:45.183388
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') is True, 'booleanize() failed for "true"'
    assert booleanize('YES') is True, 'booleanize() failed for "YES"'
    assert booleanize('nope') is False, 'booleanize() failed for "nope"'


# Generated at 2022-06-24 02:12:55.854568
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert is_string(__StringCompressor.compress('a'))
    assert is_string(__StringCompressor.compress('', 'utf-8'))
    assert is_string(__StringCompressor.compress('', 'utf-8', 9))
    assert is_string(__StringCompressor.decompress('a', 'utf-8'))
    assert __StringCompressor.decompress('a', 'utf-8') == 'a'
    assert __StringCompressor.decompress(__StringCompressor.compress('a', 'utf-8')) == 'a'

test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:13:04.011025
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MMXX') == 2020
    assert roman_decode('IV') == 4
    assert roman_decode('IX') == 9
    assert roman_decode('CXLVIII') == 148
    assert roman_decode('MCCCLXXXIV') == 1384
    assert roman_decode('XVII') == 17


if __name__ == '__main__':
    test_roman_decode()

# Generated at 2022-06-24 02:13:06.906780
# Unit test for function shuffle
def test_shuffle():
    input = 'hello world'
    output = shuffle(input)
    assert len(output) == len(input), 'Shuffled string have wrong length'
    assert output != input, 'Shuffled string is identical to the input'



# Generated at 2022-06-24 02:13:08.892419
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:13:13.150377
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('one_last_test') == 'OneLastTest'
    assert snake_case_to_camel('thisismytest') == 'Thisismytest'
    assert snake_case_to_camel('another_wrong_test', upper_case_first=False) == 'another_wrong_test'
    assert snake_case_to_camel('one_more', separator='-') == 'OneMore'



# Generated at 2022-06-24 02:13:23.131357
# Unit test for function prettify
def test_prettify():
    input_strings = ['  strip   ', ' strip leading spaces  ', 'strip trailing spaces   ', ' strip both sides  ',
                     'strip  multiple spaces', 'strip empty line\\n\\n', 'strip multiple dots..',
                     'leading spaces must be stripped "if any":', 'trailing spaces must be stripped: "if any"  ',
                     'spaces before  and  after  double quotes  "  must be only one  "', 'spaces before  and  after'
                                                                                          '  round brackets (  must be only one (',
                     'no space before  % ', 'saxon genitive is correct "Dave\'s dog" ']


# Generated at 2022-06-24 02:13:25.237461
# Unit test for function roman_encode
def test_roman_encode():
    print(roman_encode(37))

test_roman_encode()


# Generated at 2022-06-24 02:13:29.740344
# Unit test for function decompress

# Generated at 2022-06-24 02:13:31.905753
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('1') == '1'
    assert reverse('12') == '21'
    assert reverse('123') == '321'
    assert reverse('1234') == '4321'
    assert reverse('12345') == '54321'



# Generated at 2022-06-24 02:13:36.314373
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    if compressed.__len__() != 88:
        raise ValueError



# Generated at 2022-06-24 02:13:39.583417
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    b = __StringCompressor()
    return b


# PUBLIC API



# Generated at 2022-06-24 02:13:43.149582
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('abc') == 'cba'
    assert reverse('abcd') == 'dcba'
    assert reverse('abcde') == 'edcba'



# Generated at 2022-06-24 02:13:46.906474
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(1000) == 'M'
    assert roman_encode(3999) == 'MMMCMXCIX'
    
test_roman_encode()

# Generated at 2022-06-24 02:13:53.312598
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode('2') == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode('8') == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(12) == 'XII'
    assert roman_encode('13') == 'XIII'


# Generated at 2022-06-24 02:13:55.453312
# Unit test for function strip_margin
def test_strip_margin():
    assert_equal(strip_margin('''
                               line 1
                               line 2
                               line 3
                               '''),
                 '''
                 line 1
                 line 2
                 line 3
                 ''')


# Generated at 2022-06-24 02:14:01.188333
# Unit test for function strip_margin
def test_strip_margin():
    result = strip_margin("""
                           |line 1
                           |line 2
                           |line 3""")
    assert result == "line 1\nline 2\nline 3"

# Generated at 2022-06-24 02:14:06.336274
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:14:07.574255
# Unit test for function compress
def test_compress():
    # TODO: Add test
    assert True



# Generated at 2022-06-24 02:14:09.970628
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:14:13.026532
# Unit test for function booleanize
def test_booleanize():
    print(booleanize('true')) # returns True
    print(booleanize('YES')) # returns True
    print(booleanize('nope')) # returns False

test_booleanize()


# Generated at 2022-06-24 02:14:13.556609
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('')



# Generated at 2022-06-24 02:14:18.679165
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('this?is a    test!     yeah!it works.').format() == 'This is a test! Yea!it works.'



# Generated at 2022-06-24 02:14:22.033650
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        |line 1
                        |line 2
                        |line 3
                        |''') == '''
                        line 1
                        line 2
                        line 3
                        '''



# Generated at 2022-06-24 02:14:27.628636
# Unit test for function strip_margin
def test_strip_margin():
    s = '  abc  \n cde \n  \n fff'
    new_s = strip_margin(s)

    assert(new_s == 'abc\ncde\n\nfff')
    if new_s != 'abc\ncde\n\nfff':
        print('ERROR: strip_margin(s) =', new_s, ' instead of "abc\\\\ncde\\\\n\\\\nfff"')
# Test call
test_strip_margin()



# Generated at 2022-06-24 02:14:37.454552
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('V')  == 5
    assert roman_decode('VII') == 7
    assert roman_decode('XII') == 12
    assert roman_decode('XIV') == 14
    assert roman_decode('XIX') == 19
    assert roman_decode('XXII') == 22
    assert roman_decode('XXV') == 25
    assert roman_decode('XXIX') == 29
    assert roman_decode('XXX') == 30
    assert roman_decode('XXXV') == 35
    assert roman_decode('XXXVII') == 37
    assert roman_decode('XXXIX') == 39
    assert roman_decode('XL') == 40
    assert roman_decode('XLIV') == 44
    assert roman_dec

# Generated at 2022-06-24 02:14:42.778197
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)


# Generated at 2022-06-24 02:14:49.668637
# Unit test for function decompress
def test_decompress():
    return __StringCompressor.decompress("eNrzSM3JyVcIzM/NTU1KQQDUycgUy81JUHmOWY5BzFkZmI5ZjU3BgCgSA==","utf-8")


# Generated at 2022-06-24 02:14:52.784388
# Unit test for function reverse
def test_reverse(): assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:14:55.608119
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:15:03.288186
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('NO') == False
    assert booleanize('n') == False
    assert booleanize('N') == False
    assert booleanize('nope') == False
    assert booleanize(' Nope  ') == False
test_booleanize()


# Generated at 2022-06-24 02:15:06.155725
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert len(shuffle('hello world')) == 11
    assert list(set(shuffle('hello world'))) == list(set('hello world'))



# Generated at 2022-06-24 02:15:16.479426
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert(snake_case_to_camel('snake_case', "\_") == 'SnakeCase')
    assert(snake_case_to_camel('snake_case', "\_", upper_case_first=False) == 'snakeCase')
    assert(snake_case_to_camel('a', "\_") == 'A')
    assert(snake_case_to_camel('a', "\_", upper_case_first=False) == 'a')
    assert(snake_case_to_camel('this_is_a_snake_case', "\_") == 'ThisIsASnakeCase')
    assert(snake_case_to_camel('this_is_a_snake_case', "\_", upper_case_first=False) == 'thisIsASnakeCase')


# Generated at 2022-06-24 02:15:19.891608
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('abc') == 'cba'
    assert reverse('1a2b3c') == 'c3b2a1'
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:15:30.310205
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('True') == True
    assert booleanize('No') == False
    assert booleanize('YES') == True
    assert booleanize('yEs') == True
    assert booleanize(None) == False
    assert booleanize('') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('Yes') == True
    assert booleanize('No') == False
    assert booleanize('Y') == True
    assert booleanize('N') == False

# Generated at 2022-06-24 02:15:41.568297
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world!').format() == 'Hello world!'
    assert __StringFormatter('hello World!). How are you doing?').format() == 'Hello world! How are you doing?'
    assert __StringFormatter('This is a test for UPPERCASEFIRSTLETTER rule.').format() == \
           'This is a test for Uppercasefirstletter rule.'
    assert __StringFormatter('This is a test for :DUPLICATES rule.').format() == 'This is a test for :duplicates rule.'
    assert __StringFormatter('This is a test for SPACESAROUND rule.').format() == 'This is a test for spacesaround rule.'
    assert __StringFormatter('This is a test for SPACESINSIDE rule.').format() == 'This is a test for spacesinside rule.'
    assert __String

# Generated at 2022-06-24 02:15:51.727914
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(10) == 'X'
    assert roman_encode(100) == 'C'
    assert roman_encode(1000) == 'M'

    assert roman_encode(3) == 'III'
    assert roman_encode(17) == 'XVII'
    assert roman_encode(106) == 'CVI'
    assert roman_encode(1001) == 'MI'

    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(9) == 'IX'
    assert roman_encode(99) == 'XCIX'

    assert roman_encode(40) == 'XL'


# Generated at 2022-06-24 02:15:56.665850
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter("").input_string == ""
    assert __StringFormatter("  ").input_string == "  "
    assert __StringFormatter("a").input_string == "a"
    assert __StringFormatter("hello world").input_string == "hello world"

    try:
        __StringFormatter(0)
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 02:15:59.524060
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # if this test raises an error, something is wrong in the code of the method
    input_string = 'this is a test!!$%&/()=?^_<it works>'
    expected_output = 'This is a test'
    assert __StringFormatter(input_string).format() == expected_output



# Generated at 2022-06-24 02:16:09.983628
# Unit test for function shuffle
def test_shuffle():
    for i in range(1000):
        # ensure that every time we call the function with the same string we obtain a different output
        random_shuffle1 = shuffle('hello')
        random_shuffle2 = shuffle('hello')

        assert random_shuffle1 != random_shuffle2

        # ensure that for every shuffled string we have 5 'h', 1 'e', 2 'l' and 2 'o'
        char_count_map = Counter(random_shuffle1)

        assert char_count_map['h'] == 5
        assert char_count_map['e'] == 1
        assert char_count_map['l'] == 2
        assert char_count_map['o'] == 2

    # ensure that the function raise the right error when we provide
    # a non string input

# Generated at 2022-06-24 02:16:12.291282
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''


# Generated at 2022-06-24 02:16:17.291997
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsNotACamelString') == 'this_is_not_a_camel_string'


# Generated at 2022-06-24 02:16:19.286466
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello').input_string == 'hello'



# Generated at 2022-06-24 02:16:21.960081
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:16:23.875953
# Unit test for function shuffle
def test_shuffle():
    test_string = 'this is a test string'
    assert shuffle(test_string) != test_string



# Generated at 2022-06-24 02:16:25.654448
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == shuffle('hello')



# Generated at 2022-06-24 02:16:27.446217
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == 'hello'



# Generated at 2022-06-24 02:16:37.482365
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-24 02:16:49.205497
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    uncompressed_string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
    string_compressor = __StringCompressor()

# Generated at 2022-06-24 02:16:52.551412
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:17:03.704279
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake') == 'Snake'
    assert snake_case_to_camel('snake', False) == 'snake'
    assert snake_case_to_camel('s_n_a_k_e') == 'SNAKE'
    assert snake_case_to_camel('s_n_a_k_e', False) == 'sNAKE'
    assert snake_case_to_camel('s_na_ke') == 'SnaKe'
    assert snake_case_to_camel('s_nake') == 'Snake'
    assert snake_case_to_camel('snake', False, '-') == 'snake'

# Generated at 2022-06-24 02:17:06.263308
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'




# Generated at 2022-06-24 02:17:13.208283
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    # "decompress" will be a string of 169 chars
    decompressed = decompress(compressed)

    # orginal and decompressed should be equals, because compressed was obtained from original
    assert original == decompressed



# Generated at 2022-06-24 02:17:14.406355
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:17:20.883880
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('V') == 5
    assert __RomanNumbers.decode('X') == 10
    assert __RomanNumbers.decode('L') == 50
    assert __RomanNumbers.decode('C') == 100
    assert __RomanNumbers.decode('D') == 500
    assert __

# Generated at 2022-06-24 02:17:29.478426
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('') == ''

    for i in range(1, 100):
        input_string = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(i)])
        shuffled = shuffle(input_string)

        # checks that input is not the same as output (obviously)
        assert shuffled != input_string

        # checks that every input char is present in the output (but not necessarily in the same order)
        for c in input_string:
            assert c in shuffled



# Generated at 2022-06-24 02:17:35.795038
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
	assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
	assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
	assert snake_case_to_camel('the_snake_is_green', True, separator='-') == 'TheSnakeIsGreen'
	assert snake_case_to_camel('the_snake_is_green', False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:17:38.710477
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7



# Generated at 2022-06-24 02:17:49.773687
# Unit test for function prettify

# Generated at 2022-06-24 02:17:55.001546
# Unit test for function shuffle
def test_shuffle():
    # Arrange
    test_data = ['hello world', 'randomize me', 'test']

    # Act
    results = [shuffle(test_string) for test_string in test_data]

    # Assert
    for test_string in test_data:
        assert len(test_string) == len(results[test_data.index(test_string)])



# Generated at 2022-06-24 02:17:57.505297
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:18:06.091062
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('')

    assert sf.format() == ''

    sf = __StringFormatter('hello')

    assert sf.format() == 'Hello'

    sf = __StringFormatter('HELLO')

    assert sf.format() == 'HELLO'

    sf = __StringFormatter('Hello world')

    assert sf.format() == 'Hello world'

    sf = __StringFormatter('Hello world!')

    assert sf.format() == 'Hello world!'

    sf = __StringFormatter('Hello world, how are you?')

    assert sf.format() == 'Hello world, how are you?'

    sf = __StringFormatter(' Hello world, how are you?')

    assert sf.format() == 'Hello world, how are you?'

    s

# Generated at 2022-06-24 02:18:09.741241
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
    |line 1
    |line 2
    |line 3
    '''
    t = '''
    line 1
    line 2
    line 3
    '''
    print(strip_margin(s))
    print(t)
    assert(strip_margin(s) == t)

    
test_strip_margin()


# Generated at 2022-06-24 02:18:11.801278
# Unit test for function strip_margin
def test_strip_margin():
    margin = '    '
    multi_line = '\n{margin}line 1\n{margin}line 2\n{margin}line 3\n'.format(margin=margin)
    assert strip_margin(multi_line) == '\nline 1\nline 2\nline 3\n'



# Generated at 2022-06-24 02:18:22.313317
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(30) == 'XXX'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(60) == 'LX'
    assert __RomanNumbers

# Generated at 2022-06-24 02:18:33.861884
# Unit test for function compress

# Generated at 2022-06-24 02:18:35.506459
# Unit test for function reverse
def test_reverse():
    assert 'hello' == reverse('olleh')
    assert 'ab c' == reverse('c ba')



# Generated at 2022-06-24 02:18:38.963396
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    return
test_slugify()


# Generated at 2022-06-24 02:18:44.380104
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-24 02:18:56.246233
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'
    assert __RomanNumbers.__encode_digit(0, 9) == 'IX'

    assert __RomanNumbers.__encode

# Generated at 2022-06-24 02:19:07.511043
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    class_test = __RomanNumbers()
    assert class_test.encode(1) == 'I', 'Error: Test 1 failed'
    assert class_test.encode(2) == 'II', 'Error: Test 2 failed'
    assert class_test.encode(5) == 'V', 'Error: Test 3 failed'
    assert class_test.encode(10) == 'X', 'Error: Test 4 failed'
    assert class_test.encode(20) == 'XX', 'Error: Test 5 failed'
    assert class_test.encode(50) == 'L', 'Error: Test 6 failed'
    assert class_test.encode(100) == 'C', 'Error: Test 7 failed'
    assert class_test.encode(200) == 'CC', 'Error: Test 8 failed'
    assert class_test

# Generated at 2022-06-24 02:19:18.648168
# Unit test for function prettify