

# Generated at 2022-06-24 02:09:21.781851
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('MMXX') == 2020, 'Roman decode: Wrong value'



# Generated at 2022-06-24 02:09:27.084102
# Unit test for function roman_encode
def test_roman_encode():
    # Test a string as input
    assert roman_encode("2020") == "MMXX"
    # Test an integer as input
    assert roman_encode(37) == "XXXVII"
    # Test a string as input
    assert roman_encode("0") == "Illegal Argument"
    # Test a string as input
    assert roman_encode("4000") == "Illegal Argument"



# Generated at 2022-06-24 02:09:28.749562
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello world!') is not None
    assert __StringFormatter(None) is None


# Generated at 2022-06-24 02:09:38.001935
# Unit test for function compress

# Generated at 2022-06-24 02:09:47.680734
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings.__len__() == 4
    assert __RomanNumbers.__mappings[0].__len__() == 2
    assert __RomanNumbers.__mappings[1].__len__() == 2
    assert __RomanNumbers.__mappings[2].__len__() == 2
    assert __RomanNumbers.__mappings[3].__len__() == 1
    assert __RomanNumbers.__reversed_mappings.__len__() == 4
    assert __RomanNumbers.__reversed_mappings[0].__len__() == 2
    assert __RomanNumbers.__reversed_mappings[1].__len__() == 2
    assert __RomanNumbers.__reversed_mappings[2].__len__() == 2

# Generated at 2022-06-24 02:09:48.486872
# Unit test for function asciify
def test_asciify():
    assert 'The unicode chars = !' == asciify('The unicode chars = ÿ')


# Generated at 2022-06-24 02:09:54.606004
# Unit test for function asciify
def test_asciify():
    assert asciify('This is a string') == 'This is a string'

# Generated at 2022-06-24 02:09:58.526896
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I', "Incorrect roman number encoding"
    assert roman_encode(10) == 'X', "Incorrect roman number encoding"
    assert roman_encode(2020) == 'MMXX', "Incorrect roman number encoding"



# Generated at 2022-06-24 02:09:59.377625
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert is_full_string(snake_case_to_camel('a'))



# Generated at 2022-06-24 02:10:05.548722
# Unit test for function asciify
def test_asciify():
    test_in = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    test_out = 'eeuuooaaeynAAACIINOE'
    assert asciify(test_in) == test_out



# Generated at 2022-06-24 02:10:07.611224
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Tests for function asciify

# Generated at 2022-06-24 02:10:09.770519
# Unit test for function prettify

# Generated at 2022-06-24 02:10:13.156823
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('false') == False
    assert booleanize('FALSE') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('no') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    assert booleanize('on') == True
    assert booleanize('off') == False
    assert booleanize('ciao') == False


# Generated at 2022-06-24 02:10:19.031498
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    s = '1234'
    b = s.encode('utf-8')
    c = zlib.compress(b, 9)
    b64 = base64.urlsafe_b64encode(c)
    s2 = b64.decode('utf-8')
    pass

# PUBLIC API



# Generated at 2022-06-24 02:10:24.256412
# Unit test for function slugify
def test_slugify():
	assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
	assert slugify('Mönstér Mägnët') == 'monster-magnet'
	assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
	assert slugify('') == ''
	assert slugify(' ') == ''
	assert slugify(None) == ''

test_slugify()


# Generated at 2022-06-24 02:10:25.662330
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('') == ''



# Generated at 2022-06-24 02:10:29.688921
# Unit test for function compress
def test_compress():
    assert compress('') == ''
    assert compress(EMPTY) == ''
    assert compress('123') == 'eJxLzcLAACAA='
    assert compress('1,2,3') == 'eJzLycLAACAA='
    assert compress('1,2,3,4') == 'eJzLzcLAACAA='
    assert compress('1,2,3,4,4,4') == 'eJzLz8LAACAA='
    assert compress(' lorem ipsum dolor sit amet ') == 'eJzLIywAwrDp+f7xMszAvA='

# Generated at 2022-06-24 02:10:38.498805
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor().__require_valid_input_and_encoding('foo', 'utf-8') == None
    assert __StringCompressor().__require_valid_input_and_encoding('foo', '') == None
    assert __StringCompressor().__require_valid_input_and_encoding('', 'utf-8') == None
    assert __StringCompressor().__require_valid_input_and_encoding('', '') == None

    try:
        __StringCompressor().__require_valid_input_and_encoding(None, 'utf-8')
        assert False
    except InvalidInputError:
        assert True

    try:
        __StringCompressor().__require_valid_input_and_encoding('foo', None)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 02:10:42.974961
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers()

__RomanNumbers()


# Generated at 2022-06-24 02:10:45.125203
# Unit test for function roman_decode
def test_roman_decode():
    assert(roman_decode('VII') == 7)
test_roman_decode()


# ==================================================================================================================
#
#   Main API definition
#
# ==================================================================================================================


# Generated at 2022-06-24 02:10:49.787284
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    try:
        roman_encode('-123')
    except ValueError:
        assert True


# def roman_decode(input_string: str) -> int:
#     """
#     Convert the given string into an integer.
#
#     :param input_string: A string to be converted.
#     :type input_string: str
#     :return: Integer number.
#     """
#     return __RomanNumbers.decode(input_string)



# Generated at 2022-06-24 02:11:00.739634
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:11:07.952779
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE"


# PUBLIC API


# Generated at 2022-06-24 02:11:09.746401
# Unit test for function reverse
def test_reverse():
    assert reverse('reverse') == 'esrever'
    assert reverse('abcd') == 'dcba'


# Generated at 2022-06-24 02:11:10.390284
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('pippo') != 'pippo'



# Generated at 2022-06-24 02:11:16.915336
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'This is a test'
    print('Input string:', input_string)
    encoded_string = __StringCompressor.compress(input_string)
    print('Encoded string:', encoded_string)
    decoded_string = __StringCompressor.decompress(encoded_string)
    print('Decoded string:', decoded_string)
    print('Result:', decoded_string == input_string)



# Generated at 2022-06-24 02:11:28.337865
# Unit test for function asciify
def test_asciify():
    assert asciify('ÈÉÙÚÒÓÄÅËÝÑÅÀÁÇÌÍÑÓË') == 'EEUUOOAAEYNAACIINOE'
    assert asciify('æÆàÀáÁâÂåÅãÃąĄ') == 'aeAaAaAaaAaaAa'
    assert asciify('ĆĄĘĆĆĘĘĆĆĘĆĘĄĆĆĘĘĄĘ') == 'CAECEcEcECECECAeCAe'

# Generated at 2022-06-24 02:11:33.379026
# Unit test for function compress
def test_compress():
    original = 'this is a test string'
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert(original == decompressed)
    
    


# Generated at 2022-06-24 02:11:43.933125
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    output_compress = __StringCompressor.compress("Hello, World !")
    assert output_compress == "eJwdj9EKwCAMBcC5mwLVh1kxURYYBtM09cMJD_GtKKqXtfnHZNQeZScfzT_3qxHxIUVk8QfMWk-0l1aRlfljzs8OEVs0sFoTNw", "Compressing failed"


# Generated at 2022-06-24 02:11:53.903568
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    original_string = 'Fai r    r e  s t ;'
    formatted_string = 'Fair rest;'

    assert __StringFormatter(original_string).format() == formatted_string



# Generated at 2022-06-24 02:12:04.430810
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') is True
    assert booleanize('TRUE') is True
    assert booleanize('1') is True
    assert booleanize('YES') is True
    assert booleanize('yes') is True
    assert booleanize('Y') is True
    assert booleanize('y') is True

    assert booleanize('false') is False
    assert booleanize('FALSE') is False
    assert booleanize('0') is False
    assert booleanize('NO') is False
    assert booleanize('no') is False
    assert booleanize('N') is False
    assert booleanize('n') is False

    assert booleanize('yup') is False
    assert booleanize('yes i do') is False


# Generated at 2022-06-24 02:12:06.982244
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse('aBc') == 'cBa'
# Run tests for function reverse
test_reverse()



# Generated at 2022-06-24 02:12:11.383312
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    def __testcase(input_string: str):
        return __StringFormatter(input_string)

    # Positive cases
    try:
        __testcase('a')
        __testcase('')
    except:
        raise Exception('Exception not expected')

    # Negative cases
    try:
        __testcase(None)
        raise Exception('Exception expected')
    except:
        pass


# Generated at 2022-06-24 02:12:17.392363
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # roman_encode
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(14) == 'XIV'
    assert __RomanNumbers.encode(15) == 'XV'
    assert __RomanNumbers.encode(20) == 'XX'

# Generated at 2022-06-24 02:12:29.133371
# Unit test for function decompress
def test_decompress():
    assert decompress('') == ''
    assert decompress(' ') == ' '
    assert decompress('à') == 'à'
    assert decompress('AB') == 'AB'
    assert decompress('AB CD') == 'AB CD'
    assert decompress('AB CD EF') == 'AB CD EF'
    assert decompress('AB CD EF GH') == 'AB CD EF GH'
    assert decompress('AB CD EF GH IJ') == 'AB CD EF GH IJ'
    assert decompress('AB CD EF GH IJ KL') == 'AB CD EF GH IJ KL'
    assert decompress('AB CD EF GH IJ KL MN') == 'AB CD EF GH IJ KL MN'
    assert decompress('AB CD EF GH IJ KL MN OP') == 'AB CD EF GH IJ KL MN OP'

# Generated at 2022-06-24 02:12:30.435475
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('no') == False



# Generated at 2022-06-24 02:12:39.927873
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # init input string to compress
    input_string = 'This is an example of a string that is going to be compressed'

    # init encoding used for characters in input string
    encoding = 'utf-8'

    # init compression level for zlib compressor
    # (the higher, the better)
    compression_level = 9

    # compress and encode bytes using the constructor of class __StringCompressor
    compressed_string = __StringCompressor.compress(input_string, encoding, compression_level)

    # decompress and decode bytes using the constructor of class __StringCompressor
    decompressed_string = __StringCompressor.decompress(compressed_string, encoding)

    print('\ncompressed_string = {}'.format(compressed_string))
    print('\ndecompressed_string = {}'.format(decompressed_string))

   

# Generated at 2022-06-24 02:12:45.564061
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    return True


# Generated at 2022-06-24 02:12:49.391403
# Unit test for function strip_html
def test_strip_html():
    if strip_html('test: <a href="foo/bar">click here</a>') != 'test: ':
        raise AssertionError('Strip html failed!')
    if strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) != 'test: click here':
        raise AssertionError('Strip html failed!')



# Generated at 2022-06-24 02:12:52.162898
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:12:58.551175
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('tHE_sNAKE_iS_gREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('tHE_sNAKE_iS_gREEN', separator='.') == 'tHE_sNAKE_iS_gREEN'



# Generated at 2022-06-24 02:13:07.182052
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('à á â ã ä å æ ç è é ê ë ì í î ï ð ñ ò ó ô õ ö ø ù ú û ü ý þ ÿ') == 'a a a a a a ae c e e e e i i i i d n o o o o o o u u u u y th y'
    assert asciify('བོད་ཡིག') == 'bod yig'



# Generated at 2022-06-24 02:13:10.626056
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:13:11.731154
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '



# Generated at 2022-06-24 02:13:15.874274
# Unit test for function asciify
def test_asciify():
    assert(asciify("") == "")
    assert(asciify("Hello World") == "Hello World")
    assert(asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == "eeuuooaaeynAAACIINOE")
    
test_asciify()


# Generated at 2022-06-24 02:13:24.915052
# Unit test for function shuffle
def test_shuffle():
    # with this function we can ensure that shuffle always return a different string (given the fact that the same
    # source string is used in the different calls)
    def __different_strings(s1: str, s2: str):
        return len(set(s1).intersection(s2)) != len(s1)

    # test that the length of the shuffled output is the same as the input
    assert len(shuffle('hello world')) == len('hello world')

    assert __different_strings(
        shuffle('hello world'),
        shuffle('hello world')
    )

    # make sure that the input string is untouched
    in_string = 'hello'
    shuffle(in_string)
    assert in_string == 'hello'



# Generated at 2022-06-24 02:13:27.407035
# Unit test for function booleanize
def test_booleanize():
    assert booleanize == True
test_booleanize()


# Generated at 2022-06-24 02:13:39.358013
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(42) == 'XLII'
    assert __RomanNumbers.encode(43) == 'XLIII'
    assert __RomanNumbers.encode(44) == 'XLIV'
    assert __RomanNumbers.encode(45) == 'XLV'
    assert __RomanNumbers.encode(100) == 'C'
    assert __

# Generated at 2022-06-24 02:13:49.824721
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:13:52.185989
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert (compressed is not None)


# Generated at 2022-06-24 02:13:53.511007
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
        |line 1
        |line 2
        |line 3
    ''') == '''
line 1
line 2
line 3
'''

# Generated at 2022-06-24 02:13:58.031873
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    __StringFormatter('ciao')
    __StringFormatter(' ')
    __StringFormatter('')
    __StringFormatter('0')
    __StringFormatter('0.0')


# PUBLIC API



# Generated at 2022-06-24 02:14:03.870624
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('o') == 'o'
    assert reverse('') == ''
    assert reverse('selah') == 'halés'
    assert reverse('shall we date') == 'etad ew hallés'
    assert reverse('shall we date tonight') == 'thgion eton ew hallés'
    assert reverse('Shall We Date Tonight') == 'Thgion Eton Ew Hallés'
    assert reverse('shall we date tonight?') == '?thgion eton ew hallés'
    assert reverse('shall we date tonight!') == '!thgion eton ew hallés'



# Generated at 2022-06-24 02:14:11.340419
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hi') != None
    assert __StringFormatter('hi') != True
    assert __StringFormatter('hi') != False
    assert __StringFormatter('hi') != 'hi'
    assert __StringFormatter('hi') != 0
    assert __StringFormatter('hi') != 1
    assert __StringFormatter('hi') != None


# PUBLIC API



# Generated at 2022-06-24 02:14:19.212912
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter("hello world")
    assert not __StringFormatter("")
    try:
        assert __StringFormatter("")
    except InvalidInputError:
        pass
    assert not __StringFormatter(1)
    try:
        assert __StringFormatter(1)
    except InvalidInputError:
        pass
    assert not __StringFormatter([])
    try:
        assert __StringFormatter([])
    except InvalidInputError:
        pass

# Generated at 2022-06-24 02:14:27.040025
# Unit test for function decompress

# Generated at 2022-06-24 02:14:33.922979
# Unit test for function asciify
def test_asciify():
    # File contains non-ASCII characters
    input_string_file = "data/non-ASCII-characters.txt"
    with open(input_string_file, 'r') as fp:
        input_string = fp.read()
        
    output_string = asciify(input_string)
    
    # Expected output
    expected_output_string_file = "data/non-ASCII-characters-ASCII.txt"
    with open(expected_output_string_file, 'r') as fp:
        expected_output_string = fp.read()
    # Check if the ascii output is equal to expected output
    assert output_string == expected_output_string
    

# Generated at 2022-06-24 02:14:44.799836
# Unit test for function roman_decode
def test_roman_decode():
    # Test 1: one
    assert roman_decode('I') == 1, "Test 1: one"

    # Test 2: two
    assert roman_decode('II') == 2, "Test 2: two"

    # Test 3: four
    assert roman_decode('IV') == 4, "Test 3: four"

    # Test 4: seven
    assert roman_decode('VII') == 7, "Test 4: seven"

    # Test 5: eight
    assert roman_decode('VIII') == 8, "Test 5: eight"

    # Test 6: ten
    assert roman_decode('X') == 10, "Test 6: ten"

    # Test 7: eleven
    assert roman_decode('XI') == 11, "Test 7: eleven"

    # Test 8: twelve
   

# Generated at 2022-06-24 02:14:57.423375
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Arrange
    input_string = "Lorem ipsum dolor sit amet,  consectetur adipiscing elit. Etiam mattis, nisl eu sollicitudin vulputate, ipsum diam elementum purus, a mollis purus turpis eget ipsum. Nam laoreet pulvinar turpis, et iaculis urna elementum quis. Vestibulum euismod molestie augue lacinia cursus. Mauris laoreet ipsum dolor, eget pharetra diam sagittis a."

# Generated at 2022-06-24 02:15:04.950373
# Unit test for function shuffle
def test_shuffle():
    assert is_string(shuffle(''))
    assert is_string(shuffle('In order to configure the game engine, you have to add a file named "game.py" to your'
                              ' project root folder.'))
    assert is_string(shuffle('123'))
    assert is_string(shuffle('a'))



# Generated at 2022-06-24 02:15:16.242858
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''\
    |line 1
    |line 2
    |line 3
    |''') == '''\
line 1
line 2
line 3
'''
    assert strip_margin('''\
    |   line 1
    |   line 2
    |   line 3
    |''') == '''\
line 1
line 2
line 3
'''
    assert strip_margin('''\
line 1
line 2
line 3
''') == '''\
line 1
line 2
line 3
'''
    assert strip_margin('''\
    |     line 1
    |     line 2
    |     line 3
    |''') == '''\
line 1
line 2
line 3
'''


if __name__ == '__main__':
    import doctest


# Generated at 2022-06-24 02:15:22.908271
# Unit test for function slugify

# Generated at 2022-06-24 02:15:32.874407
# Unit test for function slugify
def test_slugify():
    assert slugify('Hello world') == 'hello-world'
    assert slugify('I am a super slug') == 'i-am-a-super-slug'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Yòü çäñ rëàdíz&$') == 'you-can-readiz'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Hello world', '_') == 'hello_world'
    
test_slugify()


# Generated at 2022-06-24 02:15:42.411773
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('HelloWorld') == 'hello_world'
    assert camel_case_to_snake('helloWorld') == 'hello_world'
    assert camel_case_to_snake('hello_world') == 'hello_world'
    assert camel_case_to_snake('helloWorldTest') == 'hello_world_test'
    assert camel

# Generated at 2022-06-24 02:15:54.019716
# Unit test for function booleanize
def test_booleanize():
    """Test case for booleanize function.
    """
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('True') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('Yes') == True
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize('false') == False
    assert booleanize('No') == False
    assert booleanize('no') == False
    assert booleanize('Test') == False
    assert booleanize('test') == False
    try:
        booleanize(1)
        assert False
    except:
        assert True

# Generated at 2022-06-24 02:15:56.070653
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    string = "  first   second  third  "
    fm = __StringFormatter(string)
    assert fm.input_string == string



# Generated at 2022-06-24 02:16:01.814006
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    test_string_1 = "Il rispetto delle regole è fondamentale per la vita in comune, in famiglia, nelle scuole e nel lavoro. Sono tanti i punti in cui l'uomo tutti i giorni è chiamato a fragole e panna."
    test_string_2 = "Ho dei dubbi sulle regole fondamentali della fisica"
    test_string_3 = "L'Italia è un paese magnifico"
    test_string_4 = "Perchè continui a dare regole"
    test_string_5 = "Le regole sono importanti"


# Generated at 2022-06-24 02:16:04.472373
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('\tline 1\n\tline 2\n\tline 3') == 'line 1\nline 2\nline 3'

# Generated at 2022-06-24 02:16:07.909875
# Unit test for function strip_margin
def test_strip_margin():
    """
    >>> test_strip_margin()
    """
    testStr = '''\
    line 1
    line 2
    line 3
    '''

    formattedStr = '''\
line 1
line 2
line 3'''

    assert strip_margin(testStr) == formattedStr

# Generated at 2022-06-24 02:16:11.289736
# Unit test for function prettify

# Generated at 2022-06-24 02:16:21.495011
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)

    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # print(original)
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    # print(compressed)

    assert is_string(compressed)
    assert is_full_string(compressed)
    assert len(compressed) < len(original)

    # reverse the compression using function decompress and check the result
    decompressed = decompress(compressed)

    assert is_string(decompressed)
    assert is_full_string(decompressed)

# Generated at 2022-06-24 02:16:34.218471
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .test_tools import assert_equals

    assert_equals('', __StringFormatter('').format())

    # UPpercase fisrt letter
    assert_equals('Ebook', __StringFormatter('ebook').format())
    assert_equals('1. Ebook', __StringFormatter('1. ebook').format())
    assert_equals('E-book', __StringFormatter('e-book').format())
    assert_equals('Ebook', __StringFormatter('eBook').format())
    assert_equals('12. Ebook', __StringFormatter('12. eBook').format())

    # Lowercase suffixes
    assert_equals('Ebook', __StringFormatter('ebooks').format())
    assert_equals('Ebook', __StringFormatter('ebooking').format())

# Generated at 2022-06-24 02:16:37.848588
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XIV') == 14
    assert roman_decode('MXXXIX') == 1039
    assert roman_decode('MMXX') == 2020


# Generated at 2022-06-24 02:16:49.986354
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('asdf').format() == 'Asdf'
    assert __StringFormatter('ASDF').format() == 'Asdf'
    assert __StringFormatter('aSDF').format() == 'Asdf'
    assert __StringFormatter('  asdf  ').format() == 'Asdf'
    assert __StringFormatter(' asdf asdf ').format() == 'Asdf asdf'
    assert __StringFormatter(' asdf    asdf ').format() == 'Asdf asdf'
    assert __StringFormatter('asdf  asdf ').format() == 'Asdf asdf'
    assert __StringFormatter('asdf asdf  ').format() == 'Asdf asdf'
    assert __StringFormatter('asdf asdf').format() == 'Asdf asdf'
    assert __StringFormatter

# Generated at 2022-06-24 02:16:54.003405
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('') == 0
    assert roman_decode('  ') == 0
    assert roman_decode('VII') == 7
    assert roman_decode('III') == 3
    assert roman_decode('XIX') == 19
    assert roman_decode('XXIX') == 29
    assert roman_decode('XLII') == 42
    assert roman_decode('XLIX') == 49
    assert roman_decode('XCIX') == 99
    assert roman_decode('CXXIX') == 129
    assert roman_decode('DCXCIX') == 699
    assert roman_decode('DCCXXXII') == 732
    assert roman_decode('MMXVI') == 2016

# Generated at 2022-06-24 02:16:55.727285
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('hello world')) == 'hello world'

# Generated at 2022-06-24 02:16:59.238597
# Unit test for function decompress
def test_decompress():

    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)

    assert original == decompressed



# Generated at 2022-06-24 02:17:02.307022
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('1') == True
    assert booleanize('nope') == False



# Generated at 2022-06-24 02:17:05.533333
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test', \
        'The test has given a wrong result'



# Generated at 2022-06-24 02:17:06.978676
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
# Test function
test_roman_encode()



# Generated at 2022-06-24 02:17:09.360560
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    """Unit test for constructor of class __RomanNumbers."""
    rn = __RomanNumbers()
    return rn


# PUBLIC API



# Generated at 2022-06-24 02:17:17.646514
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():

    # Test the RomanNumbers.__encode_digit() method
    assert __RomanNumbers.__encode_digit(0, 0) == ''
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'

# Generated at 2022-06-24 02:17:21.741289
# Unit test for function compress
def test_compress():
    assert(compress('test') == 'eJxLTEtNy0zTgO4N0goSSxNywQA')


# Generated at 2022-06-24 02:17:26.158191
# Unit test for function prettify

# Generated at 2022-06-24 02:17:28.702473
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# PUBLIC API


# Generated at 2022-06-24 02:17:35.171961
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('TRUE') == True
    assert booleanize('True') == True
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('') == False
    assert booleanize(' ') == False
    assert booleanize('test') == False
    assert booleanize('   ') == False
    assert booleanize('NOPE') == False

# Generated at 2022-06-24 02:17:47.565363
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('X') == 10
    assert roman_decode('XX') == 20
    assert roman_decode('XL') == 40
    assert roman_decode('L') == 50
    assert roman_decode('LX') == 60
    assert roman_decode('IC') == 99
    assert roman_decode('C') == 100
    assert roman_decode('CC') == 200
    assert roman_decode('CD') == 400
    assert roman_decode('D') == 500
    assert r

# Generated at 2022-06-24 02:17:58.950747
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'

# Generated at 2022-06-24 02:18:06.909245
# Unit test for function strip_margin
def test_strip_margin():
    text_with_margin = '''\
            line 1
            line 2
            line 3
            '''
    text_without_margin = strip_margin(text_with_margin)
    lines_without_margin = text_without_margin.splitlines()
    assert(len(lines_without_margin) == 3)
    assert(lines_without_margin[0] == 'line 1')
    assert(lines_without_margin[1] == 'line 2')
    assert(lines_without_margin[2] == 'line 3')
# Apply the unit test
test_strip_margin()



# Generated at 2022-06-24 02:18:16.699969
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('3999') == 'MMMCMXCIX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode('10') == 'X'
    assert roman_encode(10) == 'X'
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('1') == 'I'
    assert roman_encode(1) == 'I'
    assert roman_encode('0') == ''
    assert roman_encode(0) == ''



# Generated at 2022-06-24 02:18:27.032335
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this_is_a_camel_string_test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('this is a camel string test') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIs A CamelStringTest') == 'this_is_a_camel_string_test'

# Generated at 2022-06-24 02:18:28.505975
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                                                     |line 1
                                                         |line 2
                                             |line 3
                                                 |''') == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-24 02:18:30.083419
# Unit test for function asciify
def test_asciify():
    assert asciify('aèéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'aeeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:18:40.548437
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-24 02:18:44.890171
# Unit test for function shuffle
def test_shuffle():
    # Shuffle should return a string
    assert is_string(shuffle('hello world'))

    # Shuffle must return a string with the same length of the input
    assert len(shuffle('hello world')) == len('hello world')

    # Shuffle should not alter the provided string
    assert 'hello world' not in shuffle('hello world')

    # After shuffling the input string, the string should only contain valid chars of the original string
    assert set(shuffle('hello world')) == set('hello world')


# Generated at 2022-06-24 02:18:54.811389
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('False') == False
    assert booleanize('0') == False
    assert booleanize('n0') == False
    assert booleanize('nope') == False
    assert booleanize('not') == False
    assert booleanize('no') == False
    with pytest.raises(InvalidInputError):
        booleanize(123)
    with pytest.raises(InvalidInputError):
        booleanize(False)
    with pytest.raises(InvalidInputError):
        booleanize(None)


# Generated at 2022-06-24 02:19:05.262458
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII', 'wrong conversion'
    assert roman_encode(2020) == 'MMXX', 'wrong conversion'
    assert roman_encode(1) == 'I', 'wrong conversion'
    assert roman_encode(3999) == 'MMMCMXCIX', 'wrong conversion'
    assert roman_encode(3999) == 'MMMCMXCIX', 'wrong conversion'
    assert roman_encode(10101) == 'MMMIBI', 'wrong conversion'
    assert roman_encode(99) == 'XCIX', 'wrong conversion'



# Generated at 2022-06-24 02:19:17.613274
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<span class="someClass">foo</span>') == ''
    assert strip_html('<span class="someClass">foo</span>', keep_tag_content=True) == 'foo'
    assert strip_html('<div class="someClass">foo</div>') == ''
    assert strip_html('<div class="someClass">foo</div>', keep_tag_content=True) == 'foo'

