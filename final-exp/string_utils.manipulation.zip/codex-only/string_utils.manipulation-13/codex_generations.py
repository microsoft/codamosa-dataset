

# Generated at 2022-06-24 02:09:23.405608
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('abc').input_string == 'abc'


# Generated at 2022-06-24 02:09:26.108410
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MMXX') == 2020
    try:
        roman_decode('XIXM')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-24 02:09:35.539965
# Unit test for function roman_decode

# Generated at 2022-06-24 02:09:37.012621
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    a=camel_case_to_snake('ThisIsACamelStringTest')
    print(a)
    assert a == 'this_is_a_camel_case_string_test'


# Generated at 2022-06-24 02:09:46.039339
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    data = [rd.choice(rd.choices(string.ascii_uppercase +
                       string.digits + string.ascii_lowercase, k=rd.randint(1, 10000))) for i in range(1000)]
    test_str = ''.join(data)
    tmp = __StringCompressor.compress(test_str)
    tmp = __StringCompressor.decompress(tmp)
    tmp = __StringCompressor.compress(tmp)
    tmp = __StringCompressor.decompress(tmp)
    assert test_str == tmp
    assert test_str == __StringCompressor.decompress(__StringCompressor.compress(test_str))



# Generated at 2022-06-24 02:09:52.847379
# Unit test for function asciify
def test_asciify():
    assert('eeeeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË'))
    assert('eclamatory_exclamation_mark' == asciify('èclamatory_ëxclamation_mark'))
    assert('SALUDA LA GENTE' == asciify('¡¡SALUDA LA GENTE!!'))
    assert('A' == asciify('Æ'))
    assert('AE' == asciify('Æ'))
    assert('O' == asciify('Ø'))
    assert('OE' == asciify('Ø'))
    assert('AA' == asciify('Å'))

# Generated at 2022-06-24 02:10:02.931284
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(13) == 'XIII'
    assert __Roman

# Generated at 2022-06-24 02:10:12.131361
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE' # noqa
    assert asciify('Mary had a little lamb') == 'Mary had a little lamb' # noqa
    assert asciify('') == '' # noqa
    assert asciify(123456) == '123456' # noqa
    assert asciify(None) == '' # noqa
    assert asciify(False) == '' # noqa
    assert asciify({}) == '' # noqa
    assert asciify([]) == '' # noqa


# Generated at 2022-06-24 02:10:24.043054
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(6) == 'VI'
    assert roman_encode(7) == 'VII'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'

# Generated at 2022-06-24 02:10:25.825585
# Unit test for function decompress
def test_decompress():
    test="hello"
    print(decompress(compress(test)))


# Generated at 2022-06-24 02:10:27.563687
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-24 02:10:37.418839
# Unit test for function roman_encode

# Generated at 2022-06-24 02:10:42.202031
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

# Generated at 2022-06-24 02:10:47.757537
# Unit test for function strip_html
def test_strip_html():
    input_string = 'This is a test: <a href="foo/bar">click here</a>'
    stripped_string = 'This is a test: '
    stripped_string_keep_content = 'This is a test: click here'
    assert strip_html(input_string) == stripped_string
    assert strip_html(input_string, True) == stripped_string_keep_content



# Generated at 2022-06-24 02:10:51.189299
# Unit test for function strip_html
def test_strip_html():
    assert 'test: ' == strip_html('test: <a href="foo/bar">click here</a>')
    assert 'test: click here' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)
    assert 'test: ' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False)



# Generated at 2022-06-24 02:11:02.605243
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('TRUE') == True
    assert booleanize('True') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('') == False
    assert booleanize('0') == False
    assert booleanize('False') == False
    assert booleanize(True) == False
    assert booleanize(False) == False
    assert booleanize(2) == False
    assert booleanize('Bla') == False
    assert booleanize(True) == False
    assert booleanize(False) == False
    assert booleanize(-1) == False
    assert booleanize(0) == False
    assert booleanize(-2)

# Generated at 2022-06-24 02:11:05.359402
# Unit test for function strip_html
def test_strip_html():
    string = '<html><head><title>Test</title><body><p>test<a href="foo/bar">click here</a></p></body></html>'
    assert strip_html(string) == '<html><head><title>Test</title><body><p>test</p></body></html>'
    assert strip_html(string, keep_tag_content=True) == '<html><head><title>Test</title><body><p>testclick here</p></body></html>'



# Generated at 2022-06-24 02:11:06.541296
# Unit test for function roman_decode
def test_roman_decode():
    assert __RomanNumbers.decode('VII') == 7

# Generated at 2022-06-24 02:11:07.868357
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7


# Generated at 2022-06-24 02:11:10.167191
# Unit test for function prettify

# Generated at 2022-06-24 02:11:15.614748
# Unit test for function shuffle
def test_shuffle():
    output = shuffle('abcdefghijklmnopqrstuvwxyz')
    assert is_string(output)
    assert len(output) == len('abcdefghijklmnopqrstuvwxyz')
    assert ''.join(sorted(output)) == 'abcdefghijklmnopqrstuvwxyz'



# Generated at 2022-06-24 02:11:17.091310
# Unit test for function slugify
def test_slugify():
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-24 02:11:28.462478
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    print('Testing __StringCompressor')

    # check compresss()
    print('Checking compress()')
    input_string = '1234567890' * 5000
    encoded_string = __StringCompressor.compress(input_string)
    print('compressed string lenght: {}'.format(len(encoded_string)))
    assert __StringCompressor.decompress(encoded_string) == input_string

    # check decompress()
    print('Checking decompress()')
    assert __StringCompressor.decompress(encoded_string) == input_string

    # check validation
    try:
        __StringCompressor.compress(None)
    except InvalidInputError:
        pass
    else:
        assert False


# Generated at 2022-06-24 02:11:38.899356
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Hello world, I\'m a boy, but I\'m not a dog').format() == \
           'Hello world, I\'m a boy, but I\'m not a dog'

    assert __StringFormatter('hello world I\'m a boy but I\'m not a dog').format() == \
           'Hello world, I\'m a boy, but I\'m not a dog'

    assert __StringFormatter('hello world I\'M a boy but I\'m not a dog').format() == \
           'Hello world, I\'m a boy, but I\'m not a dog'

    assert __StringFormatter('hello world I\'m a boy, but I\'m not a dog').format() == \
           'Hello world, I\'m a boy, but I\'m not a dog'


# Generated at 2022-06-24 02:11:44.330822
# Unit test for function compress
def test_compress():
    result = compress("hello world")
    expected_result = "eJwDAAAAAAE=\n"
    assert result == expected_result, "Compress function returns: " + result



# Generated at 2022-06-24 02:11:54.261940
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    input_string = '   this is a test  string, don\'t you think?   '
    expected_output = 'This is a test string, don\'t you think?'

    assert __StringFormatter(input_string).format() == expected_output



# Generated at 2022-06-24 02:12:05.270896
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'

# Generated at 2022-06-24 02:12:16.045405
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_string_test') == 'ThisIsASnakeStringTest'
    # camel cases with strange separators
    assert snake_case_to_camel('this-is-a-snake-string-test') == 'ThisIsASnakeStringTest'
    assert snake_case_to_camel('this.is.a.snake.string.test') == 'ThisIsASnakeStringTest'
    # not camel cases
    assert snake_case_to_camel('this is a snake string test') == 'this is a snake string test'
    assert snake_case_to_camel('This is a snake string test') == 'This is a snake string test'

# Generated at 2022-06-24 02:12:25.877046
# Unit test for function roman_decode
def test_roman_decode():
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999
    assert __RomanNumbers.decode('MMM') == 3000
    assert __RomanNumbers.decode('MM') == 2000
    assert __RomanNumbers.decode('M') == 1000
    assert __RomanNumbers.decode('CM') == 900
    assert __RomanNumbers.decode('DCCC') == 800
    assert __RomanNumbers.decode('DCC') == 700
    assert __RomanNumbers.decode('DC') == 600
    assert __RomanNumbers.decode('D') == 500
    assert __RomanNumbers.decode('CD') == 400
    assert __RomanNumbers.decode('CCC') == 300
    assert __RomanNumbers.decode('CC') == 200
    assert __RomanNumbers.decode('C') == 100

# Generated at 2022-06-24 02:12:34.459872
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # create a random list of numbers to check for roman encoding/decoding
    nums = [random.randint(1, 3999) for _ in range(1000)]

    # check that decoding and encoding the same number returns the initial value
    for in_num in nums:
        out_roman = __RomanNumbers.encode(in_num)
        out_num = __RomanNumbers.decode(out_roman)
        assert in_num == out_num

    # check that encoding a random number and decoding the result returns the initial value
    for out_roman in [__RomanNumbers.encode(n) for n in nums]:
        out_num = __RomanNumbers.decode(out_roman)
        assert __RomanNumbers.encode(out_num) == out_roman


# PUBLIC API



# Generated at 2022-06-24 02:12:38.076458
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert(booleanize('YES') == True)
    assert(booleanize('nope') == False)


# Generated at 2022-06-24 02:12:44.969086
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == slugify('Top 10 Reasons To Love Dogs!!!')
    assert slugify('Mönstér Mägnët') == slugify('Mönstér Mägnët')



# Generated at 2022-06-24 02:12:48.389094
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('test').input_string == 'test'
    assert __StringFormatter('test   ').input_string == 'test   '
    assert __StringFormatter('').input_string == ''
    try:
        __StringFormatter(1)
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:12:59.103970
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(2) == 'II'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'
    assert roman_encode(100) == 'C'
    assert roman_encode(400) == 'CD'
    assert roman_encode(500) == 'D'
    assert roman_encode(900) == 'CM'
    assert r

# Generated at 2022-06-24 02:13:07.889642
# Unit test for function prettify
def test_prettify():
    f = prettify
    assert f(' unprettified string ,, like this one,will be"prettified" .it\\' 's awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-24 02:13:17.380822
# Unit test for function asciify
def test_asciify():
    # Tested string is taken from https://www.ncl.ucar.edu/Document/Graphics/Symbol.shtml
    test_string = 'ÀÅÈÉÙÛÜÇÌÍÑÓÖÒØÞßãèéêîìíóôõúùüÿõõõ'
    expected_result = 'AAEEUUUCIIINOOSsbeeeeiiiooouuuyooo'
    test_result = asciify(test_string)
    if test_result == expected_result:
        print('asciify success')
    else:
        print('asciify failure')



# Generated at 2022-06-24 02:13:25.947808
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    r = __RomanNumbers()
    assert r.encode(1) == 'I'
    assert r.encode(2) == 'II'
    assert r.encode(3) == 'III'
    assert r.encode(4) == 'IV'
    assert r.encode(5) == 'V'
    assert r.encode(6) == 'VI'
    assert r.encode(7) == 'VII'
    assert r.encode(8) == 'VIII'
    assert r.encode(9) == 'IX'
    assert r.encode(10) == 'X'
    assert r.encode(11) == 'XI'
    assert r.encode(12) == 'XII'
    assert r.encode(13) == 'XIII'
    assert r.en

# Generated at 2022-06-24 02:13:30.797513
# Unit test for function slugify
def test_slugify():
    list_test = {
        "Top 10 Reasons To Love Dogs!!!" : "top-10-reasons-to-love-dogs",
        "Mönstér Mägnët" : "monster-magnet"
    }
    for test in list_test.keys():
        assert slugify(test) == list_test[test]

# Generated at 2022-06-24 02:13:38.268834
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('') == False
    assert booleanize('true' ) == True 
    assert booleanize('True' ) == True 
    assert booleanize('TRUE' ) == True 
    assert booleanize('1' ) == True 
    assert booleanize('YES' ) == True 
    assert booleanize('yes' ) == True 
    assert booleanize('Yes' ) == True 
    assert booleanize('y' ) == True 
    assert booleanize('Y' ) == True 
    assert booleanize('aaa' ) == False 
    assert booleanize('yess' ) == False 
    assert booleanize('False' ) == False 
    assert booleanize('2' ) == False 
    
    print('Done!')

test_booleanize()


# Generated at 2022-06-24 02:13:49.155827
# Unit test for function prettify
def test_prettify():
    # tests for first letter
    assert prettify('hello world') == 'Hello world'
    assert prettify(' hello world') == 'Hello world'
    assert prettify('1 hello world') == '1 Hello world'
    assert prettify('0 hello world') == '0 Hello world'
    assert prettify('hello. world') == 'Hello. World'
    assert prettify('hello? world') == 'Hello? World'
    assert prettify('hello! world') == 'Hello! World'
    assert prettify('hello, world') == 'Hello, world'
    assert prettify('hello... world') == 'Hello... world'
    assert prettify('hello? world') == 'Hello? World'
    assert prettify('hello! world') == 'Hello! World'
    assert prettify('hello, world') == 'Hello, world'
    assert prettify

# Generated at 2022-06-24 02:14:00.364071
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("snake_case_string", upper_case_first = True, separator = "_") == "SnakeCaseString"
    assert snake_case_to_camel("snake_case_string", upper_case_first = False, separator = "_") == "snakeCaseString"
    assert snake_case_to_camel("snake-case-string", upper_case_first = True, separator = "-") == "SnakeCaseString"
    assert snake_case_to_camel("snake-case-string", upper_case_first = False, separator = "-") == "snakeCaseString"
    assert snake_case_to_camel("snake_case_string", upper_case_first = True, separator = "") == "snakeCaseString"
    assert snake_case_

# Generated at 2022-06-24 02:14:01.860057
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == shuffle('hello')

# Generated at 2022-06-24 02:14:11.800101
# Unit test for function decompress
def test_decompress():
    encoded = compress('测试')
    assert encoded == ('eJydUk1OwzAM/ZdJxoOjwKIYU6RzI6CX9BQEjaKjqb8+qA3qO+D/gg12wJUYxp6UZC6'
                       'UcjKWIKI8qyqVUiTdKjCwWkz8pv7V9KczJ1F7Vu1yt2yvTHVu0KxSSH7w1BFlQ5z5Z')
    assert decompress(encoded) == '测试'
    encoded = compress('中文测试')

# Generated at 2022-06-24 02:14:14.732186
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:14:26.010852
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the.snake.is.green', separator='.') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the.snake.is.green', upper_case_first=False, separator='.') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'

# Generated at 2022-06-24 02:14:34.592395
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
  assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
  assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:14:36.621183
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print(compressed)
    # print(original)
    assert compressed.__len__() == 88
test_compress()


# Generated at 2022-06-24 02:14:41.901441
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_snake_case_string') == 'ThisIsASnakeCaseString'
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('invalid') == 'Invalid'
    assert snake_case_to_camel('invalid', separator=' ') == 'invalid'
    assert snake_case_to_camel('invalid', upper_case_first=False) == 'invalid'



# Generated at 2022-06-24 02:14:53.312814
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'

    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('X') == 10
    assert __RomanNumbers.decode('C') == 100
    assert __RomanNumbers.decode('M') == 1000

    assert __RomanNumbers.decode('MMMCMXCIX') == 3999

# PUBLIC API


# Generated at 2022-06-24 02:14:55.740700
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('a') == 'a'
    assert reverse('') == ''
    assert reverse(1234) == '4321'
    assert reverse('1234') == '4321'
    assert reverse(12.34) == '43.21'
    assert reverse('12.34') == '43.21'



# Generated at 2022-06-24 02:14:58.506917
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')=='eeuuooaaeynAAACIINOE'
    
test_asciify()



# Generated at 2022-06-24 02:15:04.197979
# Unit test for function compress
def test_compress():
    from random import randint
    from core.utils import random_lower_string

    for n in range(10):
        s = random_lower_string(10, 20)
        compressed = compress(s)
        decompressed = decompress(compressed)
        assert decompressed == s

        s = random_lower_string(200, 300)
        compression_level = randint(0, 9)
        compressed = compress(s, compression_level=compression_level)
        decompressed = decompress(compressed)
        assert decompressed == s

        s = ''
        with assertRaises(ValueError):
            compressed = compress(s)

        s = '   '
        with assertRaises(ValueError):
            compressed = compress(s)
        # end for

# Generated at 2022-06-24 02:15:06.885555
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('') == ''
    assert len(shuffle('hello world')) == len('hello world')
    assert isinstance(shuffle('hello world'), str)
test_shuffle()



# Generated at 2022-06-24 02:15:09.112737
# Unit test for function prettify

# Generated at 2022-06-24 02:15:11.862507
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('please') == shuffle('please')  # this test is extremely unlikely to fail
    assert shuffle('please') != 'please'



# Generated at 2022-06-24 02:15:19.994055
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # roman numbers are always uppercase
    assert __RomanNumbers.encode('iv') == 'IV'
    assert __RomanNumbers.decode('IV') == 4

    # test null
    try:
        __RomanNumbers.encode(0)
        assert False
    except ValueError:
        assert True

    try:
        __RomanNumbers.decode(0)
        assert False
    except ValueError:
        assert True

    # test non integer input
    try:
        __RomanNumbers.encode('dummy')
        assert False
    except ValueError:
        assert True

    try:
        __RomanNumbers.encode(0)
        assert False
    except ValueError:
        assert True

    # test valid range

# Generated at 2022-06-24 02:15:26.131036
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello World'
    assert __StringFormatter('hello    wo RLD    ').format() == 'Hello Wo Rld'
    assert __StringFormatter(' hello    wo RLD    ').format() == 'Hello Wo Rld'
    assert __StringFormatter('hello        world').format() == 'Hello World'
    assert __StringFormatter('hello world ').format() == 'Hello World'
    assert __StringFormatter(' -  hello world').format() == 'Hello World'
    assert __StringFormatter('hello@world.com').format() == 'Hello@World.Com'
    assert __StringFormatter('https://www.hello.world.com').format() == 'https://www.Hello.World.Com'

# Generated at 2022-06-24 02:15:30.192343
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize(1) == None

# Generated at 2022-06-24 02:15:37.044021
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('test').input_string == 'test'
    assert __StringFormatter('test1').input_string == 'test1'
    assert __StringFormatter('test2').input_string == 'test2'
    try:
        __StringFormatter(1)
        assert False
    except InvalidInputError:
        assert True



# Generated at 2022-06-24 02:15:40.504256
# Unit test for function compress
def test_compress():
    n = 0
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert original != compressed
    # "compressed" will be a string of 88 chars
    assert len(compressed) == 88
    # "original" will be a string with 169 chars:
    assert len(original) == 169



# Generated at 2022-06-24 02:15:45.196303
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:15:49.147244
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
test_slugify()

# Generated at 2022-06-24 02:15:52.561505
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('FooBar') == 'foo_bar'
    assert camel_case_to_snake('fooBar') == 'foo_bar'
    assert camel_case_to_snake('FooBarBaz') == 'foo_bar_baz'
    assert camel_case_to_snake('fooBarBaz') == 'foo_bar_baz'



# Generated at 2022-06-24 02:15:53.851986
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:16:02.983135
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('ThisIsACamelStringTest', ' ') == 'this is a camel string test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '/') == 'this/is/a/camel/string/test'



# Generated at 2022-06-24 02:16:06.572661
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
            line 1
            line 2
            line 3
        '''

    assert strip_margin(s) == '''
line 1
line 2
line 3
'''

# Generated at 2022-06-24 02:16:19.136029
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green')
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=True)
    assert 'theSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=False)
    assert 'TheSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', separator='_')
    assert 'theSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=False, separator='_')

# Generated at 2022-06-24 02:16:23.870915
# Unit test for function strip_margin
def test_strip_margin():
    input = '''
        line 1
        \t\tline 2
        \t\tline 3
        line 4
    '''
    expected = '''
        line 1
        line 2
        line 3
        line 4
    '''
    assert strip_margin(input) == expected



# Generated at 2022-06-24 02:16:28.615195
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    stringCompressor = __StringCompressor()
    assert stringCompressor is not None
    assert str(stringCompressor) == '<__main__.__StringCompressor>'


# PUBLIC API



# Generated at 2022-06-24 02:16:30.575822
# Unit test for function shuffle
def test_shuffle():
    for _ in range(10):
        assert len(shuffle('this is a test')) == 14



# Generated at 2022-06-24 02:16:34.118307
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert 'word' in compressed, 'Nope'



# Generated at 2022-06-24 02:16:35.480124
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    compressor = __StringCompressor()
    compressor.compress('a')

# PUBLIC API



# Generated at 2022-06-24 02:16:44.247143
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():

    assert __StringFormatter('a b c')
    assert __StringFormatter('http://aaa.com')
    assert __StringFormatter('a.b@c.d')

    try:
        __StringFormatter('')
        raise ValueError('should fail')
    except InvalidInputError:
        pass

    try:
        __StringFormatter(1)
        raise ValueError('should fail')
    except InvalidInputError:
        pass

    try:
        __StringFormatter([])
        raise ValueError('should fail')
    except InvalidInputError:
        pass

    try:
        __StringFormatter(None)
        raise ValueError('should fail')
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:16:55.671982
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():

    assert snake_case_to_camel("hello_world", upper_case_first = False) == "helloWorld"
    assert snake_case_to_camel("test_test_test") == "TestTestTest"
    assert snake_case_to_camel("test_test_test", upper_case_first = False) == "testTestTest"
    assert snake_case_to_camel("test_test_test", separator = ":") == "test_test_test"
    assert snake_case_to_camel("test_test_test", separator = ":", upper_case_first = False) == "test_test_test"
    assert snake_case_to_camel("test-test-test", separator = "-") == "TestTestTest"


# Generated at 2022-06-24 02:17:06.572923
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:17:15.673401
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(5) == 'V'
    assert roman_encode(2019) == 'MMXIX'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('1514') == 'MDXIV'
    assert roman_encode(55) == 'LV'
    assert roman_encode(77) == 'LXXVII'
    assert roman_encode('1992') == 'MCMXCII'
    assert roman_encode(88) == 'LXXXVIII'
    assert roman_encode(1991) == 'MCMXCI'

# Generated at 2022-06-24 02:17:16.355600
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'

# Generated at 2022-06-24 02:17:22.824229
# Unit test for function strip_margin
def test_strip_margin():
    test1 = '''
                line 1
                line 2
                line 3
            '''
    test2 = '''
                line 1
                line 2
                line 3
                '''
    assert strip_margin(test1) == 'line 1\nline 2\nline 3'
    assert strip_margin(test2) == 'line 1\nline 2\nline 3'
    
test_strip_margin()


# Generated at 2022-06-24 02:17:25.646936
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('default') == 'default'
    assert slugify('default', ' ') == 'default'
    assert slugify('default', '-') == 'default'
    
    
test_slugify()


# Generated at 2022-06-24 02:17:27.985429
# Unit test for function compress
def test_compress():
    assert compress("helloworld") == "eJwLNzEvMjYzNzE="

# Generated at 2022-06-24 02:17:31.339939
# Unit test for function asciify
def test_asciify():
    a = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    print(asciify(a))
    return

# Generated at 2022-06-24 02:17:32.589165
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:17:41.381412
# Unit test for function decompress
def test_decompress():
    assert decompress(
        compress('''
        <p>Discounts:</p>
        <ul>
        <li>
        <a href=\"dog-bed\">Dog bed</a>
        </li>
        </ul>
        ''')) == '''<p>Discounts:</p>
        <ul>
        <li>
        <a href="dog-bed">Dog bed</a>
        </li>
        </ul>'''
    return True
# test_decompress()


# Generated at 2022-06-24 02:17:45.768669
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('nope') == False
    
    

test_booleanize()

# Generated at 2022-06-24 02:17:46.634714
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    formatter = __StringFormatter('test')
    assert isinstance(formatter, __StringFormatter)


# Generated at 2022-06-24 02:17:48.842131
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('FOO') == False
    assert booleanize('F') == False
    assert booleanize('No') == False
    assert booleanize('FALSE') == False
# Test function booleanize
test_booleanize()



# Generated at 2022-06-24 02:17:56.657012
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('bla bla bla bla')
    assert 'Bla bla bla bla' == sf.format()

    sf = __StringFormatter('bla bla bla bla bla bla')
    assert 'Bla bla bla bla bla bla' == sf.format()

    sf = __StringFormatter('bla bla - bla bla')
    assert 'Bla bla - bla bla' == sf.format()

    sf = __StringFormatter('bla bla (bla bla)')
    assert 'Bla bla (bla bla)' == sf.format()

    sf = __StringFormatter('bla bla: bla bla')

# Generated at 2022-06-24 02:18:08.017213
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n' + str(n) for n in range(20)])
    # print(original)
    compressed = compress(original, encoding='utf-8', compression_level=9)
    # print(compressed)
    # compressed = 'eJzjYmBgYKAwZlJTcVFiUWJxUWJxUWJxUWJxUWJxUWJwZlJTcVFiUWJxUWJxUWJxUWJxUWJwZlJTcVFiUWJxUWJxUWJxUWJxUWJxUWJwZlJTcVFiUWJxUWJxUWJxUWJxUWJxUWJwZlJ

# Generated at 2022-06-24 02:18:12.436280
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('hello').input_string == 'hello'
    assert __StringFormatter(' hello ').input_string == ' hello '
    assert __StringFormatter('').input_string == ''
    assert __StringFormatter('1').input_string == '1'


# Generated at 2022-06-24 02:18:21.773111
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('LXV') == 65
    assert roman_decode('IV') == 4

    # test invalid chars
    with raises(InvalidInputError):
        _ = roman_decode('IVA')

    # test invalid char combinations
    with raises(InvalidInputError):
        _ = roman_decode('IVV')

    # test negative values
    with raises(InvalidInputError):
        _ = roman_decode('-IV')

    # test zero value
    with raises(InvalidInputError):
        _ = roman_decode('0')
    
    # test out of range values
    with raises(InvalidInputError):
        _ = roman_decode('MMMMCMXCIX')


# Generated at 2022-06-24 02:18:22.878813
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:18:26.693664
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2019) == 'MMXIX'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999
    assert __RomanNumbers.decode('I') == 1
    assert __RomanNumbers.decode('MMXIX') == 2019


# Generated at 2022-06-24 02:18:28.853860
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('vii') == 7
    assert roman_decode('vIi') == 7

# Generated at 2022-06-24 02:18:37.887157
# Unit test for function compress
def test_compress():
    #     print(compres('ls'))
    #     print(compress('ks'))
    #     print(compress('lhs'))
    print(compress('wwww'))
    print(compress('dddd'))
    # print(compress(''))
    # print(compress('e'))
    # print(compress('ee'))
    # print(compress('eee'))
    # print(compress('eeee'))
    # print(compress('5'))
    # print(compress('55'))
    # print(compress('555555'))
    # print(compress('wwww'))
    # print(compress('dddd'))
    # print(compress('gggg'))
    # print(compress('eeeeee'))
# test

# Generated at 2022-06-24 02:18:48.729438
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.__require_valid_input_and_encoding('', '') == None

    try:
        __StringCompressor.__require_valid_input_and_encoding(None, '')
        assert False
    except TypeError:
        assert True

    try:
        __StringCompressor.__require_valid_input_and_encoding('', None)
        assert False
    except TypeError:
        assert True

    try:
        __StringCompressor.__require_valid_input_and_encoding('', ' ')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 02:18:59.824226
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import unittest


# Generated at 2022-06-24 02:19:07.252976
# Unit test for function strip_margin
def test_strip_margin():
    raw = '''
    |    line 1
    |    line 2
    |    line 3
    '''
    expected = '''
line 1
line 2
line 3
'''
    actual = strip_margin(raw)
    assert expected == actual
    print('test_strip_margin ok')

if __name__ == '__main__':
    test_strip_margin()

# Generated at 2022-06-24 02:19:08.958503
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin("""
                        |line 1
                        |line 2
                        |line 3
                        |""") == """
line 1
line 2
line 3
"""

# Generated at 2022-06-24 02:19:14.340087
# Unit test for function compress
def test_compress():
    # A string of 169 chars
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    # Result: a smaller string of 88 chars
    assert len(compressed) == 88



# Generated at 2022-06-24 02:19:16.519918
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == 'this_is_a_camel_case_string_test'



# Generated at 2022-06-24 02:19:23.413818
# Unit test for function prettify
def test_prettify():
    assert prettify('prettified string') == 'Prettified string'
    assert prettify(' unprettified string') == 'Unprettified string'
    assert prettify('unprettified string ') == 'Unprettified string'
    assert prettify('unprettified string') == 'Unprettified string'
    assert prettify('unprettified string, like this one,will be"prettified" .it\\\'s awesome!') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('unprettified string, like this one,will be"prettified" .it\\\'s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'