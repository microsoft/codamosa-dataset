

# Generated at 2022-06-24 02:09:25.698490
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:09:34.948370
# Unit test for function slugify
def test_slugify():
    # Test case 1
    string = 'Top 10 Reasons To Love Dogs!!!'
    res = slugify(string)
    exp = 'top-10-reasons-to-love-dogs'
    print(string)
    print(res)
    print(exp)

    # Test case 2
    string = 'Mönstér Mägnët'
    res = slugify(string)
    exp = 'monster-magnet'
    print(string)
    print(res)
    print(exp)

    # Test case 3
    string = 'list of 100 things'
    res = slugify(string)
    exp = 'list-of-100-things'
    print(string)
    print(res)
    print(exp)

#test_slugify()


# Generated at 2022-06-24 02:09:41.376867
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert isinstance(__RomanNumbers.encode(1),str)
    assert isinstance(__RomanNumbers.decode('I'),int)

if __name__ == '__main__':
    try:
        test___RomanNumbers()
    except AssertionError:
        print('AssertionError')
    else:
        print('Success')


# PUBLIC API



# Generated at 2022-06-24 02:09:46.108494
# Unit test for function slugify
def test_slugify():
	assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
	assert slugify('Mönstér Mägnët') == 'monster-magnet'
	assert slugify('The dog is öne of my favorite animals') == 'the-dog-is-öne-of-my-favorite-animals'

test_slugify()



# Generated at 2022-06-24 02:09:47.229514
# Unit test for function decompress
def test_decompress():
    assert decompress('this is a stupid test') == ''
    assert decompress('my name is Ali') == ''
    assert decompress('hey You!') == ''


# Generated at 2022-06-24 02:09:48.751998
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hello world') == 'dlrow olleh'



# Generated at 2022-06-24 02:09:57.714173
# Unit test for function roman_decode
def test_roman_decode():
    assert __roman_decode('VII') == 7
    assert __roman_decode('MMDCCLXXVII') == 2777
    assert __roman_decode('XXXII') == 32
    assert __roman_decode('MMMCDI') == 3409
    assert __roman_decode('MCCCXXI') == 1321
    try:
        __roman_decode('MCCCCXXI')
        raise AssertionError('Decoding must fail because of exceeding upper limit (3999)')
    except InvalidInputError as e:
        pass
    
    

# Generated at 2022-06-24 02:10:04.978882
# Unit test for function strip_margin
def test_strip_margin():
  assert(strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
''')
  assert(strip_margin('''
                        line 1
                          |line 2
                        line 3
                        ''') == '''
line 1
|line 2
line 3
''')
  assert(strip_margin('''
                        line 1
                        line 2
                          |line 3
                        ''') == '''
line 1
line 2
|line 3
''')

test_strip_margin()
 

# Generated at 2022-06-24 02:10:07.527744
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELLO') == 'OLLEH'
    assert reverse('HellO') == 'OllEh'
    assert reverse('123') == '321'
    assert reverse('') == ''
    assert reverse('   ') == '   '



# Generated at 2022-06-24 02:10:09.876879
# Unit test for function prettify
def test_prettify():
    test_ok = """
    string = ' unprettified string ,, like this one,will be"prettified" .it\\' s awesome! '
    expected = 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify(string) == expected
    """
    return test_ok



# Generated at 2022-06-24 02:10:17.829112
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut' \
        ' labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut' \
        ' aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum' \
        ' dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui' \
        ' officia deserunt mollit anim id est laborum.'

    compressed_string = __StringCompressor.compress(original_string)

   

# Generated at 2022-06-24 02:10:20.200637
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    try:
        reverse(1)
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:10:26.737640
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_blue', True, '_') == 'TheSnakeIsBlue'
    assert snake_case_to_camel('the_snake_is_green', False, '_') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the#snake#is#green', True, '#') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:10:37.348909
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(15) == 'XV'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers

# Generated at 2022-06-24 02:10:41.119540
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # call this last to avoid breaking of other unit tests due to error thrown here
    if not isinstance(__RomanNumbers.__init__, staticmethod):
        raise RuntimeError('__RomanNumbers.__init__ must be a static method!')

test___RomanNumbers()



# Generated at 2022-06-24 02:10:45.125283
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('I’m on a horse') == 'Im on a horse'
    assert asciify('ﬁ') == ''


# Generated at 2022-06-24 02:10:51.889916
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    # given
    input_string = 'ThisIsACamelStringTest'
    separator = '_'
    # when
    output = camel_case_to_snake(input_string, separator)
    # then
    expected = 'this_is_a_camel_string_test'
    assert output == expected



# Generated at 2022-06-24 02:10:54.420620
# Unit test for function reverse
def test_reverse():
    assert reverse('Hello World!') == '!dlroW olleH'
    assert reverse('') == ''
    assert reverse(' ') == ' '



# Generated at 2022-06-24 02:11:00.115784
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse(' ') == ' '
    assert reverse('') == ''
    assert reverse(123) == '321'
    assert reverse('hello world') == 'dlrow olleh'



# Generated at 2022-06-24 02:11:01.909517
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
line 1
line 2
line 3
''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:11:04.777224
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:11:05.603240
# Unit test for function decompress
def test_decompress():
    assert decompress('aGVsbG8gd2VsdA==') == 'hello welt'



# Generated at 2022-06-24 02:11:10.996124
# Unit test for function decompress

# Generated at 2022-06-24 02:11:14.277076
# Unit test for function slugify
def test_slugify():
    strings = {
        'Top 10 Reasons To Love Dogs!!!': 'top-10-reasons-to-love-dogs',
        'Mönstér Mägnët': 'monster-magnet',
        'The über-punctuation test!': 'the-uber-punctuation-test'
    }
    for input_str, expected_output in strings.items():
        assert slugify(input_str) == expected_output
        assert slugify(input_str, '_') == expected_output.replace('-', '_')

test_slugify()
print('Passed!')


# Generated at 2022-06-24 02:11:20.562694
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('a') == 'a'
    assert slugify('a-a') == 'a-a'
    assert slugify('a-a-a') == 'a-a-a'
    assert slugify('a a') == 'a-a'
    assert slugify('a   a') == 'a-a'
    assert slugify(' a a ') == 'a-a'
    assert slugify('a_a') == 'a-a'
    assert slugify('a__a') == 'a-a'
    assert slugify('a___a') == 'a-a'
    assert slugify

# Generated at 2022-06-24 02:11:24.798252
# Unit test for function strip_html
def test_strip_html():
    print(strip_html('<p>Hello <i>World!</i></p>'))
    print(strip_html('<p>Hello <i>World!</i></p>', True))
#test_strip_html()



# Generated at 2022-06-24 02:11:35.244263
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # check the existence of the encode() class method
    assert hasattr(__RomanNumbers, 'encode')

    # check the existence of the decode() class method
    assert hasattr(__RomanNumbers, 'decode')

    # check that encode() can handle some simple cases
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(400) == 'CD'

# Generated at 2022-06-24 02:11:41.447417
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode('10') == 'X'
    assert __RomanNumbers.decode('X') == 10

test___RomanNumbers()
del test___RomanNumbers


# PUBLIC API



# Generated at 2022-06-24 02:11:46.789562
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('y')
    assert not booleanize('false')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('n')
    assert not booleanize('ok')
    assert not booleanize('2')
    assert not booleanize('yess')
    assert not booleanize('yes1')
    assert not booleanize('')



# Generated at 2022-06-24 02:11:52.100765
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('THE_SNAKE_IS_GREEN') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', separator=' ') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:11:52.932084
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    string_compressor = __StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:12:03.102702
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', separator='-') == 'the-snake-is-green'
    assert snake_case_to_camel('this_is_a_snake', separator='_') == 'ThisIsASnake'
    assert snake_case_to_camel('TheSnakeIsGreen') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('theSnakeIsGreen') == 'TheSnakeIsGreen'

# Generated at 2022-06-24 02:12:05.251198
# Unit test for function shuffle
def test_shuffle():
    line = 'hello world'
    print('Original Value: ' + line)
    print('Shuffled Value: ' + shuffle(line))


# Generated at 2022-06-24 02:12:11.486842
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert sorted(shuffle('')) == sorted('')
    assert sorted(shuffle('hello')) == sorted('hello')
    assert sorted(shuffle('hello world')) == sorted('hello world')
    assert sorted(shuffle('Hello world')) == sorted('Hello world')

    out = set()
    for item in range(100):
        out.add(shuffle('Hello world'))

    assert len(out) > 1



# Generated at 2022-06-24 02:12:12.590891
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:12:22.718976
# Unit test for function asciify
def test_asciify():
    ascii_string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    assert asciify(ascii_string) == ascii_string
    non_ascii_string = "èéùúòóäåëýñÅÀÁÇÌÍÑÓË"
    assert asciify(non_ascii_string) == "eeuuooaaeynAAACIINOE"

test_asciify()


# Generated at 2022-06-24 02:12:27.727081
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') in [
        'l wodheorll',
        'lhdeorw ll',
        'leh orlwdl',
        'lhldorleo w',
        'l rdoehwoll',
        'e hwllodlr',
    ]



# Generated at 2022-06-24 02:12:28.261704
# Unit test for function slugify
def test_slugify():
    pass



# Generated at 2022-06-24 02:12:31.522510
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999


# STRING UTILS

# reverse string by just converting it to a list, reversing it and returning the joined list

# Generated at 2022-06-24 02:12:35.035379
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true') == True)
    assert (booleanize('YES') == True)
    assert (booleanize('nope') == False)
    

# Generated at 2022-06-24 02:12:46.767070
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'

    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'

    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(50) == 'L'

# Generated at 2022-06-24 02:12:50.717395
# Unit test for function compress
def test_compress():
    for i in range(1, 100):
        compressed = compress(str(i))
        assert i == int(decompress(compressed, encoding='utf-8'))



# Generated at 2022-06-24 02:13:00.430427
# Unit test for function compress
def test_compress():
    # Test empty string
    assert compress('') == ''

    # Test with "no compression"
    assert compress('1234567890') == '1234567890'

    # Test short strings with max compression
    assert compress('a') == 'YQ=='
    assert compress('aa') == 'YWE=\n'
    assert compress('aaa') == 'YWFh\n'
    assert compress('aaaa') == 'YWFhYQ==\n'
    assert compress('aaaaa') == 'YWFhYWE=\n'

    # Test long strings
    assert compress('1234567890') == 'xP+jbA==\n'
    assert compress('1234567890a') == 'xP+jbGFh\n'

# Generated at 2022-06-24 02:13:07.841280
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1638) == 'MDCXXXVIII'
    assert roman_encode('7') == 'VII'
    assert roman_encode('10') == 'X'
    assert roman_encode(1954) == 'MCMLIV'
    assert roman_encode('3999') == 'MMMCMXCIX'
    assert roman_encode(0) == '0'
    assert roman_encode(40) == 'XL'
    assert roman_encode('45') == 'XLV'
    assert roman_encode(68) == 'LXVIII'
    assert roman_encode('83') == 'LXXXIII'
    assert roman_encode(97) == 'XCVII'

# Generated at 2022-06-24 02:13:13.692673
# Unit test for function strip_margin
def test_strip_margin():
    test_string = '''
                   line 1
                   line 2
                   line 3
                   '''
    
    answer = '''
line 1
line 2
line 3
'''
    
    assert(strip_margin(test_string) == answer)

test_strip_margin()

# Generated at 2022-06-24 02:13:23.696665
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    assert slugify('Mönstér Mägnët', '.') == 'monster.magnet'
    assert slugify('the.the') == 'the-the'
    assert slugify('the-the') == 'the-the'
    assert slugify('the/the') == 'the-the'
    assert slugify('the_the') == 'the-the'
    assert slugify('the\\the') == 'the-the'
    assert slugify('the the') == 'the-the'


# Generated at 2022-06-24 02:13:35.544585
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter
    assert (formatter('test').format() == 'Test')
    assert (formatter('a b c').format() == 'A b c')
    assert (formatter('a   b   c').format() == 'A b c')
    assert (formatter('  a b.c ').format() == 'A b. c')
    assert (formatter(' i like pizza  ').format() == 'I like pizza')
    assert (formatter(' I like pizza!  ').format() == 'I like pizza!')
    assert (formatter('I like pizza!!!').format() == 'I like pizza!')
    assert (formatter('I like Pizza!!!').format() == 'I like pizza!')

# Generated at 2022-06-24 02:13:45.005507
# Unit test for function prettify
def test_prettify():
    tests = {
        '  hello this  is   a test': 'Hello this is a test',
        'unprettified string, like this one, will be "prettified". it\'s awesome!':
            'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    }

    for test_input, expected in tests.items():
        output = prettify(test_input)
        assert output == expected, 'Output "{}" does not match expected "{}"'.format(output, expected)



# Generated at 2022-06-24 02:13:50.313827
# Unit test for function roman_decode
def test_roman_decode():
    assert __RomanNumbers.decode("I") == 1
    assert __RomanNumbers.decode("II") == 2
    assert __RomanNumbers.decode("III") == 3
    assert __RomanNumbers.decode("v") == 5
    assert __RomanNumbers.decode("IX") == 9
    assert __RomanNumbers.decode("XXXI") == 31
    assert __RomanNumbers.decode("MMXII") == 2012
    assert __RomanNumbers.decode("") == 0
    assert __RomanNumbers.decode("asdhfasdhf") == 0


# Generated at 2022-06-24 02:13:57.917967
# Unit test for function prettify
def test_prettify():
    # This is an example of a valid test for the function above
    assert prettify('this is a test') == 'This is a test'

    # In this example we have a small bug in our code and the test is failing
    assert prettify('this is a test') == 'This is a test.'

# This is how unit tests should be automated
if __name__ == '__main__':
    test_prettify()



# Generated at 2022-06-24 02:14:01.399837
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('string to test') == 'string to test'
    assert strip_html('this is a <strong>test</strong>') == 'this is a '
    assert strip_html('<p>this is a <strong>test</strong></p>', keep_tag_content=True) == 'this is a test'



# Generated at 2022-06-24 02:14:06.747627
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'


# Generated at 2022-06-24 02:14:11.768480
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('ciao') == 'oaic'
    assert reverse('reverse') == 'esrever'
    assert reverse('') == ''



# Generated at 2022-06-24 02:14:21.459138
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # (1) Check empty input
    assert __StringFormatter(input_string = '').format() == ''

    # (2) Check uppercase-first-letter pattern
    assert __StringFormatter(input_string = 'test').format() == 'Test'
    assert __StringFormatter(input_string = 'test test').format() == 'Test Test'
    assert __StringFormatter(input_string = 'test Test').format() == 'Test Test'
    assert __StringFormatter(input_string = 'test test Test').format() == 'Test Test Test'
    assert __StringFormatter(input_string = 'test   Test').format() == 'Test Test'
    assert __StringFormatter(input_string = 'test TEST').format() == 'Test TEST'
    assert __StringFormatter(input_string = 'test -test').format()

# Generated at 2022-06-24 02:14:23.473876
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') != 'hello'
    assert len(shuffle('hello world')) == len('hello world')


# Generated at 2022-06-24 02:14:28.555617
# Unit test for function prettify

# Generated at 2022-06-24 02:14:39.886364
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    if not isinstance(__StringFormatter('ciao'), __StringFormatter):
        raise Exception('Error: class __StringFormatter constructor failed')
    if not isinstance(__StringFormatter('cia/o !!'), __StringFormatter):
        raise Exception('Error: class __StringFormatter constructor failed')
    if not isinstance(__StringFormatter('cia/o pippo!!'), __StringFormatter):
        raise Exception('Error: class __StringFormatter constructor failed')
    if not isinstance(__StringFormatter('pippo@pluto.it'), __StringFormatter):
        raise Exception('Error: class __StringFormatter constructor failed')
    if not isinstance(__StringFormatter('www.google.it'), __StringFormatter):
        raise Exception('Error: class __StringFormatter constructor failed')

# Generated at 2022-06-24 02:14:41.817706
# Unit test for function reverse
def test_reverse():
    assert reverse('abc') == 'cba'
    assert reverse('hello') == 'olleh'
    assert reverse('Hello, how are you?') == '?uoy era woh ,olleH'



# Generated at 2022-06-24 02:14:44.312240
# Unit test for function prettify
def test_prettify():
    print("Passed all the tests for function prettify")
test_prettify()


# Generated at 2022-06-24 02:14:51.170152
# Unit test for function strip_margin
def test_strip_margin():
    test_in="""\
    This is a test:
    | line 1
    | line 2
    | line 3
    """
    test_out="""\
    This is a test:
     line 1
     line 2
     line 3
    """
    assert(strip_margin(test_in) == test_out)
# end unit test
    


# Generated at 2022-06-24 02:14:57.196386
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    
test_slugify()


# Generated at 2022-06-24 02:15:08.517846
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    test_strings_to_test = [
        ("the_snake_is_green", "TheSnakeIsGreen"),
        ("the_snake__is_green", "TheSnakeIsGreen"),
        ("the_snake_is_green_", "TheSnakeIsGreen"),
    ]
    for input_tuple in test_strings_to_test:
        result = snake_case_to_camel(input_tuple[0])
        if result == input_tuple[1]:
            print("Passed test for input: " + input_tuple[0])
        else:
            print("Failed test for input: " + input_tuple[0])

# Main function which runs all tests for snake_case_to_camel()

# Generated at 2022-06-24 02:15:12.005039
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('a') == 'a'
    assert reverse('') == ''



# Generated at 2022-06-24 02:15:13.630262
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóíñçòó') == 'eeuuooincoo'



# Generated at 2022-06-24 02:15:16.479881
# Unit test for function strip_margin
def test_strip_margin():
    # Usage example of strip_margin()
    expected_value = '''
line 1
line 2
line 3
'''

    input_string = '''
              line 1          
              line 2
            line 3
'''

    actual_value = strip_margin(input_string)
    assert expected_value == actual_value



# Generated at 2022-06-24 02:15:19.091314
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == shuffle('hello world')
#     assert shuffle('hello world') != 'hello world'
    assert is_string(shuffle('hello world'))
    assert len(shuffle('hello world')) == len('hello world')

test_shuffle()



# Generated at 2022-06-24 02:15:24.344896
# Unit test for function decompress
def test_decompress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original1 = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed1 = compress(original1)
    # decompressed should be equal to original
    decompressed1 = decompress(compressed1)
    if original1 == decompressed1:
        print('decompress function: test passed!')
        return True
    print('decompress function: test failed!')
    return False


# Generated at 2022-06-24 02:15:29.902891
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()


# Generated at 2022-06-24 02:15:31.961905
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:15:35.141052
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('L') == 50
    assert roman_decode('XL') == 40
    assert roman_decode('LXVI') == 66
    assert roman_decode('MDCLXVI') == 1666

test_roman_decode()

# Generated at 2022-06-24 02:15:40.653821
# Unit test for function asciify
def test_asciify():
    str = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    ascii_string = asciify(str)
    if 'è' not in ascii_string:
        print('è')
    if 'é' not in ascii_string:
        print('é')
    if 'ù' not in ascii_string:
        print('ù')
    if 'ú' not in ascii_string:
        print('ú')
    if 'ò' not in ascii_string:
        print('ò')
    if 'ó' not in ascii_string:
        print('ó')
    if 'ä' not in ascii_string:
        print('ä')

# Generated at 2022-06-24 02:15:48.599296
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    # The compressed string should be shorter than the original one
    assert len(original) > len(compressed), 'Compressed string should be shorter than the original one'

    # Compressed and decompressed strings should be identical
    assert original == decompress(compressed), 'Original and decompressed strings should be identical'



# Generated at 2022-06-24 02:15:57.763943
# Unit test for function prettify

# Generated at 2022-06-24 02:15:59.697391
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:16:06.356424
# Unit test for function strip_margin
def test_strip_margin():
    # Check if the result is a string
    assert is_string(strip_margin('''
                    line 1
                    line 2
                    line 3
    '''))
    # Check if the result has no left margins
    assert strip_margin('''
                    line 1
                    line 2
                    line 3
    ''') == '''
line 1
line 2
line 3
'''
test_strip_margin()

# Generated at 2022-06-24 02:16:13.666904
# Unit test for function roman_decode
def test_roman_decode():

    # Check the test input against the expected result
    assert roman_decode('MDCCCCX') == 1910
    # Check the test input against the expected result
    assert roman_decode('CM') == 900
    # Check the test input against the expected result
    assert roman_decode('MMDCLXXVI') == 2676
    # Check the test input against the expected result
    assert roman_decode('MDCCCCIV') == 1904
    # Check the test input against the expected result
    assert roman_decode('MMDCCLXVI') == 2766
    # Check the test input against the expected result
    assert roman_decode('MMMMDCLXXXXVIII') == 4858
    # Check the test input against the expected result
    assert roman_decode('MDCCCCXXXIV') == 1934
    # Check

# Generated at 2022-06-24 02:16:15.981672
# Unit test for function reverse
def test_reverse():
    out = reverse('hello')
    assert out == 'olleh'


# Generated at 2022-06-24 02:16:21.432194
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
    line 1
    line 2
    line 3
    '''

test_strip_margin()


# Generated at 2022-06-24 02:16:22.417261
# Unit test for function decompress
def test_decompress():
    assert decompress(compress('HELLO WORLD')) == 'HELLO WORLD'
    
    

# Generated at 2022-06-24 02:16:27.953409
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:16:29.472152
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert isinstance(__StringCompressor, object)


# PUBLIC API



# Generated at 2022-06-24 02:16:34.312394
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '|') == 'this|is|a|camel|string|test'


# Generated at 2022-06-24 02:16:42.831675
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert not booleanize('nope')
    assert booleanize('YES')
    # invalid inputs check
    assert not booleanize('')
    assert not booleanize('False')
    assert not booleanize('0')
    assert not booleanize('n')
    assert not booleanize('no')
    assert not booleanize(1)
    assert not booleanize(False)
    assert not booleanize(0)
    try:
        booleanize(None)
        assert False
    except InvalidInputError as e:
        assert is_none(e.value)
    try:
        booleanize([])
        assert False
    except InvalidInputError as e:
        assert e.value == []

# Unit tests for function slugify

# Generated at 2022-06-24 02:16:52.162148
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_case_string_test"
    assert camel_case_to_snake("thisIsACamelStringTest") == "this_is_a_camel_case_string_test"
    assert camel_case_to_snake("this_is_a_snake_string_test") == "this_is_a_snake_string_test"
    return True
print("Unit test for function camel_case_to_snake", test_camel_case_to_snake())



# Generated at 2022-06-24 02:16:57.996634
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('world') == 'dlrow'
    assert reverse('1') == '1'
    assert reverse('1234') == '4321'
    assert reverse('') == ''
    assert reverse(True) == 'eurt'
    assert reverse(1) == '1'
    assert reverse(2.5) == '5.2'



# Generated at 2022-06-24 02:17:03.388524
# Unit test for function decompress

# Generated at 2022-06-24 02:17:11.029015
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.__require_valid_input_and_encoding(input_string='',
                                              encoding='utf-8') == ValueError
    assert __StringCompressor.__require_valid_input_and_encoding(input_string='Hello',
                                              encoding='utf-8') != ValueError
    assert __StringCompressor.__require_valid_input_and_encoding(input_string='',
                                              encoding='utf-8') == ValueError


# PUBLIC API


# noinspection PyUnusedLocal

# Generated at 2022-06-24 02:17:22.846843
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XIV') == 14
    assert roman_decode('XIX') == 19
    assert roman_decode('XX') == 20
    assert roman_decode('XXX') == 30
    assert roman_decode('XLI') == 41
    assert roman_decode('L') == 50


# Generated at 2022-06-24 02:17:31.834965
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('theSNAKEisGREEN') == 'TheSNAKEisGREEN'
    assert snake_case_to_camel('123456Test') == '123456Test'
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', False) == 'test'

# Generated at 2022-06-24 02:17:35.139147
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('spam') == 'eJzLSM3JTc0qBAAAAAAAA'
    assert __StringCompressor.decompress(__StringCompressor.compress('spam')) == 'spam'


# PUBLIC API



# Generated at 2022-06-24 02:17:39.653444
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('TRUE') == True
    assert booleanize('True') == True
    assert booleanize('TRuE') == True

    assert booleanize('1') == True
    assert booleanize('01') == True
    assert booleanize('1.1') == True
    assert booleanize('1.1.1') == True

    assert booleanize('yes') == True
    assert booleanize('YeS') == True

    assert booleanize('y') == True
    assert booleanize('Y') == True

    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('') == False
    assert booleanize(None) == False



# Generated at 2022-06-24 02:17:42.143623
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:17:52.593596
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('foo\n  bar') == 'foo\nbar'
    assert strip_margin('''
  |foo
  |bar
  |baz
  |''') == 'foo\nbar\nbaz'
    assert strip_margin('  foo bar\n    baz') == 'foo bar\n  baz'
    assert strip_margin('  foo  \n  bar') == 'foo  \nbar'
    assert strip_margin('  foo  \n  bar\nbaz') == 'foo  \nbar\nbaz'
    assert strip_margin('  foo  \n  bar  \n  baz') == 'foo  \nbar  \nbaz'

# Generated at 2022-06-24 02:18:03.340781
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('1') == True
    assert booleanize('True') == True
    assert booleanize('Yes') == True
    assert booleanize('Y') == True
    assert booleanize('1') == True
    assert booleanize('false') == False
    assert booleanize('False') == False
    assert booleanize('yes1') == False
    assert booleanize('y1') == False
    assert booleanize('yest') == False
    assert booleanize('tr') == False
    assert booleanize('tw') == False
    assert booleanize('0') == False
    assert booleanize(None) == False
    assert booleanize(0) == False
    assert booleanize('2') == False

# Generated at 2022-06-24 02:18:08.147631
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-case-string-test'



# Generated at 2022-06-24 02:18:08.890362
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7



# Generated at 2022-06-24 02:18:13.156158
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False) == 'thisIsATest'
    assert snake_case_to_camel('this-is-a-test', separator='-') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False, separator='-') == 'thisIsATest'



# Generated at 2022-06-24 02:18:16.872297
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()


# Generated at 2022-06-24 02:18:25.795778
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'
    assert __RomanNumbers.encode(12) == 'XII'
    assert __Roman

# Generated at 2022-06-24 02:18:31.617730
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode('1969') == 'MCMLXIX'
    assert __RomanNumbers.decode('MCMLXIX') == 1969
test___RomanNumbers()


# PUBLIC API



# Generated at 2022-06-24 02:18:38.192840
# Unit test for function strip_margin
def test_strip_margin():
    input_string='''
                    line 1
                    line 2
                    line 3
                 '''
    out='\nline 1\nline 2\nline 3\n'
    assert strip_margin(input_string)==out
    return
#

# Generated at 2022-06-24 02:18:50.759631
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    t1 = __StringFormatter('Ciao, come stai? ciao chiara ciao..')
    assert t1.format() == 'Ciao, come stai? Ciao chiara ciao..'

    t2 = __StringFormatter('ciao, Ciao, Come stai? sono  io  e ti faccio un regalo.  ')
    assert t2.format() == 'Ciao, ciao, come stai? Sono io e ti faccio un regalo.'

    t3 = __StringFormatter('prova, prova  ,prova   .....')
    assert t3.format() == 'Prova, prova, prova .....'

    t4 = __StringFormatter('ciao, ciao. Ciao.ciao Ciao! Ciao? Ciao; Ciao: Ciao-')

# Generated at 2022-06-24 02:18:52.821553
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    compressor = __StringCompressor()
    assert compressor != None

test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:19:03.495458
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # setup
    formatted = __StringFormatter('  I   want   to  eat   something    tasty    ').format()
    assert formatted == 'I want to eat something tasty'

    formatted = __StringFormatter('  I   want   to  eat   something    tasty@ a  bar   ').format()
    assert formatted == 'I want to eat something tasty@ a bar'

    # executes a lot of differents patterns and checks if they are all formatted correctly
    formatted = __StringFormatter('I want to eat something tasty').format()
    assert formatted == 'I want to eat something tasty'

    formatted = __StringFormatter('I  want to eat something tasty').format()
    assert formatted == 'I want to eat something tasty'

    formatted = __StringFormatter('I want  to eat something tasty').format()

# Generated at 2022-06-24 02:19:06.905694
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)

    assert original == decompressed


# Generated at 2022-06-24 02:19:11.294576
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello') == shuffle('hello')
    # test with empty string
    assert shuffle('') == ''
    # test with a sentence
    assert shuffle('hello world') == shuffle('hello world')



# Generated at 2022-06-24 02:19:12.523141
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:19:14.521651
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(__StringCompressor.compress("hello world")) == "hello world"


# PUBLIC API



# Generated at 2022-06-24 02:19:15.830436
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-24 02:19:16.381693
# Unit test for function decompress
def test_decompress():
    pass



# Generated at 2022-06-24 02:19:23.313191
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode('1234') == 'MCCXXXIV'
    assert __RomanNumbers.encode(1234) == 'MCCXXXIV'
    assert __RomanNumbers.encode('1') == 'I'
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode('3999') == 'MMMCMXCIX'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.encode('0') == ''
    assert __RomanNumbers.encode(0) == ''
    assert __RomanNumbers.encode('-1') == ''
    assert __RomanNumbers.encode(-1) == ''
    assert __RomanNumbers.encode('4000') == ''
    assert __RomanNumbers.encode(4000) == ''
