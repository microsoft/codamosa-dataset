

# Generated at 2022-06-24 02:09:30.244176
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(20) == 'XX'
    assert roman_encode(30) == 'XXX'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(60) == 'LX'
    assert roman_encode(70) == 'LXX'
    assert roman_encode(80) == 'LXXX'
    assert roman_encode(90) == 'XC'
    assert roman_encode(100) == 'C'
    assert roman_encode(200) == 'CC'


# Generated at 2022-06-24 02:09:31.559790
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'


# Generated at 2022-06-24 02:09:32.086344
# Unit test for function decompress
def test_decompress():
    assert True

# Generated at 2022-06-24 02:09:34.725264
# Unit test for function roman_decode
def test_roman_decode():
    assert(__RomanNumbers.decode("VII") == 7)
    assert(__RomanNumbers.decode("IX") == 9)
    assert(__RomanNumbers.decode("XIII") == 13)
    assert(__RomanNumbers.decode("XXXIX") == 39)
    assert(__RomanNumbers.decode("MMCXCIII") == 2193)
    assert(__RomanNumbers.decode("MMMMCMXCIX") == 4999)
    
test_roman_decode()



# Generated at 2022-06-24 02:09:45.402882
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'
    assert snake_case_to_camel('the snake is green', upper_case_first=False, separator=' ') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:09:47.169906
# Unit test for function decompress
def test_decompress():
    data = compress('This is a TEST!')
    result = decompress(data)
    assert result == 'This is a TEST!'



# Generated at 2022-06-24 02:09:48.208099
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') == 'dl hlwporleo'



# Generated at 2022-06-24 02:09:49.200809
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('abcdefgh') != 'abcdefgh'



# Generated at 2022-06-24 02:09:59.487072
# Unit test for function prettify

# Generated at 2022-06-24 02:10:06.030289
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3999) == 'MMMCMXCIX'


# Generated at 2022-06-24 02:10:11.458875
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:10:17.507201
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("thisIsACamelStringTest") == "this_is_a_camel_string_test"
test_camel_case_to_snake()



# Generated at 2022-06-24 02:10:20.726823
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('NO') == False



# Generated at 2022-06-24 02:10:30.468508
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    import pytest

    def test_valid_input():
        compressor = __StringCompressor()

    def test_invalid_input():
        with pytest.raises(InvalidInputError):
            __StringCompressor()()

    def test_invalid_encoding():
        with pytest.raises(ValueError):
            __StringCompressor()('test')

    def test_empty_input():
        with pytest.raises(ValueError):
            __StringCompressor()('', 'utf-8')

    def test_compress_invalid_compression_level():
        with pytest.raises(ValueError):
            __StringCompressor.compress('test', 'utf-8', 'a')

    def test_compress_valid_input():
        source = 'this is a test'

# Generated at 2022-06-24 02:10:40.532503
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = 'This IS A TEST STRING'
    f = __StringFormatter(s)
    assert s == f.input_string

    s = 'This string has two  consecutive  spaces  inside  it'
    f = __StringFormatter(s)
    assert s == f.input_string

    s = 'This has two consecutive uppercase letters (IS)'
    f = __StringFormatter(s)
    assert s == f.input_string

    s = 'This string HAS to be PREttified'
    f = __StringFormatter(s)
    assert s == f.input_string


# Generated at 2022-06-24 02:10:44.148317
# Unit test for function shuffle
def test_shuffle():
    input_value = 'hello world'
    result = shuffle(input_value)
    result2 = shuffle(input_value)
    assert is_string(result)
    assert result != input_value
    assert result != result2
    assert set(input_value) == set(result)
test_shuffle()



# Generated at 2022-06-24 02:10:55.145933
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    res = snake_case_to_camel('the_snake_is_green')
    assert res == 'TheSnakeIsGreen'
    res = snake_case_to_camel('the_snake_is_green', upper_case_first=False)
    assert res == 'theSnakeIsGreen'

    # invalid input
    res = snake_case_to_camel(None)
    assert res is None
    res = snake_case_to_camel(12345)
    assert res == 12345
    res = snake_case_to_camel([1, 2, 3])
    assert res == [1, 2, 3]

    # not a valid snake case string
    res = snake_case_to_camel('TheSnakeIsGreen')
    assert res == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:10:58.406094
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    assert(original != compressed)
    assert(len(original) > len(compressed))

    # the following should return the given string "original"
    assert(decompress(compressed) == original)



# Generated at 2022-06-24 02:11:05.580184
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:11:14.277059
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # Test 1
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    # Test 2
    assert snake_case_to_camel('the_snake_is_green', False) == 'theSnakeIsGreen'
    # Test 3
    assert snake_case_to_camel('the_snake_is_green', False, '-') == 'the-snake-is-green'
    # Test 4
    assert snake_case_to_camel('the_snake_is_green', True, '-') == 'The-Snake-Is-Green'



# Generated at 2022-06-24 02:11:26.468049
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    try:
        __StringCompressor.compress(1)
        assert False
    except InvalidInputError as e:
        assert e.message == 1

    try:
        __StringCompressor.compress('', compression_level= 'ciao')
        assert False
    except ValueError as e:
        assert e.args[0] == 'Invalid compression_level: it must be an "int" between 0 and 9'

    try:
        __StringCompressor.compress('')
        assert False
    except ValueError as e:
        assert e.args[0] == 'Input string cannot be empty'

    try:
        __StringCompressor.compress('ciao', encoding='')
        assert False
    except ValueError as e:
        assert e.args[0] == 'Invalid encoding'


# Generated at 2022-06-24 02:11:29.202349
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert reverse(None) != ''


# Generated at 2022-06-24 02:11:35.314163
# Unit test for function strip_margin
def test_strip_margin():
    original = r'''
    |line 1
    |line 2
    |line 3
    '''
    expected = r'''
    line 1
    line 2
    line 3
    '''
    assert expected == strip_margin(original)
if __name__ == '__main__':
    test_strip_margin()

# Generated at 2022-06-24 02:11:41.205542
# Unit test for function decompress

# Generated at 2022-06-24 02:11:47.942187
# Unit test for function prettify

# Generated at 2022-06-24 02:11:59.764710
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('foo').format() == 'Foo'
    assert __StringFormatter('foo bar').format() == 'Foo Bar'
    assert __StringFormatter('foo bar baz').format() == 'Foo Bar Baz'
    assert __StringFormatter('foo bar baz     ').format() == 'Foo Bar Baz'
    assert __StringFormatter(' foo bar baz').format() == 'Foo Bar Baz'
    assert __StringFormatter('     foo bar baz ').format() == 'Foo Bar Baz'
    assert __StringFormatter('fooBarBaz').format() == 'Foo Bar Baz'
    assert __StringFormatter('foo_bar_baz').format() == 'Foo Bar Baz'
    assert __StringFormatter('foo-bar-baz').format() == 'Foo Bar Baz'
   

# Generated at 2022-06-24 02:12:02.235566
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'Some string to be compressed'
    compressor = __StringCompressor()
    compressed_string = compressor.compress(input_string)
    assert len(compressed_string) < len(input_string)
    assert is_string(compressed_string)
    assert compressor.decompress(compressed_string) == input_string


# Generated at 2022-06-24 02:12:07.295614
# Unit test for function strip_html
def test_strip_html():
   return strip_html('test: <a href="foo/bar">click here</a>')



# Generated at 2022-06-24 02:12:19.817431
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('I am a good BOY')
    assert __StringFormatter('Very Cool')
    assert __StringFormatter('I Love You Baby')
    assert __StringFormatter('Born   in       the US')
    assert __StringFormatter('Buy     some     chocolate')
    assert __StringFormatter('I had a long holiday')
    assert __StringFormatter('Donald Jr. Trump')
    assert __StringFormatter('The New York Times')
    assert __StringFormatter('He is the president')
    assert __StringFormatter('I have to go now')
    assert __StringFormatter('I love the __ the ocean')
    assert __StringFormatter('I am going to NY')
    assert __StringFormatter('I am a good BOY')
    assert __StringFormatter('I am a good BOY')
    assert __StringForm

# Generated at 2022-06-24 02:12:31.070606
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world').format() == 'Hello World'
    assert __StringFormatter('heLLo world').format() == 'Hello World'
    assert __StringFormatter('hello worlD').format() == 'Hello World'
    assert __StringFormatter('hello        world').format() == 'Hello World'
    assert __StringFormatter('hello,world').format() == 'Hello, World'
    assert __StringFormatter('hello , world').format() == 'Hello, World'
    assert __StringFormatter('hello, world').format() == 'Hello, World'
    assert __StringFormatter('hello,world ').format() == 'Hello, World'
    assert __StringFormatter('hello, world ').format() == 'Hello, World'

# Generated at 2022-06-24 02:12:41.328315
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest', separator='-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('thisIsACamelStringTest', separator='.') == 'this.is.a.camel.string.test'



# Generated at 2022-06-24 02:12:49.874385
# Unit test for function compress
def test_compress():
    from .data_providers import random_string
    from .data_validators import is_compressed
    from .log import log_test
    from .random import random_number
    from .testing import run_tests
    from .time import timer
    from .types import is_int
    from .types import is_string
    from .types import is_tuple
    from .types import min_max
    from .types import none_or

    def __test_compress(encoding, compression_level, string):
        t = timer()
        compressed_string = compress(string, encoding, compression_level)
        t.stop()

# Generated at 2022-06-24 02:12:56.454490
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('1234') == '4321'
    assert reverse('') == ''



# Generated at 2022-06-24 02:13:00.807473
# Unit test for function shuffle
def test_shuffle():
    input_string = "hello"
    assert shuffle(input_string) != input_string



# Generated at 2022-06-24 02:13:04.925457
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                line 1
                line 2
                line 3
                ''') == '''
line 1
line 2
line 3
'''
    assert strip_margin('''
                line 1
                line 2
                    line 3
                ''') == '''
line 1
line 2
    line 3
'''
    assert strip_margin('''
                line 1
                line 2
                line 3''') == '''
line 1
line 2
line 3'''

# Generated at 2022-06-24 02:13:10.435306
# Unit test for function asciify
def test_asciify():
    source_string = u'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    assert asciify(source_string) == 'eeuuooaaeynAAACIINOE'
    print("Test for function asciify passed")

test_asciify()


# Generated at 2022-06-24 02:13:18.304525
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'
    input_string2 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua!'

    encoded_input = __StringCompressor.compress(input_string)
    decoded_input = __StringCompressor.decompress(encoded_input)

    assert decoded_input == input_string
    assert encoded_input != input_string
    assert is_string(encoded_input)

# PUBLIC API



# Generated at 2022-06-24 02:13:23.662694
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    original_string = 'Hello world! This is a simple unit test!'
    encoded_string = __StringCompressor.compress(original_string, compression_level=6)
    decoded_string = __StringCompressor.decompress(encoded_string)

    assert original_string == decoded_string


# PUBLIC API IMPLEMENTATION



# Generated at 2022-06-24 02:13:29.685252
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('True') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('ok') == False
    assert booleanize('ko') == False


# Generated at 2022-06-24 02:13:31.455535
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(0) == ''

test_roman_encode()


# Generated at 2022-06-24 02:13:34.241004
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('Abc D  e  f_').format() == 'Abc D E F'


# END PRIVATE API



# Generated at 2022-06-24 02:13:37.043636
# Unit test for function decompress
def test_decompress():
    data = '{"name":"paul","age":72,"city":"Los Angeles"}'
    d = compress(data)
    assert decompress(d) == data
test_decompress()


# Generated at 2022-06-24 02:13:45.357282
# Unit test for function shuffle
def test_shuffle():
    l = []
    for i in range(10):
        s = ('hello world ') # + str(i)
        l.append(shuffle(s))
        print(s)

    all_different = True
    for i in range(1, len(l)):
        if l[i] == l[i-1]:
            print('ERROR, two shuffles are the same:')
            print(l[i])
            print(l[i-1])
            all_different = False

    assert all_different

test_shuffle()


# Generated at 2022-06-24 02:13:49.415805
# Unit test for function strip_margin
def test_strip_margin():
    test_ex = '''
        |This is a test
        |      This is a test 2
        |
        |      This is a test 3
        '''
    test_ex_1 = strip_margin(test_ex)
    assert test_ex_1 == '''
This is a test
This is a test 2

This is a test 3
'''

test_strip_margin()



 

# Generated at 2022-06-24 02:13:55.417104
# Unit test for function slugify
def test_slugify():
        assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
        assert slugify("Mönstér Mägnët") == 'monster-magnet'

test_slugify()


# Generated at 2022-06-24 02:13:57.992058
# Unit test for function slugify
def test_slugify():
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Mönstér Mägnët') != 'monster-magnet-'


# Generated at 2022-06-24 02:13:59.880976
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    assert not reverse(1)


# Generated at 2022-06-24 02:14:03.441654
# Unit test for function strip_margin
def test_strip_margin():
    s = '''
        |line1
        | line2
        |  line3
        |   line4
        '''
    s = strip_margin(s)
    assert (s=='''
    line1
    line2
    line3
    line4
    ''')
    pass


# Generated at 2022-06-24 02:14:08.247820
# Unit test for function strip_margin
def test_strip_margin():
  assert strip_margin('line 1\nline 2\nline 3') == '''
line 1
line 2
line 3
'''
  print("'strip_margin' test PASSED")
test_strip_margin()


# Generated at 2022-06-24 02:14:12.970562
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.compress('Hello World') == __StringCompressor.compress('Hello World')
    assert __StringCompressor.decompress('BAMAwYEAkCYAAQZRAAU=') == 'Hello World'
    assert __StringCompressor.decompress('BAMAwYEAkCYAAQZRAAU=') == 'Hello World'
    assert __StringCompressor.decompress('BAMAwYEAkCYAAQZRAAU=') == __StringCompressor.compress('Hello World')
    assert __StringCompressor.decompress('BAMAwYEAkCYAAQZRAAU=') == __StringCompressor.compress('Hello World')
    assert __StringCompressor.decompress('BAMAwYEAkCYAAQZRAAU=')

# Generated at 2022-06-24 02:14:22.487347
# Unit test for function decompress
def test_decompress():
    """
    Unit test for function `decompress`.
    """
    assert 'foo' == decompress('eJwLwA8KAAADACgAAAA=')
    assert 'bar' == decompress('eJwLcA8KAAADACgAAAA=')
    assert 'foo bar' == decompress('eJwLcA8KAAADACgAAAA=', 'cp1251')
    assert 'foo' == decompress('eJwLcA8KAAADACgAAAA=', 'cp1251')



# Generated at 2022-06-24 02:14:27.718370
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert original != compressed
    decompressed = decompress(compressed)
    assert original == decompressed



# Generated at 2022-06-24 02:14:29.597224
# Unit test for function shuffle
def test_shuffle():
    init_string = 'hello world'
    shuffled = shuffle(init_string)
    assert(len(shuffled) == len(init_string))
    assert(shuffled != init_string)
    assert(len(set(init_string).intersection(set(shuffled))) == len(init_string))



# Generated at 2022-06-24 02:14:34.593220
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('hellło') == 'ołleh'
    assert reverse('') == ''
    assert reverse(666) == ''



# Generated at 2022-06-24 02:14:41.929022
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel("test_test_test") == "testTestTest"
    assert snake_case_to_camel("test_test_test", False) == "testTestTest"
    assert snake_case_to_camel("test_test_test", True) == "TestTestTest"
    assert snake_case_to_camel("test__test_test", True) == "TestTestTest"
    assert snake_case_to_camel("test__test_test", False) == "testTestTest"
    assert snake_case_to_camel("test__test_test", True, '-') == "TestTestTest"
    assert snake_case_to_camel("test__test_test", False, '-') == "testTestTest"

# Generated at 2022-06-24 02:14:45.657846
# Unit test for function roman_decode
def test_roman_decode():
    try:
        assert roman_decode('VII')==7
    except AssertionError:
        print("error")

# Generated at 2022-06-24 02:14:57.703941
# Unit test for constructor of class __StringFormatter

# Generated at 2022-06-24 02:15:00.882999
# Unit test for function asciify
def test_asciify():
    if asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE':
        print('Test 1: OK')
    else:
        print('Test 1: KO')

test_asciify()



# Generated at 2022-06-24 02:15:09.769076
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input = 'foo'
    output = __StringCompressor.compress(input)

    assert __StringCompressor.decompress(output) == input

    # Should throw an exception
    try:
        __StringCompressor.compress(None)
        assert False
    except InvalidInputError:
        assert True

    # Should throw an exception
    try:
        __StringCompressor.compress(None)
        assert False
    except InvalidInputError:
        assert True

    # Should throw an exception
    try:
        __StringCompressor.compress('')
        assert False
    except ValueError:
        assert True

    # Should throw an exception
    try:
        __StringCompressor.compress('foo', None)
        assert False
    except ValueError:
        assert True

    # Should throw an exception

# Generated at 2022-06-24 02:15:15.756106
# Unit test for function strip_html
def test_strip_html():
    try:
        strip_html(None)
        assert False
    except InvalidInputError:
        assert True

    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:15:17.152746
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == "top-10-reasons-to-love-dogs"
    assert slugify("Mönstér Mägnët") == "monster-magnet"

# Generated at 2022-06-24 02:15:19.129227
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-24 02:15:22.744827
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('XXXIX') == 39
    assert roman_decode('MCXL') == 1140
    assert roman_decode('MCMXLIX') == 1949
    assert roman_decode('MMXIX') == 2019

# Generated at 2022-06-24 02:15:34.462391
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world!').format() == 'Hello World!'
    assert __StringFormatter('hello WORLD').format() == 'Hello World'
    assert __StringFormatter('hello  world').format() == 'Hello World'
    assert __StringFormatter('hello.. wOrld').format() == 'Hello World'
    assert __StringFormatter('hello...world').format() == 'Hello World'
    assert __StringFormatter('hello_world').format() == 'Hello World'
    assert __StringFormatter('hello_world_hi').format() == 'Hello World Hi'
    assert __StringFormatter('hello_world! hi').format() == 'Hello World Hi'
    assert __StringFormatter('hello# world').format() == 'Hello # World'
    assert __StringFormatter('hello@world').format() == 'Hello @ World'


# Generated at 2022-06-24 02:15:35.630671
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''



# Generated at 2022-06-24 02:15:37.533901
# Unit test for function strip_margin
def test_strip_margin():
    input = '''
                        line 1
                        line 2
                        line 3
                    '''
    output = '''
    line 1
    line 2
    line 3
    '''
    assert strip_margin(input) == output

# Generated at 2022-06-24 02:15:41.206025
# Unit test for function prettify
def test_prettify():
    expected_string='Unprettified string, like this one, will be "prettified". It\'s awesome!'

# Generated at 2022-06-24 02:15:47.857133
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    value = __StringCompressor.compress('bla bla bla')
    assert value == 'eJzLS8gsCgvLzHwMw0E6MwM'
    assert __StringCompressor.decompress(value) == 'bla bla bla'


# PUBLIC API



# Generated at 2022-06-24 02:15:57.365921
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello world!!!').format() == 'Hello world'
    assert __StringFormatter('hello WORLD!!!').format() == 'Hello world'
    assert __StringFormatter('hello   world!!!').format() == 'Hello world'
    assert __StringFormatter('hello--world!!!').format() == 'Hello world'
    assert __StringFormatter('hello_world!!!').format() == 'Hello world'
    assert __StringFormatter('hello_World!!!').format() == 'Hello World'
    assert __StringFormatter('hello_World.').format() == 'Hello World'
    assert __StringFormatter('hello_WorLd.').format() == 'Hello World'
    assert __StringFormatter('hello,World').format() == 'Hello, world'

# Generated at 2022-06-24 02:16:06.356276
# Unit test for function strip_html
def test_strip_html():
    """
    Unit test for method strip_html
    """
    test_input = 'test: <a href="foo/bar">click here</a>'
    test_output_without_content = 'test: '
    test_output_with_content = 'test: click here'

    assert strip_html(test_input) == test_output_without_content
    assert strip_html(test_input, True) == test_output_with_content



# Generated at 2022-06-24 02:16:10.407759
# Unit test for function strip_margin
def test_strip_margin():
    assert_equal(strip_margin('''
                        line 1
                        line 2
                        line 3
                    '''), '''
                        line 1
                        line 2
                        line 3
                    ''')



# Generated at 2022-06-24 02:16:21.006001
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I', 'Encode 1'
    assert roman_encode(2) == 'II', 'Encode 2'
    assert roman_encode(3) == 'III', 'Encode 3'
    assert roman_encode(4) == 'IV', 'Encode 4'
    assert roman_encode(5) == 'V', 'Encode 5'
    assert roman_encode(6) == 'VI', 'Encode 6'
    assert roman_encode(7) == 'VII', 'Encode 7'
    assert roman_encode(8) == 'VIII', 'Encode 8'
    assert roman_encode(9) == 'IX', 'Encode 9'

# Generated at 2022-06-24 02:16:26.159489
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("XXXVIII")==38
    assert roman_decode("MMXX")==2020
    assert roman_decode("LXXXIX")==89
    assert roman_decode("MMXX")==2020
    assert roman_decode("VI")==6
    assert roman_decode("MCXVIII")==1118
    assert roman_decode("VIII")==8
    assert roman_decode("MMXVIII")==2018
    assert roman_decode("XXX")==30
    assert roman_decode("II")==2
    assert roman_decode("MMXL")==2040
    assert roman_decode("III")==3
    assert roman_decode("MMXX")==2020
    assert roman_decode("LXXX")==80

# Generated at 2022-06-24 02:16:34.406825
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen' == 'theSnakeIsGreen' == 'TheSnakeIsgreen' == 'tHeSnaKeIsGreen' == 'the_snake_is_green'
    assert snake_case_to_camel('theSnakeIsGreen', False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', True, '-') == 'TheSnakeIsGreen'



# Generated at 2022-06-24 02:16:38.873182
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'


# Generated at 2022-06-24 02:16:41.036007
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('abcdef') != 'abcdef'



# Generated at 2022-06-24 02:16:52.204879
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == 'eeuuooaaeynAAACIINOE'
    assert 'x' in asciify("간격 추가하기 (아니면 줄리어지게 하기)")
    assert '간' not in asciify("간격 추가하기 (아니면 줄리어지게 하기)")

# Generated at 2022-06-24 02:16:56.986463
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input = 'hello world'
    expected = 'hello world'

    # compress input
    output = __StringCompressor.compress(input)

    # decompress output
    output = __StringCompressor.decompress(output)

    print(output)
    assert output == expected



# Generated at 2022-06-24 02:16:59.948934
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII')==7
    assert roman_decode('cmxl')==941
# Unit test ends


# Generated at 2022-06-24 02:17:03.297692
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('TRUE') is True
    assert booleanize('1') is True
    assert booleanize('Y') is True
    assert booleanize('YES') is True
    assert booleanize('nope') is False
    return True


# Generated at 2022-06-24 02:17:06.261072
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:17:09.749917
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test_str = '__test_string__'
    test_formatter = __StringFormatter(test_str)
    if not test_formatter.input_string == test_str:
        raise Exception('Instantiation of class __StringFormatter failed')



# Generated at 2022-06-24 02:17:17.898842
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake__is_green', separator="_") == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('MY_NAME_IS_PY', upper_case_first=False) == 'myNameIsPy'
    assert snake_case_to_camel('the-snake_is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

# Generated at 2022-06-24 02:17:22.388142
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    from .__test__.string_formatter_test import test_cases

    for test_case in test_cases:
        assert test_case['expected'] == __StringFormatter(test_case['input']).format()


# PUBLIC API



# Generated at 2022-06-24 02:17:28.606002
# Unit test for function slugify
def test_slugify():
    """
    Test for function slugify.
    """
    try:
        string = 'Top 10 Reasons To Love Dogs!!!'
        expected = slugify(string, separator='-')
        computed = 'top-10-reasons-to-love-dogs'
        assert expected == computed
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-24 02:17:34.364314
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('mio  pippo').input_string == 'mio  pippo'
    try:
        __StringFormatter(None)
        assert False
    except InvalidInputError as e:
        assert e.input == None
    try:
        __StringFormatter(12)
        assert False
    except InvalidInputError as e:
        assert e.input == 12
    try:
        __StringFormatter('')
        assert False
    except InvalidInputError as e:
        assert e.input == ''


# Generated at 2022-06-24 02:17:39.427053
# Unit test for function prettify
def test_prettify():
    s = ' unprettified string ,, like this one,will be"prettified" .it\\'
    assert prettify(s) == 'Unprettified string, like this one, will be "prettified". It\'s'



# Generated at 2022-06-24 02:17:44.394403
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-24 02:17:48.204682
# Unit test for function reverse
def test_reverse():
    # if __name__ == '__main__':
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:17:54.408421
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert isinstance(__RomanNumbers, type)
    assert isinstance(__RomanNumbers.__mappings, list)
    assert isinstance(__RomanNumbers.__reversed_mappings, list)
    assert isinstance(__RomanNumbers.__encode_digit, staticmethod)
    assert isinstance(__RomanNumbers.encode, staticmethod)
    assert isinstance(__RomanNumbers.decode, staticmethod)


# PUBLIC API

# Generated at 2022-06-24 02:18:04.431458
# Unit test for function prettify
def test_prettify():
    print("Should return the string as it is if is empty")
    assert prettify("") == ""

    print("Should return the string as it is if is not a string")
    assert prettify("test") == "test"

    print("Should return the string as it is if is already formatted")
    assert prettify("test: foo bar baz") == "test: foo bar baz"

    print("Should make the first letter uppercase if necessary")
    assert prettify("test string") == "Test string"

    print("Should make the letters after a dot, an exclamation mark or a question mark uppercase if necessary")

# Generated at 2022-06-24 02:18:11.041968
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('snake_case_string') == 'SnakeCaseString'
    assert snake_case_to_camel('snake_case_string', upper_case_first=False) == 'snakeCaseString'
    assert snake_case_to_camel('snake-case-string', separator='-') == 'SnakeCaseString'
    assert snake_case_to_camel('snake-case-string', upper_case_first=False, separator='-') == 'snakeCaseString'
    assert snake_case_to_camel('snake-case-string') == 'SnakeCaseString'
    assert snake_case_to_camel('snake_case_string') == 'SnakeCaseString'



# Generated at 2022-06-24 02:18:13.034769
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert "This_is_a_camel_case_string_test" == camel_case_to_snake("ThisIsACamelCaseStringTest")


# Generated at 2022-06-24 02:18:17.125553
# Unit test for function asciify
def test_asciify():
    input = 'èéùúòóäåëýñÅÀÁÇÌÍÑÓË'
    result = asciify(input)
    assert result == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:18:21.841120
# Unit test for function prettify
def test_prettify():
    print ("Testing prettify")
    print ("Prettify test 1")

# Generated at 2022-06-24 02:18:25.093437
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)



# Generated at 2022-06-24 02:18:36.139751
# Unit test for function roman_encode
def test_roman_encode():
    result = roman_encode('1')
    assert result == 'I'
    result = roman_encode('2')
    assert result == 'II'
    result = roman_encode('3')
    assert result == 'III'
    result = roman_encode('4')
    assert result == 'IV'
    result = roman_encode('5')
    assert result == 'V'
    result = roman_encode('6')
    assert result == 'VI'
    result = roman_encode('7')
    assert result == 'VII'
    result = roman_encode('8')
    assert result == 'VIII'
    result = roman_encode('9')
    assert result == 'IX'
    result = roman_encode('10')

# Generated at 2022-06-24 02:18:42.061052
# Unit test for function asciify
def test_asciify():
    print('Testing function asciify...')
    a = asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')
    print('\nasciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") ->', a)
    if a == 'eeuuooaaeynAAACIINOE':
        print('Test passed!')
    else:
        print('Test failed!')
# End def



# Generated at 2022-06-24 02:18:46.857354
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('| Line 1\n| Line 2') == 'Line 1\nLine 2'
    assert strip_margin('< Line 1\n< Line 2') == 'Line 1\nLine 2'
    assert strip_margin('| Line 1\n| Line 2\n| Line 3') == 'Line 1\nLine 2\nLine 3'
    assert strip_margin('| Line 1\n\t| Line 2') == 'Line 1\nLine 2'
    assert strip_margin('| Line 1\n|   Line 2') == 'Line 1\nLine 2'


# Generated at 2022-06-24 02:18:50.072536
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False
    assert booleanize('FALSE') == False
    assert booleanize('0') == False

test_booleanize()


# Generated at 2022-06-24 02:18:54.118138
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:18:57.035775
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert isinstance(__StringCompressor(), __StringCompressor)
    assert isinstance(__StringCompressor.compress, type(__StringCompressor.compress))
    assert isinstance(__StringCompressor.decompress, type(__StringCompressor.decompress))


# PUBLIC API



# Generated at 2022-06-24 02:19:05.414037
# Unit test for function booleanize
def test_booleanize():
    print("Testing function booleanize")
    assert booleanize("true")
    assert booleanize("True")
    assert booleanize("TRUE")
    assert booleanize("1")
    assert booleanize("Y")
    assert booleanize("YES")
    assert booleanize("Yes")
    assert booleanize("yes")
    assert not booleanize("false")
    assert not booleanize("False")
    assert not booleanize("FALSE")
    assert not booleanize("0")
    assert not booleanize("N")
    assert not booleanize("NO")
    assert not booleanize("No")
    assert not booleanize("no")




# Generated at 2022-06-24 02:19:10.669369
# Unit test for function shuffle
def test_shuffle():
    string = 'Hello World!'
    shuffled = shuffle(string)
    assert len(shuffled) == len(string)
    assert shuffled != string



# Generated at 2022-06-24 02:19:19.836437
# Unit test for function prettify