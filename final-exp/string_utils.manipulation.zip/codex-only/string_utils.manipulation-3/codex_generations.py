

# Generated at 2022-06-24 02:09:23.906143
# Unit test for function prettify
def test_prettify():
    test_string = ' unprettified string ,, like this one,will be"prettified" .it\' s awesome! '
    output_string ='Unprettified string, like this one, will be "prettified". It\'s awesome!'

    assert prettify(test_string) == output_string

test_prettify()



# Generated at 2022-06-24 02:09:26.077894
# Unit test for function roman_decode
def test_roman_decode():
    try:
        assert roman_decode('VII') == 7
    except:
        print ('Exception raised for test case: roman_decode(VII) == 7')


# Generated at 2022-06-24 02:09:35.519510
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    import unittest
    import os

    class Test__StringCompressor(unittest.TestCase):

        def test___init__(self):
            self.assertRaises(InvalidInputError, __StringCompressor, None)
            self.assertRaises(InvalidInputError, __StringCompressor, 123)
            self.assertRaises(ValueError, __StringCompressor, '')

            self.assertRaises(ValueError, __StringCompressor, 'test', None)
            self.assertRaises(ValueError, __StringCompressor, 'test', 123)

        def test_compress(self):
            self.assertRaises(InvalidInputError, __StringCompressor.compress, None)
            self.assertRaises(InvalidInputError, __StringCompressor.compress, 123)

# Generated at 2022-06-24 02:09:46.477543
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # Compress and decompress empty string
    compressed = __StringCompressor.compress('')
    decompressed = __StringCompressor.decompress(compressed)
    assert decompressed == ''

    # Compress and decompress single char string
    compressed = __StringCompressor.compress('a')
    decompressed = __StringCompressor.decompress(compressed)
    assert decompressed == 'a'

    # Encode and decode non empty string
    compressed = __StringCompressor.compress('abc')
    decompressed = __StringCompressor.decompress(compressed)
    assert decompressed == 'abc'

    # Encode and decode non empty string
    compressed = __StringCompressor.compress('lorem ipsum')
    decompressed = __StringCompressor.decompress(compressed)

# Generated at 2022-06-24 02:09:58.574588
# Unit test for function prettify

# Generated at 2022-06-24 02:10:01.318196
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert str(type(__StringFormatter("myString"))) == "<class '__main__.__StringFormatter'>"


# Generated at 2022-06-24 02:10:07.761609
# Unit test for function strip_margin
def test_strip_margin():
    """
    Tests strip_margin() function against multiple strings.
    """
    string_1 = '''
            line 1
            line 2
            line 3
        '''
    expected_1 = '''
        line 1
        line 2
        line 3
        '''
    actual_1 = strip_margin(string_1)
    assert(actual_1 == expected_1)

    string_2 = '''
            line 1
            line 2
            line 3
            '''
    expected_2 = '''
        line 1
        line 2
        line 3
            '''
    actual_2 = strip_margin(string_2)
    assert(actual_2 == expected_2)

    print('ok')


# Generated at 2022-06-24 02:10:17.687072
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("") == ""
    assert camel_case_to_snake("a") == "a"
    assert camel_case_to_snake("ab") == "ab"
    assert camel_case_to_snake("abc") == "abc"
    assert camel_case_to_snake("aAb") == "a_ab"
    assert camel_case_to_snake("aAbC") == "a_ab_c"
    assert camel_case_to_snake("AbC") == "ab_c"
    assert camel_case_to_snake("AbCd") == "ab_cd"
    assert camel_case_to_snake("AbCdE") == "ab_cd_e"

# Generated at 2022-06-24 02:10:28.635517
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Encode tests
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(11) == 'XI'

# Generated at 2022-06-24 02:10:30.868801
# Unit test for function asciify
def test_asciify():
    assert asciify('Munich, München') == 'Munich, Munchen'
    assert asciify('Bavaria, Bayern') == 'Bavaria, Bayern'


# Generated at 2022-06-24 02:10:33.352439
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-24 02:10:39.511031
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'

test_asciify()



# Generated at 2022-06-24 02:10:43.289183
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    f = __StringFormatter('ljknkvnew er')
    f.format()


# Generated at 2022-06-24 02:10:49.613273
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('V') == 5
    assert roman_decode('X') == 10
    assert roman_decode('L') == 50
    assert roman_decode('C') == 100
    assert roman_decode('D') == 500
    assert roman_decode('M') == 1000

    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9

    assert roman_decode('XIV') == 14

# Generated at 2022-06-24 02:10:51.644803
# Unit test for function slugify
def test_slugify():
    assert slugify('') == ''
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'

    
    
    
    


# Generated at 2022-06-24 02:10:55.389466
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode("2") == "II"
    assert roman_encode("23") == "XXIII"
    assert roman_encode("43") == "XLIII"
    assert roman_encode("143") == "CXLIII"
    assert roman_encode("3143") == "MMMCXLIII"

# Running the tests
test_roman_encode()



# Generated at 2022-06-24 02:11:04.952698
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.decode('i') == 1
    assert __RomanNumbers.decode('ii') == 2
    assert __RomanNumbers.decode('iii') == 3
    assert __RomanNumbers.decode('iv') == 4
    assert __RomanNumbers.decode('v') == 5
    assert __RomanNumbers.decode('vi') == 6
    assert __RomanNumbers.decode('vii') == 7
    assert __RomanNumbers.decode('viii') == 8
    assert __RomanNumbers.decode('ix') == 9
    assert __RomanNumbers.decode('x') == 10
    assert __RomanNumbers.decode('xl') == 40
    assert __RomanNumbers.decode('cxiv') == 114
    assert __RomanNumbers.decode('cix') == 109

# Generated at 2022-06-24 02:11:07.491441
# Unit test for function reverse
def test_reverse():
    outcome = reverse('hello')
    assert outcome == 'olleh', 'Expected "olleh", but got "{}"'.format(outcome)
    outcome = reverse('Hello, World!')
    assert outcome == '!dlroW ,olleH', 'Expected "!dlroW ,olleH", but got "{}"'.format(outcome)



# Generated at 2022-06-24 02:11:12.472370
# Unit test for function prettify
def test_prettify():
    # basic cases
    assert prettify('unprettified, string') == 'Unprettified, string'
    assert prettify('unprettified string') == 'Unprettified string'
    assert prettify('  unprettified string, with   multiple spaces') == 'Unprettified string, with multiple spaces'
    assert prettify('unprettified !string?with!multiple ! punctuation') == 'Unprettified! String? With! Multiple! Punctuation'
    assert prettify('unprettified  string    with multiple empty lines') == 'Unprettified string with multiple empty lines'
    assert prettify('unprettified string with wrong saxon genitive: "dog\' s first ball"') == 'Unprettified string with wrong saxon genitive: "dog\'s first ball"'

# Generated at 2022-06-24 02:11:15.202794
# Unit test for function decompress
def test_decompress():
    original = "abcdefghijklm"
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert original == decompressed

# Generated at 2022-06-24 02:11:21.465745
# Unit test for function compress
def test_compress():

    # test compress with default params
    assert compress('this is a test') == 'eJydVm1v2zYQ3qEFAza1fYFhUHGOR9YWyUQxHRhExx6U0Unw' \
                                         'q3woTqTunTl6cXS9z35nGdRZIKzrbk1s8ZpAj+u33Rmqqm' \
                                         'mqBq3VqxqQ2i2em7WzQDXPu+fa/P/Nzv9XNlZg'

    # test compress with different compression level

# Generated at 2022-06-24 02:11:27.638716
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<div>test</div>') == 'test'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('<strong>test</strong>', keep_tag_content=True) == 'test'
    assert strip_html('') == ''


# Generated at 2022-06-24 02:11:31.133629
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-24 02:11:36.989540
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)=='test: click here'
    assert strip_html('test: <a href="foo/bar">click here</a>')=='test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False)=='test: '
    # test with a couple of tags
    assert strip_html('test: <a href="foo/bar">click here</a> <p>and here</p>')=='test:  and here'


# Generated at 2022-06-24 02:11:40.558683
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
test_roman_decode()


# Generated at 2022-06-24 02:11:48.977063
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # init class
    cls = __RomanNumbers()

    test_numbers = [
        (1000, 'M'),
        (1312, 'MCCCXII'),
        (2980, 'MMCMLXXX'),
        (3999, 'MMMCMXCIX'),
        (2000, 'MM'),
        (2499, 'MMCDXCIX'),
        (2999, 'MMCMXCIX'),
        (1000, 'M'),
    ]

    for test_number, expected in test_numbers:
        assert cls.decode(expected) == test_number
        assert cls.encode(test_number) == expected


# wrap compress and decompress into their own decorators
#
# by doing this we also avoid to extend from _StringDecorator base class.
# This means that we can't use nice

# Generated at 2022-06-24 02:11:50.397235
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('hello') == 'olleh'
# end unit test for function reverse



# Generated at 2022-06-24 02:12:01.608342
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    for input_string in [
        '',
        'A',
        'Some text',
        'some text',
        'some text some more text',
        '   some text   some   more    text    ',
        '......some text....some....more....text....',
        '////some text//some/////more////text//',
        'some text.some more text.',
        'some text.some more text.some text.some more text.',
        'some text.some more text.some text.some more text.',
        'some text|some more text',
        'some text|some more text|some text|some more text',
    ]:
        assert __StringFormatter(input_string).format() == 'Some text some more text'



# Generated at 2022-06-24 02:12:06.084814
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('1') == True
    assert booleanize('TRUE') == True
    assert booleanize('YES') == True
    assert booleanize('Y') == True
    assert booleanize('123') == False
    assert booleanize('TRUE123') == False
    assert booleanize(1) == False
    assert booleanize(True) == False


# Generated at 2022-06-24 02:12:07.292382
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('LII')==52



# Generated at 2022-06-24 02:12:08.478871
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('MCC') == 1200
# End of unit test



# Generated at 2022-06-24 02:12:20.969338
# Unit test for function decompress
def test_decompress():
    try:
        decompress('word n0')
    except InvalidInputError:
        print("True")
    decompress('word n0')
    #decompress('','')


test_decompress()

test_remove_numbers()
test_remove_duplicates()
test_insert_in()
test_normalize()
test_remove_whitespaces()
test_remove_punctuation()
test_keep_only_numbers()
test_keep_only_letters()
test_keep_only_punctuation()
test_keep_only_whitespaces()
test_reverse()
test_rot_13()
test_is_number()
test_is_letter()
test_is_digit()
test_is_punctuation()
test_is_whitespace()
test_is_lower

# Generated at 2022-06-24 02:12:31.358135
# Unit test for function shuffle

# Generated at 2022-06-24 02:12:38.472698
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('XII') == 12
    assert roman_decode('XXII') == 22
    assert roman_decode('XLIX') == 49
    assert roman_decode('MDCCC') == 1800
    assert roman_decode('MMCMXCIX') == 2999



# Generated at 2022-06-24 02:12:48.659797
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    #
    # Invalid inputs
    #

    # missing input string
    try:
        __StringFormatter(None).format()
        assert False
    except InvalidInputError:
        pass

    # empty input string
    try:
        __StringFormatter('').format()
        assert False
    except ValueError:
        pass

    # invalid input type
    try:
        __StringFormatter(1).format()
        assert False
    except InvalidInputError:
        pass

    #
    # Uppercase first char
    #

    assert __StringFormatter('test').format() == 'Test'
    assert __StringFormatter('test with more words').format() == 'Test with more words'
    assert __StringFormatter('test with more words this time').format() == 'Test with more words this time'

    #
    # Remove

# Generated at 2022-06-24 02:12:52.290600
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():

    test_string = 'john.doe@example.com'
    formatter = __StringFormatter(test_string)

    assert formatter.input_string == test_string


# Generated at 2022-06-24 02:12:57.176762
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    line 1
    line 2
    line 3
    ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:13:01.790889
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_string = "    Hello    World    "
    f = __StringFormatter(input_string)
    assert f.input_string == "Hello World"



# PUBLIC API



# Generated at 2022-06-24 02:13:09.932316
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'
    assert __RomanNumbers.encode(1984) == 'MCMLXXXIV'
    assert __RomanNumbers.decode('MCMLXXXIV') == 1984
    assert __RomanNumbers.decode('MMMCMXCIX') == 3999


# PUBLIC API



# Generated at 2022-06-24 02:13:17.566998
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('  line 1\n  line 2') == 'line 1\nline 2'
    assert strip_margin('line 1\nline 2\n') == 'line 1\nline 2\n'
    assert strip_margin('line 1\nline 2\n\n') == 'line 1\nline 2\n\n'
    assert strip_margin('  line 1\n   line 2') == 'line 1\n line 2'
    assert strip_margin('  line 1\n    line 2') == 'line 1\n  line 2'
    assert strip_margin(' line 1\n\tline 2') == 'line 1\nline 2'



# Generated at 2022-06-24 02:13:19.408046
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'


# Generated at 2022-06-24 02:13:26.731497
# Unit test for function decompress
def test_decompress():
    return __StringCompressor.decompress("VU4DZABlAG4AQwBQAHIAbwBkACQASQA9ACIARgBzAGkAbgBnACIAPgAiACAAUwBvAGMAaABlAGEAYwB0AA==", "utf-8")


# Generated at 2022-06-24 02:13:39.326109
# Unit test for function prettify

# Generated at 2022-06-24 02:13:49.824957
# Unit test for function prettify
def test_prettify():
    assert prettify('Hello World!') == prettify(' hello world! ')
    assert prettify('Hello World') == prettify(' Hello World ')
    assert prettify(' Hello World!') == 'Hello World!'
    assert prettify('Hello World! ') == 'Hello World!'
    assert prettify('Hello World!') == 'Hello World!'
    assert prettify('Hello') == prettify(' Hello ')
    assert prettify('Hello') == 'Hello'
    assert prettify(' Hello') == 'Hello'
    assert prettify('Hello ') == 'Hello'
    assert prettify('Hello, World!') == 'Hello, World!'
    assert prettify('Hello , World!') == 'Hello, World!'
    assert prettify('Hello, World!') == prettify('Hello , World!')

# Generated at 2022-06-24 02:13:55.712869
# Unit test for function roman_encode
def test_roman_encode():
  assert roman_encode(2) == 'II'
  assert roman_encode(37) == 'XXXVII'
  assert roman_encode(2020) == 'MMXX'

test_roman_encode()




# Generated at 2022-06-24 02:13:57.917636
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('123') == '321'
    assert reverse('hello world!') == '!dlrow olleh'



# Generated at 2022-06-24 02:14:04.664789
# Unit test for function compress
def test_compress():

    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)

    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    assert compressed != original
    assert len(compressed) < len(original)

    assert original == decompress(compressed)



# Generated at 2022-06-24 02:14:15.283463
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(2) == 'II'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(20) == 'XX'
    assert __RomanNumbers.encode(30) == 'XXX'

# Generated at 2022-06-24 02:14:21.043427
# Unit test for function decompress
def test_decompress():
    import zlib
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert decompress(compressed) == original


# Generated at 2022-06-24 02:14:30.892895
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XX') == 20
    assert roman_decode('XXX') == 30
    assert roman_decode('XL') == 40
    assert roman_decode('L') == 50
    assert roman_decode('LX') == 60

# Generated at 2022-06-24 02:14:36.279728
# Unit test for function strip_html
def test_strip_html():
    assert strip_html(None) == None
    assert strip_html('test') == 'test'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:14:45.288745
# Unit test for function prettify

# Generated at 2022-06-24 02:14:52.598470
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    sf = __StringFormatter("i'm a string tO test")
    assertequals(sf.input_string, "i'm a string tO test")

    try:
        sf = __StringFormatter(12)
    except Exception as e:
        assertequals(e.args[0], "Invalid input, only strings are allowed")

    sf = __StringFormatter("")
    assertequals(sf.input_string, "")



# Generated at 2022-06-24 02:14:57.535575
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    source = "testing compression and decompression of strings"
    compressed_string = __StringCompressor.compress(source)
    decompressed_string = __StringCompressor.decompress(compressed_string)

    assert(source == decompressed_string)

# public api

# unit test

# Generated at 2022-06-24 02:15:03.955041
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:15:15.291099
# Unit test for function decompress
def test_decompress():
    # (1) INPUT STRING IS EMPTY
    try:
        decompress('')
        assert False, MALFORMED_STRING_ERROR
    except InvalidInputError:
        pass

    # (2) INPUT STRING IS NOT A COMPRESSED STRING
    try:
        decompress('my string')
        assert False, INVALID_COMPRESSION_ERROR
    except InvalidInputError:
        pass

    # (3) INPUT STRING IS A VALID COMPRESSED STRING

# Generated at 2022-06-24 02:15:16.418130
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert is_string(__StringFormatter('foo')) == True



# Generated at 2022-06-24 02:15:21.926355
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    if original == compress(compressed, 'utf-8'):
        print("Unit test for compress success!")
    else:
        print("Unit test for compress failed!")



# Generated at 2022-06-24 02:15:34.222786
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    single_space = ' '
    empty = ''
    double_space = '  '
    result = __StringFormatter(double_space).format()
    assert result == single_space
    result = __StringFormatter(single_space).format()
    assert result == single_space
    result = __StringFormatter(empty).format()
    assert result == empty
    result = __StringFormatter('Questa è una stringa trim').format()
    assert result == 'Questa è una stringa trim'
    result = __StringFormatter('Questa è una stringa trim ').format()
    assert result == 'Questa è una stringa trim'
    result = __StringFormatter(' Questa è una stringa trim ').format()
    assert result == 'Questa è una stringa trim'

# Generated at 2022-06-24 02:15:35.693672
# Unit test for function roman_decode
def test_roman_decode():
    should_be_7 = roman_decode("VII")
    assert should_be_7 == 7


# Generated at 2022-06-24 02:15:36.919722
# Unit test for function shuffle
def test_shuffle():
    output = shuffle('hello world')
    assert output != 'hello world'
test_shuffle()



# Generated at 2022-06-24 02:15:39.102894
# Unit test for function shuffle
def test_shuffle():
    input_string = "hello world"
    new_string = shuffle(input_string)
    assert isinstance(new_string, str)
    assert len(new_string) == len(input_string)
    assert new_string != input_string
test_shuffle()



# Generated at 2022-06-24 02:15:45.458690
# Unit test for function strip_margin
def test_strip_margin():
    # test code
    assert strip_margin('''
        | line 1
        | line 2
        | line 3
    ''').strip() == '''
        line 1
        line 2
        line 3
    '''.strip()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:15:49.770245
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    #assert roman_encode('0') == 'ValueError'
    assert roman_encode('4000') == 'OverflowError'



# Generated at 2022-06-24 02:15:52.972447
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__index_for_sign('L') == 1
    assert __RomanNumbers.__index_for_sign('M') == 3


# Generated at 2022-06-24 02:16:00.134811
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(1) == 'I'
    assert roman_encode(3) == 'III'
    assert roman_encode(4) == 'IV'
    assert roman_encode(5) == 'V'
    assert roman_encode(8) == 'VIII'
    assert roman_encode(9) == 'IX'
    assert roman_encode(10) == 'X'
    assert roman_encode(11) == 'XI'
    assert roman_encode(40) == 'XL'
    assert roman_encode(50) == 'L'
    assert roman_encode(90) == 'XC'

# Generated at 2022-06-24 02:16:04.976473
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    input_string = "  i'm learning  python regression and    unit.  "
    obj=__StringFormatter(input_string)
    assert obj.input_string=="  i'm learning  python regression and    unit.  "
    

# Generated at 2022-06-24 02:16:09.185754
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('V') == 5
    assert roman_decode('X') == 10
    assert roman_decode('IV') == 4
    assert roman_decode('VIII') == 8
    assert roman_decode('VII') == 7
    assert roman_decode('XII') == 12
    assert roman_decode('LXX') == 70
    assert roman_decode('CCX') == 210
    assert roman_decode('MCC') == 1200
    assert roman_decode('MMX') == 2010
    assert roman_decode('MMM') == 3000
    assert roman_decode('MMMM') == 0
    assert roman_decode('blabla') == 0

# Generated at 2022-06-24 02:16:16.629543
# Unit test for function slugify
def test_slugify():
    print('Test slugify')
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Pippo - pluto,Aaaaaa') == 'pippo-pluto-aaaaaa'
    assert slugify('Mnemo.sintesi') == 'mnemo-sintesi'
    assert slugify('Mnemo') == 'mnemo'
    assert slugify('AAAAA') == 'aaaaa'
    print('Test OK')
# Test to see if function slugify works well
test_slugify()


# Generated at 2022-06-24 02:16:24.792742
# Unit test for function roman_encode
def test_roman_encode():
    assert is_string(roman_encode(1))
    assert is_string(roman_encode('123'))
    assert is_string(roman_encode('4000'))
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode('3000') == 'MMM'
    assert roman_encode('3999') == 'MMMCMXCIX'


# Generated at 2022-06-24 02:16:36.412432
# Unit test for function strip_html
def test_strip_html():
    assert strip_html("l'orgueil est un défaut") == "l'orgueil est un défaut"
    assert strip_html("l'orgueil est un <a>défaut</a>") == "l'orgueil est un défaut"
    assert strip_html("l'orgueil est un <strong>défaut</strong>") == "l'orgueil est un défaut"
    assert strip_html("l'orgueil est un <b>défaut</b>") == "l'orgueil est un défaut"
    assert strip_html("l'orgueil est un <em>défaut</em>") == "l'orgueil est un défaut"

# Generated at 2022-06-24 02:16:45.037584
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('') == False
    assert booleanize('False') == False
    assert booleanize('false') == False
    assert booleanize('f') == False
    assert booleanize('FALSE') == False
    assert booleanize('F') == False
    assert booleanize('T') == True
    assert booleanize('t') == True
    assert booleanize('TRUE') == True
    assert booleanize('true') == True
    assert booleanize('No') == False
    assert booleanize('NO') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('N') == False
    assert booleanize('Y') == True
    assert booleanize('y') == True
    assert booleanize('YES') == True
    assert booleanize('yes') == True
    assert booleanize('0')

# Generated at 2022-06-24 02:16:46.750175
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print(original, compressed)
    decompressed = decompress(compressed)
    print(decompressed)
    assert original == decompressed



# Generated at 2022-06-24 02:16:49.154128
# Unit test for function shuffle
def test_shuffle():
    x = 'hello world'
    out = shuffle(x)
    print(x)
    print(out)
# test_shuffle()



# Generated at 2022-06-24 02:16:59.673245
# Unit test for function roman_decode
def test_roman_decode():
    """Tests for :func:`~roman_decode`"""

# Generated at 2022-06-24 02:17:01.148983
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    formatter = __StringFormatter(' foo.  bar  ')
    assert formatter.format() == 'Foo. Bar'


# PUBLIC API



# Generated at 2022-06-24 02:17:06.107338
# Unit test for function strip_margin
def test_strip_margin():
    original = """\
        |This is the first line
        |This is the second one
        |This is the third one""".stripMargin
    expected = """\
        |This is the first line
        |This is the second one
        |This is the third one""".stripMargin
    assert expected == strip_margin(original)


# Generated at 2022-06-24 02:17:15.672992
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('XII') == 12
    assert roman_decode('VIII') == 8
    assert roman_decode('XIV') == 14
    assert roman_decode('XXIX') == 29
    assert roman_decode('XLIX') == 49
    assert roman_decode('LII') == 52
    assert roman_decode('LXV') == 65
    assert roman_decode('CXX') == 120
    assert roman_decode('DCCCLXXXVIII') == 888
    assert roman_decode('MCCCXXXVII') == 1337
    assert roman_decode('MMXIX') == 2019
    assert roman_decode('MMMCMXCIX') == 3999
    assert roman

# Generated at 2022-06-24 02:17:20.724894
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # compress the string 'hello world!' into base64 and check output value
    output = __StringCompressor.compress('hello world!')
    assert output == 'eNrzXV1dT0nPzs7Ozs/PD8_LlIjBQA=', 'Invalid compressed string'
    
    # decompress previously compressed string and check output value
    output = __StringCompressor.decompress('eNrzXV1dT0nPzs7Ozs/PD8_LlIjBQA=')
    assert output == 'hello world!', 'Invalid decompressed string'



# PUBLIC API



# Generated at 2022-06-24 02:17:32.579088
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('   my home   is   beautiful   ').format() == 'My home is beautiful.'
    assert __StringFormatter('   my home   is   beautiful   ').format() == 'My home is beautiful.'
    assert __StringFormatter('   my home   is   beautiful.   ').format() == 'My home is beautiful.'
    assert __StringFormatter('   my home   is   beautiful.   ').format() == 'My home is beautiful.'
    assert __StringFormatter(' click here to read more.').format() == 'Click here to read more.'
    assert __StringFormatter(' click here to read more.').format() == 'Click here to read more.'
    assert __StringFormatter(' my home is beautiful.').format() == 'My home is beautiful.'

# Generated at 2022-06-24 02:17:34.380675
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''


# Generated at 2022-06-24 02:17:38.994790
# Unit test for function booleanize
def test_booleanize():
    # positive cases
    assert booleanize('true') == True
    assert booleanize('True') == True
    assert booleanize('1') == True
    assert booleanize('YES') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize(1) == True

    # negative cases
    assert booleanize('false') == False
    assert booleanize('False') == False
    assert booleanize('0') == False
    assert booleanize('NO') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('N') == False
    assert booleanize(0) == False



# Generated at 2022-06-24 02:17:45.190492
# Unit test for function compress
def test_compress():
    # pylint: disable=unused-variable
    binding = ""
    # pylint: enable=unused-variable
    n = 0
    for n in range(20):
        binding = binding + 'word n{} '.format(n)
    compressed = compress(binding, compression_level=0)
    decompressed = decompress(compressed)
    assert binding == decompressed



# Generated at 2022-06-24 02:17:48.779326
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('True') == True
    assert booleanize('1') == True
    assert booleanize('Yes') == True
    assert booleanize('Y') == True
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('n') == False



# Generated at 2022-06-24 02:17:56.631161
# Unit test for function booleanize
def test_booleanize():
    strings_true = ['true', 'True', 'TRUE', '1', 'yes', 'YES', 'Yes', 'y']
    strings_false = ['false', 'False', 'FALSE', '0', 'no', 'NO', 'No', 'n']

    for s in strings_true:
        assert booleanize(s)

    for s in strings_false:
        assert not booleanize(s)

if __name__ == '__main__':
    test_booleanize()

    # reverse
    assert reverse('hello') == 'olleh'
    assert reverse('h') == 'h'
    assert reverse('') == ''

    # camel_case_to_snake
    assert camel_case_to_snake('HelloWorld') == 'hello_world'

# Generated at 2022-06-24 02:18:05.896264
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter("  mr. o 'brien  ").format() == "Mr. O'Brien"
    assert __StringFormatter("  mr. o 'brien  ").format() == "Mr. O'Brien"
    assert __StringFormatter("  mr. o 'brien  ").format() == "Mr. O'Brien"
    assert __StringFormatter("supercalifragilisticexpialidocious mr. o 'brien").format() == "Supercalifragilisticexpialidocious Mr. O'Brien"
    assert __StringFormatter("https://www.google.com").format() == "https://www.google.com"
    assert __StringFormatter("http://www.google.com").format() == "http://www.google.com"

# Generated at 2022-06-24 02:18:08.337346
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert decompress(compressed) == original
    print('string module test is completed successfully')

# Generated at 2022-06-24 02:18:16.907774
# Unit test for function roman_encode
def test_roman_encode():
    for i in range(1, 3999):
        assert roman_encode(i) == ROMAN[i]
    for i in range(1, 3999):
        assert roman_encode(str(i)) == ROMAN[i]
    for i in range(1, 3999):
        assert roman_encode(target=int(i)) == ROMAN[i]
    assert roman_encode(4000) == ""
    assert roman_encode('4000') == ""
    assert roman_encode(target=4000) == ""
    assert roman_encode(target='4000') == ""
    assert roman_encode(0) == ""
    assert roman_encode('0') == ""
    assert roman_encode(target=0) == ""

# Generated at 2022-06-24 02:18:24.818639
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    from hamlish_jinja.hamlish_jinja import literals
    literals['hamlish_jinja/hamlish_jinja'] = literals['hamlish_jinja/hamlish_jinja'].replace('{{', '{{ ').replace('}}', ' }}').replace('{%', '{% ').replace('%}', ' %}')
    literals['hamlish_jinja/hamlish_jinja'] = literals['hamlish_jinja/hamlish_jinja'].replace('\n{%', '\n{% ').replace('%}\n', ' %}\n')
    literal = literals['hamlish_jinja/hamlish_jinja']
    string_formatter = __StringFormatter(literal)

# Generated at 2022-06-24 02:18:35.874179
# Unit test for function slugify
def test_slugify():
    assert slugify('The rain in spain stays mainly in the plain') == 'the-rain-in-spain-stays-mainly-in-the-plain'
    assert slugify('The rain, in spain, stays mainly in the plain') == 'the-rain-in-spain-stays-mainly-in-the-plain'
    assert slugify('The    rain     in      spain   stays           mainly in the plain') == 'the-rain-in-spain-stays-mainly-in-the-plain'
    assert slugify('The RAIN in SPAIN stays mainly in the PLAIN') == 'the-rain-in-spain-stays-mainly-in-the-plain'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'




# Generated at 2022-06-24 02:18:38.879824
# Unit test for function strip_margin
def test_strip_margin():
  a = """  line1
     line2
     line3"""
  b = "line1\nline2\nline3"
  assert strip_margin(a) == b

test_strip_margin()

# Generated at 2022-06-24 02:18:46.527631
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    from .testing import assert_equal
    assert_equal(camel_case_to_snake('ThisIsACamelStringTest'), 'this_is_a_camel_string_test')
    assert_equal(camel_case_to_snake('isNotACamelString'), 'is_not_a_camel_string')



# Generated at 2022-06-24 02:18:51.970905
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    # given
    original_string = 'http://www.example.com/?key=value&args=123456789'

    # when
    encoded_string = __StringCompressor.compress(original_string, 'utf-8', 9)
    decoded_string = __StringCompressor.decompress(encoded_string, 'utf-8')

    # then
    assert original_string == decoded_string
    assert type(decoded_string) == str


# PUBLIC API



# Generated at 2022-06-24 02:18:55.312840
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    

# Generated at 2022-06-24 02:19:04.179209
# Unit test for function prettify
def test_prettify():
    assert prettify('unprettified string, like this one,will be"prettified".it\\\'s awesome!')=='Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('unprettified string, like this one,will be"prettified".it\\\'s awesome!')!='Unprettified string, like this one, will be"prettified".it\\\'s awesome!'
test_prettify()

# Generated at 2022-06-24 02:19:07.096725
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('Hi') == 'iH'
    assert reverse('HeLLo') == 'oLlLeH'



# Generated at 2022-06-24 02:19:18.597495
# Unit test for function strip_html
def test_strip_html():
    def strip_html_keep_content(input_string):
        return strip_html(input_string, keep_tag_content=True)

    # end to end tests
    assert strip_html('</p>') == ''
    assert strip_html('<p>hello world</p>') == 'hello world'
    assert strip_html('test: <p>hello world</p>') == 'test: hello world'
    assert strip_html('<a href="foo/bar">click here</a>') == 'click here'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: click here'
    assert strip_html('<a href="foo/bar">click here</a> to continue') == 'click here'