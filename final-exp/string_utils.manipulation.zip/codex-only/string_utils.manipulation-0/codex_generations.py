

# Generated at 2022-06-24 02:09:26.515476
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:09:28.613695
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    from .jsonize import jsonize
    print(jsonize(__StringCompressor, private=True))
# /Unit test for constructor of class __StringCompressor


# PUBLIC API



# Generated at 2022-06-24 02:09:32.978517
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)

    assert original == decompressed, 'decompress(): original string is different from decompressed string'



# Generated at 2022-06-24 02:09:43.187305
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # internal rule mappings for encode()
    __mappings = [
        # units
        {1: 'I', 5: 'V'},
        # tens
        {1: 'X', 5: 'L'},
        # hundreds
        {1: 'C', 5: 'D'},
        # thousands
        {1: 'M'},
    ]

    # swap key/value definitions for decode()
    __reversed_mappings = [{v: k for k, v in m.items()} for m in __mappings]

    # assert __mappings
    assert __RomanNumbers.__mappings == __mappings

    # assert __reversed_mappings
    assert __RomanNumbers.__reversed_mappings == __reversed_mappings



# Generated at 2022-06-24 02:09:51.196788
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('<a>this is a test</a>') == ''
    assert strip_html('<a>this is a test</a>', keep_tag_content=True) == 'this is a test'
    assert strip_html('<a href="foo/bar">this is a test</a>', keep_tag_content=True) == 'this is a test'
    assert strip_html('this is <strong>NOT</strong> a test') == 'this is NOT a test'

# Generated at 2022-06-24 02:09:52.092812
# Unit test for function shuffle
def test_shuffle():
    assert(shuffle('hello world') != 'hello world')



# Generated at 2022-06-24 02:09:54.959022
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test', \
        'This function must returns "this_is_a_camel_string_test"'


# Generated at 2022-06-24 02:10:04.633163
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    text = """
    Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    """
    r = __StringFormatter(text).format()

# Generated at 2022-06-24 02:10:12.250690
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])

    # "compressed" will be a string of 88 chars
    compressed = compress(original)

    # "original" and "compressed" can be safely used in any context (including URLs)
    print('Original string: {}'.format(original))
    print('Compressed string: {}'.format(compressed))
    print()

    # "decompressed" will be an exact copy of "original"
    decompressed = decompress(compressed)
    print('Decompressed string: {}'.format(decompressed))
    print()

    assert original == decompressed



# Generated at 2022-06-24 02:10:24.074715
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('my_test_string_is_valid') == 'MyTestStringIsValid'
    assert snake_case_to_camel('my_test_string_is_valid', upper_case_first=False) == 'myTestStringIsValid'
    assert snake_case_to_camel('my_test_string_is_valid', separator='-') == 'MyTestStringIsValid'
    assert snake_case_to_camel('my_test_string_is_valid', upper_case_first=False, separator='-') == 'myTestStringIsValid'
    assert snake_case_to_camel('this-is-a-test') == 'ThisIsATest'

# Generated at 2022-06-24 02:10:24.963182
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    rn = __RomanNumbers()
    assert rn != None


# Generated at 2022-06-24 02:10:33.319995
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    string_to_compress = "IoT Edge is a fully managed service that delivers cloud intelligence locally by deploying and running artificial intelligence (AI), Azure services, and custom logic directly on cross-platform IoT devices. Deploy cloud intelligence locally to help you create connected solutions that analyze data generated by your Internet of Things (IoT) devices. You can deploy IoT Edge modules to run Azure services and custom logic on IoT Edge devices."
    string_compressed = __StringCompressor.compress(string_to_compress)
    string_decompressed = __StringCompressor.decompress(string_compressed)
    if(string_to_compress != string_decompressed):
        print("test___StringCompressor failed")
    else:
        print("test___StringCompressor passed")


# PUBLIC API


# Generated at 2022-06-24 02:10:44.139097
# Unit test for function slugify
def test_slugify():
    return True
    # assert slugify('áéíóú') == 'aeiou'
    # assert slugify('aéíóúb') == 'aeioub'
    # assert slugify('  \n áéíóú \r\n') == 'aeiou'
    # assert slugify('  \n áéíóú \r\n', '-'), 'aeiou'
    # assert slugify('  \n áé!íóú \r\n') == 'aeiou'
    # assert slugify('  \n áéíóú \r\n', '-'), 'aeiou'
    # assert slugify('  \n áé!íóú \r\n') == 'aeiou'
    # assert slugify('  \n áé!íó

# Generated at 2022-06-24 02:10:50.263190
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<a href="foo/bar">') == ''
    assert strip_html('<a href="foo/bar">', keep_tag_content=True) == 'a href="foo/bar"'

    assert strip_html('<a href="foo/bar"><a>') == ''
    assert strip_html('<a href="foo/bar"><a>', keep_tag_content=True) == 'a href="foo/bar"a'

    assert strip_html('<a href="foo/bar">foo</a><a>') == ''
    assert strip_html('<a href="foo/bar">foo</a><a>', keep_tag_content=True) == 'a href="foo/bar"fooa'

    assert strip_html('<a href="foo/bar">foo</a> bar') == ' bar'


# Generated at 2022-06-24 02:11:01.145524
# Unit test for function slugify
def test_slugify():
    assert 'test' == slugify('test')
    assert 'test' == slugify('test.')
    assert 'test' == slugify('test,--')
    assert 'test' == slugify('test:')
    assert 'test' == slugify('test;')
    assert 'test' == slugify('test...')
    assert 'test' == slugify('test/')
    assert 'test' == slugify('test\\\\')
    assert 'test' == slugify('test$')
    assert 'test' == slugify('test%')
    assert 'test' == slugify('test*')
    assert 'test' == slugify('test+')
    assert 'test' == slugify('test,[')
    assert 'test' == slugify('test]')
    assert 'test' == slugify('test_')

# Generated at 2022-06-24 02:11:07.963301
# Unit test for function asciify
def test_asciify():
    result = asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')
    assert result == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:11:08.823240
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # When
    rm = __RomanNumbers()

    # Then
    assert rm is not None



# Generated at 2022-06-24 02:11:09.666271
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:11:10.631736
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    __StringCompressor()


# Generated at 2022-06-24 02:11:18.023981
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('this_is_a_test') == 'ThisIsATest'
    assert snake_case_to_camel('this_is_a_test', upper_case_first=False) == 'thisIsATest'
    assert snake_case_to_camel('this.is.another-test', separator='.') == 'ThisIsAnotherTest'
    assert snake_case_to_camel('this is not a test') == 'This is not a test'



# Generated at 2022-06-24 02:11:24.585360
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('ThisIsACamel-CaseString') == 'thisisacamel-casestring'



# Generated at 2022-06-24 02:11:35.098925
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings == [
        {1: 'I', 5: 'V'},
        {1: 'X', 5: 'L'},
        {1: 'C', 5: 'D'},
        {1: 'M'},
    ]

# Generated at 2022-06-24 02:11:38.247789
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('some_string') == 'SomeString'
    assert snake_case_to_camel('some_string', True) == 'SomeString'
    assert snake_case_to_camel('some_string', False) == 'someString'
    assert snake_case_to_camel('some string', False, ' ') == 'someString'



# Generated at 2022-06-24 02:11:40.931775
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:11:44.935008
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('ThisIsACamelCaseStringTest') == 'this_is_a_camel_case_string_test'
    assert camel_case_to_snake('thisIsACamelCaseStringTest', '-') == 'this-is-a-camel-case-string-test'
    assert camel_case_to_snake('thisIsACamelCaseStringTest', '') == 'thisisacamelcasestringtest'



# Generated at 2022-06-24 02:11:46.022613
# Unit test for function shuffle
def test_shuffle():
    assert shuffle("hello world") != "hello world"



# Generated at 2022-06-24 02:11:48.110843
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert compressed != original
    assert decompressed == original



# Generated at 2022-06-24 02:11:53.402733
# Unit test for function slugify
def test_slugify():
    #assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    #assert slugify('Top 10 Reasons To Love Dogs!!!', '_') == 'top_10_reasons_to_love_dogs'
    #assert slugify('Mönstér Mägnët', '_') == 'monster_magnet'
    #assert slugify('Top 10 Reasons To Love Dogs!!!', '+') == 'top+10+reasons+to+love+dogs'
    #assert slugify('Mönstér Mägnët', '+') == 'monster+magnet'
    #assert slugify('') == ''
    #assert slugify('gg') == 'gg'
    #

# Generated at 2022-06-24 02:12:00.014151
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert is_full_string(__StringFormatter('i am a string').input_string) is True
    assert is_full_string(__StringFormatter(' ').input_string) is True
    assert is_full_string(__StringFormatter('').input_string) is False
    assert is_full_string(__StringFormatter(None).input_string) is False
    assert is_full_string(__StringFormatter(1).input_string) is False



# Generated at 2022-06-24 02:12:01.864029
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(3900) == 'MMMCM'
    

test_roman_encode()


# Generated at 2022-06-24 02:12:04.743264
# Unit test for function strip_html
def test_strip_html():
    input_string="test: <a href='foo/bar'>click here</a>"
    actual = strip_html(input_string)
    expected = 'test: '
    assert actual == expected

# Generated at 2022-06-24 02:12:06.184704
# Unit test for function strip_margin
def test_strip_margin():
    input_string = '''
                   |line 1
                   |line 2
                   |line 3
                   '''

    assert strip_margin(input_string) == '''
    line 1
    line 2
    line 3
    '''


# Generated at 2022-06-24 02:12:08.265922
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    string = "test"

    assert __StringCompressor.decompress(__StringCompressor.compress(string), 'utf-8') == string



# Generated at 2022-06-24 02:12:09.383323
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''    line 1
    line 2
    line 3
    ''') == '''
line 1
line 2
line 3
'''


# Generated at 2022-06-24 02:12:12.412687
# Unit test for function prettify

# Generated at 2022-06-24 02:12:24.318184
# Unit test for function decompress

# Generated at 2022-06-24 02:12:33.425029
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    # Create a new instance of class __StringFormatter
    # with an empty string as input
    str_formatter = __StringFormatter('')
    # Assert that the value of input_string is an empty string
    assert str_formatter.input_string == ''
    # Assert that class __StringFormatter raises an InvalidInputError
    # when is initialized with an empty string
    raises(InvalidInputError(''))(__StringFormatter)('')
    # Assert that class __StringFormatter raises a ValueError
    # when input_string is not a string
    raises(InvalidInputError('7'))(__StringFormatter)(7)
    # Assert that class __StringFormatter raises a ValueError
    # when input_string is not a string
    raises(InvalidInputError('False'))(__StringFormatter)(False)


# Generated at 2022-06-24 02:12:38.379692
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    sf = __StringFormatter('hello')
    assert sf.input_string == 'hello'
    try:
        __StringFormatter(1)
    except InvalidInputError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 02:12:42.555678
# Unit test for function compress
def test_compress():
    original = "Hello, World"
    compressed = compress(original, encoding='utf-8', compression_level=9)
    restored = decompress(compressed, encoding='utf-8')
    assert original == restored


# Generated at 2022-06-24 02:12:45.835521
# Unit test for function strip_margin
def test_strip_margin():

    source = '''
    |one
    | two
    |  three
    '''
    expected = '''
one
 two
  three
'''

    assert strip_margin(source) == expected

# Generated at 2022-06-24 02:12:54.597775
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    test_class = __StringCompressor
    test_input = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit'
    test_output = test_input

    test_output = test_class.compress(test_input)
    test_output = test_class.decompress(test_output)

    assert test_output == test_input
    print('Test for class __StringCompressor Passed')

# PUBLIC API


# <editor-fold desc="CamelCase / SnakeCase">

# Generated at 2022-06-24 02:12:59.892438
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    text = 'test compress'
    encode = 'utf-8'

    # compress string
    compressed = __StringCompressor.compress(text, encoding=encode)

    # decompress string
    decompressed = __StringCompressor.decompress(compressed, encoding=encode)

    # check if the string is the same
    assert text == decompressed
    print('Test compress and decompress passed')


# PUBLIC API



# Generated at 2022-06-24 02:13:07.464441
# Unit test for function decompress

# Generated at 2022-06-24 02:13:18.095606
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3''') == '''line 1
line 2
line 3'''
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''line 1
line 2
line 3
'''
    assert strip_margin('''
                        line 1
                        line 2
                            line 3''') == '''line 1
line 2
    line 3'''
    assert strip_margin('''
                        line 1
                        line 2
                                line 3''') == '''line 1
line 2
        line 3'''
    assert strip_margin('''
                        line 1
                        line 2
                            ''') == '''line 1
line 2
            '''


# Generated at 2022-06-24 02:13:21.130518
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:13:24.809660
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    print('Original: {}'.format(original))
    print('Compressed: {}'.format(compressed))
    assert is_string(original)
    assert is_string(compressed)
test_compress()


# Generated at 2022-06-24 02:13:27.143828
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'

test_slugify()



# Generated at 2022-06-24 02:13:32.209247
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    t = __StringCompressor()

test___StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:13:35.091929
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'



# Generated at 2022-06-24 02:13:43.111813
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_string = 'hello world'
    encoding = 'utf-8'
    compressed_string = __StringCompressor.compress(input_string, encoding)
    assert compressed_string == 'eJxLSAoKCgqX1QIkHFR8W'
    decompressed_string = __StringCompressor.decompress(compressed_string, encoding)
    assert decompressed_string == input_string

# API



# Generated at 2022-06-24 02:13:45.184365
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') != shuffle('hello world')



# Generated at 2022-06-24 02:13:48.466952
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'

test_slugify()



# Generated at 2022-06-24 02:13:53.479100
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    print("slugify successed")

test_slugify()


# Generated at 2022-06-24 02:14:04.270415
# Unit test for function booleanize
def test_booleanize():
    print('booleanize: ')
    print('booleanize(123): ', booleanize('123'))
    print('booleanize(456): ', booleanize('456'))
    print('booleanize(False):', booleanize('False'))
    print('booleanize(True): ', booleanize('True'))
    print('booleanize(N): ', booleanize('N'))
    print('booleanize(Y): ', booleanize('Y'))
    print('booleanize(123): ', booleanize('123'))
    print('booleanize(456): ', booleanize('456'))
    print('booleanize(False):', booleanize('False'))
    print('booleanize(True): ', booleanize('True'))
    print('booleanize(N): ', booleanize('N'))
    print

# Generated at 2022-06-24 02:14:08.064278
# Unit test for function shuffle
def test_shuffle():
	assert shuffle('hello world') != 'hello world'
	assert all(shuffle(l) == l for l in permutations('hello world'))
	print("Test passed")
test_shuffle()



# Generated at 2022-06-24 02:14:16.283252
# Unit test for function prettify

# Generated at 2022-06-24 02:14:23.714999
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('V') == 5
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XL') == 40
    assert roman_decode('L') == 50
    assert roman_decode('XC') == 90
    assert roman_decode('C') == 100
    assert roman_decode('CD') == 400
    assert roman_decode('D') == 500
    assert roman_decode('CM') == 900
    assert roman_decode('M') == 1000



# Generated at 2022-06-24 02:14:27.832981
# Unit test for function decompress
def test_decompress():
    assert __StringCompressor.decompress('eJxdU21v0zAQ/RX9LzpmQZYBAvB8iAzWxFhf7EwJv4u+7VH4LlNYDZVlzO6uY7B8SCH6UOb3yUwv6U0aW8AA9lcE1G') == 'Hello world'



# Generated at 2022-06-24 02:14:38.737850
# Unit test for function booleanize
def test_booleanize():
    test_cases = [
        ("True", True),
        ("yes", True),
        ("Yes", True),
        ("true", True),
        ("1", True),
        ("Y", True),
        ("y", True),
        ("False", False),
        ("no", False),
        ("No", False),
        ("False", False),
        ("0", False),
        ("n", False),
        ("N", False),
        ("test", False),
    ]
    for test_case in test_cases:
        assert test_case[1] == booleanize(test_case[0])

if __name__ == "__main__":
    print(strip_html('<a href="www.google.com"><span class="test">DUMMY</span></a>'))

# Generated at 2022-06-24 02:14:51.212475
# Unit test for function roman_encode
def test_roman_encode():
    assert str(roman_encode(1))=='I'
    assert str(roman_encode(2))=='II'
    assert str(roman_encode(3))=='III'
    assert str(roman_encode(4))=='IV'
    assert str(roman_encode(5))=='V'
    assert str(roman_encode(6))=='VI'
    assert str(roman_encode(7))=='VII'
    assert str(roman_encode(8))=='VIII'
    assert str(roman_encode(9))=='IX'
    assert str(roman_encode(10))=='X'
    assert str(roman_encode(11))=='XI'
    assert str(roman_encode(15))=='XV'

# Generated at 2022-06-24 02:14:56.481556
# Unit test for function strip_margin
def test_strip_margin():
    test_string = '''
                    line 1
                    line 2
                    line 3
                    '''
    expected = '''
line 1
line 2
line 3
'''
    assert strip_margin(test_string) == expected



# Generated at 2022-06-24 02:15:08.958095
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñ') == 'eeuuooaaeyn'
    assert asciify('ÅÀÁÇÌÍÑÓË') == 'AAACIINOE'
    assert asciify('ÅÀÁÇÌÍÑÓËèéùúòóäåëýñ') == 'AAACIINOEeeuuooaaeyn'
    assert asciify('äåëýñÅÀÁÇÌÍÑÓËèéùúòó') == 'aeynAAACIINOEeeuuoo'
    assert asciify('öÖ') == 'oO'
    assert asciify('') == ''



# Generated at 2022-06-24 02:15:11.569529
# Unit test for function reverse
def test_reverse():
    assert reverse('hello' == 'olleh')


# Generated at 2022-06-24 02:15:17.051840
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'




# Generated at 2022-06-24 02:15:18.532070
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('YES') == True
    assert booleanize('y') == True
    assert booleanize('nope') == False



# Generated at 2022-06-24 02:15:22.419357
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    data = get_random_string(9999)
    level = 9
    compressed = __StringCompressor.compress(data, 'utf-8', level)
    decompressed = __StringCompressor.decompress(compressed)
    assert data == decompressed


# PUBLIC API

# name: camel_case_to_snake
# description:

# Generated at 2022-06-24 02:15:30.650128
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    class_name = '__StringCompressor'
    constructor = globals()[class_name]

    # noinspection PyUnresolvedReferences
    constructor.compress.__func__ is globals()[class_name + '.' + 'compress']
    # noinspection PyUnresolvedReferences
    constructor.decompress.__func__ is globals()[class_name + '.' + 'decompress']



# Generated at 2022-06-24 02:15:31.999036
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:15:35.986230
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    s = __StringFormatter('Prova')
    assert s.input_string == 'Prova'
    try:
        s = __StringFormatter(2)
        assert False
    except InvalidInputError:
        assert True
    try:
        s = __StringFormatter('')
        assert False
    except InvalidInputError:
        assert True

# Generated at 2022-06-24 02:15:41.149907
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14

# Generated at 2022-06-24 02:15:52.853538
# Unit test for function prettify
def test_prettify():
    assert prettify('unprettified string,, like this one,will be"prettified".') == 'Unprettified string, like this one, will be "prettified".'
    assert prettify('this is a error:  you are doing a calculation  of  100 *% *3') == 'This is a error: you are doing a calculation of 100% * 3'
    assert prettify('we are writing a(sentence) inside  "parentheses" and "quotes"') == 'We are writing a (sentence) inside "parentheses" and "quotes"'
    assert prettify('   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  ') == '.'

# Generated at 2022-06-24 02:15:56.942614
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter(123)
        assert False, 'Invalid string, expected error exception'
    except InvalidInputError:
        pass

    try:
        __StringFormatter('')
        assert False, 'Invalid string, expected error exception'
    except InvalidInputError:
        pass

    # valid string
    __StringFormatter('a')



# Generated at 2022-06-24 02:16:09.273945
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(500) == 'D'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(7) == 'VII'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'


# Generated at 2022-06-24 02:16:20.484750
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake('Hello') == 'hello'
    assert camel_case_to_snake('camelStringTest') == 'camel_string_test'
    assert camel_case_to_snake('CamelStringTest') == 'camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsAnUpperCaseStringTest') == 'this_is_an_upper_case_string_test'
    assert camel_case_to_

# Generated at 2022-06-24 02:16:23.320403
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor.decompress(
        __StringCompressor.compress('this is a test'),
    ) == 'this is a test'


# PUBLIC API



# Generated at 2022-06-24 02:16:29.312222
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
test_strip_html()



# Generated at 2022-06-24 02:16:31.887494
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert isinstance(roman_decode('VII'), int)

# Generated at 2022-06-24 02:16:39.649427
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    # basic camel case conversion
    assert 'fooBar' == snake_case_to_camel('foo_bar')
    assert 'fooBar' == snake_case_to_camel('fooBar')

    # custom separator
    assert 'fooBar' == snake_case_to_camel('foo-bar', separator='-')

    # numbers will be treated as normal chars
    assert 'fooBar123' == snake_case_to_camel('foo_bar123')
    assert 'fooBar123' == snake_case_to_camel('foo_bar123', upper_case_first=False)

    # case insensitive
    assert 'fooBar' == snake_case_to_camel('foo_bar', upper_case_first=False)

# Generated at 2022-06-24 02:16:42.826164
# Unit test for function roman_decode
def test_roman_decode():
    test = roman_decode("VII")
    assert test == 7, "Roman number VII does not correspond to the number 7 in decimal"

# Generated at 2022-06-24 02:16:44.580594
# Unit test for function roman_decode
def test_roman_decode():
    return roman_decode('XX') == 20



# Generated at 2022-06-24 02:16:46.947025
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert 'MCMXCIX' == __RomanNumbers.encode(1999)
    assert 2039 == __RomanNumbers.decode('MMXXXIX')



# Generated at 2022-06-24 02:16:48.300613
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-24 02:16:56.658796
# Unit test for function strip_margin
def test_strip_margin():
    string1 = '''
               line 1
               line 2
               line 3
               '''
    assert strip_margin(string1) == '''
line 1
line 2
line 3
'''
    string2 = '''    line 1
  line 2
  line 3'''
    assert strip_margin(string2) == '''line 1
line 2
line 3'''
    string3 = 'l'
    assert strip_margin(string3) == 'l'



# Generated at 2022-06-24 02:17:08.259878
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('hello_world') == 'HelloWorld'
    assert snake_case_to_camel('hello_world', upper_case_first=False) == 'helloWorld'
    assert snake_case_to_camel('hello world') == 'HelloWorld'
    assert snake_case_to_camel('hello world', upper_case_first=False) == 'helloWorld'
    assert snake_case_to_camel('hello-world') == 'HelloWorld'
    assert snake_case_to_camel('hello-world', separator='-', upper_case_first=False) == 'helloWorld'
    assert snake_case_to_camel('hello world', separator=' ') == 'HelloWorld'

# Generated at 2022-06-24 02:17:16.902939
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ABC') == 'abc'
    assert camel_case_to_snake('aBc') == 'abc'
    assert camel_case_to_snake('ThisIsADummyTest') == 'this_is_a_dummy_test'
    assert camel_case_to_snake('ThisIsAA') == 'this_is_aa'
    assert camel_case_to_snake('ThisIsAB') == 'this_is_ab'
    assert camel_case_to_snake('isAB') == 'is_ab'
    assert camel_case_to_snake('ThisIsA') == 'this_is_a'
    assert camel

# Generated at 2022-06-24 02:17:22.237822
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    
    

# Generated at 2022-06-24 02:17:26.209259
# Unit test for function shuffle
def test_shuffle():
    input = 'hello world'
    output = shuffle(input)

    assert isinstance(output, str)
    assert output != input



# Generated at 2022-06-24 02:17:34.137798
# Unit test for function reverse
def test_reverse():
    # Tests with string as input
    assert reverse('test string') == 'gnirts tset'
    assert reverse('another test') == 'tset rehtona'
    assert reverse('cat and dog') == 'god dna tac'

    # Tests with non string as input
    try:
        reverse(123)
        assert False, 'Expected to raise InvalidInputError, but no exception was raised'
    except InvalidInputError:
        assert True



# Generated at 2022-06-24 02:17:46.614883
# Unit test for function asciify

# Generated at 2022-06-24 02:17:53.223762
# Unit test for function roman_decode
def test_roman_decode():
    # Test success
    assert roman_decode('VII') == 7
    # Test failure (not a valid string)
    #assert roman_decode('VIIIIII') == 'Not a valid string'
    # Test negative input
    #assert roman_decode('-VII') == 'Not a valid string'
    # Test high input
    #assert roman_decode('MMMM') == 'Not a valid string'
    # Test empty input
    #assert roman_decode('') == 'Not a valid string'
    return


# Generated at 2022-06-24 02:18:03.673869
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('Ë') == 'E'
    assert asciify('Ç') == 'C'
    assert asciify('Æ') == 'AE'
    assert asciify('‘') == ' '
    assert asciify('THIS IS A TEST') == 'THIS IS A TEST'
    assert asciify('This is a test') == 'This is a test'
    assert asciify('this is a test') == 'this is a test'
    assert asciify('') == ''
    assert asciify(None) == ''
    assert asciify(666) == ''
   

# Generated at 2022-06-24 02:18:05.895529
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
                        line 1
                        line 2
                        line 3
                        '''

# Generated at 2022-06-24 02:18:08.845050
# Unit test for function slugify
def test_slugify():
    assert slugify('This is a Test string') == 'this-is-a-test-string'
    assert slugify('This   is a  Test string !#') == 'this-is-a-test-string'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'



# Generated at 2022-06-24 02:18:14.764098
# Unit test for function booleanize
def test_booleanize():
    # All the values that return True
    assert booleanize("true") == True
    assert booleanize("1") == True
    assert booleanize("yes") == True
    assert booleanize("y") == True
    # All the values that return False
    assert booleanize("False") == False
    assert booleanize("0") == False
    assert booleanize("NO") == False
    assert booleanize("N") == False
    assert booleanize("nope") == False
    # Test for invalid input
    booleanize("Hello world")

# Generated at 2022-06-24 02:18:17.706245
# Unit test for function slugify
def test_slugify():
	assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
	assert slugify('Mönstér Mägnët') == 'monster-magnet'
	print('Test passed')

if __name__ == '__main__':
	test_slugify()




# Generated at 2022-06-24 02:18:24.673682
# Unit test for function booleanize
def test_booleanize():
    assert(booleanize('true'))
    assert(booleanize('tRue'))
    assert(booleanize('1'))
    assert(booleanize('yes'))
    assert(booleanize('y'))
    assert(not booleanize('FALSE'))
    assert(not booleanize('0'))
    assert(not booleanize('no'))
    assert(not booleanize('n'))
    assert(not booleanize('none'))
    assert(not booleanize('NONE'))
    assert(not booleanize('mIne'))
    
if __name__ == '__main__':
    test_booleanize()
    
    
    
    
    
    

# Generated at 2022-06-24 02:18:35.740032
# Unit test for function compress
def test_compress():
    assert StringUtils.compress('random utf-8 string to compress') == 'x\x9c\xcbH\xcd\xc9\xc9W(\\H\xcd\xcf/\xcaIK\x01\x00\x1a\x13\x18\xb7\x05\xc0'
    assert StringUtils.compress('random ascii string to compress') == 'x\x9c\xcbH\xc9\xc9W(\\H\xcd\xcf/\xcaIK\x01\x00\x1a\x13\x18\xb7\x05\xc0'

# Generated at 2022-06-24 02:18:38.525709
# Unit test for function strip_html
def test_strip_html():
    assert_equals(strip_html('<p>test</p>'), 'test')
    assert_equals(strip_html('<p>test</p>', keep_tag_content=True), '<p>test</p>')



# Generated at 2022-06-24 02:18:50.985364
# Unit test for function decompress
def test_decompress():
    text = """Hi there, this is a test, I hope it all works fine."""
    assert decompress(compress(text)) == text
    assert decompress(compress(text, 'iso-8859-1'), 'iso-8859-1') == text
    assert decompress(compress(text, 'utf-16'), 'utf-16') == text
    assert decompress(compress(text, encoding='utf-8')) == text
    assert decompress(compress(text, compression_level=1)) == text
    assert decompress(compress(text, 'iso-8859-1', 1), 'iso-8859-1') == text
    assert decompress(compress(text, 'utf-16', 1), 'utf-16') == text

# Generated at 2022-06-24 02:18:55.012951
# Unit test for function decompress
def test_decompress():
    import pytest
    with pytest.raises(ValueError):
        decompress('')
        decompress('!')
        decompress('s')
        decompress('a')

    # endregion
    # region - split_by_chunk()
    # Unit test for function split_by_chunk

# Generated at 2022-06-24 02:19:02.081735
# Unit test for function prettify

# Generated at 2022-06-24 02:19:04.089981
# Unit test for function booleanize
def test_booleanize():
    assert (booleanize('true') == True)
    assert (booleanize('YES') == True)
    assert (booleanize('nope') == False)


# Generated at 2022-06-24 02:19:04.518905
# Unit test for function strip_html
def test_strip_html():
    assert True



# Generated at 2022-06-24 02:19:05.812273
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:19:10.716655
# Unit test for function decompress
def test_decompress():
    text = 'this is a test'
    compressed = compress(text)
    decompressed = decompress(compressed)
    assert decompressed == text


# Generated at 2022-06-24 02:19:11.686107
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('IV') == 4

test_roman_decode()

# Generated at 2022-06-24 02:19:13.162991
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1


# Generated at 2022-06-24 02:19:20.982698
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" class="btn">click here</a>', keep_tag_content=True) == 'test: click here'
    assert strip_html('test: <a href="foo/bar" class="btn">click here</a>', keep_tag_content=False) == 'test: '