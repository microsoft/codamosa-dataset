

# Generated at 2022-06-24 02:09:24.275500
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen', \
        'snake_case_to_camel failed to convert a snake_case string'



# Generated at 2022-06-24 02:09:32.393161
# Unit test for function decompress
def test_decompress():
    assert 'mid dl l r xpn lnd' == decompress('eJztVk0KwlAUgu/5FZm6mclPV+mCV6bJUHcnQw6Y0MkYgO9XzvI8HxjKDlbgZl1AFpJv+8Ww=')

    # actual compression result is not guaranteed to be the same over time and even in subsequent executions.
    # At the time of writing this, the best compressible ratio seems to be the one (16%) obtained below:
    assert 'hi' == decompress('eJwDAAAAAAE=')

    # The "worst" compression result (0%) is obtained by the following:
    assert 'nope' == decompress('eJwVWAE=')

    # Empty strings can be successfully compressed

# Generated at 2022-06-24 02:09:37.884222
# Unit test for function asciify
def test_asciify():
    #ascii_string = asciify(input_string)
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('Hi there? this is a test!') == 'Hi there? this is a test!'
    assert asciify('and two lines\n\n') == 'and two lines\n\n'

test_asciify()


# Generated at 2022-06-24 02:09:44.337222
# Unit test for function prettify

# Generated at 2022-06-24 02:09:50.756258
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('1') == True
    assert booleanize('y') == True
    assert booleanize('') == False



# Generated at 2022-06-24 02:09:56.106076
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('test').format() == 'test'
    assert __StringFormatter('test test').format() == 'test test'
    assert __StringFormatter('test   test').format() == 'test test'
    assert __StringFormatter('  test  ').format() == 'test'
    assert __StringFormatter('test test ').format() == 'test test'
    assert __StringFormatter(' test test ').format() == 'test test'
    assert __StringFormatter('test. test').format() == 'test. test'
    assert __StringFormatter('test; test').format() == 'test; test'
    assert __StringFormatter('"test test"').format() == '"test test"'
    assert __StringFormatter("'test test'").format() == "'test test'"

# Generated at 2022-06-24 02:10:03.006907
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print(snake_case_to_camel('hola_mundo'))
    assert snake_case_to_camel('hola_mundo') == 'HolaMundo'
    
test_snake_case_to_camel()


# Generated at 2022-06-24 02:10:07.614213
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'



# Generated at 2022-06-24 02:10:11.337189
# Unit test for function slugify
def test_slugify():
    print( "Testing function slugify...")
    #Testing function
    print("\nTest:")
    print("Input: 'Mönstér Mägnët'\nExpected output: 'monster-magnet'\nActual output:")
    print(slugify('Mönstér Mägnët'))
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    #Test passed
    print("\nTest passed.")
# Testing
test_slugify()


# Generated at 2022-06-24 02:10:18.522531
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('i h ave too    much    space inside').format() == 'I have too much space inside'
    assert __StringFormatter('i h ave too    much    space inside').format() == 'I have too much space inside'
    assert __StringFormatter('  i h ave too    much    space inside').format() == 'I have too much space inside'
    assert __StringFormatter('  i h ave too    much    space inside  ').format() == 'I have too much space inside'
    assert __StringFormatter('i h ave t oo    much    space inside').format() == 'I have too much space inside'
    assert __StringFormatter('i h ave too much space inside but too    much    space').format() == 'I have too much space inside but too much space'
    assert __StringForm

# Generated at 2022-06-24 02:10:26.920305
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('ThisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'
    assert camel_case_to_snake('ThisIsACamelStringTest', '-') == 'this-is-a-camel-string-test'
    assert camel_case_to_snake('this-is-a-camel-string-test') == 'this-is-a-camel-string-test'



# Generated at 2022-06-24 02:10:29.129670
# Unit test for function prettify

# Generated at 2022-06-24 02:10:32.247846
# Unit test for function roman_decode
def test_roman_decode():
    assert 7 == roman_decode('VII')
    assert 2020 == roman_decode('MMXX')
    assert 37 == roman_decode('XXXVII')



# Generated at 2022-06-24 02:10:35.176967
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)

    # Test: the compressed string length
    assert len(compressed) in (88, 89)

    # Test: the compressed string can be restored back to its original value
    restored = decompress(compressed)
    assert restored == original



# Generated at 2022-06-24 02:10:38.586666
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:10:40.647964
# Unit test for function booleanize
def test_booleanize():
      assert booleanize('on') == True
      assert booleanize('off') == False
      assert booleanize('True') == True
      assert booleanize('False') == False
      assert booleanize('0') == False
      assert booleanize('1') == True
      assert booleanize('y') == True
      assert booleanize('no') == False


# Generated at 2022-06-24 02:10:46.858029
# Unit test for function compress

# Generated at 2022-06-24 02:10:54.631443
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(11) == 'XI'
    assert roman_encode(33) == 'XXXIII'
    assert roman_encode(999) == 'CMXCIX'
    assert roman_encode(1997) == 'MCMXCVII'
    assert roman_encode(2008) == 'MMVIII'
    assert roman_encode(2019) == 'MMXIX'
    assert roman_encode(3999) == 'MMMCMXCIX'

    with pytest.raises(InvalidInputError):
        roman_encode('foo')



# Generated at 2022-06-24 02:10:57.056811
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('Hello') is not None
    assert __StringFormatter('') is not None
    assert __StringFormatter(None) is None

# Unit tests for method __StringFormatter.format

# Generated at 2022-06-24 02:11:06.967737
# Unit test for function prettify
def test_prettify():
    assert prettify(' unprettified string ,, like this one,will be"prettified" .it\\'
                    ' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'

# Generated at 2022-06-24 02:11:13.319289
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('abc123!?@£$%^&*()=+_') == 'abc123!?@£$%^&*()=+_'

# Generated at 2022-06-24 02:11:15.709943
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'
    assert scale(shuffle('hello world'), 15) == 'ello worlhdlo'



# Generated at 2022-06-24 02:11:20.600969
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('') == ''
    try:
        reverse(0)
        raise AssertionError('Input must be string')
    except InvalidInputError:
        pass

test_reverse()



# Generated at 2022-06-24 02:11:24.843446
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    import unittest

    # Initialization
    test1_input = '    G-UNIT  '
    test1_result = 'G-Unit'
    test2_input = ' hello  world. how are you today  '
    test2_result = 'Hello world. How are you today'
    test3_input = 'hello world. my brother\'s name is brian.he is a proffesional killer'
    test3_result = 'Hello world. My brother\'s name is Brian. He is a professional killer'
    test4_input = 'G-Unit, G-UNIT, G-UniT, g-unit'
    test4_result = 'G-Unit, G-UNIT, G-UniT, G-Unit'
    test5_input = 'G-Unit \'test\''
    test5_

# Generated at 2022-06-24 02:11:35.275697
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('2020') == 'MMXX'
    assert roman_encode(2019) == 'MMXIX'
    assert roman_encode('500') == 'D'
    assert roman_encode('200') == 'CC'
    assert roman_encode('37') == 'XXXVII'
    assert roman_encode('10') == 'X'
    assert roman_encode(20) == 'XX'
    assert roman_encode(10) == 'X'
    assert roman_encode(9) == 'IX'
    assert roman_encode(5) == 'V'
    assert roman_encode(4) == 'IV'
    assert roman_encode(1) == 'I'
    return True

# Generated at 2022-06-24 02:11:46.663684
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('') == 0
    assert roman_decode('MCMXC') == 1990
    assert roman_decode('  MMXX') == 2020
    assert roman_decode('MMMM') == 4000
    assert roman_decode('MCM') == 1900
    assert roman_decode('XX') == 20
    assert roman_decode('xix') == 19
    assert roman_decode('IV') == 4
    assert roman_decode('VIII') == 8
    assert roman_decode('MCMLIV') == 1954
    assert roman_decode('MCMLXXXIV') == 1984
    assert roman_decode('MMMCDXXXVII') == 3437
    assert roman_decode('MMMDCCXXXIII') == 3733
    assert roman_decode

# Generated at 2022-06-24 02:11:52.446356
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('<p>test:</p>') == 'test:', 'line 425'
    assert strip_html('<p class="test">test:</p>') == 'test:', 'line 426'
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: ', 'line 427'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here', 'line 428'
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False) == 'test: ', 'line 429'



# Generated at 2022-06-24 02:11:55.042738
# Unit test for function slugify
def test_slugify():
    testcases = [
        ('Top 10 Reasons To Love Dogs!!!', 'top-10-reasons-to-love-dogs'),
        ("Mönstér Mägnët", 'monster-magnet'),
        ("ØëÑ-ØË-ÑØ", 'oen-oe-noe')
    ]

    for input, expected_output in testcases:
        actual_output = slugify(input)
        assert actual_output == expected_output



# Generated at 2022-06-24 02:12:05.330107
# Unit test for function booleanize
def test_booleanize():
    assert booleanize(False) == False
    assert booleanize(True) == True
    assert booleanize('True') == True
    assert booleanize('true') == True
    assert booleanize('False') == False
    assert booleanize('false') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('Yes') == True
    assert booleanize('no') == False
    assert booleanize('y') == True
    assert booleanize('n') == False
    assert booleanize('Yes ') == True
    assert booleanize(' no') == False
    assert booleanize(' y') == True
    assert booleanize('n ') == False
    assert booleanize('0') == False
    assert booleanize(' 1') == True
    assert booleanize(' 2') == False

# Generated at 2022-06-24 02:12:07.478727
# Unit test for function decompress
def test_decompress():
    s = compress('ulisse')
    assert(decompress(s) == 'ulisse')


# ----------------------------------------------------------------------------------------------------------------------
# SUPPORT CLASSES
# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-24 02:12:08.587939
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-24 02:12:10.993501
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    test_input_string = '  t  e  s  t     '
    assert __StringFormatter(test_input_string).input_string == '  t  e  s  t     '



# Generated at 2022-06-24 02:12:12.113913
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'


# Generated at 2022-06-24 02:12:24.121580
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:12:29.753168
# Unit test for function asciify
def test_asciify():
    assert asciify(u'èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify(u'趙') == ''
    assert asciify(u'Aïda') == 'Aida'
    assert asciify(u'中国') == ' '
    assert asciify(u'中文') == ' '
    assert asciify(u'中文空白') == '  '
    assert asciify(u'中文空格') == '  '
    assert asciify(u'This is a test') == 'This is a test'

# Generated at 2022-06-24 02:12:42.090469
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    _decompress = __StringCompressor.decompress
    _compress = __StringCompressor.compress
    expected: str = "hello world"
    compressed: str = _compress(expected)
    assert(_decompress(compressed) == expected)
    assert(compressed == "eJytkNtOnCoMjEyEvPzsFv4s1ZzsjKHB8nLSEBCwg")
    shorter: str = "hello world"
    try:
        _ = __StringCompressor.compress(shorter)
        assert(False)
    except InvalidInputError:
        pass
    empty: str = ""
    try:
        _ = __StringCompressor.compress(empty)
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-24 02:12:44.212540
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('thisIsACamelStringTest') == 'this_is_a_camel_string_test'



# Generated at 2022-06-24 02:12:47.163555
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'
test_slugify()



# Generated at 2022-06-24 02:12:58.478247
# Unit test for function compress
def test_compress():
    import unittest
    from random import randint
    from . import encode, decode, compress, decompress

    # creates a string of max_chars chars
    # (chars will be ascii non empty number in range 0 - 255 and repeated to fill the string)
    def create_random_string(max_chars=None):
        # create a random list of numbers in the range 0-255
        numbers = [randint(0, 255) for i in range(max_chars + 10)]

        # divide the list of numbers in chunks of 2 or 3 (ascii letters, numbers and punctuation)
        chunks = [numbers[i:i+ 2] for i in range(0, len(numbers) - 1, 2)]

# Generated at 2022-06-24 02:13:12.969380
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert('Mr. Smith' == __StringFormatter('mr. smith').format())
    assert('Mr Smith' == __StringFormatter('mr smith').format())
    assert('Mr Smith' == __StringFormatter('Mr smith').format())
    assert('Mr Smith' == __StringFormatter('Mr Smith').format())
    assert('Mr Smith' == __StringFormatter('Mr smith ').format())
    assert('Mr Smith' == __StringFormatter(' Mr smith ').format())
    assert('Mr Smith' == __StringFormatter('\tMr smith\n').format())
    assert('Mr Smith' == __StringFormatter('\tMr \tsmith\n').format())
    assert('Mr Smith\'s' == __StringFormatter('Mr smiths').format())

# Generated at 2022-06-24 02:13:23.590207
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    string_compressor = __StringFormatter('giovanni_rossi')
    assert string_compressor.format() == 'Giovanni Rossi'

    string_compressor = __StringFormatter(' this is an invalid string with many errors  ')
    assert string_compressor.format() == 'This Is An Invalid String With Many Errors'

    string_compressor = __StringFormatter('this_string.is.valid!')
    assert string_compressor.format() == 'This String.Is Valid!'

    string_compressor = __StringFormatter('thisi (abc) string is valid')
    assert string_compressor.format() == 'Thisi (Abc) String Is Valid'

    string_compressor = __StringFormatter('thisi string is valid ?')
    assert string_compressor.format() == 'Thisi String Is Valid ?'

# Generated at 2022-06-24 02:13:35.483703
# Unit test for function strip_margin
def test_strip_margin():
    multiline_single_indentation = (
        '''
        line 1
        line 2
        line 3
        '''
    )
    multiline_double_indentation = (
        '''
        line 1
        line 2
          line 2.1
            line 2.1.1
        '''
    )
    multiline_triple_indentation = (
        '''
        line 1
        line 2
          line 2.1
            line 2.1.1
              line 2.1.1.1
                line 2.1.1.1.1
        '''
    )

# Generated at 2022-06-24 02:13:38.316940
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('true') != False
    assert booleanize('TRUE') == True
    assert booleanize('1') == True
    assert booleanize('nope') == False
    assert booleanize('nope') != True
    assert booleanize('') == False


# TESTING
# General test for positive and negative common strings

# Generated at 2022-06-24 02:13:47.042247
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII')== 7, roman_decode('VII')
    assert roman_decode('M') == 1000, roman_decode('M')
    assert roman_decode('MM') == 2000, roman_decode('MM')
    assert roman_decode('MXX') == 1020, roman_decode('MXX')
    assert roman_decode('MXXI') == 1021, roman_decode('MXXI')
    assert roman_decode('CXXI') == 121, roman_decode('CXXI')
    assert roman_decode('CXXV') == 125, roman_decode('CXXV')
    assert roman_decode('MMCC') == 2200, roman_decode('MMCC')
    assert roman

# Generated at 2022-06-24 02:13:51.581352
# Unit test for function booleanize
def test_booleanize():
    print(booleanize('true'),booleanize('true') == True)
    print(booleanize('YES'),booleanize('YES') == True)
    print(booleanize('nope'),booleanize('nope') == False)
    try:
        print(booleanize(1))
    except InvalidInputError:
        print('InvalidInputError')
    try:
        print(booleanize([1,2,3]))
    except InvalidInputError:
        print('InvalidInputError')

# Generated at 2022-06-24 02:13:53.229727
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('1') == True
    assert booleanize('nope') == False

# Generated at 2022-06-24 02:13:54.013346
# Unit test for function roman_decode
def test_roman_decode():
	assert roman_decode('VII') == 7


# Generated at 2022-06-24 02:13:55.617936
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:14:02.688719
# Unit test for function strip_margin
def test_strip_margin():
    # Arrange
    test_string = '''
        line 1
        line 2
        line 3
    '''
    expected_output = '''
line 1
line 2
line 3
'''
    # Act
    actual_output = strip_margin(test_string)
    # Assert
    assert expected_output == actual_output

# Generated at 2022-06-24 02:14:08.427518
# Unit test for function decompress
def test_decompress():
    input_string = """original string, 20 words on 4 lines.
    line 1
    line 2
    line 3"""
    assert __StringCompressor.decompress(__StringCompressor.decompress(input_string), "utf-8") == input_string

# Generated at 2022-06-24 02:14:12.363219
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:14:24.356755
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake('') == ''
    assert camel_case_to_snake(' a') == ' a'
    assert camel_case_to_snake(' this') == ' this'
    assert camel_case_to_snake('THIS') == 'this'
    assert camel_case_to_snake('this') == 'this'
    assert camel_case_to_snake('this is not a snake case string') == 'this is not a snake case string'
    assert camel_case_to_snake('ThisIsACamelCaseString') == 'this_is_a_camel_case_string'
    assert camel_case_to_snake('ThisIsACamelCaseString', '-') == 'this-is-a-camel-case-string'



# Generated at 2022-06-24 02:14:31.590011
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!! ') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët ') == 'monster-magnet'

# Generated at 2022-06-24 02:14:42.683135
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)

# Generated at 2022-06-24 02:14:51.756219
# Unit test for function shuffle
def test_shuffle():
    import random, unittest
    random.seed()
    class TestShuffleFunction(unittest.TestCase):
        """
        The test class for the shuffle function.
        """
        def test_shuffle_string(self):
            """
            Test if the shuffle function shuffles the string correctly.
            """
            # Make sure that shuffling a string is always different.
            self.assertNotEqual(shuffle("hello world"), shuffle("hello world"))

    unittest.main()



# Generated at 2022-06-24 02:15:00.414287
# Unit test for function slugify
def test_slugify():
    assert(slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs')
    assert(slugify('Mönstér Mägnët') == 'monster-magnet')
    assert(slugify('Mönstér Mägnët') != 'monster-magnet-')
    assert(slugify('Mönstér Mägnët') != 'monster-magnet-monster')
    assert(slugify('Mönstér Mägnët') != 'Monster-magnet')
    
    
test_slugify()



# Generated at 2022-06-24 02:15:02.145399
# Unit test for function slugify
def test_slugify():
    s = "Mönstér Mägnët"
    assert slugify(s) == 'monster-magnet'


# Generated at 2022-06-24 02:15:10.037876
# Unit test for function prettify
def test_prettify():
    """
    test that prettify function works as intended
    """
    assert prettify('') == ''
    assert prettify(' ') == ''
    assert prettify('first letter in the string and the ones after a dot, an exclamation or a question mark must be '
                    'uppercase') == 'First letter in the string and the ones after a dot, an exclamation or a question ' \
                                   'mark must be uppercase'
    assert prettify('unprettified string ,, like this one,will be"prettified" .it\\'
                    's awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'
    assert prettify('foo" bar" baz') == 'Foo "bar" baz'
    assert prettify('foo (bar) baz')

# Generated at 2022-06-24 02:15:20.515806
# Unit test for function slugify
def test_slugify():
    print('Testing slugify')
    print('This should be "the-answer-is-42"')
    print(slugify('The Answer is 4.2'))
    print('This should be "this-is-not-a-valid-sentence"')
    print(slugify(' This IS not a valid sentence . '))
    print('This should be "name"')
    print(slugify('''Name'''))
    print('This should be "text"')
    print(slugify('''Text'''))
    print('This should be "space-in-text-no-space"')
    print(slugify('''Space in text (no space)'''))
    print('This should be "what-is-the-question"')

# Generated at 2022-06-24 02:15:29.328201
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('ÄÖÜ') == 'aou'

# Generated at 2022-06-24 02:15:36.020349
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    expected = 'CDXCIX'
    out = __RomanNumbers.encode(499)
    assert out == expected, 'Error in method __RomanNumbers.encode()'

    expected = 499
    out = __RomanNumbers.decode(expected)
    assert out == expected, 'Error in method __RomanNumbers.decode()'


# Generated at 2022-06-24 02:15:42.524071
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true')
    assert booleanize('True')
    assert booleanize('TRUE')
    assert booleanize('TRue')
    assert booleanize('1')
    assert booleanize('yes')
    assert booleanize('YES')
    assert booleanize('Yes')
    assert booleanize('y')
    assert not booleanize('false')
    assert not booleanize('False')
    assert not booleanize('0')
    assert not booleanize('no')
    assert not booleanize('NO')
    assert not booleanize('n')
    assert not booleanize('not')

# Generated at 2022-06-24 02:15:47.221828
# Unit test for function strip_margin
def test_strip_margin():
    expected = '''
line 1
line 2
line 3
'''

    input_string = '''
    line 1
    line 2
    line 3
    '''

    assert strip_margin(input_string) == expected

# Generated at 2022-06-24 02:15:50.533252
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # test for constructor of class __RomanNumbers
    __RomanNumbers()



# Generated at 2022-06-24 02:15:58.928878
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    print('Testing function snake_case_to_camel...', end='')

    assert snake_case_to_camel('a_snake_case_string', True) == 'ASnakeCaseString'
    assert snake_case_to_camel('a_snake_case_string', False) == 'aSnakeCaseString'
    assert snake_case_to_camel('a-snake-case-string', True, '-') == 'ASnakeCaseString'
    assert snake_case_to_camel('a-snake-case-string', False, '-') == 'aSnakeCaseString'
    assert snake_case_to_camel('A_snake_case_string', True) == 'ASnakeCaseString'

# Generated at 2022-06-24 02:16:09.664288
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('123') == '123'
    assert shuffle('AAA') == 'AAA'
    assert shuffle('aA1') == 'aA1'
    assert shuffle(' aAb ') != 'aAb'
    assert shuffle(' aAb ') == ' aAb '
    assert shuffle('aAb ') != 'Aba'
    assert len(shuffle('abcdefghijklmnopqrstuvwxyz')) == 26
    assert len(shuffle('abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ')) == 52
    assert len(shuffle('abcdefghijklmnopqrstuvwxyz 1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZ')) == 62



# Generated at 2022-06-24 02:16:14.201726
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('Yes') == True
    assert booleanize('y') == True
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('No') == False
    assert booleanize('n') == False
    assert booleanize('') == False
    assert booleanize('a') == False
    try:
        booleanize(0)
        assert False
    except:
        assert True


# Generated at 2022-06-24 02:16:22.416994
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the_snake_is_green', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'

    assert snake_case_to_camel('the') == 'The'
    assert snake_case_to_camel('the', upper_case_first=False) == 'the'

# Generated at 2022-06-24 02:16:27.953753
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('test: <a href="foo/bar">click here</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'test: click here'



# Generated at 2022-06-24 02:16:33.232656
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_case_string_test"
    assert camel_case_to_snake("ThisIsACamelStringTest", separator="-") == "this-is-a-camel-case-string-test"


# Generated at 2022-06-24 02:16:35.441049
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('') == ''
    assert shuffle('foo') == 'foo'
    assert shuffle('bar') != 'bar'
    assert len(shuffle('abcdefghij')) == 10



# Generated at 2022-06-24 02:16:41.279852
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert 'this_is_a_test' == camel_case_to_snake('ThisIsATest')
    assert 'this_is_a_test' == camel_case_to_snake('ThisIsATest', separator='_')
    assert 'this-is-a-test' == camel_case_to_snake('ThisIsATest', separator='-')
    assert 'thisIsATest' == camel_case_to_snake('thisIsATest')
    assert '' == camel_case_to_snake('')
    assert 'camel_case_to_snake' == camel_case_to_snake('camel_case_to_snake')
    assert 'hello' == camel_case_to_snake('hello')
    assert 'my1_string' == camel_case_to_sn

# Generated at 2022-06-24 02:16:45.926870
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    assert asciify('Müller') == 'Muller'



# Generated at 2022-06-24 02:16:49.822187
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XIX') == 19
    assert roman_decode('IX') == 9
    assert roman_decode('LXXIV') == 74

test_roman_decode()
 


# Generated at 2022-06-24 02:16:55.889414
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'


# Generated at 2022-06-24 02:17:06.219253
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(1066) == 'MLXVI'
    assert __RomanNumbers.encode(1989) == 'MCMLXXXIX'
    assert __RomanNumbers.encode(3600) == 'MMMDC'
    assert __RomanNumbers.decode('III') == 3
    assert __RomanNumbers.decode('IV') == 4
    assert __RomanNumbers.decode('IX') == 9
    assert __RomanNumbers.decode('MLXVI') == 1066
    assert __RomanNumbers.decode('MCMLXXXIX') == 1989
    assert __RomanNumbers.decode('MMMDC') == 3600



# Generated at 2022-06-24 02:17:15.129979
# Unit test for function compress
def test_compress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    assert compressed == 'eJwBjw1x2zAQhM8+QhQ5q5Eg8CFTtDYFyw0hKgJx7o+PZBfbVZ5Q5Nqh9EuHN+phD7V/wKjJx7/u/QLcZSA=='


# Generated at 2022-06-24 02:17:25.610273
# Unit test for constructor of class __StringFormatter

# Generated at 2022-06-24 02:17:26.886129
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    assert __StringCompressor == type(__StringCompressor())


# PUBLIC API



# Generated at 2022-06-24 02:17:36.442204
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.__mappings == [{1: 'I', 5: 'V'}, {1: 'X', 5: 'L'}, {1: 'C', 5: 'D'}, {1: 'M'}]

    assert __RomanNumbers.__reversed_mappings == [{'V': 5, 'I': 1}, {'L': 5, 'X': 1}, {'D': 5, 'C': 1}, {'M': 1}]

    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __

# Generated at 2022-06-24 02:17:45.723030
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('C') == 100
    assert roman_decode('CIV') == 104
    assert roman_decode('MCMXCIX') == 1999
    assert roman_decode('MCCLXXX') == 1280
    assert roman_decode('MMM') == 3000
    assert roman_decode('MMMDCCCXXXVII') == 3837


# Generated at 2022-06-24 02:17:50.809713
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    input_str = 'test'
    inner_encodes = __StringCompressor.compress(input_str, 'utf-8')
    result = __StringCompressor.decompress(inner_encodes, 'utf-8')
    assert result==input_str
# TEST END


# Generated at 2022-06-24 02:17:51.935204
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'



# Generated at 2022-06-24 02:17:58.003332
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('test') == 'Test'
    assert snake_case_to_camel('test', False) == 'test'
    assert snake_case_to_camel('test_another') == 'TestAnother'
    assert snake_case_to_camel('test_another', False) == 'testAnother'
    assert snake_case_to_camel('test_another', True, '-') == 'TestAnother'
    assert snake_case_to_camel('test-another', True, '-') == 'TestAnother'
    assert snake_case_to_camel('test-another', False, '-') == 'testAnother'
    assert snake_case_to_camel('Test', True) == 'Test'
    assert snake_case_to_camel('Test', False) == 'Test'

# Generated at 2022-06-24 02:18:08.091606
# Unit test for function prettify
def test_prettify():
    import unittest

    class StringFormatterTestCase(unittest.TestCase):
        def setUp(self):
            self.string_formatter = __StringFormatter

        def test_uppercase_first_char(self):
            self.assertEqual('Hello world', self.string_formatter('hello world').format())
            self.assertEqual('Hello', self.string_formatter('hello').format())

        def test_remove_duplicates(self):
            self.assertEqual('Hello world', self.string_formatter('Hello   world').format())
            self.assertEqual('Hello, world', self.string_formatter('Hello,,, world').format())
            self.assertEqual('Hello, world!', self.string_formatter('Hello,,, world!!!').format())


# Generated at 2022-06-24 02:18:10.586002
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'


# Generated at 2022-06-24 02:18:22.201717
# Unit test for function strip_html
def test_strip_html():
    assert 'test: ' == strip_html('test: <a href="foo/bar">click here</a>')
    assert 'test: click here' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=True)
    assert 'test: <a href="foo/bar">click here</a>' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=False)
    assert 'test: <a href="foo/bar">click here</a>' == strip_html('test: <a href="foo/bar">click here</a>', keep_tag_content=1)

# Generated at 2022-06-24 02:18:23.395026
# Unit test for function compress
def test_compress():
    assert compress('') == ''



# Generated at 2022-06-24 02:18:24.629234
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-24 02:18:35.685700
# Unit test for function compress
def test_compress():
    import datetime
    start_time = datetime.datetime.now()
    print('test start time:', start_time)
    original_str = ' '.join(['word n{}'.format(n) for n in range(1, 20)])
    compressed_str = compress(original_str)
    assert ('word ' in compressed_str) == False
    print('compressed length:', len(compressed_str))
    decompressed_str = decompress(compressed_str)
    print('decompressed length:', len(decompressed_str))
    assert (original_str == decompressed_str) == True
    end_time = datetime.datetime.now()
    print('test end time:', end_time)
    print('test runtime:', end_time - start_time)



# Generated at 2022-06-24 02:18:39.258135
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:18:45.223613
# Unit test for function strip_html
def test_strip_html():
    assert strip_html('') == ''
    assert strip_html('\n\n') == '\n\n'
    assert strip_html('test: <a href="foo/bar">click there</a>') == 'test: '
    assert strip_html('test: <a href="foo/bar">click there</a>', keep_tag_content=True) == 'test: click there'
    assert strip_html('<p><br>This<br />Is a <b>string</b></p>') == 'ThisIs a string'
    assert strip_html('<p><br>This<br />Is a <b>string</b></p>', keep_tag_content=True) == 'ThisIs a string'

# Generated at 2022-06-24 02:18:46.616267
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'

test_reverse()


# Generated at 2022-06-24 02:18:48.234433
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False

# Generated at 2022-06-24 02:18:53.175168
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    Compressor = __StringCompressor

    input_string = 'This is a test'
    encoding = 'utf-8'

    compressed_string = Compressor.compress(input_string, encoding)
    decompressed_string = Compressor.decompress(compressed_string, encoding)

    assert decompressed_string == input_string

# END UNIT TEST

# PUBLIC API

# Blocks

# Generated at 2022-06-24 02:18:57.209958
# Unit test for function strip_margin
def test_strip_margin():
    input = """
|line 1
|line 2
| line 3
|  line 4
|       line 5
|               line 6
|line 7
"""
    output = """
line 1
line 2
line 3
 line 4
      line 5
              line 6
line 7
"""
    assert strip_margin(input) == output


# Generated at 2022-06-24 02:19:03.057854
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode("(I)") == 1
    assert roman_decode("(II)") == 2
    assert roman_decode("(III)") == 3
    assert roman_decode("(IV)") == 4
    assert roman_decode("(V)") == 5
    assert roman_decode("(VI)") == 6
    assert roman_decode("(VII)") == 7
    assert roman_decode("(VIII)") == 8
    assert roman_decode("(IX)") == 9
    assert roman_decode("(X)") == 10
    assert roman_decode("(XI)") == 11
    assert roman_decode("(XII)") == 12
    assert roman_decode("(XIII)") == 13


# Generated at 2022-06-24 02:19:07.425061
# Unit test for function booleanize
def test_booleanize():
    """
    Unit test for function booleanize
    :return:
    """
    # Test normal case
    assert booleanize('true') == True

    # Test normal case, with a different case
    assert booleanize('TRUE') == True

    # Test normal case, with a different case and a digit
    assert booleanize('yes') == True

    # Test normal case, with 2 digits
    assert booleanize('y') == True

    # Test normal case, false
    assert booleanize('yesss') == False

    # Test normal case, false
    assert booleanize('False') == False



# Generated at 2022-06-24 02:19:11.037728
# Unit test for function prettify

# Generated at 2022-06-24 02:19:18.131281
# Unit test for function reverse
def test_reverse():
    # If we pass an empty string...
    assert reverse('') == ''

    # If we pass a single char...
    assert reverse('a') == 'a'

    # If we pass a string made of multiple chars...
    assert reverse('abc') == 'cba'
    assert reverse('hello') == 'olleh'

    # If we pass a string with spaces
    assert reverse(' hello ') == ' olleh'

    # If we pass a string with non ascii chars
    assert reverse('àèìòù') == 'ùòìèà'



# Generated at 2022-06-24 02:19:27.853390
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(1) == 'I'
    assert roman_encode(10) == 'X'
    assert roman_encode(33) == 'XXXIII'
    assert roman_encode(37) == 'XXXVII'
    assert roman_encode(2020) == 'MMXX'
    assert roman_encode(3999) == 'MMMCMXCIX'
    with pytest.raises(InvalidInputError):
        roman_encode('k')
    with pytest.raises(InvalidInputError):
        roman_encode('xxxx')
    with pytest.raises(InvalidInputError):
        roman_encode(0)
    with pytest.raises(InvalidInputError):
        roman_encode(4000)
        
test_roman_encode()