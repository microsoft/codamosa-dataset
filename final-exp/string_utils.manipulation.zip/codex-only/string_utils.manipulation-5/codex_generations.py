

# Generated at 2022-06-24 02:09:22.518446
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('MCMXCIX') == 1999
    with raises(InvalidInputError):
        roman_decode('VIIX')



# Generated at 2022-06-24 02:09:33.928179
# Unit test for function decompress

# Generated at 2022-06-24 02:09:45.201072
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers().__mappings == [{1: 'I', 5: 'V'}, {1: 'X', 5: 'L'}, {1: 'C', 5: 'D'}, {1: 'M'}]
    assert __RomanNumbers().__encode_digit(0, 1) == 'I'
    assert __RomanNumbers().__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers().__encode_digit(1, 4) == 'XL'
    assert __RomanNumbers().__encode_digit(2, 3) == 'CCC'
    assert __RomanNumbers().__encode_digit(3, 9) == 'CM'
    assert __RomanNumbers().encode(9) == 'IX'
    assert __RomanNumbers().encode(1999) == 'MCMXCIX'
    assert __

# Generated at 2022-06-24 02:09:51.074718
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    __StringFormatter("string")
    try :
        __StringFormatter(7)
    except InvalidInputError as e:
        assert e.input == 7
    with pytest.raises(InvalidInputError):
        __StringFormatter(7)



# Generated at 2022-06-24 02:09:55.609137
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # set of integers to test
    input_values = list(range(1, 4000))

    # shuffle values
    random.shuffle(input_values)

    # encode all values to roman strings
    encoded_values = [__RomanNumbers.encode(v) for v in input_values]

    # assert no empty string has been generated
    empty_strings = [v for v in encoded_values if not v]
    assert empty_strings == []

    # decode all encoded values and assert results are equal
    decoded_values = [__RomanNumbers.decode(e) for e in encoded_values]
    assert decoded_values == input_values


# EXPORTED API



# Generated at 2022-06-24 02:10:05.908318
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('hello').format() == 'Hello'
    assert __StringFormatter('hello w o r l d').format() == 'Hello World'
    assert __StringFormatter('hello, world').format() == 'Hello, World'
    assert __StringFormatter('hello, world!').format() == 'Hello, World!'
    assert __StringFormatter('hello world').format() == 'Hello World'
    assert __StringFormatter('hello world!').format() == 'Hello World!'
    assert __StringFormatter('hello-world').format() == 'Hello World'
    assert __StringFormatter('hello-world!').format() == 'Hello World!'
    assert __StringFormatter('http://google.com').format() == 'http://google.com'

# Generated at 2022-06-24 02:10:07.923836
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    try:
        __StringFormatter(None)
        print("FAIL: Method StringFormatter() not raising InvalidInputError")
    except InvalidInputError:
        print("PASSED: Method StringFormatter() raising InvalidInputError")


# Generated at 2022-06-24 02:10:12.631445
# Unit test for function slugify
def test_slugify():
    assert slugify("Top 10 Reasons To Love Dogs!!!") == 'top-10-reasons-to-love-dogs'
    assert slugify("Chienne d'histoire") == 'chienne-d-histoire'
    assert slugify("Mönstér Mägnët") == 'monster-magnet'
    assert slugify("C'est vrai, c'est beau, c'est bon") == 'c-est-vrai-c-est-beau-c-est-bon'
    assert slugify("This is nice!") == 'this-is-nice'
    assert slugify("This is nice!!!") == 'this-is-nice'
    assert slugify("This is nice,") == 'this-is-nice'
    assert slugify("This is nice.") == 'this-is-nice'


# Generated at 2022-06-24 02:10:15.181645
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('') == False
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('n') == False
    assert booleanize('no') == False
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('y') == True
    assert booleanize('yes') == True


# Generated at 2022-06-24 02:10:24.289869
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode('1') == 'I'
    assert roman_encode('3') == 'III'
    assert roman_encode('4') == 'IV'
    assert roman_encode('5') == 'V'
    assert roman_encode('6') == 'VI'
    assert roman_encode('9') == 'IX'
    assert roman_encode('10') == 'X'
    assert roman_encode('40') == 'XL'
    assert roman_encode('50') == 'L'
    assert roman_encode('90') == 'XC'
    assert roman_encode('100') == 'C'
    assert roman_encode('400') == 'CD'
    assert roman_encode('500') == 'D'
    assert r

# Generated at 2022-06-24 02:10:32.970190
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # assert format('a aa A aA aaA') == 'A Aa a aa aAa'
    assert __StringFormatter('a aa A aA aaA').format() == 'A Aa a aa aAa'

    # assert format('a aa AA aA aAa') == 'A Aa a aA aAa'
    assert __StringFormatter('a aa AA aA aAa').format() == 'A Aa a aA aAa'

    # assert format('a aa AAA aA aAa') == 'A Aa a aA aAa'
    assert __StringFormatter('a aa AAA aA aAa').format() == 'A Aa a aA aAa'

    # assert format('a aa AAA aA aAa aaa aaA

# Generated at 2022-06-24 02:10:44.500735
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('1') == '1'
    assert reverse('12') == '21'
    assert reverse('123') == '321'
    assert reverse('1234') == '4321'
    assert reverse('12345') == '54321'
    assert reverse('123456789') == '987654321'
    assert reverse('1234567890') == '0987654321'
    assert reverse('12345678901') == '10987654321'
    assert reverse('123456789012') == '210987654321'
    assert reverse('Hello world!') == '!dlrow olleH'
    assert reverse('Pippo Pluto Paperino Paperina') == 'anirePa anireppaP otulP oppiP'

# Generated at 2022-06-24 02:10:50.558243
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('i am a STRING').format() == 'I am a string'
    assert __StringFormatter('over 90000000000000000000!!!').format() == 'Over 90000000000000000000!!!'
    assert __StringFormatter('   hello there   !   ').format() == 'Hello there !'
    assert __StringFormatter('   hello there   !   ').format() == 'Hello there !'
    assert __StringFormatter('    hello there    !    ').format() == 'Hello there !'
    assert __StringFormatter('Hey look, I`m 23 years old !').format() == 'Hey look, I`m 23 years old !'
    assert __StringFormatter('hey, look ! I`m a 23-years-old!!!').format() == 'Hey, look ! I`m a 23-years-old!!!'
    assert __String

# Generated at 2022-06-24 02:10:51.810178
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') is True
    assert booleanize('YES') is True
    assert booleanize('nope') is False



# Generated at 2022-06-24 02:10:57.886190
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('string')
    try:
        # Need to be a string
        __StringFormatter(12)
    except InvalidInputError as e:
        assert e.value == 12
    except:
        assert False



# Generated at 2022-06-24 02:11:00.116259
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''



# Generated at 2022-06-24 02:11:02.820446
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('HELLO') == 'OLLEH'
    assert reverse(12345) == '54321'
    assert reverse('HELLO\n') == '\nOLLEH'
    assert reverse(4567.9) == '9.7654'



# Generated at 2022-06-24 02:11:15.565924
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(4) == 'IV'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(8) == 'VIII'
    assert __RomanNumbers.encode(9) == 'IX'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(25) == 'XXV'
    assert __RomanNumbers.encode(42) == 'XLII'
    assert __RomanNumbers.encode(99) == 'XCIX'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(333) == 'CCCXXXIII'

# Generated at 2022-06-24 02:11:22.148258
# Unit test for function decompress
def test_decompress():
    original_string = "This is a very long string with a lot of repetitions, This is a very long string with a lot of repetitions, This is a very long string with a lot of repetitions, This is a very long string with a lot of repetitions"
    compressed = compress(original_string)
    assert original_string == decompress(compressed)

test_decompress()


# Generated at 2022-06-24 02:11:23.066856
# Unit test for function compress
def test_compress():
    string = 'this is a test'
    comp = compress(string)
    assert decompress(comp) == string

# Generated at 2022-06-24 02:11:34.029701
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    import random
    import string


# Generated at 2022-06-24 02:11:37.013290
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert 'word n' in original
    assert len(compressed) < len(original)
    assert original == decompress(compressed)



# Generated at 2022-06-24 02:11:46.867462
# Unit test for method format of class __StringFormatter

# Generated at 2022-06-24 02:11:47.772797
# Unit test for function shuffle
def test_shuffle():
    assert 'l wodheorll' == shuffle('hello world')
    
    

# Generated at 2022-06-24 02:11:58.196200
# Unit test for function compress
def test_compress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert compressed == 'eJyVUWtv3DAQ/7VGeG+g9XsVLiBbZuCzVYSAbTgH7V0J1mLfQrN7VUcN6xj+TDVsRZ6CYDMpU/O6dKuq3GS0y6mX7VuXsXsx7VuqtOkoaovO624TzgC0BSG2HukIx17Vb9g+PtWJAAFQCgHw=='


# Generated at 2022-06-24 02:12:01.262563
# Unit test for function strip_margin
def test_strip_margin():
    assert(strip_margin('''
                          | line 1
                          | line 2
                          | line 3
                          |''') == '''| line 1
                          | line 2
                          | line 3
                          |''')
    print('strip_margin is working correctly')


if __name__ == '__main__':
    test_strip_margin()

# Generated at 2022-06-24 02:12:10.393922
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert 'theSnakeIsGreen' == snake_case_to_camel('the_snake_is_green', upper_case_first=False)
    assert 'the' == snake_case_to_camel('the')
    assert 'the' == snake_case_to_camel('the', upper_case_first=False)
    assert 'The' == snake_case_to_camel('the', upper_case_first=True)
    assert 'HelloWorld' == snake_case_to_camel('hello_world', True)
    assert 'helloWorld' == snake_case_to_camel('hello_world', upper_case_first=False)
    assert 'helloWorld' == snake_case_to_camel('hello_world')
    assert 'helloWorld' == snake_case_to_camel('helloWorld')


# Generated at 2022-06-24 02:12:16.434631
# Unit test for function compress
def test_compress():
    assert compress(' '.join(['word n{}'.format(n) for n in range(20)])) == 'eJyLjssKy1TchDUzs9P0oEtJKpwNTIwMjC04sQkN1kJTcjXzSZmrSQ='



# Generated at 2022-06-24 02:12:20.742052
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    test_result = camel_case_to_snake('ThisIsACamelStringTest')
    assert test_result == 'this_is_a_camel_string_test'
test_camel_case_to_snake()



# Generated at 2022-06-24 02:12:24.767617
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) == 'XXXVIII'
    assert roman_encode('2020') == 'MMXX'
test_roman_encode()


# Generated at 2022-06-24 02:12:28.367604
# Unit test for function decompress
def test_decompress():
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    decompressed = decompress(compressed)
    assert(original == decompressed)


# This is a private class used to format strings following some grammar and formatting rules

# Generated at 2022-06-24 02:12:32.288108
# Unit test for function shuffle
def test_shuffle():
    try:
        shuffle(None)
        assert False
    except Exception as e:
        assert isinstance(e, InvalidInputError)
    assert shuffle('hello world') != 'hello world'
    assert 'jfkdsafafdsadf' != shuffle('jfkdsafafdsadf')


# Generated at 2022-06-24 02:12:36.758255
# Unit test for function strip_html
def test_strip_html():
    assert HTML_TAG_ONLY_RE == re.compile('<[^>]+>')
    assert HTML_RE == re.compile('<[^>]+>|&[a-z]+;')
    assert strip_html('<p>Hello World</p>')=='Hello World'
    assert strip_html('iam<p>Hello World</p>haha')=='iamHello Worldhaha'
    assert strip_html('<p><br>Hello World</p>')=='Hello World'
    assert strip_html('<p><br>Hello World</p>')=='Hello World'
    assert strip_html('<p>Hello World<br></p>')=='Hello World'
    assert strip_html('<p>Hello World<br>')=='Hello World'

# Generated at 2022-06-24 02:12:47.508383
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('I') == 1
    assert roman_decode('MIX') == 1009
    assert roman_decode('XCIX') == 99
    assert roman_decode('XXVII') == 27
    assert roman_decode('V') == 5
    assert roman_decode('LIV') == 54
    assert roman_decode('CLXXXV') == 185
    assert roman_decode('CCVI') == 206
    assert roman_decode('CIII') == 103
    assert roman_decode('LI') == 51
    assert roman_decode('DCCLXXII') == 772
    assert roman_decode('MMMCCCXXII') == 3322

# Generated at 2022-06-24 02:12:53.978431
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode('3') == 'III'
    assert __RomanNumbers.encode(3) == 'III'
    assert __RomanNumbers.encode(999999) == 'MMMMMMMCMXCIX'
    assert __RomanNumbers.encode(10000) == 'MMMMMMMMMM'

    assert __RomanNumbers.decode('III') == 3
    assert __RomanNumbers.decode('MMMMMMMMMM') == 10000


# Generated at 2022-06-24 02:12:56.908107
# Unit test for function reverse
def test_reverse():
    assert reverse('') == ''
    assert reverse('abc') == 'cba'
    assert reverse('abcde') == 'edcba'



# Generated at 2022-06-24 02:13:06.270247
# Unit test for function compress
def test_compress():
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    # pad on the right with spaces
    compressed = compressed + ' ' * (76 - len(compressed))
    origin = original + ' ' * (169 - len(original))
    # if compression is success then print result
    if origin == compressed:
        print('Compression Successfull\n')
    else:
        print('Compression Failed\n')
# MAIN PROGRAM
test_compress()

# TODO: Write unit tests for compress and decompress


# Generated at 2022-06-24 02:13:13.568527
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('this is a test') != 'this is a test'
    assert shuffle('this is a test') != 'this is a test'
    assert shuffle('this is a test') != 'this is a test'
    assert shuffle('this is a test') != 'this is a test'



# Generated at 2022-06-24 02:13:23.579962
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(0) == '', 'zero is an invalid value'
    assert roman_encode(4000) == '', 'upper limit is 3999'
    assert roman_encode(1) == 'I', '1'
    assert roman_encode(2) == 'II', '2'
    assert roman_encode(3) == 'III', '3'
    assert roman_encode(4) == 'IV', '4'
    assert roman_encode(5) == 'V', '5'
    assert roman_encode(6) == 'VI', '6'
    assert roman_encode(9) == 'IX', '9'
    assert roman_encode(10) == 'X', '10'

# Generated at 2022-06-24 02:13:30.301160
# Unit test for function decompress
def test_decompress():
    n = 0 # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(original)
    assert decompress(compressed) == original

if __name__ == '__main__':
    test_decompress()

# Generated at 2022-06-24 02:13:38.196359
# Unit test for function roman_encode

# Generated at 2022-06-24 02:13:43.406926
# Unit test for function asciify
def test_asciify():
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
test_asciify()



# Generated at 2022-06-24 02:13:50.907777
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1) == 'I'
    assert __RomanNumbers.encode(5) == 'V'
    assert __RomanNumbers.encode(10) == 'X'
    assert __RomanNumbers.encode(50) == 'L'
    assert __RomanNumbers.encode(100) == 'C'
    assert __RomanNumbers.encode(1000) == 'M'

    assert __RomanNumbers.encode(6) == 'VI'
    assert __RomanNumbers.encode(16) == 'XVI'
    assert __RomanNumbers.encode(40) == 'XL'
    assert __RomanNumbers.encode(90) == 'XC'
    assert __RomanNumbers.encode(400) == 'CD'
    assert __RomanNumbers.encode(900) == 'CM'

    assert __RomanNumbers

# Generated at 2022-06-24 02:13:52.838988
# Unit test for function compress
def test_compress():
    print("BEGIN TEST_COMPRESS")
    s = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(s)
    assert len(s) != len(compressed)



# Generated at 2022-06-24 02:13:55.580313
# Unit test for function prettify
def test_prettify():
    assert prettify(' the string,  will be'
                    ' prettified .it\' s awesome! ') == 'The string, will be "prettified". It\'s awesome!'
    assert prettify('unprettified string ,, like this one,will be "prettified" .it\' s awesome! ') == 'Unprettified string, like this one, will be "prettified". It\'s awesome!'



# Generated at 2022-06-24 02:14:05.925962
# Unit test for function decompress

# Generated at 2022-06-24 02:14:09.651406
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    class_string_compressor = __StringCompressor()


# PUBLIC API



# Generated at 2022-06-24 02:14:10.598975
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    __RomanNumbers()



# Generated at 2022-06-24 02:14:15.465095
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7



# Generated at 2022-06-24 02:14:26.328837
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    assert __StringFormatter('lorem ipsum').format() == 'Lorem ipsum'
    assert __StringFormatter('rambo 2').format() == 'Rambo 2'
    assert __StringFormatter('1066 the battle of hastings').format() == '1066 The Battle of Hastings'
    assert __StringFormatter('hello world it\'s lorem ipsum').format() == 'Hello world, it\'s lorem ipsum'
    assert __StringFormatter('hello world, it\'s lorem ipsum').format() == 'Hello world, it\'s lorem ipsum'
    assert __StringFormatter('hello world; it\'s lorem ipsum').format() == 'Hello world, it\'s lorem ipsum'
    assert __StringFormatter('hello world. it\'s lorem ipsum').format()

# Generated at 2022-06-24 02:14:30.778912
# Unit test for function reverse
def test_reverse():
    # Test
    input_string = 'hello'
    expected = 'olleh'
    actual = reverse(input_string)
    assert actual == expected, 'Unit test failed'
    # Test
    input_string = ''
    expected = ''
    actual = reverse(input_string)
    assert actual == expected, 'Unit test failed'
test_reverse()


# Generated at 2022-06-24 02:14:41.606313
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('XIII') == 13
    assert roman_decode('XXII') == 22
    assert roman_decode('XXIII') == 23
    assert roman_decode('XLIX') == 49
    assert roman_decode('LXXVII') == 77
    assert roman_decode('LXXXIV') == 84
    assert roman_decode('CXLVI') == 146
    assert roman_decode('CLXXVI') == 176
    assert roman_decode('CLXXXIII') == 183
    assert roman_decode('CCXCIX') == 299
    assert roman_decode('CCCXCIV') == 394
    assert roman_decode('CDXCIX') == 499
    assert roman_decode('DCCCXLVIII') == 848
   

# Generated at 2022-06-24 02:14:54.844034
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    normal_cases = [
        ('the_snake_is_green', True, 'TheSnakeIsGreen'),
        ('the_snake_is_green', False, 'theSnakeIsGreen'),
        ('the_snake_is_green', True, 'TheSnakeIsGreen', '_'),
        ('the_snake_is_green', False, 'theSnakeIsGreen', '_'),
        ('the-snake-is-green', True, 'TheSnakeIsGreen', '-'),
        ('the-snake-is-green', False, 'theSnakeIsGreen', '-'),
    ]


# Generated at 2022-06-24 02:15:03.378713
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    sf = __StringFormatter('a aa aa aaa aaa aaa aa bbb ccc')
    assert sf.format() == 'A aa aa aaa aaa aaa aa bbb ccc'

    sf = __StringFormatter('You@me.com')
    assert sf.format() == 'You@me.com'

    sf = __StringFormatter('You@me.com, http://www.me.com')
    assert sf.format() == 'You@me.com, http://www.me.com'

    sf = __StringFormatter('1a 2a 3 a')
    assert sf.format() == '1a 2a 3 a'

    sf = __StringFormatter('1 a 2a 3a')

# Generated at 2022-06-24 02:15:06.814784
# Unit test for function asciify
def test_asciify():
    assert asciify('åéø') == 'ao'
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'



# Generated at 2022-06-24 02:15:15.352486
# Unit test for constructor of class __StringCompressor
def test___StringCompressor():
    example_string = 'Hello World!'
    example_encoding = 'UTF-8'
    expected_compressed_string = 'eJyr5iNjJ0bUxNLEvMTSwzYpPLVcyMLEzTc2NNQQAADABMgA'
    expected_decompressed_string = 'Hello World!'

    assert __StringCompressor.compress(example_string, encoding=example_encoding) == expected_compressed_string
    assert __StringCompressor.decompress(expected_compressed_string, encoding=example_encoding) == expected_decompressed_string



# Generated at 2022-06-24 02:15:22.301970
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    pretty = __StringFormatter.format('hello, from stack overflow!')
    pretty = __StringFormatter.format('hello, from stack overflow!')
    assert pretty == 'Hello, from stack overflow!'

    pretty = __StringFormatter.format('this method is very complicated to run, because it does a lot of things at once')
    assert pretty == 'This method is very complicated to run, because it does a lot of things at once'

    pretty = __StringFormatter.format('it must not remove spaces from links http://google.com/test or from emails test@test.com or from numbers like (555) 555-12')
    assert pretty == 'It must not remove spaces from links http://google.com/test or from emails test@test.com or from numbers like (555) 555-12'


# Generated at 2022-06-24 02:15:26.198924
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    out = snake_case_to_camel('the_snake_is_green')
    assert out == 'TheSnakeIsGreen'


# Generated at 2022-06-24 02:15:35.694526
# Unit test for function slugify
def test_slugify():
    test_cases = (
        'pie',
        'pie-',
        '-pie',
        'pie-pie',
        'pie-pie-',
        '-pie-pie',
        'pie-pie-pie',
        '-pie-pie-',
        'pie-pie-pie-',
        '-pie-pie-pie',
        'pie-pie-pie-pie',
        'pie-pie-pie-pie-pie',
        '-pie-pie-pie-pie-pie',
        'pie-pie-pie-pie-pie-pie',
        '--',
        '-',
    )
    for test_case in test_cases:
        assert slugify(test_case) == "pie", slugify(test_case) + ' != ' + "pie"

test_slugify()


# Generated at 2022-06-24 02:15:43.278234
# Unit test for function strip_html
def test_strip_html():
    input_string = 'test: <a href="foo/bar">click here</a>'
    expected_output = 'test: click here'
    if strip_html(input_string, True) != expected_output:
        raise AssertionError(expected_output, strip_html(input_string, True))
    input_string = 'test: <a href="foo/bar">click here</a>'
    expected_output = 'test: '
    if strip_html(input_string) != expected_output:
        raise AssertionError(expected_output, strip_html(input_string))



# Generated at 2022-06-24 02:15:53.935807
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    assert __RomanNumbers.encode(1954) == 'MCMLIV'
    assert __RomanNumbers.encode(1990) == 'MCMXC'
    assert __RomanNumbers.encode(2014) == 'MMXIV'
    assert __RomanNumbers.encode(3999) == 'MMMCMXCIX'

    assert __RomanNumbers.decode('XXI') == 21
    assert __RomanNumbers.decode('II') == 2
    assert __RomanNumbers.decode('MCMXLIV') == 1944
    assert __RomanNumbers.decode('XXXVII') == 37
    assert __RomanNumbers.decode('MMXIV') == 2014
    assert __RomanNumbers.decode('IV') == 4


# PUBLIC API



# Generated at 2022-06-24 02:15:58.577458
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('YES') == True
    assert booleanize('nope') == False


# Generated at 2022-06-24 02:16:04.694997
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
    |    line 1
    |    line 2
    |    line 3
    ''') == '''
    line 1
    line 2
    line 3
    '''


# PUBLIC API ALIASES

strip_url = partial(strip_html, keep_tag_content=True)

# Generated at 2022-06-24 02:16:06.125467
# Unit test for method format of class __StringFormatter
def test___StringFormatter_format():
    # replace this for custom test
    assert True

# Generated at 2022-06-24 02:16:17.033508
# Unit test for function compress
def test_compress():
    n = 0  # <- ignore this, it's a fix for Pycharm (not fixable using ignore comments)
    # "original" will be a string with 169 chars:
    original = ' '.join(['word n{}'.format(n) for n in range(20)])
    # "compressed" will be a string of 88 chars
    compressed = compress(original)
    print('original size: {}'.format(len(original)))
    print('compressed size: {}'.format(len(compressed)))
    restored = decompress(compressed)
    print('restored size: {}'.format(len(restored)))
    assert original == restored



# Generated at 2022-06-24 02:16:27.610433
# Unit test for function roman_encode
def test_roman_encode():
    # Try to encode a valid number
    result = roman_encode("420")
    expected = "CDXX"
    assert result == expected

    # Try to encode a invalid number
    try:
        roman_encode("4000")
        assert False
    except:
        assert True

    # Try to encode a invalid number
    try:
        roman_encode("0")
        assert False
    except:
        assert True

    # Try to encode a invalid number
    try:
        roman_encode("CDXX")
        assert False
    except:
        assert True



# Generated at 2022-06-24 02:16:35.875362
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    input_string = 'snake_case_string'
    expected_string = 'SnakeCaseString'
    assert expected_string == snake_case_to_camel(input_string)
    input_string = 'snake_case_string'
    expected_string = 'snakeCaseString'
    assert expected_string == snake_case_to_camel(input_string, False)
    input_string = 'snake-case-string'
    expected_string = 'SnakeCaseString'
    assert expected_string == snake_case_to_camel(input_string, True, '-')


# Generated at 2022-06-24 02:16:45.009362
# Unit test for function prettify

# Generated at 2022-06-24 02:16:51.070712
# Unit test for function reverse
def test_reverse():
    assert reverse('hello') == 'olleh'
    assert reverse('ciao') == 'oaic'
    assert reverse('a') == 'a'
    assert reverse('ab') == 'ba'
    assert reverse('') == ''
    assert reverse(' ') == ' '
    assert reverse(None) == None
    assert reverse(123) == None


# Generated at 2022-06-24 02:16:56.660171
# Unit test for function strip_margin
def test_strip_margin():
    assert strip_margin('''
                        line 1
                        line 2
                        line 3
                        ''') == '''
line 1
line 2
line 3
'''
    print("test_strip_margin: passed")
    
test_strip_margin()


# Generated at 2022-06-24 02:16:59.673518
# Unit test for function asciify
def test_asciify():
    print('Testing function asciify... ', end='', flush=True)
    assert asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË') == 'eeuuooaaeynAAACIINOE'
    print('Passed.')



# Generated at 2022-06-24 02:17:03.033086
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('VII') == 7
    assert roman_decode('VII') == 7
    assert roman_decode('VII') == 7
    assert roman_decode('VII') == 7

# Generated at 2022-06-24 02:17:05.532875
# Unit test for function strip_margin
def test_strip_margin():
    str1 = '''
            line 1
            line 2
            line 3
            '''
    print(strip_margin(str1))



# Generated at 2022-06-24 02:17:13.921211
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    assert snake_case_to_camel('the_snake_is_green') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen', upper_case_first=False) == 'theSnakeIsGreen'
    assert snake_case_to_camel('TheSnakeIsGreen', upper_case_first=False, separator='-') == 'TheSnakeIsGreen'
    assert snake_case_to_camel('the-snake-is-green', upper_case_first=False, separator='-') == 'theSnakeIsGreen'



# Generated at 2022-06-24 02:17:20.634753
# Unit test for function prettify
def test_prettify():
    assert prettify(' tidy up  the string  like this one.') == 'Tidy up the string like this one.'
    assert prettify('test: <a href="foo/bar">click here</a>') == 'Test: <a href="foo/bar">click here</a>'
    assert prettify('test: <a href="foo/bar">click here</a>', keep_tag_content=True) == 'Test: click here'
    assert prettify('  test: foo bar') == 'Test: foo bar'
    assert prettify('test: foo bar  ') == 'Test: foo bar'
    assert prettify('<tag>foo</tag> <tag>bar</tag>') == '<tag>foo</tag> <tag>bar</tag>'

# Generated at 2022-06-24 02:17:21.777036
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    inst = __StringFormatter("s")
    assert inst.input_string == "s"



# Generated at 2022-06-24 02:17:28.155415
# Unit test for function asciify
def test_asciify():
    assert asciify("test") == "test"
    assert asciify("èòàìù") == "eoa_i_u"
    assert asciify("Þ.Æ.À.Ö.Å") == "_.A.A.O.A"
    assert asciify("tét") == "t_t"



# Generated at 2022-06-24 02:17:30.859173
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('') == ''
    assert shuffle('hello world') != 'hello world'
    assert shuffle('hello world') == shuffle('hello world')



# Generated at 2022-06-24 02:17:32.838677
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    import math
    out = __StringFormatter(4).format()
    math.isnan(out)



# Generated at 2022-06-24 02:17:37.701818
# Unit test for function strip_html
def test_strip_html():
    assert is_full_string(strip_html('<p>Test</p>')) == False
    assert is_full_string(strip_html('<p>Test</p>', keep_tag_content=True)) == True
#end test_strip_html



# Generated at 2022-06-24 02:17:44.882956
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('true') == True
    assert booleanize('1') == True
    assert booleanize('yes') == True
    assert booleanize('y') == True
    assert booleanize('false') == False
    assert booleanize('0') == False
    assert booleanize('no') == False
    assert booleanize('n') == False
    assert booleanize('ciao') == False

#
#
#


# Generated at 2022-06-24 02:17:51.612142
# Unit test for function shuffle
def test_shuffle():
    for string in ["test", "", "       ", "test with spaces"]:
        shuffled_string = shuffle(string)
        assert set(shuffled_string) == set(string), "Chars of {} are not shuffled".format(string)
        #assert len(shuffled_string) == len(string), "String length after shuffling is not the same as before"



# Generated at 2022-06-24 02:18:01.190196
# Unit test for function booleanize
def test_booleanize():
    assert booleanize('') == False
    assert booleanize(' ') == False
    assert booleanize('A') == False
    assert booleanize('True') == True
    assert booleanize('TRUE') == True
    assert booleanize('false') == False
    assert booleanize('1') == True
    assert booleanize('0') == False
    assert booleanize('yes') == True
    assert booleanize('YES') == True
    assert booleanize('NO') == False
    assert booleanize('n') == False
    assert booleanize('y') == True
    assert booleanize('Y') == True
    assert booleanize('N') == False


# Generated at 2022-06-24 02:18:03.769487
# Unit test for function snake_case_to_camel
def test_snake_case_to_camel():
    string = "the_snake_is_green"
    output = snake_case_to_camel(string, upper_case_first = True, separator = '_')
    assert output == "TheSnakeIsGreen"

# Generated at 2022-06-24 02:18:06.239043
# Unit test for function compress
def test_compress():
    input_string = ' '.join(['word n{}'.format(n) for n in range(20)])
    compressed = compress(input_string)
    assert isinstance(compressed, str)


# Generated at 2022-06-24 02:18:10.977394
# Unit test for function camel_case_to_snake
def test_camel_case_to_snake():
    assert camel_case_to_snake("ThisIsACamelStringTest") == "this_is_a_camel_string_test"


# Generated at 2022-06-24 02:18:11.835238
# Unit test for function shuffle
def test_shuffle():
    assert shuffle('hello world') != 'hello world'



# Generated at 2022-06-24 02:18:22.314325
# Unit test for function prettify

# Generated at 2022-06-24 02:18:25.002254
# Unit test for function asciify
def test_asciify():
    assert asciify("èéùúòóäåëýñÅÀÁÇÌÍÑÓË") == 'eeuuooaaeynAAACIINOE'

test_asciify()


# Generated at 2022-06-24 02:18:36.081854
# Unit test for function asciify
def test_asciify():
    assert 'aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789 ' == asciify(
        'aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789 ')
    assert 'eeuuooaaeynAAACIINOE' == asciify('èéùúòóäåëýñÅÀÁÇÌÍÑÓË')
    assert 'elhlo world' == asciify('elhlo world')
    assert '' == asciify(' ')

# Generated at 2022-06-24 02:18:38.880012
# Unit test for function roman_encode
def test_roman_encode():
    assert roman_encode(37) # returns 'XXXVIII'
    assert roman_encode('2020') # returns 'MMXX'
test_roman_encode()



# Generated at 2022-06-24 02:18:51.260303
# Unit test for function slugify
def test_slugify():
    assert slugify('Top 10 Reasons To Love Dogs!!!') == 'top-10-reasons-to-love-dogs'
    assert slugify('Mönstér Mägnët') == 'monster-magnet'
    assert slugify('给老人买不') == 'gei-lao-ren-mai-bu'
    assert slugify('Русский вариант') == 'russkiy-variant'
    assert slugify('इसे साफ करें') == 'ise-saf-karen'
    assert slugify('Éléments définis') == 'elements-definis'

# Generated at 2022-06-24 02:18:59.790374
# Unit test for constructor of class __RomanNumbers
def test___RomanNumbers():
    # Test rules required in order to encode input numbers into roman numbers
    assert __RomanNumbers.__encode_digit(0, 1) == 'I'
    assert __RomanNumbers.__encode_digit(0, 2) == 'II'
    assert __RomanNumbers.__encode_digit(0, 3) == 'III'
    assert __RomanNumbers.__encode_digit(0, 4) == 'IV'
    assert __RomanNumbers.__encode_digit(0, 5) == 'V'
    assert __RomanNumbers.__encode_digit(0, 6) == 'VI'
    assert __RomanNumbers.__encode_digit(0, 7) == 'VII'
    assert __RomanNumbers.__encode_digit(0, 8) == 'VIII'

# Generated at 2022-06-24 02:19:05.551842
# Unit test for function roman_decode
def test_roman_decode():
    assert roman_decode('I') == 1
    assert roman_decode('II') == 2
    assert roman_decode('III') == 3
    assert roman_decode('IV') == 4
    assert roman_decode('V') == 5
    assert roman_decode('VI') == 6
    assert roman_decode('VII') == 7
    assert roman_decode('VIII') == 8
    assert roman_decode('IX') == 9
    assert roman_decode('X') == 10
    assert roman_decode('XI') == 11
    assert roman_decode('XII') == 12
    assert roman_decode('XIII') == 13
    assert roman_decode('XIV') == 14

# Generated at 2022-06-24 02:19:10.716606
# Unit test for constructor of class __StringFormatter
def test___StringFormatter():
    assert __StringFormatter('wow') is not None
    try:
        __StringFormatter(5)
        assert False
    except InvalidInputError:
        assert True


# Generated at 2022-06-24 02:19:19.617923
# Unit test for constructor of class __StringCompressor