

# Generated at 2022-06-24 19:17:56.695749
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'provisioner'
    str_1 = 'group'
    task_result_0 = TaskResult(str_0, str_1, {'results': [{'foo': True}]})
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:17:58.694151
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = ':_3'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    var_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:17:59.347151
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert is_skipped()


# Generated at 2022-06-24 19:18:02.114824
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '"&\\QP"\nRQ&\'95{'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:05.739448
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '"&\\QP"\nRQ&\'95{'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    bool_1 = False
    var_0 = task_result_0.needs_debugger(bool_1)


# Generated at 2022-06-24 19:18:10.522366
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '"&\\QP"\nRQ&\'95{'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:18:16.165876
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '_g[:f~'
    str_1 = '[Bz\'7sU`}6U'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, str_1)
    bool_1 = task_result_0.needs_debugger(bool_0)

if __name__ == '__main__':
    print('Running tests for TaskResult')
    # Tests for TaskResult
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:18:21.763119
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:18:28.046780
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '"&\\QP"\nRQ&\'95{'
    str_1 = 'P%\t\\D\'\n9'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_1, bool_0)
    var_0 = task_result_0.needs_debugger(bool_0)

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:18:31.613331
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'Q\'V7&u"a1@l7OC'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    var_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:42.280957
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result = task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:51.247762
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'kBA*$OW'
    bool_0 = False
    str_1 = 'Qf^1mTk'
    task_result_0 = TaskResult(str_0, str_1, str_1)
    task_result_0.needs_debugger(bool_0)
    task_result_0 = TaskResult(str_1, str_0, str_0)
    task_result_0.needs_debugger(bool_0)
    task_result_0 = TaskResult(str_0, str_0, str_1)
    task_result_0.needs_debugger(bool_0)
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger(bool_0)
    task_result

# Generated at 2022-06-24 19:18:54.588812
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

# Generated at 2022-06-24 19:19:02.956881
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    str_1 = '*v)V2'
    str_2 = '60}'
    str_3 = '+w0[>'
    list_0 = [str_0, str_1, str_2]
    dict_0 = {'_ansible_parsed': str_0}
    dict_1 = {'_ansible_no_log': bool_0}
    dict_2 = {str_3: str_1, '_ansible_no_log': bool_0}
    dict_3 = {'_ansible_no_log': bool_0, '_ansible_parsed': str_0}
    dict_4 = {}

# Generated at 2022-06-24 19:19:04.871322
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # TaskResult_is_failed
    bool_0 = TaskResult.is_failed('') # Execution test failed
    bool_1 = TaskResult.is_failed('') # Execution test failed


# Generated at 2022-06-24 19:19:07.732819
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_0.is_failed()



# Generated at 2022-06-24 19:19:12.545201
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:15.818814
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '}+`]vDnP$'
    TaskResult.clean_copy()


# Generated at 2022-06-24 19:19:19.382828
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult('', '', '')
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:26.893966
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:19:37.615555
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str = 'mW&O-o0b}@'



# Generated at 2022-06-24 19:19:38.587623
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert(test_case_0())


# Generated at 2022-06-24 19:19:39.856364
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert False


# Generated at 2022-06-24 19:19:43.420265
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    ts_0 = TaskResult(['y2FcSM_9'], {'a':0}, {'b':1}, {'c':0})
    assert ts_0.clean_copy() == {'a':0, 'b':1, 'c':0}


# Generated at 2022-06-24 19:19:47.267392
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    arguments = {'task_fields': {'debugger': 'on_skipped'}, 'host': 'localhost', 'task': 'PlaybookResult', 'return_data': '{}uV7Bpj1'}
    taskresult = TaskResult(**arguments)
    assert taskresult.needs_debugger(False) == False



# Generated at 2022-06-24 19:19:50.629225
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '}+`]vDnP$'


# Generated at 2022-06-24 19:19:52.940998
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result = TaskResult(None, None, None)
    assert task_result.is_skipped() == False


# Generated at 2022-06-24 19:19:54.360748
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    first = TaskResult('doge')
    second = first.clean_copy()
    assert second.task_name == 'doge'

# Generated at 2022-06-24 19:19:56.388766
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    v_0 = TaskResult(test_case_0(), test_case_0(), test_case_0())
    v_1 = v_0._check_key(test_case_0())


# Generated at 2022-06-24 19:20:00.095233
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert TaskResult.is_skipped('self') == False


# Generated at 2022-06-24 19:20:15.315169
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Y&b*h|nqk'
    dict_0 = dict()
    task_result_0 = TaskResult(str_0, str_0, dict_0)
    bool_0 = task_result_0.needs_debugger()
    assert bool_0 == False



# Generated at 2022-06-24 19:20:18.473184
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    data = '_[:fZ~'
    task_result_0 = TaskResult(data, data, data)
    bool_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:20:26.631342
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '_'
    str_1 = 'M'
    str_2 = '1'
    bool_0 = False
    dict_0 = dict()
    dict_0['_ansible_parsed'] = False
    dict_0['vars'] = dict_0
    dict_0['stat'] = dict_0
    dict_0['changed'] = False
    dict_0['invocation'] = dict_0
    dict_0['skip_reason'] = str_0
    dict_0['_ansible_no_log'] = False
    dict_0['rc'] = 0
    dict_0['failed_when_result'] = False
    dict_0['_ansible_item_result'] = True
    dict_0['_ansible_ignore_errors'] = False

# Generated at 2022-06-24 19:20:30.531006
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '*'
    bool_0 = False
    dict_0 = dict()
    task_result_0 = TaskResult(str_0, bool_0, dict_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:20:35.563082
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)



# Generated at 2022-06-24 19:20:42.792569
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    a= {}
    a['failed'] = True
    task_result_0 = TaskResult('', '', a)
    if not task_result_0.is_failed():
        raise Exception('Failure')
    
    a['failed'] = False
    task_result_1 = TaskResult('', '', a)
    if task_result_1.is_failed():
        raise Exception('Failure')


# Generated at 2022-06-24 19:20:50.743781
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    host_0 = '"\x7f\x1f\x1c\xa0\x14\x11\x06\x15\xa4t\x03\x82\xa9\x0c\x1f\xb5\xa6\x07\x1f\x8b\xf7\x0f\xa7\xfc\x1e\x0c\x0e\xf5\x8a6\xfb\xc0\xa3\x9f\x83\x1f\x95\xe7'

# Generated at 2022-06-24 19:20:56.203454
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'lII-<_'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_0.is_failed()
    assert bool_1 is False


# Generated at 2022-06-24 19:21:00.608539
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    lst_0 = ['02', 'B^', 'e#', '_[:fZ~', '&', '*', '_[:fZ~']
    int_0 = 0

# Generated at 2022-06-24 19:21:05.596600
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_0.is_skipped()
    str_1 = '_[:fZ~'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    bool_2 = task_result_1.is_skipped()
    assert bool_1 == bool_2


# Generated at 2022-06-24 19:21:18.033788
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '_[:fZ~'
    bool_2 = True
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger(bool_2)


# Generated at 2022-06-24 19:21:24.539390
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '@z'
    str_1 = '9vl%'
    int_0 = 0
    str_2 = 'gT'
    str_3 = '$Dlx'
    int_1 = -34
    str_4 = 'U'
    str_5 = '~f'
    task_result_0 = TaskResult(str_0, str_1, str_2)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._host == str_0
    assert task_result_1._task == str_1
    assert task_result_1._result == str_2
    assert task_result_1._task._ds == {'safe': True}
    assert task_result_1._task._uid == str_3
    assert task_

# Generated at 2022-06-24 19:21:26.200307
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    # FIXME: implement unit test here
    assert True



# Generated at 2022-06-24 19:21:31.492304
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'v1'
    dict_0 = {"ansible_facts": "test_facts"}
    bool_0 = True
    task_result_0 = TaskResult(str_0, dict_0, dict_0)
    assert not task_result_0.needs_debugger(), "task_result_0.needs_debugger() did not return False as expected"



# Generated at 2022-06-24 19:21:33.718758
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_skipped() == bool_0


# Generated at 2022-06-24 19:21:35.715540
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:21:40.381002
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    """
    Assert is_skipped returns boolean value
    """
    task_name = 'test_TaskResult_is_skipped'
    task_result = TaskResult('host', 'task', {'test': True, 'skipped': True, 'failed': False})
    result = task_result.is_skipped()
    assert result == True


# Generated at 2022-06-24 19:21:43.685573
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)


# Generated at 2022-06-24 19:21:46.326099
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)


# Generated at 2022-06-24 19:21:49.011600
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_1 = 'Ex2&'
    bool_1 = True
    task_result_1 = TaskResult(str_1, str_1, str_1)
    assert not task_result_1.is_skipped()


# Generated at 2022-06-24 19:22:09.754477
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'O=%2'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:22:19.820085
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'h'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert (task_result_0.is_skipped() == bool_0)
    str_1 = 'A~i\x7f3m'
    bool_1 = False
    task_result_1 = TaskResult(str_1, str_1, str_1)
    assert (task_result_1.is_skipped() == bool_1)
    str_2 = '5'
    bool_2 = False
    task_result_2 = TaskResult(str_2, str_2, str_2)
    assert (task_result_2.is_skipped() == bool_2)
    str_3 = ''
    bool_3 = False


# Generated at 2022-06-24 19:22:22.405580
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '~t'
    bool_0 = False
    task_result_1 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_1.is_failed()


# Generated at 2022-06-24 19:22:26.017934
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '_[:fZ~'
    bool_0 = False
    test_case_0()
    task_result_0 = TaskResult(str_0, str_0, str_0)
    #assert not task_result_0.is_failed()
    bool_0 = True
    #assert task_result_0.is_failed()


# Generated at 2022-06-24 19:22:31.259416
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '__'
    exception_type_0 = AssertionError
    str_1 = 'A%'
    str_2 = 'M'
    dict_0 = {str_0: str_0, 'GU#': str_1, str_2: str_2}
    task_result_0 = TaskResult(str_0, str_0, dict_0)
    task_result_1 = TaskResult(str_0, str_0, dict_0)
    task_result_1._result.update({'changed': False})
    task_result_2 = TaskResult(str_0, str_0, dict_0)
    task_result_2._result.update({'changed': True})
    task_result_2.is_changed()

# Generated at 2022-06-24 19:22:38.047855
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_1 = '$'
    str_2 = 'exV4'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    task_result_0 = task_result_1.clean_copy()
    bool_0 = task_result_0.is_skipped()
    str_0 = task_result_0.task_name
    bool_1 = task_result_0.is_unreachable()
    bool_2 = task_result_0.is_changed()
    bool_3 = task_result_0.is_failed()


# Generated at 2022-06-24 19:22:40.848181
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '_[:fZ~'
    bool_0 = False
    str_1 = '=t\rMe#'
    task_result_0 = TaskResult(str_0, str_1, str_0)
    bool_1 = task_result_0.is_failed()
    assert bool_1 == bool_0


# Generated at 2022-06-24 19:22:45.462240
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('x', '', '')
    task_result_0._result['_ansible_no_log'] = True
    task_result_0.clean_copy()


# description: clean up internal keys for actual output
# param str_0:
# return: str

# Generated at 2022-06-24 19:22:51.556960
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = ';XpKG'
    str_1 = 'B4'
    str_2 = 'VJ!X'
    str_3 = '~+EuA'
    str_4 = 'MYI~)'
    str_5 = 'nWFr'
    str_6 = 'D'
    str_7 = 'K'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_1, bool_0)
    if (task_result_0._check_key(str_2)):
        assert ((not ((not task_result_0.is_failed()) or (not task_result_0.is_unreachable()))))

# Generated at 2022-06-24 19:22:54.089626
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'X'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)


# Generated at 2022-06-24 19:23:38.836584
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '`i'
    str_1 = '9#Q'
    str_2 = '^F'
    str_3 = '27'
    str_4 = 'Y;'
    str_5 = '_'
    dict_0 = {str_3 : str_2, str_4 : str_2, str_5 : str_0}
    dict_1 = {str_1 : dict_0, str_2 : dict_0}
    task_result_0 = TaskResult(str_0, str_2, dict_1)
    task_result_1_0 = task_result_0.clean_copy()
    assert task_result_1_0._task_fields is not None
    assert task_result_1_0._result == dict_1
    assert task_result_1_0._

# Generated at 2022-06-24 19:23:44.639385
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:50.050688
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'j'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, bool_0)
    bool_expect_0 = False
    bool_expect_1 = True
    bool_1 = task_result_0.is_failed()

    if bool_1 == bool_expect_0:
        print("PASS")
    else:
        print("FAIL")

    task_result_0._result = {'failed': False}
    bool_2 = task_result_0.is_failed()

    if bool_2 == bool_expect_0:
        print("PASS")
    else:
        print("FAIL")

    task_result_0._result = {'failed': True, 'failed_when_result': False}

# Generated at 2022-06-24 19:23:57.646031
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult('', '', '')
    str_0 = 'w<t~Oc'
    bool_0 = False
    task_result_0._task_fields = {str_0: bool_0}
    task_result_0._task = 'ZzHG'
    task_result_0._task._action = 'e:U6'
    task_result_0._result = {'failed': False, 'failed_when_result': False, 'results': [{'failed': False, 'failed_when_result': False}, {'failed': False, 'failed_when_result': False}, {'failed': False, 'failed_when_result': False}]}

    assert task_result_0.needs_debugger() == False


# Generated at 2022-06-24 19:24:03.895402
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Jd<F'
    str_1 = 'd)p%'
    dict_0 = dict()
    dict_2 = dict()
    dict_2['failed'] = True
    dict_2['invocation'] = dict(module_name = 'setup', module_args = '',)
    dict_0['invocation'] = dict_2
    dict_0['failed'] = True
    dict_0['_ansible_no_log'] = False
    TaskResult.clean_copy(TaskResult(str_0, str_0, dict_0))


# Generated at 2022-06-24 19:24:13.870065
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Declare objects and variables
    str_0 = 'm:0|$=@Z'

    # Assertion message
    msg_0 = "Failed at assertion 'task_result_0.is_skipped() == False'"

    # Call the method to test
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_skipped() == False, msg_0
    # Call the method to test
    task_result_0 = TaskResult(str_0, str_0, dict())
    assert task_result_0.is_skipped() == False, msg_0
    # Call the method to test

# Generated at 2022-06-24 19:24:15.628262
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('_[:fZ~', '_[:fZ~', '_[:fZ~')
    task_result_0.clean_copy()



# Generated at 2022-06-24 19:24:20.871537
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Test for method is_failed(TaskResult.is_failed())
    assert TaskResult.is_failed(TaskResult(True, True, True))


# Generated at 2022-06-24 19:24:24.331031
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '9fuBY'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_result_0.is_failed()
    assert not bool_1


# Generated at 2022-06-24 19:24:34.111150
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '9SQz'
    bool_0 = True

# Generated at 2022-06-24 19:26:07.898024
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'l)_z&B:L#Zgq#W}F'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    locally_enabled_0 = not bool_0
    globally_enabled_0 = False
    result_0 = task_result_0.needs_debugger(locally_enabled_0)


# Generated at 2022-06-24 19:26:12.172886
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    data_0 = {'changed': True}
    str_0 = '_[:fZ~'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, data_0)
    # assert task_result_0.needs_debugger() ==


# Generated at 2022-06-24 19:26:16.718474
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'FlFCn'
    bool_0 = True
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.needs_debugger(bool_0)


# Generated at 2022-06-24 19:26:19.372544
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'l'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result = task_result_0.is_skipped()


# Generated at 2022-06-24 19:26:23.950743
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '< \n!ecN'
    str_1 = '>hJ0?4+'
    str_2 = 'E'
    task_result_0 = TaskResult(str_0, str_1, str_2)
    # str_0 is the boolean value.
    # str_1 is the boolean value.
    assert not task_result_0.needs_debugger(str_0)
    # str_0 is the boolean value.
    assert not task_result_0.needs_debugger(str_0)
    # str_0 is the boolean value.
    # str_1 is the boolean value.
    assert not task_result_0.needs_debugger(str_0, str_1)
    # str_0 is the boolean value.
    # str_1 is the boolean value.


# Generated at 2022-06-24 19:26:25.120502
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:26:35.685770
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult('_[:fZ~', '_[:fZ~', '_[:fZ~')
    bool_0 = task_result_0.is_failed()
    assert bool_0 == False
    task_result_0 = TaskResult('', '', '')
    bool_0 = task_result_0.is_failed()
    assert bool_0 == False
    task_result_0 = TaskResult('[', 'ix`/|;', '{')
    bool_0 = task_result_0.is_failed()
    assert bool_0 == False
    task_result_0 = TaskResult('f', 'h', 'p')
    bool_0 = task_result_0.is_failed()
    assert bool_0 == False

# Generated at 2022-06-24 19:26:37.549623
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    if task_result_0.needs_debugger(bool_0):
        raise Exception("needs_debugger returned wrong value")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:26:43.251144
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\'_'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert(task_result_0.needs_debugger(True) == True)


# Generated at 2022-06-24 19:26:50.187718
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '`H,=z%.e[s'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)

    test_cases = [
        (task_result_0, False, False),
    ]

    for test_case in test_cases:
        task_result = test_case[0]
        globally_enabled = test_case[1]
        expect = test_case[2]

        print(test_case)
        result = task_result.needs_debugger(globally_enabled)
        assert result == expect, "failed test"
