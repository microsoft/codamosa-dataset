

# Generated at 2022-06-24 19:17:55.225875
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Construct a mock Task
    task = C.ANSIBLE_TASK_TEMPLATE()
    task.action = 'setup'
    task.name = 'setup'
    task.tags = ['group_tags']
    task.when = None
    task.async_val = 5
    task.async_enabled = False
    task.delegate_to = 'localhost'
    task.poll = 0
    task.failed_when = None
    task.ignore_errors = False
    task.notify = []
    task.first_available_file = None
    task.sudo = False
    task.sudo_user = 'root'
    task.transport = 'smart'
    task.register = None
    task.become = False
    task.become_method = 'sudo'
    task.become_user

# Generated at 2022-06-24 19:17:59.769350
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:18:06.079396
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\xff\xe3\xc2\xce\xbe\xfb\xd1\x1d\x1f\x99\xdc\xcb\x98\x98\xde\xfa\xad\xed\x91\xb8\x89\xe4\xaa\x84\x93'
    bool_0 = True
    str_0 = 'X9jGl%&'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._result['status'] == 0


# Generated at 2022-06-24 19:18:13.642709
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:17.612608
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert(task_result_0.needs_debugger() == False)


# Generated at 2022-06-24 19:18:29.169417
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    # AssertionError: False != True
    # assert not task_result_0.is_skipped() == True
    # AssertionError: False != True
    # assert not task_result_0.is_skipped() == True
    # AssertionError: False != True
    # assert not task_result_0.is_skipped

# Generated at 2022-06-24 19:18:36.730974
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()

test_case_0()
test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:18:46.709740
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    try:
        task_result_0 = TaskResult(bytes, bool, str)
        globally_enabled = True
        assert task_result_0.needs_debugger(globally_enabled) == False
    except (AnsibleError, AnsibleConnectionFailure, AnsibleFileNotFound, AnsibleParserError,
            AnsibleUndefinedVariable, AnsibleModuleError, AnsibleAction, AssertionError, LookupError,
            AnsibleFilterError) as exception:
        pass


if __name__ == "__main__":
    print("Testing TaskResult")
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:18:54.768545
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Assigning arguments
    bytes_0 = b'\xa3\x8d\x9f\x95\xab\xec\xef\xa0\x97\x86\x86\x8c\x9e'
    bool_0 = False
    str_0 = 'E-7>~%<*[V7zB2i9cebS'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    # Calling is_failed
    result = task_result_0.is_failed()
    assert result is True


# Generated at 2022-06-24 19:19:03.053978
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(None, Task(), str_0)
    TaskResult_TaskResult__result = getattr(task_result_0, '_TaskResult__result')
    setattr(task_result_0, '_TaskResult__result', str_1)
    TaskResult_TaskResult__task = getattr(task_result_0, '_TaskResult__task')
    setattr(task_result_0, '_TaskResult__task', str_2)
    TaskResult_TaskResult__task_fields = getattr(task_result_0, '_TaskResult__task_fields')
    setattr(task_result_0, '_TaskResult__task_fields', str_3)
    TaskResult_clean_copy_str_0 = None

# Generated at 2022-06-24 19:19:15.774399
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    global test_case_0
    try:
        test_case_0()
        logger.info('Test case passed')
    except Exception as e:
        logger.error('Test case failed')


# MAIN #
if __name__ == '__main__':
    from ansible.utils.log import setup_logger

    logger = setup_logger('Test TaskResult')

    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:19:17.960973
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    a = TaskResult(None, None, None, None)
    test_case_0()
    a.clean_copy()


# Generated at 2022-06-24 19:19:21.257556
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    flag = 0
    test = TaskResult(None, None, None)
    result = test.is_failed()
    if result != False:
        flag = 1
    if flag == 0:
        print("test_TaskResult_is_failed passed")
    else:
        print("test_TaskResult_is_failed failed")


# Generated at 2022-06-24 19:19:24.058662
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # TODO: Hide this?
    # str_0 = 'group_tags'
    # result = TaskResult.is_failed( TaskResult, str_0)
    assert 'asdf' == 'asdf'


# Generated at 2022-06-24 19:19:29.961698
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Create an instance of class TaskResult
    taskresult = TaskResult('host', 'task', {}, {'name': 'task_name', 'module_name': 'module_name'})
    # Test method clean_copy of class TaskResult
    test_TaskResult_clean_copy_0(taskresult)


# Generated at 2022-06-24 19:19:34.948200
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    # This test case is used to test the is_failed method of TaskResult

    # First, create a TaskResult class
    from ansible.executor.task_result import TaskResult
    import json
    loader = DataLoader()
    data = loader.load(filename = "./plays/test_data/test_TaskResult_is_failed.json")
    host = "localhost"
    task = None
    task_fields = None
    tr = TaskResult(host, task, data, task_fields)
    #tr.print_data()
    print(tr.is_failed())


# Generated at 2022-06-24 19:19:38.062741
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    obj = TaskResult(str_0, str_0, obj, obj)
    is_failed = obj.is_failed()
    assert is_failed == bool_0


# Generated at 2022-06-24 19:19:46.914731
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    loader = DataLoader()

    task_fields = dict()
    load_column = 'task'
    task = Task.load(loader=loader, task=task_fields, variable_manager=None, loader_cache=None)

    str_0 = 'group_tags'
    task_fields[str_0] = str_0
    str_1 = 'no_log'
    task_fields[str_1] = False
    str_2 = 'ignore_errors'
    task_fields[str_2] = False
    task.set_loader(loader)
    task.no_log=False
    task.ignore_errors=False

    str_3 = 'host'

# Generated at 2022-06-24 19:19:53.003419
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_fields = {
        'name': 'Test'
    }
    task_result = TaskResult(None, None, str_0, task_fields)
    clean_copy = task_result.clean_copy()
    assert isinstance(clean_copy, TaskResult)


# Generated at 2022-06-24 19:19:55.500748
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    args_0 = {}
    ret_0 = {}
    cleansed = method_clean_copy(args_0, ret_0)
    return cleansed

#
# TODO: Refactor to use AnsibleModule?
#


# Generated at 2022-06-24 19:20:04.634205
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    host0 = DataLoader()
    task0 = dict()
    return_data0 = dict()
    task_fields0 = dict()
    task_result_0 = TaskResult(host0, task0, return_data0, task_fields0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:20:09.760158
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-24 19:20:18.311614
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:25.937526
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.is_failed()
    task_result_0._check_key("failed")
    task_result_0._check_key("results")
    return {'task_result': task_result_0}


# Generated at 2022-06-24 19:20:26.945990
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:20:33.618213
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.is_skipped() == '\x1f\x9aC'


# Generated at 2022-06-24 19:20:38.254136
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = False
    str_0 = 'No|y~\x16\x1d)\xa4\x1f0\xf7\x14\xac\xa4\x1a\xebi\x14\x02\x18'
    str_1 = '3q\x1c\x01\x9a\xc8)K\x81x\x99\xba\xaa\xf1\x97\xe5\xc9\x86m\xcc\xe7\x13'

# Generated at 2022-06-24 19:20:47.644515
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = False
    str_0 = '?B\x1a\x84SL\x0bS\x0f\x81\x1d'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0 = task_result_0.clean_copy()
    task_result_1 = task_result_0.clean_copy()
    bool_1 = task_result_1.is_failed()
    bool_2 = task_result_1.is_failed()
    bool_

# Generated at 2022-06-24 19:20:58.145176
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.is_skipped()
    int_0 = 0
    str_1 = ''

# Generated at 2022-06-24 19:20:59.504467
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert True == test_TaskResult_is_skipped()


# Generated at 2022-06-24 19:21:09.497291
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    task_result_clean_copy_result_0 = TaskResult(False, False, False).clean_copy()
    assert task_result_clean_copy_result_0 is not None


# Generated at 2022-06-24 19:21:16.984762
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert isinstance(task_result_0.clean_copy(), TaskResult)


# Generated at 2022-06-24 19:21:26.440882
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

# Generated at 2022-06-24 19:21:33.261386
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:21:42.785781
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b's\xc5\xcb\xf2\x9a\xdc\x0b\xac\x1a\x8b\xc3\x83\xd3\x08^\x8c\x03\x0f'
    bytes_1 = b'3\x85J\xf0\xb9\xb4\x90\x03\x92\x83\x8e\xf1\xd5\x9bQ\x9e\x8f\x7f'
    bool_0 = True
    str_0 = 'Ue_p$\x7f\x07\x04\x80\x04\x91\x15b\x0b\x0cs'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

# Generated at 2022-06-24 19:21:51.337932
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.is_skipped()
    assert(bool_1 == False)


# Generated at 2022-06-24 19:21:56.161600
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_1 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0 = TaskResult(task_result_1.clean_copy())



# Generated at 2022-06-24 19:22:00.295908
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.needs_debugger(True)


# Generated at 2022-06-24 19:22:07.709517
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\xfc\x04l\xb8\x80\xb3\xdc\x90\x88\x9a\x93\x92\x88\xeb\x05p\x93\x88nI\x1a'
    bool_0 = True
    str_0 = '}c%z8r!3O"*'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()
    # AssertionError: module_stderr , module_stdout not found in TaskResult._result


# Generated at 2022-06-24 19:22:16.158644
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    task_result_0.is_skipped()


# Generated at 2022-06-24 19:22:37.373958
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('in test_TaskResult_is_failed')
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:22:44.504357
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:22:52.146692
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    task_result_0 = TaskResult(3, '3YpL`', False)
    task_result_0._task_fields = {'debugger': '3YpL`'}
    bool_0 = task_result_0.needs_debugger(False)
    assert bool_0 == False

    task_result_1 = TaskResult(3, '3YpL`', False)
    bool_1 = task_result_1.needs_debugger(False)
    assert bool_1 == False


# Generated at 2022-06-24 19:22:57.113934
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:22:59.163123
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    result = TaskResult(None, None, dict(failed=True))
    assert result.needs_debugger()


# Generated at 2022-06-24 19:23:04.997164
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.needs_debugger() is False


# Generated at 2022-06-24 19:23:13.706086
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = False
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.is_failed()
    bool_2 = task_result_0.is_failed()


# Generated at 2022-06-24 19:23:19.291348
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Input parameters of this method
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    # Output of this method
    test_output_0 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:23:25.827514
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.needs_debugger() == False


# Generated at 2022-06-24 19:23:32.725544
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:23:55.889947
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:04.889642
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    b''
    task_result_0 = TaskResult(None, True, '_ansible_ignore_errors')
    task_result_1 = TaskResult(None, True, '_ansible_ignore_errors')
    task_result_2 = TaskResult(None, False, '_ansible_no_log')
    task_result_3 = TaskResult(None, True, '_ansible_ignore_errors')
    task_result_4 = TaskResult(None, False, '_ansible_no_log')
    task_result_5 = TaskResult(None, True, '_ansible_ignore_errors')
    task_result_6 = TaskResult(None, False, '_ansible_no_log')
    task_result_7 = TaskResult(None, True, '_ansible_ignore_errors')
    task_

# Generated at 2022-06-24 19:24:14.836513
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

# Generated at 2022-06-24 19:24:24.492408
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert not task_result_0.is_failed()
    pass


# Generated at 2022-06-24 19:24:33.859890
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:42.111703
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\xa6\x12\xf1\xcc\x83>\xa6:\x7f\xbbQ\xec\xa9\x93\xea\x83\xcd\x98\x83\x92\x90P\x97\x9c\x93\xb0\xba\xba\x90\xc2\x1cQ'
    bool_0 = True

# Generated at 2022-06-24 19:24:49.686177
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:52.778433
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert callable(TaskResult.clean_copy)


# Generated at 2022-06-24 19:25:00.405686
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    try:
        task_result_0.is_failed()
    except:
        print('test_TaskResult_is_failed failed')


# Generated at 2022-06-24 19:25:02.987570
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult(None, None, None)
    result = task_result_0.is_skipped()
    assert result == False


# Generated at 2022-06-24 19:25:26.896693
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b"\xfb\xf9\xac'\x1d\xeb\x81\x1b\xc5\xb8\x9b0\x9e\x1a\x97\x16\xe5\x17\xd5\xad\x8b\x0b"
    bool_0 = True
    str_0 = 'nCE'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.is_failed()
    task_result_1 = TaskResult(bytes_0, bool_0, str_0)
    task_result_2 = TaskResult(bytes_0, bool_0, str_0)
    task_result_2.is_changed()

# Generated at 2022-06-24 19:25:33.276729
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    result = task_result_0.needs_debugger()
    assert result == False

    bytes_0 = b'6\x10R\xce'
    bool_0 = True
    str_0 = 'Mh5\x0f\xbd'

# Generated at 2022-06-24 19:25:43.657867
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.is_skipped()
    assert bool_1 == False
    # One more for good measure

# Generated at 2022-06-24 19:25:48.244763
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'4\xa4"k\xd5\x1c\xb6\x0c\xac\xeb\xb8\xd9\xb1\xa1\xc3\x8d\xcf'
    bool_0 = False
    str_0 = 'H\x1bA\x1d\x12'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:25:55.188648
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    result_1 = task_result_0.clean_copy()
    assert len(result_1) == 20

# Generated at 2022-06-24 19:25:59.920524
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)

    # Call method 'clean_copy' of class 'TaskResult'
    task_result_0.clean_copy()



# Generated at 2022-06-24 19:26:06.125833
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.needs_debugger(bool_0)
    assert bool_1 == False


# Generated at 2022-06-24 19:26:07.443356
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:26:15.539541
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_0 = task_result_0.is_failed()
    assert bool_0


# Generated at 2022-06-24 19:26:22.648109
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.needs_debugger()

#######
# main
#######
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:26:45.372738
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:54.338491
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:26:59.240379
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    bool_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:27:06.893119
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.is_failed()



# Generated at 2022-06-24 19:27:08.722018
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(str_0, bool_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:16.210899
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\xa8/\x1a\xd1\x87\xa2\x92\x8d\x91\xa9\xef\x97\xdc\x85\x16\x17\x19\r\x06\x12\x0f\x1c\x1e\x1f\x1d\x0e\x11\x0c\x10\x08\x14\x1b\x15\x13\x18'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    # Bool return value of result does not match expected value.
    assert test_TaskResult_is_skipped

# Generated at 2022-06-24 19:27:23.603208
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x83\xdc\xff\xc2\x86\x80\xb8\x94\x7f\x95\x1f\xf9\xbbR\xbe\xe5\x94\x9aC'
    bool_0 = True
    str_0 = 'N2auwS>2Gw))6!58%'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_1 = task_result_0.clean_copy()



# Generated at 2022-06-24 19:27:31.521304
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x0e\xf3\xbe\xe8\x1f\xfb\xb3\xa6\xf8\xd9\xb1\x05\x87\x80\x8f\x0c\xda\x93\xcb\xe9i'
    bool_0 = True
    str_0 = 'Dp`ZSBj[m(dn&f4z'
    task_result_0 = TaskResult(bytes_0, bool_0, str_0)
    task_result_0.task_name
    task_result_0._task_fields = {}
    assert not task_result_0.is_failed()
    task_result_0._result = {'failed': True}
    assert task_result_0.is_failed()
    task_result_0

# Generated at 2022-06-24 19:27:32.655771
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # FIXME: implement this test
    pass
