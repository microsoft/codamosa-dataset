

# Generated at 2022-06-24 19:18:00.503717
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    dict_0 = {}
    float_0 = -813.64
    task_result_0 = TaskResult(dict_0, float_0, tuple_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:18:02.911047
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:18:06.867972
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    bool_0 = task_result_0.needs_debugger()
    assert(not bool_0)


# Generated at 2022-06-24 19:18:12.464366
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    bool_0 = task_result_0.needs_debugger()
    bool_1 = task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:18:14.908309
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)

    result = task_result_0.is_failed()


# Generated at 2022-06-24 19:18:17.847072
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)

    # assert False, task_result_0.is_failed()


# Generated at 2022-06-24 19:18:23.500101
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = 1.29
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_0._result = {'skipped': True}
    assert task_result_0.is_skipped() == True
    task_result_0._result = {'skipped': False}
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:18:26.661326
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    tuple_0 = ()
    float_0 = -170.858
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:18:36.327825
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = -9.60925
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    bool_0 = task_result_0.is_skipped()
    assert not bool_0
    tuple_1 = ()
    float_1 = -170.29
    task_result_1 = TaskResult(tuple_1, float_1, tuple_1)
    bool_1 = task_result_1.is_skipped()
    assert not bool_1
    tuple_2 = ()
    float_2 = 524.657
    task_result_2 = TaskResult(tuple_2, float_2, tuple_2)
    bool_2 = task_result_2.is_skipped()
    assert not bool_2
    tuple_

# Generated at 2022-06-24 19:18:40.608472
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tuple_0 = ()
    float_0 = -914.84
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1.is_changed() == False
    assert task_result_1.is_skipped() == False
    assert task_result_1.is_failed() == False
    assert task_result_1.is_unreachable() == False
    assert task_result_1.needs_debugger() == False


# Generated at 2022-06-24 19:18:53.088272
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)

    # Test with default arguments
    task_result_0.clean_copy()


if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:18:57.094341
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    tuple_0 = ()
    float_0 = 1.097

    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    print('True') if task_result_0.is_skipped() == False else print('False')

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_is_skipped()

# Generated at 2022-06-24 19:19:01.438099
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:08.466746
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = -44.98
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_0._task_fields = {}
    task_result_0._task_fields['ignore_errors'] = False
    task_result_0._task = ()
    task_result_0._result = {}
    task_result_0._result['results'] = []
    task_result_0._result['results'].append({})
    task_result_0._result['results'][0]['skipped'] = False
    task_result_0._result['results'][0]['failed'] = True
    assert task_result_0.is_skipped() == False
    dict_0 = {}

# Generated at 2022-06-24 19:19:13.697313
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:18.940761
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:21.645008
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    tuple_0 = ()
    float_0 = 22.3068000023
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    expected = True
    actual = task_result_0.is_failed()
    assert actual == expected


# Generated at 2022-06-24 19:19:26.011515
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    globally_enabled = False
    bool_0 = task_result_0.needs_debugger(globally_enabled)

if __name__ == '__main__':
    import sys
    func = getattr(sys.modules[__name__], sys.argv[1])
    args = None
    if len(sys.argv) > 2:
        args = sys.argv[2:]
    func(*args)

# Generated at 2022-06-24 19:19:28.514171
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    result = task_result_0.is_skipped()
    assert False == result


# Generated at 2022-06-24 19:19:31.215540
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    tuple_0 = ()
    float_0 = -436.157
    task_result_0 = TaskResult(tuple_0, float_0, tuple_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:19:42.361741
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.needs_debugger(False)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:19:46.470095
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.is_skipped()
    assert bool_0 is False


# Generated at 2022-06-24 19:19:52.971681
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0_clean = task_result_0.clean_copy()
    return task_result_0_clean


# Generated at 2022-06-24 19:19:55.725111
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(float_0, float_0, float_0)
    globally_enabled_0 = bool()
    result = TaskResult.needs_debugger(task_result_0, globally_enabled_0)
    assert type(result) == bool


# Generated at 2022-06-24 19:20:02.836485
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.is_skipped()

    # FIXME: is_skipped method returns type bool

    assert bool_0 == bool()


# Generated at 2022-06-24 19:20:05.293657
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print("In test_TaskResult_is_skipped")
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    if task_result_0.is_skipped():
        raise ValueError("Incorrect value returned by is_skipped")


# Generated at 2022-06-24 19:20:08.813314
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Test TaskResult.clean_copy()
    # Not implemented
    pass



# Generated at 2022-06-24 19:20:13.259978
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = test_case_0()
    bool_0 = task_result_0.is_failed()
    assert bool_0 == True


# Generated at 2022-06-24 19:20:20.212766
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:20:26.636307
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:20:38.747905
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -436.157

    # Call task_result_0.is_skipped()
    assert False == TaskResult(float_0, float_0, float_0).is_skipped()

    # Call task_result_1.is_skipped()
    assert False == TaskResult(float_0, float_0, float_0).is_skipped()

    # Call task_result_2.is_skipped()
    assert False == TaskResult(float_0, float_0, float_0).is_skipped()

    # Call task_result_3.is_skipped()
    assert False == TaskResult(float_0, float_0, float_0).is_skipped()


# Generated at 2022-06-24 19:20:48.046336
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_5 = bool()
    float_2 = float()
    float_2 = float()
    float_3 = float()
    float_3 = float()
    float_4 = float()
    float_4 = float()
    float_5 = float()
    float_5 = float()
    float_0 = float()
    float_0 = float()
    float_1 = float()
    float_1 = float()

# Generated at 2022-06-24 19:20:55.178534
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = 1.0
    float_1 = -3.00497636634258
    str_0 = 'gjy6V-U6,u?7:lU&=uZ'
    float_2 = 6.83499987988485
    task_result_0 = TaskResult(float_1, float_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:58.683837
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -926.092672967
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._host is not float_0


# Generated at 2022-06-24 19:21:05.538165
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = 1836
    str_0 = str(int_0)
    task_result_0 = TaskResult(int_0, int_0, {str_0: int_0}, int_0)
    assert task_result_0.is_skipped() is False
    str_1 = str(int_0)
    task_result_1 = TaskResult(int_0, int_0, {str_1: int_0}, int_0)
    assert task_result_1.is_skipped() is False
    str_2 = str(int_0)
    task_result_2 = TaskResult(int_0, int_0, {str_2: int_0}, int_0)
    assert task_result_2.is_skipped() is False


# Generated at 2022-06-24 19:21:16.138176
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    for i in range(0, 10):
        task_fields = {'debugger': 'debugger', 'ignore_errors': 1}
        float_0 = float()
        float_1 = float()
        float_2 = float()
        float_3 = float()
        float_4 = float()
        task_result_0 = TaskResult(float_1, float_2, float_3, task_fields)
        task_result_0.is_failed()
        task_result_0._result = {'results': [{'failed': 1, 'changed': 1, 'invocation': {'module_name': 'module_name'}}], 'changed': 1, '_ansible_no_log': 0, 'failed': 1}
        task_result_0.is_failed()

# Generated at 2022-06-24 19:21:18.514000
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.clean_copy()

# Generated at 2022-06-24 19:21:20.877235
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
   # initialization
   float_0 = -436.157
   task_result_0 = TaskResult(float_0, float_0, float_0)
   # test
   assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:21:29.977919
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -571.958
    float_1 = 223.516
    TaskResult_0 = TaskResult(float_0, float_1, float_1)
    expected = TaskResult_0._check_key(float_1)
    actual = TaskResult_0.is_failed()
    try:
        assert (expected == actual)
    except AssertionError as e:
        print(
            'Test failed: expected {0}, actual {1}'.format(expected, actual))


# Generated at 2022-06-24 19:21:40.438548
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    import random
    float_0 = -176.324
    float_1 = -946.265
    float_2 = -868.443
    float_3 = 517.634
    task_result_0 = TaskResult(float_0, float_1, float_2)
    task_result_1 = TaskResult(float_0, float_1, float_2)
    task_result_2 = TaskResult(float_0, float_1, float_2)
    task_result_3 = TaskResult(float_0, float_1, float_2)
    task_result_4 = TaskResult(float_0, float_1, float_2)
    task_result_5 = TaskResult(float_0, float_1, float_2)

# Generated at 2022-06-24 19:21:54.106781
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    # call the method
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:21:57.160861
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(
        DataLoader().load("[yaml, json, ini], plaintext"),
        DataLoader().load("[yaml, json, ini], plaintext"),
        DataLoader().load("[yaml, json, ini], plaintext"),
    )
    data = task_result_0.needs_debugger()

## Unit test for method is_changed of class TaskResult

# Generated at 2022-06-24 19:21:59.248063
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -436.157
    testresult_0 = TaskResult(float_0, float_0, float_0)
    result = testresult_0.is_skipped()
    assert(result == False)


# Generated at 2022-06-24 19:22:02.073043
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    assert True


# Generated at 2022-06-24 19:22:05.288956
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    result_0 = task_result_0.clean_copy()
    assert result_0 is not None, "Returned value of TaskResult.clean_copy is None!"


# Generated at 2022-06-24 19:22:06.906968
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()


# Generated at 2022-06-24 19:22:14.092093
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_1 = -2.906
    bool_0 = False
    data_loader_0 = DataLoader()
    str_0 = "l"
    task_result_1 = TaskResult(bool_0, str_0, data_loader_0)
    assert task_result_1.is_skipped() == False

    int_0 = 0
    bool_1 = False
    dict_0 = {}
    dict_1 = dict_0
    dict_0["F"] = dict_1
    dict_0["F"] = dict_1
    dict_0["F"] = dict_1
    dict_0["F"] = dict_1
    dict_0["F"] = dict_1
    dict_0["F"] = dict_1
    dict_2 = dict_0
    dict_1["M"] = dict

# Generated at 2022-06-24 19:22:21.352470
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.needs_debugger()
    assert not bool_0
    bool_0 = task_result_0.needs_debugger()
    assert not bool_0
    bool_0 = task_result_0.needs_debugger(True)
    assert bool_0
    bool_0 = task_result_0.needs_debugger(True)
    assert bool_0


# Generated at 2022-06-24 19:22:29.759930
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -382.61
    float_1 = -826.68
    task_result_2 = TaskResult(float_0, float_1, float_1)
    task_result_3 = TaskResult(float_0, float_1, float_0)
    task_result_3._result = {'failed': True}
    task_result_1 = TaskResult(float_0, float_1, float_0)
    task_result_1._result = {'failed': False}
    assert task_result_1.is_failed() is False
    assert task_result_2.is_failed() is False
    assert task_result_3.is_failed() is True


# Generated at 2022-06-24 19:22:33.222527
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    dict_0 = dict()
    list_0 = list()
    dict_0['results'] = list_0
    task_result_0 = TaskResult('host', 'task', dict_0)
    assert task_result_0.is_skipped() is False


# Generated at 2022-06-24 19:22:47.727003
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -154.75
    float_1 = -143.827
    str_0 = '-1'
    str_1 = '-250'
    float_2 = -23.446
    float_3 = -1.86
    float_4 = -464.963
    str_2 = '-2'
    str_3 = '-3'
    task_result_0 = TaskResult(float_0, float_1, float_2)
    try:
        task_result_0.clean_copy()
    except Exception:
        None



# Generated at 2022-06-24 19:22:51.666465
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -8.2231806
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:01.225878
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_1 = TaskResult(float_0, float_0, float_0)
    task_result_2 = TaskResult(bool_0, float_0, float_0)
    task_result_3 = TaskResult(float_0, float_0, float_0)
    task_result_4 = TaskResult(float_0, float_0, float_0)
    task_result_5 = TaskResult(float_0, float_0, float_0)
    task_result_6 = TaskResult(float_0, float_0, float_0)
    task_result_7 = TaskResult(float_0, float_0, float_0)

# Generated at 2022-06-24 19:23:03.835336
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Skip test for some platforms
    if C.DEFAULT_INTERPRETER == '/usr/bin/pwsh' or C.DEFAULT_INTERPRETER == '/usr/bin/python2':
        return

    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:23:08.368715
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    assert not task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:16.231934
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print("Test that is_skipped returns false if there are no results")
    assert TaskResult("", "", "").is_skipped() == False

    print("Test that is_skipped returns false if there are no skipped results")
    assert TaskResult("", "", {"results": [{"skipped": False, "whatever": "whatever"}]}).is_skipped() == False

    print("Test that is_skipped returns true if all of the results are skipped")
    assert TaskResult("", "", {"results": [{"skipped": True, "whatever": "whatever"}, {"skipped": True, "whatever": "whatever"}]}).is_skipped() == True

# Generated at 2022-06-24 19:23:21.155833
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -436.157
    task_fields_0 = dict()
    task_result_0 = TaskResult(float_0, float_0, float_0, task_fields_0)
    result = task_result_0.is_failed()
    assert result == False


# Generated at 2022-06-24 19:23:25.515804
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = -427.33422
    task_result_0 = TaskResult(float_0, float_0, float_0)
    expected = False
    actual = task_result_0.needs_debugger(globally_enabled=False)
    assert expected == actual, "Expected: %s, Actual: %s" % (expected, actual)


# Generated at 2022-06-24 19:23:29.661602
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)

    # Call method
    clean_copy = task_result_0.clean_copy()

    # Test return type
    assert isinstance(clean_copy, TaskResult)



# Generated at 2022-06-24 19:23:35.787365
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = -505.370664
    task_result_0 = TaskResult(float_0, float_0, float_0, float_0)
    task_result_0.needs_debugger()
    task_result_0.needs_debugger()
    task_result_0.needs_debugger()
    task_result_0.needs_debugger()
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:23:52.477092
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:03.896701
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -542.3089
    float_1 = float_0
    string_0 = '_ansible_verbose_override'
    string_1 = '_ansible_no_log'
    list_0 = []
    list_1 = list_0
    tuple_0 = ()
    tuple_1 = tuple_0
    dict_0 = {'changed': 1, 'failed': 0, 'skipped': 0, 'task_name': 'TASK_NAME', 'task_path': 'TASK_PATH'}
    dict_1 = {}

    # Preparation
    class Test0(object):
        def method_0(self, arg_0):
            return arg_0
    in_0 = list_1
    in_1 = tuple_1
    in_2 = list_0


# Generated at 2022-06-24 19:24:05.578272
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -461.895
    task_result_0 = TaskResult(float_0, float_0, float_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:24:09.419338
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.is_failed()
    bool_1 = bool_0
    assert bool_0 == bool_1


# Generated at 2022-06-24 19:24:16.498928
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    assert not task_result_0.is_failed()
    assert not task_result_0.is_failed()
    assert not task_result_0.is_failed()

    task_result_1 = TaskResult(float_0, float_0, float_0)
    assert not task_result_1.is_failed()
    assert not task_result_1.is_failed()
    assert not task_result_1.is_failed()

    task_result_2 = TaskResult(float_0, float_0, float_0)
    assert not task_result_2.is_failed()
    assert not task_result_2.is_failed()
    assert not task_result_2

# Generated at 2022-06-24 19:24:21.785467
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -254.363
    task_result_0 = TaskResult(float_0, float_0, float_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:24:32.630868
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = -208.37459
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23

# Generated at 2022-06-24 19:24:34.014576
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(None, None, None)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:39.462619
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = float('inf')
    float_1 = float('-inf')
    float_2 = float('nan')
    task_result_0 = TaskResult(float_1, float_2, float_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:24:50.606122
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:25:32.058549
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:37.664956
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -541.428
    float_1 = 947.922
    task_0 = TaskResult(float_0, float_1, None)
    task_1 = task_0.clean_copy()


# Generated at 2022-06-24 19:25:40.584418
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # set up
    task_result_0 = TaskResult(1, 0, 0, 0)
    # execution
    result = task_result_0.is_failed()
    assert result


# Generated at 2022-06-24 19:25:42.779180
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_obj = TaskResult(float_0, float_0, float_0)
    result = task_result_obj.needs_debugger(float_0)


# Generated at 2022-06-24 19:25:49.681853
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = -4198.937
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_1 = TaskResult(float_0, float_0, float_0)
    task_result_1._task_fields = {
        "debugger": "on_failed",
    }
    task_result_3 = TaskResult(float_0, float_0, float_0)
    task_result_3._task_fields = {
        "ignore_errors": True,
        "debugger": "on_failed",
    }
    task_result_1._result = {
        "failed": False,
    }
    task_result_2 = TaskResult(float_0, float_0, float_0)

# Generated at 2022-06-24 19:25:51.936172
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    float_0 = -521.33
    task_result_0 = TaskResult(float_0, float_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:56.951866
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult('foo', {'bar': 'baz'}, {'foo': 'bar'})
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:26:00.496966
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Creating a new instance of TaskResult
    task_result_1 = TaskResult()
    # Getting the is_skipped of object task_result_1
    task_result_1.is_skipped()
    # Getting the is_skipped of object task_result_1
    task_result_1.is_skipped()


# Generated at 2022-06-24 19:26:04.283479
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_1 = -924.878
    task_result_0 = TaskResult(float_1, float_1, float_1)
    assert (task_result_0.is_failed() == False), "is_failed() method fails for %s of class %s" % ("TaskResult", "TaskResult")



# Generated at 2022-06-24 19:26:05.014354
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert TaskResult.is_skipped() == None


# Generated at 2022-06-24 19:27:22.429857
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass


# Generated at 2022-06-24 19:27:25.143276
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    float_0 = -436.157
    task_result_0 = TaskResult(float_0, float_0, float_0)
    result_bool_0 = task_result_0.is_failed()



# Generated at 2022-06-24 19:27:27.501687
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    float_0 = -716.8
    task_result_0 = TaskResult(float_0, float_0, float_0)
    bool_0 = task_result_0.is_skipped()
    assert bool_0 == False


# Generated at 2022-06-24 19:27:31.444270
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    float_0 = 7.3
    task_result_0 = TaskResult(float_0, float_0, float_0)
    a1 = True
    a2 = task_result_0.needs_debugger(a1)
    assert a2 == False, 'Expected: False, but got: %s' % a2
