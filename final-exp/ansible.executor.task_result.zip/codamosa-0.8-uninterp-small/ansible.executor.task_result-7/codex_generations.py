

# Generated at 2022-06-24 19:18:00.505702
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    try:
        test_case_0()
    except:
        assert False, 'Could not run test case test_case_0'

# Generated at 2022-06-24 19:18:08.548191
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'$\xbce,\x05\xc4w\x04k'
    set_0 = {bytes_0}
    task_result_0 = TaskResult(bytes_0, set_0, set_0)
    assert not task_result_0.needs_debugger()

    # parameter changes (don't have parameter yet)
    #assert task_result_0.needs_debugger(True)
    #assert task_result_0.needs_debugger(True, True)
    #assert not task_result_0.needs_debugger(False)
    #assert not task_result_0.needs_debugger(False, False)




# Generated at 2022-06-24 19:18:13.306195
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x03\x02\x0f\x11\x1a x\x15\xc9'
    set_0 = {bytes_0}
    task_result_0 = TaskResult(bytes_0, set_0, set_0)
    int_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:18:19.424956
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Prepare
    bytes_0 = b'$\xbce,\x05\xc4w\x04k'
    set_0 = {bytes_0}
    task_result_0 = TaskResult(bytes_0, set_0, set_0)

    # Method invocation
    task_result_0_copy = task_result_0.clean_copy()
    assert isinstance(task_result_0_copy._result, set) == True
    
    # Add assertions here
    assert len(task_result_0_copy._result) == 1
    assert isinstance(task_result_0_copy, TaskResult) == True
    assert isinstance(task_result_0_copy._result.copy().pop(), AnsibleUnsafeText) == True
   

# Generated at 2022-06-24 19:18:29.450797
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x19\xaa\x80\xc6\xe2\xe8h!\xba\x88\x1a%'
    set_0 = {bytes_0}
    task_result_0 = TaskResult(bytes_0, set_0, set_0)
    result_0 = task_result_0.is_skipped()
    assert not result_0

# Generated at 2022-06-24 19:18:39.757542
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("\ntest_TaskResult_clean_copy method")
    import json
    bytes_0 = b'(}'
    bytes_1 = b'{\x1b\x1e'
    bytes_2 = b'\x9c'
    bytes_3 = b'\x03\xb0\xa2\x1b'

# Generated at 2022-06-24 19:18:41.484636
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    #
    task_result_0 = TaskResult(None, None, None)
    #
    if task_result_0.is_failed:
        pass


# Generated at 2022-06-24 19:18:48.577252
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x16\xa0\xad\x16\x1f\x8f\xa8\x8f\x16\xd0\xbd\x8a\x92\x9f\x11\x10\x01\x1b\x04\x06\x97\n\xf2\xea\x15\x94\xaa\x8a\xa0\x00\xec\x10'
    set_0 = {bytes_0}
    task_result_0 = TaskResult(bytes_0, set_0, set_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:49.272135
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()

# Generated at 2022-06-24 19:18:52.783669
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    with pytest.raises(TypeError):
        TaskResult(None, None, None)._check_key()



# Generated at 2022-06-24 19:19:01.532401
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(None)
    task_result_1 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:19:04.665232
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # set up the following variables for testing
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # test clean_copy
    clean_copy_0 = task_result_0.clean_copy()
    assert clean_copy_0
    

# Generated at 2022-06-24 19:19:09.037997
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_1 = TaskResult(var_0, var_0, var_0)
    task_result_2 = task_result_1.clean_copy()


if __name__ == '__main__':
    import inspect
    import sys, os
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    test_case_0()

    print("All test cases finished")

# Generated at 2022-06-24 19:19:13.736920
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # call method clean_copy
    result = task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:20.934498
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = task_result_0.needs_debugger()
    assert not var_0
    # UNSUPPORTED: IfExpression(body=Call(func=Attribute(value=Name(id='task_result_0', ctx=Load()), attr='needs_debugger', ctx=Load()), args=[Name(id='var_0', ctx=Load())], keywords=[], starargs=None, kwargs=None), test=NameConstant(value=False), orelse=NameConstant(value=False))


# Generated at 2022-06-24 19:19:24.061194
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Simple test with basic settings

    var_1 = None
    var_2 = None
    task_result_1 = TaskResult(var_1, var_1, var_1)
    var_3 = task_result_1.clean_copy()
    assert var_3


# Generated at 2022-06-24 19:19:33.863763
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    hostname = 'localhost'
    task_name = 'debug'
    action = 'debug'
    my_vars = dict()
    my_vars['hostvars'] = dict()
    my_vars['hostvars'][hostname] = dict()
    var_0 = dict()
    var_0['_ansible_ignore_errors'] = None
    var_0['_ansible_item_result'] = None
    var_0['_ansible_parsed'] = True
    var_0['_ansible_no_log'] = False
    var_0['_ansible_delegated_vars'] = dict()
    var_0['_ansible_delegated_vars']['ansible_host'] = hostname

# Generated at 2022-06-24 19:19:38.443129
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    var_1 = None
    task_result_0 = TaskResult(var_0, var_1, var_0)
    var_2 = False
    assert task_result_0.needs_debugger(var_2) == 0

# Generated at 2022-06-24 19:19:42.803470
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    try:
        var_1 = task_result_0.clean_copy()
    except TypeError:
        var_1 = None
    assert var_1 is not None


# Generated at 2022-06-24 19:19:45.431393
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = None
    var_2 = None
    task_result_1 = TaskResult(var_1, var_2, var_2)
    assert False == task_result_1.needs_debugger()


# Generated at 2022-06-24 19:19:56.197008
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0._result['results'] = [{'skipped': False, '_ansible_no_log': False}, {'skipped': True, '_ansible_no_log': False}]

    assert task_result_0.is_skipped() == True


# Generated at 2022-06-24 19:20:02.098049
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {'results': [{'skipped': False}, {'skipped': False}, {'skipped': False}, {'skipped': False}]}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert(task_result_0.is_skipped() is False)
    var_1 = {'results': [{'skipped': True}, {'skipped': True}, {'skipped': True}, {'skipped': True}]}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    assert(task_result_1.is_skipped() is True)

# Generated at 2022-06-24 19:20:11.488831
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    var_1 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)

    var_0 = None
    var_1 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_2 = False
    var_3 = False
    var_4 = True
    var_5 = False
    var_6 = True
    var_7 = False
    var_8 = False
    var_9 = True
    var_10 = True
    var_11 = True
    var_12 = True
    var_13 = False
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None

# Generated at 2022-06-24 19:20:13.877463
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    task_result_1 = TaskResult(var_1, var_2, var_3)
    task_result_1.is_skipped()
    assert bool(var_4)


# Generated at 2022-06-24 19:20:18.207638
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:20:19.698750
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert True == TaskResult(None, None, None).is_failed()


# Generated at 2022-06-24 19:20:22.657817
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # Call method is_failed of class TaskResult
    result = task_result_0.is_failed()


# Generated at 2022-06-24 19:20:24.703679
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    res_0 = TaskResult(var_0, var_0, var_0)
    assert res_0.is_skipped() == False


# Generated at 2022-06-24 19:20:26.915519
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:20:35.057890
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0._check_key(var_0)
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_result_0._task_fields = '2'
    task_

# Generated at 2022-06-24 19:20:43.081341
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass


# Generated at 2022-06-24 19:20:47.494571
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = TaskResult(None, None, None)
    var_0._result = {
        'results': [
            {'failed_when_result': 'failed'},
            {'failed_when_result': 'failed'},
            {'failed_when_result': 'failed'}
        ]
    }
    test_case_0()

# Generated at 2022-06-24 19:20:57.931020
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    TASK_RESULT = {'attempts': 2, 'changed': True}
    TASK_RESULT_1 = {'attempts': 3, 'failed_when_result': False}
    TASK_RESULT_2 = {'attempts': 1, 'changed': False}

    var_0 = None
    var_1 = None
    var_2 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    if not task_result_0.is_failed():
        print('1 test executed')
    else:
        print('ERROR: test not executed')

    task_result_1 = TaskResult(var_1, var_1, TASK_RESULT)

# Generated at 2022-06-24 19:21:03.125693
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_2 = False
    var_3 = True
    var_4 = False
    task_result_1 = TaskResult(var_3, var_3, var_3)
    task_result_1._task_fields['debugger'] = var_2
    task_result_1._task_fields['ignore_errors'] = var_2

    assert task_result_1.needs_debugger == var_4
    del task_result_1



# Generated at 2022-06-24 19:21:07.504783
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = None
    task_result_0.needs_debugger(var_1)


# Generated at 2022-06-24 19:21:13.263683
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_1 = None
    var_2 = None
    task_result_1 = TaskResult(var_1, var_1, var_1)
    task_result_2 = task_result_1.clean_copy()
    assert (task_result_2 is not None)

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:16.260284
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_failed()



# Generated at 2022-06-24 19:21:18.585365
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert(task_result_0.clean_copy() is not None)

# Generated at 2022-06-24 19:21:20.260536
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    r = None
    t = None
    var_0 = TaskResult(r, t, var_0)
    var_0.needs_debugger()

# Generated at 2022-06-24 19:21:23.641186
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert task_result_0.clean_copy() is not None, "Cannot create object TaskResult"

test_case_0()
test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:33.274877
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:34.816801
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    assert True


# Generated at 2022-06-24 19:21:39.050155
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = TaskResult(None, None, None)
    var_0._result = { "failed": False, "invocation": { "module_name": "ping" } }
    var_0.is_failed()
    # assertEquals(var_0.is_failed(), False)


# Generated at 2022-06-24 19:21:39.896435
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

# Generated at 2022-06-24 19:21:43.268590
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)

    # Invoke method
    var_1 = task_result_0.is_failed()

    # Test for expected exception

    # Test for expected type
    assert isinstance(var_1, bool)


# Generated at 2022-06-24 19:21:48.120137
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)

    # Test if the call method needs_debugger(var_0) of class TaskResult raises a TypeError
    try:
        task_result_0.needs_debugger(var_0)
    except TypeError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-24 19:21:58.599982
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = 'skipped'
    task_result_1 = TaskResult(var_1, var_1, {'skipped': True, 'changed': False, 'failed': False, 'rc': 0})
    assert not task_result_1.is_failed()
    var_2 = 'skipped'
    task_result_2 = TaskResult(var_2, var_2, {'skipped': False, 'changed': False, 'failed': True, 'rc': 0})
    assert task_result_2.is_failed()
    var_3 = 'skipped'
    task_result_3 = TaskResult(var_3, var_3, {'skipped': False, 'changed': False, 'failed': False, 'rc': 0})
    assert not task_result_3.is_failed()


# Generated at 2022-06-24 19:22:02.272181
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # Check if the value of attribute failed is True
    assert False == task_result_0.is_failed()
    # Check if the value of attribute failed is False
    assert not(True == task_result_0.is_failed())


# Generated at 2022-06-24 19:22:04.908236
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    if not task_result_0.is_skipped():
        print("Test case 0 Failed")


# Generated at 2022-06-24 19:22:09.625336
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = None
    var_2 = None
    task_result_1 = TaskResult(var_1, var_2, var_2)
    if task_result_1.is_failed():
        print('Test PASSED')
    else:
        print('Test FAILED')


# Generated at 2022-06-24 19:22:17.783329
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert True


# Generated at 2022-06-24 19:22:20.221016
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    """test method TaskResult.needs_debugger"""
    task_result = TaskResult(None, None, None)
    assert task_result.needs_debugger()


# Generated at 2022-06-24 19:22:27.438525
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = None
    task_result_1 = TaskResult(var_0, var_0, var_0)
    var_2 = None
    task_result_2 = TaskResult(var_0, var_0, var_0)
    var_3 = None
    task_result_3 = TaskResult(var_0, var_0, var_0)
    var_4 = None
    task_result_4 = TaskResult(var_0, var_0, var_0)
    var_5 = None
    task_result_5 = TaskResult(var_0, var_0, var_0)
    var_6 = None

# Generated at 2022-06-24 19:22:28.747480
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert callable(TaskResult.clean_copy)


# Generated at 2022-06-24 19:22:34.953688
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
  var_1 = None
  var_2 = None
  var_3 = None
  var_4 = None
  var_5 = None

  task_result_1 = TaskResult(var_2, var_3, var_4)
  task_result_2 = task_result_1.clean_copy()
  if task_result_2 is None:
    assert True
  elif task_result_2 is False:
    assert True
  else:
    assert False


# Generated at 2022-06-24 19:22:37.436692
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = None
    task_result_1 = TaskResult(var_1, var_1, var_1)
    assert not task_result_1.is_failed()



# Generated at 2022-06-24 19:22:42.860607
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = TaskResult('host', 'task', 'return_data')

# Generated at 2022-06-24 19:22:54.023890
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = None
    var_1 = None
    task_result_0 = TaskResult(var_0, var_0, var_1)
    var_0 = False
    var_1 = None
    task_result_1 = TaskResult(var_0, var_0, var_1)
    var_0 = False
    var_1 = None
    task_result_2 = TaskResult(var_0, var_0, var_1)
    var_0 = False
    var_1 = None
    task_result_3 = TaskResult(var_0, var_0, var_1)
    var_0 = False
    var_1 = None
    task_result_4 = TaskResult(var_0, var_0, var_1)
    var_0 = False
    var_1 = []


# Generated at 2022-06-24 19:22:56.069594
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = True
    var_1 = False
    task_result_0 = TaskResult(var_1, var_1, var_1)
    result = task_result_0.needs_debugger(var_0)

# Generated at 2022-06-24 19:23:03.500834
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # In this test we call method needs_debugger of class TaskResult with
    # parameters 'globally_enabled' set to False, and check that result is
    # False
    var_1 = False
    var_2 = TaskResult(None, None, None)
    result = var_2.needs_debugger(var_1)
    assert(result == False)
    # Now we call method needs_debugger of class TaskResult with
    # parameters 'globally_enabled' set to True, and check that result is
    # False
    var_1 = True
    result = var_2.needs_debugger(var_1)
    assert(result == False)

# Generated at 2022-06-24 19:23:11.789871
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result = TaskResult(None, None, None)
    task_result.clean_copy()

# Generated at 2022-06-24 19:23:13.048459
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    result = test_case_0()
    assert result == None



# Generated at 2022-06-24 19:23:15.622098
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_0 = None

    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert "censored" in task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:20.445473
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_1 = TaskResult(var_0, var_0, var_0)
    task_result_2 = task_result_1.clean_copy()
    assert type(task_result_2) is TaskResult


# Generated at 2022-06-24 19:23:25.181411
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    global var_0
    global task_result_0
    global test_case_0
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert (task_result_0.needs_debugger(False) == False)
    assert (task_result_0.needs_debugger(True) == False)


# Generated at 2022-06-24 19:23:27.466166
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = task_result_0.is_failed()

# Generated at 2022-06-24 19:23:29.844240
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    ''' Unit test for method is_failed of class TaskResult '''
    # TODO: Implement a simple test function for method is_failed of class TaskResult
    assert False



# Generated at 2022-06-24 19:23:32.754816
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result_bool_0 = task_result_0.is_failed()



# Generated at 2022-06-24 19:23:33.627300
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    '''test for TaskResult.needs_debugger'''
    raise Exception("incomplete test")


# Generated at 2022-06-24 19:23:37.441283
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # Check the return class.
    assert TaskResult(var_0, var_0, var_0).__class__ == TaskResult


# Generated at 2022-06-24 19:23:49.630796
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    
    # Test with default parameters
    result_needs_debugger_0 = task_result_0.needs_debugger()
    print(result_needs_debugger_0)
    
    # Test with given parameter
    param_needs_debugger_0 = True
    result_needs_debugger_0 = task_result_0.needs_debugger(param_needs_debugger_0)
    print(result_needs_debugger_0)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 19:23:52.517707
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:23:58.368052
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()
    assert var_1 is not None


# Generated at 2022-06-24 19:24:07.586675
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_1 = None
    var_2 = None
    var_3 = None
    task_result_0 = TaskResult(var_1, var_2, {'_ansible_no_log': False, 'changed': True, 'invocation': {'module_args': {'type': 'chown'}, 'module_name': 'file'}, 'item': 'foo'})
    var_3 = task_result_0.clean_copy()
    assert var_3._result == {'item': 'foo', '_ansible_no_log': False, '_ansible_item_label': 'foo', 'changed': True}
    assert var_3._task == None
    assert var_3._task_fields == {}
    assert var_3._host == None
    assert var_3._ansible_no_log == False


# Generated at 2022-06-24 19:24:10.118205
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # Call method needs_debugger of class TaskResult using task_result_0 instance
    assert task_result_0.needs_debugger(False)
    # Must execute test method for class TaskResult that begins with 'test'


# Generated at 2022-06-24 19:24:14.118261
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    try:
        var_0 = None
        task_result_0 = TaskResult(var_0, var_0, var_0)
        var_1 = task_result_0.is_failed()
        assert False
    except KeyError as e:
        assert True
    except AssertionError as ae:
        assert False


# Generated at 2022-06-24 19:24:21.866317
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = None
    task_result_0.task_name = var_1
    var_2 = None
    task_result_0._result = var_2
    var_1 = None
    task_result_0.is_failed = var_1


# Generated at 2022-06-24 19:24:24.533693
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = None
    var_1 = TaskResult(var_1, var_1, var_1)
    var_1.needs_debugger()


# Generated at 2022-06-24 19:24:27.126715
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task, result = TestTaskResultClass.make_task_result(False)
    task_result_0 = TaskResult(None, task, result)
    var_0 = None
    var_0 = task_result_0.needs_debugger(var_0)


# Generated at 2022-06-24 19:24:30.205954
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_1 = TaskResult('arg_0', 'arg_1', 'arg_2')

    assert task_result_1.is_failed() == False


# Generated at 2022-06-24 19:24:40.258420
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    ret = task_result_0.needs_debugger()
    assert ret == False

# Generated at 2022-06-24 19:24:50.992542
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import os
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins import strategy_loader
    from ansible.errors import AnsibleUndefinedVariable

    display = Display()
    display.verbosity = 3

    # TODO: test_case_0 is commented as test fails for python 2.6.9
    # test_case_0()
    # test_case_1()
    # test_case_2()

    # TODO: test cases below are commented as they make the test case to fail with "ModuleNotFoundError: No module named 'ansible.parsing'"
    # test_case_3()
    # test_case_4()

    # TODO: test case

# Generated at 2022-06-24 19:24:56.413179
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    globally_enabled_0 = False
    try:
        task_result_0.needs_debugger(globally_enabled_0)
    except Exception as e:
        raise Exception(e)


if __name__ == '__main__':
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:24:59.169236
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0._check_key(var_0)

# Generated at 2022-06-24 19:25:00.301295
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_1 = None
    assert task_result_1.is_failed() == False


# Generated at 2022-06-24 19:25:01.799694
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = test_case_0()
    var_0 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:25:08.368635
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    debugger = 'on_unreachable'
    ignore_errors = False
    task_fields = {'debugger': debugger, 'ignore_errors': ignore_errors}
    task_result = TaskResult(None, None, {}, task_fields)
    globally_enabled = True
    result = task_result.needs_debugger(globally_enabled)
    assert result == True, "Failed to assert that test_TaskResult_needs_debugger() result is True"
    debugger = 'never'
    ignore_errors = True
    task_fields = {'debugger': debugger, 'ignore_errors': ignore_errors}
    task_result = TaskResult(None, None, {}, task_fields)
    globally_enabled = True
    result = task_result.needs_debugger(globally_enabled)

# Generated at 2022-06-24 19:25:10.854228
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
  var_0 = None
  var_1 = None
  var_2 = None
  var_3 = {'results': {}}
  task_result = TaskResult(var_0, var_1, var_2)
  clean_copy = task_result.clean_copy()



# Generated at 2022-06-24 19:25:14.398316
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # test with all var = None
    test_case_0()


# Generated at 2022-06-24 19:25:19.321513
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()
    var_2 = task_result_0.clean_copy()
    assert var_1.is_failed() == task_result_0.is_failed(), "'is_failed' return value mismatch"
    assert var_2.needs_debugger() == task_result_0.needs_debugger(), "'needs_debugger' return value mismatch"


# Generated at 2022-06-24 19:25:30.655532
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import ansible.playbook.task
    var_0 = ansible.playbook.task.Task()
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = None
    task_result_0.needs_debugger(var_1)


# Generated at 2022-06-24 19:25:36.909679
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    for var_0 in range(0, 100):
        for var_1 in range(0, 100):
            for var_2 in range(0, 100):
                task_result_0 = TaskResult(var_0, var_1, var_2)
                if (not (task_result_0.clean_copy())):
                    print("unexpected result for TaskResult.clean_copy()")
                    return 0
    return 1


# Generated at 2022-06-24 19:25:40.019349
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_1 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:25:43.453363
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    try:
        task_result_0.clean_copy()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 19:25:49.807691
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_3 = None
    var_4 = None
    var_5 = None
    task_result_0 = TaskResult(var_3, var_4, var_5)
    var_1 = "debugger"
    var_2 = "always"
    task_result_0._task_fields[var_1] = var_2
    var_6 = False
    var_7 = task_result_0.needs_debugger(var_6)
    print(str(var_7))

if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:25:54.575185
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    remote_port = True
    var_1 = True
    var_2 = True
    var_3 = True
    var_4 = True
    var_5 = True
    var_6 = True
    var_7 = True
    var_8 = True
    var_9 = True
    var_10 = True
    assert not(task_result_0.needs_debugger(remote_port))


# Generated at 2022-06-24 19:26:02.068613
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = 'failed_when_result'
    task_result_0._result = {'failed_when_result': var_1}
    var_2 = task_result_0._result
    var_3 = 'failed_when_result'
    var_1 = var_2.get(var_3, False)
    var_4 = 'results'
    var_5 = task_result_0._result
    var_4 = var_5.get(var_4, [])
    var_6 = True
    var_7 = []
    var_8 = {}
    var_8['failed_when_result'] = False
    var_7.append(var_8)
    var_

# Generated at 2022-06-24 19:26:06.022109
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print(colored("\n### TEST: test_TaskResult_clean_copy", "yellow"))
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    actual = task_result_0.clean_copy()
    expected = None
    #print(actual)
    assert actual == expected


# Generated at 2022-06-24 19:26:08.932512
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:17.743346
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import ansible
    # Setup data
    host_0 = ansible.inventory.host.Host('localhost')
    task_0 = ansible.playbook.task.Task()
    return_data_0 = None
    task_fields_0 = dict()
    # Setup task_result
    task_result_0 = TaskResult(host_0, task_0, return_data_0, task_fields_0)
    globally_enabled_0 = False
    # Invoke method
    ret_0 = task_result_0.needs_debugger(globally_enabled_0)
    # Check for expected results
    assert(ret_0 == False)

# Generated at 2022-06-24 19:26:52.751802
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert task_result_0.clean_copy() == {'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'}


# Generated at 2022-06-24 19:27:00.712108
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # just make sure it works when non-boolean is passed
    task_result_0 = TaskResult(None, None, None)
    assert task_result_0.needs_debugger(1) == False
    assert task_result_0.needs_debugger(0) == False

    # non-debug_enabled
    task_result_0 = TaskResult(None, None, None)
    assert task_result_0.needs_debugger(False) == False

    # with debugger: always
    task_result_1 = TaskResult(None, None, None, {'debugger': 'always'})
    assert task_result_1.needs_debugger(True) == True

    # with debugger: True
    task_result_2 = TaskResult(None, None, None, {'debugger': True})
    assert task_result_

# Generated at 2022-06-24 19:27:05.171520
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()
    assert var_1._task_fields is not None



# Generated at 2022-06-24 19:27:10.307467
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    data_0 = {'invocation': {'module_name': 'command', 'module_args': 'echo *************'}, '_ansible_verbose_always': False, '_ansible_no_log': False, 'changed': True, 'rc': 0, 'stderr': '', 'stdout': '*************\n', 'stdout_lines': ['*************'], '_ansible_item_result': True}
    task_result_0 = TaskResult(None, None, data_0)

    result = task_result_0.clean_copy()

    assert result is not None

# Generated at 2022-06-24 19:27:13.345986
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # is_failed() -> bool
    assert isinstance(task_result_0.is_failed(), bool)


# Generated at 2022-06-24 19:27:16.433520
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result_0 = task_result_0.clean_copy()
    assert result_0 is not None


# Generated at 2022-06-24 19:27:21.467019
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._task == var_0
    assert task_result_1._host == var_0
    assert task_result_1._task_fields == {}



# Generated at 2022-06-24 19:27:26.479499
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = None
    var_1 = 1
    task_result_0 = TaskResult(var_0, var_0, var_1)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:27:32.797635
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    var_1 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result_0 = task_result_0.needs_debugger(var_1)
    print(result_0)

# Generated at 2022-06-24 19:27:35.914084
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = None
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = False
    var_1 = True
    task_result_0.needs_debugger(var_1)
    task_result_0.needs_debugger(var_0)
