

# Generated at 2022-06-24 19:17:55.032749
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    class DummyClass:
        def __init__(self):
            self.func_attrib = DummyClass()
            self.bool_attrib = False

    dummy_instance = DummyClass()
    assert isinstance(dummy_instance, DummyClass)
    assert not dummy_instance.bool_attrib
    instance_0 = TaskResult(dummy_instance, dummy_instance, False)
    assert not instance_0.is_skipped()

# Generated at 2022-06-24 19:17:57.625794
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    set_0 = set()
    int_0 = 7927
    task_result_0 = TaskResult(set_0, int_0, set_0)
    var_0 = task_result_0.is_skipped()
    assert var_0 == False


# Generated at 2022-06-24 19:17:59.670300
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    dict_0 = dict()
    int_0 = 1370
    task_result_0 = TaskResult(dict_0, int_0, dict_0)
    var_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:18:03.259819
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    set_0 = set()
    int_0 = 2571
    task_result_0 = TaskResult(set_0, int_0, set_0)
    for i in range(10):
        task_result_0.clean_copy()
    var_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:18:06.774050
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    set_0 = set()
    int_0 = 2571
    task_result_0 = TaskResult(set_0, int_0, set_0)
    var_0 = task_result_0.is_skipped()
    assert (var_0 == False)


# Generated at 2022-06-24 19:18:10.582415
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    set_0 = set()
    int_0 = 2571
    task_result_0 = TaskResult(set_0, int_0, set_0)
    var_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:21.385308
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    set_0 = set()
    int_0 = 2989
    str_0 = '\x81\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac\x98\xac'
    task_result_0 = TaskResult(set_0, int_0, str_0)
    if (test_TaskResult_clean_copy.counter == 0):
        TaskResult_clean_copy(task_result_0)
        test_TaskResult_clean_copy.counter += 1

test_TaskResult_clean_copy.counter = 0


# Generated at 2022-06-24 19:18:26.462550
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    set_0 = set()
    int_0 = 10844
    task_result_0 = TaskResult(set_0, int_0, set_0)

    result = task_result_0.is_failed()
    assert result == False

# Generated at 2022-06-24 19:18:32.447198
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    set_0 = set()
    int_0 = 2143
    task_result_0 = TaskResult(set_0, int_0, set_0)
    var_0 = task_result_0.clean_copy()
    print(var_0)
    assert var_0.__class__.__name__ == 'TaskResult'
    assert var_0.is_skipped() == False
    assert var_0.is_failed() == False
    assert var_0.task_name == 'command'
    assert var_0.is_changed() == False
    assert var_0.is_unreachable() == False



# Generated at 2022-06-24 19:18:37.623171
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Create test variables
    task_result_0 = {}
    task_result_1 = {}
    # Create test case
    tr = TaskResult(task_result_0, task_result_0, task_result_1)
    # Run method
    test_result = tr.clean_copy()
    # Check result
    assert test_result == task_result_0


# Generated at 2022-06-24 19:18:55.781533
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Global variable 'data' is declared 'global' in function 'test_TaskResult_is_skipped' at line #15
    global result, data
    data = {'succeeded': False, 'changed': True, '_ansible_no_log': False, 'failed_when_result': False, 'skipped': True, '_ansible_item_result': True, '_ansible_ignore_errors': None, '_ansible_item_label': None, '_ansible_parsed': True, 'invocation': {'module_args': {'name': 'test'}}, '_ansible_parsed': True, '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_item_label': None}

# Generated at 2022-06-24 19:19:02.487406
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    this_task_result = TaskResult(None, None, None)
    this_task_result.is_failed = test_case_0
    this_task_result.is_unreachable = test_case_0
    this_task_result.is_skipped = test_case_0
    assert this_task_result.needs_debugger(True) == False



# Generated at 2022-06-24 19:19:05.180136
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = None
    task = None
    return_data = {"changed": True, "failed": True}
    task_fields = None
    tr = TaskResult(host, task, return_data, task_fields)
    local_bool = tr.is_failed()
    assert local_bool == True

# Generated at 2022-06-24 19:19:13.483928
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields = {'_ansible_no_log': True, 'debugger': 'always'}
    task_result = TaskResult('host', 'task', {'failed_when_result': True, '_ansible_no_log': True}, task_fields)
    result = True
    assert task_result.needs_debugger() == result

if __name__ == '__main__':
    import pytest
    # --durations=10  <- May be used to show potentially slow tests
    pytest.main(args=[__file__, "--durations=10"])

# Generated at 2022-06-24 19:19:18.285055
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_TaskResult = TaskResult('host', 'task', 'return_data', 'task_fields')
    assert test_TaskResult.is_failed() == False


# Generated at 2022-06-24 19:19:24.798983
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()
    # Initialize mock objects
    host = Mock(name='host')
    task = Mock(name='task')
    return_data = Mock(name='return_data')
    task_fields = Mock(name='task_fields')
    # Create a TaskResult object for test
    tr = TaskResult(host, task, return_data, task_fields)
    # Assert that needs_debugger returns False (default value)
    tr.needs_debugger() == False

if __name__ == '__main__':
    test_TaskResult_needs_debugger()
    print("All tests passed!")

# Generated at 2022-06-24 19:19:31.568707
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print('In test_TaskResult_clean_copy')
    loader = DataLoader()
    task = MagicMock()
    host = '172.17.0.2'
    task_fields = dict()
    return_data = dict()
    taskresult = TaskResult(host, task, return_data, task_fields)
    result = taskresult.clean_copy()
    assert result is not None
    assert result != taskresult
    print('passed test_TaskResult_clean_copy')



# Generated at 2022-06-24 19:19:37.702313
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:19:46.672257
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # no input from the user
    obj = TaskResult(host, task, return_data, task_fields)
    ret_val = obj.needs_debugger()

    if ret_val is True:
        # print("The function is True")
        # print("Test case 1,0 passed")
        bool_1 = True
    else:
        # print("The function is False")
        # print("Test case 1,0 failed")
        bool_1 = False
    # print("test_case_1_0 completed")

    # user inputs a value that already exists
    obj = TaskResult(host, task, return_data, task_fields)
    ret_val = obj.needs_debugger(globally_enabled)

# Generated at 2022-06-24 19:19:56.908434
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger(): 
    test_task = mock.MagicMock()
    test_loader = DataLoader()
    test_loader.load = mock.MagicMock(return_value = {})
    test_host = mock.MagicMock()
    test_fields = {}
    test_result = TaskResult(test_host, test_task, {}, test_fields)
    test_result.is_failed = mock.MagicMock()
    test_result.is_failed.return_value = False
    test_result.is_unreachable = mock.MagicMock(return_value = False)
    test_result.is_skipped = mock.MagicMock(return_value = False)
    test_result.is_changed = mock.MagicMock(return_value = False)
    assert test_result.needs_debugger() == bool_0

# Generated at 2022-06-24 19:20:07.973884
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
  # statment
  bool_0 = True
  task_0 = TaskResult(None, None, None, None)
  assert task_0.is_failed() == bool_0
  test_case_0()


# Generated at 2022-06-24 19:20:11.158872
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    taskresult = TaskResult()
    result = taskresult.is_failed()
    assert result != False


# Generated at 2022-06-24 19:20:17.915310
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = None
    task = None
    return_data = {
        'msg': 'changed',
        'changed': True,
        'rc': 0,
        'invocation': {
            'module_name': 'test',
        },
    }
    task_fields = {
        'name': 'test',
    }
    tr = TaskResult(host, task, return_data, task_fields)
    assert tr.is_failed() == False


# Generated at 2022-06-24 19:20:21.685390
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Create a clean_copy object with a host and a task
    taskresult = TaskResult

    result = taskresult.clean_copy()
    assert not result
    assert result is not None

if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:20:26.240472
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    obj = TaskResult(None, None, None)
    assert obj.is_failed()==bool_0


# Generated at 2022-06-24 19:20:30.735382
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Given the following setup
    task_result = TaskResult("", "", "")
    # And the following execution
    is_skipped = task_result.is_skipped()
    # Then the returned value should be
    assert bool_0 == is_skipped, "TaskResult.is_skipped does not work as expected"



# Generated at 2022-06-24 19:20:34.714859
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    t = TaskResult(None, None, {})
    r = t.is_failed()
    test_case_0()

    return r


# Generated at 2022-06-24 19:20:37.400137
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    obj = TaskResult(test_case_0,test_case_0)
    bool_1 = obj.is_skipped()
    assert bool_1 == True


# Generated at 2022-06-24 19:20:44.145967
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = {
        "results": [
            {
                "skipped": False
            },
            {
                "skipped": True
            }
        ]
    }
    host = ""
    task = ""
    task_fields = None
    task_result = TaskResult(host,task,result,task_fields)
    expected = False
    actual = task_result.is_skipped()
    print("expected: ", expected)
    print("actual: ", actual)
    assert (actual == expected)


# Generated at 2022-06-24 19:20:48.046451
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Initiate the class
    test_object = TaskResult(None, None, None, {})
    try:
        test_method = test_object.clean_copy
        assert test_case_0() == None
    except Exception as e: # catch *all* exceptions
        print("EXCEPTION", e)
        assert False

# Generated at 2022-06-24 19:20:59.789867
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    result_0 = TaskResult(None, None, {})
    test_case_0()
    #TODO add testcase here


if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.abspath('..'))
    import ansible
    sys.modules['ansible'] = ansible
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:21:01.081761
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("test_TaskResult_clean_copy")
    assert False

# Generated at 2022-06-24 19:21:03.914635
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    a= TaskResult(0,0,0)
    res = a.is_skipped()
    if res:
        test_case_0()
    else:
        print('test_TaskResult_is_skipped passed')


# Generated at 2022-06-24 19:21:07.603160
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test = TaskResult("host", "task", {"failed":False, "msg":"failed"}, {"name":"task1"})
    assert test.clean_copy() == {'msg': 'failed'}


# Generated at 2022-06-24 19:21:12.992238
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tsk_res = TaskResult(host, task, return_data, task_fields)
    tsk_res_clean_copy = tsk_res.clean_copy()
    if tsk_res_clean_copy is None:
        bool_0 = True
        assert bool_0
# Test method clean_copy of class TaskResult
test_TaskResult_clean_copy()


# Generated at 2022-06-24 19:21:18.188755
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # pass a bool value as parameter
    taskresult = TaskResult(None, None, None)
    result = taskresult.needs_debugger(test_case_0())
    assert isinstance(result, bool), 'Return type of needs_debugger must be <type \'bool\'>, not ' + str(type(result))
    assert result == False, 'Result of needs_debugger must be False, not '+str(result)


# Generated at 2022-06-24 19:21:22.249814
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Arrange
    fi = mock.MagicMock()
    fi.return_value = True

    # Act
    try:
        test_case_0()
    except Exception:
        bool_1 = False
    else:
        bool_1 = True

    # Assert
    assert bool_1 == bool_0, 'test_TaskResult_clean_copy failed!'

test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:31.304337
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Initializing argument variables

    host = ''
    task = 'task'
    return_data = dict()
    task_fields = dict()

    tr = TaskResult(host,task,return_data,task_fields)
    tr._task_fields['debugger'] = 'never'
    tr._task_fields['ignore_errors'] = 'no'
    globally_enabled = False

    tr._result['failed_when_result'] = 'failed'

    # Execute needs_debugger of class TaskResult
    result = tr.needs_debugger(globally_enabled)

    assert result == bool_0


# Generated at 2022-06-24 19:21:40.085118
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    # Initialize variable with default value
    bool_0 = False

    # Try to get an exception by calling
    # method on object that has not been initialized
    try:
        bool_0 = test_TaskResult_is_skipped()
    except (UnboundLocalError, NameError) as exception:
        print("UnboundLocalError or NameError")
        test_case_0()

    # Try to get an exception by calling
    # method on object that has not been initialized
    try:
        bool_0 = test_TaskResult_is_skipped()
    except (UnboundLocalError, NameError) as exception:
        print("UnboundLocalError or NameError")
        test_case_0()


# Generated at 2022-06-24 19:21:46.440077
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_name = 'some_task'
    task_action = 'ping'
    task_args = 'args'
    task_tags = 'ansible_tasks_test'
    task_when = False
    task_register = 'content'

    task_hosts = ['host1', 'host2']
    task_result = TaskResult(task_hosts, task_name, task_action, task_args, task_tags, task_when, task_register)
    clean_result = task_result.clean_copy()
    assert_result = True
    if not clean_result:
        assert_result = False
        print(clean_result)

    # Return value of call to clean_copy of TaskResult is True.
    assert assert_result == True


# Generated at 2022-06-24 19:22:02.120156
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    t = TaskResult({}, {}, {})
    t.is_failed()
    t.is_changed()
    t.is_skipped()
    t.is_unreachable()


# Generated at 2022-06-24 19:22:07.627092
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Create an instance of TaskResult
    # Test the default values of instance attributes
    t1 = TaskResult(None, None, None, None)
    t1._result = dict()

    # Test the return value of method is_failed, which return false
    if not t1.is_failed():
        test_case_0()

    # Test the return value of method is_failed, which return true
    t1._result = dict(failed = True)
    if t1.is_failed():
        test_case_0()


# Generated at 2022-06-24 19:22:11.019851
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()


# Generated at 2022-06-24 19:22:20.229281
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
        task_fields = []

        task_fields.append(TaskResult(None, None, {"failed_when_result": False}, {"debugger": "on_failed", "ignore_errors": True}))
        task_fields.append(TaskResult(None, None, {"failed_when_result": True}, {"debugger": "on_failed", "ignore_errors": False}))
        task_fields.append(TaskResult(None, None, {"failed_when_result": False}, {"debugger": "on_failed", "ignore_errors": False}))
        task_fields.append(TaskResult(None, None, {"failed_when_result": True}, {"debugger": "on_failed", "ignore_errors": True}))

# Generated at 2022-06-24 19:22:22.241341
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.play_context import PlayContext

    t = TaskResult('host', 'task', 'return_data')
    assert t


# Generated at 2022-06-24 19:22:26.156752
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    h_0 = None
    task_0 = None
    return_data_0 = None
    task_fields_0 = None
    obj_0 = TaskResult(h_0, task_0, return_data_0, task_fields_0)
    try:
        obj_0.needs_debugger(bool_0)
    except NameError as e_0:
        print(e_0)


# Generated at 2022-06-24 19:22:28.008323
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    case_0 = TaskResult(None, None, None)
    assert case_0.needs_debugger() == False

# Generated at 2022-06-24 19:22:30.340651
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    for i in range(1000000):
        taskresult = TaskResult('localhost', 'setup', '{"failed":false}')
        test_case_0()
        taskresult.needs_debugger()

# Generated at 2022-06-24 19:22:38.777012
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Check that expected path is taken when debugger is specified and
    # ignore errors is not specified
    task_fields = {
        'name': 'test_name',
        'debugger': 'on_failed'
    }
    task_result = TaskResult('test_host', 'test_task', 'test_result', task_fields)
    assert task_result.needs_debugger(True) == True

    # Check that expected value is returned when debugger is specified and
    # ignore errors is specified
    task_fields['ignore_errors'] = True
    assert task_result.needs_debugger(True) == False

    # Check that expected value is returned when debugger is specified and
    # ignore errors and globally enabled is specified
    assert task_result.needs_debugger(True) == True

# Generated at 2022-06-24 19:22:40.138415
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    taskresult = TaskResult(object(), object(), dict())
    taskresult.clean_copy()

# Generated at 2022-06-24 19:22:52.733771
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # run function
    needs_debugger = test_case_0()
    assert needs_debugger == False

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:22:57.988082
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = False
    bool_1 = False
    str_0 = 'on_failed'
    task_0 = TaskResult(bool_0, bool_1, bool_1)
    task_0._task_fields['debugger'] = str_0
    bool_0 = task_0.needs_debugger(bool_0)
    print("Value returned: ", bool_0)


# Generated at 2022-06-24 19:23:01.026320
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = False
    try:
        obj = TaskResult(None, None, None)
        bool_0 = obj.is_skipped()
        bool_0 = True
    except:
        bool_0 = True
    assert bool_0

# Generated at 2022-06-24 19:23:03.986530
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    try:
        # Test cases
        t = TaskResult(None, None, {})
        t.clean_copy()
    except Exception as err:
        print("Error: {0}".format(err))
        test_case_0()


# Generated at 2022-06-24 19:23:05.337723
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print('Method test_TaskResult_clean_copy not implemented')
    test_case_0()


# Generated at 2022-06-24 19:23:06.271889
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Just to know there is a test for this method
    assert True


# Generated at 2022-06-24 19:23:15.757096
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:23:21.629189
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Initialize an instance of class TaskResult
    TaskResult_instance = TaskResult('foo', 'foo', 'foo', 'foo')
    # Get method clean_copy of TaskResult
    TaskResult_clean_copy_method = getattr(TaskResult_instance, "clean_copy")
    # Call clean_copy method
    TaskResult_clean_copy_method()
    test_case_0()

# Generated at 2022-06-24 19:23:26.841191
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task

    host = None
    task = Task()
    return_data = {}
    task_fields = {}
    task_result = TaskResult(host, task, return_data, task_fields)

    bool_0 = task_result.needs_debugger()

    if bool_0:
        test_case_0()

if __name__ == "__main__":
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:23:30.128325
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TODO: add unit tests for TaskResult class - method clean_copy
    task_result_0 = TaskResult()

if __name__ == "__main__":
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:23:41.367284
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # FIXME: needs mock
    pass


# Generated at 2022-06-24 19:23:47.462336
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":true,"skipped":false,"changed":false,"invocation":{"module_name":"system","module_args":"{\"free_form\":[\"date\"]}","module_complex_args":{},"module_complex_args_names":{}},"result":{"_ansible_parsed":true,"stdout":"Tue Sep  3 17:43:41 EEST 2019\n","stdout_lines":["Tue Sep  3 17:43:41 EEST 2019"],"stderr":"","cmd":["date"],"rc":0,"start":"2019-09-03 17:43:41.913072","delta":"0:00:00.059051","end":"2019-09-03 17:43:41.972123","msg":"","_ansible_no_log":false}}'

# Generated at 2022-06-24 19:23:52.160334
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:03.862974
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '{"failed":false}'
    str_1 = '{"failed":false,"msg":"The module failed to execute correctly, you will find more details in the module output below:\\n\\nstdout:\\nmsg:\\n\\nstderr:\\nmsg:\\n","rc":1}'
    str_2 = '{"failed":false,"rc":1,"stdout_lines":["msg:"]}'
    test_data = [
        (str_0, False),
        (str_1, False),
        (str_2, False),
        (None, False),
        ('hey', False),
        ('', False),
    ]
    for data in test_data:
        task_result_0 = TaskResult(data[0], data[0], data[0])

# Generated at 2022-06-24 19:24:10.087970
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    host = 'localhost'
    task = 'vim'
    return_data = {"failed": True}
    task_fields = {}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert task_result.is_failed() == True

    return_data = {"failed": False}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert task_result.is_failed() == False

# Generated at 2022-06-24 19:24:13.237320
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()

test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:24:18.582551
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert TaskResult('result_copy_copy', 'result_copy_copy', '{"failed":true}').clean_copy()._result == {'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'}
    assert TaskResult('result_copy_result', 'result_copy_result', '{"failed":false, "failed_when_result":false}').clean_copy()._result == {'failed_when_result': False}
    assert TaskResult('result_copy_result', 'result_copy_result', '{"failed":false, "failed_when_result":true}').clean_copy()._result == {'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'}

# Generated at 2022-06-24 19:24:25.584766
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    data = {
      "msg": "All items completed",
      "results": [
            {"item": "first", "changed": True},
            {"item": "second", "changed": False},
            {"item": "third", "changed": False}
        ]
    }
    data_loader = DataLoader()
    res = TaskResult('localhost', 'test task', data_loader.load(data))
    is_skipped = res.is_skipped()
    assert not is_skipped



# Generated at 2022-06-24 19:24:33.953767
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_1 = '{"msg":"the output has been hidden due to the fact that \'no_log: true\' was specified for this result","censored":"the output has been hidden due to the fact that \'no_log: true\' was specified for this result"}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    var_1 = task_result_1.is_failed()


if __name__ == '__main__':
    test_TaskResult_is_failed()
    test_case_0()

# Generated at 2022-06-24 19:24:36.379963
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_1 = '{"skipped":false}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    var_1 = task_result_1.is_skipped()


# Generated at 2022-06-24 19:24:48.320264
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.is_failed()



# Generated at 2022-06-24 19:24:57.736239
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.v2.playbook.play_context import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.v2.playbook.task import Task
    from ansible.v2.playbook.block import Block
    from ansible.v2.playbook.role_include import IncludeRole
    from ansible.v2.playbook.role import Role
    from ansible.v2.playbook.handler_task_include import HandlerTaskInclude
    from ansible.v2.playbook.task_include import TaskInclude
    from ansible.v2.playbook.handler_task import HandlerTask
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result

# Generated at 2022-06-24 19:25:05.952784
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.clean_copy()

    str_1 = '{"failed":false}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    var_1 = task_result_1.needs_debugger()

    str_2 = '{"failed":false}'
    task_result_2 = TaskResult(str_2, str_2, str_2)
    var_2 = task_result_2.needs_debugger()

    str_3 = '{"failed":false}'
    task_result_3 = TaskResult(str_3, str_3, str_3)

# Generated at 2022-06-24 19:25:11.659074
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Input parameters
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert str(task_result_1) == "TaskResult(hlq.hlq.blq)"



# Generated at 2022-06-24 19:25:16.516737
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:24.089647
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.needs_debugger()
    assert var_0 == False

if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:25:26.274795
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert isinstance(task_result_1, TaskResult)


# Generated at 2022-06-24 19:25:29.919037
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger()
    assert (bool_0 == False)


# Generated at 2022-06-24 19:25:34.269816
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TaskResult is a TaskResult object
    str_1 = '{"failed":false}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    clean_copy_of_taskresult = task_result_1.clean_copy()
    #assert_equal(clean_copy_of_taskresult, "censored")
    #assert_equal(clean_copy_of_taskresult, )
    assert(clean_copy_of_taskresult == "censored")

# Generated at 2022-06-24 19:25:40.632946
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result_0 = task_result_0.clean_copy()
    assert isinstance(result_0, TaskResult)
    # AssertionError: False != True
    var_0 = result_0.needs_debugger()


# Generated at 2022-06-24 19:25:52.747531
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    TaskResult.clean_copy(task_result_0)


# Generated at 2022-06-24 19:25:57.945601
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = 'bogus'
    task = 'bogus'
    return_data = '{"failed":false}'
    task_fields = dict()
    task_result_0 = TaskResult(host, task, return_data, task_fields)
    var_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:26:00.637978
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:02.248475
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:26:05.326536
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    var_0 = task_result_0.is_skipped()

    assert var_0 is False


# Generated at 2022-06-24 19:26:07.209245
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:10.660083
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:13.994034
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:15.317079
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()

# Generated at 2022-06-24 19:26:18.697953
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:26:31.112487
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_1 = '{"failed":false}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    var_1 = task_result_1.is_skipped()


# Generated at 2022-06-24 19:26:37.281158
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    _task = TaskResult('host', 'task', 'return_data')
    _clean_copy = _task.clean_copy()
    _copy_result = _clean_copy._result
    assert 'failed' not in _copy_result
    assert 'changed' in _copy_result
    assert 'attempts' in _copy_result


# Generated at 2022-06-24 19:26:39.063165
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:26:46.314858
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '{"failed":false}'
    str_1 = '{"failed":true}'
    str_2 = '{"failed":false,"results":[{"failed":true}]}'

    task_result = TaskResult(str_0, str_0, str_0)
    assert task_result.is_failed() == False

    task_result = TaskResult(str_0, str_0, str_1)
    assert task_result.is_failed() == True

    task_result = TaskResult(str_0, str_0, str_2)
    assert task_result.is_failed() == True


# Generated at 2022-06-24 19:26:55.390303
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert False == TaskResult('host_0', 'task_0', 'result_0').is_failed()
    assert True == TaskResult('host_1', 'task_1', 'result_1').is_failed()
    assert False == TaskResult('host_2', 'task_2', 'result_2').is_failed()
    assert False == TaskResult('host_3', 'task_3', 'result_3').is_failed()
    assert False == TaskResult('host_4', 'task_4', 'result_4').is_failed()
    assert False == TaskResult('host_5', 'task_5', 'result_5').is_failed()
    assert False == TaskResult('host_6', 'task_6', 'result_6').is_failed()

# Generated at 2022-06-24 19:26:57.567288
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_1 = '{"_ansible_verbose_always":false}'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    assert isinstance(task_result_1.clean_copy(), TaskResult) == True


# Generated at 2022-06-24 19:26:58.453701
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    assert TaskResult.needs_debugger(args=['', '']) == None


# Generated at 2022-06-24 19:27:06.839150
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    str_1 = '{"failed":false,"item":""}'
    task_result_0 = TaskResult(str_1, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._result.get('item') == ''
    assert task_result_1._task_fields.get('name') == None
    assert task_result_1._task.get_action() == None


# Generated at 2022-06-24 19:27:08.937483
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:11.217448
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = ''
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()

# Generated at 2022-06-24 19:27:24.571720
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:27:27.565141
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = ""
    return_data = {"results": [{"skipped": True}, {"skipped": True}, {}]}
    task_result = TaskResult(
        host,
        None,
        return_data,
        {"debugger": "on_skipped"}
    )


# Generated at 2022-06-24 19:27:30.119083
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '{"failed":false}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    var_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:27:33.797822
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '{"failed":true}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_failed(), task_result_0

if __name__ == "__main__":
    test_TaskResult_is_failed()