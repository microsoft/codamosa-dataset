

# Generated at 2022-06-24 19:17:57.051955
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger()
    assert(not bool_0)


# Generated at 2022-06-24 19:18:00.748324
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'5z@'
    str_0 = 'h_Xe?QC:VD'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    bool_0 = task_result_0.is_failed()
    assert bool_0 == False


# Generated at 2022-06-24 19:18:05.061820
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'O\x0f\'\xe5b\x9eNO'
    str_0 = 'C5:5d5Z.8[Df?_'
    task_result_0 = TaskResult(str_0, bytes_0, str_0)
    assert (task_result_0.is_failed() == False)
    assert (task_result_0.is_failed() == False)


# Generated at 2022-06-24 19:18:10.581973
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # test case 0
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()



# Generated at 2022-06-24 19:18:17.997561
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'`1'
    str_0 = 'h*'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert not task_result_0.is_skipped()

    bytes_1 = b'jdul'
    str_1 = '^e&'
    task_result_1 = TaskResult(bytes_1, str_1, str_1)
    assert not task_result_1.is_skipped()

    bytes_2 = b'DwM'
    str_2 = 'm'
    task_result_2 = TaskResult(bytes_2, str_2, str_2)
    assert not task_result_2.is_skipped()


# Generated at 2022-06-24 19:18:21.790274
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:18:30.840211
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    bytes_1 = b'9sc'
    bytes_2 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    str_1 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_1, str_0, str_0)
    task_result_1 = TaskResult(bytes_2, str_1, str_1)
    task_result_2 = TaskResult(bytes_0, str_1, str_1)
    task_result_3 = TaskResult(bytes_0, str_0, str_0)
    task_result_4 = TaskResult(bytes_1, str_1, str_1)
   

# Generated at 2022-06-24 19:18:39.850893
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'1\x0f\xd9\xe7\x91\x1e\xc2\xfa8W\xf5\x06\xfbk\x00\x00\x00\x00\xdd\x07\xd8M\x17\x18\x13\xa3\x92\x9c\x87\xec\x99\t\x18\x13\xa3'
    str_0 = '\x9d\x87\xec\x99\t\x18\x13\xa3'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert not task_result_0.is_failed()

# Generated at 2022-06-24 19:18:43.487462
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Setup Test
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    # Assertion
    assert(False == task_result_0.is_skipped())


# Generated at 2022-06-24 19:18:49.140390
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    bytes_1 = b'Lc7l'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    str_1 = 'o8E/0'
    str_2 = 'a'
    str_3 = '61'
    task_result_0 = TaskResult(bytes_0, str_0, str_1)
    bool_0 = task_result_0.needs_debugger(str_2)
    bool_1 = task_result_0.needs_debugger(str_3)


# Generated at 2022-06-24 19:19:00.070540
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'f<'
    str_0 = 'y'
    str_1 = ')B'
    str_2 = 'I\\='
    str_3 = '+'
    float_0 = -1.41432
    task_result_0 = TaskResult(bytes_0, str_0, float_0, str_1)


# Generated at 2022-06-24 19:19:04.284240
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert task_result_0.needs_debugger(False) == False


test_case_0()
test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:19:07.330138
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'O;l'
    str_0 = '9sc'
    str_1 = 'I8)p'
    task_result_0 = TaskResult(bytes_0, str_0, str_1)
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:19:12.818736
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:19.667982
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_1 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_1, str_0, str_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:22.952803
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Case 1

    # Case 2

    # Case 3
    assert TaskResult.is_failed() == False


# Generated at 2022-06-24 19:19:29.348993
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'q'
    str_0 = '_'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:38.490869
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\xed\xab\x93\x84\xf7\xb2\xbf\xf7^\x04\x9c\xaa\xec\xef\xa8\x0b\xda\x0c\x8a\x9c\xaf\xb1'
    str_0 = 'H\x17\x04'
    bytes_1 = b'\x1f\x1a\xde\xf8\x83\x94\x96\xb0\xa5\xb7,b\xcc\x0c\x91\x8a'
    dict_0 = dict()

# Generated at 2022-06-24 19:19:42.520587
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'5@-w'
    str_0 = 'xB'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    int_0 = task_result_0.is_failed()



# Generated at 2022-06-24 19:19:46.880073
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\xc5\xd7,\x91'
    str_0 = '~Ai,5|t_dY[\xc2\x87Es\x99\x80\x0c\x9c\xaa'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_copy_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:57.018762
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '5 O"u.Z"-`9%cQf3qH'
    str_1 = 'Yw[8'
    task_result_0 = TaskResult(str_0, str_1, str_1)
    task_result_0.needs_debugger()


test_case_0()

# Generated at 2022-06-24 19:20:02.798147
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert not task_result_0.is_skipped()
    task_result_0._result = {'skipped': True}
    assert task_result_0.is_skipped()
    task_result_0._result = {'results': [{'skipped': True}]}
    assert task_result_0.is_skipped()
    task_result_0._result = {'results': [{'skipped': False}]}
    assert not task_result_0.is_skipped()
    task_result_0._result = {'results': ['skipped']}


# Generated at 2022-06-24 19:20:05.023274
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    boolean_0 = task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:20:11.759124
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host_0 = TaskResult.__new__(TaskResult)
    str_0 = TaskResult.__new__(TaskResult)
    str_1 = TaskResult.__new__(TaskResult)
    task_result_0 = TaskResult(host_0, str_0, str_1)
    try:
        task_result_0.is_failed()
    except Exception:
        print('exception raised')

# Generated at 2022-06-24 19:20:18.069972
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
  bytes_0 = b'9sc'
  str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
  task_result_0 = TaskResult(bytes_0, str_0, str_0)
  # test if task_result_0.clean_copy() equal to self._result
  assert task_result_0.clean_copy() == task_result_0._result


# Generated at 2022-06-24 19:20:26.327091
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x86\xbe\x18\xf9\x01\r\xe1J\xd8e\x0f\x7f(d\x80\xc0\x01\xe8Vv\x9e\xbcb\xbb!\x8e\xbc\x1d\xd6\xa8\x00\xe6\x0f\x13\x07\x99\xcf\xc48\xce\xe8\x8a\x9c'

# Generated at 2022-06-24 19:20:34.772159
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_action = 'ping'
    task_args = 'pong'
    task_delegated_vars = 'pung'
    task_loop = 'pang'
    task_name = 'pung'
    task_register = 'pang'
    task_run_once = 'pang'
    task_tags = 'pang'
    task_when = 'pang'
    task_with_items = 'pang'

# Generated at 2022-06-24 19:20:39.773704
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert isinstance(task_result_1, TaskResult)



# Generated at 2022-06-24 19:20:47.555874
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Create mock objects
    bytes_0 = b'H\x8as\x90a/\x15\x9a\x8aN\x9f\x91\xce'
    str_0 = 'x\x1c\x0e\x8b\x7f\x16\x99\xec\xba(\x0b\xed\x9d\xe8\xefX\x0b\x82'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    # Call method to test
    result = task_result_0.is_failed()

    # Check for expected result
    assert result is not False, "Unexpected result returned"



# Generated at 2022-06-24 19:20:58.009227
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:21:08.096529
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task = Task('task_1')
    host = Host('host_1')
    tr = TaskResult(host, task, bytes_0)
    assert tr.is_failed() == True


# Generated at 2022-06-24 19:21:14.637992
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = TaskResult(host=bytes_0,task=bytes_0,return_data=bytes_0)
    expect = True
    actual = result.is_skipped()
    assert expect == actual, 'Expected different value'

    result = TaskResult(host=bytes_0,task=bytes_0,return_data=bytes_0)
    expect = False
    actual = result.is_skipped()
    assert expect == actual, 'Expected different value'


# Generated at 2022-06-24 19:21:22.512834
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:21:24.028757
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult(0, 0, 0, 0)
    assert task_result.needs_debugger(0) == 0

# Generated at 2022-06-24 19:21:32.199729
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields = {
        'name': 'ping',
        'debugger': 'on_skipped',
        'ignore_errors': True,
    }
    host = 'testing_host'
    task = 'test_task'
    return_data = {
        'skipped': True,
        '_ansible_no_log': False,
    }
    obj_2 = TaskResult(host, task, return_data, task_fields)
    result_3 = obj_2.needs_debugger(True)

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:21:35.931799
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    parameters_0 = TaskResult(None, None, None)
    assert parameters_0.needs_debugger(False) == False

if __name__=='__main__':
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:21:42.349683
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_fields = {'name' : 'test'}
    task = 'test ansible module TaskResult'
    host = 'test host'
    return_data = {'skipped' : False}
    obj = TaskResult(host, task, return_data, task_fields)
    result = obj.is_skipped()
    assert result

    return_data = {'skipped' : True}
    obj = TaskResult(host, task, return_data, task_fields)
    result = obj.is_skipped()
    assert result


# Generated at 2022-06-24 19:21:52.975561
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    '''
    unit test for TaskResult::clean_copy
    '''
    import unittest

    result = TaskResult(bytes_0, bytes_0, bytes_0, bytes_0)

# Generated at 2022-06-24 19:21:59.023526
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\x86\xbe\x18\xf9\x01\r\xe1J\xd8e\x0f\x7f(d\x80\xc0\x01\xe8Vv\x9e\xbcb\xbb!\x8e\xbc\x1d\xd6\xa8\x00\xe6\x0f\x13\x07\x99\xcf\xc48\xce\xe8\x8a\x9c'
    bytes_1 = b"\x02"

# Generated at 2022-06-24 19:22:06.806110
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    data = {'failed_when_result': False}
    task = {'action': 'debug'}

    result = TaskResult(1, task, data)

    result.clean_copy()
    assert result._task_fields.get('name', None) is None

    data = {'failed_when_result': False}
    task = {'action': 'debug'}

    result = TaskResult(1, task, data)

    result.clean_copy()
    assert result._task_fields.get('name', None) is None


# Generated at 2022-06-24 19:22:18.520272
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print("Testing is_skipped")
    # Put your code that tests TaskResult.is_skipped here.
    # Make sure to include a test for every possible branch/path through your code
    # This includes errors and exceptions that may be thrown.


# Generated at 2022-06-24 19:22:20.228996
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult(None, None, None)
    task_result.needs_debugger(True)

test_case_0()
test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:22:22.894426
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert(False)


# Generated at 2022-06-24 19:22:25.727443
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    '''
    Unit test for method is_skipped of class TaskResult
    '''

    # Testing for a true case
    assert True

    # Testing for a false case
    assert True

    # Testing for a one of many true case
    assert True


# Generated at 2022-06-24 19:22:31.085931
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:22:39.917667
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_fields = dict()
    task_fields["_ansible_parsed"] = True
    task_fields["loop_control"] = dict()
    task_fields["always_run"] = False
    task_fields["name"] = "Add the public key to authorized_keys"
    task_fields["delegate_to"] = None
    task_fields["register"] = "rm_tmp_key"
    task_fields["async"] = 0
    task_fields["retries"] = 3
    task_fields["vars"] = dict()
    task_fields["delegate_facts"] = None
    task_fields["tags"] = ["always"]
    task_fields["until"] = None
    task_fields["ignore_errors"] = False
    task_fields["with_items"] = None
    task_fields["when"] = None

# Generated at 2022-06-24 19:22:48.896368
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("Testing: clean_copy")
    task_fields = dict()
    task_fields['name'] = 'this is a task name'
    host = 'this is a host'
    task = 'this is a task'
    return_data = dict()
    return_data['changed'] = True
    return_data['failed'] = 'this is a failure'
    return_data['skipped'] = 'this is a skipped result'
    return_data['unreachable'] = True
    return_data['ansible_facts'] = {'a': bytes_0}
    obj = TaskResult(host, task, return_data, task_fields)
    r = obj.clean_copy()


# Generated at 2022-06-24 19:22:55.952175
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task = {u'action': u'ping'}
    host = u'127.0.0.1'
    task_result = TaskResult(host, task, bytes_0)
    try:
        assert task_result.is_skipped() == False
    except AssertionError:
        raise AssertionError('Expected False, got %s' % task_result.is_skipped())


# Generated at 2022-06-24 19:22:58.145695
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult()
    globally_enabled = False
    assert task_result.needs_debugger(globally_enabled) == False


# Generated at 2022-06-24 19:23:06.045623
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    loader = DataLoader()
    yaml_data = "---\nfailed: True\n_ansible_verbose_always: True\n_ansible_no_log: True\n_ansible_item_label: \"{{'some'}}\"\nchanged: False\n_ansible_verbose_override: True"
    processed_data = loader.load(yaml_data)
    # Create action plugin instance
    task = ShellModule(task=dict(action=dict()), connection=dict(), play_context=dict(become=False), loader=loader, templar=None, shared_loader_obj=None)
    task._low_level_execute_command(b"id -a", b"id -a\n", b"")
    result = task.result
    result.clean_copy()

# Unit test

# Generated at 2022-06-24 19:23:15.704004
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:23:20.855726
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b']e'
    str_0 = '1'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger(True)
    assert bool_0


# Generated at 2022-06-24 19:23:27.583343
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    """Test for TaskResult.clean_copy"""

    # Test for presence of function test_TaskResult_clean_copy
    assert hasattr(TaskResult, 'clean_copy')
    bytes_0 = b'*!Q'
    str_0 = 'dtH[#'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    expected_0 = TaskResult
    # Call task_result_0.clean_copy()
    actual_0 = task_result_0.clean_copy()
    assert isinstance(actual_0, expected_0)

# Test for method __init__ of class TaskResult

# Generated at 2022-06-24 19:23:37.754515
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    # test case: clean_copy
    
    # Calling clean_copy method of TaskResult class
    task_result_0_clean_copy = task_result_0.clean_copy()
    # Calling is_failed method of TaskResult class
    task_result_0_clean_copy_is_failed_value = task_result_0_clean_copy.is_failed()
    # Calling is_changed method of TaskResult class
    task_result_0_clean_copy_is_changed_value = task_result_0_clean_copy.is_changed()
    # Calling task_name method

# Generated at 2022-06-24 19:23:46.257892
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    bool_0 = task_result_0.is_failed()
    assert not bool_0
    bool_1 = task_result_0.is_skipped()
    assert not bool_1
    bool_2 = task_result_0.is_unreachable()
    assert not bool_2
    task_result_0.needs_debugger(globally_enabled = True)
    task_result_0.needs_debugger(globally_enabled = False)


# Generated at 2022-06-24 19:23:52.965081
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    # TODO: add some assertions



# Generated at 2022-06-24 19:23:59.092859
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    localhost = 'localhost'
    task_result_0 = TaskResult(localhost, str_0, str_0)
    task_result_0.needs_debugger()

# Generated at 2022-06-24 19:24:04.300308
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:04.709915
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
	pass

# Generated at 2022-06-24 19:24:09.899601
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    # Inconsistency == Failure
    assert task_result_0.is_skipped() == False



# Generated at 2022-06-24 19:24:23.082269
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.clean_copy() # Expecting no exception to be raised


# Generated at 2022-06-24 19:24:29.001159
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    globally_enabled = False
    ret_0 = task_result_0.needs_debugger(globally_enabled)
    assert ret_0, "TypeError - Function 'needs_debugger' of class TaskResult returns type <class 'bool'>, but should return type <class 'bool'>\n"


# Generated at 2022-06-24 19:24:33.230366
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    assert task_result_0.is_failed() is False


# Generated at 2022-06-24 19:24:40.653448
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    some_host = 'vm1'

    some_task = 'task_data'

    some_return_data = dict()
    some_return_data['failed'] = "some text"

    some_task_fields = dict()
    some_debug_level = 'on_skipped'
    some_task_fields['debugger'] = some_debug_level

    test_result = TaskResult(some_host, some_task, some_return_data, some_task_fields)
    test_result.needs_debugger()

# Generated at 2022-06-24 19:24:50.435835
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Test the case where 'failed' is False
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    result = task_result_0.is_failed()
    assert result == False
    # Test the case where 'failed' is True
    bytes_1 = b'9sc'
    str_1 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_1 = TaskResult(bytes_1, str_1, str_1)
    result = task_result_1.is_failed()
    assert result == True

# Generated at 2022-06-24 19:24:59.803827
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(b't', [b'W*tZ,G|H=ro', b'_'], [b'y*OtL~', b'+W'])
    globally_enabled_0 = True
    needs_debugger_0 = task_result_0.needs_debugger(globally_enabled_0)
    assert needs_debugger_0 == False

    globally_enabled_1 = TaskResult(b'!', [b'D~OW<l!1x', b'b'], [b'=T+p%&', b'P/'])
    needs_debugger_1 = task_result_0.needs_debugger(globally_enabled_1)
    assert needs_debugger_1 == False


# Generated at 2022-06-24 19:25:03.956200
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    str_1 = '#\tL#)t'
    task_result_0 = TaskResult(bytes_0, str_0, str_1)

    # call function
    ret = task_result_0.is_skipped()



# Generated at 2022-06-24 19:25:09.159840
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    result = task_result_0.is_skipped()


# Generated at 2022-06-24 19:25:17.217556
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b't\x10\xe3'
    str_0 = '^F'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    bytes_1 = b'!\x17\x1c\x1d\xee'
    str_1 = '3'
    task_result_1 = TaskResult(bytes_1, str_1, str_1)
    int_0 = task_result_1.is_skipped()



# Generated at 2022-06-24 19:25:19.301638
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:25:38.353297
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)


# Generated at 2022-06-24 19:25:42.732213
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    assert True
    bytes_0 = b'Y'
    str_0 = 'K&'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert callable(getattr(task_result_0, "is_skipped", None))
    assert task_result_0.is_skipped() == False



# Generated at 2022-06-24 19:25:50.810760
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Test for the case where the results are empty
    # Expect the result is 'skipped'
    bytes_0 = b'\xdb,'
    str_0 = 'H'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert task_result_0.is_skipped()==True

    # Test for the case where the results are not empty
    # Expect the result is 'skipped'
    bytes_0 = b'\xdb,'
    str_0 = 'H'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert task_result_0.is_skipped()==True

    # Test for the case where the results are not empty
    # Expect the result is False
    bytes_0 = b'\xdb,'

# Generated at 2022-06-24 19:25:53.709455
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'&e'
    int_0 = 0
    str_0 = 'gT'
    str_1 = 'b0!gxj1.e'
    task_result_0 = TaskResult(bytes_0, str_0, str_1)
    bool_0 = task_result_0.is_failed()
    print(bool_0)


# Generated at 2022-06-24 19:26:00.625357
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'o.D\x7f\n\x1e\x1a\x1c^\x0e\x10\x15\x0b\x1b\x07\x1a\x1f\x03'
    str_1 = '\x1cF\x05\x11\x14\x0c\x13\x00\x1d\x19\x1f'
    str_2 = '\x0b\x08\x14\x03\x1f\x00\x1bG\x0e\x02\x0c\x00\x14\x11\x0f\x06\x12\x1a\x00\x07\x11\x0b\x13'


# Generated at 2022-06-24 19:26:04.391153
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    res = task_result_0.needs_debugger(True)



# Generated at 2022-06-24 19:26:07.452970
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:26:14.036167
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('in test_TaskResult_is_failed')
    bytes_0 = b'\x92\xeb\xbd4\x1e\x9f$\x14\xee\xc6'
    task = {'results': []}
    task_result = TaskResult(bytes_0, task, task)
    test_TaskResult_is_failed_0(task_result)
    test_TaskResult_is_failed_1(task_result)


# Generated at 2022-06-24 19:26:19.228024
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    assert not task_result_0.is_failed()
    pass


# Generated at 2022-06-24 19:26:23.909257
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
#     bytes_0 = b'9sc'
#     str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
#     task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0 = TaskResult(None, None, None)
    try:
        result_0 = task_result_0.is_skipped()
    except Exception:
        raise


# Generated at 2022-06-24 19:26:51.244838
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    bytes_1 = b'a'
    str_1 = 'f)F(d'
    str_2 = 'T2\x17\x18\x14R\x03\x15\x05\x07\x0c\x1e\x0b\x1f\x06\r'
    bytes_2 = b'E'
    str_3 = 'm'
    bytes_3 = b'\x7f'
    bytes_4 = b'\xf2'
    str_4 = 'u'

# Generated at 2022-06-24 19:26:57.829399
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x0c$\xa8\x1f\xd3\x7f\xd5\xc8@'
    str_0 = 'Q\x86)y\xad\xa6rw\xfe\x9d\x8b\xc0\xb1\x1e]v\x8a\xe3u\xfb\xf5\xd9\x8d\x93\xed\x0c\xdb\x8d'
    bytes_1 = b'\xb2\xf8\x0c\xac\x05\x01\x8f\xc4\xfc\x9a\x92\x87+}$\xbc\xa1'

# Generated at 2022-06-24 19:27:02.689322
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Test no-op path
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    result = task_result_0.needs_debugger()
    assert not result

    # Test no-op path
    result = task_result_0.needs_debugger(True)
    assert not result

    # Test failure path
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    result = task_result_0.needs_debugger(False)
    assert not result

    # Test failure path
    result = task_result_

# Generated at 2022-06-24 19:27:04.774255
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:27:06.508655
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TaskResult.is_changed()
    pass


# Generated at 2022-06-24 19:27:09.339220
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'9sc'
    str_0 = 'E7rqt^e)xX-0JaB-Yj0.'
    task_result_0 = TaskResult(bytes_0, str_0, str_0)

    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:27:13.346124
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'zn\x1f\x15\x90'
    int_0 = -7
    str_0 = '6Ia'
    task_result_0 = TaskResult(str_0, int_0, bytes_0)
    result = task_result_0.is_failed()



# Generated at 2022-06-24 19:27:23.277325
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_1 = b'#^b'
    str_1 = 'Ua5o5-7@!Jx-v*zKj'
    dict_1 = {}
    dict_1['skipped'] = False
    dict_1['_ansible_ignore_errors'] = False
    dict_1['stderr'] = ':s'
    dict_1['rc'] = 0
    dict_1['stdout_lines'] = ['M0Z$T3H', 'p', 't', 'y^xA-L9P', 'N', '2!@Zt']
    dict_1['start'] = '2019-11-15 15:55:24.990680'

# Generated at 2022-06-24 19:27:25.365313
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # AssertionError: Expected task_result_1.clean_copy() to equal 'dict' but got 'dict'
    assert type.__name__ == 'type'



# Generated at 2022-06-24 19:27:28.176174
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_1 = b'u\x87\x07\xc2'
    str_1 = 'Hc\x7fq[r\x14\x1a\x02'
    task_result_1 = TaskResult(bytes_1, str_1, str_1)
    result_1 = task_result_1.is_failed()
    assert isinstance(result_1, bool)
