

# Generated at 2022-06-24 19:17:56.752314
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_1 = -18352
    str_1 = "IG79"
    float_1 = 8192.0
    task_result_1 = TaskResult(int_1, str_1, float_1)
    assert task_result_1.is_failed() == False


# Generated at 2022-06-24 19:18:04.645891
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Test only case 1
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    # Test control point 1
    # Call method needs_debugger with parameters False
    assert not task_result_0.needs_debugger()
    # Test control point 2
    # Call method needs_debugger with parameters True
    assert not task_result_0.needs_debugger(True)
    # Test control point 3
    # Call method needs_debugger with parameters False
    assert not task_result_0.needs_debugger()
    # Test control point 4
    # Call method needs_debugger with

# Generated at 2022-06-24 19:18:12.461940
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_1 = task_result_0.clean_copy()
    test_1_result = task_result_1
    assert test_1_result == task_result_0


# Generated at 2022-06-24 19:18:19.525568
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = 1431
    str_0 = "3J@ZAP)G\x14\x14\x05\x0c\x1b\x1e\"\x1c\x1e\x1c\x17\x05.N\x15\x1c\x1f\x01"
    float_0 = 14.08205
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:22.827043
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_1 = 0
    str_1 = "ab\\D$"
    float_1 = -9.0
    task_result_1 = TaskResult(int_1, str_1, float_1)
    assert task_result_1.is_skipped() == False


# Generated at 2022-06-24 19:18:24.627253
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    pass


# Generated at 2022-06-24 19:18:33.343215
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:18:41.253461
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = 50026
    str_0 = "=@/\x15\x17\x00\x1a\x11\x16p\x1cw\x0f\x18\x11\x0b\x05\x1aY(J\x1f\x00\x1c\x17\x00\x1c\x14\x18\x13\x0c\x0c\x17\x06\x1c\x06\x06\x1a\x13"
    float_0 = -624.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:46.265943
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -1966
    str_0 = "J\x1e\x1b\x0b\x03#\x056\x1c\x04\x0c\x12"
    float_0 = 0.04
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:18:56.184200
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result_0 = task_result_0.clean_copy()
    str_1 = 'y$^kQ\x0c[5.c\'0a(A\x0b&'
    assert str_1 == str_0
    bool_0 = bool('eH_7VJ\x0c)&\\?]<')
    bool_1 = bool(str_0)
    assert bool_0 == bool_1
    int_1 = -38726
    int_2 = int(str_0)
    assert int

# Generated at 2022-06-24 19:19:08.844437
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = 0
    str_0 = ")"
    float_0 = 578.5475469302049
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.needs_debugger('l')


# Generated at 2022-06-24 19:19:15.463142
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    test_value = task_result_0.needs_debugger()
    assert False



# Generated at 2022-06-24 19:19:20.455978
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -5377
    str_0 = '96i/:0k2/'
    float_0 = -6398.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:24.459101
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert not  task_result_0.clean_copy() is None


# Generated at 2022-06-24 19:19:30.772627
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.is_skipped()
    assert bool_0 is False


# Generated at 2022-06-24 19:19:34.165240
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result = task_result_0.needs_debugger(bool_0)
    assert(isinstance(result, bool))
    assert result


# Generated at 2022-06-24 19:19:40.669303
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    # Method is_skipped of class TaskResult has not been implemented
    assert False


# Generated at 2022-06-24 19:19:47.731872
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_tuple_0 = tuple(task_result_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:48.756390
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(0, "", 0)
    task_result_0.needs_debugger

# Generated at 2022-06-24 19:19:50.754191
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    #test_case_0()
    print('testcase')



# Generated at 2022-06-24 19:20:14.400032
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_1 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_1 = 512.0
    int_1 = 30
    task_result_0 = TaskResult(int_0, str_1, float_1)
    #Verify True
    bool_0 = task_result_0.is_failed()
    #Verify False
    bool_0 = task_result_0.is_failed(int_1)


# Generated at 2022-06-24 19:20:19.397004
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:26.697687
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -3900
    str_0 = ">"
    float_0 = 8192.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1.task_name == str_0
    assert task_result_0._task == task_result_1._task
    assert task_result_0._result == task_result_1._result
    assert task_result_0._host == task_result_1._host
    assert task_result_1._host == int_0
    assert task_result_0._task_fields == task_result_1._task_fields


# Generated at 2022-06-24 19:20:31.281959
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    # True
    print(task_result_0.is_failed())


# Generated at 2022-06-24 19:20:37.713886
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:47.159910
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('test_TaskResult_is_failed')
    # Assign values for test
    str_0 = "H^x\x1f$"
    bool_0 = True
    int_0 = -1788
    bool_1 = False
    float_0 = 895.0
    # Test method is_failed of class TaskResult
    int_0 = -1602
    str_0 = "l!<\x0e\x10(\x1cX\x1f,\x1b\x1d\x1f"
    task_result_0 = TaskResult(int_0, str_0, int_0)
    task_result_0.is_failed()
    # Test method is_failed of class TaskResult
    print('Test method is_failed of class TaskResult')

# Generated at 2022-06-24 19:20:51.740299
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -6616
    str_0 = '^D`\x0e\'v\x1fD\x0eV!\x1c'
    float_0 = 0.015625
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:20:56.746648
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)


# Generated at 2022-06-24 19:21:02.834610
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print('')
    # Setup test data
    int_0 = 8
    str_0 = "ER\x06b!v;S\x0b>\x0bP"
    int_1 = -29610
    list_0 = [int_0, str_0, int_1]
    tuple_0 = (list_0,)
    TaskResult_0 = TaskResult(int_0, str_0, tuple_0)

    # Invoke method
    TaskResult_0.is_skipped()

    # Assert
    # Assert None



# Generated at 2022-06-24 19:21:06.151980
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    ans         = task_result_0.is_failed()
    assert       ans == False


# Generated at 2022-06-24 19:21:38.193490
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -1601
    str_0 = "._@.b\x10%c\x0c"
    float_0 = -77.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    # Test error conditions
    try:
        task_result_0.is_failed(int_0)
    except TypeError:
        pass

    # Test normal condition
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:21:45.004576
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    # Test without argument
    assert False == task_result_0.needs_debugger()

    # Test with arguments
    assert False == task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:21:49.789706
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.is_failed()
    return bool_0


# Generated at 2022-06-24 19:21:53.821355
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result_0 = task_result_0.is_failed()
    assert result_0 == False


# Generated at 2022-06-24 19:21:54.812929
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # test TaskResult.is_skipped()
    assert True


# Generated at 2022-06-24 19:22:01.016429
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    ret_val_0 = task_result_0.needs_debugger(False)

    assert ret_val_0 == False


# Generated at 2022-06-24 19:22:03.886942
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -1599
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.is_failed()
    bool_1 = task_result_0.is_changed()


# Generated at 2022-06-24 19:22:09.817105
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.is_failed()

# Generated at 2022-06-24 19:22:14.878510
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:22:21.662420
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -14030
    str_0 = '''jiV>m'\x1f?S$5<5\x1b3!\x1eU\x18*6\x1e'''
    task_result_0 = TaskResult(int_0, str_0)
    assert not task_result_0.is_failed()
    assert task_result_0.is_failed()
    assert task_result_0.is_failed()


# Generated at 2022-06-24 19:22:43.612550
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert True == TaskResult.is_failed(str)
    assert True == TaskResult.is_failed(int)
    assert True == TaskResult.is_failed(float)


# Generated at 2022-06-24 19:22:48.817477
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -11359
    str_0 = "H5'wm\x7f\x16C(w0:\\\x18\x2c\x7f"
    float_0 = 8192.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:22:57.906725
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -183
    str_0 = "p.V7`;tH#\x7f54'\x16\x5c\x5f9\x1b\x09\x1e\x1ao7\x0b8W"
    float_0 = 2048.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result = task_result_0.is_skipped()

    assert result == False, "Expected False, but got %s" % result



# Generated at 2022-06-24 19:23:02.182986
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert task_result_0.clean_copy() != None


# Generated at 2022-06-24 19:23:07.441699
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Create new object of TaskResult
    task_result_0 = TaskResult(
        host='host_0',
        task=None,
        return_data='return_data_0',
        task_fields=_IGNORE)

    # Set value of variable globally_enabled
    globally_enabled = 'globally_enabled'

    # Store values of method needs_debugger of task_result_0 in a variable
    needs_debugger_result = task_result_0.needs_debugger(globally_enabled)

    # Assert the expected result
    assert needs_debugger_result == False



# Generated at 2022-06-24 19:23:17.393556
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2757

# Generated at 2022-06-24 19:23:22.388318
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    TaskResult_0 = TaskResult(int_0, str_0, float_0)
    TaskResult_0.clean_copy()



# Generated at 2022-06-24 19:23:28.697298
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result_0 = task_result_0.clean_copy()
    if None:
        raise Exception()


# Generated at 2022-06-24 19:23:33.444021
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.clean_copy()

# Generated at 2022-06-24 19:23:38.270160
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:24:21.784382
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = 1
    str_0 = "WF9|"
    dict_0 = dict()
    dict_0["changed"] = True
    dict_0["failed"] = True
    dict_0["invocation"] = dict_0
    task_result_0 = TaskResult(int_0, str_0, dict_0)
    assert task_result_0.is_failed()


# Generated at 2022-06-24 19:24:25.584586
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    return_data = {
        "changed": True,
        "results": [{
            "changed": False
        }],
    }
    task_result_0 = TaskResult(None, None, return_data)
    assert task_result_0.is_skipped()


# Generated at 2022-06-24 19:24:36.166569
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -112.1223332763
    str_0 = "1"
    float_0 = -112.1223332763
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert(task_result_0.is_skipped() == False)

    int_0 = -112.1223332763
    str_0 = "1"
    float_0 = 0.2483917894444
    task_result_0 = TaskResult(int_0, str_0, float_0)
    assert(task_result_0.is_skipped() == False)

    int_0 = 0.2483917894444
    str_0 = "H"
    float_0 = -112.1223332763
    task_result_0

# Generated at 2022-06-24 19:24:40.724407
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = 5
    str_0 = "LM['\x0bp\x13\x1f\x0c\x0e:`\x1d"
    float_0 = 957.9
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:51.159004
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = "O$\x13\x1f\x16\x01\x0e\x1e\x1d%\x18?\x1e\x11;\x05\x11\x1e\x07\x12\x1c\x16\x1d\x1d"
    task = "\x1a\x1f\x1d\x0c\x0e\x1a\x14[\x1f\x19\x1f\x15\x11\x07\x08\x16\x13i\x0b\x1a\x1c\x1d\x04\x0e\x0c\x13\x1a\x1f\x1d\x0c\x0e\x1a\x14"
    return

# Generated at 2022-06-24 19:24:56.188382
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result = task_result_0.is_skipped()
    assert (result != 0)

# Generated at 2022-06-24 19:25:02.581724
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.needs_debugger(True)
    print("action is: " + str(bool_0))

if __name__ == "__main__":
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:25:06.148847
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = 937
    str_0 = "J-\x1d2G\t\rsKe,\x13p\x0b\x12\"\x0e"
    float_0 = 0.96
    task_result_0 = TaskResult(int_0, str_0, float_0)
    bool_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:25:14.948329
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(127, "S]{~*R0", 2.2)
    task_result_1 = task_result_0.clean_copy()
    task_result_1 = TaskResult(127, "S]{~*R0", 2.2)
    task_result_1 = task_result_0.clean_copy()
    task_result_2 = TaskResult(127, "S]{~*R0", 2.2)
    task_result_1 = task_result_2.clean_copy()
    task_result_1 = TaskResult(127, "S]{~*R0", 2.2)
    task_result_1 = task_result_2.clean_copy()

# Generated at 2022-06-24 19:25:19.760513
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -1979283340
    str_0 = "3%r\x1f\x1c\x1a\x1e\x1b\x18\x12\x00\r%r\x1f\x1c\x1a\x1e\x1b\x18\x12\x00\r%r\x1f\x1c\x1a\x1e\x1b\x18\x12\x00\r"
    float_0 = -2048.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:26:32.801517
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -10024
    str_0 = "f)`r:r"
    float_0 = -3032.0

    task_result_0 = TaskResult(int_0, str_0, float_0)
    
    # set assertions here
    # test if 'task_result_0' has attribute 'clean_copy'
    assert hasattr(task_result_0, 'clean_copy')

# Unit tests for method is_changed of class TaskResult

# Generated at 2022-06-24 19:26:36.496981
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    return_value_0 = task_result_0.clean_copy()
    assert return_value_0



# Generated at 2022-06-24 19:26:46.980816
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    int_0 = 45152
    str_0 = "7'4$\x1f7&\x0e%\x0b"
    float_0 = 69.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    assert task_result_0.needs_debugger() == False
    assert task_result_0.needs_debugger(True) == False

    int_1 = -28067
    str_1 = "n$^3\x18[5.c'0a(A\x0b&"
    float_1 = -921.0
    task_result_1 = TaskResult(int_1, str_1, float_1)

    assert task_result_1.needs_debugger() == False
    assert task_result_1.needs_

# Generated at 2022-06-24 19:26:53.048445
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0.clean_copy()



# Generated at 2022-06-24 19:26:59.580249
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    int_0 = -8422
    float_0 = -241.3
    str_0 = "E\x1c\x1d$@\x1b\x0c\x0fPq>w\x0c\x1d\x1c%4^g\x03\x1e\x1d\x1c\x00o\x1c\x1d\x1c"
    task_result_0 = TaskResult(str_0, int_0, float_0)

    task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:05.855368
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -1811
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    answer_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:27:09.937598
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = 930
    str_0 = '|\x1f`C\x1a\x1a(N\\}hA\\\x1a\\\x10\x0f\x02'
    float_0 = 366.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    result = task_result_0.clean_copy()
    assert result == task_result_0


# Generated at 2022-06-24 19:27:16.883918
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -701
    str_0 = '-@13w#vD`MjWm`X=\x7f\x0b\x1e'
    float_0 = 0.0
    dict_5 = dict()
    task_0 = Task(int_0, str_0, float_0, dict_5)
    str_1 = '&l9Td7\x1f[;|bP,18Qa"z]\x19\x02\x0c'
    float_1 = 0.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    task_result_0._task = task_0
    task_result_0._result = str_1
    task_result_1 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:27:22.062442
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)

    # Test procedure
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:27.814649
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2080
    str_0 = "y$^kQ\x0c[5.c'0a(A\x0b&"
    float_0 = 512.0
    task_result_0 = TaskResult(int_0, str_0, float_0)
    # Call method clean_copy of class TaskResult
    task_result_0.clean_copy()
