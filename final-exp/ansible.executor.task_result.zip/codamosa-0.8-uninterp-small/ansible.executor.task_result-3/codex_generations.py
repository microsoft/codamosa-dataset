

# Generated at 2022-06-24 19:17:59.429591
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:18:07.602503
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Create an instance of the class being tested
    str_0 = 'ua-\r\n'
    str_1 = 'tok'
    str_2 = 'ui-'
    str_3 = 'tok'
    str_4 = ' <>tok'
    int_0 = 2
    int_1 = 4
    int_2 = 0
    int_3 = 3
    none = None
    bool_0 = False
    bool_1 = True
    dict_0 = {
        'changes': {
            'stdout': str_4,
            'stdout_lines': [str_4]
        }
    }

# Generated at 2022-06-24 19:18:12.748221
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    try:
        print('%s.%s' % (__name__, 'test_TaskResult_clean_copy'))
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print('passed!')

if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:18:15.618955
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '+G'
    dict_0 = {str_0: str_0, str_0: str_0}
    task_result_0 = TaskResult(str_0, dict_0, dict_0)
    task_result_0.needs_debugger()



# Generated at 2022-06-24 19:18:20.412757
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    dict_0 = {'task': {'task-0': {'role file': '', 'task': '', 'add': ''}}, 'include_role': {'name': 'name-0'}}
    str_0 = 'module'
    dict_1 = {str_0: dict_0}
    dict_2 = {'task': {'task-0': {'role file': '', 'task': '', 'add': ''}}, 'include_role': {'name': 'name-0'}}
    task_result_0 = TaskResult(str_0, dict_1, dict_2)
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:18:31.749608
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'v3qo;\r~Ks\t{E_t'
    list_1 = ['a8r=W', 'v3qo;\r~Ks\t{E_t', ':', None]
    list_2 = [';F', 'v3qo;\r~Ks\t{E_t', ':', None]
    list_0 = [";Y\t_!^\x7f,4+", "v3qo;\r~Ks\t{E_t", ":", None]
    dict_0 = {str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0}

# Generated at 2022-06-24 19:18:37.554493
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'W?\x1c\x17\x06\x1e\x0f\x08\x10F'
    dict_0 = {str_0: str_0, str_0: str_0}
    task_result_0 = TaskResult(str_0, dict_0, dict_0)

    assert task_result_0.needs_debugger() == False

# Generated at 2022-06-24 19:18:48.661539
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # get resultset
    # check if is_skipped is called with a TaskResult object
    # check if returned value is a bool
    # check if is_skipped returned value is True
    # check if is_skipped returned value is False
    str_0 = 'd\x13&o\x0c\x01\x09\x02\x02\x12\x0c\x05\x10\x02\x05\x0f\x12\t\x07\x06\t\x1c'
    dict_0 = {str_0: str_0, str_0: str_0}
    task_result_0 = TaskResult(str_0, dict_0, dict_0)
    assert_true(task_result_0.is_skipped())

# Generated at 2022-06-24 19:18:58.108464
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '[Y]\r\n'
    dict_0 = {'cwm-L\x82\x19\x02': str_0, 'r\x19\x00': str_0, 'e\x19\x00': str_0, 's\x00\x00\x00\x00\x00\x00': str_0, ']\x00\x00\x00\x00\x00': str_0, 'v\x19\x00': str_0}
    str_1 = 'q6\x14\x00\x00'
    str_2 = '\x11\x18\x00\x00'
    task_result_0 = TaskResult(str_1, dict_0, dict_0)
    assert not task_result_0.is_

# Generated at 2022-06-24 19:19:06.658884
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '!'
    str_1 = 'n'
    str_2 = 'PH'
    str_3 = 'n4'
    str_4 = '.'
    str_5 = '*<'
    str_6 = '^1'
    str_7 = ']Q'
    str_8 = 's'
    str_9 = 'Bg'
    str_10 = 'Ao'
    dict_0 = {str_3: str_7, str_9: str_7, str_10: str_7}
    dict_1 = {str_2: str_7, str_4: str_7, str_5: str_7, str_6: str_7}

# Generated at 2022-06-24 19:19:20.063399
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '>\x0c\x14\x10\t\x14t'
    str_1 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_1, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:24.317377
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '{i\x7f,\t?\x7f\x0cm\x7fh\rpp\x7f<\x0c}'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:30.812266
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '\xe3Y\xc9\xd7\xb3\xdd\x01'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.is_failed()
    str_0 = '"h\x0c\xc8\x08\xe0<\xfc\x91\x94\xa2\xeb'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.is_failed()
    str_0 = 'http://example.com'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.is_failed()

# Generated at 2022-06-24 19:19:36.543831
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger()

if __name__ == "__main__":
    import time, sys

    count = int(sys.argv[1]) if sys.argv[1:] else 100
    timer = time.time
    if sys.platform == 'win32':
        timer = time.clock
    range_it = range(count)
    dt = timer() - timer()
    for i in range_it:
        test_case_0()

    dt = timer() - timer()
    for i in range_it:
        test_TaskResult_needs_debugger()

   

# Generated at 2022-06-24 19:19:42.600587
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger(True)
    bool_1 = task_result_0.needs_debugger(True)
    assert bool_0 == bool_1



# Generated at 2022-06-24 19:19:44.385297
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert test_case_0() is None, "Method: clean_copy of class: TaskResult should call return None"


# Generated at 2022-06-24 19:19:47.154381
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:56.609221
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    task_result_0 = TaskResult(str_0, str_1, str_1)
    task_result_0.needs_debugger()



# Generated at 2022-06-24 19:20:02.869008
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'y+7Vm\x5c\x5ci<}P\x7fL\x1f\x18'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:04.696737
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = ','
    str_1 = '\\'
    task_result_0 = TaskResult(str_0, str_1, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:15.723325
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '7v\x0cWV\x0c\x1e`;|\x1bO\x02)0@3'
    str_1 = "{{ 'hello' }}"
    task_result_0 = TaskResult(str_1, str_0, str_0)
    str_2 = 's\x0c?_\n%w\x1d\x12\x1a'
    dict_0 = dict()
    dict_0['msg'] = str_2
    dict_0['changed'] = True
    dict_0['failed'] = False
    dict_0['invocation'] = dict()
    dict_1 = dict()
    dict_1['module_name'] = 'Replace'
    dict_0['invocation']['module_name'] = dict_1


# Generated at 2022-06-24 19:20:20.475474
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\x04\x0c"\xa1!\xe7\x11T\x04\x11\x12\x16\t\x1c'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger(True)



# Generated at 2022-06-24 19:20:27.050729
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Set up
    task_result = TaskResult('a', 'b', 'c')

    # Invoke method
    result = task_result.needs_debugger('a')


# Generated at 2022-06-24 19:20:28.445541
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

if __name__ == '__main__':
    # Unit tests for TaskResult class
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:20:35.167353
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '\x0e'
    str_1 = '\x0e'
    dict_0 = {'\x0e': {'\x0e': '\x0e', '\x0f': '\x0e'}, '\x0f': {'\x0e': '\x0e', '\x0f': '\x0e'}}
    dict_1 = {'\x0e': '\x0e', '\x0f': '\x0e'}
    dict_2 = {'\x0e': '\x0e', '\x0f': '\x0e'}
    dict_3 = {'\x0e': '\x0e', '\x0f': '\x0e'}

# Generated at 2022-06-24 19:20:40.146487
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    class_under_test = TaskResult
    # parameters
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result_0 = class_under_test.is_failed(task_result_0)
    assert result_0 == False


# Generated at 2022-06-24 19:20:48.797994
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'F_lRg&'
    str_1 = ';Y\x0c<%56'
    task_result_0 = TaskResult(str_0, str_1, str_0)
    ret_0 = task_result_0.is_skipped()
    str_2 = '9Z?Pb\x0c'
    str_3 = 'r@1B.\x0e'
    task_result_1 = TaskResult(str_2, str_3, str_1)
    ret_1 = task_result_1.is_skipped()
    str_4 = 'jJ&n_'
    str_5 = '+%c$#'
    task_result_2 = TaskResult(str_4, str_5, str_1)

# Generated at 2022-06-24 19:20:59.394387
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    str_1 = '}zJ=%%fM\r9\x1e)5I\x19\x1a\x1a\x0b\x0e'
    str_2 = 'I\x1a,W\x1e\x1a\x05\x11\x1b\x0cX\x0e\x05\x1a\x1f'
    str_3 = '\x1b\x1f\x12k\x1d\x12\x0f\x1fK\x1f\x1a\x1d\x19'
    task_result_0 = TaskResult(str_0, str_1, str_2)


# Generated at 2022-06-24 19:21:02.950923
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Create instances of TaskResult
    task_result_0 = TaskResult('hostname', 'task', 'result')
    task_result_1 = TaskResult('hostname', 'task', 'result')

    # Verify the failure of is_failed function
    if task_result_1.is_failed():
        raise Exception('Unexpected behavior: TaskResult.is_failed')


# Generated at 2022-06-24 19:21:14.407766
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from string import ascii_uppercase, digits
    from random import choice
    from ansible.parsing.dataloader import DataLoader
    task_fields = {}
    host = ''.join([choice(ascii_uppercase) for i in range(10)])
    task = ''.join([choice(digits) for i in range(10)])
    return_data = ''.join([choice(ascii_uppercase) for i in range(10)])
    task_fields = DataLoader().load(task_fields)
    task_result_0 = TaskResult(host, task, return_data, task_fields)
    task_result_0.clean_copy()

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:29.016256
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_1 = 'i\x0c=|\x7f\x13\x1b\x1c\\\x7f\x03\x1d\x01\x1b\x1b'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    assert_equal(task_result_1.is_skipped(), False)


# Generated at 2022-06-24 19:21:40.367688
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '\n\x14z}\x1e'
    str_1 = '3\x12t\x21\x0e\x0cd\x00\x13\x1f'

# Generated at 2022-06-24 19:21:46.874409
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'perf2.dns.globoi.com'
    TaskResult_0 = TaskResult(str_0, str_0, str_0)
    result_1 = TaskResult_0.clean_copy()
    assert result_1.task_name == 'perf2.dns.globoi.com'


# Generated at 2022-06-24 19:21:54.995016
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Oj\x0c8\x0cd\x0bM~\x0bZ[\x0ey_R\x0b'
    str_1 = 'Y\x0e\x0b\x0fj\x0eu\x0e\x0cq\x0c\x0e9\x0f\x0fC}\x0e'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    # Check if the method clean_copy of class TaskResult throws an exception
    with pytest.raises(Exception):
        task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:59.232218
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'Dl\x1apH#'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:22:02.383791
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert test_case_0() is None


# Generated at 2022-06-24 19:22:08.308933
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Instantiate
    task_result_0 = TaskResult('x', 'x', 'x')

    # Test needs_debugger
    assert task_result_0.needs_debugger() == False


# Generated at 2022-06-24 19:22:15.319349
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\x7f\x87\x04\xe1\x1cW\x9c\x19\x0b#\xdc\x15\x87\x1cw3'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger()
    assert not bool_0


# Generated at 2022-06-24 19:22:22.029535
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Create TaskResult object
    task_result_0 = TaskResult(".H\x0bdSFZ^\x0cfOR#a6>ZnA", ".H\x0bdSFZ^\x0cfOR#a6>ZnA", ".H\x0bdSFZ^\x0cfOR#a6>ZnA")
    # Get result of is_skipped() method
    result = task_result_0.is_skipped()

    assert result == False


# Generated at 2022-06-24 19:22:25.437415
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Setup
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    # Verify
    assert not task_result_0.is_skipped()
    # Teardown


# Generated at 2022-06-24 19:22:37.816057
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_1 = TaskResult('', {}, {})
    task_result_2 = TaskResult('', {}, {})

    task_result_3 = TaskResult('', {}, {})
    task_result_3.clean_copy()
    task_result_3._task_fields = {}

    task_result_4 = TaskResult('', {}, {})
    task_result_4.clean_copy()
    task_result_4._task = {}

    task_result_5 = TaskResult('', {}, {})
    task_result_5.clean_copy()
    task_result_5._host = {}


# Generated at 2022-06-24 19:22:42.609330
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = ',\x0b=?`\x08\x0f"|\x0cjB6\x07\x04\x0c\x00\x0bF\x0c'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:22:53.844632
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'T.\t\r\t\x0b\x0b\x0b\x0b\x0b\x0b\x01\x0b\x0b4\x01\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x06\x01\x0b\x0b4\x01\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x06'
    task_result_0 = TaskResult(str_0, str_0, str_0)

# Generated at 2022-06-24 19:22:59.393872
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_1 = ' \x0b*^\x0fY\x00\x11P\x14K[R\x1c'
    str_2 = '\x0b\x01\x00r\x0b\x0cR=\x1c\x0f\x19\x15'
    str_3 = '\x06\x12\x1c\x0e\x0bX\x06\x1e\x0b\x0c\x12'
    task_result_0 = TaskResult(str_1, str_2, str_3)
    assert not task_result_0.needs_debugger()
    str_4 = ' \x0b*^\x0fY\x00\x11P\x14K[R\x1c'
   

# Generated at 2022-06-24 19:23:07.179888
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._host == '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    assert task_result_1._task == '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    assert task_result_1._task_fields == {}



# Generated at 2022-06-24 19:23:17.185678
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult('hostname', 'task', {'changed': True})
    assert not task_result_0.needs_debugger(True)
    assert not task_result_0.needs_debugger(False)

# Generated at 2022-06-24 19:23:26.877507
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'm_\x0b\x17\x12\x1a\x1e\t\x07\x19\t\x0f\x17\x07\x1d\x1b\x1f\x1b\x19\t\x0f\x07\x0b\x1e\x1d\x17\x1b\x1d\x0f\x07\x1a\x1e\x12\x07\x0f\x19\n\n\x1a\x07\x1f\x1b\x1e\x0f\x19\x07'

# Generated at 2022-06-24 19:23:37.353016
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '\x08\x1b\x0c\x0e\x1b\x1b'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_skipped() == False
    str_0 = '\x06\x11\r\r\r\r\r\r'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_skipped() == False
    str_0 = '\x0c\r\r\r\r\r\r\r\r\r\r'
    task_result_0 = TaskResult(str_0, str_0, str_0)

# Generated at 2022-06-24 19:23:43.566825
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult('aZl2K7VdD', 'N', 'N')
    assert task_result_0.is_skipped() == False
    task_result_1 = TaskResult('D', '1$?sLZ@[m', 'D')
    assert task_result_1.is_skipped() == False


# Generated at 2022-06-24 19:23:46.202782
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '\tS\x0e3PX\x0bMK<\x0fH\x0bR*5'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:53.674203
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result = TaskResult(host=None, task=None, return_data=None)
    assert not task_result.is_skipped()


# Generated at 2022-06-24 19:23:58.677252
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result = TaskResult('host', 'task', str_0)
    ansible_check_key = task_result.is_skipped()
    return ansible_check_key


# Generated at 2022-06-24 19:24:07.587061
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:24:08.707925
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert test_TaskResult_is_skipped.__annotations__ == {}


# Generated at 2022-06-24 19:24:09.490230
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert True


# Generated at 2022-06-24 19:24:09.959110
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert True


# Generated at 2022-06-24 19:24:12.964517
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    tr = TaskResult('foo', 'bar', str_0)
    assert tr.clean_copy() == {u'censored': u'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'}


# Generated at 2022-06-24 19:24:15.446124
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    data = {'skipped': True, 'results': [{'skipped': True}, {'skipped': True}, {'skipped': True}]}
    task_result = TaskResult(None, None, data)
    assert task_result.is_skipped() is True


# Generated at 2022-06-24 19:24:27.243862
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = {'results': [{'skipped': False}, {'skipped': False}, {'skipped': False}]}
    task = {'name': 'parsing_status.py', 'ignore_errors': False}
    TaskResult('host', task, result)
    assert TaskResult('host', task, result).is_skipped() == False
    result = {'results': [{'skipped': False}]}
    assert TaskResult('host', task, result).is_skipped() == False
    task = {'name': 'parsing_status.py', 'ignore_errors': False}
    result = {'skipped': False}
    assert TaskResult('host', task, result).is_skipped() == False

# Generated at 2022-06-24 19:24:35.762620
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'm_\x0b\x17\x12\x1a\x1e\t\x07\x19\t\x0f\x17\x07\x1d\x1b\x1f\x1b\x19\t\x0f\x07\x0b\x1e\x1d\x17\x1b\x1d\x0f\x07\x1a\x1e\x12\x07\x0f\x19\n\n\x1a\x07\x1f\x1b\x1e\x0f\x19\x07'
    task_fields_0 = {'delegate_to': 'localhost', 'register': 'test_TASK_2'}

# Generated at 2022-06-24 19:24:48.054627
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'z\x0bn\x1a\x0b\x0fP\x1f\x1a\r\r\\\x08\x1a\x0c9\x1bK'
    str_1 = '\x0ct\x17\x1c\x1frv'
    task_result_0 = TaskResult(str_0, str_0, str_1)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:24:51.491058
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_1 = TaskResult(str_0, str_0, str_0)
    globally_enabled_0 = True
    assert task_result_1.needs_debugger(globally_enabled=globally_enabled_0) == True


# Generated at 2022-06-24 19:24:53.886605
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # FIXME: Auto-generated by mock_codecov_fixture_factory.py
    expected = None
    assert expected == TaskResult.is_failed()


# Generated at 2022-06-24 19:25:03.386072
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = ':gU;F6<Hp6'
    str_1 = 'zQ`f'
    str_2 = '+&\x7f:\x1fNp~\x1dc\x1d,/\x1f\\fw\x16\x01f\x01\x10J\x1b\x1a\x1a\x0e\x0e\x19\x16$9'
    dict_0 = {'yq\x1d': 0, str_0: ')>e!l'}
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = TaskResult(str_0, str_0, str_0)

# Generated at 2022-06-24 19:25:05.912933
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = callable
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:25:14.805318
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    str_1 = '\n{uA7'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = TaskResult(str_0, str_0, str_0)
    task_result_1._task_fields = {'debugger': task_result_0, 'ignore_errors': task_result_0}
    task_result_2 = TaskResult(str_0, str_0, str_0)
    task_result_2._task_fields = {'debugger': task_result_0}
    task_result_3 = TaskResult(str_0, str_0, str_0)
    task_result_3._task

# Generated at 2022-06-24 19:25:19.417436
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'd$R'
    dict_0 = {}
    str_1 = 'm0nK'
    task_result_0 = TaskResult(str_0, str_1, dict_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._task != None
    assert task_result_1._result != None
    assert task_result_1._task_fields != None
    assert task_result_1._host != None


# Generated at 2022-06-24 19:25:22.949383
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

# Generated at 2022-06-24 19:25:25.755553
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    res = task_result_0.needs_debugger('', str_0)
    assert res == True


# Generated at 2022-06-24 19:25:26.423241
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    clean_copy()


# Generated at 2022-06-24 19:26:04.248560
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:26:08.768758
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '*^a0\x0c@8\x01\x0bmy\r\n\x1c\x1b'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    if task_result_0.is_failed():
        print('task_result_0.is_failed(): ', task_result_0.is_failed())
    else:
        print(task_result_0.is_failed())


# Generated at 2022-06-24 19:26:19.334731
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:26:22.614460
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result = task_result_0.needs_debugger(True)
    assert result == False


# Generated at 2022-06-24 19:26:28.534047
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Init of data
    str_0 = 'y5I5$Y#\x0bF%Wl2\x0c~'

# Generated at 2022-06-24 19:26:35.252215
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

	# Arrange
	data_0 = set()
	data_1 = []
	data_2 = {}
	data_3 = {}
	data_4 = {}
	data_5 = {}
	data_6 = {}
	data_7 = {}
	data_8 = {}

	data_2 = get_random_str(10)
	
	data_8 = {'failed':data_2}

	# Act
	task_result_0 = TaskResult(data_2, data_2, data_8)
	task_result_1 = TaskResult(data_2, data_2, data_8)
	task_result_2 = TaskResult(data_2, data_2, data_0)
	task_result_3 = TaskResult(data_2, data_2, data_1)
	task_result

# Generated at 2022-06-24 19:26:38.608303
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_1 = '.H\x0bdSFZ^\x0cfOR#a6>ZnA'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    bool_1 = task_result_1.needs_debugger()


# Generated at 2022-06-24 19:26:44.634450
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'n'
    str_1 = 'alhaqs]+£z\x0b'
    str_2 = 'f~\x0e'
    str_3 = 'G\x0b'
    str_4 = 'b@4\x0cL\x0b\x0clB'
    dict_0 = {'H': str_4, 'e': str_0, 'l': str_2, 'o': str_1, 'W': str_3}
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    str_5 = 'B'
    str_6 = '!'

# Generated at 2022-06-24 19:26:48.078840
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = '\xc5\x18\x00\xaf\x00\xee\x00\x00\x00\x00\x00\x00\x00\x04'
    result = TaskResult(str_0, str_0, str_0)
    assert result.is_failed() == False


# Generated at 2022-06-24 19:26:52.179597
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '`pc\x0c6A\x0cbq'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_skipped()
