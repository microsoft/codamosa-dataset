

# Generated at 2022-06-24 19:17:56.690366
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult("", "", "")
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:18:00.137292
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_1 = '\x0ba\x0c'
    bytes_1 = b'\x0b'
    task_result_1 = TaskResult(bytes_1, str_1, bytes_1)
    assert task_result_1.needs_debugger(False) is False


# Generated at 2022-06-24 19:18:05.301991
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'f\x1f\x03\x10\x01\x0f\n\x1b^\x1c\x0fz\x0b'
    bytes_0 = b'\xd6\x14\x87\x8a\x1d\x13/\xcf\x0f\x9e\xd1\xe3'
    task_result_0 = TaskResult(bytes_0, str_0, bytes_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:18:15.302379
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-24 19:18:22.251593
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'n9\x0cezn(trF(vS1IK*'
    bytes_0 = b'^'
    task_result_0 = TaskResult(bytes_0, str_0, bytes_0)
    var_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:18:27.476035
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    host_0 = 'test_value_0'
    task_0 = 'test_value_1'
    return_data_0 = b'}'
    task_result_0 = TaskResult(host_0, task_0, return_data_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:18:35.483342
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = ',{k\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b@'
    bytes_0 = b'\x9f'
    task_result_0 = TaskResult(bytes_0, str_0, bytes_0)
    var_0 = task_result_0.is_skipped()
    assert var_0 == False


# Generated at 2022-06-24 19:18:37.994027
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    pattern_0 = b'\n\t'
    task_result_0 = TaskResult(b'\n', pattern_0, b';')
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:18:40.446131
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("in test_TaskResult_clean_copy")
    task_result_0 = TaskResult(str, str, dict)
    result = task_result_0.clean_copy()
    assert type(result) == TaskResult


# Generated at 2022-06-24 19:18:46.025928
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '\x0c'
    bytes_0 = b'\x8b\x0c\x90\xa3\x02\xba\xdb\x14\x9e\x9c'
    task_result_0 = TaskResult(bytes_0, str_0, bytes_0)
    var_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:06.628884
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    class var_2:
        class default:
            class __dict__:
                class get:
                    class return_value:
                        FAILED = False
                        UNREACHABLE = False
                        CHANGED = False
                        SKIPPED = False
    class var_3:
        def __init__(self, value):
            self.value = value
    class var_4:
        def __init__(self, name, value):
            self.name = name
            self.value = value
    class var_5:
        def __init__(self):
            self._task_fields = var_2
            self._task = var_3({'debugger': 'on_failed'})
    class var_1:
        def get(self, name):
            return var_4(name,True)
    C.TASK

# Generated at 2022-06-24 19:19:07.897838
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('in test_TaskResult_is_failed')


# Generated at 2022-06-24 19:19:12.729051
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'TaskResult.is_failed(): '
    str_1 = 'Done'
    str_2 = '+'
    var_0 = print(str_0 + str_1 + str_2)


# Generated at 2022-06-24 19:19:24.211127
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    dict_0 = dict()
    dict_1 = dict()
    dict_1['results'] = dict_0
    dict_2 = dict()
    dict_2['skipped'] = True
    dict_2['failed'] = True
    dict_1.update(dict_2)
    dict_1.update(dict_2)
    dict_3 = dict()
    dict_3['_task'] = dict_1
    dict_3['_host'] = dict_1
    dict_3['task_fields'] = dict_1
    dict_1 = dict()
    dict_2 = dict()
    dict_2['skipped'] = True
    dict_2['failed'] = False
    dict_1.update(dict_2)
    dict_1.update(dict_2)
    # var_0 = dict()


# Generated at 2022-06-24 19:19:30.724731
# Unit test for method needs_debugger of class TaskResult

# Generated at 2022-06-24 19:19:32.629780
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print ("\nIn Test: test_TaskResult_clean_copy")
    test_case_0()
    print ("\nTest Complete: test_TaskResult_clean_copy")

test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:19:35.322531
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

# Global variable __all__ will be used to import only needed functions
__all__ = ['test_TaskResult_clean_copy']

# Generated at 2022-06-24 19:19:37.355431
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('in test_TaskResult_is_failed')
    test_result = TaskResult(None, None, {'result': {'failed': False}})
    result = test_result.is_failed()
    print(result)


# Generated at 2022-06-24 19:19:39.696822
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'in test_TaskResult_is_skipped'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:19:47.858048
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print('in test_TaskResult_clean_copy')
    dict_0 = dict()
    var_0 = 'test_TaskResult_clean_copy'
    dict_0['name'] = var_0
    dict_0['command'] = var_0
    dict_0['changed'] = False
    dict_0['start'] = var_0
    dict_0['invocation'] = dict()
    dict_0['invocation']['module_args'] = dict()
    dict_0['invocation']['module_args']['msg'] = var_0
    dict_0['result'] = dict()
    dict_0['result']['stderr'] = var_0
    dict_0['result']['stdout'] = var_0
    dict_0['result']['stdout_lines'] = list

# Generated at 2022-06-24 19:20:01.224558
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'in test_TaskResult_is_skipped'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:20:06.354425
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    '''
    is_skipped().
    '''
    str_0 = 'in test_TaskResult_is_skipped'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:20:07.645188
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_1 = 'in test_TaskResult_clean_copy'
    var_1 = print(str_1)

# Generated at 2022-06-24 19:20:19.016421
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # -------------------------------------------
    # initialization
    str_0 = 'in is_skipped of TaskResult'
    var_0 = print(str_0)

    #print(str_0)
    # -------------------------------------------

    # -------------------------------------------
    # funtion body
    #print(str_0)
    #print(var_0)
    var_1 = type(var_0)
    #print(var_1)

    str_1 = 'this is a string'
    var_0 = str_1

    var_2 = type(var_0)
    #print(var_2)
    # -------------------------------------------

    # -------------------------------------------
    # finalization
    #print(str_0)
    #print(var_0)
    # -------------------------------------------


# Generated at 2022-06-24 19:20:27.039478
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print('in TaskResult_is_skipped')

# Generated at 2022-06-24 19:20:35.112849
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-24 19:20:39.627086
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'in test_TaskResult_is_skipped'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:20:41.714190
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'in test_TaskResult_is_skipped'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:20:43.464414
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
  t = TaskResult(3, 1, 2)
  t.clean_copy()


# Generated at 2022-06-24 19:20:44.803672
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    # Test case 0
    test_case_0()



# Generated at 2022-06-24 19:20:55.895214
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'in test_TaskResult_needs_debugger'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:21:03.610778
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # begin tests
    test_TaskResult_clean_copy_0()
    test_TaskResult_clean_copy_1()
    test_TaskResult_clean_copy_2()
    test_TaskResult_clean_copy_3()
    test_TaskResult_clean_copy_4()
    test_TaskResult_clean_copy_5()
    test_TaskResult_clean_copy_6()
    test_TaskResult_clean_copy_7()
    test_TaskResult_clean_copy_8()
    test_TaskResult_clean_copy_9()
    test_TaskResult_clean_copy_10()
    test_TaskResult_clean_copy_11()
    test_TaskResult_clean_copy_12()
    test_TaskResult_clean_copy_13()
    test_TaskResult_clean_copy_14()

# Generated at 2022-06-24 19:21:11.429174
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import unittest

    test_0 = unittest.TestCase('__init__')
    test_0.maxDiff = None

    try:
        test_0.assertEqual(test_case_0(), None)
    except Exception as e:
        test_0.assertEqual(e.args[0], 'TaskResult.clean_copy is not implemented')

    # test_TaskResult_clean_copy ends here

if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:19.584978
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    
    # var_0 = TaskResult(var_1, var_2, var_3)
    # var_0.clean_copy(var_4)
    # assert var_0.value == var_1
    ## Test 0
    # test if the str_0 variable has the value 'in test_TaskResult_clean_copy'
    str_0 = 'in test_TaskResult_clean_copy'
    var_1 = print(str_0)
    var_1 = len(str_0)
    # assert var_0.value == var_1
    if var_1 == 16:
        print('test 0: True')
        return True
    else:
        print('test 0: False')
        return False


# Generated at 2022-06-24 19:21:26.633919
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_9 = [u'skipped', u'failed', u'unreachable']
    var_10 = {'skipped': False, 'failed': False, 'unreachable': False}
    var_11 = print(u'skipped')
    var_12 = print(u'failed')
    var_13 = print(u'unreachable')
    var_14 = {'skipped': True}
    var_15 = var_14
    var_16 = var_15
    var_17 = print(u'skipped')
    var_18 = print(u'failed')
    var_19 = print(u'unreachable')
    var_20 = {'skipped': True, 'failed': False, 'unreachable': False}
    var_21 = var_20
    var_22 = var_21


# Generated at 2022-06-24 19:21:29.683160
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    def test_TaskResult_needs_debugger_case_0():
        str_0 = 'in test_TaskResult_needs_debugger case 0'
        var_0 = print(str_0)


# Generated at 2022-06-24 19:21:40.415210
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    print('Test: test_TaskResult_needs_debugger')
    str_0 = '>>> task_fields = {"debugger": "never"}'
    var_0 = print(str_0)
    TaskResult.needs_debugger(task_fields = {'debugger': 'never'})
    str_1 = '>>> task_fields = {"debugger": "always"}'
    var_0 = print(str_1)
    TaskResult.needs_debugger(task_fields = {'debugger': 'always'})
    str_2 = '>>> task_fields = {"debugger": "on_failed"}'
    var_0 = print(str_2)
    TaskResult.needs_debugger(task_fields = {'debugger': 'on_failed'})

# Generated at 2022-06-24 19:21:46.566001
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print('in test_TaskResult_is_skipped')
    a = TaskResult(None, None, None)
    a_expect = False
    assert a.is_skipped() == a_expect
    print('PASSED: test_TaskResult_is_skipped')


# Generated at 2022-06-24 19:21:53.953274
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    global _CHECK_KEY_
    _CHECK_KEY_ = False

    global _DEBUGGER_

    _DEBUGGER_ = 'on_failed'

    global _RESULT_

    _RESULT_ = {'failed': True}

    global _TASK_FIELDS_

    _TASK_FIELDS_ = {'debugger': 'on_failed'}

    global _IGNORE_ERRORS_

    _IGNORE_ERRORS_ = False

    var_1 = {'debugger': _DEBUGGER_,
              'ignore_errors': _IGNORE_ERRORS_}

    var_2 = TaskResult(None, None, _RESULT_, var_1)

    if _TASK_FIELDS_.get('debugger') in ('on_failed',
                                         'always'):
        var_3

# Generated at 2022-06-24 19:21:56.757140
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = TaskResult(host, task, return_data, task_fields)
    var_0 = result.is_skipped()
# Tests if the method is_skipped returns the expected boolean result

# Generated at 2022-06-24 19:22:13.640059
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    # Init vars
    str_0 = 'in TaskResult_is_failed'
    var_0 = print(str_0)

    # Create object TaskResult
    var_1 = TaskResult()

    # Call method is_failed of object TaskResult
    var_2 = var_1.is_failed()

    # Source: https://github.com/ansible/ansible/blob/devel/lib/ansible/debug.py
    # Type: ansible/debug
    # Context: ansible/debug
    # Page: https://github.com/ansible/ansible/blob/devel/lib/ansible/debug.py
    # Name: ansible/debug.py
    str_1 = 'in debugger_on'
    var_3 = print(str_1)
    str_2 = 'raising'


# Generated at 2022-06-24 19:22:21.391721
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Run method to test with inputs and expected results
    str_0 = 'in test_TaskResult_clean_copy'
    var_0 = print(str_0)

if __name__ == "__main__":
    # Setup test cases to run
    test_cases = [
        test_case_0,
        test_TaskResult_needs_debugger
    ]

    # Run all test cases
    print("Running test cases:")
    for test_case in test_cases:
        test_case()
    print("Completed all test cases")

# Generated at 2022-06-24 19:22:23.011061
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'in test_TaskResult_is_failed'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:22:29.005231
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    def mocked_dict_copy(self):
        return dict()
    taskresult_obj = TaskResult(None, None, None)
    taskresult_obj._result = {'skipped': True}
    assert taskresult_obj.is_skipped()
    taskresult_obj._result = {'skipped': False}
    assert not taskresult_obj.is_skipped()
    taskresult_obj._result = {'results': [dict(), dict()]}
    assert not taskresult_obj.is_skipped()
    taskresult_obj._result = {'results': [{'skipped': True}, {'skipped': True}]}
    assert taskresult_obj.is_skipped()


# Generated at 2022-06-24 19:22:38.122573
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    dict_0 = dict({'invocation': {'module_name': 'command', 'module_args': 'id', 'module_complex_args': {'creates': '/etc/sudoers.d/ansible-sudoers', '_original_file': '/etc/sudoers.d/ansible-sudoers', 'removes': None, '_uses_shell': True, '_raw_params': 'id', '_uses_delegate_to': False, 'chdir': None, 'executable': None, '_raw_args': 'id', 'warn': True, '_ansible_check_mode': False, '_ansible_diff': True}}} ,)
    str_1 = 'bogus'

# Generated at 2022-06-24 19:22:39.305428
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_input = 'This is a test input string'
    result = test_input
    assert True


# Generated at 2022-06-24 19:22:39.840295
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    pass

# Generated at 2022-06-24 19:22:41.751608
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    t = TaskResult(None, None, {}, {})
    assert not t.needs_debugger()


# Generated at 2022-06-24 19:22:44.030555
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'in test_TaskResult_is_failed'
    var_0 = print(str_0)



# Generated at 2022-06-24 19:22:54.689604
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-24 19:23:03.520298
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b';'
    task_result_0 = TaskRe

# Generated at 2022-06-24 19:23:15.216549
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'#'
    bytes_1 = b',Q'
    bytes_2 = b'=y'
    bytes_3 = b'03'
    bytes_4 = b'2Q'
    bytes_5 = b'<\x17'
    bytes_6 = b'@\x0f'
    bytes_7 = b'D\x1f'
    bytes_8 = b'I\x1a'
    bytes_9 = b'P\x12'
    bytes_10 = b'V\x0b'
    bytes_11 = b'\\\x07'
    bytes_12 = b'b\x17'
    bytes_13 = b'h\x1a'
    bytes_14 = b'm\x0f'
    bytes_15 = b'u\n'


# Generated at 2022-06-24 19:23:20.398850
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    test_TaskResult_is_failed_ret_0 = task_result_0.is_failed()
    assert false == test_TaskResult_is_failed_ret_0


# Generated at 2022-06-24 19:23:28.401648
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible_collections.nsbl.ansible_modules.plugins.modules.command import ActionModule as CommandActionModule

# Generated at 2022-06-24 19:23:38.389100
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'test string'
    bytes_1 = b'LM\xe2\x80\xb2\xd4\x1d\x15\xe6\x9f\xba\x04\x1a\x80\xe0\x7f\xaa\xb1\xc9)\xd3\x0c\x1d\x86\x8e\xbd'
    bytes_2 = b'set_fact'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = bytes_0
    dict_1['ignore_errors'] = False
    dict_1['register'] = bytes_0
    dict_1['module_setup'] = False
    dict_1['module_name'] = bytes_0
    dict_1['action'] = bytes_2


# Generated at 2022-06-24 19:23:40.802120
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()


# unit tests
if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:23:46.727872
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    result = TaskResult(None, None, b';')
    result._result = {
        'results': [
            {
                'skipped': False,
                'failed': False,
                'invocation': {
                },
                'warnings': [],
                'changed': False,
                '_ansible_parsed': True
            },
            {
                'skipped': False,
                'failed': True,
                'invocation': {
                },
                'warnings': [],
                'changed': False,
                '_ansible_parsed': True
            }
        ],
        '_ansible_parsed': True
    }
    assert(result.is_failed() == True)


# Generated at 2022-06-24 19:23:57.407490
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    assert not task_result_0.is_failed()
    task_result_0._result = dict(((b'\xff\xef\xbd\xbd', b'closed')))
    assert task_result_0.is_failed()
    task_result_0._result = dict(((b'module_stdout', b'')))
    assert not task_result_0.is_failed()
    task_result_0._result = dict(((b'module_stderr', b'')))
    assert not task_result_0.is_failed()

# Generated at 2022-06-24 19:24:05.328305
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    from ansible.playbook.task import Task

    bytes_0 = b'w\xef\xdb\xf5'

# Generated at 2022-06-24 19:24:08.688909
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x92\x8a'
    TaskResult_object = TaskResult(bytes_0)
    bool_0 = TaskResult_object.needs_debugger()
    print(bool_0)


# Generated at 2022-06-24 19:24:24.417077
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True


# Generated at 2022-06-24 19:24:29.509271
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_1 = TaskResult(None, None, None)
    result = task_result_1.is_failed()


# Generated at 2022-06-24 19:24:38.785327
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'F,'
    bytes_1 = b'{/'
    bytes_2 = b'\nN'
    bytes_3 = b';?'
    bytes_4 = b'!'
    bytes_5 = b'k|'
    bytes_6 = b'\x0f'
    bytes_7 = b'\x0c'
    bytes_8 = b'\x0f'
    bytes_9 = b'\x0f'
    result_1 = {'T': {'0': bytes_7, '1': bytes_8, '2': bytes_9}}
    task_result_0 = TaskResult(bytes_0, bytes_1, bytes_2)
    task_result_0._result = result_1
    assert task_result_0.is_skipped() == False
   

# Generated at 2022-06-24 19:24:42.118262
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    ignore_errors = False
    task_result_0 = TaskResult(None, None, None)
    task_result_1 = TaskResult(None, None, None)
    task_result_0.needs_debugger(ignore_errors)
    task_result_1.needs_debugger(ignore_errors)
    return

# Generated at 2022-06-24 19:24:46.070732
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    """Test is_failed"""
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)

    # Test is_failed with negative data
    assert task_result_0.is_failed() == False



# Generated at 2022-06-24 19:24:49.182652
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'P'
    TaskResult_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    assert TaskResult_0.is_failed() == False


# Generated at 2022-06-24 19:24:51.832767
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    assert(task_result_0.clean_copy() != None)

# Generated at 2022-06-24 19:24:52.736526
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_case_0()

# Generated at 2022-06-24 19:24:56.463221
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    result_0 = task_result_0.needs_debugger(False)
    assert(type(result_0) == bool)


# Generated at 2022-06-24 19:25:04.659695
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b';'
    bytes_1 = b'p>'
    bytes_2 = b'(F'
    bytes_3 = b'[-'
    bytes_4 = b'\t'
    bytes_5 = b'#'
    bytes_6 = b'I'
    bytes_7 = b'\x0c'
    bytes_8 = b'{'
    bytes_9 = b')'
    bytes_10 = b'7'
    bytes_11 = b'<'
    bytes_12 = b'l'
    bytes_13 = b'j'
    bytes_14 = b'5'
    bytes_15 = b'X'
    bytes_16 = b'\x0f'
    bytes_17 = b'b'
    bytes_18 = b'C'
    bytes

# Generated at 2022-06-24 19:25:46.465977
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True


# Generated at 2022-06-24 19:25:48.385654
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    result = task_result_0.is_skipped()
    assert result is False


# Generated at 2022-06-24 19:25:49.159592
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # No exception expected.
    test_case_0()

# Generated at 2022-06-24 19:25:55.904637
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_1 = b'*'
    bytes_2 = b'V'
    bytes_3 = b'NS'
    bytes_4 = b'Z\x08'
    bytes_5 = b'C\x08l'
    int_0 = 3
    bytes_6 = b'I\x1c\x08\x1d\x0c'
    int_1 = 6
    bytes_7 = b'N+\x08.\x0c'
    int_2 = 9
    bytes_8 = b'$\x07M'
    int_3 = 12
    bytes_9 = b'2\x07'
    int_4 = 15
    bytes_10 = b'U\x07\\'
    int_5 = 18
    bytes_11 = b'N\x08\\'
   

# Generated at 2022-06-24 19:25:57.125352
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # TODO: it needs to be tested
    assert True


# Generated at 2022-06-24 19:26:00.440999
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    task_result_1 = TaskResult(bytes_0, bytes_0, bytes_0)
    result = task_result_1.is_skipped()


# Generated at 2022-06-24 19:26:08.139881
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'(\xf3\xe3'
    dict_0 = dict(__name__='\x9e\x8a\x80\x96\x98\xae\xb8\x92\x9d\xb9\x93\x8e\xba\x82\x9b\xb5\xb1')
    str_0 = dict_0['__name__']
    dict_1 = dict()
    dict_1['invocation'] = None
    dict_1['name'] = 'debug'
    dict_1['results'] = []
    dict_1['_ansible_verbose_always'] = True
    dict_1['_ansible_no_log'] = False
    task_result_0 = TaskResult(bytes_0, bytes_0, dict_1)
    bool_0

# Generated at 2022-06-24 19:26:16.107337
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    """
    # python -m pytest tests/unit/utils/taskresult_test.py::test_TaskResult_is_skipped
    """

    bytes_0 = b'\x0f\x04\xa7\x16\x10\x91\xbc\xa0\x9d\xa5\xf1\x83\xeb\xff'

    task_result_0 = TaskResult(
        bytes_0,
        bytes_0,
        bytes_0,
    )

    task_result_0.is_skipped()



# Generated at 2022-06-24 19:26:19.371613
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b';'
    task_result_0 = TaskResult(bytes_0, bytes_0, bytes_0)
    result_0 = task_result_0.is_skipped()
    assert result_0 == False


# Generated at 2022-06-24 19:26:22.378726
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult("host_0", "task_0", {"_ansible_parsed": True, "invocation": "invocation_0"})
    assert task_result_0._check_key("failed") == False
