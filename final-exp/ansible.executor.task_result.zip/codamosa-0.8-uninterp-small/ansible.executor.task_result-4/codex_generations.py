

# Generated at 2022-06-24 19:17:58.638053
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '"`9}Rz"{=+'
    float_0 = 16.0
    list_0 = ['d', '3', 'H', 'n']
    list_1 = ['C', '4', ':', '^']
    list_2 = list(range(26))
    dict_0 = {float_0: list_2, str_0: list_1}
    task_result_0 = TaskResult(str_0, float_0, dict_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:18:05.740222
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = "v92'}(p!\\\rG\taeoagC"
    float_0 = 3244.0
    dict_0 = {float_0: str_0, str_0: float_0}
    task_result_0 = TaskResult(str_0, float_0, dict_0)
    str_1 = "v92'}(p!\\\rG\taeoagC"
    float_1 = 3244.0
    dict_1 = {float_1: str_1, str_1: float_1}
    task_result_1 = TaskResult(str_1, float_1, dict_1)
    task_result_2 = task_result_1.clean_copy()
    assert task_result_2._result == dict_1
    task_result_

# Generated at 2022-06-24 19:18:12.383529
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = "v92'}(p!\\\rG\taeoagC"
    float_0 = 3244.0
    dict_0 = {float_0: str_0, str_0: float_0}
    task_result_0 = TaskResult(str_0, float_0, dict_0)
    assert task_result_0.is_failed()


# Generated at 2022-06-24 19:18:14.415592
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    test_case_0()


# Generated at 2022-06-24 19:18:20.211267
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = "V\x1b\x7fI\x16\x7f"
    str_1 = "Y\x1f\x1eD\x1f\x0e"
    str_2 = "2"
    str_3 = "c\x038\x10-\x04"
    str_4 = "e\x0e#\x1a=\x1b"
    str_5 = "H"
    float_0 = 2530.0
    float_1 = 7682.0
    float_2 = 5131.0
    float_3 = 2993.0
    float_4 = 8507.0
    float_5 = 783.0
    float_6 = 6696.0
    float_7 = 3747.0
    float_8 = 5847

# Generated at 2022-06-24 19:18:21.121510
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    test_case_0()


# Generated at 2022-06-24 19:18:28.730481
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = "v92'}(p!\\\rG\taeoagC"
    float_0 = 3244.0
    dict_0 = {float_0: str_0, str_0: float_0}
    task_result_0 = TaskResult(str_0, float_0, dict_0)
    result = task_result_0.clean_copy()
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:18:35.905953
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = "v92'}(p!\\\rG\taeoagC"
    float_0 = 3244.0
    dict_0 = {float_0: str_0, str_0: float_0}
    task_result_0 = TaskResult(str_0, float_0, dict_0)
    task_result_0.needs_debugger(float_0)

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:18:40.541727
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = "v92'}(p!\\\rG\taeoagC"
    float_0 = 3244.0
    dict_0 = {float_0: str_0, str_0: float_0}
    task_result_0 = TaskResult(str_0, float_0, dict_0)

    # Test case for the method is_failed of class TaskResult
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:18:48.897107
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = "tN4-J!N\tG\rR\x0e"
    int_0 = 7921
    dict_0 = {str_0: int_0, int_0: str_0}
    task_result_0 = TaskResult(str_0, int_0, dict_0)
    task_result_1 = task_result_0.clean_copy()
    task_result_1.clean_copy()
    float_0 = 4239.0
    int_1 = 83
    dict_1 = {float_0: int_1, str_0: float_0, int_1: str_0}
    task_result_2 = TaskResult(str_0, int_0, dict_1, task_result_1)

# Generated at 2022-06-24 19:19:02.608865
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = '\x0c`\x03\x15\x11\x14\x00\x12+'
    str_1 = '\x0c`\x03\x15\x11\x14\x00\x12/'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result_bool = task_result_0.is_skipped()
    assert result_bool == False
    task_result_1 = TaskResult(str_0, str_0, str_0)
    result_bool = task_result_1.is_skipped()
    assert result_bool == False
    task_result_2 = TaskResult(str_0, str_1, str_0)
    result_bool = task_result_2.is_skipped()

# Generated at 2022-06-24 19:19:04.841889
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TODO: Nothing is tested here but we should
    #       - Create TaskResult with all attributes
    #       - then test TaskResult.clean_copy()
    #       This will be fixed in #77684
    pass



# Generated at 2022-06-24 19:19:06.668202
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:19:17.253176
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'z\x0cfQv\x08\x14\x1e\x0f2\x23\x1c\x1f\x1d'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.task_fields = {'debugger': 'on_failed'}
    str_1 = 'k\x03\x05\x1b\x1b\x0f\x12\x02\x13\x18\x07\x03\x1b\x1a\x07'
    ret = task_result_0.needs_debugger(str_1)
    assert(ret)


# Generated at 2022-06-24 19:19:20.416480
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1 is not None


# Generated at 2022-06-24 19:19:23.512412
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    str_0 = '|\t>Q\t-'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    # test 1
    x = task_result_0.needs_debugger()
    assert x == False


# Generated at 2022-06-24 19:19:26.471997
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '^\x1c\x1b\x04\x0cP\x11?'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result = task_result_0.clean_copy()
    assert result is not None



# Generated at 2022-06-24 19:19:34.067682
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    str_1 = '/\x7f\x19\x7f\x03?\x7f\x04\x7f\x02\x7f\x01\x7f'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = TaskResult(str_0, str_0, str_0)
    task_result_1._task_fields = dict()
    task_result_1._task_fields.setdefault('name', str_0)
    bool_0 = task_result_1.needs_debugger()
    task_result_2 = TaskResult(str_0, str_0, str_0)
    task_result_2._task_

# Generated at 2022-06-24 19:19:44.724392
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    # This is testing the code path for pseudo-action
    # when loop is done
    test_result_0 = {'results':[{'unreachable': False}]}
    task_result_1 = TaskResult(None, None, test_result_0)
    assert not task_result_1.is_skipped()

    test_result_1 = {'results':[{'skipped': True}]}
    task_result_2 = TaskResult(None, None, test_result_1)
    assert task_result_2.is_skipped()

    test_result_2 = {'results':[{'failed': False, 'skipped': False}]}
    task_result_3 = TaskResult(None, None, test_result_2)
    assert not task_result_3.is_skipped()

    test_

# Generated at 2022-06-24 19:19:49.681633
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult('', '', {'changed': False})
    assert not task_result_0.is_skipped()
    task_result_1 = TaskResult('', '', {'results': [{'skipped': True}]})
    assert task_result_1.is_skipped()
    task_result_2 = TaskResult('', '', {'results': [{'skipped': False}]})
    assert not task_result_2.is_skipped()
    task_result_3 = TaskResult('', '', '{}')
    assert task_result_3.is_skipped()


# Generated at 2022-06-24 19:20:02.031192
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_1 = 'wcG'
    str_2 = '3]Ub'
    task_result_1 = TaskResult(str_1, str_2, str_2)
    bool_1 = task_result_1.needs_debugger(str_2)
    print("TEST RUNNER: The returned variable is of type {}".format(type(bool_1)))
    print("TEST RUNNER: The returned variable's value is {}".format(bool_1))

# Generated at 2022-06-24 19:20:07.031287
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert not task_result_0.needs_debugger()


# Generated at 2022-06-24 19:20:12.093044
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'H\x0f\x1a\\\x1e\x1b"'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:15.711955
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.clean_copy()



# Generated at 2022-06-24 19:20:22.261058
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    data = {
        'ansible_facts': {
            'a': '1',
            'ansible_internal_var': '2',
        },
    }
    tr = TaskResult('Zf\x0boa?+GmcIFj1', 'Zf\x0boa?+GmcIFj1', data)
    assert tr.clean_copy()._result['ansible_facts']['a'] == '1'
    assert 'ansible_internal_var' not in tr.clean_copy()._result['ansible_facts']

# Generated at 2022-06-24 19:20:30.694927
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\t<r>\r\x1e\x03\x16\x11\x14\n'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result_0 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:20:35.561688
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '\x1b'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    result = task_result_0.clean_copy()


# Generated at 2022-06-24 19:20:42.199571
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = ''
    str_1 = '^kf\x0c\x13\x04\x10\x0c'
    str_2 = '\x16\x17\x00\x0b\x08\x00\x0c\x12\x1f\x0b'
    str_3 = '\x04\x10\x0c\x14'

    task_result_0 = TaskResult(str_0, str_1, str_2)
    task_result_1 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:20:45.942937
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    test_bool_0 = False
    assert task_result_0.needs_debugger(test_bool_0) == False
    test_bool_1 = True
    assert task_result_0.needs_debugger(test_bool_1) == False


# Generated at 2022-06-24 19:20:48.299283
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print('test_TaskResult_clean_copy ...')
    test_case_0()
    print('test_TaskResult_clean_copy ok')


# Generated at 2022-06-24 19:21:01.179561
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'OJ}Tl'
    str_1 = '8W[\x7fQ'

    task_result_0 = TaskResult(str_0, str_0, str_1)
    task_result_0.needs_debugger(True)


if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.module_utils.common.http import test_case_0

    test_case_0()

# Generated at 2022-06-24 19:21:04.254500
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'z*'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    glob = True
    test_value = task_result_0.needs_debugger(glob)
    assert test_value


# Generated at 2022-06-24 19:21:10.910814
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Declaration of local variable result
    expected_result = 0

    # Declaration of local variable task_result
    task_result = TaskResult('host', 'task', 'result')

    # Call method needs_debugger of class TaskResult with argument global_enabled=0
    actual_result = task_result.needs_debugger(0)

    # Compare local variable actual_result with expected variable expected_result
    assert actual_result == expected_result

# Generated at 2022-06-24 19:21:13.241393
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    task_result_0 = TaskResult('host', Task(), '{}')
    task_result_1 = task_result_0.clean_copy()
    assert task_result_0._task is task_result_1._task
    assert task_result_0._host is task_result_1._host
    assert task_result_0._task_fields is task_result_1._task_fields



# Generated at 2022-06-24 19:21:21.743346
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.runner import Runner
    import json

    # Create fake modules
    fake_modules = dict()
    fake_modules[u'ping'] = {'module': 'ping',
                             'no_log': False,
                             'args': {
                                 'data': u'pong'},
                             'changed': False,
                             '__ansible_module__': 'ping'
                             }
    fake_modules[u'fail'] = {'module': 'fail',
                             'no_log': False,
                             'args': {},
                             '__ansible_module__': 'fail'
                             }
    fake

# Generated at 2022-06-24 19:21:31.824542
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    
    # Test cases

    # 1
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    test_TaskResult_needs_debugger_1 = task_result_0.needs_debugger()

    # 2
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    test_TaskResult_needs_debugger_2 = task_result_0.needs_debugger(True)


# Generated at 2022-06-24 19:21:36.198864
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'l\x1b'
    arg_0 = TaskResult(str_0, str_0, str_0)
    assert arg_0.needs_debugger(False) == False , "TaskResult.needs_debugger(False) should return False"
# End of unit tests

# Generated at 2022-06-24 19:21:40.123220
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    bool_0 = False

    task_result_0 = TaskResult(str_0, str_0, str_0)

    assert task_result_0.needs_debugger(bool_0) == 0


# Generated at 2022-06-24 19:21:43.482813
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger()

    assert(task_result_0.needs_debugger() == False)


# Generated at 2022-06-24 19:21:51.918746
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    class my_object(object):
        pass

    task_result_1 = TaskResult("localhost", "my_task", {})
    task_result_2 = TaskResult("localhost", "my_task", {})
    task_result_3 = TaskResult("localhost", "my_task", {})
    task_result_4 = TaskResult("localhost", "my_task", {})
    task_result_5 = TaskResult("localhost", "my_task", {})
    task_result_6 = TaskResult("localhost", "my_task", {})
    task_result_7 = TaskResult("localhost", "my_task", {})
    task_result_8 = TaskResult("localhost", "my_task", {})
    task_result_9 = TaskResult("localhost", "my_task", {})

# Generated at 2022-06-24 19:22:08.811510
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    result = {"changed": True, "msg": "All items completed", "results": [{"_ansible_no_log": False, "changed": False,
                                                                           "item": "10.28.27.125", "skip_reason": "Conditional check failed"},
                                                                          {"_ansible_no_log": False, "changed": True, "item": "10.28.27.123",
                                                                           "skip_reason": "Conditional check failed"},
                                                                          {"_ansible_no_log": False, "changed": False,
                                                                           "item": "10.28.27.124", "skip_reason": "Conditional check failed"}]}
    task_result_1 = TaskResult("host", "task", result)
    # should see something like the following

# Generated at 2022-06-24 19:22:19.237947
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0._result = {'changed': False, 'failed': False, 'skipped': False}
    task_result_0._task_fields = {'name': 'set_fact', 'ignore_errors': True}
    task_result_0._task = task_result_0._result.get('_ansible_item_label')
    boolean_0 = task_result_0.needs_debugger()
    assert not boolean_0


# Generated at 2022-06-24 19:22:24.302914
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:22:33.513365
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Clean tasks should not be checked when DEBUG_TASKs is set
    assert not TaskResult('dummy', 'dummy', 'dummy').needs_debugger(globally_enabled=True)
    assert not TaskResult('dummy', 'dummy', 'dummy').needs_debugger(globally_enabled=False)
    # When DEBUG_TASKs is set
    assert TaskResult('dummy', 'dummy', {'failed': True}).needs_debugger(globally_enabled=True)
    assert TaskResult('dummy', 'dummy', {'failed': True}).needs_debugger(globally_enabled=True)
    assert TaskResult('dummy', 'dummy', {'unreachable': True}).needs_debugger(globally_enabled=True)

# Generated at 2022-06-24 19:22:37.815805
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Create instance of class with params
    task_result_0 = TaskResult('blabla', 'foo', 'bar')
    # Check result of method clean_copy with params
    assert task_result_0.clean_copy()


if __name__ == '__main__':
    # Run unit tests
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:22:40.210737
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('Zf\x0boa?+GmcIFj1', 'Zf\x0boa?+GmcIFj1', 'Zf\x0boa?+GmcIFj1')
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:22:40.845458
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass


# Generated at 2022-06-24 19:22:48.003397
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'z\x04a\x0b?o\x19\n#\x00\x1f\x13\x1a\x1d\x00\x17\x0e:\x06g\x1a\x17\x0c\x0c'
    bool_0 = True
    task_0 = TaskResult(str_0, str_0, str_0)
    bool_1 = task_0.needs_debugger(bool_0)
    assert not bool_1


# Generated at 2022-06-24 19:22:52.458619
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:22:57.813306
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import random

    # Create a random bool value for globally_enabled and calls needs_debugger
    for x in range(100):
        globally_enabled = bool(random.randint(0, 1))
        result = test_TaskResult_needs_debugger_sub(globally_enabled)
        assert result is not None
        assert result is False


# Sub method to test needs_debugger

# Generated at 2022-06-24 19:23:12.277157
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    arg0 = 'Zf\x0boa?+GmcIFj1'
    arg1 = 'Zf\x0boa?+GmcIFj1'
    arg2 = 'Zf\x0boa?+GmcIFj1'
    arg3 = 'Zf\x0boa?+GmcIFj1'
    obj0 = TaskResult(arg0, arg1, arg2, arg3)
    ret0 = obj0.is_failed()
    assert ret0 == False


# Generated at 2022-06-24 19:23:14.565710
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('task_result_0', 'task_result_0', 'task_result_0')
    task_result_1 = task_result_0.clean_copy()
# Test fails. 


# Generated at 2022-06-24 19:23:16.155506
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task = 'task'
    result = 'result'
    res = TaskResult(task, task, result)
    assert res.clean_copy() == result

# Generated at 2022-06-24 19:23:24.331152
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    str_1 = '-1\x01\x17\x1d]\x03\x1f\x0e\n'
    task_result_1 = TaskResult(str_1, str_1, str_1)
    result = task_result_0.clean_copy()
    assert result._task == str_0
    assert result._result == 'Zf\x0boa?+GmcIFj1'



# Generated at 2022-06-24 19:23:34.871748
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'd\x0e\x1c'
    str_1 = 'nK[\x18\x1d\x1c'
    str_2 = 'E\x10'
    str_3 = ',\x1a'
    str_4 = 'R\t\x1d\x0e?\x04'
    str_5 = 'T-.\x14\x0e?\x04'
    str_6 = 'K[\x18\x1d\x1c'
    iterator_0 = '\n'
    task_result_0 = TaskResult(str_6, str_6, {str_5: str_2, str_0: str_5, str_1: str_0, str_3: str_5, str_4: str_3})
   

# Generated at 2022-06-24 19:23:38.391180
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '\x1b\x0c\x03\x12'
    TaskResult_0 = TaskResult(str_0, str_0, str_0)

    assert TaskResult_0.needs_debugger() == False


# Generated at 2022-06-24 19:23:40.363596
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '+\x04\r\x06J\x0f'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:41.907914
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult('5O5Szv5', '_', 'lK0Y0N')
    assert task_result_0.is_failed() is False


# Generated at 2022-06-24 19:23:44.398668
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.needs_debugger(True)


# Generated at 2022-06-24 19:23:48.099324
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Reset the random seed, to get the same random values each time
    random.seed(0)

    # Generate random parameters
    bool_0 = bool(random.sample([False, True], 1)[0])

    # Call the method (avoiding debug output)
    with test_helper.capture_output() as (stdout, stderr):
        result_0 = TaskResult_0.needs_debugger(bool_0)
    C.module_response_output = None

    # Verify the result
    assert (result_0 == result_0)

# Generated at 2022-06-24 19:24:00.637858
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    bool_0 = False
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger(bool_0)
    assert bool_0 is False


# Generated at 2022-06-24 19:24:02.034690
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('Yf\x00]y,I', '[', {'_ansible_no_log': True})
    assert task_result_0.clean_copy() is not None



# Generated at 2022-06-24 19:24:03.121654
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass


# Generated at 2022-06-24 19:24:12.530310
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Test case where task_fields is nil.
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.needs_debugger() == False

    # Test case where task_fields is set.
    task_result_1 = TaskResult(str_0, str_0, str_0,
                               {'debugger': 'on_failed', 'ignore_errors': False})
    assert task_result_1.needs_debugger() == False
    task_result_2 = TaskResult(str_0, str_0, str_0,
                               {'debugger': 'on_failed', 'ignore_errors': True})
    assert task_result_2.needs_debugger()

# Generated at 2022-06-24 19:24:18.794604
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    str_1 = 'Yep, I did it'
    str_2 = 'Nope, I failed'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    # case 1
    task_result_0._task_fields = {'debugger': 'on_failed', 'ignore_errors': False}
    task_result_1 = TaskResult(str_0, str_0, str_1)
    assert task_result_1.needs_debugger() == False
    # case 2
    task_result_2 = TaskResult(str_0, str_0, str_2)
    assert task_result_2.needs_debugger() == True
    # case 3
    task_result_0._

# Generated at 2022-06-24 19:24:22.748975
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:24:27.385065
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Setup
    str_0 = '_task_fields'
    dict_0 = dict()
    dict_0['name'] = 'test_task'

    # Exercise
    task_result_0 = TaskResult(str_0, str_0, str_0, dict_0)

    # Verify
    assert task_result_0.needs_debugger(False) == False


# Generated at 2022-06-24 19:24:36.348324
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    global debug_globally_enabled
    global TaskResult

    TaskResult = {
        'debug_globally_enabled': True,
        'task_fields': {'debugger': 'on_failed', 'ignore_errors': False},
        'result': {'failed': True}
    }
    assert TaskResult.needs_debugger() == True

    TaskResult = {
        'debug_globally_enabled': True,
        'task_fields': {'debugger': 'on_failed', 'ignore_errors': False},
        'result': {'failed': False}
    }
    assert TaskResult.needs_debugger() == False


# Generated at 2022-06-24 19:24:38.553824
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result = TaskResult("", "", "")
    assert task_result.is_failed() == False, "Failed to assert is_failed()"


# Generated at 2022-06-24 19:24:41.680908
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    int_0 = 0
    task_result_0.needs_debugger(int_0)

# Generated at 2022-06-24 19:24:57.884337
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.clean_copy() is not None
    str_1 = 'YW\x0c\x0e\x0bqm@Z#\x00mR\x0b\x0bP!\x00'
    task_result_0 = TaskResult(str_1, str_1, str_1)
    assert task_result_0.clean_copy() is not None
    str_2 = 'OYw\x0b\x0b\x0cd"\x00\x0b\'1\x00\x00\x00>'

# Generated at 2022-06-24 19:25:01.135217
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:25:11.629690
# Unit test for method needs_debugger of class TaskResult

# Generated at 2022-06-24 19:25:20.417986
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = '+C\x0c\x7f'
    str_1 = '\x19>\x7f\\m\x13'
    str_2 = '\x15{2\x15\x16\x1c'
    str_3 = '-'
    str_4 = 'p\t\x0b\x15\x18'
    list_0 = [str_1, str_1, str_0, str_4, str_4, str_4, str_4]
    str_5 = 'e'
    dict_0 = {str_2: str_2, str_0: str_1}
    dict_1 = {str_5: dict_0, str_5: dict_0}

# Generated at 2022-06-24 19:25:23.205200
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    print("\n-- test_TaskResult_is_skipped --")
    result = {'results': [{'skipped': True}, {'skipped': True}, {'skipped': True}]}
    task_result = TaskResult('localhost', 'test_module', result)
    assert task_result.is_skipped() == True

# Generated at 2022-06-24 19:25:23.912292
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass



# Generated at 2022-06-24 19:25:26.344391
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'd\x4f\x7f\x9f\x04\x76\x19'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    task_result_1 = task_result_0.needs_debugger()
    assert task_result_1 == False


# Generated at 2022-06-24 19:25:31.953548
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    """Unit test to check needs_debugger method of class TaskResult"""
    
    # Create task_result_0
    _task_fields = {'ignore_errors': False, 'debugger': None}
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0, _task_fields)
    
    # Value of the expected output
    expected = False
    
    # Call the function under test to get the actual output
    actual = task_result_0.needs_debugger()
    
    assert actual == expected
    

# Generated at 2022-06-24 19:25:43.524109
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'd}$k30[\x08.Vd\x03\xa3\xa9\n\x04\x86'

# Generated at 2022-06-24 19:25:48.439350
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'y\x14\x08\x1a\x1c\x11|z\x0f\x17\x08\n\n\t'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    # Ensure clean_copy return type is TaskResult
    assert(isinstance(task_result_0.clean_copy(), TaskResult))


# Generated at 2022-06-24 19:26:11.534924
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    print('Start to test method needs_debugger of class TaskResult')
    print('Test case 0: ...')
    test_case_0()
    print('Test passed!')

# Program entrance
if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:26:21.479345
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = '_'
    str_1 = 'L'
    str_2 = 'h'
    str_3 = 'UwI\x0e1L\x07H'
    # Unit test for needs_debugger of class TaskResult
    task_result_0 = TaskResult(str_0, str_1, str_2)
    str_4 = 'd'
    str_5 = 'm'
    str_6 = 'K'
    str_7 = '.'
    str_8 = '.'
    str_9 = '.'
    str_10 = '.'
    str_11 = '.'
    str_12 = '.'
    str_13 = '.'
    str_14 = '.'
    str_15 = '.'
    str_16 = '.'
    str_17 = '.'

# Generated at 2022-06-24 19:26:30.473182
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    str_0 = '$z\x0f\x7f@\x0b\x02\x18A\x7fI\x02;V\x1c\x1ei'

# Generated at 2022-06-24 19:26:38.525488
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(str_0, str_0, str_0)
    str_1 = 'Zf\x0boa?+GmcIFj1'
    boolean_0 = task_result_0._task_fields.get(str_1)
    assert boolean_0 is False
    boolean_0 = task_result_0.needs_debugger()
    assert boolean_0 is False

if __name__ == "_main__":
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:26:41.099764
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)

    assert not task_result_0.needs_debugger()


# Generated at 2022-06-24 19:26:43.316855
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(str, str, str)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:26:45.534510
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # test cases
    # test_case_0()

    # Run all test cases
    print("Running test cases")
    test_case_0()
    print("Passed all test cases")

test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:26:52.181915
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult('l$(', '\x17\x06\x16\x1b\x1a', '\x1e\x1a\x15')
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:27:00.299751
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 19:27:05.557773
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger()
    assert bool_0 == False


# Generated at 2022-06-24 19:27:34.593927
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'J\x07E8V2W\x1eT\x0f'
    str_1 = 'C\x0cR\x1d\x1c\x1e\x1bN@\x1b'
    task_result_0 = TaskResult(str_0, str_1, str_0)
    result = task_result_0.clean_copy()
    print('Expected:', 'V8WQN')
    print('Actual  :', result)
    assert result == 'V8WQN'
    assert False

# Generated at 2022-06-24 19:27:41.117274
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'Zf\x0boa?+GmcIFj1'
    task_result_0 = TaskResult(str_0, str_0, str_0)
    bool_0 = task_result_0.needs_debugger()

