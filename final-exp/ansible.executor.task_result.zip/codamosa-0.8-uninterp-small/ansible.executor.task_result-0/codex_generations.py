

# Generated at 2022-06-24 19:17:51.938193
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # Call method needs_debugger of class TaskResult
    task_result_0.needs_debugger()


# Generated at 2022-06-24 19:17:57.927117
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    bool_1 = False
    assert task_result_0.needs_debugger(bool_1)


if __name__ == '__main__':
    test_TaskResult_needs_debugger()
    test_case_0()

# Generated at 2022-06-24 19:18:02.835171
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    result = task_result_0.clean_copy()
    assert(isinstance(result._result, dict))


# Generated at 2022-06-24 19:18:09.136717
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:18:14.519626
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    result = task_result_0.is_skipped()
    assert result == False


# Generated at 2022-06-24 19:18:19.974603
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Setup
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    # Testing
    assert task_result_0.is_failed() == False



# Generated at 2022-06-24 19:18:24.187931
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    output_0 = task_result_0.clean_copy()



# Generated at 2022-06-24 19:18:32.594543
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult('f\x0b\x07*', '\x02\x01\x1d\x16\xf5', '\x06\x0c\x12', '\x0c\x1d1\x068')
    task_result_1 = task_result_0.clean_copy()

    assert task_result_1._host=='f\x0b\x07*'
    assert task_result_1._task=='\x02\x01\x1d\x16\xf5'
    assert task_result_1._task_fields=='\x0c\x1d1\x068'

# Generated at 2022-06-24 19:18:38.851722
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # AssertionError: False != True : is_skipped
    assert task_result_0.is_skipped() == False

# Generated at 2022-06-24 19:18:45.811461
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert task_result_0.needs_debugger(True) == False


# Generated at 2022-06-24 19:18:55.057714
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TODO: construct test
    pass



# Generated at 2022-06-24 19:19:03.252969
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    dict_0 = dict()
    dict_0['invocation'] = dict()
    dict_0['invocation']['module_args'] = dict()
    dict_0['invocation']['module_args']['chdir'] = ''
    dict_0['invocation']['module_args']['creates'] = None
    dict_0['invocation']['module_args']['executable'] = None

# Generated at 2022-06-24 19:19:07.343301
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    test_case_0()


# Generated at 2022-06-24 19:19:15.286916
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\x93\xda'
    str_0 = '#\xbe@\x84\xfa)i.\xed\x8a\xb3\x1a\xc1\x87\x9f\x06\x99\x89\x0c3\xd3\xc1\x14'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)


# Generated at 2022-06-24 19:19:22.212364
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'\x00\x01\x00\x00\x00\x01\x00\x15\x00\x00\x00\x01\x00\x15\xa1\x01'
    str_0 = '{\x0c'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:19:29.279208
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\xda\xfe\x1b\x00\x93\xf2\x85\x0b;\xe2&@S\x1d\x05\x81\xdd\xa4\xa8\x99'
    str_0 = 'failed'
    str_1 = 'msg'
    str_2 = 'unreachable'
    str_3 = 'invocation'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_0._result = {
        str_1: str_0,
        str_2: str_0,
        str_3: str_3
    }
    task_result_0.clean_copy()

# Generated at 2022-06-24 19:19:34.387228
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    if task_result_0.is_skipped():
        exception_0 = AssertionError('expected False, but got True')
        raise exception_0


# Generated at 2022-06-24 19:19:40.407894
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # assert test



# Generated at 2022-06-24 19:19:42.561374
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # FIXME: test this method

    # FIXME: how to test bool(task_result_0._task_fields)?
    pass



# Generated at 2022-06-24 19:19:48.079557
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    result_bool_0 = task_result_0.is_failed()
    assert result_bool_0 == False


# Generated at 2022-06-24 19:19:58.210758
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    test_case_0()

if __name__ == "__main__":
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:20:05.058250
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'-\x16\xc2\x81\xf6\x1b\xc3\\\xe3\x16\x9b\xdb\xa4\xc4\x8f&\xed\xb7\xee\xf1'
    str_0 = '\n'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # Testing if the value of 'task_result_0.is_skipped' is equal to 'True'
    assert task_result_0.is_skipped() == True


# Generated at 2022-06-24 19:20:11.940673
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

# Generated at 2022-06-24 19:20:21.980732
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-24 19:20:26.695547
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_1 = task_result_0.clean_copy()
    assert isinstance(task_result_1, TaskResult)


# Generated at 2022-06-24 19:20:29.745415
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    result = task_result_0.is_failed()
    print(result)


# Generated at 2022-06-24 19:20:31.257874
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult(bytes, str, str)
    task_result.needs_debugger()


# Generated at 2022-06-24 19:20:34.447326
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert hasattr(test_case_0().is_skipped(), '__call__')



# Generated at 2022-06-24 19:20:45.008732
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'@\xbb\xff\xeb\x19\xa2\x1c\xfaF/\x9d\x145\x15\x85\xc8\x8a\xd1\xe6\x16\xe2\x9b\xab\x05\xdb\xf4\x92\xaaN\x85'
    str_0 = 'T\xee\x18\x1b\x93\xb6\xf3\x7f\x19X\x93\xb9@\x1c\xa2\x8d\xd6\xde\xa5\x08'
    bool_0 = True
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    bool_2 = task_result

# Generated at 2022-06-24 19:20:46.646632
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pytest.skip("Need to be implemented")



# Generated at 2022-06-24 19:21:03.770899
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert isinstance(task_result_0.clean_copy(), TaskResult)


# Generated at 2022-06-24 19:21:10.863076
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:21:16.497506
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_1 = task_result_0.clean_copy()
    assert False

# Generated at 2022-06-24 19:21:23.768466
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    result = task_result_0.is_skipped()
    assert result == False


# Generated at 2022-06-24 19:21:28.148328
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = TaskResult(b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r', '{}', '{}', False)

    assert task_result_0 is not None
    pass


# Generated at 2022-06-24 19:21:32.835108
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print('Test: method clean_copy of class TaskResult')
    test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()
    #test_case_4()
    #test_case_5()
    #test_case_6()
    #test_case_7()



# Generated at 2022-06-24 19:21:39.090624
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b"\x10\"\x83\x88\x1d\x93\x08\xc8\x17"
    str_0 = '\x7f\x8dZ'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert isinstance(task_result_0.clean_copy(), TaskResult)



# Generated at 2022-06-24 19:21:49.946703
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'\x0c\xed\xf3\xfa\x89\xcb\x91\x9c\x9a\xd6\xaa\xa8\xbf\xa6\x89\xf1'
    str_0 = 'HP'
    bool_0 = True
    task_result_0 = TaskResult(str_0, bytes_0, str_0, bool_0)
    bool_0 = False
    bool_1 = False
    bool_2 = task_result_0.needs_debugger(bool_0)
    assert bool_1 == bool_2

# Generated at 2022-06-24 19:21:54.240512
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    ret = task_result_0.needs_debugger()
    assert ret == False


# Generated at 2022-06-24 19:22:01.229280
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    bool_0 = task_result_0.is_skipped()
    assert bool_0 == False


# Generated at 2022-06-24 19:22:20.461812
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    TaskResult.needs_debugger(task_result_0, str_0)

# Generated at 2022-06-24 19:22:24.821991
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    bool_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:22:32.212008
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_1 = '\n\t'
    str_2 = '\n\t'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_1, str_2, bool_0)
    task_result_0_copy = task_result_0.clean_copy()
    assert task_result_0_copy is not None

if __name__ == '__main__':
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:22:37.641499
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    bool_1 = task_result_0.is_skipped()
    assert bool_1 == False


# Generated at 2022-06-24 19:22:42.980669
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    expected_0 = {'_ansible_parsed': False, 'censored': "the output has been hidden due to the fact that 'no_log: true' was specified for this result"}
    expected_0.update({'changed': False})
    bytes_0 = b'#\x1d\x16\x1e\x18\xebk\xac\x9f\x1f\x17'

# Generated at 2022-06-24 19:22:48.615886
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert task_result_0.is_failed() is False


# Generated at 2022-06-24 19:22:56.653616
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # Test for is_skipped of class TaskResult
    assert task_result_0.is_skipped() == False

# Generated at 2022-06-24 19:23:05.077469
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    some_dict = {
        'failed': False,
        'changed': True,
        'msg': 'All items completed',
        'results': [
            {
                'item': '64.54.95.100',
                'changed': True,
                'failed': False,
                'ping': 'pong'
            }
        ]
    }
    task = TaskResult('some_host', 'some_task', some_dict, None)
    assert task.is_skipped() == False

# Generated at 2022-06-24 19:23:11.689792
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:23:15.743109
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert task_result_0.is_failed() == False
    bytes_1 = b'G\xc1\xf7\xd3\x04\xcb\xeb\x98\x87\x8d\x14\xee\x7f\x88\xb8\xeb\n'
    str_1 = ''
    bool_1 = True
    task_result_1 = TaskResult(bytes_1, str_1, str_1, bool_1)

# Generated at 2022-06-24 19:23:30.427206
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    assert True == TaskResult.needs_debugger(test_TaskResult_needs_debugger, True)


# Generated at 2022-06-24 19:23:40.512667
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b"'\xbej\xa1\xaf\xf90J\x9f\xb9:\xbc\x98\xbc\x8a\x1f"

# Generated at 2022-06-24 19:23:44.754160
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    value_0 = task_result_0.is_failed()
    assert value_0 == False


# Generated at 2022-06-24 19:23:47.934231
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    test_case_0()


# Generated at 2022-06-24 19:23:54.375022
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)

    # Test for TaskResult.is_failed()
    assert not task_result_0.is_failed()
#


# Generated at 2022-06-24 19:24:04.752959
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert not task_result_0.is_failed()

    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = True
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert not task_result_0.is_failed()

   

# Generated at 2022-06-24 19:24:13.991188
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # test from ansible.module_utils.common._clean_results()
    print("Testing TaskResult.clean_copy()")
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    bool_0 = True
    # bool_1 = bool(bool_0)
    str_0 = '{}'
    str_1 = str(str_0)
    str_2 = str(bytes_0)
    str_3 = str_2 + str_1
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_0.is_failed()
    task_result_0._task_fields.get('name')
    task_result_

# Generated at 2022-06-24 19:24:15.738704
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert TaskResult(bytes(0), '', '', False).clean_copy() is not None


# Generated at 2022-06-24 19:24:27.492652
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bytes_0 = b'\xab\x01\xbb\x1f\xb2\x9f\x0f\xc2\xaa\xce\x1b\x1b\xb8'
    str_0 = '9|\x10n\xaa\xbe\x12\xb6\xf3\xa2\x14\xd3q\xf9\xc7\x05'

# Generated at 2022-06-24 19:24:32.568214
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = test_case_0()
    # Test for proper error handling with incorrect number of arguments
    try:
        task_result_0.needs_debugger()
    except AssertionError as e:
        pass


# Generated at 2022-06-24 19:25:00.030058
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Assertions
    assert test_TaskResult_needs_debugger.__doc__
    assert test_TaskResult_needs_debugger.__name__


# Generated at 2022-06-24 19:25:05.176597
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    task_result_0.needs_debugger()

# Generated at 2022-06-24 19:25:14.269784
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    # line 1: def __init__(self, host, task, return_data, task_fields=None):
    # line 3:     if isinstance(return_data, dict):
    # line 4:         self._result = return_data.copy()
    # line 5:     else:
    # line 7:         self._result = DataLoader().load(return_data)
    assert not (task_result_0._check_key(bool_0))

# Generated at 2022-06-24 19:25:16.357592
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from xyz import xyz
    from ansible import ansible
    xyz = ansible.ansible.TaskResult
    assert xyz(test_case_0()).clean_copy() == test_case_0().clean_copy()


# Generated at 2022-06-24 19:25:19.239529
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert TaskResult().clean_copy() == dict()



# Generated at 2022-06-24 19:25:20.810610
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Run the test case
    test_case_0()

if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:25:26.773738
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    task_result_0 = TaskResult(bytes_0, str_0, str_0, bool_0)
    assert not task_result_0.is_failed()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_case_0()
    test_TaskResult_is_failed()

# Generated at 2022-06-24 19:25:28.446808
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert isinstance(test_case_0, object)
    assert TaskResult.clean_copy(test_case_0)

# Generated at 2022-06-24 19:25:32.178674
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bytes_0 = b'0\x14\xa1R\x1b ]\x10!%\x8e\xeb\x9fI\r'
    str_0 = '{}'
    bool_0 = False
    assert TaskResult(bytes_0, str_0, str_0, bool_0).is_failed(), 'is_failed() returned False'


# Generated at 2022-06-24 19:25:41.706329
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bytes_0 = b'\xee\x89\x19\xd6\xea\x10\xe0\x8d\x19'
    str_1 = '<module>'
    str_2 = '{"changed": false, "rc": 255, "stderr": "", "stdout": "", "stdout_lines": [], "warnings": []}'
    bool_1 = True
    task_result_0 = TaskResult(bytes_0, str_1, str_2, bool_1)
    assert(True == task_result_0.is_skipped())
