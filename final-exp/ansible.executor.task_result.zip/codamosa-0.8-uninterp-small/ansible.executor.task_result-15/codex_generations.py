

# Generated at 2022-06-24 19:17:43.267101
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

if __name__ == '__main__':
    # unit tests for testing this class
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:17:44.059211
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_case_0()


# Generated at 2022-06-24 19:17:47.247603
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Setup
    int_0 = -222
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = True
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    globally_enabled = task_result_0.needs_debugger(True)

    # assert that the code runs without errors
    assert(True)


# Generated at 2022-06-24 19:17:55.797306
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -7072
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert not task_result_0.is_skipped()
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert not task_result_0.is_skipped()
    int_5 = -7890
    dict_6 = {int_5: int_5, int_5: int_5}
    str_0 = 'e;.'
    int_6 = -1679
    int_7 = 8808
    int_8 = 5339
    int_9 = 5807
    int_10 = 5485
   

# Generated at 2022-06-24 19:18:03.795026
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -4833
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)

    # Test for default argument for is_skipped()
    assert task_result_0.is_skipped() == False

    int_1 = -1330
    dict_1 = {int_1: int_1, int_1: int_1}
    bool_1 = False
    task_result_1 = TaskResult(int_1, dict_1, bool_1)

    # Test if the argument of is_skipped() is of type TaskResult object
    assert isinstance(task_result_1.is_skipped(), TaskResult)


# Generated at 2022-06-24 19:18:08.503258
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2255
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)


# Generated at 2022-06-24 19:18:16.589611
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Test task_result_0
    int_0 = -1975
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert not task_result_0.is_failed(), \
        "'task_result_0': expected <False>, got <{0}>".format(task_result_0.is_failed())

    # Test task_result_1
    int_0 = -1948
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_1 = TaskResult(int_0, dict_0, bool_0)
    assert not task_result_1.is_

# Generated at 2022-06-24 19:18:23.908544
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -1806
    list_0 = [int_0, int_0, int_0, int_0]
    dict_0 = dict()
    float_0 = float(int_0)
    float_1 = float(-int_0)
    task_result_0 = TaskResult(dict_0, dict_0, list_0)
    task_result_1 = task_result_0.clean_copy()
    assert (task_result_1._result == dict_0)


# Generated at 2022-06-24 19:18:27.749656
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:18:37.472302
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)

    # Clean result from ansible internal data
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1.is_failed() is False
    assert task_result_1.is_unreachable() is False
    assert task_result_1.is_changed() is False
    assert task_result_1.is_skipped() is False

    # Clean with internal data present
    task_result_0._result["failed"] = True
    task_result_1 = task_result_0.clean_copy()
    assert task_result_

# Generated at 2022-06-24 19:18:48.870568
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    bool_1 = task_result_0.is_skipped()
    assert (bool_1 == False)


# Generated at 2022-06-24 19:18:52.447084
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert test_case_0() is None , "Test case is failed."


# Generated at 2022-06-24 19:19:02.347428
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    dict_0 = {}
    dict_0['results'] = []
    dict_0['msg'] = 'msg'
    dict_0['invocation'] = {}
    dict_0['invocation']['module_name'] = 'module_name'
    dict_0['invocation']['module_args'] = 'module_args'
    dict_0['_ansible_item_label'] = '_ansible_item_label'
    dict_0['_ansible_parsed'] = True
    dict_0['_ansible_no_log'] = True
    dict_0['_ansible_item_result'] = True
    dict_0['_ansible_verbose_override'] = True
    dict_0['_ansible_diff'] = '_ansible_diff'

# Generated at 2022-06-24 19:19:05.297802
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -565
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:19:07.806772
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:13.859454
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Init
    int_0 = -3949
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)

    # Assertions
    assert False


# Generated at 2022-06-24 19:19:18.178146
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:19:24.355928
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = 13336
    dict_0 = {"mO`P": "HuF`", "'1Y\u000e": "'1Y\u000e"}
    int_1 = -23172
    task_result_0 = TaskResult(int_0, dict_0, int_1)
    int_0 = -10994
    dict_1 = {"L~\u001c": "Jf", "p": int_0}
    task_result_1 = TaskResult(int_1, dict_1, int_1)
    int_2 = -22554
    dict_2 = {"z^e": "z^e", ">E": ">E"}
    task_result_2 = TaskResult(task_result_1, dict_2, int_2)
    int_0 = -19759
    dict

# Generated at 2022-06-24 19:19:27.464294
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:19:31.308403
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

        # Tests:

        # test_case_0()

        print(str(TaskResult('host_0', 'task_0', 'return_data_0')), '\n')

if __name__ == "__main__":
        test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:19:46.039086
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_1 = TaskResult(host, task, return_data, task_fields)
    var_2 = var_1.is_skipped()
    # Verifying the test case's result
    assert var_2 == True


# Generated at 2022-06-24 19:19:48.351082
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # verify calling test_0 with input paramater var_0 results in expected_result_0
    expected_result_0 = {}
    result_0 = test_0(var_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-24 19:19:52.074236
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = test_case_0()
    obj = TaskResult([], [], [])
    obj.clean_copy()


# Generated at 2022-06-24 19:19:54.664288
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    r = TaskResult(None, None, None, None)
    r.is_changed = lambda: False
    r.is_failed = lambda: False
    r.is_skipped = lambda: False
    r.is_unreachable = lambda: False
    is_debugger_enabled = True

    actual = r.needs_debugger(is_debugger_enabled)
    assert actual == False
    return actual


# Generated at 2022-06-24 19:19:56.071426
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    obj = TaskResult(var_0, var_0, var_0, var_0)
    assert obj.needs_debugger() == False

# Generated at 2022-06-24 19:20:01.581603
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_1 = TaskResult(TaskResult,TaskResult,var_0)
    assert assert_equal(EXPECTED, TaskResult.is_skipped(var_1))


# Generated at 2022-06-24 19:20:02.889895
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(None,None, None, None)
    #assert var_0.is_skipped()


# Generated at 2022-06-24 19:20:05.949181
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_1 = TaskResult(None, None, None, None)
    var_2 = var_1.clean_copy()
    print(var_2._result)

    assert var_2._result == var_1._result
    assert var_2._task_fields == var_1._task_fields

if __name__ == "__main__":
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:20:07.612877
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = TaskResult(host=None, task=None, return_data={})
    assert var_0.clean_copy() == {}


# Generated at 2022-06-24 19:20:11.936755
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = TaskResult(var_0)
    var_2 =  var_1.is_failed()
    print("test_TaskResult_is_failed: " + str(var_2))


# Generated at 2022-06-24 19:20:21.188082
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = TaskResult()
    print(var_0)

# Generated at 2022-06-24 19:20:26.137500
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_fields = {}
    task_fields['name'] = 'example: task'
    task_fields['action'] = 'action_x'
    task_fields['args'] = {}
    task_result = {}
    task_result['failed'] = True
    obj = TaskResult('host_x', 'task_x', task_result, task_fields)

    result = obj.is_failed()
    assert result, "TaskResult.is_failed() test case 0 failed"


# Generated at 2022-06-24 19:20:34.591326
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    from ansible.playbook.task import Task

    var_0 = {}
    task_fields = {}
    task = Task(None, var_0, task_fields)
    host = None
    # Load the result with empty result
    return_data = {}
    task_result = TaskResult(host, task, return_data)
    # Assert skipped should be False
    assert (task_result.is_skipped() == False)
    return_data['skipped'] = False
    task_result = TaskResult(host, task, return_data)
    # Assert skipped should be False
    assert (task_result.is_skipped() == False)
    return_data['skipped'] = True
    task_result = TaskResult(host, task, return_data)
    # Assert skipped should be True

# Generated at 2022-06-24 19:20:44.072651
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_15 = {'_ansible_item_label': 'my_item', '_ansible_no_log': False, 'msg': 'TASK [debug] *******************************************************************\nok: [localhost] => {\n    "msg": "Bar"\n}'}
    var_18 = {'action': 'debug', '_ansible_no_log': False, 'msg': 'Hello world'}
    var_22 = {'changed': True, '_ansible_item_label': 'my_item', '_ansible_no_log': False, 'msg': 'TASK [debug] *******************************************************************\nok: [localhost] => {\n    "msg": "Bar"\n}'}

# Generated at 2022-06-24 19:20:47.710394
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_1 = TaskResult(test_case_0(), test_case_0(), test_case_0())
    res = var_1.clean_copy()
    # FIXME: Implement proper unit tests (not covered)

    print("get_task_name\n")



# Generated at 2022-06-24 19:20:49.987274
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    var_0 = TaskResult()
    assert var_0.is_skipped() == None


# Generated at 2022-06-24 19:21:01.341455
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # No debugger in Task
    global var_0
    var_0 = {}
    case_0 = TaskResult("host_0", "task_0", "return_data_0", var_0)
    test_result_0 = case_0.needs_debugger("globally_enabled_0")
    assert test_result_0 == False, "Test case 0 in TaskResult.needs_debugger() Failed"

    # debugger is always
    global var_1
    var_1 = {}
    var_1["debugger"] = "always"
    case_1 = TaskResult("host_1", "task_1", "return_data_1", var_1)
    test_result_1 = case_1.needs_debugger("globally_enabled_1")

# Generated at 2022-06-24 19:21:02.791678
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_0 = TaskResult(None, None, None)
    # Return correct value
    assert task_0.clean_copy() == None


# Generated at 2022-06-24 19:21:05.680637
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(None, None, {})
    var_1 = var_0.is_skipped()



# Generated at 2022-06-24 19:21:11.559202
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    '''
    Unit test for TaskResult.is_skipped
    '''
    # Mock test for TaskResult
    class TaskResult_mock:
        def __init__(self):
            self.var_0 = {}

        def _check_key(self, key):
            return True

    result = TaskResult_mock()
    assert result.is_skipped() is True


# Generated at 2022-06-24 19:21:20.249956
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = TaskResult(None, None, {'failed': True})
    var_1 = var_0.clean_copy()
    assert not var_1.is_failed()

# Generated at 2022-06-24 19:21:28.204592
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = DataLoader().load("""state""")
    var_1 = DataLoader().load("""failed""")
    var_2 = DataLoader().load("""unreachable""")
    var_3 = DataLoader().load("""meta""")
    var_4 = DataLoader().load("""failed""")
    var_5 = DataLoader().load("""changed""")
    var_6 = DataLoader().load("""changed""")
    var_7 = DataLoader().load("""changed""")
    var_8 = DataLoader().load("""changed""")
    var_9 = DataLoader().load("""changed""")
    var_10 = DataLoader().load("""changed""")
    var_11 = DataLoader().load("""changed""")
    var_12 = DataLoader().load("""changed""")
    var

# Generated at 2022-06-24 19:21:31.939067
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print(test_case_0.__doc__, "Testing TaskResult.is_failed()")
    tc0 = TaskResult(var_0)
    result_0 = tc0.is_failed()
    print("Passed")

test_case_1 = {}


# Generated at 2022-06-24 19:21:36.475002
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # test case 1
    var_1 = {}
    result = TaskResult(var_0, var_1, var_0).is_failed()
    assert result == False

if __name__ == "__main__":
    test_case_0()
    test_TaskResult_is_failed()

# Generated at 2022-06-24 19:21:40.599337
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    print("Testing needs_debugger")
    test_0_TaskResult = TaskResult(None, None, None)
    test_0_needs_debugger = test_0_TaskResult.needs_debugger()
    print(test_0_needs_debugger)
    assert test_0_needs_debugger == False


# Generated at 2022-06-24 19:21:41.286865
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_case_0()

# Generated at 2022-06-24 19:21:46.822576
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = TaskResult(var_0, var_0, var_0)
    var_2 = var_1.needs_debugger(var_0)
    assert var_2 == False


# Generated at 2022-06-24 19:21:48.521479
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()

if __name__ == "__main__":
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:53.130740
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(None, None, None)
    var_0.is_skipped()


# Generated at 2022-06-24 19:21:55.619716
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = TaskResult( '','','')
    assert False == var_0.needs_debugger()

    var_0 = TaskResult( '','','', dict( ignore_errors = True))
    assert False == var_0.needs_debugger()


# Generated at 2022-06-24 19:22:13.250196
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Test with an empty dictionary
    test_case_0()

    # Test with a dictionary having a True value
    var_1 = {}
    var_1['failed'] = True
    result = True

    # Test with a dictionary having a False value
    var_2 = {}
    var_2['failed'] = False
    result = False

    # Test with a dictionary having a False value
    var_3 = {}
    var_3['failed'] = False
    var_3['results'] = []
    result = False

    # Test with a dictionary having a True value
    var_4 = {}
    var_4['failed'] = False
    var_4['results'] = [{'failed': True}]
    result = True

    # Test with a dictionary having a True value and a False value
    var_5 = {}
    var

# Generated at 2022-06-24 19:22:18.283442
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # task_fields = None
    # load_data = {}
    # task = None
    # host = None
    # self = TaskResult(host, task, load_data, task_fields)
    test_case_0()


# Generated at 2022-06-24 19:22:21.244089
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Create a new TaskResult object with init parameters
    var_0 = TaskResult(host, task, return_data, task_fields)
    # Calling is_failed function
    var_0.is_failed()


# Generated at 2022-06-24 19:22:22.307887
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Telemtry not implemented
    return


# Generated at 2022-06-24 19:22:24.044764
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(host, task, return_data, task_fields)
    var_0.is_skipped()


# Generated at 2022-06-24 19:22:25.843014
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    var_1 = (var_0)
    return var_1

# Generated at 2022-06-24 19:22:28.065017
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(host = 'host0', task = 'task0', return_data = 'return_data0', task_fields = 'task_fields0')
    print(var_0.is_skipped())


# Generated at 2022-06-24 19:22:29.238339
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:22:31.280554
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_0 = TaskResult(var_0, var_0, var_0)
    var_0.clean_copy()



# Generated at 2022-06-24 19:22:33.370360
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(var_0, var_0, var_0)
    var_0.is_skipped()



# Generated at 2022-06-24 19:22:46.167957
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = 1550
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    bool_0 = task_result_0.needs_debugger()
    assert bool_0 == False


# Generated at 2022-06-24 19:22:51.540313
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2254
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    assert task_result_0.is_failed() is False


# Generated at 2022-06-24 19:22:55.985372
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    bool_1 = task_result_0.needs_debugger()


# Generated at 2022-06-24 19:23:00.276631
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2410
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:23:01.541277
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:23:08.266428
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    task_result_1 = TaskResult(int_0, dict_0, bool_0)
    task_result_2 = TaskResult(int_0, dict_0, bool_0)
    task_result_3 = TaskResult(int_0, dict_0, bool_0)
    task_result_4 = TaskResult(int_0, dict_0, bool_0)
    task_result_5 = TaskResult(int_0, dict_0, bool_0)
    task_result_6 = TaskResult(int_0, dict_0, bool_0)

# Generated at 2022-06-24 19:23:13.335978
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Test case 0
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    ret_0 = task_result_0.needs_debugger(bool_0)


# Generated at 2022-06-24 19:23:16.839976
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)

    # Case 1:
    bool_0 = task_result_0.needs_debugger(False)


# Generated at 2022-06-24 19:23:24.043550
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -13727
    dict_0 = {'a': 'a', 'b': 'b', 'a': 'a', 'b': 'b', 'a': 'a', 'b': 'b', 'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)

    assert isinstance(task_result_0.clean_copy(), TaskResult)


# Generated at 2022-06-24 19:23:28.241256
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    int_0 = -2986
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)


# Generated at 2022-06-24 19:23:43.180961
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # FIXME: test me
    assert False == True

# Generated at 2022-06-24 19:23:48.607134
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -6941
    dict_0 = {}

# Generated at 2022-06-24 19:23:57.386365
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()

    task_result_0 = TaskResult(bool_0, bool_1, bool_2)
    bool_14 = task_result_0.is_failed()
    bool_15 = task_result_0.is_unreachable()

    task_result_1 = TaskResult(bool_3, bool_4, bool_5)
    bool_16 = task_

# Generated at 2022-06-24 19:24:00.441166
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult(42, {}, False)
    assert not task_result_0.needs_debugger(True)

if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:24:03.301118
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    task_result_clean_copy = task_result_0.clean_copy()
    print(task_result_clean_copy)
    assert task_result_clean_copy == bool_0

if __name__ == '__main__':
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:24:09.009956
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    int_0 = -2281
    dict_0 = {int_0: int_0}
    bool_0 = True
    task_result_0 = TaskResult(int_0, dict_0, dict_0)

    taskresult_0 = task_result_0.clean_copy()

    test_case_0()

# Generated at 2022-06-24 19:24:13.799290
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -3906
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    int_1 = 2440
    bool_1 = task_result_0.needs_debugger(int_1)
    print(bool_1)

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:24:18.671923
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    bool_1 = False
    bool_2 = task_result_0.needs_debugger(bool_1)
    bool_1 = True
    bool_2 = task_result_0.needs_debugger(bool_1)
    bool_1 = False
    bool_2 = task_result_0.needs_debugger(bool_1)


# Generated at 2022-06-24 19:24:22.705901
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = 16
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_1 = {int_0: int_0, int_0: int_0}
    task_result_0 = TaskResult(int_0, dict_0, dict_1)
    assert task_result_0.is_skipped() == False
    int_0 = 0
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_1 = {int_0: int_0, int_0: int_0}
    task_result_0 = TaskResult(int_0, dict_0, dict_1)
    assert task_result_0.is_skipped() == True
    int_0 = -142

# Generated at 2022-06-24 19:24:27.063994
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    int_0 = -2281
    dict_0 = {int_0: int_0, int_0: int_0}
    bool_0 = False
    task_result_0 = TaskResult(int_0, dict_0, bool_0)
    bool_1 = task_result_0.is_skipped()
    assert bool_1


# Generated at 2022-06-24 19:25:03.146595
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_1 = {'results': [{'skipped': True}, {'skipped': False}], 'skipped': False}
    var_2 = {'results': [], 'skipped': True}
    var_3 = 'results'
    var_4 = 'skipped'
    var_5 = {'results': [{'skipped': False}, {'skipped': False}], 'skipped': False}
    var_6 = {'results': [{'skipped': True}, {'skipped': True}], 'skipped': False}
    var_7 = {'skipped': True}
    var_8 = 'msg'
    var_9 = 'skipped'
    var_10 = False


# Generated at 2022-06-24 19:25:06.008729
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_skipped()

    assert var_1 == False


# Generated at 2022-06-24 19:25:14.171785
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    var_2 = TaskResult(var_0, var_0, var_0)
    var_3 = var_2.needs_debugger(var_0)
    var_4 = TaskResult(var_0, var_0, var_1)
    var_5 = var_4.needs_debugger(var_0)
    var_6 = TaskResult(var_0, var_0, var_1)
    var_7 = var_6.needs_debugger(var_1)
    var_8 = TaskResult(var_0, var_0, var_0)
    var_9 = var_8.needs_debugger(var_1)

# Generated at 2022-06-24 19:25:20.486308
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_is_skipped_0 = {'_ansible_no_log': True, '_ansible_item_label': u'omg', '_ansible_parsed': True, '_ansible_verbose_always': True, 'warnings': []}
    task_result_is_skipped_1 = {'_ansible_item_label': u'omg', '_ansible_parsed': True, '_ansible_verbose_always': True, 'warnings': []}
    task_result_is_skipped_exec = TaskResult(task_result_is_skipped_0, task_result_is_skipped_0, task_result_is_skipped_1)
    task_result_is_skipped_0 = task_result_is_skipped_exec.is_

# Generated at 2022-06-24 19:25:22.542526
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_0 = {}
    task_result_0 = TaskResult(var_0, task_0, var_0)
    assert(task_result_0.needs_debugger(False) == False)

# Generated at 2022-06-24 19:25:27.184921
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    task_result_0 = TaskResult(var_1, var_2, var_3, var_0)
    var_4 = task_result_0.is_failed()
    var_5 = task_result_0.is_unreachable()
    var_6 = task_result_0.is_changed()
    var_7 = task_result_0.needs_debugger()
    var_8 = task_result_0.needs_debugger(var_6)


# Generated at 2022-06-24 19:25:29.336445
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.needs_debugger()


if __name__ == "__main__":
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:25:32.646621
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_failed()
    print(var_1)

if __name__ == '__main__':
    test_case_0()
    #test_TaskResult_is_failed()

# Generated at 2022-06-24 19:25:43.592452
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Test case with a basic task_result with empty result
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert not task_result_0.is_skipped()

    # Test case with a nested result with "skipped" key set to True
    var_2 = {}
    var_2['results'] = [{'skipped':True}]
    task_result_1 = TaskResult(var_0, var_0, var_2)
    assert task_result_1.is_skipped()

    # Test case with a nested result with "skipped" key set to False
    var_3 = {}
    var_3['results'] = [{'skipped':False}]

# Generated at 2022-06-24 19:25:45.832144
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:26:26.714777
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # guess you have to run with -k and -C
    var_0 = {}
    var_1 = {}
    var_2 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    var_3 = {}
    var_3 = task_result_0.needs_debugger(var_3)



# Generated at 2022-06-24 19:26:29.320987
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = False
    task_result_0.needs_debugger(var_1)


# Generated at 2022-06-24 19:26:31.832005
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_3 = {}
    var_4 = {}
    var_5 = {}
    # Unit Test for method is_failed of class TaskResult
    task_result_1 = TaskResult(var_3, var_4, var_5)
    var_6 = task_result_1.is_failed()


# Generated at 2022-06-24 19:26:34.218235
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_2 = {}
    task_result_var_0 = TaskResult(var_2, var_2, var_2)
    var_3 = task_result_var_0.is_skipped()


# Generated at 2022-06-24 19:26:35.632315
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_1 = TaskResult()
    # Test there is no exception raised by calling the method.
    var_1.clean_copy()


# Generated at 2022-06-24 19:26:36.295868
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True



# Generated at 2022-06-24 19:26:37.610298
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
	# test that 1 == 1
	assert(task_result_0.needs_debugger() == True)


# Generated at 2022-06-24 19:26:41.921506
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_list_0 = []
    var_data_0 = DataLoader().load("{'failed': False, '_ansible_no_log': False, 'invocation': {'module_name': 'win_ping'}, 'ansible_facts': {'discovered_interpreter_python': 'C:\\\\Python27\\\\python.exe'}}")
    var_host_0 = {}
    var_name_0 = None
    var_task_0 = {}
    var_task_result_0 = TaskResult(var_host_0, var_task_0, var_data_0)
    var_task_0['name'] = var_name_0
    var_list_0.append(var_task_result_0)
    for var_task_result_1 in var_list_0:
        var_task_

# Generated at 2022-06-24 19:26:47.597676
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = {}
    var_2 = {}
    var_2['debugger'] = 'on_failed'
    var_2['debugger_enabled'] = True
    task_result_0._task_fields = var_2
    var_1['failed'] = True
    var_1['skipped'] = False
    var_1['unreachable'] = False
    task_result_0._result = var_1
    var_3 = task_result_0.needs_debugger()
    assert var_3 == True


# Generated at 2022-06-24 19:26:50.311879
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # unit tests for method is_skipped
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:27:27.416148
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:32.451174
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.is_skipped()

