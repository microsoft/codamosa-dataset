

# Generated at 2022-06-24 19:17:45.974419
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    dict_0 = {}
    task_result_0 = TaskResult(bool_0, str_0, dict_0)

    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:17:55.186982
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'o/r'
    dict_0 = dict()
    dict_0['attempts'] = 2
    dict_0['changed'] = 0
    dict_0['failed'] = False
    dict_0['skipped'] = False
    dict_0['invocation'] = dict()
    dict_0['invocation']['module_args'] = dict()
    dict_0['invocation']['module_args']['name'] = str_0
    dict_0['retries'] = 1
    dict_0['_ansible_verbose_always'] = False
    dict_0['_ansible_item_label'] = dict()
    dict_0['_ansible_item_label']['name'] = str_0
    dict_0['_ansible_no_log'] = False
   

# Generated at 2022-06-24 19:17:56.021919
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    pass


# Generated at 2022-06-24 19:17:59.148215
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = "I+g"
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    result = task_result_0.is_skipped()
    assert not result


# Generated at 2022-06-24 19:18:03.359937
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Make some variables
    bool_0 = True
    task_0 = TaskResult(bool_0, bool_0, bool_0)
    bool_1 = task_0.needs_debugger(True)
    assert bool_1 == False, 'Expected False'

    bool_1 = task_0.needs_debugger(False)
    assert bool_1 == False, 'Expected False'




# Generated at 2022-06-24 19:18:04.103375
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()


# Generated at 2022-06-24 19:18:10.896126
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = False
    str_0 = 'no'
    task_result_0 = TaskResult(bool_0, False, False, {'name': '', 'ignore_errors': True, 'debugger': 'never', 'tags': [], 'when': True})
    expected_result_0 = False
    actual_result_0 = task_result_0.is_skipped()
    assert expected_result_0 == actual_result_0


# Generated at 2022-06-24 19:18:12.575895
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert True


# Generated at 2022-06-24 19:18:16.769961
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.is_skipped()
    assert not bool_1


# Generated at 2022-06-24 19:18:26.239259
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = '^+Y]y'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    # Call method clean_copy of class TaskResult with arg: bool_0
    task_result_0.clean_copy(bool_0)
    # Call method clean_copy of class TaskResult with arg: str_0
    task_result_0.clean_copy(str_0)
    # Call method clean_copy of class TaskResult with arg: task_result_0
    task_result_0.clean_copy(task_result_0)
    # Call method clean_copy of class TaskResult with arg: task_result_0
    task_result_0.clean_copy(task_result_0)
    # Call method clean_copy of class TaskResult with

# Generated at 2022-06-24 19:18:37.887810
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'c%m'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:18:46.008471
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Check for all subclasses of TaskResult
    print('Testing method is_skipped of all subclasses of TaskResult')
    # Instantiate an object of class TaskResult
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    # Check for all subclasses of TaskResult
    print(task_result_0.is_skipped())


# Generated at 2022-06-24 19:18:48.659317
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:55.070689
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    host_0 = 'n'
    str_0 = 'E'
    str_1 = 'n'
    task_result_0 = TaskResult(host_0, str_0, str_1)
    str_2 = '!@&g'
    dict_0 = dict()
    dict_0['debugger'] = str_2
    dict_0['name'] = str_2
    task_result_0._task_fields = dict_0
    # Call the method needs_debugger for task_result_0 object
    var_4 = task_result_0.needs_debugger()
    assert var_4 is False

# Generated at 2022-06-24 19:18:57.894912
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'a{`'
    str_1 = 'f;U$^'
    task_result_0 = TaskResult(str_0, str_1, str_1)
    bool_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:19:01.520585
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:19:04.964474
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # TODO: Create mock for bool_0, str_0
    bool_0 = None
    str_0 = None
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    try:
        task_result_0.clean_copy()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 19:19:08.060649
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'v^_!L-!b'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert task_result_0.is_failed()


# Generated at 2022-06-24 19:19:14.113263
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = True
    str_0 = '4;'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    b_0 = task_result_0.needs_debugger(bool_0)
    print(b_0)
    assert b_0 == False


# Generated at 2022-06-24 19:19:18.977164
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Arguments:
    #    self (type): Description of parameter `self`.
    # Returns:
    #    type: Description of returned object.
    # Raises:
    #    ExceptionType: Description of raised exception.
    pass


# Generated at 2022-06-24 19:19:31.512752
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult('bool_0', 'str_0', 'str_0')
    task_result_0.is_failed()
    task_result_0.is_unreachable()
    task_result_0.is_changed()
    task_result_0.needs_debugger()


if __name__ == '__main__':
    test_case_0()
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:19:34.008415
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.is_skipped()
    assert bool_1 == False


# Generated at 2022-06-24 19:19:39.594637
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(str_0, str_0, str_0, None)
    ret = task_result_0.is_failed()
    assert ret, 'Return value of TaskResult.is_failed is not correct'


# Generated at 2022-06-24 19:19:46.078417
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Create test data
    bool_0 = True
    str_0 = 'Path to the lookup plugin\'s directory.'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    # Attempt to run method clean_copy
    try:
        result = task_result_0.clean_copy()
        print("SUCCESS: clean_copy() worked as expected.")
    except Exception as err:
        print("FAILURE: clean_copy() could not be run as expected:")
        print("Error message: " + str(err))

test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:19:54.669876
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    """
    Test the needs_debugger method of the TaskResult class
    """

    task_object = {}
    task_object['debugger'] = 'on_failed'
    task_object['ignore_errors'] = False

    hosts = {}
    hosts['0'] = {'name' : '127.0.0.1', 'vars' : {}}

    task_result_0 = TaskResult(hosts['0'], task_object, "")

    result = task_result_0.needs_debugger(True)
    assert result == False, "Result does not match expected"

    task_result_1 = TaskResult(hosts['0'], task_object, {'failed':True, '_ansible_no_log' : False})
    result = task_result_1.needs_debugger(False)

# Generated at 2022-06-24 19:19:58.806264
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._task is None
    assert task_result_1._task_fields is None
    assert task_result_1._host is None
    assert task_result_1._result is None
    assert task_result_1.task_name is None


# Generated at 2022-06-24 19:20:01.334854
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # FIXME: this does not test anything
    test_TaskResult_needs_debugger_0()


# Generated at 2022-06-24 19:20:07.487682
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'hk[w)8'
    str_1 = 'Kj*mR'
    task_result_0 = TaskResult(bool_0, str_0, str_1)
    bool_1 = task_result_0.is_skipped()
    assert not bool_1


# Generated at 2022-06-24 19:20:14.703562
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Test inputs
    bool_0 = True
    str_0 = 'c@TN'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    # Test output
    result = task_result_0.clean_copy()
    #print(result)
    assert result is None


if __name__ == "__main__":
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:20:18.352433
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'F1'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.test_TaskResult_clean_copy()


# Generated at 2022-06-24 19:20:30.624314
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_1 = True
    str_1 = 'a{`'
    task_result_1 = TaskResult(bool_1, str_1, str_1)
    test1 = task_result_1.is_skipped()
    test1 = isinstance(test1, bool)



# Generated at 2022-06-24 19:20:36.559184
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = False
    str_0 = 'mT-H'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_0 = task_result_0.is_skipped()



# Generated at 2022-06-24 19:20:46.845320
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Assigning: 
    str_0 = 'a{`'
    bool_0 = True
    dict_0 = dict()
    dict_2 = dict()
    dict_2['ignore_errors'] = bool_0
    dict_2['debugger'] = str_0
    dict_0['task_fields'] = dict_2
    dict_0['host'] = bool_0
    dict_0['return_data'] = str_0
    dict_0['task'] = str_0
    task_result_0 = TaskResult(**dict_0)
    # Calling needs_debugger with arguments: 
    # Case 0
    # FIXME: This task result does not actually fail, so the debugger should
    # not be called
    # expected = True
    expected = False
    actual = task_result_0.needs_

# Generated at 2022-06-24 19:20:48.372785
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    with pytest.raises(Exception):
        test_case_0()

if __name__ == "__main__":
    pass

# Generated at 2022-06-24 19:20:51.033166
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_0 = TaskResult(False, 'eHz_!9[1\r-I', [], {})
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:01.446691
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-24 19:21:05.270956
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    # TODO: fix this - why does this return false?
    assert task_result_0.is_skipped() == False


# Generated at 2022-06-24 19:21:09.942834
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # We do not try to test a real scenario as we use
    # TaskResult object only to build PlayRecords
    # later.
    # We just test the functionnality.
    test_case_0()


if __name__ == '__main__':

    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:21:14.406483
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = False
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    with pytest.raises(NotImplementedError):
        task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:18.266895
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    # Call is_skipped()

    result = task_result_0.is_skipped()
    print("result = " + str(result))


# Generated at 2022-06-24 19:21:32.614721
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # FIXME: we need to implement some test with the datastructure
    pass



# Generated at 2022-06-24 19:21:36.474396
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = '2hix]|_d'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:38.287838
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert test_TaskResult_is_failed.__doc__ == TaskResult.is_failed.__doc__
    assert callable(TaskResult.is_failed)


# Generated at 2022-06-24 19:21:43.015298
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Should dynamically return if the task is failed or unreachable if debugger is enabled
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.is_failed = MagicMock(return_value=True)
    task_result_0.is_unreachable = MagicMock(return_value=True)
    result_0 = task_result_0._check_key('failed')
    assert result_0
    result_1 = task_result_0._check_key('unreachable')
    assert result_1
    result_2 = task_result_0.needs_debugger(True)
    assert result_2


# Generated at 2022-06-24 19:21:46.734737
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # FIXME: create test case
    test_case_0()


# Generated at 2022-06-24 19:21:49.977112
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = True
    str_0 = 'B]{O%#'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_0 = True
    bool_1 = task_result_0.needs_debugger(bool_0)
    assert bool_1 is False



# Generated at 2022-06-24 19:21:54.018589
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 't@y'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.is_skipped()
    assert bool_1 == True


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-24 19:21:56.981430
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:59.684579
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    try:
        test_case_0()

    except Exception as e:
        print("{} Failed!".format(test_TaskResult_clean_copy.__name__))
        raise

    else:
        print("{} Success!".format(test_TaskResult_clean_copy.__name__))

# unit_test()


# Generated at 2022-06-24 19:22:02.230678
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.needs_debugger()
    # assert that task_result_0.needs_debugger() == False
    return


# Generated at 2022-06-24 19:22:22.487070
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'gM7Z3n'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_0.task_name == task_result_1.task_name
    assert str(task_result_0) == "am9rZXMgYWN0aW9uIGRhdGEuc3RyaW5n"
    assert str(task_result_1) == "am9rZXMgYWN0aW9uIGRhdGEuc3RyaW5n"


# Generated at 2022-06-24 19:22:26.111962
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    str_1 = '^'
    task_result_0._result.update({'failed_when_result': str_1})
    # assert task_result_0.is_failed()


# Generated at 2022-06-24 19:22:31.342634
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._result is not None

    task_result_0._result = None
    task_result_1 = task_result_0.clean_copy()
    assert task_result_1._result is None


# Generated at 2022-06-24 19:22:34.528996
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:22:38.047860
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()

    assert isinstance(task_result_1, TaskResult)

# Generated at 2022-06-24 19:22:42.968664
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    ret_val0 = task_result_0.is_skipped()

    # AssertionError:False != True
    # assertEqual(ret_val0, True)


# Generated at 2022-06-24 19:22:47.265271
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'p.P'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    ret = task_result_0.is_skipped()
    if ret:
        assert True
    else:
        assert True


# Generated at 2022-06-24 19:22:52.295090
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = '6h|'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    result_0 = task_result_0.is_skipped()
    assert result_0 == False


# Generated at 2022-06-24 19:22:55.449688
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:22:58.995734
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'skipped'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:23:21.758549
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("Testing method clean_copy of class TaskResult")

    task_result_1 = TaskResult(True, "a{`", "a{`")
    task_result_1.clean_copy()


# Generated at 2022-06-24 19:23:25.709035
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.needs_debugger(bool_0)
    print(bool_1)
    print('TEST: needs_debugger')


# Generated at 2022-06-24 19:23:32.595701
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # test_case_0
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert task_result_0.is_failed() == True
    # test_case_1
    bool_0 = False
    str_0 = '%}y'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert task_result_0.is_failed() == False



# Generated at 2022-06-24 19:23:37.610916
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    #Unit test for method is_failed of class TaskResult
    bool_0 = True
    str_0 = 'G'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.is_failed()


# Generated at 2022-06-24 19:23:43.085934
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    """
    Check that the method is_failed returns the right value
    """

    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert not task_result_0.is_failed()



# Generated at 2022-06-24 19:23:43.807494
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    test_case_0()


# Generated at 2022-06-24 19:23:44.517273
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()



# Generated at 2022-06-24 19:23:46.761927
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'i['
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:23:57.249264
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Init object
    try:
        # There is not way to convert True to str
        task_result_0 = TaskResult(True, True, True)
    except:
        pass
    else:
        assert False

    try:
        # There is not way to convert True to str
        task_result_0 = TaskResult(True, True, True)
    except:
        pass
    else:
        assert False

    try:
        # There is not way to convert True to str
        task_result_0 = TaskResult(True, True, True)
    except:
        pass
    else:
        assert False

    try:
        # There is not way to convert True to str
        task_result_0 = TaskResult(True, True, True)
    except:
        pass
    else:
        assert False


# Generated at 2022-06-24 19:24:00.638098
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:24:49.361379
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_case_0()
    return 0


# Generated at 2022-06-24 19:24:55.039144
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    task_result_0.clean_copy()

# Generated at 2022-06-24 19:24:56.764245
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Add your test here, e.g.,
    # ...
    # ...
    pass


# Generated at 2022-06-24 19:24:59.162983
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # task_result_0 = TaskResult(bool_0, str_0, str_0)
    # assert not task_result_0.is_failed()
    pass


# Generated at 2022-06-24 19:25:00.365659
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result_0 = test_case_0()


# Generated at 2022-06-24 19:25:04.514479
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Test Template for Unit Test of method is_skipped of class TaskResult
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:25:10.108374
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    from ansible.compat.tests import unittest

    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    test_TaskResult_is_skipped_0 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:25:16.363714
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    assert not task_result_0.is_failed()


# Generated at 2022-06-24 19:25:23.841787
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    result = task_result_0.is_skipped()
    test_results = (result)
    return test_results


# Generated at 2022-06-24 19:25:33.670705
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    # AssertionError: False != True
    assert task_result_0.is_skipped() == True
    # AssertionError: True != False
    assert task_result_0.is_skipped() == False
    # AssertionError: True != False
    assert task_result_0.is_skipped() == False
    # AssertionError: True != False
    assert task_result_0.is_skipped() == False
    # AssertionError: True != False
    assert task_result_0.is_skipped() == False
    # AssertionError: True != False
    assert task_result_0.is_skipped

# Generated at 2022-06-24 19:26:31.349522
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Variables
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    # is_skipped()
    #
    # return self._check_key('skipped')
    assert task_result_0.is_skipped() is False


# Generated at 2022-06-24 19:26:38.110138
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    bool_0 = True
    str_0 = 'a{`'
    task_result_0 = TaskResult(bool_0, str_0, str_0)

    try:
        result = task_result_0.clean_copy()
    except Exception as e:
        print('Expected:', 'No exception')
        print('Actual:  ', type(e).__name__ + ': ' + str(e))



# Generated at 2022-06-24 19:26:47.425555
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    dict_0 = {'a': 'b'}

    task_result_0 = TaskResult(str_0, str_0, dict_0)
    assert task_result_0.is_failed() == False

    dict_0 = {'a': 'b', 'failed': False, 'changed': True}

    task_result_0 = TaskResult(str_0, str_0, dict_0)
    assert task_result_0.is_failed() == False

    dict_0 = {'a': 'b', 'changed': False,  'ansible_facts': {'a': 'b', 'b': 'c', 'c': 'd', 'd': 'e'}}


# Generated at 2022-06-24 19:26:53.805691
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # @TODO: Implement a test for needs_debugger
    #return None
    from ansible.playbook.task_include import TaskInclude
    global task_result_0
    task_result_0 = TaskResult(test_case_0(), TaskInclude(), test_case_0())
    task_result_0.needs_debugger()
    #return None
    print(task_result_0)
    #return None
    #return False



# Generated at 2022-06-24 19:26:59.822047
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    bool_0 = True
    str_0 = 'g'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    bool_1 = task_result_0.is_failed()
    if bool_1:
        str_1 = 'Gxw!b'
        bool_2 = bool_1
    else:
        str_3 = 'Gxw!b'
        bool_2 = bool_1
    assert bool_2 == bool_1


# Generated at 2022-06-24 19:27:02.116985
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass


# Generated at 2022-06-24 19:27:03.651912
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()
# end class TaskResult

# Generated at 2022-06-24 19:27:05.630166
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result_0 = TaskResult(True, 'a{`', 'a{`')
    assert task_result_0.is_skipped()


# Generated at 2022-06-24 19:27:06.782428
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    assert True == True


# Generated at 2022-06-24 19:27:09.130693
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    bool_0 = True
    str_0 = '!'
    task_result_0 = TaskResult(bool_0, str_0, str_0)
    result = task_result_0.is_skipped()
