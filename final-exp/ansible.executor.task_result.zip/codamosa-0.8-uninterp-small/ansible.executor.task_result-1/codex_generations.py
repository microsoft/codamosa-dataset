

# Generated at 2022-06-24 19:17:52.739564
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'Dq3r$Jo'
    tuple_0 = (0, str_0, 2)
    list_0 = [None, 4, 6752]

    task_result_0 = TaskResult(str_0, tuple_0, list_0)

    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:17:56.440064
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    need = task_result_0.needs_debugger()
    if not need:
        print("Success")


# Generated at 2022-06-24 19:17:59.869441
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'j'
    dict_0 = {}
    dict_1 = {}
    tuple_0 = None
    task_result_0 = TaskResult(str_0, tuple_0, dict_0, dict_1)
    task_result_0.clean_copy()



# Generated at 2022-06-24 19:18:03.153866
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    print("test_TaskResult_clean_copy begin")
    result = TaskResult("", "", "")
    result.clean_copy()
    print("test_TaskResult_clean_copy end")

if __name__ == "__main__":
    test_case_0()
    test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:18:06.344913
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    result = task_result_0.clean_copy()
    assert result == list_0


# Generated at 2022-06-24 19:18:12.462636
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    task_result_0._result = {'failed': True}
    assert task_result_0.is_failed() == True


# Generated at 2022-06-24 19:18:14.924396
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:23.648330
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)

    # Call needs_debugger
    str_1 = 'The role \'apache\' was not found'
    str_2 = 'This option requires a file containing a list of collection names, one per line.'
    tuple_1 = (str_1, str_2)
    dict_0 = dict()
    dict_0['content'] = 'regex_search'
    bool_0 = True
    dict_0['failed_when_result'] = bool_0
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts']['env'] = dict()
    dict_0

# Generated at 2022-06-24 19:18:29.043566
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = ':::'
    tuple_0 = None
    list_0 = [None]
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:18:32.709845
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    assert not task_result_0.is_skipped()


# Generated at 2022-06-24 19:18:41.756976
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    assert task_result_0.is_failed() == False
    return 


# Generated at 2022-06-24 19:18:48.630980
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    task_result_0._task_fields = {'debugger': 'on_skipped'}
    function_return = task_result_0.needs_debugger(True)
    try:
        assert function_return == False
    except AssertionError:
        raise


# Generated at 2022-06-24 19:18:56.343009
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    task_result_0.clean_copy()
    str_1 = 'You must specify a collection name or a requirements file.'
    tuple_1 = None
    list_1 = []
    task_result_1 = TaskResult(str_0, tuple_0, list_0)


# Generated at 2022-06-24 19:19:04.040108
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    temp_1 = None
    temp_2 = None
    temp_3 = None
    temp_4 = None
    temp_5 = None
    temp_6 = None
    temp_7 = None
    temp_8 = None
    temp_9 = None
    temp_10 = None
    temp_11 = None
    temp_12 = None
    temp_13 = None
    temp_14 = None
    temp_15 = None
    temp_16 = None
    temp_17 = None
    temp_18 = None
    # Arrange
    temp_19 = None
    temp_20 = None
    temp_21 = None
    temp_22 = None
    temp_23 = None
    temp_24 = None
    temp_25 = None
    temp_26 = None
    temp_27 = None

# Generated at 2022-06-24 19:19:07.421209
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    bool_0 = task_result_0.needs_debugger(True)
    assert True == bool_0


# Generated at 2022-06-24 19:19:13.442392
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'You must specify a collection name or a requirements file.'
    dict_0 = {}
    task_result_0 = TaskResult(str_0, dict_0, dict_0)
    obj_0 = task_result_0.clean_copy()
    assert isinstance(obj_0, TaskResult) == True


# Generated at 2022-06-24 19:19:19.700218
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    bool_0 = task_result_0.is_skipped()
    

# Generated at 2022-06-24 19:19:22.655708
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    dict_0 = {}
    tuple_0 = None
    list_0 = []
    test_TaskResult = TaskResult(dict_0, tuple_0, list_0)
    result = test_TaskResult.is_skipped()
    assert False == result


# Generated at 2022-06-24 19:19:26.045736
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    result = task_result_0.clean_copy()
    assert isinstance(result, TaskResult)


# Generated at 2022-06-24 19:19:28.801571
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    str_0 = 'You must specify a collection name or a requirements file.'
    tuple_0 = None
    list_0 = []
    task_result_0 = TaskResult(str_0, tuple_0, list_0)
    assert task_result_0.is_failed() == False


# Generated at 2022-06-24 19:19:39.083728
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert task_result_0.is_skipped() == False



# Generated at 2022-06-24 19:19:47.560496
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = TaskResult(None, None, { 'results': [ {'skipped': True, 'item': 'item1'}, {'skipped': True, 'item': 'item2'} ] })
    var_1 = var_0.is_skipped()
    assert var_1 == True
    var_2 = {}
    var_3 = TaskResult(None, None, { 'results': [ {'skipped': False, 'item': 'item1'}, {'skipped': True, 'item': 'item2'} ] })
    var_4 = var_3.is_skipped()
    assert var_4 == False
    var_5 = {}

# Generated at 2022-06-24 19:19:52.813792
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_failed()
    assert var_1 == False


# Generated at 2022-06-24 19:19:55.627515
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:20:04.510783
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()
    var_2 = {'_ansible_verbose_always': False, '_ansible_no_log': False, '_ansible_item_result': True}
    if (not (var_1._result == var_2)):
        raise AssertionError("%s != %s" % (var_1._result, var_2))


# Generated at 2022-06-24 19:20:07.166686
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.is_skipped()


# Generated at 2022-06-24 19:20:11.836808
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_1, var_0)
    var_2 = task_result_0.is_skipped()
    print(var_2)

# Generated at 2022-06-24 19:20:14.592820
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = task_result_0.is_failed()


# Generated at 2022-06-24 19:20:24.133164
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = 'changed'
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = 'unreachable'
    task_result_1 = TaskResult(var_0, var_0, var_0)
    var_0 = 'failed_when_result'
    task_result_2 = TaskResult(var_0, var_0, var_0)
    var_0 = 'results'
    task_result_3 = TaskResult(var_0, var_0, var_0)
    value_0 = task_result_0.is_failed()
    value_1 = task_result_1.is_failed()
    value_2 = task_result_2.is_failed()
    value_3 = task_result_3.is_failed()



# Generated at 2022-06-24 19:20:27.491914
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert var_0 == task_result_0.is_failed()


# Generated at 2022-06-24 19:20:42.235003
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    debugger = 'on_failed'
    globally_enabled = False
    # FIXME: assert not test_TaskResult_needs_debugger
    # assert test_TaskResult_needs_debugger


# Generated at 2022-06-24 19:20:44.856830
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_result_1 = test_case_0()

    try:
        assert isinstance(
            task_result_1.clean_copy(),
            TaskResult,
        ) == True
    except AssertionError:
        raise AssertionError("TaskResult object did not cleanly copy.")

# Generated at 2022-06-24 19:20:51.740635
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_1 = task_result_0.clean_copy()
    var_7 = task_result_1._result
    var_8 = task_result_1._result
    var_9 = task_result_0._result
    if (var_9 == var_8):
        print("true")
    else:
        print("false")
    var_10 = task_result_0._result
    if (var_10 == var_9):
        print("true")
    else:
        print("false")
    return task_result_1


# Generated at 2022-06-24 19:20:54.714736
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = TaskResult({}, {}, {})
    assert var_0.clean_copy()

# Generated at 2022-06-24 19:20:57.151837
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    methodResult = task_result_1.clean_copy()
    assert methodResult == None

# Generated at 2022-06-24 19:20:57.947300
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()


# Generated at 2022-06-24 19:21:01.663612
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_0 = TaskResult(var_0, var_0, var_0, {'name': 'test_TaskResult_needs_debugger'})
    var_1 = True
    var_0 = var_0.needs_debugger(var_1)


# Generated at 2022-06-24 19:21:08.096474
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_0 = TaskResult('ssh://127.0.0.1:2222', 'ssh://127.0.0.1:2222', 'ssh://127.0.0.1:2222')
    var_0 = task_result_0.needs_debugger()
    _debugger = 'ssh://127.0.0.1:2222'

    # AssertionError: <false> is not true
    assert var_0 is True


# Generated at 2022-06-24 19:21:11.059840
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.is_failed()



# Generated at 2022-06-24 19:21:14.134577
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result = task_result_0.clean_copy()
    assert True


# Generated at 2022-06-24 19:21:23.255681
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    ret = task_result_0.needs_debugger()
    assert ret is False
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 19:21:27.075153
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = {}
    task_result_0 = TaskResult(var_1, var_1, var_1)
    var_2 = False
    var_3 = task_result_0.needs_debugger(var_2)


# Generated at 2022-06-24 19:21:31.567878
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = 'stdout'
    var_1 = 'stdout'
    var_2 = 'stdout'
    var_3 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:21:35.936443
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    globally_enabled = True
    try:
        task_result_0.needs_debugger(globally_enabled)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:21:39.656411
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    #var_0 = {}
    #task_result_0 = TaskResult(var_0, var_0, var_0)
    #assert task_result_0.clean_copy().get("_ansible_no_log")
    pass


# Generated at 2022-06-24 19:21:42.820776
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    try:
        test = task_result_1.is_failed()
    except Exception as err:
        test = err
    assert isinstance(test, bool)


# Generated at 2022-06-24 19:21:44.320533
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    print('Testing is_failed')
    from ansible.parsing.dataloader import DataLoader



# Generated at 2022-06-24 19:21:48.946186
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
  var_0 = {}
  var_1 = {}
  task_result_0 = TaskResult(var_0, var_1, var_0)
  # Check if the function returns a boolean value
  assert isinstance(task_result_0.needs_debugger(False), bool)


# Generated at 2022-06-24 19:21:58.641315
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    '''
    Test is_skipped
    '''

    my_var = {}
    my_var['_ansible_verbose_always'] = False
    my_var['_ansible_no_log'] = False
    my_var['_ansible_item_label'] = False
    my_var['_ansible_verbose_override'] = False
    my_var['changed'] = False
    my_var['rc'] = 0
    my_var['stderr'] = ''
    my_var['stderr_lines'] = ['']
    my_var['stdout'] = '''
'''
    my_var['stdout_lines'] = ['', '']

# Generated at 2022-06-24 19:22:00.764539
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_0 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:22:19.735025
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    print("Test starts!")
    var_1 = {"debugger": "on_failed"}
    var_2 = {"ignore_errors": True}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    task_result_1 = TaskResult(var_1, var_1, var_1, task_fields=var_2)
    task_result_1.is_skipped()
    task_result_1.is_unreachable()
    task_result_1.is_changed()
    task_result_1.is_failed()
    task_result_1.needs_debugger(globally_enabled=True)
    print("Test ends!")

if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:22:22.855633
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_case_0()



# Generated at 2022-06-24 19:22:32.034024
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    # TASK FAILURE REPSONS
    # 1) an exception occurred on the controller:
    #    this is represented by a task result with the KEY 'exception'
    #    in the dictionary, which contains a string from the exception
    # 2) the task marked itself failed:
    #    this is represented by a task result with the KEY 'failed'
    #    whose value is a boolean True
    # 3) the task is failed_when and the failed_when condition is true
    #    this is represented by a task result with the KEY 'failed_when_result'
    #    whose value is a boolean True

    entry_point_0 = {}
    entry_point_0['failed'] = True

    # 1) "failed"

# Generated at 2022-06-24 19:22:34.839065
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result = task_result_0.clean_copy()


# Generated at 2022-06-24 19:22:38.009500
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.needs_debugger()
    task_result_0.needs_debugger(var_1)

# Generated at 2022-06-24 19:22:48.045660
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)

    # Check for the case where result is not a dict
    if task_result_0._check_key('failed') == True and \
       task_result_0._check_key('failed') == True and \
       task_result_0._check_key('failed') == False:
        print("Test Passed")
        # Check if 'failed' is not a key, but the field is not empty and all the values are True
        # or if 'failed' is in the key, and the value is True

# Generated at 2022-06-24 19:22:51.623521
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import mock

    m = mock.Mock()

    instance = m.return_value

    assert isinstance(m().clean_copy(), object)


# Generated at 2022-06-24 19:22:55.153951
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = None
    needs_debugger_retval_0 = task_result_0.needs_debugger(var_1)


# Generated at 2022-06-24 19:22:56.516415
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():  

    # call test case
    test_case_0()

# Generated at 2022-06-24 19:22:59.411959
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_4 = task_result_0.clean_copy()

# Generated at 2022-06-24 19:23:10.360014
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = True
    result_0 = task_result_0.needs_debugger(var_1)
    print(result_0)

# Generated at 2022-06-24 19:23:17.889892
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    var_3 = {}
    task_result_0._result = var_3
    # Workaround for bug #2409
    var_4 = task_result_0.clean_copy()
    var_5 = {}
    var_6 = {}
    task_result_0._result = var_6
    task_result_0._task = var_5
    # Workaround for bug #2409
    var_7 = task_result_0.clean_copy()
    var_8 = {}
    var_9 = {}
    task_result_0._task = var_8
    task_result_0._task_fields = var_9
   

# Generated at 2022-06-24 19:23:21.069215
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    string_0 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:25.100431
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = True
    var_2 = task_result_0.needs_debugger(var_1)


if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:23:28.107052
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    # setup and call the test
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_1 = task_result_0.clean_copy()

    # check the results
    assert(task_result_1)

# Generated at 2022-06-24 19:23:29.056678
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()



# Generated at 2022-06-24 19:23:33.493050
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    globally_enabled_0 = True
    res = task_result_0.needs_debugger(globally_enabled_0)
    assert res is False


# Generated at 2022-06-24 19:23:36.805954
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    test_TaskResult_clean_copy_fixture_0(var_0, task_result_0)


# Generated at 2022-06-24 19:23:39.316156
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:23:46.934490
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_0 = {}
    var_1 = {}
    var_2 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    task_result_1 = task_result_0.clean_copy()
    assert task_result_0._result == task_result_1._result
    assert task_result_0._task == task_result_1._task
    assert task_result_0._host == task_result_1._host



# Generated at 2022-06-24 19:24:08.526469
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)

    result_1 = task_result_1.is_failed()
    assert result_1


# Generated at 2022-06-24 19:24:12.273840
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result = task_result_0.needs_debugger(False)
    assert result == False, 'Failed task_result_0.needs_debugger(False) is False'


# Generated at 2022-06-24 19:24:14.533004
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    print(task_result_0.clean_copy())


# Generated at 2022-06-24 19:24:20.444397
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    vars = {}
    task_result = TaskResult(vars, vars, vars)
    task_result._result = {'failed': 's'}
    assert task_result.is_failed() == 's'



# Generated at 2022-06-24 19:24:28.928102
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    
    var_1 = {}
    var_2 = {}
    task_result_1 = TaskResult(var_1, var_2, var_1)
    assert(task_result_1.is_failed() == False)
    var_3 = {}
    var_3['failed'] = True
    task_result_2 = TaskResult(var_1, var_2, var_3)
    assert(task_result_2.is_failed() == True)
    task_result_3 = TaskResult(var_1, var_2, var_1)
    assert(task_result_3.is_failed() == False)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-24 19:24:36.627714
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    var_3 = {}
    var_4 = {}
    var_5 = {}
    task_result_1 = TaskResult(var_3, var_4, var_5)
    var_6 = {}
    var_7 = {}
    var_8 = {}
    task_result_2 = TaskResult(var_6, var_7, var_8)
    var_9 = {}
    var_10 = {}
    var_11 = {}
    task_result_3 = TaskResult(var_9, var_10, var_11)
    var_12 = {}
    var_13 = {}
    var_14 = {}
    task

# Generated at 2022-06-24 19:24:38.941270
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert task_result_0.needs_debugger()

# Generated at 2022-06-24 19:24:43.894181
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = {}
    var_2 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    task_result_1.needs_debugger(False)


if __name__ == '__main__':
    test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:24:47.003184
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.needs_debugger()



# Generated at 2022-06-24 19:24:49.729502
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:03.500616
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    obj_0 = TaskResult(var_0, var_0, var_0)
    method_ret_0 = obj_0.is_failed()
    assert method_ret_0 == False



# Generated at 2022-06-24 19:25:12.921695
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields_0 = {}
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0, task_fields_0)
    assert not task_result_0.needs_debugger()

    task_fields_1 = {'debugger': 'always'}
    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1, task_fields_1)
    assert task_result_1.needs_debugger()

    task_fields_2 = {'debugger': 'on_failed', 'ignore_errors': True}
    var_2 = {}
    task_result_2 = TaskResult(var_2, var_2, var_2, task_fields_2)
    assert not task_result_2.needs_

# Generated at 2022-06-24 19:25:14.889884
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:18.034629
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.is_failed(var_0)


if __name__ == "__main__":
    test_TaskResult_is_failed()

# Generated at 2022-06-24 19:25:23.374189
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import unittest2
    import sys
    import random
    import tempfile
    import shutil
    import os

    class Test_TaskResult(unittest2.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_clean_copy(self):
            for i in range(100):
                with self.subTest(i=i):
                    self.assertNotEqual(random.choice([False, True]), random.choice([False, True]))

            with self.subTest(i='_task'):
                var_0 = {}
                task_result_0 = TaskResult(var_0, var_0, var_0)
                ret_0 = task_result

# Generated at 2022-06-24 19:25:29.104665
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    assert task_result_1.is_failed() == False



# Generated at 2022-06-24 19:25:33.764818
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:25:37.836624
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    result_0 = task_result_0.clean_copy()
    assert result_0 == {}


# Generated at 2022-06-24 19:25:41.342007
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    # Call method needs_debugger of class TaskResult
    var_1 = task_result_0.needs_debugger(var_0)

# Generated at 2022-06-24 19:25:44.891246
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    _1 = task_result_0.clean_copy()
    assert _1 is not None, '_1'

test_case_0()
test_TaskResult_clean_copy()

# Generated at 2022-06-24 19:26:05.952977
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    task_result_1 = TaskResult(var_1, var_2, var_3)
    var_4 = {}
    assert task_result_1.needs_debugger(var_4)
    var_5 = {}
    var_6 = {}
    var_7 = {}
    task_result_2 = TaskResult(var_5, var_6, var_7)
    var_8 = {}
    assert task_result_2.needs_debugger(var_8)
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    task_result_3 = TaskResult(var_9, var_10, var_11)
    var_13 = {}
    assert task

# Generated at 2022-06-24 19:26:08.052773
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    var_1 = TaskResult(var_0, var_0, var_0)
    assert(var_1.is_failed() == False)


# Generated at 2022-06-24 19:26:12.727921
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {}
    var_1 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_2 = task_result_0.is_failed()
    assert var_2 == False, "value of var_2, returned from task_result_0.ask() is False."


# Generated at 2022-06-24 19:26:13.998193
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    test_case_0()
    assert True

# Generated at 2022-06-24 19:26:16.811305
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_0 = Task.Task()
    task_result_0 = TaskResult(var_0, task_0, var_0)


# Generated at 2022-06-24 19:26:19.447197
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    ret = task_result_0.clean_copy()



# Generated at 2022-06-24 19:26:24.008658
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # From the documentation:
    # Checks if the task should be debugged, based on the task's `debugger` attribute,
    # the global ansible configuration option TASK_DEBUGGER_ENABLED, and the current
    # state of the task.
    # Returns True if we should stop and invoke the debugger.

    # Set up the mock objects
    my_task = Mock()
    my_task.get_name.return_value = 'my_task'
    my_task.action = 'debug'
    my_task.debugger = 'never'

    my_task_dict = {'name': 'my_task',
                    'debugger': 'never'}
    my_host = Mock()

    my_result = {'failed': False}

    # Don't use the debugger if the TASK_DEBUGGER_ENABLED

# Generated at 2022-06-24 19:26:33.540991
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    var_0 = {"failed": True}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    assert(task_result_0.is_failed() == True)
    var_1 = {"failed": False}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    assert(task_result_1.is_failed() == False)
    var_2 = {"failed": False, "results": [{"failed": True}]}
    task_result_2 = TaskResult(var_2, var_2, var_2)
    assert(task_result_2.is_failed() == True)
    var_3 = {"unreachable": True}
    task_result_3 = TaskResult(var_3, var_3, var_3)


# Generated at 2022-06-24 19:26:38.811636
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)
    var_1 = {}
    task_result_0.is_failed = mock_task_result_is_failed(var_1)
    var_2 = {}
    task_result_0.is_unreachable = mock_task_result_is_unreachable(var_2)
    var_3 = {}
    task_result_0._task_fields = {"debugger":var_3}
    task_result_0.needs_debugger()
    task_result_0._task_fields = {"ignore_errors":var_3}
    task_result_0.needs_debugger()

# Generated at 2022-06-24 19:26:43.348981
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    var_1 = {}
    var_2 = {}

    task_result_0 = TaskResult(var_0, var_1, var_2)
    task_result_0.clean_copy()

# Generated at 2022-06-24 19:27:10.622196
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result_1 = TaskResult({'foo': 'bar'}, {'foo': 'bar'}, {'foo': 'bar'})
    b_val_1 = task_result_1.needs_debugger(False)

    try:
        assert b_val_1 == False
        print("test case 0 ok")
    except AssertionError:
        print("test case 0 failed")

test_TaskResult_needs_debugger()

# Generated at 2022-06-24 19:27:12.212374
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert(False == test_case_0().is_failed())


# Generated at 2022-06-24 19:27:17.262689
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    test_case_0()
    var_1 = {}
    var_2 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    task_result_2 = TaskResult(var_2, var_2, var_2)
    assert(task_result_1.needs_debugger() == task_result_2.needs_debugger())


# Generated at 2022-06-24 19:27:20.618104
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    task_result_0.clean_copy()


# Generated at 2022-06-24 19:27:26.587906
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # var_0 is a dict:
    var_0 = {}
    # var_1 is a dict:
    var_1 = {}
    # var_2 is a dict:
    var_2 = {}
    # task_result_0 is a TaskResult:
    task_result_0 = TaskResult(var_0, var_1, var_2)
    # copy_0 is a TaskResult:
    copy_0 = task_result_0.clean_copy()
    assert isinstance(copy_0, TaskResult)


# Generated at 2022-06-24 19:27:29.844925
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = {}
    task_result_0 = TaskResult(var_0, var_0, var_0)

    var_1 = {}
    task_result_1 = TaskResult(var_1, var_1, var_1)
    #assert task_result_1.clean_copy() == task_result_0

# Generated at 2022-06-24 19:27:37.167781
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    var_0 = '_ansible_verbose_always'
    var_1 = '_ansible_ignore_errors'
    var_2 = '_ansible_no_log'
    var_3 = '_ansible_verbose_override'
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    task_result_0 = TaskResult(var_0, var_1, var_2)
    task_result_1 = TaskResult(var_3, var_4, var_5, task_fields=var_6)
    task_result_2 = TaskResult(var_4, var_4, var_4)
    assert task_result_1.needs_debugger(True)