

# Generated at 2022-06-22 20:25:34.411604
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult

    task = Task()
    host = 'test'
    task_fields = {'name': 'test_name', 'ignore_errors': False, 'debugger': None}
    return_data = {'invocation': {'module_args': 'test_args'}, 'failed_when_result': False, 'results': [{'skipped': True}]}

    task_result = TaskResult(host, task, return_data, task_fields)
    task_result_copy = task_result.clean_copy()

    assert task_result_copy._task_fields == task_fields
    assert task_result_copy._task == task
    assert task_result_copy._host == host

# Generated at 2022-06-22 20:25:44.126620
# Unit test for constructor of class TaskResult
def test_TaskResult():
    '''test TaskResult class constructor'''

    return_data = dict(changed=True,
                       failed=False,
                       skipped=False,
                       unreachable=False,
                       returncode=0,
                       module_stdout="test-stdout",
                       module_stderr="test-stderr")

    tr = TaskResult('hostname', dict(name='test-task'), return_data)

    assert tr
    assert tr.is_changed()
    assert not tr.is_failed()
    assert not tr.is_unreachable()
    assert not tr.is_skipped()
    assert tr.clean_copy()

# Generated at 2022-06-22 20:25:55.075878
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    '''The method TaskResult::needs_debugger returns True if the global debugger is enabled
    and one of the following condition is true
    - Task has failed and ignore_errors is not set
    - Task is unreachable
    - Task has debugger set to always
    - Task has debugger set to on_failed and task has failed and ignore_errors is not set
    - Task has debugger set to on_unreachable and task is unreachable
    - Task has debugger set to on_skipped and task is skipped

    The method returns False in all other cases.
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult

   

# Generated at 2022-06-22 20:26:02.266534
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    from ansible.playbook.task import Task

    task = Task()
    task.set_loader(DataLoader())
    task_fields = {}

# Generated at 2022-06-22 20:26:09.297085
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    from ansible.playbook.task import Task

    task1 = Task()
    task1.action = 'shell'
    task1.args['_ansible_verbose_always'] = True
    task1.args['_ansible_no_log'] = True
    task1.name = 'task1'

    result1 = TaskResult('mockhost', task1, {'results': [{'skipped': True}, {'skipped': True}]})
    assert result1.is_skipped()

    result2 = TaskResult('mockhost', task1, {'results': [{'skipped': True}, {'skipped': False}]})
    assert not result2.is_skipped()

    result3 = TaskResult('mockhost', task1, {'skipped': True})
    assert result3.is_

# Generated at 2022-06-22 20:26:19.071741
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields = dict()
    host = dict()
    task = dict()
    return_data = dict()
    result = TaskResult(host, task, return_data, task_fields)

    # failed=True, unreachable=False, ignore_errors=False, debugger=False
    task_fields['ignore_errors'] = False
    host['failed'] = True
    host['unreachable'] = False
    task['debugger'] = False
    assert result.needs_debugger() == False
    assert result.needs_debugger(True) == True

    # failed=True, unreachable=False, ignore_errors=False, debugger=always
    task_fields['ignore_errors'] = False
    host['failed'] = True
    host['unreachable'] = False
    task['debugger'] = 'always'

# Generated at 2022-06-22 20:26:25.131387
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    task = DummyTask(action='ping')

    host = DummyHost(name='localhost')

    result = {'msg': 'pong'}
    task_result = TaskResult(host, task, result)
    assert not task_result.is_unreachable()

    result = {'msg': 'pong', 'unreachable': True}
    task_result = TaskResult(host, task, result)
    assert task_result.is_unreachable()

    result = {'results': [{'msg': 'pong'}, {'msg': 'pong', 'unreachable': True}]}
    task_result = TaskResult(host, task, result)
    assert task_result.is_unreachable()



# Generated at 2022-06-22 20:26:34.562646
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    ''' 
    Testing method is_failed of class TaskResult
    '''
    host = "test.example.com"
    task = object
    return_data = dict()
    task_fields = dict()

    tr = TaskResult(host, task, return_data, task_fields)

    # Test is_failed with 'failed' set to True
    return_data = dict(failed=True)
    tr = TaskResult(host, task, return_data, task_fields)
    assert tr.is_failed() == True

    # Test is_failed with 'failed' set to False
    return_data = dict(failed=False)
    tr = TaskResult(host, task, return_data, task_fields)
    assert tr.is_failed() == False

    # Test is_failed with 'failed' not set
    return_

# Generated at 2022-06-22 20:26:46.055937
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    import ansible.playbook.task_include
    import ansible.playbook.task

    task = ansible.playbook.task_include.TaskInclude()

# Generated at 2022-06-22 20:26:55.515791
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    class MockTask:
        def __init__(self):
            self.name = 'module_name'
            self.action = 'module_action'
            self.ignore_errors = False
            self.no_log = False

    class MockHost:
        pass

    task = MockTask()
    host = MockHost()

    def test_single(result, debugger, ansible_verbose, ansible_verbose_override, ansible_no_log,
                    ignore_errors, globally_enabled, expected):
        task.debugger = debugger
        task.ignore_errors = ignore_errors
        task.no_log = ansible_verbose_override or ansible_no_log
        result['_ansible_verbose_always'] = ansible_verbose
        result['_ansible_verbose_override'] = ans

# Generated at 2022-06-22 20:27:05.258321
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    task = None
    host = "127.0.0.1"
    return_data = {u'stdout': u'', u'stdout_lines': [], u'changed': False, u'rc': 0, u'stderr': u'', u'invocation': {u'module_args': {u'name': u'vboxnet0', u'bridge_ports': u'enp0s8'}, u'module_name': u'nmcli'}, u'warnings': [u'* (dev) vboxnet0: new bridge device\n']}

    taskresult = TaskResult(host, task, return_data)
    assert taskresult.is_changed() == False


# Generated at 2022-06-22 20:27:14.093666
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # for loop tasks
    # loop tasks are only skipped if all the items are skipped

    # a loop task has any failed result
    failed_result = TaskResult('test_host', 'test_task', {'results':[{'failed':False}, {'failed':True}]})
    assert failed_result.is_skipped() == False

    # a loop task has no failed results but all items are skipped
    skipped_result = TaskResult('test_host', 'test_task', {'results':[{'failed':False}, {'skipped':True}]})
    assert skipped_result.is_skipped() == True

    # a loop task has no failed results and some items are not skipped

# Generated at 2022-06-22 20:27:19.042628
# Unit test for constructor of class TaskResult
def test_TaskResult():
    host = object()
    task = object()
    return_data = object()
    task_fields = object()

    tr = TaskResult(host, task, return_data, task_fields)
    assert(tr._host is host)
    assert(tr._task is task)
    assert(tr._result is return_data)
    assert(tr._task_fields is task_fields)


# Generated at 2022-06-22 20:27:24.647745
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    '''
    Ensure that the method is_skipped is properly reporting when a task has been skipped.
    '''
    task = { 'name': 'test'}
    data = { 'results': [{ 'skipped': True, '_ansible_item_result': True }, {'_ansible_item_result': True}]}
    assert TaskResult('test', task, data).is_skipped()

    data = { 'results': [{ 'skipped': False, '_ansible_item_result': True }, {'_ansible_item_result': True}]}
    assert not TaskResult('test', task, data).is_skipped()

    data = {'results': [{'_ansible_item_result': True}, {'_ansible_item_result': True}]}

# Generated at 2022-06-22 20:27:32.460740
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    class FakeTask:
        def __init__(self):
            self.action = "debug"

    # Empty result should return False
    result = TaskResult("192.168.0.1", FakeTask(), {})
    assert result.is_changed() is False

    # Non-empty result without changed key should return False
    result = TaskResult("192.168.0.1", FakeTask(), {"a": "b"})
    assert result.is_changed() is False

    # Non-empty result with changed key should return True
    result = TaskResult("192.168.0.1", FakeTask(), {"a": "b", "changed": True})
    assert result.is_changed() is True


# Generated at 2022-06-22 20:27:44.622715
# Unit test for constructor of class TaskResult
def test_TaskResult():
    import pytest
    action_name = 'set_fact'
    action_data = '{}'
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    task = Task()
    task.set_loader(None)
    task._parent = Block()
    task._parent.set_loader(None)
    task.action = action_name
    task._parent.name = 'test_block'
    task.name = action_name

    host = 'test_host'
    return_data = 'test_data'
    task_fields = dict()
    test_task_result = TaskResult(host, task, return_data, task_fields)
    assert test_task_result._task is not None
    assert test_task_result._result == return_data
    assert test_

# Generated at 2022-06-22 20:27:56.959891
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    host = None
    task = None
    task_fields = {}
    return_data = {}

    result = TaskResult(host, task, return_data, task_fields=task_fields)

    # test global_debugger_on
    assert(result.needs_debugger( True ) == False )

    # test fail without ignore_errors
    task_fields['debugger'] = None
    return_data['failed'] = True
    return_data['unreachable'] = False
    return_data['skipped'] = False
    result = TaskResult(host, task, return_data, task_fields=task_fields)
    assert(result.needs_debugger( True ) == True )

    # test fail with ignore_errors 
    task_fields['ignore_errors'] = True
    return_data['failed'] = True
    return

# Generated at 2022-06-22 20:28:06.832907
# Unit test for constructor of class TaskResult
def test_TaskResult():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # create Task object
    TaskObj = Task()
    TaskObj._role = None
    TaskObj.action = 'shell'
    TaskObj.args['creates'] = None
    TaskObj.args['chdir'] = None
    TaskObj.args['removes'] = None
    TaskObj.args['executable'] = None
    TaskObj.args['warn'] = True
    TaskObj.args['creates'] = None
    TaskObj.args['chdir'] = None
    TaskObj.args['removes'] = None
    TaskObj.args['executable'] = None
    TaskObj.args['_raw_params'] = 'uptime'

# Generated at 2022-06-22 20:28:17.841157
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task = dict(name = "test_is_skipped")
    task_fields = dict(name = "test_is_skipped")
    # Test for return value False, 'skipped' is not in _result
    return_data = dict(msg='skipped', skipped=False)
    task_result = TaskResult('host', task, return_data, task_fields)
    assert task_result.is_skipped() == False

    # Test for return value True, 'skipped' is in _result
    return_data = dict(msg='skipped', skipped=True)
    task_result = TaskResult('host', task, return_data, task_fields)
    assert task_result.is_skipped() == True

    # Test for return value True, 'skipped' is in results and all items are skipped

# Generated at 2022-06-22 20:28:27.229967
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    class TestHost:
        def __init__(self, name):
            self._name = name
    # test with a wrong task value
    host = TestHost('local')
    task_fields = {'task': 'fake'}
    return_data = {}
    result = TaskResult(host, task_fields, return_data)
    assert result.is_unreachable() is False
    # test with a task value of setup
    task_fields = {'task': 'setup'}
    return_data = {}
    result = TaskResult(host, task_fields, return_data)
    assert result.is_unreachable() is False
    # test with a wrong return_data value
    task_fields = {'task': 'fake'}
    return_data = {'unreachable': False}

# Generated at 2022-06-22 20:28:37.073431
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # This unit test can be used to test both fail_when_result and fail/failed flags in result
    # as it will return True if any of the flag is set to True
    result = {"failed_when_result": True}
    expected = True
    task_fields = None
    task = None
    task_result = TaskResult("test_host", task, result, task_fields)
    assert task_result.is_failed() == expected
    result = {"failed": True}
    task_result = TaskResult("test_host", task, result, task_fields)
    assert task_result.is_failed() == expected
    result = {"failed": False}
    task_result = TaskResult("test_host", task, result, task_fields)

# Generated at 2022-06-22 20:28:42.718644
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    # create an unreachable TaskResult
    task = 'shell'
    host = 'localhost'
    task_fields = {'name': 'foo'}
    return_data = {'unreachable': True}
    taskResult = TaskResult(host, task, return_data, task_fields)

    # test whether it is unreachable
    assert taskResult.is_unreachable() == True


# Generated at 2022-06-22 20:28:47.859976
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():

    taskresult = TaskResult("localhost", None, { "ignore_errors": True, "unreachable": True })
    assert taskresult.is_unreachable() is False

    taskresult = TaskResult("localhost", None, { "ignore_errors": False, "unreachable": True })
    assert taskresult.is_unreachable() is True

    taskresult = TaskResult("localhost", None, { })
    assert taskresult.is_unreachable() is False



# Generated at 2022-06-22 20:28:56.135989
# Unit test for constructor of class TaskResult
def test_TaskResult():
    host = '192.168.1.1'
    task = AnsibleTask(None)
    fields = dict()
    fields['name'] = 'task_result'
    fields['ignore_errors'] = True
    fields['debugger'] = 'on_failed'
    return_data = dict()
    return_data['unreachable'] = False
    return_data['results'] = [dict(), dict(), dict()]
    return_data['results'][0]['changed'] = False
    return_data['results'][1]['changed'] = False
    return_data['results'][2]['changed'] = False
    return_data['results'][0]['failed'] = False
    return_data['results'][1]['failed'] = True
    return_data['results'][2]['failed'] = True
    return

# Generated at 2022-06-22 20:29:00.298941
# Unit test for constructor of class TaskResult
def test_TaskResult():
    class Task:
        name = 'test'
        action = 'setup'
        no_log = False

    # Without argument return_data
    task_result = TaskResult(None, Task(), {})
    assert task_result._result == {}

    # With argument return_data
    return_data = {'failed': True}
    task_result = TaskResult(None, Task(), return_data)
    assert task_result._result == return_data
    assert task_result.is_failed()

    # With argument task_fields
    task_fields = {'name': 'setup_test'}
    task_result = TaskResult(None, Task(), return_data, task_fields)
    assert task_result.task_name == 'setup_test'

# Generated at 2022-06-22 20:29:12.178609
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    assert not TaskResult(None, {"changed": False}, None).is_failed()
    assert not TaskResult(None, {}, None).is_failed()
    assert not TaskResult(None, {"failed_when_result": False}, None).is_failed()
    assert     TaskResult(None, {"failed_when_result": True}, None).is_failed()
    assert not TaskResult(None, {"results": [{"failed_when_result": False}]}, None).is_failed()
    assert     TaskResult(None, {"results": [{"failed_when_result": True}]}, None).is_failed()
    assert not TaskResult(None, {"results": [{"failed_when_result": False}, {"failed_when_result": False}]}, None).is_failed()

# Generated at 2022-06-22 20:29:23.516808
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = '192.168.0.1'
    task = None
    task_fields = None

    return_data = [{'item': 'sample', 'changed': True, 'skipped': True},
                   {'item': 'sample', 'changed': False, 'skipped': False},
                   {'changed': True, 'skipped': False},
                   {'changed': False, 'skipped': False}]

    result = TaskResult(host, task, return_data, task_fields)

    assert result.is_skipped() == True


# Generated at 2022-06-22 20:29:31.719875
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    task = None
    return_data = {u'changed': True}
    task_fields = {u'name': u'replace'}
    # case 1
    task_result1 = TaskResult(None, task, return_data, task_fields)
    assert task_result1.is_changed()

    # case2
    return_data[u'changed'] = False
    task_result2 = TaskResult(None, task, return_data, task_fields)
    assert not task_result2.is_changed()



# Generated at 2022-06-22 20:29:41.166078
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_fields = {'name': 'test', 'ignore_errors': False, 'debugger': 'auto'}
    host = 'test'
    task = 'test'
    return_data = [
        {'item': 'a', 'skipped': False},
        {'item': 'b', 'skipped': True},
    ]
    assert TaskResult(host, task, return_data, task_fields).is_skipped() is False

    return_data = [
        {'item': 'a', 'skipped': True},
        {'item': 'b', 'skipped': True},
    ]
    assert TaskResult(host, task, return_data, task_fields).is_skipped() is True

    return_data = 'test'

# Generated at 2022-06-22 20:29:43.102767
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    task_result = TaskResult(None, None, {'changed': True})
    assert task_result.is_changed() == True
    task_result = TaskResult(None, None, {})
    assert task_result.is_changed() == False


# Generated at 2022-06-22 20:29:54.428015
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # data
    host = '127.0.0.1'
    task = {"name": "test", "action": "setup"}
    task_fields = dict()

    # return data
    return_data = {"_ansible_verbose_always": True, "changed": False, "invocation": {"module_args": {"paths": [], "gather_subset": "all"}}, "failed": True, "item": "all"}

    # create TaskResult
    r = TaskResult(host, task, return_data, task_fields)

    # call clean_copy
    copy = r.clean_copy()

    assert copy._result == {'failed': True}


# Generated at 2022-06-22 20:30:01.317936
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    #Init
    host = "test_host"
    task = "test_task"
    return_data = ""
    task_fields = "test_task_fields"
    task_result = TaskResult(host, task, return_data, task_fields)

    if task_result.is_failed():
        # print("test_TaskResult_is_failed failed")
        assert True

    # if task_result.is_failed():
    #     raise AssertionError("test_TaskResult_is_failed failed")

# Generated at 2022-06-22 20:30:13.353533
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskExecutor
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-22 20:30:24.994105
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # return value of true in case failed_when_result is present in results
    assert TaskResult(None, None, {'failed_when_result': True}, {}).is_failed() == True
    # return value of false in case failed_when_result is absent in results
    assert TaskResult(None, None, {'failed_when_result': False}, {}).is_failed() == False
    # return value of true in case failed_when_result is present in results of items
    assert TaskResult(None, None, {'results': [{'failed_when_result': True}]}, {}).is_failed() == True
    # return value of false in case failed_when_result is absent in results of items
    assert TaskResult(None, None, {'results': [{'failed_when_result': False}]}, {}).is_failed()

# Generated at 2022-06-22 20:30:29.174117
# Unit test for constructor of class TaskResult
def test_TaskResult():
    host = 'test_host'
    task = 'test_task'
    return_data = {'status':'ok', 'data':'test_data'}
    task_fields = 'test_fields'
    result = TaskResult(host, task, return_data, task_fields)
    assert result._host == host
    assert result._task == task
    assert result._result == return_data
    assert result._task_fields == task_fields


# Generated at 2022-06-22 20:30:41.687896
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import unittest
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.plugins.action.normal import ActionModule

    class TestHost:
        name = 'test'

    class TestTask:
        name = 'TestTask'
        action = 'debug'
        ignore_errors = True
        no_log = True

        class action_plugin_class(ActionModule):
            pass

    class TestTaskResult:

        _host = TestHost()
        _task = TestTask()
        _result = AnsibleMapping(dict(
            failed=False,
            unreachable=False,
            skipped=False,
            failed_when_result=False
        ))

# Generated at 2022-06-22 20:30:51.047095
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # TaskResult._result is a dict with a key 'failed_when_result'
    assert TaskResult(None, None, {'failed_when_result': True}).is_failed() == True
    assert TaskResult(None, None, {'failed_when_result': False}).is_failed() == False

    # TaskResult._result is a dict with a key 'failed'
    assert TaskResult(None, None, {'failed': True}).is_failed() == True
    assert TaskResult(None, None, {'failed': False}).is_failed() == False

    # TaskResult._result is a dict with a key 'results' and it is a list of
    # dict like {'failed_when_result': True}

# Generated at 2022-06-22 20:30:55.672786
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    task_result = TaskResult(None, None, {'unreachable': True})
    assert task_result.is_unreachable()

    task_result = TaskResult(None, None, {'changed': True})
    assert not task_result.is_unreachable()

# Generated at 2022-06-22 20:31:03.696781
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    test_result = TaskResult(None, None, {'unreachable': True})
    assert test_result.is_unreachable()

    test_result = TaskResult(None, None, {'unreachable': False})
    assert not test_result.is_unreachable()

    results = [{ 'unreachable': False }, { 'unreachable': True }]
    test_result = TaskResult(None, None, {'results': results})
    assert test_result.is_unreachable()



# Generated at 2022-06-22 20:31:13.113548
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task import Task

    task_name = 'Dummy'
    host_name = 'localhost'
    changed = False
    result = {'changed': changed}
    task_fields = {'name': task_name}
    task = Task()
    task.name = task_name
    task_result_obj = TaskResult(host_name, task, result, task_fields)

    assert(task_result_obj.is_changed() == changed)
    assert(task_result_obj.task_name == task_name)


# Generated at 2022-06-22 20:31:21.617434
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    host = 'host1'
    task = 'task1'
    return_data = {'changed': False, 'failed': True, 'skipped': False}
    task_fields = dict()
    taskresult = TaskResult(host, task, return_data, task_fields)
    assert not taskresult.is_changed()
    return_data = {'changed': True, 'failed': False, 'skipped': False}
    taskresult = TaskResult(host, task, return_data, task_fields)
    assert taskresult.is_changed()


# Generated at 2022-06-22 20:31:32.854192
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    # task result with no changed field
    result = {
        'parsed': True,
        '_ansible_verbose_always': False,
        '_ansible_no_log': False,
        'invocation': {
            'module_name': 'setup',
            'module_args': {
                'filter': '*'
            }
        }
    }
    task = None
    task_result = TaskResult(None, task, result)
    assert task_result.is_changed() == False
    # task result with changed field equal to True

# Generated at 2022-06-22 20:31:40.268359
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = {'results': [{'item': 'a', 'skipped': False}, {'item': 'b', 'skipped': True}, {'item': 'c', 'skipped': False}, {'item': 'd', 'skipped': True}], '_ansible_item_label': 'item', '_ansible_no_log': False, 'changed': False, 'ansible_facts': {'discovered_interpreter_python': '/bin/python'}, '_ansible_verbose_override': False}
    assert TaskResult(None, None, result).is_skipped()

# Generated at 2022-06-22 20:31:46.475679
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    host1 = 'host1'
    task = 'task'
    # Test 1
    return_data = {"res1":"true"}
    task_fields = 'task_fields1'
    task_result = TaskResult(host1, task, return_data, task_fields)
    assert task_result.is_changed()

# Generated at 2022-06-22 20:31:55.778592
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    # First, create a basic task result dict
    result_dict = dict()
    result_dict['changed'] = False
    result_dict['unreachable'] = True
    result_dict['_ansible_no_log'] = False
    result_dict['_ansible_item_result'] = True
    result_dict['_ansible_verbose_override'] = True
    result_dict['_ansible_ignore_errors'] = True
    result_dict['_ansible_result_var'] = True
    result_dict['_ansible_parsed'] = True
    result_dict['_ansible_delegated_vars'] = dict()

    # Initilize an instance of the TaskResult class
    result_obj = TaskResult(None, None, result_dict)

    # Run the clean_copy method, get

# Generated at 2022-06-22 20:32:04.053617
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    r = {
        "msg": "Task 'hello world' skipped due to conditional check",
        "skipped": True,
        "skip_reason": "Conditional check failed"
    }
    task = TaskResult('example.org', None, r)
    assert task.is_skipped() is True
    r = {"msg": "Task 'hello world' skipped due to conditional check"}
    task = TaskResult('example.org', None, r)
    assert task.is_skipped() is False
    r = {"msg": "Task 'hello world' failed due to conditional check"}
    task = TaskResult('example.org', None, r)
    assert task.is_skipped() is False
    # test loop_result

# Generated at 2022-06-22 20:32:10.107327
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.plugins.action import ActionBase

    class FakeAction(ActionBase):
        def run(self, connection, tmp=None, task_vars=None):
            self._task.args['log'] = 'Something\n'

            return {
                'failed': True,
                'invocation': {
                    'module_args': self._task.args,
                },
                'parsed': True,
                'msg': 'task failed'
            }

    action = FakeAction(task=dict(args=dict()), connection=None, tempdir=None)
    task_fields = dict(name='fake task')
    result = TaskResult(host='fake host', task=action, return_data=action.run(), task_fields=task_fields)

    # with log in result
    result_clean_copy = result.clean

# Generated at 2022-06-22 20:32:21.117785
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    is_changed = False
    is_skipped = False
    is_failed = False
    is_unreachable = False
    is_censored = False
    is_attempts = False
    is_changed_after_censored = False
    is_failed_after_censored = False
    is_attempts_after_censored = False

    host = "host"
    task = "task"
    return_data = {
        "changed": True,
        "skipped": True,
        "failed": True,
        "unreachable": True,
        "censored": "censored",
        "attempts": 2,
        "something_else": "something_else",
        "_ansible_no_log": True,
        "invocation": "invocation"
    }


# Generated at 2022-06-22 20:32:32.548238
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.task import Task

    t = Task()
    t.set_name('test_task')
    t.set_action('test_action')
    t.set_args({'a': 'test_content'})
    t.set_only_if('test_only_if')
    t.set_notify('test_notify')
    t.set_delegate_to('test_delegate_to')
    t.set_delegate_facts(True)
    t.set_local_action(True)
    t.set_transport('local')
    t.set_loop('test_loop')
    t.set_first_available_file('test_file')
    t.set_first_available_file('test_file')


# Generated at 2022-06-22 20:32:39.729377
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    _ld = DataLoader()

    _host = "127.0.0.1"

    # Test result with 'failed' key
    _result = _ld.load("""{ "failed": true }""")
    _task_fields = {}
    _task = None
    _t = TaskResult(_host, _task, _result, _task_fields)
    assert _t.is_failed()

    # Test result with 'failed' key and 'failed_when_result'
    _result = _ld.load("""{ "failed": true, "failed_when_result": true }""")
    _task_fields = {}
    _task = None
    _t = TaskResult(_host, _task, _result, _task_fields)
    assert _t.is_failed()

    # Test result with 'failed' key and 'failed

# Generated at 2022-06-22 20:32:49.872804
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task_fields = {
        'name': 'test name'
    }
    _result = {
        'failed': False,
        'changed': False,
        'invocation': {
            'module_args': {
                'a': 10,
                'b': 20,
                'c': 'abc',
                'd': True
            }
        },
        'ansible_facts': {
            'e': 'xyz'
        }
    }
    task = {
        'name': 'test name',
        'no_log': False,
        'action': 'test action'
    }
    host = '127.0.0.1'
    result = TaskResult(host, task, _result, task_fields)
    clean_copy = result.clean_copy()
    assert clean_copy.is_changed

# Generated at 2022-06-22 20:32:57.077261
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    host = '127.0.0.1'
    task = dict()
    return_data = dict(changed=True)
    task_fields = dict()
    result = TaskResult(host, task, return_data, task_fields)
    assert result.is_changed()
    return_data = dict(changed=False)
    result = TaskResult(host, task, return_data, task_fields)
    assert not result.is_changed()


# Generated at 2022-06-22 20:33:05.693428
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import unittest

    class TestTaskResult_clean_copy(unittest.TestCase):
        def test_clean_copy(self):
            # task and host are both unused by clean_copy, so we pass in dummy values
            host = "dummy_host"
            task = "dummy_task"

            # test with no_log = False
            input = {"changed": True, "failed": False, "failed_when_result": True, "unreachable": False, "skipped": False, "no_log": False}
            result = TaskResult(host, task, input)
            result_copy = result.clean_copy()
            self.assertNotEqual(result._result['failed_when_result'], result_copy._result['failed_when_result'])

# Generated at 2022-06-22 20:33:07.463781
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    pass


# Generated at 2022-06-22 20:33:14.865605
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    task_fields = {'name': 'test_task', 'changed_when': 'False'}
    return_data = {'_ansible_parsed': True, 'changed': True}
    task = 'test_task'
    host = 'test_host'
    task_result = TaskResult(host, task, return_data, task_fields=task_fields)
    is_changed = task_result.is_changed()
    assert is_changed is False



# Generated at 2022-06-22 20:33:24.402389
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    task_fields = dict()
    task = Task()

# Generated at 2022-06-22 20:33:33.544126
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-22 20:33:44.688943
# Unit test for constructor of class TaskResult
def test_TaskResult():

    class fake_module:
        def __init__(self, action):
            self.action = action

    task0 = fake_module(action='debug') # action 'debug'
    data0 = {'unreachable': False, 'msg': 'ok', 'results': [{'unreachable': False, 'msg': 'ok'}, {'unreachable': False, 'msg': 'ok'}]}
    host0 = 'localhost'
    result0 = TaskResult(host0, task0, data0)
    assert result0.is_changed() is False
    assert result0.is_skipped() is False
    assert result0.is_failed() is False
    assert result0.is_unreachable() is False
    assert result0.needs_debugger(True) is True


# Generated at 2022-06-22 20:33:55.236514
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import json
    from ansible.playbook.play_context import PlayContext

    def permute_results(result, missed, skipped, failed, unreachable):

        # permute possible result combinations
        if missed:
            result['missed'] = True
        if skipped:
            result['skipped'] = True
        if failed:
            result['failed'] = True
        if unreachable:
            result['unreachable'] = True
    from ansible.vars.hostvars import HostVars
    facts = HostVars({"127.0.0.1": {'ansible_facts': {'fact_one': 'value_one', 'fact_two': 'value_two'}}})
    host = "127.0.0.1"
    task = {"action": "debug", "no_log": True}
    return_

# Generated at 2022-06-22 20:33:57.491439
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    hostname = 'testhost'
    task = TaskResult(hostname, None, {})
    assert task.is_failed() == False

    task = TaskResult(hostname, None, {'failed': True})
    assert task.is_failed() == True


# Generated at 2022-06-22 20:34:09.579182
# Unit test for constructor of class TaskResult
def test_TaskResult():
    loader = DataLoader()
    result = loader.load('{"changed":true,"unreachable":false,"skipped":false,"failed":false,"rc":0,"stdout":"hello world","stderr":"error msg","msg":"no message"}')
    host = "host"
    task = ["task"]
    task_fields = {'name':'test'}
    taskresult = TaskResult(host, task, result, task_fields)
    clean_taskresult = taskresult.clean_copy()
    # test TaskResult
    assert taskresult.task_name == "test"
    assert taskresult.is_changed() == True
    assert taskresult.is_skipped() == False
    assert taskresult.is_failed() == False
    assert taskresult.is_unreachable() == False

# Generated at 2022-06-22 20:34:20.338854
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    class Task:
        def __init__(self, fields):
            self.no_log = fields.get('no_log', False)

    class Host:
        def __init__(self, variables):
            self.vars = variables

    class Result:
        def __init__(self, is_failed, is_unreachable):
            self.is_failed = is_failed
            self.is_unreachable = is_unreachable

        def is_changed(self):
            return False

        def is_skipped(self):
            return False


# Generated at 2022-06-22 20:34:30.691041
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    host_name = 'localhost'
    task = dict(action='shell', args='echo "hello"')
    return_data = dict(rc=0, stdout='hello', stderr='', start='2016-01-05 14:17:30.642307', end='2016-01-05 14:17:30.985853', delta='0:00:00.343546', msg='', cmd='echo "hello"', invo='')

    # 1 - test with is_unreachable = False
    task_result = TaskResult(host_name, task, return_data)
    assert task_result.is_unreachable() is False

    # 2 - test with is_unreachable = True
    task_result = TaskResult(host_name, task, dict(unreachable=True))
    assert task_result

# Generated at 2022-06-22 20:34:35.090590
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Create a TaskResult and set the result that would be returned
    # and then test if the method is_skipped is really working
    test_result = TaskResult(None, None, {'results':[{'item': {'name':'test_result'}}]})
    test_result._result = {'results':[{'item': {'name':'test_result'}, 'skipped':True}]}
    assert test_result.is_skipped()
    test_result._result = {'results':[{'item': {'name':'test_result'}, 'skipped':False}]}
    assert not test_result.is_skipped()

# Generated at 2022-06-22 20:34:43.718400
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import copy

    host = copy.deepcopy(C.DEFAULT_HOST_LIST)
    task_vars = combine_vars(loader=DataLoader(), vars=(dict(C.DEFAULT_HOST_LIST.get_vars(), ansible_debug=True)))
    task = Task()

    # => task_fields has "debugger" set and the global option is set

# Generated at 2022-06-22 20:34:52.941056
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = 'host1'
    task = {'task': 'copy'}

    # case 1: regular task and result contains key 'failed'
    return_data = {'failed': True}
    task_fields = {}
    TaskResult_obj = TaskResult(host, task, return_data, task_fields)
    assert True == TaskResult_obj.is_failed()

    # case 2: loop task and result contains key 'failed'
    return_data = {'results': [{'failed': True}]}
    task_fields = {}
    TaskResult_obj = TaskResult(host, task, return_data, task_fields)
    assert True == TaskResult_obj.is_failed()

    # case 3: regular task and result does not contain key 'failed'
    return_data = {'failed': None}
    task_fields

# Generated at 2022-06-22 20:35:03.557957
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test for TaskResult.is_changed()
    test_changed_dict = {'changed': True}
    test_changed_unicode = AnsibleUnicode(u'{"changed": true}')
    test_changed_str = '{"changed": true}'

    res1 = TaskResult(None, None, test_changed_dict)
    res2 = TaskResult(None, None, test_changed_unicode)
    res3 = TaskResult(None, None, test_changed_str)
    assert res1.is_changed() is True
    assert res2.is_changed() is True
    assert res3.is_changed() is True
    assert res1.clean_copy().is_changed() is True
    assert res2.clean_copy

# Generated at 2022-06-22 20:35:14.020404
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    t = TaskResult(None, None, {"changed": False})
    assert not t.is_changed()
    t = TaskResult(None, None, {"changed": True})
    assert t.is_changed()
    # results
    t = TaskResult(None, None, {"results": [{"changed": False}]})
    assert not t.is_changed()
    t = TaskResult(None, None, {"results": [{"changed": True}]})
    assert t.is_changed()
    t = TaskResult(None, None, {"results": [{}, {"changed": True}]})
    assert t.is_changed()


# Generated at 2022-06-22 20:35:22.388948
# Unit test for constructor of class TaskResult
def test_TaskResult():

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # create task
    pb = Task()
    pb._role = None
    pb._block = None
    pb._parent = None
    pb._play = None
    pb._task_include = None
    pb._role_include = None
    pb._loader = None
    pb._dep_chain = None
    pb._loop = None
    pb._always_run = None
    pb._tags = None
   

# Generated at 2022-06-22 20:35:31.550976
# Unit test for constructor of class TaskResult
def test_TaskResult():
    return_data = DataLoader().load("{\"hosts\": {\"1.1.1.1\": {\"changed\": true, \"unreachable\": false, \"failed\": false, \"invocation\": {\"module_args\": {\"name\": \"sed\", \"state\": \"absent\"}, \"module_name\": \"package\"}, \"ansible_facts\": {\"discovered_interpreter_python\": \"/usr/bin/python\"},\"module_name\": \"package\",\"module_uuid\": \"3f10230d3c6a7ad6c9d6f66dbe8c8f0b\",\"item\": {\"key\": \"value\"}}}},\"changed\": false,\"unreachable\": false,\"failed\": false,\"_ansible_verbose_always\": true}")
    task = '{"name": "package"}'