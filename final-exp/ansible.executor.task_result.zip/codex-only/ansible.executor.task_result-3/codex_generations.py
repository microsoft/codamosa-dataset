

# Generated at 2022-06-22 20:25:26.909733
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    return_data = dict(unreachable=True)
    result = TaskResult('host', 'task', return_data)
    assert result.is_unreachable() is True

    return_data = dict(unreachable=False)
    result = TaskResult('host', 'task', return_data)
    assert result.is_unreachable() is False

# Generated at 2022-06-22 20:25:34.123312
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    host_mock = {}
    task_mock = {}
    return_data_mock = {}
    task_fields_mock = {}

    tr = TaskResult(host_mock, task_mock, return_data_mock, task_fields_mock)
    assert tr.is_changed() == False

    return_data_mock = {'changed': True}
    tr = TaskResult(host_mock, task_mock, return_data_mock, task_fields_mock)
    assert tr.is_changed() == True


# Generated at 2022-06-22 20:25:43.770557
# Unit test for constructor of class TaskResult
def test_TaskResult():

    # test init method with different values of return_data
    # return_data is a dict
    ans_test = TaskResult(None, None, {'result': 'Result', 'msg': 'This is the message'})
    assert ans_test._result == {'result': 'Result', 'msg': 'This is the message'}

    # return_data is a json string
    ans_test = TaskResult(None, None, '{"result": "Result", "msg": "This is the message"}')
    assert ans_test._result == {'result': 'Result', 'msg': 'This is the message'}



# Generated at 2022-06-22 20:25:54.774318
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    import pytest

    # TaskResult.is_skipped returns False if the result of task execution is
    # neither skipped nor is a loop result.
    task_result = TaskResult(host=None, task=None, return_data={'changed': False})
    assert not task_result.is_skipped()

    # TaskResult.is_skipped returns True if the result of task execution is
    # skipped.
    task_result = TaskResult(host=None, task=None, return_data={'skipped': True})
    assert task_result.is_skipped()

    # TaskResult.is_skipped returns True if the result of task execution is a
    # loop result and every result in 'results' is skipped.

# Generated at 2022-06-22 20:26:02.094970
# Unit test for constructor of class TaskResult
def test_TaskResult():
    task = dict()
    task["action"] = "ping"
    task["delegate_to"] = "localhost"
    return_data = dict()
    return_data["failed"] = False
    return_data["changed"] = False
    return_data["rc"] = 0
    return_data["msg"] = "pong"
    task_fields = {'no_log': True}
    task_result = TaskResult("localhost", task, return_data, task_fields)
    assert(task_result._host == "localhost")
    assert(task_result._task == task)
    assert(task_result._result == {'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'})
    assert(task_result._task_fields == task_fields)

# Generated at 2022-06-22 20:26:12.593436
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    p = Play()
    b = Block()
    t = Task()
    f = TaskResult(None, t, {})

    t._attributes['ignore_errors'] = False
    assert f.needs_debugger() == False
    t._attributes['ignore_errors'] = None
    assert f.needs_debugger() == False

    t._attributes['debugger'] = 'always'
    assert f.needs_debugger(True) == True
    t._attributes['debugger'] = 'never'
    assert f.needs_debugger(True) == False
    t._attributes['debugger'] = 'on_failed'

# Generated at 2022-06-22 20:26:22.361730
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = 'testhost'
    task = 'testtask'
    return_data = {'changed':False,'results':[{'changed':False,'failed':False,'invocation':{'module_args':{'items':[{'key':'hello','value':'world'}],'path':'/tmp/test'}},'item':{'key':'hello','value':'world'},'module_name':'ini_file'}]}
    task_fields = {'name':'test taskname'}

    taskresult = TaskResult(host, task, return_data, task_fields)
    assert taskresult.is_failed() == False

# Generated at 2022-06-22 20:26:28.835903
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Expected: True
    host = None
    task = None

# Generated at 2022-06-22 20:26:41.237478
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    # create TaskResult for all variations of skipped task
    # returned data type is dict
    return_data = dict(
        skipped=True,
        results=[
            dict(
                skipped=True,
            ),
            dict(
                skipped=True,
            ),
        ],
    )
    taskresult_dict = TaskResult(None, None, return_data)

    # returned data type is str
    return_data = dict(
        skipped=True,
        results=[
            dict(
                skipped=True,
            ),
            dict(
                skipped=True,
            ),
        ],
    )
    return_data_str = str(return_data)
    taskresult_str = TaskResult(None, None, return_data_str)

    tasks = (taskresult_dict, taskresult_str)


# Generated at 2022-06-22 20:26:53.106752
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import json
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 20:27:04.148831
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # test failed
    failed = dict(failed = True, changed = False, skipped = False)
    assert TaskResult(None, None, failed).is_failed()
    # test failed_when
    failed_when = dict(failed_when_result = True, changed = False, skipped = False)
    assert TaskResult(None, None, failed_when).is_failed()
    # test failed_when_result on plalybook results
    failed_when_result = dict(
        results = [
            dict(failed_when_result = True, changed = False, skipped = False),
            dict(failed_when_result = False, changed = False, skipped = False)
        ]
    )
    ok_task = TaskResult(None, None, failed_when_result)
    assert ok_task.is_failed()
    # test for ok


# Generated at 2022-06-22 20:27:13.326870
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # "failed_when_result" key should be present in task result
    class Task:
        def __init__(self, ignore_errors):
            self.action = 'some_action'
            self.ignore_errors = ignore_errors

        def get_name(self):
            return 'some_task_name'

    class Host:
        def __init__(self):
            self.name = 'some_host'
            self.vars = {}

    # Test with ignore_errors=False:
    # Test with 'failed_when_result' key present in task result
    assert TaskResult(Host(), Task(False), {'failed_when_result': True}).is_failed()
    # Test with 'failed_when_result' key not present in task result
    assert not TaskResult(Host(), Task(False), {}).is_failed

# Generated at 2022-06-22 20:27:18.758023
# Unit test for constructor of class TaskResult
def test_TaskResult():
    '''
    >>> from ansible.playbook.task import Task
    >>> t = Task()
    >>> tr = TaskResult(None, t, {'foo': 'bar'})
    >>> tr.task_name
    >>> t._uuid = 'uuid'
    >>> tr.task_name
    '''
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 20:27:26.201323
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task = {'name': 'fake'}
    task_fields = {'name': 'fake'}
    fake_host = {'name': 'jdoe'}

# Generated at 2022-06-22 20:27:34.385867
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    result_with_failed_when_result_passed = {'_ansible_no_log': False,
                                             '_ansible_item_result': True,
                                             '_ansible_item_label': u'gather_subset',
                                             '_ansible_parsed': True,
                                             'failed_when_result': False}
    result_with_failed_when_result_failed = {'_ansible_no_log': False,
                                             '_ansible_item_result': True,
                                             '_ansible_item_label': u'gather_subset',
                                             '_ansible_parsed': True,
                                             'failed_when_result': True}

# Generated at 2022-06-22 20:27:43.967850
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():

    from ansible.playbook.task import Task

    test_host = 'test_host'
    test_task = Task()

    return_data = dict(unreachable=True)
    task_result = TaskResult(test_host, test_task, return_data)
    assert(task_result.is_unreachable() is True)

    return_data = dict(unreachable=False)
    task_result = TaskResult(test_host, test_task, return_data)
    assert(task_result.is_unreachable() is False)


# Generated at 2022-06-22 20:27:52.250571
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    # Give tasks a name and a debugger key
    # The name is not used by the method but is needed by the constructor of
    # class TaskResult
    tasks = [dict(name='task_debugger_always', debugger='always'),
             dict(name='task_debugger_never', debugger='never'),
             dict(name='task_debugger_on_failed', debugger='on_failed'),
             dict(name='task_debugger_on_unreachable', debugger='on_unreachable'),
             dict(name='task_debugger_on_skipped', debugger='on_skipped')]

    # The task object is not needed by the method but is needed by the constructor
    # of class TaskResult
    task_object = object()

    # No debugger key given in a task

# Generated at 2022-06-22 20:28:03.751182
# Unit test for constructor of class TaskResult
def test_TaskResult():
    '''
    Test to check intialization of TaskResult object and its methods
    '''
    dr = DataLoader()
    test_data = '{"test_data": "test"}'
    test_task_field = {"name":"fake_task","other_data":"something"}
    test_result = TaskResult("test1234", {"action": "test", "no_log": True}, dr.load(test_data), test_task_field)
    assert test_result.task_name == "fake_task"
    assert test_result.is_changed() == False
    assert test_result.is_skipped() == False
    assert test_result.is_failed() == False
    assert test_result.is_unreachable() == False
    assert test_result.needs_debugger(False) == False

# Generated at 2022-06-22 20:28:15.360060
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    class Task:
        def __init__(self, action, no_log, ignore_errors):
            self.action = action
            self.no_log = no_log
            self.ignore_errors = ignore_errors

    assert TaskResult(
        'host',
        Task('ping', False, False),
        {'unreachable': True},
        {'debugger': 'on_unreachable',}
    ).needs_debugger(globally_enabled=True)

    assert TaskResult(
        'host',
        Task('ping', False, False),
        {'unreachable': True},
        {'debugger': 'on_unreachable', 'ignore_errors': True,}
    ).needs_debugger(globally_enabled=True) is False


# Generated at 2022-06-22 20:28:26.265602
# Unit test for method needs_debugger of class TaskResult

# Generated at 2022-06-22 20:28:36.360234
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    # Test 1: no result and no task fields
    result = TaskResult("test_host", "test_task", {})
    assert not result.is_changed()

    # Test 2: task has 'changed' field set to False
    result = TaskResult("test_host", "test_task", {}, {'changed': False})
    assert not result.is_changed()

    # Test 3: task has 'changed' field set to True
    result = TaskResult("test_host", "test_task", {}, {'changed': True})
    assert result.is_changed()

    # Test 4: result has 'changed' field set to False
    result = TaskResult("test_host", "test_task", {'changed': False}, {})
    assert not result.is_changed()

    # Test 5: result has 'changed' field set to

# Generated at 2022-06-22 20:28:46.585647
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-22 20:28:53.118347
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task = {
        'name': 'testing is_failed method',
        'ignore_errors': True,
        'debugger': False,
    }
    result = {
        'failed': False,
        'changed': False,
        '_ansible_no_log': False,
        'failed_when_result': True,
        'results': [{
            'failed': True,
            'changed': False,
            'failed_when_result': True,
        }]
    }
    tr = TaskResult('test_host', task, result)
    assert tr.is_failed() == True

# Generated at 2022-06-22 20:29:04.131054
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    dummy_host = 'localhost'
    dummy_task = None
    return_data = {
        'msg': 'No route to host',
        'unreachable': True
    }
    task_result = TaskResult(dummy_host, dummy_task, return_data)
    assert task_result.is_unreachable() is True
    task_result = TaskResult(dummy_host, dummy_task, {'unreachable': False})
    assert task_result.is_unreachable() is False
    return_data = {
        'msg': 'No route to host',
        'unreachable': False
    }
    task_result = TaskResult(dummy_host, dummy_task, return_data)
    assert task_result.is_unreachable() is False

# Generated at 2022-06-22 20:29:10.174970
# Unit test for constructor of class TaskResult
def test_TaskResult():
    return_data = dict()
    return_data['failed'] = False
    return_data['changed'] = True
    return_data['skipped'] = False
    return_data['unreachable'] = False
    return_data['invocation'] = {'module_name': 'ping', 'module_args': {'data': 'pong'}}
    return_data['ansible_facts'] = {'discovered_interpreter_python': '/usr/bin/python'}
    return_data['elapsed'] = 0
    return_data['_ansible_no_log'] = False
    return_data['_ansible_verbose_always'] = True

    # If return_data is dict, no need to load.
    raw_data = DataLoader().load(return_data)

    # Call constructor of class TaskResult
   

# Generated at 2022-06-22 20:29:22.854742
# Unit test for constructor of class TaskResult
def test_TaskResult():
    from ansible.plugins.task.builtin import ActionModule
    from ansible.playbook.task import Task

    _task = Task()
    _task.action = 'test_action'
    _task.name = 'test_name'
    _task.ignore_errors = False
    _task.delegate_to = None
    _action_mod = ActionModule(_task, '/path/to/ansible')
    _task_fields = dict()
    _task_fields['name'] = 'test_name'
    _task_fields['action'] = 'test_action'
    _task_fields['ignore_errors'] = False
    _task_fields['delegate_to'] = None

# Generated at 2022-06-22 20:29:34.745079
# Unit test for constructor of class TaskResult
def test_TaskResult():
    host_name = "test_host"
    task_name = "test_task"
    task_data = {"test_key": "test_value", "test_key2": "test_value2"}
    task_fields = {"test_key3": "test_value3"}
    task_result = TaskResult(host_name, task_name, task_data, task_fields)

    assert task_result._host == host_name
    assert task_result._task == task_name
    assert task_result._result == task_data
    assert task_result._task_fields == task_fields
    assert task_result.task_name == task_name

    task_result._result = "task_result_data"
    assert task_result._result == "task_result_data"

# Generated at 2022-06-22 20:29:46.944298
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-22 20:29:59.557657
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Test data
    task = {'debugger': None, 'ignore_errors': False}
    task_fields = {'debugger': None, 'ignore_errors': False}
    return_data = {'failed': False, 'skipped': False, 'unreachable': False}

    # Failed and no ignore_errors
    task['debugger'] = 'on_failed'
    task_fields['debugger'] = 'on_failed'
    r = TaskResult(None, task, return_data, task_fields)
    assert r.needs_debugger(False)
    r = TaskResult(None, task, return_data, task_fields)
    assert r.needs_debugger(True)

    # Failed and no ignore_errors, but debugger is on_skipped
    task['debugger'] = 'on_skipped'
   

# Generated at 2022-06-22 20:30:04.577469
# Unit test for constructor of class TaskResult
def test_TaskResult():
    result = TaskResult(host={}, task={}, return_data={})
    assert result._host == {}
    assert result._task == {}
    assert result._result == {}
    assert result._task_fields == {}

    result = TaskResult(host=[], task=[], return_data=[], task_fields=[])
    assert result._host == []
    assert result._task == []
    assert result._result == []
    assert result._task_fields == []

# Generated at 2022-06-22 20:30:14.561836
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():

    class FakeHost(object):
        def __init__(self, name, port=None, user=None, password=None, ssh_key=None, ansible_ssh_pass=None):
            self.name = name
            self.port = port
            self.user = user
            self.password = password
            self.ssh_key = ssh_key
            self.ansible_ssh_pass = ansible_ssh_pass

    class FakeTask(object):
        def __init__(self, no_log=False, action=None, args=None):
            self.no_log = no_log
            self.action = action
            self.args = args

        def get_name(self):
            return self.action + ' ' + self.args

    # Expected result: True

# Generated at 2022-06-22 20:30:21.692883
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = {}
    task = {}
    data = {"changed": False, "invocation": {"module_args": {}}, "item": "", "msg": "Hello!"}
    task_fields = {}

    task_result = TaskResult(host, task, data, task_fields)
    cc_task_result = task_result.clean_copy()

    assert cc_task_result._result == {"msg": "Hello!"}

# Generated at 2022-06-22 20:30:32.277269
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields1 = {'debugger' : 'never'}
    task_fields2 = {'debugger' : 'on_failed'}
    task_fields3 = {'debugger' : 'on_skipped'}
    task_fields4 = {'debugger' : 'on_unreachable'}

    #
    #  True/False tests
    #
    #  debugger is set to never, no matter what the result is.
    #  debugger is never True.
    tr = TaskResult('host', 'task', {}, task_fields1)
    assert tr.needs_debugger() == False

    tr = TaskResult('host', 'task', {}, task_fields2)
    assert tr.needs_debugger() == False

    tr = TaskResult('host', 'task', {}, task_fields3)
   

# Generated at 2022-06-22 20:30:36.709817
# Unit test for constructor of class TaskResult
def test_TaskResult():
    assert TaskResult(None, None, {"foo":"bar"})._result == {"foo": "bar"}
    assert TaskResult(None, None, {"changed": False})._result == {"changed": False}
    assert TaskResult(None, None, {"changed": True})._result == {"changed": True}



# Generated at 2022-06-22 20:30:37.322629
# Unit test for constructor of class TaskResult
def test_TaskResult():
    pass

# Generated at 2022-06-22 20:30:48.423707
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    task_fields = {'name': 'test_task_name'}
    task = object()
    host = object()
    return_data = {'invocation': {'module_args': {'debugger': None}}}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert not task_result.needs_debugger()

    return_data = {'invocation': {'module_args': {'debugger': 'on_failed'}}}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert not task_result.needs_debugger()

    return_data = {'invocation': {'module_args': {'debugger': 'on_failed'}}, 'failed_when_result': True}

# Generated at 2022-06-22 20:30:53.529272
# Unit test for constructor of class TaskResult
def test_TaskResult():
  return_data = {'msg': 'ok'}
  task = TaskResult('host', 'task', return_data)
  assert task._host == 'host'
  assert task._task == 'task'
  assert task._result == {'msg': 'ok'}


# Generated at 2022-06-22 20:31:04.836634
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult(host=None, task=None, return_data={}, task_fields={})

    result = task_result.needs_debugger(True)
    assert(result == False)

    # If a global debugger is enabled, if task is failed or unreachable, debugger is needed
    task_result._result = {'failed': True}
    result = task_result.needs_debugger(True)
    assert(result == True)

    task_result._result = {'unreachable': True}
    result = task_result.needs_debugger(True)
    assert(result == True)

    # If task.debugger is 'always', debugger is needed
    task_result._task_fields = {'debugger': 'always'}
    result = task_result.needs_debugger(True)

# Generated at 2022-06-22 20:31:09.907323
# Unit test for constructor of class TaskResult
def test_TaskResult():
    host = 'host'
    task = 'task'
    return_data = 'return_data'
    task_fields = {'name': 'task-name'}

    obj = TaskResult(host, task, return_data, task_fields)
    assert isinstance(obj, TaskResult)

# Generated at 2022-06-22 20:31:21.463089
# Unit test for constructor of class TaskResult
def test_TaskResult():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.inventory.host

    # Define a fake task with fake data
    task = ansible.playbook.task.Task()
    task._role_name = "the_role"
    task.action = "shell"
    task.args = "echo hello world"
    task.set_loader(DataLoader())

    # Define a fake host with fake data
    host = ansible.inventory.host.Host("test.example.org")
    host.vars = {"test_var": "test_value"}

    # Fake data
    data = {}
    data['invocation'] = {}
    data['invocation']['module_args'] = "echo hello world"
    data['invocation']['module_name'] = "shell"
   

# Generated at 2022-06-22 20:31:32.641714
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-22 20:31:42.505746
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = {'name': 'testing'}
    task = {'action': 'debug',
            'async': 99999,
            'ignore_errors': True,
            'poll': 0,
            'register': 'shell_out'}
    task_fields = {'name': 'shell_out',
                   'debugger': 'on_failed',
                   'ignore_errors': True}

# Generated at 2022-06-22 20:31:52.571128
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-22 20:32:00.209812
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    result_str = '{"failed": true, "invocation": {"module_name": "command","module_args": "ifconfig"},"msg": "The module failed to execute correctly.\nSee stdout/stderr for the exact error","rc": 127}'
    task = TaskResult('test_host', None, result_str)
    assert task.is_unreachable() == False, "TaskResult instance continue to be reachable after an error"
    result_str = '{"unreachable": true}'
    task = TaskResult('test_host', None, result_str)
    assert task.is_unreachable() == True, "TaskResult instance is not unreachable after unreachable flag is set"

# Generated at 2022-06-22 20:32:08.301366
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    class TestTask:
        def __init__(self):
            self.action = ''
            self.no_log = False
    class TestTaskFields:
        def __init__(self):
            self.name = ''
            self.debugger = ''
            self.ignore_errors = False
    from ansible.plugins.callback import CallbackBase
    C.TASK_DEBUGGER_IGNORE_ERRORS = True

    test_task = TestTask()
    test_task_fields = TestTaskFields()
    data = DataLoader().load('')

    # Task is not a loop
    test_task.action = 'debug'
    task_result = TaskResult('test_host', test_task, data, test_task_fields)
    assert task_result.is_skipped() == False

    # Task is failed

# Generated at 2022-06-22 20:32:17.512598
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task_result = TaskResult(None, None, None)
    # Case 1
    assert(task_result._check_key('failed') == False)
    # Case 2
    task_result_2 = TaskResult(None, None, {'results': [{'failed': True}, {'failed': False}]})
    assert(task_result_2._check_key('failed') == True)
    # Case 3
    task_result_2 = TaskResult(None, None, {'results': [{'failed': False}, {'failed': False}]})
    assert(task_result_2._check_key('failed') == False)


# Generated at 2022-06-22 20:32:29.149220
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = TaskResult(
        host="localhost",
        task="",
        return_data={
            "results": [
                {},
                {}
            ]
        }
    )

    assert result.is_skipped() == False

    result = TaskResult(
        host="localhost",
        task="",
        return_data={
            "results": [
                {},
                {
                    "skipped": True
                }
            ]
        }
    )

    assert result.is_skipped() == False

    result = TaskResult(
        host="localhost",
        task="",
        return_data={
            "results": [
                {
                    "skipped": True
                },
                {
                    "skipped": True
                }
            ]
        }
    )

    assert result.is_skipped

# Generated at 2022-06-22 20:32:37.863289
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    ret_data = {
        'results': [
            {'failed_when_result': True},
            {'failed_when_result': True},
        ]
    }
    host = "localhost"
    task = "Dummy"
    task_fields = {}

    task_result = TaskResult(host, task, ret_data, task_fields)
    assert(task_result.is_skipped() == False)

    ret_data = {
        'results': [
            {'failed_when_result': True},
            {'failed_when_result': True},
            {'skipped': True},
        ]
    }
    task_result = TaskResult(host, task, ret_data, task_fields)
    assert(task_result.is_skipped() == False)


# Generated at 2022-06-22 20:32:45.489017
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    test_result = DataLoader().load("""{
        "_ansible_parsed": true,
        "changed": true,
        "invocation": {
            "module_args": {

            }
        },
        "msg": "default"
    }""")

    task_result = TaskResult('host_name', 'task_name', test_result)

    assert task_result.is_changed()



# Generated at 2022-06-22 20:32:57.569169
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_result = TaskResult(None, None, {}, {'ignore_errors': True})
    assert not task_result.needs_debugger(False)

    task_result = TaskResult(None, None, {}, {'ignore_errors': True, 'debugger': 'never'})
    assert not task_result.needs_debugger(True)

    task_result = TaskResult(None, None, {}, {'ignore_errors': False, 'debugger': 'never'})
    assert not task_result.needs_debugger(True)

    task_result = TaskResult(None, None, {}, {'ignore_errors': False, 'debugger': 'on_failed'})
    assert not task_result.needs_debugger(True)


# Generated at 2022-06-22 20:33:06.479324
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():

    class Test_Task:
        def __init__(self, action):
            self.action = action
            self.no_log = False

    class Test_Host:
        pass

    class Test_Task_Fields:
        def __init__(self, name):
            self.name = name

    # Test 1:
    task = Test_Task('debug')
    task_fields = Test_Task_Fields(name=None)
    host = Test_Host()
    return_data = {'failed': True}
    expected_result = True
    result = TaskResult(host, task, return_data, task_fields).is_failed()

    assert result == expected_result

    # Test 2:
    task = Test_Task(None)
    task_fields = Test_Task_Fields(name=None)

# Generated at 2022-06-22 20:33:10.002729
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task_result = TaskResult()
    if task_result.is_skipped():
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-22 20:33:20.388447
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    class MockTask:
        def __init__(self, action, no_log):
            self.action = action
            self.no_log = no_log

    class MockHost:
        pass

    # non-changed task
    tr = TaskResult(MockHost(), MockTask("debug", False), {'failed': False, 'changed': False})
    assert tr.is_changed() == False

    # changed task
    tr = TaskResult(MockHost(), MockTask("debug", False), {'failed': False, 'changed': True})
    assert tr.is_changed() == True

    # failed and changed task
    tr = TaskResult(MockHost(), MockTask("debug", False), {'failed': True, 'changed': True})
    assert tr.is_changed() == True

    # failed and non-changed task

# Generated at 2022-06-22 20:33:31.709369
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():

    # hosts -> no attribute changed
    result = TaskResult('test_host', 'test_task', {}, {})
    assert not result.is_changed()

    # host -> attribute changed = True
    result = TaskResult('test_host', 'test_task', {'changed':True}, {})
    assert result.is_changed()

    # host -> attribute changed = False
    result = TaskResult('test_host', 'test_task', {'changed': False}, {})
    assert not result.is_changed()

    # host -> attribute changed not set
    result = TaskResult('test_host', 'test_task', {'message':'Test message'}, {})
    assert not result.is_changed()

    # host -> attribute changed = False

# Generated at 2022-06-22 20:33:43.826381
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
    # is_changed should return True if 'changed' is True
    task_result_changed = TaskResult('host', 'task', dict(changed=True))
    assert task_result_changed.is_changed()

    # is_changed should return False if 'changed' is not True
    task_result_not_changed = TaskResult('host', 'task', dict(changed=False))
    assert not task_result_not_changed.is_changed()

    # is_changed should return True if any item of 'results' is True
    task_result_changed_result = TaskResult('host', 'task', dict(results=[dict(changed=True)]))
    assert task_result_changed_result.is_changed()

    # is_changed should return False if all items of 'results' are False
    task_result_not_changed_result = TaskResult

# Generated at 2022-06-22 20:33:54.230564
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    task_fields = {
        'debugger': 'on_skipped',
        'name': 'debug',
    }
    block = Block()
    role = Role()
    role.start_at_task(u'debug', loader)
    play = Play()
    block.add_task(task=role.tasks()[0], role=role)
    play.add_block(block)
    playbook = Playbook()
    playbook.add_play(play)

# Generated at 2022-06-22 20:34:00.117979
# Unit test for method is_changed of class TaskResult
def test_TaskResult_is_changed():
	with open('canary_taskresult_changed_true', 'r') as infile:
		data = infile.read()
		task = TaskResult(0, 0, data)
		assert(task.is_changed())

	with open('canary_taskresult_changed_false', 'r') as infile:
		data = infile.read()
		task = TaskResult(0, 0, data)
		assert(not task.is_changed())


# Generated at 2022-06-22 20:34:11.844869
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # TaskResult object initialized with skipped result
    taskresult = TaskResult(None, None, {'skipped': True})
    assert True == taskresult.is_skipped()
    # TaskResult object initialized with not skipped result
    taskresult = TaskResult(None, None, {'skipped': False})
    assert False == taskresult.is_skipped()
    # TaskResult object initialized with a list of result
    taskresult = TaskResult(None, None, {'results': [{'skipped': True}, {'skipped': True}]})
    assert True == taskresult.is_skipped()
    # TaskResult object initialized with a list of result
    taskresult = TaskResult(None, None, {'results': [{'skipped': True}, {'skipped': False}]})
    assert False == taskresult.is_skipped

# Generated at 2022-06-22 20:34:24.263155
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    fake_task = {"action": "ping", "name": "ping_all"}
    fake_host = "all"
    fake_task_fields = {"name": "ping_all"}

    result_ok = {'ping': 'pong'}
    result = TaskResult(fake_host, fake_task, result_ok, fake_task_fields)

    result_unreachable = {'unreachable': True}
    result_unreachable_obj = TaskResult(fake_host, fake_task, result_unreachable, fake_task_fields)

    result_failed = {'failed': True}
    result_failed_obj = TaskResult(fake_host, fake_task, result_failed, fake_task_fields)

    assert result_ok.is_unreachable() == False
    assert result_unreachable_obj

# Generated at 2022-06-22 20:34:33.755223
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    """ Test method clean_copy of class TaskResult """

    # Create TaskResult object
    task_result = TaskResult(None, None, {}, None)
    task_result._result = {
        "successful": True,
        "attempts": 5,
        "changed": True,
        "results": [
            {"changed": True},
            {"changed": False},
            {"changed": True},
            {"changed": False}
        ],
        "retries": 0,
        "failed": False
    }

    # Validate copy
    copy = task_result.clean_copy()
    assert isinstance(copy, TaskResult)
    assert "successful" not in copy._result
    assert "attempts" in copy._result
    assert "changed" in copy._result
    assert "results" in copy._result

# Generated at 2022-06-22 20:34:45.640865
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task  # noqa
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play  # noqa

    result = TaskResult(None, None, {})
    assert result.needs_debugger() == False

    result = TaskResult(None, Task(), {})
    assert result.needs_debugger() == False

    result = TaskResult(None, Task(action='debug'), {})
    assert result.needs_debugger() == True

    result = TaskResult(None, Task(block=Block(play=None)), {})
    assert result.needs_debugger() == False

    result = TaskResult(None, Task(block=Block(play=Play())), {})
    assert result.needs_debugger() == False


# Generated at 2022-06-22 20:34:46.235443
# Unit test for constructor of class TaskResult
def test_TaskResult():
    assert True

# Generated at 2022-06-22 20:34:56.161938
# Unit test for constructor of class TaskResult
def test_TaskResult():
    module_name = 'test_TaskResult'
    inv_args = {'result': {}}
    args = {'name': module_name}
    args['args'] = inv_args

    # Create Task object
    t = Task()
    # Create task
    t.args = args
    # Create TaskResult object
    r = TaskResult({}, t, t.args['args'].get('result'))
    assert r.task_name == module_name
    assert not r.is_failed()
    assert not r.is_unreachable()
    assert not r.is_changed()
    assert not r.needs_debugger()


# Generated at 2022-06-22 20:35:01.858500
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    tasks = [{'task': {'name': 't1', 'ignore_unreachable': False}, 'result': {'unreachable': True}, 'expect': True},
             {'task': {'name': 't1', 'ignore_unreachable': True}, 'result': {'unreachable': True}, 'expect': False},
             {'task': {'name': 't1', 'ignore_unreachable': False}, 'result': {'unreachable': False}, 'expect': False},
             {'task': {'name': 't1', 'ignore_unreachable': True}, 'result': {'unreachable': False}, 'expect': False},
             ]

    for task in tasks:
        result = TaskResult('host', task['task'], task['result'])

# Generated at 2022-06-22 20:35:09.390760
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-22 20:35:20.950839
# Unit test for constructor of class TaskResult
def test_TaskResult():
    pass
#    from ..plugins.vars import load_extra_vars
#    from ..playbook.play_context import PlayContext
#    from ..playbook.task import Task
#    task_vars = {}
#    play_context = PlayContext()
#    test_loader = DataLoader()
#    task_vars.update(load_extra_vars(loader=test_loader, play_context=play_context, variables=[]))
#    test_task = Task.load(dict(action=dict(module='shell', args='ls')))
#    test_host = 'localhost'
#    test_return_data = dict()
#    test_task_fields = dict(action=dict(module='shell'))
#    result_obj = TaskResult(test_host, test_task, test_return_data, task

# Generated at 2022-06-22 20:35:30.838255
# Unit test for method is_unreachable of class TaskResult
def test_TaskResult_is_unreachable():
    from ansible.playbook.task import Task
    task = Task()
    task.action = 'shell'
    task.args = dict()
    task.args['chdir'] = '/tmp'
    task.args['_raw_params'] = 'cat /root/toto'
    task.set_loader(DataLoader())

    test_result = TaskResult('test_host', task, dict())
    test_result._result = dict()
    test_result._result['failed'] = False
    test_result._result['skipped'] = False
    test_result._result['unreachable'] = False

    assert(test_result.is_unreachable() == False)

    test_result._result['unreachable'] = True

    assert(test_result.is_unreachable() == True)
