

# Generated at 2022-06-10 23:41:55.432819
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    host = "example.com"
    task = "test task"
    data = {
        'failed': True,
        'failed_when_result': False,
    }
    result = TaskResult(host, task, data)
    assert result.is_failed() == True, "Failed field False should make is_failed() return True"
    data['failed'] = False
    data['failed_when_result'] = True
    result = TaskResult(host, task, data)
    assert result.is_failed() == True, "Failed_when_result field True should make is_failed() return True"
    data['failed_when_result'] = False
    data['unreachable'] = False
    result = TaskResult(host, task, data)

# Generated at 2022-06-10 23:42:07.996544
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    """ is_skipped() should recognize skipped/failed results """

    # TaskResult must receive a host, task and return
    # we mock a task here
    task = type('Task', (object,), {'no_log': False})
    host = type('Host', (object,), {'name': 'localhost'})

    # make return for TaskResult

# Generated at 2022-06-10 23:42:21.289964
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    # Running the loop below would give you one copy of the result
    # per iteration
    for i in range(0, 10):
        host = Host(name="localhost")
        task = Task()
        # Cleaner result: no failed_when_result, no results, no stderr

# Generated at 2022-06-10 23:42:32.341509
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    result = {
        'a': 'test',
        'b': 42,
        'c': {
            'x': 'subtest',
            'y': 31
        },
        'changed': False,
        'cmd': 'some-cmd',
        'invocation': {
            'module_args': 'some-opts'
        },
        'failed': True,
        '_ansible_item_label': 'item',
        '_ansible_no_log': True,
        '_ansible_verbose_always': False,
        '_ansible_verbose_override': False,
        '_ansible_ignore_errors': False,
    }

    result_ = TaskResult('host', 'task', result, task_fields={'name': 'task-name'}).clean_copy()
    assert result

# Generated at 2022-06-10 23:42:40.326127
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # task result contains failure status
    result = {'failed': True}
    assert TaskResult(None, None, result).is_failed()

    # task result contains unreachable status (is false)
    result = {'unreachable': True}
    assert not TaskResult(None, None, result).is_failed()

    # result contains both failure and unreachable
    result = {'failed': True, 'unreachable': True}
    assert TaskResult(None, None, result).is_failed()

    # result is a list of dicts that contains at least one dict with failure status
    result = {'results': [{'failed': True}, {'failed': False}, {}]}
    assert TaskResult(None, None, result).is_failed()

    # result is a list of dicts that contains dict with failure_when_result status
    result

# Generated at 2022-06-10 23:42:49.829895
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # pylint: disable=W0212
    class Task:
        def __init__(self, action, ignore_errors=False, debugger=None):
            self.ignore_errors = ignore_errors
            self.action = action
            self.debugger = debugger

        def get_name(self):
            return 'test_TaskResult_needs_debugger'

    # this requires the use of the private member _check_key
    result = TaskResult(None, Task('test'), {'changed': False, 'failed': False, 'unreachable': True})
    assert result._check_key('unreachable') == True  #pylint: disable=protected-access
    assert result.needs_debugger(True) == True

# Generated at 2022-06-10 23:43:00.173430
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    fake_task = dict(action='debug', no_log=True, task_name='fake_task_1')
    fake_task_2 = dict(action='debug', no_log=False, task_name='fake_task_2')
    fake_host = dict(name='fake_host_1')
    fake_host_2 = dict(name='fake_host_2')
    fake_data_1 = dict(failed=True, _ansible_verbose_always=True, _ansible_no_log=True, ignored='fake_data_1')
    fake_data_2 = dict(success=True, _ansible_verbose_always=True, _ansible_no_log=False, ignored='fake_data_2')

# Generated at 2022-06-10 23:43:11.204598
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    loader = DataLoader()
    host = "127.0.0.1"
    task = None
    return_data = loader.load("""{
        "msg": "All items completed",
        "results": [
            {
                "item": "172.16.0.1",
                "changed": false,
                "failed": false,
                "skipped": true
            },
            {
                "item": "172.16.0.2",
                "changed": false,
                "failed": false,
                "skipped": true
            }
        ],
        "changed": false
    }""")
    task_fields = None
    taskresult = TaskResult(host, task, return_data, task_fields)

    # Check if a result of a loop task is skipped
    assert taskresult.is_skipped()

# Generated at 2022-06-10 23:43:22.537159
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result_dict_1 = {'results': [{'skipped': True}]}
    result_dict_2 = {'results': [{'skipped': False}]}
    result_dict_3 = {'results': [{'something': 'else'}]}
    result_dict_4 = {'results': [{}]}

    assert TaskResult(None, None, result_dict_1).is_skipped()
    assert not TaskResult(None, None, result_dict_2).is_skipped()
    assert TaskResult(None, None, result_dict_3).is_skipped()
    assert TaskResult(None, None, result_dict_4).is_skipped()

    result_dict_5 = {'results': ['string']}
    result_dict_6 = {}


# Generated at 2022-06-10 23:43:31.434380
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = 'testhost'
    task = []
    task_fields = None

    # 1. dict result contains failed_when_result
    return_data_one = {
        "failed_when_result": True
    }
    task_result_one = TaskResult(host, task, return_data_one, task_fields)
    assert(task_result_one.is_skipped() == False)

    # 2. dict result contains results
    return_data_two = {
        "results": [
            {
                "item": "item0"
            },
            {
                "item": "item1",
                "skipped": True
            },
            {
                "item": "item2",
                "skipped": True
            }
        ]
    }

# Generated at 2022-06-10 23:43:47.970597
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import inspect
    import ansible.task

    loader = DataLoader()
    fake_task = ansible.task.Task(action='setup')
    fake_task.set_loader(loader)
    fake_task.name = 'fake task'


# Generated at 2022-06-10 23:44:00.293847
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # case 1
    test1 = TaskResult('host', 'task', {'changed': True, 'failed': True, 'skipped': True, 'unreachable': True, '_ansible_no_log': True, '_ansible_verbose_override': True, '_ansible_item_label': 'item'})
    result1 = test1.clean_copy()
    assert(result1.is_changed() == True)
    assert(result1.is_skipped() == False)
    assert(result1.is_failed() == False)
    assert(result1.is_unreachable() == False)

# Generated at 2022-06-10 23:44:10.411214
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task

    host = 'dummy_host'
    task_fields = dict()
    return_data = dict()

    # case 1
    task_fields['debugger'] = 'always'
    task = Task.load(task_fields, play=None, variable_manager=None, loader=None)
    task_result = TaskResult(host, task, return_data)
    assert(task_result.needs_debugger() == True)

    # case 2
    task_fields['debugger'] = 'never'
    task = Task.load(task_fields, play=None, variable_manager=None, loader=None)
    task_result = TaskResult(host, task, return_data)
    assert(task_result.needs_debugger() == False)

    # case 3
    task

# Generated at 2022-06-10 23:44:20.423604
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    from ansible.playbook.task import Task

    data = {'failed': False, 'msg': ''}
    dataloader = DataLoader()
    task = Task()

    # if global flag is false, then skip
    result = TaskResult('', task, data, task_fields={'ignore_errors': False})
    assert result.needs_debugger() == False

    #
    # 'always' flag is relevant only if global flag is True
    #
    result = TaskResult('', task, data, task_fields={'ignore_errors': False, 'debugger': 'always'})
    assert result.needs_debugger(globally_enabled=True) == True

    result = TaskResult('', task, data, task_fields={'ignore_errors': False, 'debugger': 'always'})
    assert result.needs_debug

# Generated at 2022-06-10 23:44:31.252022
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    pref_debugger_value_dict = {
        'always': True,
        'never': False,
        'on_failed': True,
        'on_skipped': False,
        'on_unreachable': True
    }

    class Task:
        def __init__(self, action='', no_log=False, ignore_errors=False):
            self.action = action
            self.no_log = no_log
            self.ignore_errors = ignore_errors

    class Host:
        def __init__(self, name):
            self.name = name

    # Failed task test

# Generated at 2022-06-10 23:44:41.100904
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.manager import PlaybookManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.plugins import callback_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    callback = callback_loader.get('json')
    options = {}

    playbook1 = PlaybookExecutor(playbooks=['playbook_test.yml'], inventory=variable_manager,
                                 variable_manager=variable_manager, loader=loader,
                                 options=options, passwords={})


# Generated at 2022-06-10 23:44:50.604323
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import unittest
    try:
        # Python 3
        from unittest.mock import MagicMock
    except ImportError:
        # Python 2
        from mock import MagicMock

    class TestTask:
        def __init__(self):
            self.action = None
            self.no_log = False

    class TestTaskResult(unittest.TestCase):
        def setUp(self):
            self.task_fields = {}
            self.task = TestTask()
            self.host = MagicMock()

        def test_TaskResult_clean_copy_debug_no_log(self):
            self.task.action = 'debug'
            self.task.no_log = True

# Generated at 2022-06-10 23:45:02.389035
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult

    task = Task()
    task._role = None
    task._parent = None
    task._block = None
    task._play = None
    task._ds = None
    task._context = None
    task._private = None
    task._only_if = None
    task._notify = None
    task._when = None
    task._loop = None
    task._ignore_errors = None
    task._tags = None
    task._run_once = None
    task._loop_args = None
    task._delegate_to = None
    task._register = None
    task._local_action = None
    task._always_run = None
    task._remote_user = None
    task._connection = None
   

# Generated at 2022-06-10 23:45:14.690913
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    task = {}
    host = ""
    return_data = {"results": [{"skipped": "True"}]}
    task_fields = {}

    task_result = TaskResult(host, task, return_data, task_fields)
    assert task_result.is_skipped()

    return_data = {"results": [{"skipped": "True"}, {"skipped": "False"}]}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert not task_result.is_skipped()

    return_data = {"results": [{"skipped": "True"}, {"skipped": "True"}]}
    task_result = TaskResult(host, task, return_data, task_fields)
    assert task_result.is_skipped()


# Generated at 2022-06-10 23:45:25.765286
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = None
    task = None

    return_data = dict(
        host="127.0.0.1",
        changed=False,
        _ansible_no_log=True,
        results=dict(
            host="10.0.0.1",
            failed=True,
            _ansible_no_log=False
        ),
        _ansible_item_label="test",
        invocation=dict(
            module_name="test",
            module_args={
                "one": 1,
                "two": "two",
                "three": True
            }
        )
    )
    task_fields = dict(
        name="test",
        action="test",
        no_log=True
    )

    original_result = TaskResult(host, task, return_data, task_fields)


# Generated at 2022-06-10 23:45:41.097074
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    host = "127.0.0.1"

# Generated at 2022-06-10 23:45:52.018030
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # On failed, is_failed() is True, Task with debugger is True and globally_enabled is True
    my_task = Task()
    my_task._role = None
    my_task._parent = Block(play=Play().load(dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[my_task],
    ), loader=None, variable_manager=None, loader_cache=C.DATA_CACHE_PLUGINS))
    my_task._role_name = None


# Generated at 2022-06-10 23:45:59.772841
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    import ansible.plugins.strategy
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager

    import ansible.inventory
    import ansible.playbook.play
    import ansible.plugins.loader

    import os

    # Load the file as a playbook
    pb = ansible.playbook.playbook.PlayBook(
        playbook=os.path.join(os.path.dirname(__file__), 'test_TaskResult_needs_debugger_playbook.yaml'),
        host_list=[os.path.join(os.path.dirname(__file__), 'test_TaskResult_needs_debugger_inventory.yaml')],
        ansible_version=CLI.version
    )

    # Load the inventory

# Generated at 2022-06-10 23:46:09.097389
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    global C
    C.TASK_DEBUGGER_IGNORE_ERRORS = True

    task_fields = {}

    result_obj = TaskResult('', task_fields=task_fields, task='', return_data={})

    task_fields['ignore_errors'] = False
    C.TASK_DEBUGGER_IGNORE_ERRORS = False
    assert result_obj.needs_debugger(True) is False

    task_fields['ignore_errors'] = False
    task_fields['debugger'] = None
    C.TASK_DEBUGGER_IGNORE_ERRORS = False
    assert result_obj.needs_debugger(True) is True

    task_fields['ignore_errors'] = False
    task_fields['debugger'] = None
    C.TASK_DEBUGGER_IGNORE_ERRORS = True


# Generated at 2022-06-10 23:46:22.013932
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    """ Unit test to validate TaskResult class with the method needs_debugger """
    original_debugger_config = C.TASK_DEBUGGER
    # Create a task object
    task_fields = {}
    task = object
    task_name = "Temp task name"
    task_args = {}
    task_action = None
    task_dep_chain = None
    task_loader = None
    task_uuid = None
    task_loop = None
    task_item_cache_key = None
    task_first_available_file = None
    task_post_validate = None
    task_vars = None
    task_when = None

    task = object
    task.name = task_name
    task.args = task_args
    task.action = task_action
    task.cleanup_action = task_

# Generated at 2022-06-10 23:46:30.885568
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    host = Host(name='foo')
    task = Task()
    result = TaskResult(host, task, {'failed': True})
    assert(result.is_failed() is True)

    result = TaskResult(host, task, {'failed': False})
    assert(result.is_failed() is False)

    result = TaskResult(host, task, {'failed_when_result': True})
    assert(result.is_failed() is True)

    result = TaskResult(host, task, {'failed_when_result': False})
    assert(result.is_failed() is False)

    result = TaskResult(host, task, {'results': [{'failed': True}]})

# Generated at 2022-06-10 23:46:40.672037
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task = dict()
    task['failure'] = True
    task['debugger'] = 'always'
    task1 = dict()
    task1['failure'] = True
    task1['debugger'] = 'on_failed'
    task2 = dict()
    task2['debugger'] = 'on_failed'
    task2['failure'] = False
    task3 = dict()
    task3['debugger'] = 'on_failed'
    task3['failure'] = True
    task3['ignore_errors'] = True 
    task4 = dict()
    task4['debugger'] = 'on_failed'
    task4['failure'] = True
    task5 = dict()
    task5['debugger'] = 'on_unreachable'
    task5['failure'] = True

# Generated at 2022-06-10 23:46:52.774195
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import ansible.playbook.task
    host = ansible.playbook.task.Task()
    host.set_variable('ansible_play_debugger', 'on_failed')
    task = ansible.playbook.task.Task()
    task.action = "debug"
    task_fields = {'debugger': 'always'}
    tr = TaskResult(host, task, {"failed": True}, task_fields)
    assert tr.needs_debugger() == True
    task_fields['ignore_errors'] = True
    assert tr.needs_debugger() == False
    task_fields['debugger'] = 'on_failed'
    assert tr.needs_debugger() == True
    task_fields['debugger'] = 'on_unreachable'
    assert tr.needs_debugger() == False
    task_fields

# Generated at 2022-06-10 23:46:58.057388
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = '127.0.0.1'
    task = TaskResult(host, '', 'key1: value1')
    result = task.clean_copy()
    assert result._result['key1'] == 'value1'

# Generated at 2022-06-10 23:47:08.202235
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    TaskResult_orig = TaskResult
    Task_orig = Task
    TaskFields_orig = TaskFields

    result_dict = {'invocation': 'invocation', 'changed': 'changed', 'item': 'item', 'failed_when_result': 'failed_when_result', '_ansible_no_log': '_ansible_no_log', 'ansible_facts': 'ansible_facts', 'ansible_parent_pid': 'ansible_parent_pid', 'ansible_diff': 'ansible_diff', 'ansible_item_label': 'ansible_item_label', 'ansible_job_id': 'ansible_job_id'}

    class Task:
        def __init__(self, action=None, name=None):
            self.action = action
            self.name = name

# Generated at 2022-06-10 23:47:24.379857
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = "fake host"
    task = "fake task"

# Generated at 2022-06-10 23:47:32.580180
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = '127.0.0.1'
    task = 'copy'
    return_data = {'changed':False, 'skipped':True}
    task_fields = {'name':'copy'}

    result = TaskResult(host, task, return_data, task_fields)
    assert result.is_skipped() == True
    assert result.is_failed() == False
    assert result.is_unreachable() == False
    assert result.is_changed() == False

# Generated at 2022-06-10 23:47:41.425277
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    import tasks.vars

    task0 = tasks.vars.TaskVars({'action': 'this is my action', 'debugger': 'on_skipped'})
    result0 = TaskResult('localhost', task0, {'skipped': False, 'failed': True})
    assert not result0.is_skipped()

    task1 = tasks.vars.TaskVars({'action': 'this is my action', 'debugger': 'on_skipped'})
    result1 = TaskResult('localhost', task1, {'skipped': True, 'failed': False})
    assert result1.is_skipped()

    task2 = tasks.vars.TaskVars({'action': 'this is my action', 'debugger': 'on_skipped'})

# Generated at 2022-06-10 23:47:55.690042
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.vars.manager

    host = ansible.inventory.host.Host(name="127.0.0.1")
    task = ansible.playbook.task.Task()
    task_fields = dict()
    task.set_loader(DataLoader())
    task._role = ansible.playbook.role.Role()
    task._role._role_path = "RolePath"

    loader = DataLoader()

    task.name = 'ping'
    task.action = 'ping'
    task.set_loader(loader)

    task.vars = ansible.vars.manager.VarsManager()

    task.vars.data = {'debugger': 'on_failed'}
    task

# Generated at 2022-06-10 23:48:05.746715
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    t = TaskResult('ubuntu-01', None, dict())
    assert False == t.needs_debugger()
    assert True == t.needs_debugger(globally_enabled=True)

    t._task_fields['debugger'] = 'always'
    assert True == t.needs_debugger()
    assert True == t.needs_debugger(globally_enabled=True)

    t._task_fields['debugger'] = 'on_failed'
    assert False == t.needs_debugger()
    t._result['failed'] = True
    assert True == t.needs_debugger()
    t._task_fields['ignore_errors'] = True
    assert False == t.needs_debugger()
    t._task_fields['ignore_errors'] = False
    assert True == t.needs_debugger()

# Generated at 2022-06-10 23:48:16.910428
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import copy

    class Task(object):
        def __init__(self, action=None, no_log=None):
            self.action = action
            self.no_log = no_log

        def get_name(self):
            return ''

    def _get_json(result):
        '''
        Generate a json formatted string from a result.
        '''
        import json
        return json.dumps(result, sort_keys=True, indent=4, separators=(',', ': '))

    def _compare_results(result1, result2):
        '''
        Compare two results.
        '''
        return _get_json(result1) == _get_json(result2)


# Generated at 2022-06-10 23:48:25.099344
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task_fields = {}
    task_fields['name'] = 'test'
    task_fields['action'] = 'shell'
    task_fields['ignore_errors'] = False
    result = {
        'changed': False,
        'failed': False,
        'unreachable': False
    }
    task_result = TaskResult(None, None, result, task_fields)
    C.TASK_DEBUGGER_IGNORE_ERRORS = True

    task_fields['debugger'] = 'always'
    assert task_result.needs_debugger()

    task_fields['debugger'] = 'never'
    assert not task_result.needs_debugger()

    task_fields['debugger'] = 'on_failed'
    assert not task_result.needs_debugger()

    result['failed'] = True
    task

# Generated at 2022-06-10 23:48:36.246149
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Create a fake TaskResult instance
    # We just need a task field and a result
    # The task field is:
    #   - debugger
    #   - ignore_errors
    # The result is:
    #   - failed
    #   - unreachable
    #   - skipped
    task_fields = dict(
        debugger='on_failed',
        ignore_errors=True,
    )
    _result = dict(
        failed=False,
        unreachable=False,
        skipped=False,
    )
    fake_task_result = TaskResult(
        host=None,
        task=None,
        return_data=_result,
        task_fields=task_fields,
    )
    # Simple case: debugger is on, so it should always return True

# Generated at 2022-06-10 23:48:43.307994
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Fake _host and _task objects
    _host = {'name': 'faux'}
    _task = {}

    input_ = {
        'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result',
        'changed': False,
        'failed': False
    }

    expected_output = {
        'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result',
        'changed': False,
        'failed': False
    }

    assert TaskResult(_host, _task, input_).clean_copy()._result == expected_output


# Generated at 2022-06-10 23:48:54.341166
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    class TestTask:
        def __init__(self, action, no_log):
            self.action = action
            self.no_log = no_log

    # Test 1 - debug task with no_log
    task = TestTask(C._ACTION_DEBUG, True)
    host = "test_host"
    return_data = {
        'failed': True,
        'failed_when_result': True,
        'invocation': {
            'module_args': {'_ansible_no_log': True}
        },
        'msg': "fatal",
        'rc': 1,
        'stderr': '',
        'stderr_lines': [],
        'stdout': "",
        'stdout_lines': []
    }

    result = TaskResult(host, task, return_data)

# Generated at 2022-06-10 23:49:20.538837
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    import datetime
    import json

    from ansible.vars.manager import VariableManager

    t = datetime.datetime.utcnow()
    test_result = {
        "ansible_facts":
        {
            "distribution": "Ubuntu",
            "distribution_major_version": "14",
            "distribution_release": "trusty",
            "distribution_version": "14.04",
            "lsb": {
                "codename": "trusty",
                "description": "Ubuntu 14.04 LTS",
                "id": "Ubuntu",
                "major_release": "14",
                "release": "14.04"
            }
        },
        "changed": False,
        "ping": "pong"
    }

# Generated at 2022-06-10 23:49:34.170512
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task

    module_stdout = '{"failed": true, "foo": "bar", "baz": "qux"}'
    task = Task.load(dict(action=dict(module='debug', args=dict())))
    result = TaskResult(dict(), task, DataLoader().load(module_stdout))
    assert result.clean_copy()._result == {"failed": True, "foo": "bar", "baz": "qux"}
    task.no_log = True
    result = TaskResult(dict(), task, DataLoader().load(module_stdout))
    assert result.clean_copy()._result == {"censored": "the output has been hidden due to the fact that 'no_log: true' was specified for this result", "foo": "bar", "baz": "qux"}


# Generated at 2022-06-10 23:49:43.064280
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = "localhost"
    task = {'name':'dummy'}
    return_data = {'failed':True, 'stderr_lines':['error'], 'stdout_lines':['ok']}
    result = TaskResult(host, task, return_data).clean_copy()
    assert not 'failed' in result._result
    assert not 'stderr_lines' in result._result
    assert not 'stdout_lines' in result._result

# Generated at 2022-06-10 23:49:55.193091
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task = AnsibleTask()

# Generated at 2022-06-10 23:50:09.058642
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    assert TaskResult(None, None, None).needs_debugger(True) == False
    assert TaskResult(None, None, None, {'debugger': 'always'}).needs_debugger(True) == True
    assert TaskResult(None, None, None, {'debugger': 'on_failed'}).needs_debugger(True) == False
    assert TaskResult(None, None, None, {'debugger': 'on_failed'}).needs_debugger(True) == False
    assert TaskResult(None, None, None, {'debugger': 'on_failed', 'ignore_errors': True}).needs_debugger(True) == False
    assert TaskResult(None, None, None, {'debugger': 'on_failed', 'ignore_errors': False}).needs_debugger(True) == False
    assert Task

# Generated at 2022-06-10 23:50:19.907501
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    class FakeTask(object):
        def __init__(self, action, no_log=False):
            self.action = action
            self.no_log = no_log

        def get_name(self):
            return 'fake'

    class BackwardsCompat(object):
        pass

    C.TASK_DEBUGGER_IGNORE_ERRORS = False


# Generated at 2022-06-10 23:50:24.780250
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    host = "dummy"
    task = object()
    return_data = {'invocation': {'module_args': {'verbose': True}}}
    taskresult = TaskResult(host, task, return_data)
    assert taskresult.clean_copy()._result == {'censored': 'the output has been hidden due to the fact that \'no_log: true\' was specified for this result'}

# Generated at 2022-06-10 23:50:35.152208
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    '''
    TaskResult.clean_copy
    '''

    from ansible.playbook.task import Task

    host = 'test_host'
    task = Task()
    task.action = 'setup'
    # FIXME: create task_fields
    task_fields = dict()

    return_data = {
        "ansible_facts": {
            "test_data": "just for test",
        },
    }

    task_result = TaskResult(host, task, return_data, task_fields)
    task_result_clean_copy = task_result.clean_copy()

    assert task_result_clean_copy._result == {
        "ansible_facts": {
            "test_data": "just for test",
            "_ansible_no_log": False,
        },
    }

# Generated at 2022-06-10 23:50:42.724709
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    class Host:
        pass

    class Task:
        def __init__(self, action, debugger, ignore_errors=False):
            self.action = action
            self.debugger = debugger
            self.ignore_errors = ignore_errors

    # test host
    host = Host()
    host.name = 'host'

    # test task
    task = Task(action=None, debugger=None)

    # test task_fields
    task_fields = dict()

    # test return_data
    return_data = dict()

    # test TaskResult
    task_result = TaskResult(host, task, return_data, task_fields)

    # test needs_debugger
    assert task_result.needs_debugger() == False

    # test with debugger = 'always'
    task.debugger = 'always'

# Generated at 2022-06-10 23:50:48.002485
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Test's variables
    task = type('MockTask', (object,), dict(no_log=False, action='MockAction'))
    host = type('MockHost', (object,), dict())
    data = {
        '_ansible_no_log': False,
        '_ansible_item_label': 'Test',
        '_ansible_verbose_override': False,
        '_ansible_verbose_always': False,
        'invocation': {
            'module_args': {
                'module_arg1': 'MockArg1'
            }
        },
        'changed': True
    }
    task_fields = dict()
    # Create TaskResult with data to clean
    taskresult = TaskResult(host, task, data, task_fields)
    # Clean data
    cleaned

# Generated at 2022-06-10 23:51:18.488976
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task = dict(
        action=dict(
            module='debug',
            args=dict(msg='Failed!')
        ),
        name='Failed test'
    )
    host = dict(name='localhost')
    data = dict(failed=True)
    r = TaskResult(host, task, data)
    assert True == r.needs_debugger()

# Generated at 2022-06-10 23:51:19.596678
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    pass
    # TODO

# Generated at 2022-06-10 23:51:30.503702
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    # Test for failed task result
    data = dict(failed=True)
    test = TaskResult("host", "task", data)
    assert test.is_failed() == True

    # Test for failed when result is present in task result
    data = dict(failed_when_result=False)
    test = TaskResult("host", "task", data)
    assert test.is_failed() == False

    # Test for failed when result is present in loop task result
    data = dict(results=[dict(failed_when_result=True)])
    test = TaskResult("host", "task", data)
    assert test.is_failed() == True

    # Test for failed when result is absent in loop task result
    data = dict(results=[dict(failed_when_result=False)])
    test = TaskResult("host", "task", data)

# Generated at 2022-06-10 23:51:41.082484
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    TASK_NAME = '/path/to/the/task'
    MODULE_ARGS = {'foo': 'bar'}
    MODULE_NAME = 'shell'
    MODULE_RESULT = {
        'failed': False,
        'invocation': {
          'module_args': MODULE_ARGS,
        },
    }

    module_result_copy = module_response_deepcopy(MODULE_RESULT)

    task_fields = {
        'action': MODULE_NAME,
        'module_args': MODULE_ARGS,
        'name': TASK_NAME,
    }

    task = TaskResult('localhost', 'localhost', module_result_copy, task_fields)

    # Check if the result of clean_copy is what we expect