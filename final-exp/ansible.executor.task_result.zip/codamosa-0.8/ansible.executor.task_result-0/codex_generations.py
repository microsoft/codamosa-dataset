

# Generated at 2022-06-10 23:41:50.623093
# Unit test for method is_skipped of class TaskResult

# Generated at 2022-06-10 23:41:57.614102
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import ansible.playbook.task_include
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    opts = {'strategy':'free', 'forks':3, 'become':None, 'become_method':None, 'become_user':None, 'remote_user':None, 'check':False, 'verbosity':0, 'module_path':None, 'extra_vars':[], 'playbook_path':'/etc/ansible/test.yml', 'listhosts':None, 'listtasks':None, 'listtags':None, 'syntax':None, 'connection':'smart', 'diff':False, 'step':None, 'start_at_task':None}
    passwords = {'conn_pass':'', 'become_pass':''}
    loader = DataLoader()

# Generated at 2022-06-10 23:42:09.676023
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # Create the class TaskResult with a json containing a list of dicts
    # The result is False
    task_result = TaskResult("", "", json_list_dicts)
    assert not task_result.is_skipped()

    # Create the class TaskResult with a json containing a list of dicts
    # The result is True
    task_result = TaskResult("", "", json_list_dicts_skipped)
    assert task_result.is_skipped()

    # Create the class TaskResult with a json containing a dict
    # The result is True
    task_result = TaskResult("", "", json_dict_skipped)
    assert task_result.is_skipped()

# Common dict for the tests

# Generated at 2022-06-10 23:42:22.304100
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-10 23:42:33.196116
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task = DummyTask()
    result = TaskResult('test_host', task, {'failed' : True})
    assert result.is_failed() == True
    result = TaskResult('test_host', task, {'failed' : False})
    assert result.is_failed() == False
    result = TaskResult('test_host', task, {'fail' : False})
    assert result.is_failed() == False
    result = TaskResult('test_host', task, {})
    assert result.is_failed() == False
    result = TaskResult('test_host', task, {'failed_when_result' : True})
    assert result.is_failed() == True
    result = TaskResult('test_host', task, {'results' : [{'failed' : True}]})

# Generated at 2022-06-10 23:42:44.392810
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    import ansible.constants as C
    from ansible.vars.clean import module_response_deepcopy, strip_internal_keys
    from ansible.parsing.dataloader import DataLoader

    # _IGNORE = ('failed', 'skipped')
    # _PRESERVE = ('attempts', 'changed', 'retries')
    # _SUB_PRESERVE = {'_ansible_delegated_vars': ('ansible_host', 'ansible_port', 'ansible_user', 'ansible_connection')}

    # stuff callbacks need
    # CLEAN_EXCEPTIONS = (
    #     '_ansible_verbose_always',  # for debug and other actions

# Generated at 2022-06-10 23:42:48.974255
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    task =  {
        "debugger": "on_failed",
        "_ansible_ignore_errors": False
    }
    result = TaskResult("host", task, {"failed": True})

    assert result.needs_debugger(True) == True

    task =  {
        "debugger": "on_failed",
        "_ansible_ignore_errors": False
    }
    result = TaskResult("host", task, {"failed": False})

    assert result.needs_debugger(True) == False

    task =  {
        "debugger": "on_failed",
        "_ansible_ignore_errors": True
    }
    result = TaskResult("host", task, {"failed": False})


# Generated at 2022-06-10 23:42:55.359734
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    # Get dynamic class TaskResult
    TaskResult_class = globals()['TaskResult']

    # Create TaskResult instance with optional arguments
    TaskResult_obj = TaskResult_class(host, task, return_data, task_fields)

    # Call method clean_copy of object TaskResult_obj
    clean_copy_result = TaskResult_obj.clean_copy()

    # Returns value of method clean_copy
    assert clean_copy_result == {}

# Generated at 2022-06-10 23:43:04.136148
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task
    task = Task()
    loader = DataLoader()

    # task.action is 'setup', globally_enabled is True
    # ignore_errors is False
    task_result_failed = TaskResult('host', task, {'failed': True, 'invocation': {'module_name': 'setup', 'module_args': ''}}, {'ignore_errors': False})
    assert task_result_failed.needs_debugger(True) == True

    # task.action is 'setup', globally_enabled is True
    # ignore_errors is True
    task_result_failed = TaskResult('host', task, {'failed': True, 'invocation': {'module_name': 'setup', 'module_args': ''}}, {'ignore_errors': True})
    assert task_result_failed.needs_

# Generated at 2022-06-10 23:43:15.175176
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    loader = DataLoader()
    variable_manager = None
    inventory = None
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    _task = Task(action=dict(module='setup'))

    results = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=None,
        passwords=None,
        stdout_callback='oneline',
        run_additional_callbacks=C.DEFAULT_LOAD_CALLBACK_PLUGINS,
        run_tree=False,
        # Needed for module_utils/facts.py
        private_data_dir=C.DEFAULT_PRIVATE_DATA_DIR
    )._tqm._final_q

    tresult = Task

# Generated at 2022-06-10 23:43:30.601117
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    import pytest
    assert TaskResult(None, None, None).needs_debugger() == False
    assert TaskResult(None, None, None, dict(debugger='always')).needs_debugger() == True
    assert TaskResult(None, None, None, dict(debugger='on_failed')).needs_debugger() == False
    assert TaskResult(None, None, { 'failed' : True } , dict(debugger='on_failed')).needs_debugger() == True
    assert TaskResult(None, None, { 'failed' : True } , dict(debugger='on_failed', ignore_errors=True)).needs_debugger() == False
    assert TaskResult(None, None, None, dict(debugger='on_unreachable')).needs_debugger() == False

# Generated at 2022-06-10 23:43:43.081912
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # This is a bit of a hack to get full coverage
    # it would be better to import from test/lib/test_vars.py
    class TestTask:
        def __init__(self, no_log):
            self.no_log = no_log
            self.action = "debug"

    result = {
        "_ansible_parsed": True,
        "changed": False,
        "invocation": {
            "module_args": "",
            "module_name": "debug"
        },
        "msg": "Hello World!",
        "failed": False
    }

    task = TestTask(False)
    clean_copy = TaskResult("dummy", task, result).clean_copy()
    assert clean_copy._result == result

    task = TestTask(True)

# Generated at 2022-06-10 23:43:50.397347
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    # Need to do that to not pollute the global cache of plugin loaders
    from ansible.plugins import task_debugger
    task_debugger._PLUGIN_CACHE = dict()
    task_debugger.PluginLoader = task_debugger._AnsiblePluginLoader
    task_debugger.init(task_debugger._AnsiblePluginLoader)

    from ansible.parsing.dataloader import DataLoader

    ds = DataLoader().load(None)

    from ansible.playbook import Playbook, Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-10 23:44:01.784953
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task

    task_result = TaskResult(host=None, task=Task(), return_data={}, task_fields={})
    
    # unit test for TaskResult.needs_debugger() where method's parameters are all falsy
    actual_result = task_result.needs_debugger()
    expected_result = False
    assert expected_result == actual_result

    # unit test for TaskResult.needs_debugger() where globally_enabled is falsely
    actual_result = task_result.needs_debugger(globally_enabled=False)
    expected_result = False
    assert expected_result == actual_result

    # unit test for TaskResult.needs_debugger() where globally_enabled is truthy and one of _debugger is truthy
    _debugger = 'on_skipped'
    actual

# Generated at 2022-06-10 23:44:10.549783
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    class Task:
        def __init__(self):
            self.action = 'noop'
    class Host:
        def __init__(self):
            self.name = 'localhost'
    task = Task()
    host = Host()
    # test TaskResult._check_key
    assert TaskResult(host, task, {'failed': True})._check_key('failed') == True
    assert TaskResult(host, task, {'failed': False})._check_key('failed') == False
    assert TaskResult(host, task, {'failed': True, 'ignore_errors': True})._check_key('failed') == True
    assert TaskResult(host, task, {'results': [{'failed': True}, {'failed': False}, {}]})._check_key('failed') == True

# Generated at 2022-06-10 23:44:20.928893
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    test_class = TaskResult("host", "task", {
        'changed': True,
        'failed': False,
        'skipped': False,
        'invocation': {},
        '_ansible_parsed': True,
        'module_stdout': '',
        '_ansible_item_result': False,
        'item': '',
        '_ansible_no_log': False,
        '_ansible_verbose_always': True,
        '_ansible_item_label': '',
        '_ansible_ignore_errors': None,
        '_ansible_verbs': [],
        '_ansible_version': '2.7.11'
    })

    # clean_copy() return TaskResult with params (self._host, self._task, {}, self._task_fields)

# Generated at 2022-06-10 23:44:30.875459
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play_context = PlayContext(loader=loader)
    task_name = 'setup'
    task_action = 'setup'
    task_args = {'tree': '/path/to/directory'}
    task_deps = None
    task_loop = None
    task_loop_with_items = None
    playbook_context = None
    task_vars = {'foo': 'bar'}
    task_when = None
    task_register = 'result'
    task_ignore_errors = False
    task_retries = 3
    task_

# Generated at 2022-06-10 23:44:43.197732
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a VariableManager
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create an InventoryManager and add host inventory to it
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager.set_inventory(inventory)

    # Create a task
    task = Task()

    # Create a TaskResult and add task to it
    task_result = TaskResult('', task, {})

    # Check method is_skipped of class TaskResult
    # Check if task_result is skipped when results has empty dict
    task_result._result = {'results': []}

# Generated at 2022-06-10 23:44:55.472867
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-10 23:45:02.765036
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import json

    ansible_vars = VariableManager()
    loader = DataLoader()

    host = Host('server')
    task = Task()
    task.action = 'setup'
    task.no_log = True


# Generated at 2022-06-10 23:45:29.795436
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    result = TaskResult("", "", {})
    assert result.is_skipped() == False

    result = TaskResult("", "", {})
    result._result = {'results':[{'skipped': True}]}
    assert result.is_skipped() == True

    result = TaskResult("", "", {})
    result._result = {'results':[{'skipped': False}]}
    assert result.is_skipped() == False

    result = TaskResult("", "", {})
    result._result = {'results':[{'skipped': False}, {'skipped': False}]}
    assert result.is_skipped() == False

    result = TaskResult("", "", {})
    result._result = {'results':[{'skipped': False}, {'skipped': True}]}
   

# Generated at 2022-06-10 23:45:34.849620
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    test_task = {}
    item1 = {}
    results = [item1]
    test_result = {'results': results}
    tr = TaskResult('host', test_task, test_result)

    assert(tr.is_skipped() == False)

    item1['skipped'] = True
    assert(tr.is_skipped() == True)

# Generated at 2022-06-10 23:45:43.112950
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    '''
    Test the clean_copy method of the TaskResult class.

    The expected values are the same as the output of clean_copy in the controller.
    The test passes if the outputs of the clean_copy method are the same.
    '''
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Values needed to create a TaskResult object
    # Generated with Ansible 2.6.1

    # Results of the result plugin

# Generated at 2022-06-10 23:45:53.361913
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import json
    import sys

    class FakeTask:
        pass

    return_data = {
        "_ansible_verbose_always": True,
        "_ansible_no_log": True,
        "stderr": "",
        "rc": 0,
        "stderr_lines": [],
        "stdout": "",
        "stdout_lines": []
    }
    task_fields = {
        "ignore_errors": True,
        "debugger": "on_failed",
        "name": "setup"
    }
    task = FakeTask()
    task.action = None
    sys.modules['ansible.module_utils.basic'] = FakeTask
    sys.modules['ansible.module_utils.facts'] = FakeTask
    sys.modules['ansible.module_utils.urls']

# Generated at 2022-06-10 23:46:01.080448
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():

    task_result = TaskResult(host=None, task=None, return_data={}, task_fields=None)
    result = task_result.needs_debugger(globally_enabled=True)
    assert not result

    task_result = TaskResult(host=None, task=None, return_data={'failed':True}, task_fields=None)
    result = task_result.needs_debugger(globally_enabled=True)
    assert result

    task_result = TaskResult(host=None, task=None, return_data={'failed':True, 'failed_when_result': True},
                             task_fields={'debugger':'on_failed', 'ignore_errors': True})
    result = task_result.needs_debugger(globally_enabled=True)
    assert not result

    task_result

# Generated at 2022-06-10 23:46:10.865212
# Unit test for method clean_copy of class TaskResult

# Generated at 2022-06-10 23:46:23.910463
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    from ansible.playbook.task import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    import os
    import json

    TESTFILE = os.path.join(os.path.dirname(__file__), "../vars/facts_cache.json")
    FAKEDATA = json.load(open(TESTFILE, 'r'))
    FAKEDATA['invocation'] = {'module_args': {'filter': '*', 'gather_subset': ['all']}}
    FAKEDATA['_ansible_no_log'] = True
    FAKEDATA['_ansible_parsed'] = True

    t = TaskInclude()
    t.attribute_for_host = lambda host: 'TASK'
    t.vars = dict()

# Generated at 2022-06-10 23:46:36.069463
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    task = AnsibleTask()
    task.async_val = 0
    task.poll = 0

    assert(TaskResult({}, task, {'failed': True}).is_failed() is True)
    assert(TaskResult({}, task, {'failed': False}).is_failed() is False)
    assert(TaskResult({}, task, {'failed': 'hat'}).is_failed() is True)
    assert(TaskResult({}, task, {'results': [{'failed': 'hat'}]}).is_failed() is True)
    assert(TaskResult({}, task, {'results': [{'failed': 'hat'}, {}]}).is_failed() is True)
    assert(TaskResult({}, task, {'results': [{}, {}]}).is_failed() is False)

# Generated at 2022-06-10 23:46:43.555749
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():

    test_variables = [
        {'key': 'failed', 'expect': True},
        {'key': 'changed', 'expect': True},
        {'key': 'invocation', 'expect': False},
        {'key': '_ansible_item_label', 'expect': True}
    ]
    test_variables_no_log = [
        {'key': 'failed', 'expect': True},
        {'key': 'attempts', 'expect': True},
        {'key': 'changed', 'expect': True},
        {'key': 'invocation', 'expect': False},
    ]

    # Case 1: set action in C._ACTION_DEBUG
    #         no_log: True

# Generated at 2022-06-10 23:46:49.759898
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    host = "localhost"
    task = None
    return_data = {'skipped': True, 'results': [{'item': 'foo'}]}
    task_fields = None
    task_result = TaskResult(host, task, return_data, task_fields)

    assert task_result.is_skipped() == True
# end of test_TaskResult_is_skipped


# Generated at 2022-06-10 23:47:23.488623
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    '''
    Unit test for method clean_copy of class TaskResult
    '''
    from ansible.plugins.loader import action_loader

    action = action_loader.get('ping', class_only=True)
    task_fields = {'action': 'ping', 'name': 'test_task'}

    task = action.load(task_fields, None, None, '')

    task_result = TaskResult('host-1', task, dict(changed=True, failed=False, skipped=True, unreachable=False, _ansible_verbose_always=True, _ansible_no_log=True, _ansible_item_label='localhost', _ansible_verbose_override=False), task_fields)

    clean_result = task_result.clean_copy()


# Generated at 2022-06-10 23:47:36.803719
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():

    # create a host
    from ansible.inventory.host import Host
    host = Host(name="localhost")

    # create a task
    from ansible.playbook.task import Task
    task = Task()
    task._role = None
    task._parents = []
    task._role_params = {}
    task._task_deps = None
    task._block = task
    task._role_name = None
    task._loop = None
    task._when = None
    task._any_errors_fatal = None
    task._notify = []
    task._loop_with = None
    task._always_run = False
    task._delegate_to = None
    task._transport = 'smart'
    task._no_log = None
    task._run_once = False
    task._use_unsafe_shell

# Generated at 2022-06-10 23:47:45.716808
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # simple test with a tuple:
    input_task_result = TaskResult("host", "task", {'x': "y", '_ansible_foo': "bar", '_ansible_verbose_always': "foo"})
    result = input_task_result.clean_copy()
    assert result._result == {'x': "y", '_ansible_verbose_always': "foo"}, "Failed to remove _ansible_foo from result"

    # test with a list:
    task_result_list = TaskResult("host", "task", {'results': [{'x': "y", '_ansible_foo': "bar", '_ansible_verbose_always': "foo"}, {'_ansible_foo': "bar", '_ansible_verbose_always': "foo"}]})
    result = task

# Generated at 2022-06-10 23:47:59.847298
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    import ansible.playbook.task_include as ti
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.executor.task_result import TaskResult

    task_name = 'test_TaskResult_clean_copy'
    task_action = 'setup'
    task_include = Include()
    task_args = None
    task_tags = ['debug', 'always']
    task_when = None
    task_register = None
    task_loop = None
    task_delegate_to = None
    task_delegate_facts = False
    task_run_once = False

# Generated at 2022-06-10 23:48:11.593914
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # result is a dict
    assert TaskResult('', '', {'skipped': True}).is_skipped()
    assert not TaskResult('', '', {'skipped': False}).is_skipped()
    # result is a list
    assert TaskResult('', '', [{'skipped': True}]).is_skipped()
    assert not TaskResult('', '', [{'skipped': False}]).is_skipped()
    # result is a list of dicts
    assert TaskResult('', '', [{'skipped': True}, {}]).is_skipped()
    assert TaskResult('', '', [{'skipped': True}, {'skipped': True}]).is_skipped()
    assert not TaskResult('', '', [{'skipped': True}, {'skipped': False}]).is_skipped

# Generated at 2022-06-10 23:48:22.179312
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():

    # Examples of task results with skipped flag set to True.
    # Skipped results are identified as True by task.is_skipped().
    # Those examples use different formats of task results and:
    # - no loop
    # - with loop

    task_results1 = dict(skipped=True)
    task_results2 = list([dict(skipped=True)])
    task_results3 = dict(results=[dict(skipped=True)])
    task_results4 = dict(results=list([dict(skipped=True)]))
    task_results5 = dict(results=list([dict(skipped=True), dict(skipped=True)]))

    # Test task results without loop
    assert(TaskResult('localhost', dict(task=dict(action=dict())), task_results1).is_skipped())

# Generated at 2022-06-10 23:48:25.172983
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    assert TaskResult(None, None, {'skipped': True}).is_skipped()
    assert TaskResult(None, None, {'skipped': False}).is_skipped() is False

# Generated at 2022-06-10 23:48:36.327325
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    c = C
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.plugins import callback_loader
    import json
    import os

    class MockTask:
        def __init__(self, name='', no_log=False, action='', ignore_errors=False, debugger=None):
            self.name = name
            self.no_log = no_log
            self.action = action
            self.ignore_errors = ignore_errors
            self.debugger = debugger

        def get_name(self):
            return self.name

    class MockPlayBook:
        def __init__(self, vars={}, dump_callbacks=False):
            self.vars = vars
            self.callback_loader = callback_loader
            self.dump_callbacks = dump_callbacks

# Generated at 2022-06-10 23:48:43.308067
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    task = Task()
    task.action = 'debug'
    task.no_log = True
    task.bypass_host_loop = True
    task._parent = None
    task._role = None
    task._block = None
    task._loader = None
    task._role_name = None
    task._play = None
    task._block_name = None
    task._ds = None
    task._data = None
    task._task_fields = None


# Generated at 2022-06-10 23:48:54.341502
# Unit test for method is_failed of class TaskResult

# Generated at 2022-06-10 23:49:34.004297
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    task = dict(name='test_TaskResult_clean_copy', action='read')
    task_fields = dict(name='test_TaskResult_clean_copy')

    # Case 1 - _ansible_no_log = False
    return_data = dict(item='default',
                       _ansible_no_log=False,
                       _ansible_item_label='default',
                       _ansible_verbose_always=True)
    result = TaskResult('host', task, return_data, task_fields)
    clean_result = result.clean_copy()
    expected_clean_result = dict(item='default',
                                 _ansible_item_label='default',
                                 _ansible_verbose_always=True)
    assert clean_result._result == expected_clean_result

    # Case 2 - _ansible_

# Generated at 2022-06-10 23:49:48.427302
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible import constants as C

    host = Host(name="test")
    task = Task()
    task._role = None
    task._role_name = 'test'
    task._role_path = '/tmp/ansible-role-test'
    task._ds = dict()
    task.action = 'test'
    task.name = 'test'
    task.no_log = None
    task._ds = dict()
    task_vars = dict()
    task_vars['test_var'] = AnsibleUnicode('passed')

# Generated at 2022-06-10 23:49:58.413968
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    # Tests if the method clean_copy completely removes the "failed" key
    # if _ansible_no_log is set to True.
    # The method strip_internal_keys is tested in a unit test of the module
    # ansible.vars.clean.
    task = DummyTask(no_log=True)
    task.action = "test"
    result = TaskResult(None, task, {'failed': False, '_ansible_no_log': True})
    clean = result.clean_copy()
    assert clean._result['_ansible_no_log'] is False
    assert 'failed' not in clean._result

# This class does not implement all methods of the class Task.
# It is only used to test the method clean_copy of the class TaskResult.

# Generated at 2022-06-10 23:50:10.907142
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    expected_result = {
        "_ansible_parsed": True,
        "changed": True,
        "msg": "All items completed",
        "results": [
            {
                "_ansible_item_result": True,
                "_ansible_no_log": False,
                "_ansible_parsed": True,
                "changed": True,
                "invocation": {
                    "module_args": {
                        "name": "some",
                        "state": "absent",
                    },
                    "module_name": "service"
                },
                "parsed": True
            }
        ],
    }


# Generated at 2022-06-10 23:50:21.244691
# Unit test for method is_failed of class TaskResult
def test_TaskResult_is_failed():
    test_string = '''{
        "_ansible_verbose_always": true,
        "_ansible_no_log": false,
        "changed": false,
        "invocation": {
            "module_name": "include_variables",
            "module_args": {
                "paths": [
                    "/home/vagrant/git/ansible-review/test/data/test_tasks/test_include_variables.yml"
                ]
            },
            "_ansible_file_name": "test/data/test_tasks/test_include_variables.yml"
        },
        "msg": "All items completed"
    }'''

    test_data = DataLoader().load(test_string)

    assert not TaskResult(None, None, test_data).is_failed()

# Generated at 2022-06-10 23:50:29.623106
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.yaml import objects

    # test no_log option
    task_no_log = Task()
    task_no_log.action = 'copy'
    task_no_log.no_log = True
    loader = DataLoader()


# Generated at 2022-06-10 23:50:37.557160
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import get_all_plugin_loaders

    mock_loader = get_all_plugin_loaders()

    task = Task()
    task._role_name = AnsibleUnicode('test_TaskResult_clean_copy')
    task.action = 'debug'
    task.set_loader(mock_loader)
    task.module_args = {'msg': 'test_TaskResult_clean_copy'}
    task.args = {}
    task.loop = None
    task.role = None
    task.tags = []
    task.ignore_errors = False


# Generated at 2022-06-10 23:50:46.239380
# Unit test for method is_skipped of class TaskResult
def test_TaskResult_is_skipped():
    # items in is_skipped
    class Host:
        def __init__(self, hostname):
            self.name = hostname

    class Task:
        def __init__(self):
            self.action = 'setup'

        def get_name(self):
            return None

    class TaskResult:
        def __init__(self, host, task, return_data, task_fields=None):
            self._host = host
            self._task = task

            if isinstance(return_data, dict):
                self._result = return_data.copy()
            else:
                self._result = DataLoader().load(return_data)

            if task_fields is None:
                self._task_fields = dict()
            else:
                self._task_fields = task_fields

    host = Host('test_host')

# Generated at 2022-06-10 23:50:56.504908
# Unit test for method needs_debugger of class TaskResult
def test_TaskResult_needs_debugger():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

# Generated at 2022-06-10 23:51:04.984226
# Unit test for method clean_copy of class TaskResult
def test_TaskResult_clean_copy():
    from ansible.playbook.task import Task

    results = {'failed': True, 'exception': 'foo', 'msg': 'bar',
               '_ansible_item_label': 'blah', '_ansible_verbose_always': True,
               '_ansible_ignore_errors': True, '_ansible_no_log': True,
               '_ansible_verbose_override': True, 'invocation': 'invocation',
               'attempts': 7, 'changed': False, 'retries': 3}

    task = Task.load({'action': {'__ansible_module__': 'foo', '__ansible_arguments__': []}, 'name': 'foo task'})
    t = TaskResult('meh', task, results)
    clean_t = t.clean_copy()
