

# Generated at 2022-06-29 18:06:45.582488
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1', position=-3) == '1.0.0'
    assert bump_version('0.1.1', position=-2) == '0.2.0'
    assert bump_version('0.1.1', position=-1) == '0.1.2'
    assert bump_version('0.1.1', position=0) == '1.0.0'
    assert bump_version('0.1.1', position=1) == '0.2.0'
    assert bump_version('0.1.1', position=2) == '0.1.2'
    assert bump_version('0.1.1', pre_release='a') == '0.2.0a0'

# Generated at 2022-06-29 18:06:53.352290
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.1', 0) == '2.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.1.0', 1) == '1.2.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.1', 2) == '1.0.2'
    assert bump_version('1.0.0', 0, 'a') == '2.0.0'
    assert bump_version('1.0.0', 0, 'alpha') == '2.0.0'

# Generated at 2022-06-29 18:07:01.215222
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'b') == '1.1b0'
    assert bump_version('1.0.0', -2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -1, 'b') == '1.0.1b0'

# Generated at 2022-06-29 18:07:12.819440
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # pylint: disable=R0914
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'a') == '1.2.4a0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.2.4a0'

    assert bump_version('1.2.3', 1, 'b') == '1.2.4b0'
    assert bump_version('1.2.3', 1, 'beta') == '1.2.4b0'


# Generated at 2022-06-29 18:07:23.689688
# Unit test for function bump_version
def test_bump_version():
    pass

    # def test_bump_version():
    #     from textwrap import dedent
    #
    #     test_cases = dedent(
    #         """
    #     (0, 0, 0, 'Alpha-', 1),
    #     (0, 0, 0, 'Alpha', 1),
    #     (0, 0, 0, 'alpha-', 1),
    #     (0, 0, 0, 'alpha', 1),
    #     (0, 0, 0, 'a', 1),
    #     (0, 0, 0, 'a-', 1),
    #     (0, 0, 0, 'a-1', 1),
    #     (0, 0, 0, 'a-12', 1),
    #     (0, 0, 0, 'a-12.3', 1),
   

# Generated at 2022-06-29 18:07:34.457543
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version."""
    func_name = bump_version.__name__

    r0 = bump_version('1.0.0a0')
    assert r0 == '1.0.0a1', "Unexpected %s result: %r" % (func_name, r0)

    r1 = bump_version('1.0.0a1')
    assert r1 == '1.0.0a2', "Unexpected %s result: %r" % (func_name, r1)

    r2 = bump_version('1.0.0a2')
    assert r2 == '1.0.0a3', "Unexpected %s result: %r" % (func_name, r2)

    r3 = bump_version('1.0.0b0')

# Generated at 2022-06-29 18:07:46.370197
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.9') == '1.2.10'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3.0a0'
    assert bump_version('1.2.3', position=1, pre_release='Alpha') == '1.3.0a0'

# Generated at 2022-06-29 18:07:55.163885
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import pytest
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.0.0', 1) == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1) == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.9.0') == '2.0.0'
    assert bump_version('1.9.0', 1) == '1.10.0'

# Generated at 2022-06-29 18:07:56.024160
# Unit test for function bump_version
def test_bump_version():
    bump_version('0.1.1')

# Generated at 2022-06-29 18:08:09.312950
# Unit test for function bump_version
def test_bump_version():

    assert(bump_version('1.0.0') == '1.0.1')
    assert(bump_version('1.0.0', position=1) == '1.1.0')
    assert(bump_version('1.0.0', position=-1) == '1.1.0')
    assert(bump_version('1.0.0', position=0) == '2.0.0')
    assert(bump_version('1.0.0', position=-3) == '2.0.0')

    assert(bump_version('1.0.0', pre_release='a') == '1.0.0a1')
    assert(bump_version('1.0.0a1', pre_release='a') == '1.0.0a2')

# Generated at 2022-06-29 18:08:30.238351
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0-a0') == '1.0.1'
    assert bump_version('1.0.1-a0') == '1.0.2'
    assert bump_version('1.0.1-a1') == '1.0.2'
    assert bump_version('1.0.1-a0', pre_release='a') == '1.0.1-a1'
    assert bump_version('1.0.1-a1', pre_release='a') == '1.0.1-a2'

# Generated at 2022-06-29 18:08:38.435079
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:51.286268
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0-a0') == '1.0.1'
    assert bump_version('1.0.0-alpha0') == '1.0.1'
    assert bump_version('1.0.1-alpha1') == '1.0.2'
    assert bump_version('1.0.1-beta1') == '1.0.2'
    assert bump_version('1.0.0-beta0') == '1.0.1'
    assert bump_version('1.0.1-b1') == '1.0.2'

# Generated at 2022-06-29 18:09:04.350462
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3b1') == '1.2.3b2'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.2.3a0'
    assert bump_version('1.2.3a0', 1, 'alpha') == '1.3.0'

# Generated at 2022-06-29 18:09:16.682876
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.
    """
    import json
    import os

    # Read the test data
    cur_path = os.path.dirname(os.path.abspath(__file__))
    test_data_path = os.path.join(cur_path, 'test_data/bump_version.json')
    with open(test_data_path, 'r') as test_data_file:
        test_data = json.load(test_data_file)
    # Run the tests
    # pylint: disable=C0103
    for test_id, test in enumerate(test_data):
        position = test[1]['position']
        pre_release = test[1]['pre_release']
        should_be = test[1]['should_be']

# Generated at 2022-06-29 18:09:23.660929
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914
    """
    Unit test for function bump_version
    """
    import pytest
    major_expectations = (
        ('0.1.0', _BUMP_VERSION_MAJOR),
        ('1.0.0', _BUMP_VERSION_MAJOR),
        ('1.0.0.post0', _BUMP_VERSION_MAJOR),
    )
    minor_expectations = (
        ('0.1.0', _BUMP_VERSION_MINOR),
        ('1.1.0', _BUMP_VERSION_MINOR),
        ('1.1.0.post0', _BUMP_VERSION_MINOR),
    )

# Generated at 2022-06-29 18:09:36.543963
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('0.1.0', 2, pre_release='alpha') == '0.1.1a0'
    assert bump_version('0.1.0a0', 2, pre_release='alpha') == '0.1.1a1'
    assert bump_version('0.1.0a0', 2, pre_release='beta') == '0.1.1b0'
    assert bump_version('0.1.0b0', 2, pre_release='alpha') == '0.1.1a0'

# Generated at 2022-06-29 18:09:43.848543
# Unit test for function bump_version
def test_bump_version():
    res = bump_version('1.0.0')
    assert res == '1.0.1'

    res = bump_version('1.0.0', 3)
    assert res == '1.0.1'

    res = bump_version('1.1.0')
    assert res == '1.2.0'

    res = bump_version('1.1.0', 1)
    assert res == '1.2.0'

    res = bump_version('1.1.0', -2)
    assert res == '1.2.0'

    res = bump_version('1.0.0', 0)
    assert res == '2.0.0'

    res = bump_version('1.0.0', -3)
    assert res == '2.0.0'

    res = bump_

# Generated at 2022-06-29 18:09:56.484899
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.0', position=0) == '1.0.0'
    assert bump_version('1.1.0', position=0) == '2.0.0'
    assert bump_version('0.1.2', position=0) == '1.0.0'
    assert bump_version('0.1.0', position=1, pre_release='a') == '0.2a0'
    assert bump_version

# Generated at 2022-06-29 18:10:07.025943
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'alpha') == '1.0.1a0'
    assert bump_version('1.0.1', 2, 'a') == '1.0.1a1'
    assert bump_version('1.0.1a1', 2, 'a') == '1.0.2'

# Generated at 2022-06-29 18:10:13.117424
# Unit test for function bump_version
def test_bump_version():
    from .utils import _bump_util

    _bump_util(bump_version)

# Generated at 2022-06-29 18:10:25.161272
# Unit test for function bump_version
def test_bump_version():
    """Test the function ``bump_version``."""

# Generated at 2022-06-29 18:10:37.355583
# Unit test for function bump_version
def test_bump_version():
    import unittest
    from .version import __version__

    class TestBumpVersion(unittest.TestCase):

        def test_bump_version_no_options(self):
            self.assertEqual(__version__, '0.3.1')
            self.assertEqual(bump_version(__version__), '0.3.2')
            self.assertEqual(bump_version(__version__, 1), '0.4.0')
            self.assertEqual(bump_version(__version__, 0), '1.0.0')
            self.assertEqual(bump_version(__version__, 0), '1.0.0')
            self.assertEqual(bump_version(__version__, -1), '0.3.2')
            self.assertE

# Generated at 2022-06-29 18:10:49.396139
# Unit test for function bump_version
def test_bump_version():
    def test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = '',
    ) -> None:
        result = bump_version(version, position, pre_release)
        if result != expected:
            raise AssertionError(
                "When calling 'bump_version(%r, %r, %r), got:\n%s\n\n"
                "Expected:\n%s" % (
                    version,
                    position,
                    pre_release,
                    result,
                    expected,
                )
            )

    test(
        version='0.1',
        expected='0.2',
    )
    test(
        version='1.2',
        position=1,
        expected='2.2',
    )


# Generated at 2022-06-29 18:11:01.921155
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('0.1.0')  # Version bump patch
    assert version == '0.1.1'
    version = bump_version('0.1.0', 1)  # Version bump minor
    assert version == '0.2.0'
    version = bump_version('0.2.0', 0)  # Version bump major
    assert version == '1.0.0'
    version = bump_version('0.1.1', 1, 'a')  # Version bump minor alpha
    assert version == '0.2.1a0'
    version = bump_version('0.2.1a2', 1, 'b')  # Version bump minor beta
    assert version == '0.3.1b0'
    version = bump_version('0.2.1a2', 1)  # Version bump minor

# Generated at 2022-06-29 18:11:10.312509
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,C0303,W0105
    assert bump_version('1.2') == '2.0'  # noqa: W605
    assert bump_version('1.2', position=1) == '1.3'
    assert bump_version('1.2', position=-2) == '1.3'
    assert bump_version('1.2', position=-1) == '1.2.1'
    assert bump_version('1.2', position=-2, pre_release='beta') == '1.2b0'
    assert bump_version('1.2b0', position=-2, pre_release='b') == '1.2b1'
    assert bump_version('1.2b0', position=-2, pre_release='alpha') == '1.2b0'

# Generated at 2022-06-29 18:11:21.943840
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:35.419959
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', pre_release='b') == '1.0.0b0'
    assert bump_version('1.2.3b3', pre_release='b') == '1.2.3b4'
    assert bump_version('1.2.3a3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.0', pre_release='b') == '1.2.0b0'
    assert bump_version('1.2.0', pre_release='b', position=1) == '1.2.0b0'

# Generated at 2022-06-29 18:11:46.401010
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    def _are_equal(
            v1: str,
            v2: str
    ) -> bool:
        return StrictVersion(v1) == StrictVersion(v2)

    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        if expected is None:
            with pytest.raises(ValueError):
                bump_version(
                    version,
                    position=position,
                    pre_release=pre_release
                )
            return
        actual = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        assert _are_equal(expected, actual)


# Generated at 2022-06-29 18:11:57.638524
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.3', 0) == '1.0.0'
    assert bump_version('0.2.3', 0, 'alpha') == '1.0.0'
    assert bump_version('0.2.3', 0, 'beta') == '1.0.0'

    assert bump_version('0.2.3', 1) == '0.3.0'
    assert bump_version('0.2.3', 1, 'alpha') == '0.3.0a0'
    assert bump_version('0.2.3', 1, 'beta') == '0.3.0b0'
    assert bump_version('0.2.3', 1, 'a') == '0.3.0a0'
    assert bump_version('0.2.3', 1, 'b')

# Generated at 2022-06-29 18:12:13.842505
# Unit test for function bump_version
def test_bump_version():
    '''
    Unit tests for function bump_version
    '''
    #
    # Print the test version number
    #
    test_version_number = bump_version.__doc__.split('\n')[1]
    print('Test version number: %s' % test_version_number)
    #
    # Test the various version bump types
    #
    the_test = _build_version_info('0.0.4')
    assert(the_test.major.num == 0)
    assert(the_test.major.pos == 0)
    assert(the_test.minor.num == 0)
    assert(the_test.minor.pos == 1)
    assert(the_test.patch.num == 4)
    assert(the_test.patch.pos == 2)

# Generated at 2022-06-29 18:12:24.338939
# Unit test for function bump_version
def test_bump_version():
    ver_str = '1.2.3'
    assert bump_version(ver_str, 0) == '2.0.0'
    assert bump_version(ver_str, 0, 'a') == '2.0.0'
    assert bump_version(ver_str, 1) == '1.3.0'
    assert bump_version(ver_str, 1, 'a') == '1.3.0'
    assert bump_version(ver_str, 2) == '1.2.4'
    assert bump_version(ver_str, 2, 'a') == '1.2.4'
    assert bump_version(ver_str, -1) == '1.2.4'
    assert bump_version(ver_str, -2) == '1.3.0'

# Generated at 2022-06-29 18:12:29.466999
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    ver_str = '1.2.3.4'
    bump_pos = 2
    pre_release = 'b'

    # Act
    new_ver_str = bump_version(ver_str, bump_pos, pre_release)

    # Assert
    assert new_ver_str == '1.2.3b0'



# Generated at 2022-06-29 18:12:42.098614
# Unit test for function bump_version
def test_bump_version():
    from .__about__ import __version__
    from .__support__ import build_module_version

    test_version = build_module_version()

    # Major
    bumped = bump_version(test_version, position=0)
    bumped_should_be = '%s.0.0' % (int(test_version.split('.')[0]) + 1)
    assert bumped == bumped_should_be
    bumped = bump_version(test_version, position=-3)
    assert bumped == bumped_should_be

    # Minor
    bumped = bump_version(test_version, position=1)
    bumped_should_be = '%s.%s.0' % (
        test_version.split('.')[0],
        int(test_version.split('.')[1]) + 1
    )

# Generated at 2022-06-29 18:12:53.642846
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version"""
    # basic test
    test_version = '1.2.3'
    assert bump_version(test_version) == '1.2.4'
    assert bump_version(test_version, 2) == '1.2.4'
    assert bump_version(test_version, 1) == '1.3.0'
    assert bump_version(test_version, 0) == '2.0.0'
    assert bump_version(test_version, -3) == '1.2.4'
    assert bump_version(test_version, -2) == '1.3.0'
    assert bump_version(test_version, -1) == '2.0.0'
    # test pre-release
    pre_release = 'alpha'

# Generated at 2022-06-29 18:13:02.848308
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.12.3') == '0.12.4'
    assert bump_version('0.12.3', 2, 'beta') == '0.12.4b0'
    assert bump_version('0.12.3', 1, 'beta') == '0.13b0'
    assert bump_version('0.12.3', 1, 'alpha') == '0.13a0'
    assert bump_version('0.12.3a5', 1, 'beta') == '0.13b0'
    assert bump_version('0.12.3a5', 1, None) == '0.13'
    assert bump_version('0.12.3b5', 1, 'alpha') == '0.13a0'

# Generated at 2022-06-29 18:13:15.549952
# Unit test for function bump_version
def test_bump_version():
    def test_bump_version_inner(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected_result: str = ''
    ) -> None:
        result = bump_version(version, position, pre_release)
        assert result == expected_result

    def setup_test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected_result: str = ''
    ) -> None:
        args = (version, position, pre_release)
        kwargs = {'expected_result': expected_result}
        return args, kwargs


# Generated at 2022-06-29 18:13:23.583358
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    Raises:
        AssertionError: if the given ``version`` is an invalid version number.
        
    """
    # Create a function for testing
    def assert_version(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> bool:
        ver = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        return ver == expected

    # Run tests
    assert assert_version('1.2.3', '1.2.4')
    assert assert_version('1.2.3', '1.2.4', 2)
    assert assert_version('1.2.3', '1.2.4', position=2)

# Generated at 2022-06-29 18:13:36.664756
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: bump_version')

    # Test populating results dictionary

# Generated at 2022-06-29 18:13:46.504483
# Unit test for function bump_version
def test_bump_version():
    """Test."""
    print('in test')
    version = bump_version('1.2.3')
    assert version == '1.2.4'

    version = bump_version('1.2.0')
    assert version == '1.2.0'

    version = bump_version('1.2.3', position=2)
    assert version == '1.2.4'

    version = bump_version('1.2.3', position=1)
    assert version == '1.3.0'

    version = bump_version('1.2.3', position=0)
    assert version == '2.0.0'

    version = bump_version('1.2.3-rc5', position=2, pre_release='a')
    assert version == '1.2.4-a0'

    version

# Generated at 2022-06-29 18:14:02.459455
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert '1.0.0' == bump_version('0.0.0')
    assert '1.0.1' == bump_version('1.0.0')
    assert '1.1.0' == bump_version('1.0.0', 1)
    assert '1.1.0.0' == bump_version('1.1.0')
    assert '1.1.1' == bump_version('1.1.0', 2)
    assert '1.1.1' == bump_version('1.1.0.0')
    assert '1.1.0.0a0' == bump_version('1.1.0.0', 2, 'a')

# Generated at 2022-06-29 18:14:11.990374
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=W0110
    """
    Tests for the function
    :meth:`kurt.util.version.bump_version`.
    """
    from kurt.util.version import bump_version

    def _test_it(ver, pos, pre, expect):
        result = bump_version(ver, pos, pre)
        assert result == expect, (
            "Version number bumped from: %r, at position: %r, "
            "with pre-release: %r, did not get expected output: %r" % (
                ver,
                pos,
                pre,
                expect
            )
        )

    _test_it('1.2.3', -1, 'a', '1.3.0')

# Generated at 2022-06-29 18:14:20.244063
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', pre_release='alpha') == '0.1.0a0'
    assert bump_version('0.1.0a1', pre_release='alpha') == '0.1.0a2'
    assert bump_version('0.1.0b1', pre_release='alpha') == '0.1.1a1'
    assert bump_version('0.1.0b4', pre_release='alpha') == '0.1.0a0'

# Generated at 2022-06-29 18:14:31.531811
# Unit test for function bump_version
def test_bump_version():
    import os
    import tempfile

    # Define the test iterable

# Generated at 2022-06-29 18:14:43.130552
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:49.933525
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:01.924992
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0', pre_release='alpha') == '1.0.0a0'
    assert bump_version('1.0.0', pre_release='beta') == '1.0.0b0'
    assert bump_version('1.0.0a0', pre_release='a') == '1.0.0a1'
    assert bump_version('1.0.0a0', pre_release='b')

# Generated at 2022-06-29 18:15:10.312534
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '2.0.1'
    assert bump_version('2.0.0', 1) == '2.1.0'
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('2.0.0', 2) == '2.0.1'
    assert bump_version('2.0.0', -1) == '2.0.1'
    assert bump_version('2.0.0', -2) == '2.1.0'
    assert bump_version('2.0.0', -3) == '3.0.0'
    assert bump_version('2.0.0', pre_release='a') == '2.0.1a0'

# Generated at 2022-06-29 18:15:22.665631
# Unit test for function bump_version
def test_bump_version():
    """Test 'bump_version' function."""
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 3, 'a') == '0.1.1'
    assert bump_version('0.1.0', 2, 'a') == '0.1.0a0'
    assert bump_version('0.1.0', 2, 'A') == '0.1.0a0'
    assert bump_version('0.1.0', 1, 'b') == '0.2.0'
    assert bump_version('0.1.0a0', 2, 'b') == '0.1.0a0b0'

# Generated at 2022-06-29 18:15:32.031342
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0a0') == '1.2.1a0'
    assert bump_version('1.2.0a5') == '1.2.1a0'
    assert bump_version('1.2.3a4') == '1.2.4a0'
    assert bump_version('1.2.3a4') == '1.2.4a0'

# Generated at 2022-06-29 18:15:47.146233
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'"""
    def check(before: str, version: str) -> None:
        before = cast(str, before)
        version = cast(str, version)
        out = bump_version(before)
        assert out == version, (
            "Returned version number, %r, not as expected: %r"
            % (out, version)
        )
    check(before='1.2.3', version='1.2.4')
    check(before='1.2.0', version='1.2.1')
    check(before='1.2.3.dev', version='1.2.4')
    check(before='1.2.3a0.dev', version='1.2.3a1')

# Generated at 2022-06-29 18:15:56.842266
# Unit test for function bump_version
def test_bump_version():
    version = "0.0.0"
    assert bump_version(version) == "0.0.1"

    version = "0.0.1"
    assert bump_version(version) == "0.0.2"

    version = "0.0.1"
    assert bump_version(version, pre_release="beta") == "0.0.1b0"

    version = "0.0.1b0"
    assert bump_version(version, pre_release="beta") == "0.0.1b1"

    version = "0.0.1b0"
    assert bump_version(version) == "0.0.2"

    version = "0.0.1b0"
    assert bump_version(version, position=1) == "0.1.1"


# Generated at 2022-06-29 18:16:08.154814
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1a0') == '0.0.1a1'
    assert bump_version('0.0.1a1') == '0.0.1a2'
    assert bump_version('0.0.1b0') == '0.0.1b1'
    assert bump_version('0.0.1b1') == '0.0.1b2'

    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.1.0') == '0.1.1'