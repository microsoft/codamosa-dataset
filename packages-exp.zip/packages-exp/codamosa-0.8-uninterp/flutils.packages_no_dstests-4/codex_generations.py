

# Generated at 2022-06-29 18:06:47.735817
# Unit test for function bump_version
def test_bump_version():
    version = '0.2.5'
    result = bump_version(version)
    assert result == '0.2.6'
    result = bump_version(version, position=1)
    assert result == '0.3.0'
    result = bump_version(version, position=1, pre_release='b')
    assert result == '0.3.0b0'
    result = bump_version(result, position=1, pre_release='b')
    assert result == '0.3.0b1'
    result = bump_version(result, position=1, pre_release='b')
    assert result == '0.3.0b2'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:06:56.801356
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0912,R0915
    """Test ``bump_version`` function."""
    # noinspection PyUnusedLocal
    def _check(info, version, position, pre_release, expected):
        if (version, position, pre_release) == expected:
            return
        actual = bump_version(version, position, pre_release)
        assert expected == (version, position, pre_release), (
            '%s: failed\n\tversion: %r\n\tposition: %r\n\tpre_release: %r\n'
            '\texpected: %r\n\tactual  : %r\n' % (
                info,
                version,
                position,
                pre_release,
                expected,
                actual
            )
        )


# Generated at 2022-06-29 18:07:03.178109
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3a0'
    new_version = bump_version(version)
    assert new_version == '1.2.3a1', new_version

if __name__ == '__main__':
    """
    Since bump_version() is a public function and we want to perform unit
    tests on it, we have made it available for testing and demonstration.
    """
    test_bump_version()

# Generated at 2022-06-29 18:07:14.937840
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:24.996872
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Test bump_version()"""
    # pylint: disable=R0912,R0915
    print('Running test_bump_version')
    versions = []
    tests = []
    versions.append(
        ('1.2.3-alpha', _build_version_info('1.2.3-alpha'))
    )
    versions.append(
        ('1.2-alpha', _build_version_info('1.2-alpha'))
    )
    versions.append(
        (' 1.2alpha', _build_version_info(' 1.2alpha'))
    )
    versions.append(
        ('1.2a', _build_version_info('1.2a'))
    )

# Generated at 2022-06-29 18:07:36.573245
# Unit test for function bump_version
def test_bump_version():
    """Test case for the **bump_version** function."""
    # Test 'bump_version' function

    assert(
        bump_version(
            '1.2.3'
        ) == '1.2.4'
    )
    assert(
        bump_version(
            '1.2.0'
        ) == '1.2.1'
    )
    assert(
        bump_version(
            '1.2.3', position=1
        ) == '1.3.0'
    )
    assert(
        bump_version(
            '1.2.3', position=1, pre_release='b'
        ) == '1.3b0'
    )

# Generated at 2022-06-29 18:07:48.316071
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    def do_test(version, position, pre_release, expected):
        # noinspection PyUnusedLocal
        result = bump_version(version, position, pre_release)
        assert isinstance(result, str)
        assert result == expected

    do_test('0.0.0', 0, None, '1.0.0')
    do_test('0.0.0', 1, None, '0.1.0')
    do_test('0.0.0', 2, None, '0.0.1')

    do_test('0.0.0', -3, None, '1.0.0')
    do_test('0.0.0', -2, None, '0.1.0')

# Generated at 2022-06-29 18:07:56.155617
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', -1) == '0.0.2'

    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', -2) == '0.1.1'

    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0', -3) == '1.1.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'

# Generated at 2022-06-29 18:08:09.486209
# Unit test for function bump_version
def test_bump_version():
    no_pre = ['1.2', '1.2.3', '1.2.4']
    pre_beta = ['1.2b0', '1.2.3b4']
    pre_alpha = ['1.2a0', '1.2.3a4']

# Generated at 2022-06-29 18:08:20.060528
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3.4.5') == '2.0'
    assert bump_version('1.2.3.4.5', position=0) == '2.0'
    assert bump_version('1.2.3.4.5', position=1) == '1.3'
    assert bump_version('1.2.3.4.5', position=2) == '1.2.4'
    assert bump_version('1.2.3.4.5', position=-1) == '1.2.4'
    assert bump_version('1.2.3.4.5', position=-2) == '1.3'
    assert bump_version('1.2.3.4.5', position=-3) == '2.0'

# Generated at 2022-06-29 18:08:51.921697
# Unit test for function bump_version
def test_bump_version():
    version = '0.5.5'
    assert bump_version(version) == '0.5.6'
    assert bump_version(version, 0) == '1.0.0'
    assert bump_version(version, 1) == '0.6.0'
    assert bump_version(version, 2) == '0.5.6'
    assert bump_version(version, 3) == '0.5.5'
    assert bump_version(version, -1) == '0.5.6'
    assert bump_version(version, -2) == '0.6.0'
    assert bump_version(version, -3) == '1.0.0'

    version = '0.6.2.dev-59-gcb4e6bd'

# Generated at 2022-06-29 18:08:58.431000
# Unit test for function bump_version
def test_bump_version():
    """test bump_version"""
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', position=2) == '0.1.1'
    assert bump_version('0.1.0', position=0) == '1.0.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.0', position=-1) == '0.1.1'
    assert bump_version('0.1.0', position=-2) == '0.2.0'
    assert bump_version('0.1.0', position=-3) == '1.0.0'

# Generated at 2022-06-29 18:09:11.264477
# Unit test for function bump_version
def test_bump_version():

    ver_obj = bump_version('0.23.1', position=2)
    assert ver_obj == "0.23.2"
    ver_obj = bump_version('0.23.1', position=1)
    assert ver_obj == "0.24"
    ver_obj = bump_version('0.23.1', position=0)
    assert ver_obj == "1.0"
    ver_obj = bump_version('0.23.1')
    assert ver_obj == "0.23.2"
    ver_obj = bump_version('0.23.1', position=2, pre_release="b")
    assert ver_obj == "0.23.2b0"
    ver_obj = bump_version('0.23.1', position=1, pre_release="a")
    assert ver

# Generated at 2022-06-29 18:09:21.197399
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914,R0915
    def test_loop(test_args):
        # noinspection PyUnusedLocal
        out: str = bump_version(test_args.version, test_args.position, test_args.pre_release)
        assert out == test_args.expected, '%s != %s' % (out, test_args.expected)
    try:
        test_args = '1.2.3'
        assert isinstance(test_args, str) is True
    except AssertionError:
        raise AssertionError("'test_args' should be a 'str'.")


# Generated at 2022-06-29 18:09:33.819341
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 1, 'alpha') == '0.2a0'
    assert bump_version('0.1.0', 1, 'b') == '0.2b0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0', 0, 'b') == '1.0.0'
    assert bump_version('0.1.0', position=0) == '1.0.0'

# Generated at 2022-06-29 18:09:44.509821
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'b') == '1.1.0b0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'

# Generated at 2022-06-29 18:09:57.165841
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=-1) == '1.2.1'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3.0'

# Generated at 2022-06-29 18:10:07.567519
# Unit test for function bump_version
def test_bump_version():
    """Test that the bump_version function operates as expected."""
    # Basic tests
    assert '0.0.1' == bump_version('0.0.0')
    assert '0.1.0' == bump_version('0.0.1')
    assert '0.1.1' == bump_version('0.1.0')
    assert '1.0.0' == bump_version('0.1.1')
    # Alpha tests
    assert '0.0.1a1' == bump_version('0.0.1a0')
    assert '0.1.1a1' == bump_version('0.1.1a0')
    assert '0.0.1b1' == bump_version('0.0.1a1')
    assert '0.1.1b1' == bump_version

# Generated at 2022-06-29 18:10:12.068921
# Unit test for function bump_version
def test_bump_version():
    # Test no bump
    assert bump_version('1.0.0') == '1.0.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=-1) == '1.1.0'
    assert bump_version('1.0.0', position=-2) == '2.0.0'
    assert bump_version('1.0.0', position=-3) == '1.0.1'
    # Test pre-releases

# Generated at 2022-06-29 18:10:24.897161
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version"""
    # A test for the function bump_version().
    # This function is used for the VersionControl class.
    # https://github.com/saltstack/salt/blob/master/salt/version.py
    # pylint: disable=R0914

    def assert_eq(data1, data2):
        assert data1 == data2, '%r should equal %r' % (data1, data2)

    assert_eq(bump_version('0.0.1'), '0.0.2')
    assert_eq(bump_version('0.0.1', pre_release='b'), '0.1.0b0')
    assert_eq(bump_version('0.0.1', position=1), '1.0.0')

# Generated at 2022-06-29 18:10:39.938693
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:53.228638
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2.3', 0) == '2'
    assert bump_version('1.2.3', 1, 'a') == '1.3a0'
    assert bump_version('1.2.3a0', 1, 'a') == '1.3a1'
    assert bump_version('1.2.3', 1, 'b') == '1.3b0'
    assert bump_version('1.2.3b0', 1, 'b') == '1.3b1'
    assert bump_version('1.2.3a0', 2, 'b') == '1.2.3b0'


# Generated at 2022-06-29 18:11:00.434683
# Unit test for function bump_version
def test_bump_version():
    version = '1.12.101'
    position = 1
    pre_release = 'b'
    # test
    assert bump_version(version,position,pre_release) == '1.12b0'

    version = '1.12.101'
    position = -1
    pre_release = 'b'
    # test
    assert bump_version(version,position,pre_release) == '1.12.101b0'

# Generated at 2022-06-29 18:11:09.622485
# Unit test for function bump_version
def test_bump_version():
    def run_test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_result: str
    ) -> None:
        result = bump_version(
            version, position=position, pre_release=pre_release
        )
        if result != expected_result:
            raise ValueError(
                "bump_version(%r, position=%r, "
                "pre_release=%r) returned: %r.  Expected: %r" % (
                    version,
                    position,
                    pre_release,
                    result,
                    expected_result
                )
            )



# Generated at 2022-06-29 18:11:21.461150
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function bump_version
    """
    assert bump_version('0.2.0a0') == '0.2.0a1'
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1a0') == '0.2.1a1'
    assert bump_version('0.2.1b0') == '0.2.1b1'
    assert bump_version('0.2.1a1') == '0.2.1a2'
    assert bump_version('0.2.1b1') == '0.2.1b2'

# Generated at 2022-06-29 18:11:34.897336
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2, 'a') == '1.2.3a0'
    assert bump_version('1.2.3alpha4') == '1.2.3alpha5'
    assert bump_version('1.2.3', 1, 'b') == '1.3b0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('2.0.0', 2) == '2.0.1'
    assert bump_version('2.0.0', 0, 'a') == '3.0.0'
    assert bump_version('2.0.0alpha1') == '2.0.0alpha2'

# Generated at 2022-06-29 18:11:42.200206
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from unittest.case import TestCase
    from unittest import mock
    from io import StringIO
    import sys

    with mock.patch('sys.stdout', new_callable=StringIO) as mock_stdout:
        with mock.patch('sys.stderr', new_callable=StringIO) as mock_stderr:
            with mock.patch('sys.path', []) as mock_path:
                old_exit = sys.exit
                try:
                    sys.exit = mock.Mock()
                    # import the module, with the patched sys
                    import bump_version  # pylint: disable=E0401
                    sys.exit.assert_not_called()
                finally:
                    sys.exit = old_exit


# Generated at 2022-06-29 18:11:51.349886
# Unit test for function bump_version
def test_bump_version():
    # Test the case of no pre-release
    # Should increase the patch position
    assert bump_version('1.2.0') == '1.2.1'
    # Should increase the minor position
    assert bump_version('1.0.3', 1) == '1.1.0'
    # Should increase the minor position
    assert bump_version('1.0.3', 'minor') == '1.1.0'
    # Should increase the major position
    assert bump_version('1.1.5', 0) == '2.0.0'
    # Should increase the major position
    assert bump_version('1.1.5', 'major') == '2.0.0'
    # Should increase the patch position
    assert bump_version('0.0.0', 'patch') == '0.0.1'


# Generated at 2022-06-29 18:12:02.976887
# Unit test for function bump_version
def test_bump_version():
    for pos in (0,1,2):
        print('--- Bumping major/minor/patch positions ---')
        print(bump_version('1.0.0', pos))
    print('--- Bumping major/minor/patch with alpha/beta ---')
    print(bump_version('1.0.0a0', 2, 'a'))
    print(bump_version('1.0.0b0', 2, 'b'))
    print(bump_version('1.0a0', 1, 'a'))
    print(bump_version('1.0b0', 1, 'b'))


# Unit test to test each position
# TODO: Add 'bad' tests as well

# Generated at 2022-06-29 18:12:15.276417
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:27.315254
# Unit test for function bump_version
def test_bump_version():
#   print('bump_version')
    def test_it(version, expected):
        actual = bump_version(version)
        print(f"    {version} -> {actual}")
        # assert actual == expected
#   test_it('0.0.0', '0.0.1')
    # test_it('0.0.1', '0.0.2')
    # test_it('0.0.2', '0.0.3')
    # test_it('0.0.3', '0.0.4')
    # test_it('0.0.4', '0.0.5')
    # test_it('0.0.5', '0.0.6')
    # test_it('0.0.6', '0.0.7')
    # test_it('

# Generated at 2022-06-29 18:12:39.589188
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    ver = "1.0.0"

    # Act
    out = bump_version(ver)

    # Assert
    assert(out == "1.1.0")

    # Act
    out = bump_version(ver, 0)

    # Assert
    assert(out == "2.0.0")

    # Act
    out = bump_version(ver, 2)

    # Assert
    assert(out == "1.0.1")

    # Act
    out = bump_version(ver, 0, "alpha")

    # Assert
    assert(out == "1.1.0")

    # Act
    out = bump_version(ver, 1, "alpha")

    # Assert
    assert(out == "1.1.0")

    # Act
    out = bump_

# Generated at 2022-06-29 18:12:50.595844
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0') == '1.1'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=-1) == '0.0.1'
    assert bump_version('0.0.0', position=-2) == '0.1.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'
    assert bump_version('0.2-beta1') == '0.2.1'
    assert bump_version('0.2-beta1', position=1) == '0.3'

# Generated at 2022-06-29 18:13:01.367341
# Unit test for function bump_version
def test_bump_version():
    from .test_bumpversion import (
        VERSION_NUMBERS,
        BUMP_VERSION_EXPT,
    )
    for i, ver_info in enumerate(VERSION_NUMBERS):
        BUMP_VERSION_EXPT[i] = bump_version(
            ver_info['version'],
            ver_info['position'],
            ver_info['pre_release'],
        )

# Generated at 2022-06-29 18:13:02.946159
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212,W0612
    raise NotImplementedError()


# Generated at 2022-06-29 18:13:15.643824
# Unit test for function bump_version
def test_bump_version():
    """Unit test function."""
    # First test
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=2, pre_release='Alpha') == '1.2.4a0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'

    # Second test
    assert bump_version('1.2.3', position=1) == '1.3.0'

# Generated at 2022-06-29 18:13:23.636202
# Unit test for function bump_version
def test_bump_version():
    # Simple test
    assert bump_version('0.1.2') == '0.1.3'
    # Test with pre-release
    assert bump_version('0.1.2', position=1, pre_release='a') == '0.2a0'
    # Test with major
    assert bump_version('0.1.2', position=0) == '1.0.0'
    # Test with major pre-release
    assert bump_version('0.1.2', position=0, pre_release='a') == '1.0.0'
    # Test with major pre-release, but position 1
    assert bump_version('0.1.2', position=1, pre_release='a') == '0.2a0'
    # Test with pre-release alpha

# Generated at 2022-06-29 18:13:36.673707
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2', -1, 'a') == '0.1.3a0'
    assert bump_version('0.1.2', -1, 'alpha') == '0.1.3a0'
    assert bump_version('0.1.2', -1, 'b') == '0.1.3b0'
    assert bump_version('0.1.2', -1, 'beta') == '0.1.3b0'
    assert bump_version('0.1.3a3', -1, 'a') == '0.1.3a4'
    assert bump_version('0.1.3a3', -1, 'alpha') == '0.1.3a4'

# Generated at 2022-06-29 18:13:42.191411
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0',  0) == '1.0.0'
    assert bump_version('0.2.0',  1) == '0.3.0'
    assert bump_version('0.0.0',  2) == '0.0.1'
    assert bump_version('0.2.0', -1) == '0.2.1'
    assert bump_version('0.2.0', -2) == '0.3.0'
    assert bump_version('0.2.0', -3) == '1.0.0'

    assert bump_version('0.0.0',  0,  '') == '1.0.0'

# Generated at 2022-06-29 18:13:53.634156
# Unit test for function bump_version
def test_bump_version():
    def test_pass(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ):
        actual = bump_version(version, position, pre_release)
        assert expected == actual

    def test_fail(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
            expected_fail: Exception
    ):
        try:
            test_pass(version, position, pre_release, expected)
            assert False, 'An exception should have been raised.'
        except Exception as err:
            if err.args[0] == expected_fail.args[0]:
                return
            raise

    test_pass('1.1', -1, None, '1.2')  # Patch