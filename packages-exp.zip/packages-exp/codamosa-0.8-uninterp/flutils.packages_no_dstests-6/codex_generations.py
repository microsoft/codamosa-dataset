

# Generated at 2022-06-29 18:06:45.483019
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0', -3) == '1.0.0'
    assert bump_version('0.1.0', 3) == '0.1.0'
    assert bump_version('0.1.0', position=-1) == '0.1.0'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.1', 1) == '0.2.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump

# Generated at 2022-06-29 18:06:53.294480
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:03.806783
# Unit test for function bump_version
def test_bump_version():
    bump_version('0.1')
    bump_version('0.1.1')
    bump_version('0.1.3')
    bump_version('0.1.3', 1)
    bump_version('0.1.3', 1, 'b')
    bump_version('0.1.3', 1, 'b')
    bump_version('0.1.3', 1, 'beta')
    bump_version('0.1.3', 1, 'a')
    bump_version('0.1.3', 1, 'alpha')
    bump_version('3.2.1a0')
    bump_version('3.2.1a0', 2)
    bump_version('3.2.1a2')
    bump_version('3.2.1a2', 2, 'a')
    bump_

# Generated at 2022-06-29 18:07:15.614865
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version`` function
    """
    assert _build_version_bump_type(1, 'a') == _BUMP_VERSION_MINOR_ALPHA
    assert _build_version_bump_type(1, 'alpha') == _BUMP_VERSION_MINOR_ALPHA
    assert _build_version_bump_type(1, 'b') == _BUMP_VERSION_MINOR_BETA
    assert _build_version_bump_type(1, 'beta') == _BUMP_VERSION_MINOR_BETA
    assert _build_version_bump_type(1, None) == _BUMP_VERSION_MINOR
    assert _build_version_bump_type(2, 'a') == _BUMP_VERSION_PATCH_ALPHA
    assert _

# Generated at 2022-06-29 18:07:25.467633
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version()"""

    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.2.3') == '1.2.4'

    assert bump_version('1.2.3a0') == '1.2.3a1'
    assert bump_version('1.2.3alpha0') == '1.2.3alpha1'
    assert bump_version('1.2.3b0') == '1.2.3b1'

# Generated at 2022-06-29 18:07:37.218387
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version()."""
    import unittest
    import datetime
    import random
    import string

    class BumpVersionTest(unittest.TestCase):
        def _run_test(
                self,
                version: str,
                position: int,
                pre_release: Optional[str],
                expected_return: str,
        ):
            self.assertEqual(
                expected_return,
                bump_version(version=version, position=position,
                             pre_release=pre_release),
                'position=%s pre_release=%s' % (position, pre_release)
            )


# Generated at 2022-06-29 18:07:49.015408
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version() function."""

    import sys
    import os
    import functools
    import unittest

    # Make sure the version number module works, with basic versions
    def _basic_version_check(
        version: str,
        expected: str,
        position: int = 2,
        pre_release: Optional[str] = None
    ) -> None:
        # pylint: disable=W0106
        '''
        A basic check for the bump_version() function.

        '''
        bumped = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )

# Generated at 2022-06-29 18:07:55.660640
# Unit test for function bump_version
def test_bump_version():
    from .helper import check_function_output

    check_function_output(
        psh.bump_version,
        '12.3.4',
        '12.3.5',
    )
    check_function_output(
        psh.bump_version,
        '12.3.4a1',
        '12.3.4a2',
    )
    check_function_output(
        psh.bump_version,
        '12.3.4b1',
        '12.3.4b2',
    )
    check_function_output(
        psh.bump_version,
        '12.3.4',
        '12.3.5',
    )

# Generated at 2022-06-29 18:08:08.919436
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # Arrange
    version = '1.0.0'
    position = 2
    pre_release = None
    expected = '1.0.0.0'
    # Act
    actual = bump_version(version, position, pre_release)
    # Assert
    assert actual == expected, "Expected %s, actual %s" % (expected, actual)

    # Arrange
    version = '1.0.0.1'
    position = 2
    pre_release = None
    expected = '1.0.0.1'
    # Act
    actual = bump_version(version, position, pre_release)
    # Assert
    assert actual == expected, "Expected %s, actual %s" % (expected, actual)

    # Arrange

# Generated at 2022-06-29 18:08:18.933611
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1111
    from pytest import mark
    from testfixtures import compare, ShouldRaise

    compare(
        bump_version('1.0.0'),
        '1.0.1'
    )
    compare(
        bump_version('1.0.0', 2),
        '1.0.1'
    )
    compare(
        bump_version('1.0.0', 2, 'a'),
        '1.0.1a0'
    )
    compare(
        bump_version('1.0.0', 1),
        '1.1'
    )
    compare(
        bump_version('1.0.0', 1, 'a'),
        '1.1a0'
    )

# Generated at 2022-06-29 18:08:53.888179
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        "0.1.1", 0, pre_release="a"
    ) == "1.0.0"
    assert bump_version("0.1.1", 1, pre_release="a") == "0.2.0a0"
    assert bump_version("0.1.1a0", 1, pre_release="a") == "0.2.0a0"
    assert bump_version("0.1.1", 0) == "1.0.0"
    assert bump_version("0.1.0a0", 1) == "0.2.0"
    assert bump_version("0.1.1a0", 2) == "0.1.2"

# Generated at 2022-06-29 18:09:06.344309
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

# Generated at 2022-06-29 18:09:18.965851
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=missing-docstring
    def test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_result: str,
            msg: Optional[str] = None
    ) -> None:
        output = bump_version(version, position, pre_release)
        assert output == expected_result
        if msg is not None:
            assert output in msg

    # Sanity check
    assert bump_version('0.0.0', 2) == '0.0.1'

    # No pre-release
    test(
        version='1.2.3',
        position=0,
        pre_release=None,
        expected_result='2.0.0'
    )

# Generated at 2022-06-29 18:09:32.558288
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version with examples.

    """
    # Bump minor
    assert bump_version('1.2.4') == '1.3.0'
    # Bump minor, with pre-release minor
    assert bump_version('1.2a1.1') == '1.3.0'
    # Bump minor, pre-release beta
    assert bump_version('1.2b1.1') == '1.3.0'
    # Bump minor pre-release alpha
    assert bump_version('1.2.3', pre_release='a') == '1.3.0'
    # Bump minor pre-release beta
    assert bump_version('1.2.3', pre_release='b') == '1.3.0'
    # Bump major

# Generated at 2022-06-29 18:09:43.511289
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version()')

# Generated at 2022-06-29 18:09:53.961519
# Unit test for function bump_version
def test_bump_version():
    old_version = '0.0.0'
    for position in range(3):
        for pre_release in ['a', 'alpha', 'b', 'beta']:
            print("VERSION:")
            print(old_version)
            print("POSITION:")
            print(position)
            print("PRE-RELEASE:")
            print(pre_release)
            new_version = bump_version(old_version, position, pre_release)
            print("NEW VERSION:")
            print(new_version)
            print("")
            old_version = new_version

test_bump_version()

# Generated at 2022-06-29 18:10:05.088941
# Unit test for function bump_version
def test_bump_version():
    """Simple unit test for the bump_version function."""

# Generated at 2022-06-29 18:10:18.076914
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', pre_release='a') == '0.0.0a0'
    assert bump_version('0.0.0a0', pre_release='a') == '0.0.0a1'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('1.1.0', 1) == '1.2.0'
    assert bump_version('1.0.1', 2) == '1.0.2'
    assert bump_version('1.0.0a0', 2) == '1.0.1'
    assert bump_version('1.1.0a0', 2) == '1.1.1'

# Generated at 2022-06-29 18:10:30.792902
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0111
    def check(ver_obj: _VersionInfo, position: int,
              prerelease: Optional[str],
              bumped: str):
        ver_obj = cast(_VersionInfo, ver_obj)
        prerelease = cast(Optional[str], prerelease)
        bumped = cast(str, bumped)
        bump_type = _build_version_bump_type(position, prerelease)
        if bump_type in _BUMP_VERSION_MINORS:
            if bump_type == _BUMP_VERSION_MINOR and ver_obj.minor.pre_txt:
                txt = ver_obj.minor.num

# Generated at 2022-06-29 18:10:40.761852
# Unit test for function bump_version
def test_bump_version():
    # Accepts a string and returns a string.
    assert isinstance(bump_version('1.0.0'), str)

    # The default is to bump the patch version.
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=2, pre_release='') == '1.0.1'

    # Bumping the minor version will bump the last digit of the minor version.
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=1, pre_release='') == '1.1.0'

    # Bumping the

# Generated at 2022-06-29 18:10:56.977583
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.4.0') == '2.4.1'
    assert bump_version('2.4.1') == '2.4.2'
    assert bump_version('2.4.a1') == '2.4.a2'
    assert bump_version('2.4.a0') == '2.4.a1'
    assert bump_version('2.4.b1') == '2.4.b2'
    assert bump_version('2.4.b0') == '2.4.b1'

    assert bump_version('2.5.0') == '2.5.1'
    assert bump_version('2.5.1') == '2.5.2'
    assert bump_version('2.5.a1') == '2.5.a2'


# Generated at 2022-06-29 18:11:08.242676
# Unit test for function bump_version
def test_bump_version():
    def _bv(version, position=2, pre_release=None):
        return bump_version(version, position, pre_release)

    assert _bv('1.0.0') == '1.0.1'
    assert _bv('1.0.2') == '1.0.3'
    assert _bv('1.4.8') == '1.4.9'
    assert _bv('3.3.7') == '3.3.8'
    assert _bv('3.0.0') == '3.0.1'
    assert _bv('4.2.2') == '4.2.3'
    assert _bv('3.8.2') == '3.8.3'


# Generated at 2022-06-29 18:11:21.104245
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.0.0-a0.dev') == '1.0.0a1.dev'
    assert bump_version('1.0.0a2.dev') == '1.0.0a3.dev'
    assert bump_version('1.0.0b2.dev') == '1.0.0b3.dev'
    assert bump_version('1.0.0b2.dev') == '1.0.0b3.dev'
    assert bump_version('1.0.0a1.dev1') == '1.0.0a2.dev1'

# Generated at 2022-06-29 18:11:34.518597
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version(
            given_input, expected
    ):
        bumped = bump_version(*given_input)
        if bumped != expected:
            print('Given: %r' % given_input)
            print('Expected: %r' % expected)
            print('Received: %r' % bumped)
            print('Position: %r' % given_input[1])
            print('Pre-release: %r' % given_input[2])
            raise AssertionError("Output mismatch.")

    _test_bump_version(
        ('0.0.0', 0, None),
        '1.0.0'
    )
    _test_bump_version(
        ('0.0.0', 1, None),
        '0.1.0'
    )
    _test_

# Generated at 2022-06-29 18:11:41.897052
# Unit test for function bump_version
def test_bump_version():
    from . import test_generic_function
    from . import test_generic_bump_versions
    from . import test_generic_bump_versions_prerelease
    for ver in test_generic_function.TEST_VERSIONS:
        expected = test_generic_function.EXPECTED_OUT[ver]
        out = bump_version(ver)
        assert out == expected, (
            "%r != %r (%r)" % (out, expected, ver)
        )
    for ver in test_generic_bump_versions.TEST_VERSIONS:
        expected = test_generic_bump_versions.EXPECTED_OUT[ver]
        out = bump_version(ver)
        assert out == expected, (
            "%r != %r (%r)" % (out, expected, ver)
        )

# Generated at 2022-06-29 18:11:51.130560
# Unit test for function bump_version
def test_bump_version():
    import time
    import re
    import random
    import string
    import sys
    print('-' * 40)
    print('Starting test of bump_version')
    line_fmt = '    %s: %r'
    lines = [
        line_fmt % ('platform', sys.platform),
        line_fmt % ('python', sys.version.replace('\n', ' ')),
        line_fmt % ('bump_version', '%d.%d.%d' % (sys.version_info[0], sys.version_info[1], sys.version_info[2])),
        line_fmt % ('random-seed', random.random()),
    ]
    print('\n'.join(lines))
    print('-' * 40)


# Generated at 2022-06-29 18:12:03.902248
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.3") == "1.2.4"
    assert bump_version("1.2.3", 0) == "2.0.0"
    assert bump_version("1.2.3", 2) == "1.2.4"
    assert bump_version("1.2.3", 1) == "1.3.0"
    assert bump_version("1.2.3", pre_release="a") == "1.2.4a0"
    assert bump_version("1.2a1.3", 2) == "1.2a1.4"
    assert bump_version("1.2a1.3b2", 2) == "1.2a1.4"

# Generated at 2022-06-29 18:12:16.049193
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function :func:`bump_version`."""
    from re import compile as re_compile
    from .utils import assert_regex

    ver_re: re_compile
    ver_re = re_compile(r'^\d+\.\d+\.\d+$')
    assert_regex(ver_re, bump_version('0.1.1'))
    assert_regex(ver_re, bump_version('0.1.1', 2))

    assert_regex(ver_re, bump_version('0.1.1', 0))
    assert_regex(ver_re, bump_version('0.1.1', 0, None))
    assert_regex(ver_re, bump_version('0.1.1', 0, 'a'))
    assert_

# Generated at 2022-06-29 18:12:26.091239
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0') == '1.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
   

# Generated at 2022-06-29 18:12:38.055553
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for the bump_version function
    """
    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.0.0", 1) == "1.1.0"
    assert bump_version("1.0.0", 1, "a") == "1.1a0"
    assert bump_version("1.0.0", 0) == "2.0.0"
    assert bump_version("1.0.0", 0, "a") == "2.0a0"
    assert bump_version("1.0.0", -1, "a") == "1.0.1a0"
    assert bump_version("1.0.0", -1, "alpha") == "1.0.1a0"

# Generated at 2022-06-29 18:12:59.549196
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0a1') == '1.0.0a2'
    assert bump_version('1.0.0a0') == '1.0.1a0'
    assert bump_version('1.0.0a0', pre_release='a') == '1.0.0a1'
    assert bump_version('1.0.0a0', pre_release='alpha') == '1.0.0a1'
    assert bump_version('1.0.0a1', pre_release='alpha') == '1.0.0a2'
    assert bump_version('1.0.0a1', pre_release='b') == '1.1.0b0'
    assert bump_

# Generated at 2022-06-29 18:13:12.282558
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=W1401,R0204
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 1) == '1.3'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', 0) == '2'
    assert bump_version('1.2.0', -3) == '1.2.1'
    assert bump_version('1.2.0', -2) == '1.3'
    assert bump_version('1.2.0', -1) == '2'
    assert bump_version('1.2.0', 3) == '1.2.1'

# Generated at 2022-06-29 18:13:21.483299
# Unit test for function bump_version
def test_bump_version():
    """Test the module function bump_version."""
    def _test_bump_version(test_num: int, version: str, position: int,
                           pre_release: Optional[str],
                           expected_version: str):
        # noinspection PyShadowingNames
        def _fmt(s: str):
            s = s.replace('None', '<None>')
            return s

        err_msg = "TestFailure-%s" % test_num
        err_msg += "\nFunc: _test_bump_version"
        err_msg += "\n\tVersion: %s" % _fmt(str(version))
        err_msg += "\n\tPosition: %s" % _fmt(str(position))
        err_msg += "\n\tPre-Release: %s" % _

# Generated at 2022-06-29 18:13:34.127759
# Unit test for function bump_version
def test_bump_version():
    function_name = 'bump_version'

# Generated at 2022-06-29 18:13:37.514618
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint
    version = '1.2.3.alpha.0'
    out = bump_version(version, 0, 'alpha')
    pprint(out)



# Generated at 2022-06-29 18:13:47.078951
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('99.0.0'))
    print(bump_version('99.0.0', 2))
    print(bump_version('99.0.0', 2, 'b'))
    print(bump_version('99.0.0', 1, 'b'))
    print(bump_version('99.0.0', 0, 'b'))
    print(bump_version('99.0.0', 2, 'a'))
    try:
        print(bump_version('99.0.0', 0, 'a'))
    except ValueError as ex:
        print(ex)
    try:
        print(bump_version('99.0.0', -2, 'a'))
    except ValueError as ex:
        print(ex)


# Generated at 2022-06-29 18:14:00.335447
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2') == '2.0'
    assert bump_version('1.2', 0) == '2.0'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1.2', 2) == '1.2.1'
    assert bump_version('1.2', 2, 'a') == '1.2a0'
    assert bump_version('1.2a0', 2, 'a') == '1.2a1'
    assert bump_version('1.2a0', 2, 'b') == '1.2b0'
    assert bump_version('1.2b0', 2, 'b') == '1.2b1'

# Generated at 2022-06-29 18:14:10.553474
# Unit test for function bump_version
def test_bump_version():
    from semver import VersionInfo
    version = VersionInfo.parse('0.0.1')
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', pre_release='a') == '0.0.1a1'
    assert bump_version('0.0.1', pre_release='a') == str(version.next_patch(alpha=1))
    assert bump_version('0.0.1', pre_release='b') == '0.0.1b1'
    assert bump_version('0.0.1', pre_release='b') == str(version.next_patch(beta=1))
    assert bump_version('0.0.1', pre_release='alpha') == '0.0.1a1'
    assert bump_

# Generated at 2022-06-29 18:14:17.820463
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    """Unit test for function bump_version."""
    #
    # The following tests are based on some of the tests from the
    # pip packaging tests.
    #

    #
    # Case 1: No number bump, no pre-release
    #
    version = '1.2.0'
    position = 2
    pre_release = None
    expected = '1.2.0'
    result = bump_version(version, position, pre_release)
    assert result == expected

    #
    # Case 2: Major version bump
    #
    version = '0.2.1'
    position = 0
    pre_release = None
    expected = '1.0.0'
    result = bump_version(version, position, pre_release)
    assert result == expected



# Generated at 2022-06-29 18:14:28.750458
# Unit test for function bump_version
def test_bump_version():
    """Test the :obj:`bump_version` function in the :mod:`bump_version` module."""
    # pylint: disable=R0914
    # noinspection PyUnresolvedReferences
    import sys
    sys.dont_write_bytecode = True
    from rmfriend.util.testing import (
        BehaviorDrivenTestCase,
        TestData,
        TestDataList,
    )
    from rmfriend.util.testing.assertions import (
        AssertIsInstance,
        AssertReturnsNoValue,
        AssertRaises,
    )


# Generated at 2022-06-29 18:14:44.936476
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""

    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1', -1) == '0.1.2'
    assert bump_version('0.1.1', -2) == '0.2.1'
    assert bump_version('0.1.1', -3) == '1.0.0'
    assert bump_version('1.1.1', 0) == '2.0.0'
    assert bump_version('1.1.1', 1) == '1.2.1'
    assert bump_version('1.1.1', 2) == '1.1.2'
    assert bump_version('1.1.0', 1) == '1.2.0'

# Generated at 2022-06-29 18:14:53.874203
# Unit test for function bump_version
def test_bump_version():
    # pylint:disable=W0109,W0102

    # No pre-release
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', position=2) == '0.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version

# Generated at 2022-06-29 18:15:05.041462
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.1', 1) == '1.3.0'
    assert bump_version('1.2.1', 0) == '2.0.0'
    assert bump_version('1.2.1', 1, 'b') == '1.2.1b1'
    assert bump_version('1.2.1', 1, 'beta') == '1.2.1b1'
    assert bump_version('1.2.1', 1, 'a') == '1.2.1a1'
    assert bump_version('1.2.1', 1, 'alpha') == '1.2.1a1'

# Generated at 2022-06-29 18:15:11.503894
# Unit test for function bump_version
def test_bump_version():
    """Test the version number bumping code."""
    def check(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        """Check that the function bumps as it says it will."""
        bumped_version = bump_version(version, position, pre_release)
        assert bumped_version != version, (
            "Version '{}' is bumped with position {} and pre-release of {} "
            "and the bumped version is the same as the original version."
            "".format(version, position, pre_release)
        )
        ver_obj = StrictVersion(bumped_version)

# Generated at 2022-06-29 18:15:24.148102
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    ver_info = _build_version_info('0.0.1')
    assert ver_info.major.num == 0
    assert ver_info.major.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.txt == '0'
    assert ver_info.patch.num == 1
    assert ver_info.patch.txt == '1'
    assert ver_info.pre_pos == -1
    #
    ver_info = _build_version_info('0.1.1')
    assert ver_info.major.num == 0
    assert ver_info.major.txt == '0'
    assert ver_info.minor.num == 1
    assert ver_info.minor.txt == '1'


# Generated at 2022-06-29 18:15:29.346278
# Unit test for function bump_version
def test_bump_version():
    def do_test(version, position, pre_release, debug):
        if debug:
            print(
                '%s\nversion=%s position=%s pre_release=%s\n%s' % (
                    '*' * 32,
                    version,
                    position,
                    pre_release,
                    '*' * 32,
                )
            )
        out = bump_version(version, position, pre_release)
        if debug:
            print('out=%s\n' % out)

    # test 0 - Normal
    do_test('1.0.0', 1, None, False)
    # test 1 - Normal
    do_test('1.0.0', 2, None, False)
    # test 2 - Normal
    do_test('1.0.1', 2, None, False)

# Generated at 2022-06-29 18:15:32.737403
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3', pre_release='b', position=1) == '1.2b0'

# Generated at 2022-06-29 18:15:45.499070
# Unit test for function bump_version
def test_bump_version():  # type: ignore
    from pytest_check import check

    def _chk(version: str, position: int, pre_release: Union[str, None],
             expected: str) -> None:
        result = bump_version(version, position, pre_release)
        check(result == expected, '%r != %r' % (result, expected))

    _chk('1.0.0', 0, None, '2.0.0')
    _chk('1.0.0', -3, None, '2.0.0')

    _chk('1.0.0', 1, None, '1.1.0')
    _chk('1.0.0', -2, None, '1.1.0')


# Generated at 2022-06-29 18:15:55.592710
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from pytest import mark
    from pytest import raises as assert_raises


# Generated at 2022-06-29 18:15:59.006905
# Unit test for function bump_version
def test_bump_version():
    pass


if __name__ == '__main__':
    # pylint: disable=E1120
    test_bump_version()