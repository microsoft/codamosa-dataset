

# Generated at 2022-06-29 18:06:49.172639
# Unit test for function bump_version
def test_bump_version():
    version = "1.0.0"
    newVersion = "1.1.0"
    assert(bump_version(version) == newVersion)
    newVersion = "1.1.1"
    assert(bump_version(version, 2) == newVersion)
    newVersion = "1.1.1"
    assert(bump_version(version, 2, "beta") == newVersion)
    newVersion = "1.1.0a0"
    assert(bump_version(version, 1, "alpha") == newVersion)
    newVersion = "1.1.0b0"
    assert(bump_version(version, 1, "beta") == newVersion)
    newVersion = "1.1.1b0"

# Generated at 2022-06-29 18:06:59.144686
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # Test incrementing the major version number
    test_ver = '1.0.0'
    new_ver = bump_version(test_ver)
    assert new_ver == '2.0.0'
    test_ver = new_ver
    new_ver = bump_version(test_ver)
    assert new_ver == '3.0.0'

    # Test incrementing the minor version number
    test_ver = '1.0.0'
    new_ver = bump_version(test_ver, 1)
    assert new_ver == '1.1.0'
    test_ver = new_ver
    new_ver = bump_version(test_ver, 1)
    assert new_ver == '1.2.0'

    # Test incrementing the patch version

# Generated at 2022-06-29 18:07:10.612038
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:21.876455
# Unit test for function bump_version
def test_bump_version():
    import unittest

# Generated at 2022-06-29 18:07:28.498939
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:40.787810
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', position=-1) == '0.0.2'
    assert bump_version('0.0.1', position=-2) == '0.1.0'
    assert bump_version('0.0.1', position=-3) == '1.0.0'
    assert bump_version('0.1.1', pre_release='a') == '0.1.1a1'

# Generated at 2022-06-29 18:07:51.421311
# Unit test for function bump_version
def test_bump_version():
    ver_range = {
        'start': '1.2.3',
        'end': '2.0.0',
        'inc': (
            (0, 0, '2.2.3'),
            (0, 1, '2.3.3'),
            (0, 2, '3.0.0'),
            (1, 1, '2.2.3'),
            (1, 2, '2.3.3'),
            (2, 2, '2.2.4'),
        )
    }
    for ver_str in (ver_range['start'], ver_range['end']):
        for pos in range(-3, 3):
            for pre_release in ('a', 'b'):
                for pre_num in (0, 9):
                    old_ver = '%s%s%s'

# Generated at 2022-06-29 18:08:02.488877
# Unit test for function bump_version
def test_bump_version():
    from string import ascii_lowercase
    import random
    import re

    assert bump_version('1.2.3')                == '1.2.4'
    assert bump_version('1.2.3', 1)             == '1.3.0'
    assert bump_version('1.2.3', 2)             == '2.0.0'
    assert bump_version('1.2.3', 2, None)       == '2.0.0'
    assert bump_version('1.2.3', 2, 'alpha')    == '2.0.0a0'
    assert bump_version('1.2.3', 2, 'b')        == '2.0.0b0'

# Generated at 2022-06-29 18:08:12.280771
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.2') == '1.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=-3) == '2'
    assert bump_version('1.2.3', position=-2) == '1.3'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=2) == '1.2.4'

# Generated at 2022-06-29 18:08:17.412749
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    print(version)
    for i in range(-3, 3):
        for j in ('a', 'b', 'alpha', 'beta', None):
            print('\t', i, j, bump_version(version, i, j))

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:08:38.858099
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', -2, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', -3, 'a') == '2.0.0a0'
    assert bump_version('1.0.0', 0, 'a') == '2.0.0a0'


if __name__ == '__main__':
    print(bump_version('1.0.0'))

# Generated at 2022-06-29 18:08:51.788852
# Unit test for function bump_version
def test_bump_version():
    # field version = version
    # field major = major part of version
    # field minor = minor part of version
    # field patch = patch part of version
    # field pre_pos = pre-release position in version string (int)
    # field major.name = name of major part ('major')
    # field major.txt = text of major part ('1', '2'...)
    # field major.num = numeric value of major part (1, 2, ...)
    # field major.pre_txt = prerelease text of major part ('')
    # field major.pre_num = prerelease numeric value of major part (-1)
    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    assert ver_info.major.name == 'major'

# Generated at 2022-06-29 18:09:05.183442
# Unit test for function bump_version
def test_bump_version():
    print("Unit test for function bump_version")

    #Test to bump up version at patch level.
    version = bump_version('9.3.1')
    print("Version:", version)
    #Test to bump up alpha version at minor level.
    version = bump_version('9.3.1', 1, 'a')
    print("Version:", version)
    #Test to bump up minor version at major level.
    version = bump_version('9.3.1', 0)
    print("Version:", version)
    #Test to bump up alpha version at patch level.
    version = bump_version('9.3.1', 2, 'a')
    print("Version:", version)
    #Test to bump up beta version at patch level.
    version = bump_version('9.3.1', 2, 'b')


# Generated at 2022-06-29 18:09:17.595159
# Unit test for function bump_version
def test_bump_version():
    # Tests for major release bumps
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0a1', position=0) == '1.0.0'
    assert bump_version('0.0.0b1', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'
    assert bump_version('0.0.0a1', position=-3) == '1.0.0'
    assert bump_version('0.0.0b1', position=-3) == '1.0.0'
    # Tests for minor release bumps
    assert bump_version('0.0.0', position=1) == '0.1.0'


# Generated at 2022-06-29 18:09:24.031148
# Unit test for function bump_version
def test_bump_version():
    input_version = "0.0.0"
    output_version = bump_version(input_version)
    print("Input version is: ", input_version)
    print("Output version is: ", output_version)
    input_version = "0.0.1"
    output_version = bump_version(input_version)
    print("Input version is: ", input_version)
    print("Output version is: ", output_version)
    input_version = "1.0.0"
    output_version = bump_version(input_version)
    print("Input version is: ", input_version)
    print("Output version is: ", output_version)
    input_version = "1.1.0"
    output_version = bump_version(input_version)
    print("Input version is: ", input_version)


# Generated at 2022-06-29 18:09:36.589542
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0')
    assert version == '1.0.1'

    version = bump_version('1.0.0', 'patch')
    assert version == '1.0.1'

    version = bump_version('1.0.0', 1)
    assert version == '1.1.0'

    version = bump_version('1.0.0', 'minor')
    assert version == '1.1.0'

    version = bump_version('1.0.1', 1)
    assert version == '1.1.1'

    version = bump_version('1.0.1', 'minor')
    assert version == '1.1.1'

    version = bump_version('1.1.1', 0)
    assert version == '2.0.1'



# Generated at 2022-06-29 18:09:43.885327
# Unit test for function bump_version
def test_bump_version():
    """
    unit test for function _bump_version
    """
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.1.0') == '1.2.0'
    assert bump_version('4.9.14') == '4.10.0'
    assert bump_version('1.0.0-alpha-0') == '1.1.0'
    assert bump_version('1.0.0-alpha-1') == '1.0.0-alpha-2'
    assert bump_version('1.0.0-beta-0') == '1.1.0'

# Generated at 2022-06-29 18:09:56.532895
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 1, 'b') == '1.0.0b0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'

# Generated at 2022-06-29 18:10:02.968513
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function 'bump_version'.
    """
    import sys

    if sys.version_info < (3, 6):
        return
    # noinspection PyUnresolvedReferences
    from .bump_version_unit_tests import BumpVersionUnitTests  # pylint: disable=C0415
    BumpVersionUnitTests.test_bump_version()

# Generated at 2022-06-29 18:10:10.307615
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='alpha') == '1.3.3a0'
    assert bump_version('1.2.3', pre_release='beta') == '1.3.3b0'
    assert bump_version('1.2.3', pre_release='a') == '1.3.3a0'
    assert bump_version('1.2.3', pre_release='b') == '1.3.3b0'
    assert bump_version('1.2.3.0', pre_release='b') == '1.3.3b0'

# Generated at 2022-06-29 18:10:26.416838
# Unit test for function bump_version
def test_bump_version():
    # base test
    assert bump_version('0.1.2') == '0.1.3'

    # test a version with no pre-release info at the end
    assert bump_version('0.11.5') == '0.11.6'
    assert bump_version('1.2.3') == '1.2.4'

    # test a version with pre-release info at the end
    assert bump_version('1.2.3a4') == '1.2.3a5'
    assert bump_version('1.2.3a4') == '1.2.3a5'

    # test bumping pre-release info
    assert bump_version('1.2.3a4') == '1.2.3a5'

# Generated at 2022-06-29 18:10:38.455547
# Unit test for function bump_version
def test_bump_version():
    print('Testing the "bump_version" function.')

# Generated at 2022-06-29 18:10:51.556702
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def assert_version_equal(a, b):
        assert a == b

    def assert_error(a, b):
        assert bump_version(a, b) == "The given value for 'pre_release', %r, can only be one of: \n'a', 'alpha', 'b', 'beta', None." % b

    assert_version_equal(bump_version('1.0.0'), '2.0.0')
    assert_version_equal(bump_version('0.0.0'), '1.0.0')
    assert_version_equal(bump_version('0.0.1'), '1.0.0')

    assert_version_equal(bump_version('1.0.0', 0), '2.0.0')
    assert_version

# Generated at 2022-06-29 18:10:57.808899
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, 'b') == '2.0.0'
    assert bump_version('1.0.0', 1, 'b') == '1.1b0'
    assert bump_version('1.0.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0.0a0') == '1.0.0a1'
    assert bump_version('1.0.0a0', 1) == '1.1.0'
    assert bump_

# Generated at 2022-06-29 18:11:08.711981
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.3",1,None) == "1.3.0"
    assert bump_version("1.2.3",1,None) == "1.3.0"
    assert bump_version("1.2.a0",2,None) == "1.2.1"
    assert bump_version("1.4.a4",2,"beta") == "1.4.b0"
    assert bump_version("1.2.3",-2,None) == "1.2.3"
    assert bump_version("1.2.3",-1,None) == "1.3.0"
    assert bump_version("1.2.3",-1,"alpha") == "1.2.a0"
    assert bump_version("1.2.3",-1,"beta")

# Generated at 2022-06-29 18:11:21.232003
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0')
    assert version == '1.0.1'
    version = bump_version('1.0.0', position=-2)
    assert version == '1.0.1'
    version = bump_version('1.0.0', position=1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', position=-1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', position=0)
    assert version == '2.0.0'
    version = bump_version('1.0.0', position=-3)
    assert version == '2.0.0'
    version = bump_version('1.0.0', pre_release='alpha')
    assert version

# Generated at 2022-06-29 18:11:34.658166
# Unit test for function bump_version
def test_bump_version():
    print()
    print('bump_version(version) with no arguments.')
    print(bump_version('0.9.0'))
    print()

    print('bump_version(version, position)')
    print(bump_version('0.9.0', 0))
    print(bump_version('0.9.0', 1))
    print(bump_version('0.9.0', 2))
    print()

    print('bump_version(version, position, pre_release)')
    print(bump_version('0.9.0', 0, 'a'))
    print(bump_version('0.9.0', 1, 'a'))
    print(bump_version('0.9.0', 2, 'a'))

# Generated at 2022-06-29 18:11:42.048201
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=2, pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3b1', position=2, pre_release='b') == '1.2.3b2'
    assert bump_version('1.2.3.4', position=1) == '1.3.0.0'

# Generated at 2022-06-29 18:11:51.243412
# Unit test for function bump_version
def test_bump_version():
    """
    Bump the version while playing with the position and
    pre_release parameters.
    """
    assert bump_version('1.3.0') == '1.3.1'
    assert bump_version('1.3.0', 2, 'alpha') == '1.3.1a0'
    assert bump_version('1.3.0a0') == '1.3.1a0'
    assert bump_version('1.3.0a0', 2, 'alpha') == '1.3.1a1'
    assert bump_version('1.3.0a0', 2, 'beta') == '1.3.1b0'
    assert bump_version('1.3.0b0') == '1.3.1b0'

# Generated at 2022-06-29 18:12:04.123928
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:19.402875
# Unit test for function bump_version
def test_bump_version():
    print("Testing function bump_version")
    version = ["2.3.0", "2.3.0a0", "2.3.0b0", "2.3.0-alpha.0", "2.3.0-beta.0", "1.2.3", "1.2.3a0", "1.2.3b0", "1.2.3-alpha.0", "1.2.3-beta.0", "10.20.30", "10.20.30a0", "10.20.30b0", "10.20.30-alpha.0", "10.20.30-beta.0"]
    position = [-1,0,-2,-3, 2,1,0]
    prerelease = ["", "a", "alpha", "b", "beta"]

# Generated at 2022-06-29 18:12:27.694337
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.3.4') == '2.3.5'
    assert bump_version('2.3.4a0') == '2.3.4a1'
    assert bump_version('2.3.4b0') == '2.3.4b1'
    assert bump_version('2.3.4a5') == '2.3.4a6'
    assert bump_version('2.3.4b5') == '2.3.4b6'
    assert bump_version('2.3.4', 1) == '2.4.0'
    assert bump_version('2.3.4', 1, 'a') == '2.4.0a0'
    assert bump_version('2.3.4', 1, 'alpha') == '2.4.0a0'

# Generated at 2022-06-29 18:12:40.009195
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3') == '1.2.4'

# Generated at 2022-06-29 18:12:51.373701
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=3) == '0.1.0'
    assert bump_version('0.0.0', position=4) == '0.1.0'
    assert bump_version('0.0.0', position=5) == '0.0.1'

# Generated at 2022-06-29 18:13:01.686856
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:14.283189
# Unit test for function bump_version
def test_bump_version():
    # Bump major
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.12.9') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.12.9') == '2.0.0'
    assert bump_version('1.0.0-alpha.1') == '2.0.0'

    # Bump minor
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.12.0', 1) == '0.13.0'
    assert bump_version('1.0.0', 1) == '1.1.0'

# Generated at 2022-06-29 18:13:22.800520
# Unit test for function bump_version
def test_bump_version():
    # major
    assert bump_version('1.0', 0) == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    # minor
    assert bump_version('1.0') == '2.0.0'
    assert bump_version('1.0', 1) == '1.1.0'
    assert bump_version('1.1.0') == '1.2.0'
    assert bump_version('2.5.5') == '2.6.0'  # Alpha or beta not set
    # patch
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', 2)

# Generated at 2022-06-29 18:13:35.684798
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0') == '2.0'
    assert bump_version('1.0.0') == '2.0'
    assert bump_version('1.0.0.0') == '2.0'
    assert bump_version('1.0.0', 0) == '2.0'
    assert bump_version('1.0.0', 1) == '1.1'
    assert bump_version('1.0.1', 1) == '1.1'
    assert bump_version('1.0.4', 1) == '1.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0.a0') == '1.0.1'

# Generated at 2022-06-29 18:13:45.872905
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:59.179595
# Unit test for function bump_version
def test_bump_version():
    def _test(
            version: str,
            position: int = 0,
            pre_release: Optional[str] = None,
            expected: str = '',
    ) -> None:
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        if actual != expected:
            raise Exception(
                "The given version value, %r, does not equal the "
                "expected value, %r." % (actual, expected)
            )

    _test(
        '1.0.0',
        0,
        None,
        '2.0.0'
    )
    _test(
        '1.0.0',
        0,
        'a',
        '1.1.0a0'
    )
    _test

# Generated at 2022-06-29 18:14:13.053260
# Unit test for function bump_version
def test_bump_version():
    # Test Version bumping
    # Test 0.0.0
    zero_ver = bump_version('0.0.0')
    if zero_ver != '1.0.0':
        raise AssertionError(
            "Expecting that bump_version('0.0.0') == '1.0.0', but "
            "got '{}'".format(zero_ver)
        )
    # Test 0.0.0-rc0
    zero_ver = bump_version('0.0.0-rc0')
    if zero_ver != '1.0.0':
        raise AssertionError(
            "Expecting that bump_version('0.0.0-rc0') == '1.0.0', but "
            "got '{}'".format(zero_ver)
        )
   

# Generated at 2022-06-29 18:14:23.597929
# Unit test for function bump_version
def test_bump_version():
    out = bump_version('1.0.0')
    assert out == '1.0.1'

    out = bump_version('1.0.0', pre_release='a')
    assert out == '1.0.1a0'

    out = bump_version('1.0.0', pre_release='b')
    assert out == '1.0.1b0'

    out = bump_version('1.0.0', pre_release='none')
    assert out == '1.0.1'

    out = bump_version('1.0.0', 1)
    assert out == '1.1.0'

    out = bump_version('1.0.0', 1, pre_release='a')
    assert out == '1.1.0a0'


# Generated at 2022-06-29 18:14:34.168225
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1', 2, 'a') == '1.0.2a0'
    assert bump_version('1.0.1', 2, 'b') == '1.0.2b0'
    assert bump_version('1.0.1', 2, 'A') == '1.0.2a0'
    assert bump_version('1.0.1', 2, 'B') == '1.0.2b0'
    assert bump_version('1.0.1', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.1', 1, 'b') == '1.1.0b0'

# Generated at 2022-06-29 18:14:37.989455
# Unit test for function bump_version
def test_bump_version():
    version = "1.2.0"
    new_version = bump_version(version)
    expected_value = "1.2.1"
    assert new_version == expected_value

# Generated at 2022-06-29 18:14:47.418299
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'

    assert bump_version('1.0.1', 1) == '1.1.0'
    assert bump_version('2.0.0', 1) == '2.1.0'
    assert bump_version('2.1.0', 1) == '2.2.0'


# Generated at 2022-06-29 18:14:55.313445
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.0.0') == '3.0.1'
    assert bump_version('3.0.0', 2) == '3.0.1'
    assert bump_version('3.0.0', 3) == '3.0.1'

    assert bump_version('3.0.0', 0) == '4.0.0'
    assert bump_version('3.0.0', 0, 'a') == '4.0.0'
    assert bump_version('3.0.0', 0, 'alpha') == '4.0.0'

    assert bump_version('3.0.0', -1) == '3.1.0'
    assert bump_version('3.0.0', -1, 'a') == '3.1.0'

# Generated at 2022-06-29 18:15:06.466502
# Unit test for function bump_version
def test_bump_version():
    def _test_one(version, position, pre_release, expected_result):
        """Make one test"""
        actual_result = bump_version(version, position, pre_release)
        print('version: {0}, position: {1}, pre_release: {2}, expected_result: {3}, actual_result: {4}'.format(
            version, position, pre_release, expected_result, actual_result)
        )
        assert actual_result == expected_result

# Generated at 2022-06-29 18:15:17.401292
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.1.0') == '2.1.1'
    assert bump_version('2.1.0', 1) == '2.2.1'
    assert bump_version('2.1.0', 0) == '3.0.0'
    assert bump_version('2.1.1', -1) == '2.1.2'
    assert bump_version('2.1.1', -2) == '2.2.2'
    assert bump_version('2.1.1', -3) == '3.1.2'
    assert bump_version('2.1.0', 1, 'a') == '2.2.1a0'
    assert bump_version('2.1.0', 2, 'a') == '2.1.1a0'
    assert bump_

# Generated at 2022-06-29 18:15:29.149739
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:40.536063
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function
    """
    # Normal use
    assert bump_version('1.2.3.4') == '1.2.4'
    assert bump_version('1.2.3.4', 1) == '1.3'
    assert bump_version('1.2.3.4', 0) == '2'
    assert bump_version('1.2.3.4', 2) == '1.2.4'
    assert bump_version('1.2.3.4', -1) == '1.2.4'
    assert bump_version('1.2.3.4', -2) == '1.3'
    assert bump_version('1.2.3.4', -3) == '2'

    # Pre_release

# Generated at 2022-06-29 18:16:00.615965
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('')
    assert version == '0.0.1'

    version = bump_version('', pre_release='a')
    assert version == '0.1a0'

    version = bump_version('', 2, 'a')
    assert version == '0.0.1a0'

    version = bump_version('0.0.1', 2, 'a')
    assert version == '0.0.1a0'

    version = bump_version('1.2.3', 2, 'a')
    assert version == '1.2.4a0'

    version = bump_version('1.2.3', 2, 'b')
    assert version == '1.2.4b0'

    version = bump_version('1.2.3', 2, 'alpha')

# Generated at 2022-06-29 18:16:12.083284
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', position=-2) == '1.1.0'
    assert bump_version('1.0.0', position=-3) == '2.0.0'
    assert bump_version('1.0.0', pre_release='alpha') == '1.0.0a0'
    assert bump