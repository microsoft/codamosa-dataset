

# Generated at 2022-06-29 18:06:40.592034
# Unit test for function bump_version
def test_bump_version():
    version = '0.1.0'
    position = 2
    pre_release = 'beta'
    out = '0.1.1'
    assert bump_version(version, position, pre_release) == out

# Generated at 2022-06-29 18:06:50.619715
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion
    tst_prd_ver = '1.0.0'
    tst_dev_ver = '2.0.0a1'
    tst_de2_ver = '2.0.0b2'

    assert bump_version(tst_prd_ver) == '1.0.1'
    assert bump_version(tst_prd_ver, position=1) == '1.1.0'
    assert bump_version(tst_prd_ver, pre_release='a') == '1.0.0a0'
    assert bump_version(tst_dev_ver, pre_release='b') == '2.0.0b0'
    assert bump_version(tst_dev_ver) == '2.0.0b0'

# Generated at 2022-06-29 18:07:00.555847
# Unit test for function bump_version
def test_bump_version():
    import json
    import os
    import unittest

    os_path_join = os.path.join
    os_path_abspath = os.path.abspath

    version_tests_path = os_path_join(
        os_path_abspath(os.path.dirname(os.path.realpath(__file__))),
        'tests',
        'json',
        'version-tests.json'
    )
    ts = json.loads(open(version_tests_path, 'r').read())
    for test_set in ts:
        # noinspection PyTypeChecker
        setUp = test_set.get('setUp', None)

# Generated at 2022-06-29 18:07:12.090796
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    version = bump_version('1.0.0', pre_release='a')
    assert version == '1.0.0a0'
    version = bump_version('1.2.3', pre_release='b')
    assert version == '1.2.3b0'
    version = bump_version('1.2.3', pre_release='a')
    assert version == '1.2.3a0'

    version = bump_version('1.0.0', 2)
    assert version == '1.0.1'
    version = bump_version('1.0.0', 1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', 0)

# Generated at 2022-06-29 18:07:23.090223
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('0.9.9'))
    print(bump_version('0.9.9', position=2))
    print(bump_version('0.9.9', position=2, pre_release=None))
    print(bump_version('0.9.9', position=2, pre_release='alpha'))
    print(bump_version('0.9.9', position=2, pre_release='beta'))
    print(bump_version('0.9.9', position=1, pre_release='alpha'))
    print(bump_version('0.9.9', position=1, pre_release='beta'))
    print(bump_version('0.9.9', position=0, pre_release='alpha'))

# Generated at 2022-06-29 18:07:33.591857
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3a4') == '1.2.3a5'
    assert bump_version('1.2.3a4', 0) == '1.2.3a5'
    assert bump_version('1.2.3b1') == '1.2.3b2'
    assert bump_version('1.2.3b1', 0) == '1.2.3b2'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version

# Generated at 2022-06-29 18:07:45.508648
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '1.0.0'
    assert bump_version('0.1.1', pre_release='a', position=0) == '0.1.1a0'
    assert bump_version('0.1.1', pre_release='a', position=-1) == '0.2.0a0'
    assert bump_version('0.1.1', pre_release='a') == '0.2.0a0'
    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0', pre_release='b') == '1.1.0b0'

# Generated at 2022-06-29 18:07:54.712203
# Unit test for function bump_version
def test_bump_version():
    version = 'v0.0.0'
    result = bump_version(version)
    assert result == 'v0.0.1'

    version = '0.0.0'
    result = bump_version(version)
    assert result == '0.0.1'

    version = 'v0.0.0a0'
    result = bump_version(version)
    assert result == 'v0.0.1'

    version = '0.0.0a0'
    result = bump_version(version)
    assert result == '0.0.1'

    version = 'v0.0.0a0'
    result = bump_version(version, 2, pre_release='alpha')
    assert result == 'v0.0.0a1'


# Generated at 2022-06-29 18:08:07.823364
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    version_inst = StrictVersion('0.1.3.alpha')
    version = '%s' % version_inst
    versions = {
        'major': '1.0.0',
        'minor': '0.2.0',
        'patch': '0.1.4',
        'minor.alpha': '0.1.alpha0',
        'minor.beta': '0.2.0',
        'patch.alpha': '0.1.3.alpha1',
        'patch.beta': '0.1.beta0',
    }
    for bump_type, expected in versions.items():
        position = bump_type.split('.')[0]
        pre_release = bump_type.split('.')[-1]

# Generated at 2022-06-29 18:08:17.126709
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:35.993274
# Unit test for function bump_version
def test_bump_version():
    # Test basic bumping
    # Test minor
    ver = bump_version('1.2.0')
    assert ver == '1.3.0'
    # Test patch
    ver = bump_version('1.2.0', 2)
    assert ver == '1.2.1'
    # Test major
    ver = bump_version('1.2.0', 0)
    assert ver == '2.0.0'
    # Test minor alpha
    ver = bump_version('1.2.0', 1, 'a')
    assert ver == '1.3a0'
    # Test minor beta
    ver = bump_version('1.2.0', 1, 'b')
    assert ver == '1.3b0'
    # Test patch alpha

# Generated at 2022-06-29 18:08:47.938193
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase
    from unittest.mock import patch

    class MockHomebrew(object):
        class MockFormula(object):
            class MockVersion(object):
                def rebuild(self, version_str: str) -> None:
                    raise RuntimeError(version_str)

                def version_str(self) -> str:
                    raise RuntimeError("version_str")

                def version_obj(self) -> StrictVersion:
                    raise RuntimeError("version_obj")

                def version_obj_or_dev(self) -> StrictVersion:
                    raise RuntimeError("version_obj_or_dev")

                def __init__(self, formula: 'MockFormula'):
                    self.formula = formula

            def __init__(self, name: str, version: StrictVersion = None):
                self

# Generated at 2022-06-29 18:08:56.751866
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version

    :return: None
    """
    from dataver import bump_version

# Generated at 2022-06-29 18:09:08.194247
# Unit test for function bump_version
def test_bump_version():
    assert '1.1.1' == bump_version('1.1.0')
    assert '1.2.0' == bump_version('1.1.1')
    assert '2.0.0' == bump_version('1.2.1')
    assert '1.1.0' == bump_version('1.1.0', -1)
    assert '1.1.1' == bump_version('1.1.0', -2)
    assert '1.2.0' == bump_version('1.1.0', -3)
    assert '1.1.1' == bump_version('1.1.0', 2)
    assert '1.2.0' == bump_version('1.1.0', 1)

# Generated at 2022-06-29 18:09:20.253665
# Unit test for function bump_version
def test_bump_version():
    # major
    assert '2.0.0' == bump_version('1.2.1')
    assert '2.0.0' == bump_version('1.2.1', 0)
    assert '2.0.0' == bump_version('1.2.1', 0, 'a')
    assert '2.0.0' == bump_version('1.2.1', '0', 'a')
    assert '2.0.0' == bump_version('1.2.1', pre_release='a')
    assert '2.0.0' == bump_version('1.2.1', 0, 'b')
    assert '2.0.0' == bump_version('1.2.1', '0', 'b')

# Generated at 2022-06-29 18:09:33.142556
# Unit test for function bump_version
def test_bump_version():
    import os

    this_dir, this_filename = os.path.split(__file__)
    with open(os.path.join(this_dir, 'test_bump_version.txt'), 'rb') as fp:
        try:
            lines = fp.read().decode('utf-8').split('\n')
        except UnicodeDecodeError:
            lines = fp.read().decode('latin-1').split('\n')

    for line in lines:
        if not line.strip():
            continue

        print(line)
        if line.startswith('#'):
            continue

        line = line.strip()
        parts = line.split('; ')
        version = parts[0]
        for txt in parts[1:]:
            position, pre_release = txt.split

# Generated at 2022-06-29 18:09:43.991955
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('3.4.0') == '3.4.1'
    assert bump_version('3.4.0', 0) == '4.0.0'
    assert bump_version('3.4.0', 1) == '3.5.0'

# Generated at 2022-06-29 18:09:56.669193
# Unit test for function bump_version
def test_bump_version():
    import pytest

    def test_bump_version_instance(
            version_in,
            position,
            pre_release,
            version_out
    ) -> None:
        assert bump_version(version_in, position, pre_release) == version_out

    # Create test cases

# Generated at 2022-06-29 18:10:07.180799
# Unit test for function bump_version
def test_bump_version():  # noqa
    def _test_one(ver: str, pos: int, pre: Optional[str], exp: str):
        act = bump_version(ver, pos, pre)
        assert act == exp, f"For {ver}, {pos}, {pre}:\n" \
                           f"  Expected: '{exp}'" \
                           f"  Actual:   '{act}'"

    _test_one('0.0.0', 2, None, '0.0.1')
    _test_one('0.0.0', -1, None, '0.0.1')
    _test_one('0.0.1', 2, None, '0.0.2')
    _test_one('0.0.2', 2, 'b', '0.0.3b0')
    _test

# Generated at 2022-06-29 18:10:19.533746
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.1', position=0) == '2.0.1'
    assert bump_version('1.0.1', position=1) == '1.1.1'
    assert bump_version('1.0.0', position=1) == '1.1'
    assert bump_version('1.0.1.0', position=1) == '1.1.1.0'
    assert bump_version('1.0.1.0a0', position=1) == '1.1.1.0a0'
    assert bump_version('1.0', position=1) == '1.1'

# Generated at 2022-06-29 18:10:33.876269
# Unit test for function bump_version
def test_bump_version():
    print("Testing bump_version()")
    test_vectors = (
        ('1.0.0', '2.0.0'), ('1.2.2', '1.3.0'), ('1.2.2', '1.2.3'),
        ('1.2.2a0', '1.3.0'), ('1.2.2a0', '1.2.3'), ('1.2.2a1', '1.2.2a2'),
        ('1.2.2a1', '1.2.3'), ('1.2.2b1', '1.2.2b2'), ('1.2.2b1', '1.2.3'),
    )
    for (version, desired) in test_vectors:
        bump = bump_version(version)

# Generated at 2022-06-29 18:10:40.208622
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('0.2.0', 1, 'a') == '0.3.0'
    assert bump_version('0.2.0', 1, 'alpha') == '0.3.0'
    assert bump_version('0.2.0') == '0.2.0'
    assert bump_version('0.2.0', -1) == '0.2.0'
    assert bump_version('0.2.0', -2) == '0.3.0'
    assert bump_version('0.2.0', -3) == '1.0.0'
    assert bump_version('0.2.0a1', -3) == '1.0.0'
    assert bump_version

# Generated at 2022-06-29 18:10:53.490691
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.6.1', position=2) == '0.6.2'
    assert bump_version('1.1.0', position=2) == '1.1.1'
    assert bump_version('1.1.0', position=1) == '1.2.0'
    assert bump_version('0.6.1', position=1) == '0.7.0'
    assert bump_version('0.6.1', position=0) == '1.0.0'

    assert bump_version('0.6.1', position=2, pre_release='alpha') == '0.6.2a0'
    assert bump_version('0.6.1', position=1, pre_release='beta') == '0.7.0b0'

# Generated at 2022-06-29 18:11:05.541457
# Unit test for function bump_version
def test_bump_version():
    test_data = [
        '4.2.3.4',
        '4.2.3',
        '4.2.3a2',
        '4.2.3a0',
        '4.2.1',
        '5.5.5',
    ]
    test_data = list(map(
        lambda x: bump_version(x, 2, 'a'), test_data
    ))

    assert test_data[0] == '4.2.3a0'
    assert test_data[1] == '4.2.4a0'
    assert test_data[2] == '4.2.3a3'
    assert test_data[3] == '4.2.3a1'
    assert test_data[4] == '4.2.2a0'

# Generated at 2022-06-29 18:11:18.401663
# Unit test for function bump_version
def test_bump_version(): #pylint: disable=C0116,C0115
    try:
        bump_version('1')
    except ValueError:
        pass
    else:
        assert False, "Should have received ValueError."

    assert '2.0' == bump_version('1.6.1')
    assert '1.0' == bump_version('0.11.1')
    assert '0.12.0' == bump_version('0.11.1', 1)
    assert '0.11.1a1' == bump_version('0.11.1', 2, 'a')
    assert '0.11.1a1' == bump_version('0.11.1', 2, 'alpha')
    assert '0.11.1b1' == bump_version('0.11.1', 2, 'b')

# Generated at 2022-06-29 18:11:31.029074
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:42.917759
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0', position=-1) == '1.3.0'
    assert bump_version('1.2.0', position=-2) == '2.0.0'
    assert bump_version('1.2.0', position=-3) == '2.0.0'
    assert bump_version('1.2.0', pre_release='a') == '1.2.0a0'
    assert bump_version('1.2.0', pre_release='A') == '1.2.0a0'
    assert bump_version('1.2.0a0', pre_release='a')

# Generated at 2022-06-29 18:11:51.839425
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: bump_version')

# Generated at 2022-06-29 18:12:03.103488
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from py_make_file import code_coverage_enforcer

    dirpath, filename = path.split(path.abspath(__file__))
    cov_file_path = path.join(dirpath, '..', '..', '.coverage')

    if code_coverage_enforcer.should_run_branch_coverage(
            filename,
            cov_file_path
    ) is True:
        # Branch coverage enforcement
        test_branch_coverage()
    else:
        print("Detected branch coverage run, skipping branch test.")
        # No branch coverage enforcement
        test_no_branch_coverage()



# Generated at 2022-06-29 18:12:15.365254
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.0.0-alpha.1') == '1.0.1'
    assert bump_version('1.0.1-alpha.1') == '1.0.2'
    assert bump_version('1.1.0-alpha.1') == '1.1.1'
    assert bump_version('1.2.0-alpha.1') == '1.2.1'

# Generated at 2022-06-29 18:12:27.192850
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.12.13') == '2.12.14'
    assert bump_version('2.12.13', 0) == '3.12.13'
    assert bump_version('2.12.13', 1) == '2.13.13'
    assert bump_version('2.12.13', 1, 'b') == '2.12.14b0'
    assert bump_version('2.12.13b2', -2, 'b') == '2.12.14b0'
    assert bump_version('2.12.13b2', -1, 'b') == '2.12.14b3'
    assert bump_version('2.12.13b2', -1, 'a') == '2.12.14a0'

# Generated at 2022-06-29 18:12:29.854194
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '0.1.1'


if __name__ == '__main__':
    import sys
    print(bump_version(sys.argv[1]))

# Generated at 2022-06-29 18:12:42.412865
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0', position=-1)
    assert version == '1.0.1'
    version = bump_version('1.0.0', position=-2)
    assert version == '1.1.0'
    version = bump_version('1.0.0', position=-3)
    assert version == '2.0.0'
    version = bump_version('1.0.0', position=0)
    assert version == '1.0.0'
    version = bump_version('1.0.0', position=1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', position=2)
    assert version == '1.0.1'
    version = bump_version('1.0.0', position=3)
   

# Generated at 2022-06-29 18:12:47.329761
# Unit test for function bump_version
def test_bump_version():
    # Check for a major increment
    assert bump_version('1.2.3') == '2.0.0'
    assert bump_version('0.2.3') == '1.0.0'
    # Check for a minor increment
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('0.2.3') == '0.3.0'
    # Check for a patch increment
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('0.2.3') == '0.2.4'
    # Check default values
    assert bump_version('1.2.3') == '1.2.3'
    assert bump_version('1.2.3') == '1.2.3'
   

# Generated at 2022-06-29 18:12:58.542636
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:12.142180
# Unit test for function bump_version
def test_bump_version():
    def test(version, position, pre_release):
        old = StrictVersion(version)
        new = bump_version(version, position, pre_release)
        new = StrictVersion(new)

        old_ver = old.version
        old_pre = old.prerelease

        new_ver = new.version
        new_pre = new.prerelease

        assert new_ver == old_ver, (
            "Version number should be the same but was %s != "
            "%s" % (new_ver, old_ver)
        )
        if position == 2 and pre_release is None:
            assert new_pre == old_pre, (
                "Pre-release should be the same but was %s != %s" %
                (new_pre, old_pre)
            )
            return


# Generated at 2022-06-29 18:13:21.364159
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    assert bump_version('1.0.0') == '1.0.1'
    # noinspection PyUnresolvedReferences
    assert bump_version('1.0.0', 0) == '2.0.0'
    # noinspection PyUnresolvedReferences
    assert bump_version('1.0.0', 1) == '1.1.0'
    # noinspection PyUnresolvedReferences
    assert bump_version('1.0.0', 2) == '1.0.1'
    # noinspection PyUnresolvedReferences
    assert bump_version('1.0.1', 0) == '2.0.0'
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-29 18:13:34.128076
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        '1.0.0'
    ) == '1.0.1'
    assert bump_version(
        '1.0.0.dev1'
    ) == '1.0.1.dev1'
    assert bump_version(
        '1.0.0.dev1', position=0
    ) == '2.0.0.dev1'
    assert bump_version(
        '1.0.0.dev1', position=1
    ) == '1.1.0.dev1'
    assert bump_version(
        '1.0.0.dev1', position=-1
    ) == '1.0.1.dev1'

# Generated at 2022-06-29 18:13:44.801172
# Unit test for function bump_version
def test_bump_version():
    #
    # The current version is 1.2.0
    #

    #
    #
    # Bumping the major version number
    #
    #

    # Bumping major version number by default.
    r = bump_version('1.2.0')
    assert r == '2.0.0'
    # Bumping major version number explicitly.
    r = bump_version('1.2.0', 0)
    assert r == '2.0.0'
    # Bumping major version number by negative number.
    r = bump_version('1.2.0', -3)
    assert r == '2.0.0'

    #
    #
    # Bumping the minor version number
    #
    #
    # Bumping minor version number by default.

# Generated at 2022-06-29 18:13:57.703472
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:10.795212
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.5.0') == '1.5.1'
    assert bump_version('1.5.0', 2) == '1.5.1'
    assert bump_version('1.5.0', 2, 'alpha') == '1.5.0a0'
    assert bump_version('1.5.0a0') == '1.5.0a1'
    assert bump_version('1.5.0a0', 2, 'alpha') == '1.5.0a1'
    assert bump_version('1.5.0alpha0', 2, 'alpha') == '1.5.0alpha1'
    assert bump_version('1.5.0alpha123', 2, 'alpha') == '1.5.0alpha124'

# Generated at 2022-06-29 18:14:18.460686
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.3") == "1.2.4"
    assert bump_version("1.2.3", 2) == "1.2.4"
    assert bump_version("1.2.3", position=2) == "1.2.4"
    assert bump_version("1.2.3", pre_release="a") == "1.2.3a0"
    assert bump_version("1.2.3", pre_release="alpha") == "1.2.3a0"
    assert bump_version("1.2.3", pre_release="b") == "1.2.3b0"
    assert bump_version("1.2.3", pre_release="beta") == "1.2.3b0"
    assert bump_version("1.2.3a0")

# Generated at 2022-06-29 18:14:21.104727
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:14:32.455880
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:39.566539
# Unit test for function bump_version
def test_bump_version():
    # Given
    version = '1.2.3'
    position = 2
    pre_release = None
    expected_output = '1.2.4'
    # When
    actual_output = bump_version(
        version,
        position,
        pre_release
    )
    # Then
    assert expected_output == actual_output

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:14:48.260263
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('10.0.0') == '11.0.0'
    assert bump_version('1.0.0a0', 0) == '2.0.0a0'
    assert bump_version('1.0.0a0', 1) == '1.1.0a0'
    assert bump_version('1.0.0a0', 2) == '1.0.1a0'
    assert bump_version('1.0.0a0', -1) == '1.0.0a0'
    assert bump_version('1.0.0a0', -2) == '1.0.0a0'

# Generated at 2022-06-29 18:14:55.759434
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:06.896185
# Unit test for function bump_version
def test_bump_version():
    import unittest

    def run(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = None
    ) -> None:
        nonlocal tests
        got = bump_version(version, position, pre_release)
        tests += 1
        if expected is None:
            expected = version
        if got != expected:
            err_msg = '(%r) != (%r) -- version:%r, position:%r, pre-release:%r'
            raise AssertionError(err_msg % (got, expected, version, position,
                                            pre_release))

    tests = 0
    run('0.0.0')
    run('0.0.1', expected='0.0.2')

# Generated at 2022-06-29 18:15:17.502670
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.4.4') == '2.4.5'
    assert bump_version('1.4.4') == '1.4.5'
    assert bump_version('1.4.4', 1) == '1.5.0'
    assert bump_version('1.4.4', 0) == '2.0.0'
    assert bump_version('2.4.4', 1, 'alpha') == '2.5.0a0'
    assert bump_version('2.6.3a3') == '2.6.3a4'
    assert bump_version('2.6.2a7') == '2.6.2a8'
    assert bump_version('2.6.2a7', 1, 'beta') == '2.7.0b0'
    assert bump

# Generated at 2022-06-29 18:15:29.192881
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(version='1.0.0') == '1.0.1'
    assert bump_version(version='1.0.0', position=2) == '1.0.1'
    assert bump_version(version='1.0.0', position=_BUMP_VERSION_PATCH) == '1.0.1'
    assert bump_version(version='1.0.2') == '1.0.3'
    assert bump_version(version='1.0.2', position=2) == '1.0.3'
    assert bump_version(version='1.0.2', position=_BUMP_VERSION_PATCH) == '1.0.3'
    assert bump_version(version='1.0.0', position=1) == '1.1.0'
    assert bump_

# Generated at 2022-06-29 18:15:46.306567
# Unit test for function bump_version
def test_bump_version():
    import unittest
    
    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_patch(self):
            self.assertEqual('0.1.0', bump_version('0.1.0'))
            self.assertEqual('0.1.1', bump_version('0.1.0', 2))
            self.assertEqual('0.1.1', bump_version('0.1.0', -1))
            self.assertEqual('0.1.1', bump_version('0.1.0', -3))
            self.assertEqual('0.1.1a0', bump_version('0.1.0', 1, 'alpha'))

# Generated at 2022-06-29 18:15:56.190261
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.2') == '0.0.3'
    assert bump_version('0.0.3') == '0.0.4'
    assert bump_version('0.0.4') == '0.0.5'
    assert bump_version('0.0.5') == '0.0.6'
    assert bump_version('0.0.6') == '0.0.7'
    assert bump_version('0.0.7') == '0.0.8'
    assert bump_version('0.0.8') == '0.0.9'

# Generated at 2022-06-29 18:16:08.072030
# Unit test for function bump_version