

# Generated at 2022-06-29 18:06:45.432634
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', 3) == '0.1.1'
    assert bump_version('0.0.0', 4) == '1.1.1'
    assert bump_version('0.0.0', 5) == '1.1.1'
    assert bump_version('1.1.1') == '2.0.0'

# Generated at 2022-06-29 18:06:53.264582
# Unit test for function bump_version
def test_bump_version():
    import pytest

    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.0.0", "p") == "1.0.1"
    assert bump_version("1.0.0", "patch") == "1.0.1"

    assert bump_version("1.0.0", "m") == "1.1.0"
    assert bump_version("1.0.0", "minor") == "1.1.0"

    assert bump_version("1.0.0", "M") == "2.0.0"
    assert bump_version("1.0.0", "major") == "2.0.0"

    assert bump_version("1.0.0", "p", "alpha") == "1.0.1a0"

# Generated at 2022-06-29 18:07:03.761822
# Unit test for function bump_version
def test_bump_version():
    # Test basic
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('1.1.1') == '1.1.2'

    # Test non-zero minor
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.2.0') == '0.2.1'

    # Test position
    assert bump_version('0.0.0', 0) == '1.0.0'

# Generated at 2022-06-29 18:07:15.564079
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=E1101,W0612
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2)

# Generated at 2022-06-29 18:07:25.474242
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    func_name = 'bump_version'
    unit_test: Dict[str, Any] = {}
    unit_test['name'] = 'Test "%s"' % func_name
    unit_test['result'] = True
    unit_test['comment'] = ''
    unit_test['changes'] = {}
    #
    # Test version '0.1.0'
    #
    comment = ''
    version = '0.1.0'

# Generated at 2022-06-29 18:07:37.218020
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version

    """
    from . import test_version
    import os
    import tempfile
    import unittest
    import shutil

    class TestBumpVersion(unittest.TestCase):
        """
        Bump version test class

        """
        def test_bump_version(self):
            """
            Test bump_version

            """
            version_string = test_version
            self.assertEqual(version_string, '1.2.3.a2')
            bumped = bump_version(version_string, position=2)
            self.assertEqual(bumped, '1.2.4')
            bumped = bump_version(version_string, position=1)
            self.assertEqual(bumped, '1.3.0')
            bumped = bump_version

# Generated at 2022-06-29 18:07:49.013823
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:56.498794
# Unit test for function bump_version
def test_bump_version():

    # Patch Version Bump
    vnum = bump_version('1.2.3')
    assert vnum == '1.2.4'
    vnum = bump_version('1.2.0')
    assert vnum == '1.2.1'
    vnum = bump_version('1.2.0rc1')
    assert vnum == '1.2.1'
    vnum = bump_version('1.2.0alpha1')
    assert vnum == '1.2.1'
    vnum = bump_version('1.2.0beta1')
    assert vnum == '1.2.1'

    # Minor Version Bump
    vnum = bump_version('1.2.3', 1)
    assert vnum == '1.3.0'

# Generated at 2022-06-29 18:08:09.569125
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from unittest import TestCase
    from os import path

    class Test_bump_version(TestCase):
        def test_versions(self):
            """Test each version in the test data file"""
            with open(path.join(path.dirname(__file__), 'test-versions.txt')) as test_data:
                for line in test_data:
                    if line.startswith('#'):
                        continue
                    if line.strip() == '':
                        continue
                    parts = line.split('\t')
                    res = bump_version(parts[0], int(parts[1]))
                    self.assertEqual(res, parts[2].rstrip())

    Test_bump_version('test_versions').test_versions()

# Generated at 2022-06-29 18:08:20.182929
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Test the bump_version function.

    *New in version 0.3*

    """
    # ---
    # TODO: Add tests for version parsing
    # ---
    assert bump_version('0.5.0') == '0.5.1'
    assert bump_version('0.5.0', 0) == '1.0.0'
    assert bump_version('0.5.0', 1) == '0.6.0'
    assert bump_version('0.5.0', 2) == '0.5.0'
    assert bump_version('0.5.0', -1) == '0.5.0'
    assert bump_version('0.5.0', -2) == '0.5.0'

# Generated at 2022-06-29 18:08:55.881838
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', position=0) == '1.0.0'
    assert bump_version('0.2.0', position=0, pre_release='alpha') == '1.0.0a1'
    assert bump_version('0.2.0', position=0, pre_release='a') == '1.0.0a1'
    assert bump_version('0.2.0', position=1) == '0.3.0'
    assert bump_version('0.2.0', position=1, pre_release='a') == '0.3.0a1'
    assert bump_version('0.2.5a1') == '0.2.5a2'
    assert bump_

# Generated at 2022-06-29 18:09:07.181863
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version
    """

    print("Testing function bump_version")

    major_increase = [
        '0.1.1',
        '0.1.2',
        '0.1.3',
        '0.1.4',
    ]


# Generated at 2022-06-29 18:09:19.610067
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.1.0') == '2.1.1'
    assert bump_version('4.3.3') == '4.3.4'
    assert bump_version('3.3', 0) == '4.0'
    assert bump_version('3.3', 0, 'a') == '4.0'
    assert bump_version('3.3', 1) == '3.4'
    assert bump_version('3.3', 1, 'a') == '3.4a0'
    assert bump_version('2.1a1') == '2.1.1'
    assert bump_version('4.3a4') == '4.3.4'
    assert bump_version('3.3', 0, 'a') == '4.0'

# Generated at 2022-06-29 18:09:32.660305
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:40.097247
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""
    # Import standard library modules
    import doctest
    # Find to the test module
    import _test_bump_version
    # Run the tests
    result = doctest.testmod(_test_bump_version)
    # Check the results
    if result.failed > 0:
        raise SystemExit(result)

# Execute the test function as a standalone program
if __name__ == "__main__":
    test_bump_version()

# Generated at 2022-06-29 18:09:50.282863
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises
    from version_bump import bump_version

    increment = '0.1.1'
    position = 2
    pre_release = None

    assert bump_version(increment,position,pre_release) == '0.1.2'

    increment = '0.1.1'
    position = 0
    pre_release = None

    assert bump_version(increment,position,pre_release) == '1.0.0'

    increment = '0.1.1'
    position = 1
    pre_release = 'b'

    assert bump_version(increment,position,pre_release) == '0.2.1b0'

    increment = '0.0.1'
    position = 1
    pre_release = 'b'


# Generated at 2022-06-29 18:10:02.327293
# Unit test for function bump_version
def test_bump_version():
    from pyvcs import bump_version

# Generated at 2022-06-29 18:10:15.187803
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:28.030089
# Unit test for function bump_version
def test_bump_version():
    tests = (
        '0.2.0',
        '0.2.0a0',
        '0.2.0b0',
        '1.2.3',
        '3.0.0',
    )
    for test in tests:
        assert bump_version(test) == '1.2.4'
        assert bump_version(test, 0) == '4.0.0'
        assert bump_version(test, 1) == '1.3.0'
        assert bump_version(test, 2) == '1.2.4'

        assert bump_version(test, 0, 'a') == '4.0.0a0'
        assert bump_version(test, 0, 'b') == '4.0.0b0'
        assert bump_version(test, 1, 'a')

# Generated at 2022-06-29 18:10:37.299248
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0a1')
    assert version == '1.0.0a2'
    version = bump_version('1.0.0a1', 1)
    assert version == '1.0.1'
    version = bump_version('1.0.0', 1, 'a')
    assert version == '1.0.1a0'
    version = bump_version('1.0.0', 1, 'b')
    assert version == '1.0.1b0'
    version = bump_version('1.0.0', 0, 'x')
    assert version == '2.0.0'

test_bump_version()

# Generated at 2022-06-29 18:11:01.562655
# Unit test for function bump_version
def test_bump_version():
    def _run_test(version, position, pre_release, expected):
        assert bump_version(version, position, pre_release) == expected

    # version
    _run_test('0.9.0', 0, None, '1.0.0')
    _run_test('0.9.0', 0, 'a', '1.0.0')
    _run_test('0.9.0', 0, 'alpha', '1.0.0')
    _run_test('0.9.0', 0, 'b', '1.0.0')
    _run_test('0.9.0', 0, 'beta', '1.0.0')
    # position
    _run_test('0.9.0', 1, None, '0.10.0')

# Generated at 2022-06-29 18:11:03.452638
# Unit test for function bump_version
def test_bump_version():
    return


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:11:11.049654
# Unit test for function bump_version
def test_bump_version():
    def _assert_eq(result, expected):
        msg = " %r != %r " % (result, expected)
        assert result == expected, msg

    # The standard tests

    # Test basic bumping
    _assert_eq(bump_version('0.1.0'), '0.1.1')
    _assert_eq(bump_version('0.1.2'), '0.1.3')
    _assert_eq(bump_version('0.1.0', position=1), '0.2.0')
    _assert_eq(bump_version('0.2.0', position=1), '0.3.0')
    _assert_eq(bump_version('0.2.0', position=0), '1.0.0')

# Generated at 2022-06-29 18:11:22.780158
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=unused-variable
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 0, 'a') == '1.0.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1.0a0'
    assert bump_version('0.1.0', 1, 'a') == '0.2.0a0'
    assert bump_version('0.1.0a0') == '0.1.0a1'

# Generated at 2022-06-29 18:11:35.980238
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class BumpVersionTests(unittest.TestCase):
        """Unit tests for ``bump_version``."""

        def test_1(self):
            """Test cases for ``bump_version``.

            Tests the method ``bump_version``.

            """
            out = bump_version('0.0.0')
            self.assertEqual(out, '0.0.1')
            out = bump_version('0.0.0', position=0)
            self.assertEqual(out, '1.0.0')
            out = bump_version('0.0.0', position=1)
            self.assertEqual(out, '0.1.0')
            out = bump_version('0.0.0', position=2)

# Generated at 2022-06-29 18:11:46.953466
# Unit test for function bump_version
def test_bump_version():
    # Test normal use of bumping a version number
    assert bump_version('2019.2.0') == '2019.2.1', 'bump_version test 1 failed'
    assert bump_version('2019.2.1') == '2019.2.2', 'bump_version test 2 failed'
    assert bump_version('2019.0.0') == '2019.0.1', 'bump_version test 3 failed'
    assert bump_version('2019.2.0', position=1) == '2019.3.0', 'bump_version test 4 failed'
    assert bump_version('2019.2.0', position=0) == '2020.0.0', 'bump_version test 5 failed'

# Generated at 2022-06-29 18:11:58.868778
# Unit test for function bump_version
def test_bump_version():
    """Function bump_version() - Unit tests."""
    # Basic major bump
    assert bump_version('1.0.0') == '2.0.0'
    # Basic minor bump
    assert bump_version('1.0.0', 1) == '1.1.0'
    # Basic patch bump
    assert bump_version('1.0.0', 2) == '1.0.1'
    # Major bump - with minor pre-release
    assert bump_version('1.1a0.0') == '2.0.0'
    assert bump_version('1.1b0.0') == '2.0.0'
    # Major bump - with patch pre-release
    assert bump_version('1.0a1.0') == '2.0.0'

# Generated at 2022-06-29 18:12:11.775616
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0612
    import os
    import unittest
    from hl7_transform.testing import get_test_data_filename

    class _BumpVersionTestCase(unittest.TestCase):
        def _assert_bump_version(
                self,
                ver: str,
                item: int,
                pre: Optional[str],
                expect: str,
        ) -> None:
            result = bump_version(ver, item, pre)
            self.assertEqual(
                result,
                expect,
                "For version: %r; with item: %r; and pre: %r; "
                "the expected version was: %r; got: %r;." % (
                    ver,
                    item,
                    pre,
                    expect,
                    result,
                )
            )

# Generated at 2022-06-29 18:12:22.778057
# Unit test for function bump_version
def test_bump_version():
    import os as _os
    from os.path import join as _join
    from os.path import split as _split

    from common import create_bump_version_test_files as _create_files
    from common import delete_bump_version_test_files as _delete_files

    _test_root = _split(_os.path.abspath(__file__))[0]
    _log_file_path = _join(_test_root, 'bump_version_test.log')
    _log_file = open(_log_file_path, 'w')
    _log_file.write('Creating/setting up test files...')
    _create_files(_test_root)

    _files_path = _join(_test_root, 'files')

# Generated at 2022-06-29 18:12:29.692070
# Unit test for function bump_version
def test_bump_version():
    """Unit test for 'bump_version' function."""
    def _make_test_data():
        """Helper function to create the test data."""

# Generated at 2022-06-29 18:12:55.839385
# Unit test for function bump_version
def test_bump_version():
    test_version = '1.2.3'
    pep440_version = '1.2.3'
    new_version = bump_version(pep440_version)
    assert new_version == test_version, 'Version not bumped properly.'
    test_version = '1.2.4'
    pep440_version = '1.2.3'
    new_version = bump_version(pep440_version, 2)
    assert new_version == test_version, 'Version not bumped properly.'
    test_version = '1.3.0'
    pep440_version = '1.2.3'
    new_version = bump_version(pep440_version, 1)
    assert new_version == test_version, 'Version not bumped properly.'
    test_version = '1.2.3'

# Generated at 2022-06-29 18:12:57.378315
# Unit test for function bump_version
def test_bump_version():
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(BumpVersionTestCase('test_bump_version'))
    return suite


# Generated at 2022-06-29 18:13:04.389611
# Unit test for function bump_version
def test_bump_version():
    """Test cases for bump_version.

    .. function:: test_bump_version()

        Unit tests for the :func:`~.bump_version` function.

    """
    def _test_valid(case, current_version, position, pre_release, expected):
        """Test a given version number increase.

        Args:
            case (str):          The current test case.
            current_version (str):  The current version number.
            position (int):        The position of the version number
                                   component to increase.
            pre_release (str):    The pre-release version number
                                  component to increase.
            expected (str):       The expected version number.

        """
        result = bump_version(
            version=current_version,
            position=position,
            pre_release=pre_release
        )
       

# Generated at 2022-06-29 18:13:16.138905
# Unit test for function bump_version
def test_bump_version():
    from unittest.case import TestCase
    from unittest.mock import MagicMock
    import os

    import testfixtures

    import bumpversion

    # pylint: disable=R0903

    class _TestCase(TestCase):

        def test_init(self):
            """
            Test initializing the _TestCase class.
            """
            test_fixtures = [
                'bumpversion.bump_version',
            ]
            with testfixtures.Replacer() as r:
                for fixture in test_fixtures:
                    r.replace(fixture, MagicMock())

    test_case = _TestCase()

    test_fixtures = [
        'bumpversion.bump_version',
    ]

    version = '1.3.0'
    position = None
    pre_release

# Generated at 2022-06-29 18:13:26.160794
# Unit test for function bump_version
def test_bump_version():

    from sys import exc_info
    from traceback import print_exception

    def run_test(ver: str, pos: int, pre: Optional[str]):
        try:
            print('Testing: "%s", %d, "%s"' % (ver, pos, pre))
            print(bump_version(ver, pos, pre))
        except Exception:
            print_exception(*exc_info())

    print('\n' * 2)
    print('Testing bump_version()')
    ver: str = '1.2.3'
    run_test(ver, 1, 'a')
    run_test(ver, 1, 'alpha')
    run_test(ver, 1, 'b')
    run_test(ver, 1, 'beta')
    run_test(ver, 1, None)
    run_test

# Generated at 2022-06-29 18:13:37.515118
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    import pytest
    from .release import create_version_test_data
    version_data = create_version_test_data()
    version_major = version_data['version_major']
    version_minor = version_data['version_minor']
    version_patch = version_data['version_patch']
    version_alpha = version_data['version_alpha']
    version_beta = version_data['version_beta']
    version_release = version_data['version_release']

    # No change bump
    assert bump_version(version_major) == version_major
    assert bump_version(version_minor) == version_minor
    assert bump_version(version_patch) == version_patch
    assert bump_version(version_release) == version_release
   

# Generated at 2022-06-29 18:13:47.077229
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:00.336157
# Unit test for function bump_version
def test_bump_version():
    def run_test(
            ver: str,
            pos: int,
            pre: Optional[str],
            exp: str
    ):
        act = bump_version(ver, pos, pre)
        err_msg = (
            "The version number was not bumped as expected.\n"
            "Version: %r\n"
            "Position: %r\n"
            "Pre-Release: %r\n"
            "Expected: %r\n"
            "Got: %r" % (
                ver, pos, pre, exp, act
            )
        )
        assert act == exp, err_msg
    run_test('1.0.0', 0, None, '2.0.0')
    run_test('2.0.0', 1, None, '2.1.0')
    run

# Generated at 2022-06-29 18:14:10.551392
# Unit test for function bump_version
def test_bump_version():
    """Test method."""
    test_version = bump_version('1.2.3.4')
    assert test_version == '1.2.4'
    test_version = bump_version('1.2.3.4', 2, None)
    assert test_version == '1.2.4'
    test_version = bump_version('1.2.3', 1, None)
    assert test_version == '1.3'
    test_version = bump_version('1.2.3', 0, None)
    assert test_version == '2.0'
    test_version = bump_version('1.2.3', -2, None)
    assert test_version == '1.3'
    test_version = bump_version('1.2.3', -1, None)

# Generated at 2022-06-29 18:14:16.413032
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.6.1') == '0.6.2'
    assert bump_version('0.6.1', 0) == '1.0.0'
    assert bump_version('0.6.1', 1) == '0.7.0'
    assert bump_version('0.6.1', 2) == '0.6.1'
    assert bump_version('0.6.0', 2) == '0.6.1'
    assert bump_version('0.6.1', -1) == '0.6.1'
    assert bump_version('0.6.1', -2) == '0.6.0'
    assert bump_version('0.6.1', -3) == '0.5.1'

# Generated at 2022-06-29 18:15:09.927720
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:22.204843
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.3.0'
    assert bump_version('1.2.3', position=-2) == '2.0.0'
    assert bump_version('1.2.3', position=-3) == '2.0.0'

    assert bump_version('1.2.3', position=1, pre_release='alpha') == '1.3.0'
    assert bump_version('1.2.3', position=2, pre_release='alpha')

# Generated at 2022-06-29 18:15:31.738632
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:44.240297
# Unit test for function bump_version
def test_bump_version():
    print("[info] Testing function bump_version")
    assert bump_version('2.3.4') == '2.3.5'
    assert bump_version('2.3.4', position=2) == '2.3.5'
    assert bump_version('2.3.0') == '2.3.1'
    assert bump_version('2.3.4', position=0) == '3.0.0'
    assert bump_version('2.0.0', position=1) == '2.1.0'
    assert bump_version('2.3.4', position=1) == '3.0.0'
    assert bump_version('2.0.0', position=0) == '3.0.0'

# Generated at 2022-06-29 18:15:49.877156
# Unit test for function bump_version
def test_bump_version():
    def check_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
    ) -> None:
        actual = bump_version(version, position, pre_release)
        try:
            assert actual == expected
        except AssertionError:
            print(
                "bump_version(%r, %r, %r) failed: "
                "Expecting: %r, Actual: %r" % (
                    version,
                    position,
                    pre_release,
                    expected,
                    actual
                )
            )
            raise

    check_version('0.3.3', 0, None, '1.0.0')
    check_version('0.3.3', 1, None, '0.4.0')

# Generated at 2022-06-29 18:15:58.144573
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    position = 0
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out, '1.0.0'

    version = '0.0.0'
    position = 1
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out, '0.1.0'

    version = '0.0.0'
    position = 2
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out, '0.0.1'

    version = '0.0.0'
    position = -1
    pre_release = None
    out = bump_version(version, position, pre_release)

# Generated at 2022-06-29 18:16:09.110272
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2.0') == '0.1.3.0'
    assert bump_version('0.1.2-alpha.1') == '0.1.3-alpha.1'
    assert bump_version('0.1.2-beta.3') == '0.1.3-beta.3'
    assert bump_version('0.1.2-beta.3-rc.4') == '0.1.3-beta.3-rc.4'

    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2-alpha.1', 1) == '0.2.0-alpha.1'
    assert bump_