

# Generated at 2022-06-29 18:06:46.250708
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # noinspection Mypy
    get_num: Callable[[str, int, int], Tuple[int, int]] = lambda ver, pos, typ: (
        int(ver.split('.')[0]),
        int(ver.split('.')[1])
    )
    ver = '1.0.0'
    assert bump_version(ver, 0) == '2.0.0'
    assert bump_version(ver) == '1.0.1'
    assert bump_version(ver, 1) == '1.1.0'
    assert bump_version(ver, 1, 'a') == '1.1a0'
    assert bump_version(ver, 1, 'alpha') == '1.1a0'

# Generated at 2022-06-29 18:06:53.778411
# Unit test for function bump_version
def test_bump_version():
    """Test Version Number Bumping."""
    version = '1.0a1'
    assert bump_version(version) == '1.0a2'
    assert bump_version(version, position=3) == '1.0a2'
    assert bump_version(version, position=-1) == '1.0a2'
    assert bump_version(version, pre_release='b') == '1.0b0'
    assert bump_version(version, position=1, pre_release='b') == '1.0b0'
    assert bump_version(version, position=-2, pre_release='b') == '1.0b0'
    assert bump_version(version, pre_release='a') == '1.0a2'

# Generated at 2022-06-29 18:07:04.597418
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for the bump_version function

    :return: None
    """
    from xfmod import version as xfmod_version

# Generated at 2022-06-29 18:07:16.075707
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0') == '1'
    assert bump_version('0.1') == '0.2'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.1', 0) == '1.1.1'
    assert bump_version('0.1.1', 0, 'a') == '1.1.1'
    assert bump_version('0.1.1', 0, 'b') == '1.1.1'
    assert bump_version('0.1.1', 1) == '0.2.1'
    assert bump_version('0.1.1', 1, 'a') == '0.2a0'
    assert bump

# Generated at 2022-06-29 18:07:25.822903
# Unit test for function bump_version
def test_bump_version():
    all_tests_passed = True
    msg = ''

# Generated at 2022-06-29 18:07:37.696183
# Unit test for function bump_version
def test_bump_version():
    def _get_vn(v: str) -> Tuple[int, int, int, str]:
        ver = _build_version_info(v)
        return (
            ver.major.num, ver.minor.num, ver.patch.num, ver.patch.pre_txt
        )

    assert _get_vn('1.2.3a2') == (1, 2, 3, 'a')
    assert _get_vn('1.2.3b2') == (1, 2, 3, 'b')
    assert _get_vn('1.2.3') == (1, 2, 3, '')
    assert _get_vn('1.2.3a2.6') == (1, 2, 3, 'a')

# Generated at 2022-06-29 18:07:49.415352
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the `bump_version` module function."""
    import pytest
    from pytest import raises
    from bumpversion.utils import _equals, _get_module_path

    out = bump_version("0.0.0")
    assert _equals("0.0.1", out)

    out = bump_version("0.0.1")
    assert _equals("0.0.2", out)

    out = bump_version("0.1.0")
    assert _equals("0.1.1", out)

    out = bump_version("1.0.0")
    assert _equals("1.0.1", out)

    # Major bump
    out = bump_version("1.0.0", position=0)

# Generated at 2022-06-29 18:07:51.731257
# Unit test for function bump_version
def test_bump_version():
    start_ver = '1.2.3'
    ver = bump_version(start_ver)
    assert ver == '1.2.4'



# Generated at 2022-06-29 18:07:57.771876
# Unit test for function bump_version
def test_bump_version():
    # Test MAJOR version bump
    assert '1.0.0' == bump_version('0.0.0', position=0)
    assert '2.0.0' == bump_version('1.0.0', position=0)
    assert '2.0.0' == bump_version('1.1.1', position=0)
    # Test MINOR version bump
    assert '0.1.0' == bump_version('0.0.0')
    assert '0.2.0' == bump_version('0.1.0')
    assert '0.2.0' == bump_version('0.1.1')
    assert '1.2.0' == bump_version('1.1.0')
    assert '2.2.0' == bump_version('2.1.0')
    #

# Generated at 2022-06-29 18:08:10.512513
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'

# Generated at 2022-06-29 18:08:38.765852
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.3", position=2) == "1.2.4"
    assert bump_version("1.2.0", position=2) == "1.2"
    assert bump_version("1.0.0", position=2) == "1"

    assert bump_version("4.3.3", position=1) == "4.4"
    assert bump_version("4.3.3", position=1, pre_release="a") == "4.4a0"
    assert bump_version("4.3.3", position=1, pre_release="b") == "4.4b0"
    assert bump_version("4.3.3", position=-1) == "4.3.4"

# Generated at 2022-06-29 18:08:51.654852
# Unit test for function bump_version
def test_bump_version():
    """Ensures that the bump_version() function returns the correct values."""
    # pylint: disable=R0914,R0915
    # noinspection PyTypeChecker

# Generated at 2022-06-29 18:09:03.885148
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version() with examples."""
    assert bump_version('0.3') == '0.4'
    assert bump_version('0.3.1') == '0.3.2'
    assert bump_version('0.3', position=0) == '1.0'
    assert bump_version('0.3', pre_release='a') == '0.3a0'
    assert bump_version('0.3a0', pre_release='a') == '0.3a1'
    assert bump_version('0.3a0') == '0.4'
    assert bump_version('0.3a0', position=0) == '1.0a0'

# Generated at 2022-06-29 18:09:07.182343
# Unit test for function bump_version
def test_bump_version():
    """Ensure the bump_version function works as expected."""
    assert bump_version("1.5.1") == "1.5.2"


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:09:19.605201
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.3.5') == '0.3.6'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('0.3.5-a1') == '0.3.5a2'
    assert bump_version('0.3.5-b1') == '0.3.5b2'
    assert bump_version('0.3.5a1') == '0.3.5a2'
    assert bump_version('0.3.5b1') == '0.3.5b2'
    assert bump_version('0.3.5-beta1') == '0.3.5b2'
    assert bump_version('0.3.5-alpha1') == '0.3.5a2'
    assert bump

# Generated at 2022-06-29 18:09:32.659973
# Unit test for function bump_version
def test_bump_version():
    expected = "1.0.1"
    output = bump_version("1.0.0")
    assert output == expected
    expected = "1.1.0"
    output = bump_version("1.0.0", pre_release="a")
    assert output == expected
    output = bump_version("1.0.0", pre_release="alpha")
    assert output == expected
    expected = "1.0.1b0"
    output = bump_version("1.0.0", pre_release="b")
    assert output == expected
    output = bump_version("1.0.0", pre_release="beta")
    assert output == expected
    expected = "1.1.0"
    output = bump_version("1.0.0", 1, "a")
    assert output == expected
    output = bump

# Generated at 2022-06-29 18:09:43.593391
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', position=-3) == '1.1.0'
    assert bump_version('1.0.0', position=-2) == '2.0.0'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'

# Generated at 2022-06-29 18:09:56.211337
# Unit test for function bump_version
def test_bump_version():
    """Unit test bump_version."""

# Generated at 2022-06-29 18:10:06.789440
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:11.665747
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version
    """
    from .test_version import _bump_version_test_data
    for item in _bump_version_test_data:
        for test in item:
            out = bump_version(*test['bump_version'])
            assert out == test['out']

# Generated at 2022-06-29 18:10:35.892166
# Unit test for function bump_version
def test_bump_version():
    """
    ..  todo::

        -   Add more test cases.

    """
    ver_list = [
        '1.0.0',
        '1.0.1',
        '1.1.1',
        '1.0a0',
        '1.0a1',
        '1.0b0',
        '1.0b1',
        '1.0.0a0',
        '1.0.0a1',
        '1.0.0b0',
        '1.0.0b1',
    ]
    for ver in ver_list:
        nbump_ver = bump_version(ver)
        nver_obj = StrictVersion(nbump_ver)
        ver_obj = StrictVersion(ver)

# Generated at 2022-06-29 18:10:46.593660
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.2') == '1.0.0'
    assert bump_version('2.3.3') == '3.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    assert bump_version('1.1.1', 1) == '1.2.0'
    assert bump_version('1.1.0', 1) == '1.2.0'
    assert bump_version('1.1.0', 1, 'b') == '1.2.0b1'
    assert bump_version('1.2.0b1', 1) == '1.3.0'

# Generated at 2022-06-29 18:10:57.679810
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    assert bump_version(version) == '1.0.1'
    version = '1.0.0'
    assert bump_version(version, 0) == '2.0.0'
    version = '1.0.0'
    assert bump_version(version, 1) == '1.1.0'
    version = '1.0.0a0'
    assert bump_version(version) == '1.0.1'
    version = '1.0.0a0'
    assert bump_version(version, 2) == '1.0.1'
    version = '1.0.0a0'
    assert bump_version(version, 0, 'a') == '2.0.1'
    version = '1.0.0a0'
   

# Generated at 2022-06-29 18:11:02.651429
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = bump_version('0.1.0')
    assert version == '0.1.1'


if __name__ == "__main__":
    test_bump_version()

# Generated at 2022-06-29 18:11:10.652051
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3', pre_release='b', position=1) == '1.3b0'
    assert bump_version('1.2.3', pre_release='b', position=1) == '1.3b0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'

# Generated at 2022-06-29 18:11:22.440543
# Unit test for function bump_version
def test_bump_version():
    """Test the function :func:`build_version`."""
    # pylint: disable=W0212,E1102
    # noinspection PyUnresolvedReferences
    from .test_errors import assert_test_logs, test_logs
    from .test_types import str_any_ex
    from .test_type_match_decor import type_match

    def assert_bump(
            version: str,
            bumped: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ):
        out = bump_version(version, position, pre_release)
        assert out == bumped

    with assert_test_logs() as log:
        log.write('Testing function "bump_version(...)".')

# Generated at 2022-06-29 18:11:35.744658
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0') == '0.1.0'
    assert bump_version('0.1') == '0.1.1'
    assert bump_version('0') == '1.0.0'
    assert bump_version('1') == '1.1.0'
    assert bump_version('1', pre_release='a') == '1.1.0a0'
    assert bump_version('1.1', pre_release='a') == '1.1.0a0'
    assert bump_version('1.1.0', pre_release='a') == '1.1.1a0'
    assert bump_

# Generated at 2022-06-29 18:11:47.378499
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function

    :returns:
        True if the unit test ran successfully, otherwise returns False

    """
    import pprint
    # noinspection PyUnresolvedReferences
    import bugtracker.mod_version as mod_version

    unit_test: Dict[str, Any] = {
        'version': [],
        'position': [],
        'pre_release': [],
        'expected': [],
        'result': [],
        'failed': [],
        'failed_msg': [],
    }

# Generated at 2022-06-29 18:11:59.253713
# Unit test for function bump_version
def test_bump_version():
    from .test_util import assert_raises_regex

    # Test for out of index
    ST_9 = '%s.%s.%s'
    for ver in ('1.0.0', '9.9.9'):
        for pos in (0, 1, 2):
            for pre in ('a', 'alpha', 'b', 'beta', None):
                out = bump_version(version=ver, position=pos, pre_release=pre)
                assert_raises_regex(
                    ValueError,
                    'Only the \'minor\' or \'patch\' parts of the version '
                    'number can get a prerelease bump\.',
                    bump_version,
                    version=ver,
                    position=pos,
                    pre_release='a'
                )

    # Test bump type 'a' and 'alpha'

# Generated at 2022-06-29 18:12:12.150033
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(version='1.2.3') == '1.2.4'
    assert bump_version(version='1.2.3', position=-3) == '2.0.0'
    assert bump_version(version='1.2.3', position=-2) == '1.3.0'
    assert bump_version(version='1.2.3', position=-1) == '1.2.4'
    assert bump_version(version='1.2.3', position=0) == '2.0.0'
    assert bump_version(version='1.2.3', position=1) == '1.3.0'
    assert bump_version(version='1.2.3', position=2) == '1.2.4'

# Generated at 2022-06-29 18:12:38.841161
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(version='1.1.1') == '1.1.2'
    assert bump_version(version='1.1.1', position=1) == '1.2.0'
    assert bump_version(version='1.1.1', position=1, pre_release='a') == '1.2a0'
    assert bump_version(
        version='1.1a0',
        position=1,
        pre_release='a'
    ) == '1.2a0'
    assert bump_version(
        version='1.1b0',
        position=1,
        pre_release='a'
    ) == '1.2a0'

# Generated at 2022-06-29 18:12:49.794436
# Unit test for function bump_version
def test_bump_version():
    assert (bump_version('0.0.0') == '0.0.1')
    assert (bump_version('0.0.1') == '0.0.2')
    assert (bump_version('0.0.0.dev0') == '0.0.1.dev0')
    assert (bump_version('0.0.0.a0') == '0.0.0.a1')
    assert (bump_version('0.0.0.a1') == '0.0.0.a2')
    assert (bump_version('0.0.0.b0') == '0.0.0.b1')
    assert (bump_version('0.0.0.b1') == '0.0.0.b2')

# Generated at 2022-06-29 18:13:00.730374
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', -3) == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'

    assert bump_version('0.0.0', pre_release='alpha') == '0.1.0a0'
    assert bump_version('0.0.0', position=1, pre_release='alpha') == '0.1.0a0'

# Generated at 2022-06-29 18:13:04.662998
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    position = -3
    pre_release = 'a'
    assert bump_version(version, position, pre_release) == '1.3.0a0'


# Generated at 2022-06-29 18:13:08.535879
# Unit test for function bump_version
def test_bump_version():
    for (args, response) in TEST_DATA:
        result = bump_version(*args)
        assert result == response

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:13:18.819955
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:31.386293
# Unit test for function bump_version
def test_bump_version():
    """Test bumping a version number.

    :return:
        True if the test is passed.

    """
    def _check_b(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = ''):
        if pre_release is None:
            pre_release = ''
        got = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        if got != expected:
            raise ValueError(
                "Got %r, expected %r" % (got, expected)
            )

    _check_b(version='0.1.0', position=0, expected='1.0.0')

# Generated at 2022-06-29 18:13:42.151249
# Unit test for function bump_version
def test_bump_version():
    """Tests for the bump_version() function."""
    assert bump_version('0.3.4') == '0.3.5'
    assert bump_version('0.3.4', 1) == '0.4.0'
    assert bump_version('0.3.4', 1, 'a') == '0.4.0a0'
    assert bump_version('0.3.4a0') == '0.3.4a1'
    assert bump_version('0.3.4a0', 1) == '0.4.0'
    assert bump_version('0.3.4a0', 1, 'a') == '0.4.0'
    assert bump_version('0.3.4b0') == '0.3.4b1'

# Generated at 2022-06-29 18:13:44.709915
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120
    from version import version

    from . import test_api

    test_api.test_function(bump_version, version)

# Generated at 2022-06-29 18:13:57.537561
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:13.734642
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:24.109940
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0a1') == '0.1a0'
    assert bump_version('0.0.0b1') == '0.1b0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0a0') == '0.0.1a0'
    assert bump_version('0.0.0b0') == '0.0.1b0'
    assert bump_version('0.0') == '0.1'
    assert bump_version('0.0a0') == '0.1a0'
    assert bump_version('0.0b0') == '0.1b0'
    assert bump_version('0') == '1'
    assert bump_version('0a0')

# Generated at 2022-06-29 18:14:35.149208
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: bump_version')
    # Test version increase
    version = bump_version('1.2.3')
    print('  Old version: 1.2.3')
    print('  New version: {}'.format(version))
    assert version == '1.2.4'
    # Test pre-release increase
    version = bump_version('1.2.3', 2, 'a')
    print('  Old version: 1.2.3')
    print('  New version: {}'.format(version))
    assert version == '1.2.4a0'
    # Test pre-release increase
    version = bump_version('1.2.3a0', 2, 'a')
    print('  Old version: 1.2.3a0')
    print('  New version: {}'.format(version))


# Generated at 2022-06-29 18:14:46.027303
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """
    assert '0.2.1' == bump_version('0.2.0')
    assert '0.2.1' == bump_version('0.2.0a0')
    assert '0.2.1' == bump_version('0.2.0b0')
    assert '1.0.0' == bump_version('0.2.1')
    assert '1.0.0' == bump_version('0.2.1a0')
    assert '1.0.0' == bump_version('0.2.1b0')
    assert '0.2.1' == bump_version('0.2.0', position=2)

# Generated at 2022-06-29 18:14:54.316513
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    :return:
    """


# Generated at 2022-06-29 18:15:05.548367
# Unit test for function bump_version
def test_bump_version():
    # Test a 'major' version bump
    version = bump_version('0.3.3')
    assert version == '1.0.0', 'Failed major version bump'

    # Test a 'minor' version bump
    version = bump_version('0.3.3', position=1)
    assert (
        version == '0.4.0' or version == '0.4.3'
    ), 'Failed minor version bump'

    # Test a 'patch' version bump
    version = bump_version('0.3.3', position=2)
    assert (
        version == '0.3.4' or version == '0.3.3'
    ), 'Failed patch version bump'

    # Test a 'minor.alpha' version bump

# Generated at 2022-06-29 18:15:15.674086
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'

# Generated at 2022-06-29 18:15:27.463928
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.1') == '0.1.1.1'
    assert bump_version('0.2.2') == '0.2.3'
    assert bump_version('1.0.0.0') == '1.0.0.0.1'
    assert bump_version('1.1.0.0') == '1.1.0.0.1'
    assert bump_version('1.1.0.0.1') == '1.1.0.0.1.1'
    assert bump_version('2.2.2') == '2.2.3'
    assert bump_version('2.3.3.4') == '2.3.3.4.1'
   

# Generated at 2022-06-29 18:15:36.750692
# Unit test for function bump_version
def test_bump_version():
    import os
    import unittest

    class TestStaticVersionBump(unittest.TestCase):
        # pylint: disable=too-many-public-methods
        def test_version_bump(self):
            # pylint: disable=redefined-outer-name
            filename = os.path.join(
                os.path.dirname(__file__),
                'test_version_bump_data.txt'
            )

            def test_file_simple(
                    reader: Generator[str, None, None]
            ) -> Generator[Tuple[int, Dict[str, Any], str, str], None, None]:
                for line in reader:
                    line = line.strip()
                    if line.startswith('#') or line == '':
                        continue
                    parts = line.split()


# Generated at 2022-06-29 18:15:47.274809
# Unit test for function bump_version
def test_bump_version():

    def check(
            ver: Union[str, float],
            pos: int,
            pre: Union[str, bool],
            exp: str
    ) -> None:
        act = bump_version(ver, pos, pre)
        assert act == exp, '%r != %r' % (act, exp)

    def check_ex(
            ver: Union[str, float],
            pos: int,
            pre: Union[str, bool],
            exp: str
    ) -> None:
        try:
            act = bump_version(ver, pos, pre)
        except ValueError as err:
            assert str(err) == exp, '%r != %r' % (str(err), exp)
        else:
            msg = 'No exception was raised.  Expected: %r' % exp
            raise Assertion

# Generated at 2022-06-29 18:16:07.982184
# Unit test for function bump_version
def test_bump_version():
    def _assert(
            version_,
            pos_,
            pre_,
            result_
    ):
        # noinspection PyUnusedLocal
        changed = False
        new_version = bump_version(
            version=version_,
            position=pos_,
            pre_release=pre_
        )
        assert new_version == result_, (
            "'%s' != '%s' for '%s' (pos=%s, pre=%s)"
            "" % (
                new_version,
                result_,
                version_,
                pos_,
                pre_
            )
        )
    # Simple test cases
    _assert('0.2.3', 0, None, '1.0.0')