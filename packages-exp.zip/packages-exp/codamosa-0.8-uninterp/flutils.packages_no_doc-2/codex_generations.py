

# Generated at 2022-06-29 18:06:44.826925
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for the function bump_version
    """
    """
    For this function here, the tests are all done by hand.
    I did a print out of the unit test to include here, then just
    removed the print statement in the code. 
    """
    with open('test_data.txt', 'r') as in_file:
        test_data = in_file.read()
        print('-' * 80)
        print('Unit test for function bump_version:')
        print('-' * 80)
        print(test_data)
        in_file.close()


# Generated at 2022-06-29 18:06:47.458138
# Unit test for function bump_version
def test_bump_version():
    current_version = bump_version('1.15.1', position=2, pre_release=None)
    assert current_version == '1.15.2'


# Generated at 2022-06-29 18:06:54.396790
# Unit test for function bump_version
def test_bump_version():
    def _assert_bump(
            ver: str,
            pos: int,
            pre: Optional[str],
            out: str
    ) -> None:
        actual = bump_version(ver, pos, pre)
        assert actual == out

    # Should bump major version
    _assert_bump('0.2.3', -3, None, '1.0.0')
    _assert_bump('0.2.3', 0, None, '1.0.0')
    _assert_bump('0.2.3', -3, 'beta', '1.0.0')
    _assert_bump('0.2.3', 0, 'beta', '1.0.0')

    # Should bump minor version

# Generated at 2022-06-29 18:07:05.255156
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '2.0.1'
    assert bump_version('2.0.0', position=2) == '2.0.1'
    assert bump_version('2.0.0', position=2, pre_release='b') == '2.0.1b0'
    assert bump_version('2.0.10b4') == '2.0.10b5'
    assert bump_version('2.0.10a4') == '2.0.10a5'
    assert bump_version('2.0.10a4', position=1) == '2.1.0'
    assert bump_version('2.0.10a4', position=1, pre_release='b') == '2.1.0b0'

# Generated at 2022-06-29 18:07:17.460294
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:26.532660
# Unit test for function bump_version
def test_bump_version():
    from datetime import datetime
    from collections import namedtuple

    testcase = namedtuple('testcase', ['input', 'output'])

# Generated at 2022-06-29 18:07:38.483810
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:50.184830
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3', 'a') == '1.2.4a0'

# Generated at 2022-06-29 18:07:58.714359
# Unit test for function bump_version
def test_bump_version():
    # Make sure we can bump the major part.
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.2.3') == '2.0.0'
    assert bump_version('2.2.2') == '3.0.0'
    assert bump_version('3.3.3', position=0) == '4.0.0'
    # Make sure we can bump the minor part.
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.2.3', position=1)

# Generated at 2022-06-29 18:08:10.943998
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('1.0.1', 2) == '1.0.2'

    assert bump_version('0.0.0', 1, 'a') == '0.1.0a0'
    assert bump_version('0.0.0', 2, 'a') == '0.0.1a0'
    assert bump_version('0.0.1', 2, 'a') == '0.0.1a0'

# Generated at 2022-06-29 18:08:39.646864
# Unit test for function bump_version
def test_bump_version():
    cases = [
        # ToDo: Add test cases.
    ]
    for version, position, pre_release, expected in cases:
        actual = bump_version(version, position, pre_release)
        msg = "bump_version(%r, %r, %r) expected: %r, actual: %r" % (
            version, position, pre_release, expected, actual
        )
        assert actual == expected, msg

# Generated at 2022-06-29 18:08:52.372662
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', position=0) == '1.0.0'
    assert bump_version('0.2.1', position=0, pre_release='b') == '1.0.0'
    assert bump_version('0.2.1', position=1) == '0.3.0'
    assert bump_version('0.2.1', position=2) == '0.2.2'
    assert bump_version('0.2.1', position=-1) == '0.2.2'
    assert bump_version('0.2.1', position=-2) == '0.3.0'

# Generated at 2022-06-29 18:09:06.163266
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion
    from unittest import main, TestCase

    class TestBumpVersion(TestCase):
        def assert_version_bump(
                self,
                version: str,
                position: int = 2,
                pre_release: Optional[str] = None,
                expected: Optional[str] = None
        ) -> None:

            if expected is None:
                bump_test: Union[str, None] = None
            else:
                bump_test = StrictVersion(expected)
            actual = bump_version(version, position, pre_release)
            actual_spv = StrictVersion(actual)

# Generated at 2022-06-29 18:09:18.772846
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:27.003225
# Unit test for function bump_version
def test_bump_version():
    version = '2.2.5'
    assert bump_version(version, position=2) == '2.2.6'
    assert bump_version(version, position=-1) == '2.2.6'
    assert bump_version(version, position=-2) == '2.3.0'
    assert bump_version(version, position=-3) == '3.0.0'


# Generated at 2022-06-29 18:09:39.058232
# Unit test for function bump_version
def test_bump_version():
    print('Testing: bump_version')
    version_major = '1.0.0'
    assert bump_version(version_major, 0) == '2.0.0'
    assert bump_version(version_major, 0, 'a') == '2.0.0'
    assert bump_version(version_major, 0, 'b') == '2.0.0'

    version_minor = '1.1.0'
    assert bump_version(version_minor, 1) == '1.2.0'
    assert bump_version(version_minor, 1, 'a') == '1.2.0a0'
    assert bump_version(version_minor, 1, 'b') == '1.2.0b0'

# Generated at 2022-06-29 18:09:46.800719
# Unit test for function bump_version
def test_bump_version():
    version = "1.2.3"
    position = 1
    pre_release = "a"
    assert bump_version(version, position, pre_release) == "1.3a0"
    assert bump_version(version, position) == "1.3"
    version = "1.2.3"
    position = 0
    assert bump_version(version, position) == "2.0"
    version = "1.2.3"
    assert bump_version(version) == "1.2.4"
    version = "1.2.3a"
    assert bump_version(version) == "1.2.3a1"
    version = "1.2.3a1"
    assert bump_version(version) == "1.2.3a2"

# Generated at 2022-06-29 18:10:00.148924
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('13.143.15.b1') == '13.143.16.a0'
    assert bump_version('13.143.15.b1', 2) == '13.143.16.a0'
    assert bump_version('13.143.15.b1', 'patch') == '13.143.16.a0'
    assert bump_version('13.143.15.b1', 'b', 'a') == '13.143.15.a2'
    assert bump_version('13.143.15.b1', 'b', 'b') == '13.143.15.b2'
    assert bump_version('13.143.15.b1', 'b', 'B') == '13.143.15.b2'

# Generated at 2022-06-29 18:10:09.035262
# Unit test for function bump_version
def test_bump_version():
    version = '0.1.0'
    assert bump_version(version) == '0.1.1'
    assert bump_version(version, position=1) == '0.2.0'
    assert bump_version(version, position=0) == '1.0.0'
    assert bump_version(version, position=1, pre_release='a') == '0.2.0a0'
    assert bump_version(version, position=1, pre_release='b') == '0.2.0b0'
    assert bump_version(version, position=2, pre_release='a') == '0.1.1a0'
    assert bump_version(version, position=2, pre_release='b') == '0.1.1b0'
    version = '0.1.0a0'


# Generated at 2022-06-29 18:10:11.262522
# Unit test for function bump_version
def test_bump_version():
    """
    >>> test_bump_version()
    True
    """
    import doctest
    return doctest.testmod()[0] == 0

# Generated at 2022-06-29 18:10:28.368978
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion as SV

# Generated at 2022-06-29 18:10:39.102498
# Unit test for function bump_version
def test_bump_version():
    from . import bump_version
    assert bump_version('1.0.1b2', 0) == '2.0.0'
    assert bump_version('1.0.1b2', 1) == '1.1.0'
    assert bump_version('1.0.1b2', 2) == '1.0.2'
    assert bump_version('1.0.1b2', pre_release='a') == '1.1.1a0'
    assert bump_version('1.0.1b2', 2, pre_release='a') == '1.0.2a0'
    assert bump_version('1.0.1b2', 2, pre_release='b') == '1.0.2b0'

# Generated at 2022-06-29 18:10:52.492215
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', pre_release='a') == '1.0.1a0'
    assert bump_version('1.0.0', pre_release='alpha') == '1.0.1a0'
    assert bump_version('1.0.0', pre_release='b') == '1.0.1b0'
    assert bump_version('1.0.0', pre_release='beta') == '1.0.1b0'
    assert bump_version('1.0.0', position=-1, pre_release='a') == '1.0.1a0'
    assert bump_

# Generated at 2022-06-29 18:11:04.620747
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.1', 0) == '2.0.1'
    assert bump_version('1.0.1', 1) == '1.1.1'
    assert bump_version('1.0.1', 2) == '1.0.2'
    assert bump_version('1.0.1', -1) == '1.1.1'
    assert bump_version('1.0.1', -2) == '2.0.1'

# Generated at 2022-06-29 18:11:11.476171
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.1.1') == '1.2.0'
    assert bump_version('2.3.4') == '3.0.0'
    assert bump_version('2.9.9') == '3.0.0'
    assert bump_version('1.8.0') == '1.9.0'
    assert bump_version('1.8.0a0') == '1.8.0'
    assert bump_version('1.8.0a9') == '1.8.0a10'
    assert bump_

# Generated at 2022-06-29 18:11:24.334884
# Unit test for function bump_version
def test_bump_version():
    """Function bump_version"""
    # noinspection SpellCheckingInspection

# Generated at 2022-06-29 18:11:36.531921
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:47.222809
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.2') == '1.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3.alpha') == '1.2.3.alpha'
    assert bump_version('1.2.3.alpha', 2, 'a') == '1.2.4'
    assert bump_version('1.2.0.alpha') == '1.2.0.alpha'
    assert bump_version('1.2.0.alpha', 2, 'a') == '1.2.1'
    assert bump_version('1.2.3.alpha', 2, 'b') == '1.2.3.beta'

# Generated at 2022-06-29 18:11:59.210181
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', -3) == '1.0.0'

    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', -2) == '0.1.0'

    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', -1) == '0.0.1'

    assert bump_version('1.0.0') == '2.0.0'

# Generated at 2022-06-29 18:12:12.103982
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E0001,E0102
    def _assert_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        result = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        assert result == expected

    _assert_version(
        '0.0.1',
        position=0,
        pre_release=None,
        expected='1.0'
    )
    _assert_version(
        '0.0.1+b14',
        position=0,
        pre_release=None,
        expected='1.0'
    )

# Generated at 2022-06-29 18:12:28.411539
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.9.9') == '0.10.0'
    assert bump_version('0.9.9', position=0) == '1.0.0'
    assert bump_version('0.9.9', position=1) == '0.10.0'
    assert bump_version('0.9.9', position=2) == '0.9.10'
    assert bump_version('0.9.9', position=-1) == '0.9.10'
    assert bump_version('0.9.9', position=-2) == '0.10.0'
    assert bump_version('0.9.9', position=-3) == '1.0.0'
    assert bump_version('0.9.9', position=-4) == '1.0.0'
    assert bump

# Generated at 2022-06-29 18:12:40.895943
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:52.416853
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'

    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'

    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'

    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'


# Generated at 2022-06-29 18:13:02.110011
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.1'
    assert bump_version(version) == '0.0.2'
    assert bump_version(version, pre_release='a') == '0.0.2a0'
    assert bump_version(version, pre_release='alpha') == '0.0.2a0'
    assert bump_version(version, pre_release='b') == '0.0.2b0'
    assert bump_version(version, pre_release='beta') == '0.0.2b0'
    version = '0.0.2a0'
    assert bump_version(version) == '0.0.2a0'
    assert bump_version(version, pre_release='a') == '0.0.2a1'
    assert bump_version(version, pre_release='alpha')

# Generated at 2022-06-29 18:13:14.747613
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0a1', pre_release='a') == '1.0.0a2'
    assert bump_version('1.0.0a1', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0a1', pre_release='b', position=1) == '1.1.0b0'

# Generated at 2022-06-29 18:13:23.115459
# Unit test for function bump_version
def test_bump_version():
    version = '1.9.0'
    # bump_type = _BUMP_VERSION_MAJOR
    # assert bump_version(version, bump_type) == '2.0.0'
    # bump_type = _BUMP_VERSION_MINOR
    # assert bump_version(version, bump_type) == '1.10.0'
    # bump_type = _BUMP_VERSION_MINOR_ALPHA
    # assert bump_version(version, bump_type) == '1.10.0a0'
    # bump_type = _BUMP_VERSION_MINOR_BETA
    # assert bump_version(version, bump_type) == '1.10.0b0'
    # bump_type = _BUMP_VERSION_PATCH
    # assert bump_version(version, bump_type)

# Generated at 2022-06-29 18:13:36.018127
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.4.0') == '1.5.0'
    assert bump_version('1.0.1') == '1.0.2'
    # Test with pre-release
    assert bump_version('1.0.1a1') == '1.0.1a2'
    assert bump_version('1.0.0b1') == '1.0.0b2'
    assert bump_version('1.0.0a1') == '1.0.1'
    assert bump_version('1.0.0b1') == '1.0.1'
    # Test with not enough pre-release numbers

# Generated at 2022-06-29 18:13:46.108178
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('1.0.0-alpha.0') == '1.1.0'
    assert bump_version('1.0.0-alpha.0', 1) == '1.1.0'
    assert bump_version('1.0.0-alpha.0', 2) == '1.1.0'
    assert bump_version('1.0.0-alpha.0', 0) == '2.0.0'
    assert bump_version('1.1.0-alpha.2') == '1.1.1'
    assert bump_version

# Generated at 2022-06-29 18:13:59.409592
# Unit test for function bump_version
def test_bump_version():
    import random
    import string

    # unit test for function _build_version_info
    def test_build_version_info(ver):
        info_obj = _build_version_info(ver)
        assert info_obj.version == ver
        for idx, val in enumerate(ver.split('.')):
            if not val:
                # if val is null, then the version is major, minor
                # and patch version all zero.
                nval = 0
            else:
                if 'a' in val or 'b' in val:
                    # if val contains 'a' or 'b', then the version is
                    # pre-release version, so we need to remove it.
                    spval = val.split(val[-1])
                    nval = int(spval[0])
                else:
                    nval = int

# Generated at 2022-06-29 18:14:09.704232
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.0', pre_release='a') == '0.1.0a0'
    assert bump_version('0.1.0', position=1, pre_release='a') == '0.1.0a0'
    assert bump_version('0.1.0', position=1, pre_release='b') == '0.1.0b0'
    assert bump_version('0.1.0a0') == '0.2.0'

# Generated at 2022-06-29 18:14:38.916065
# Unit test for function bump_version
def test_bump_version():
    from dataviva import __version__

    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

    assert bump_version('1.2.3', 1, 'a') == '1.3a0'

# Generated at 2022-06-29 18:14:47.935581
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', position=0) == '1.0.0'
    assert bump_version('0.1.2', position=1) == '0.2.0'
    assert bump_version('0.1.2', position=2) == '0.1.3'
    assert bump_version('0.1.2', position=-1) == '0.1.2'
    assert bump_version('0.1.2', position=-2) == '0.1.2'
    assert bump_version('0.1.2', position=-3) == '0.1.2'
    assert bump_version('1.2.3') == '1.2.4'

# Generated at 2022-06-29 18:14:55.524267
# Unit test for function bump_version
def test_bump_version():
    print("\nbump_version(v) - return next(bumped) version\n")

# Generated at 2022-06-29 18:15:06.664479
# Unit test for function bump_version
def test_bump_version():
    v = '2.0.0'
    assert bump_version(v) == '2.0.1'
    assert bump_version(v, position=2) == '2.0.1'
    assert bump_version(v, position=2) == '2.0.1'
    assert bump_version(v, position=2, pre_release='a') == '2.0.1a0'
    assert bump_version(v, position=2, pre_release='b') == '2.0.1b0'
    assert bump_version(v, position=2, pre_release='A') == '2.0.1a0'
    assert bump_version(v, position=2, pre_release='A') == '2.0.1a0'
    v = '2.0.1'

# Generated at 2022-06-29 18:15:17.450841
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3a0') == '1.2.3a1'
    assert bump_version('1.2.3a7') == '1.2.3a8'
    assert bump_version('1.2.3b2') == '1.2.3b3'
    assert bump_version('1.2.3b0') == '1.2.3b1'
    assert bump_version('1.2.3-dev') == '1.2.3-dev'
    assert bump_version('1.2.3-dev2') == '1.2.3-dev2'
    assert bump_version('1.2.3-beta') == '1.2.3-beta'
   

# Generated at 2022-06-29 18:15:29.192712
# Unit test for function bump_version
def test_bump_version():
    return "test_bump_version"

# This code is for testing purpose
if __name__ == "__main__":
    print(bump_version('1.2.3'))
    print(bump_version('1.2.0'))
    print(bump_version('1.2.0', 1))
    print(bump_version('1.1.0', 1, 'b'))
    print(bump_version('1.1.0', 2, 'alpha'))
    print(bump_version('1.1.0', 2, 'a'))
    print(bump_version('1.2.3', -3))
    print(bump_version('1.2.3', -2))
    print(bump_version('1.2.3', -1))

# Generated at 2022-06-29 18:15:40.581138
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:46.770257
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1') == '1.2', \
        "The major and minor versions should be bumped"
    assert bump_version('1.1.0') == '1.2', \
        "The minor versions should be bumped"
    assert bump_version('1.1.1') == '1.1.2', \
        "The patch versions should be bumped"
    assert bump_version('1.1', position=0) == '2.0', \
        "The major versions should be bumped"
    assert bump_version('1.1', position=-2) == '1.1.1', \
        "The patch versions should be bumped"
    assert bump_version('1.1.1', position=-2) == '1.1.2', \
        "The patch versions should be bumped"
    assert bump_version

# Generated at 2022-06-29 18:15:56.595566
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', pre_release='a') == '0.1.0a0'
    assert bump_version('0.0.0a0') == '0.0.1'
    assert bump_version('0.0.0a0', pre_release='a') == '0.0.0a1'
    assert bump_version('0.0.0', pre_release='b') == '0.1.0b0'
    assert bump_version('0.0.0b0') == '0.0.1'
    assert bump_version('0.0.0b0', pre_release='b') == '0.0.0b1'

# Generated at 2022-06-29 18:16:08.115704
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=-3) == '2.0.0'
    assert bump_version('1.2.3', position=-2) == '1.3.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=2) == '1.2.4'
