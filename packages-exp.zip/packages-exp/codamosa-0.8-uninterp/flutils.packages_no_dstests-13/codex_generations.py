

# Generated at 2022-06-29 18:06:49.629092
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.0', 3) == '1.2.1'
    assert bump_version('1.2.0', -3) == '1.2.1'
    assert bump_version('1.2.0', -2) == '1.3.0'
    assert bump_version('1.2.3', -2)

# Generated at 2022-06-29 18:06:59.408403
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    assert bump_version('0.9') == '1.0'
    assert bump_version('0.9', 1) == '0.10'
    assert bump_version('0.9', 2) == '0.9.1'
    assert bump_version('0.9', 3) == '0.9'
    assert bump_version('0.9x') == '0.9x'
    assert bump_version('0.9a') == '0.10'
    assert bump_version('0.9a', 1) == '0.9a'
    assert bump_version('0.9a', 2) == '0.9.1'
    assert bump_version('0.9a', 3) == '0.9'

# Generated at 2022-06-29 18:07:10.915291
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from pytest import mark
    from importlib import import_module

    this_dir = path.dirname(path.abspath(__file__))
    version_file: str = path.join(this_dir, '_version.py')
    ver_mod = import_module('cloudplayer.iokit._version')
    version_current = getattr(ver_mod, 'VERSION')
    version_bumped = bump_version(version_current)
    assert version_current != version_bumped
    StrictVersion(version_current)
    StrictVersion(version_bumped)

    pos = cast(int, type(bump_version).__code__.co_varnames.index('position'))

# Generated at 2022-06-29 18:07:22.133157
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0') == '1.0.1'
    assert bump_version('1') == '1.0.1'
    assert bump_version('1.0.0-alpha') == '1.0.1'
    assert bump_version('1.0-alpha') == '1.0.1'
    assert bump_version('1-alpha') == '1.0.1'
    assert bump_version('1.0.0-alpha.0') == '1.0.1'
    assert bump_version('1.0-alpha.0') == '1.0.1'
    assert bump_version('1-alpha.0') == '1.0.1'

# Generated at 2022-06-29 18:07:32.411417
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1-a0') == '0.1.1-a1'
    assert bump_version('0.1.1-b0') == '0.1.1-b1'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 1, pre_release='alpha') == '0.2.0-a0'

# Generated at 2022-06-29 18:07:33.805263
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod()

# Generated at 2022-06-29 18:07:45.724643
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*
    """

    # Raises ValueError if given an invalid 'version' value
    with pytest.raises(ValueError):
        bump_version('1.1.1.1')

    # Raises ValueError if the given 'position' value is invalid
    with pytest.raises(ValueError):
        bump_version('1.1.1', 10)

    # Raises ValueError when a 'major' part is bumped with a prerelease
    with pytest.raises(ValueError):
        bump_version('1.1.2', 0, 'a')

    # Raises a ValueError if an invalid prerelease is given
    with pytest.raises(ValueError):
        bump_version('1.1.2', 1, 'c')



# Generated at 2022-06-29 18:07:49.744940
# Unit test for function bump_version
def test_bump_version():
    func_name = 'bump_version'

# Generated at 2022-06-29 18:07:57.503721
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""

    # test_bump_version001
    tests = [
        ('0.10.0', 0, '0.10.0'),
        ('0.10.0', 1, '0.11.0'),
        ('0.10.0', 2, '0.10.1'),
        ('0.10.0', -1, '0.10.1'),
        ('0.10.0', -2, '0.11.0'),
        ('0.10.0', -3, '1.0.0'),
    ]
    for version, position, expected in tests:
        out = bump_version(version, position=position)
        assert out == expected

    # test_bump_version002

# Generated at 2022-06-29 18:08:10.330105
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version

    :return:
        :obj:`bool`

        * ``True`` if the unit test succeeded.

    """
    ver_names = [
        '1.2.3', '0.3.4', '2.4.6', '4.5.0', '1.6.0', '1.7', '1.8',
        '0.0.2', '2.0.1', '0.0.0', '1', '2', '3', '4', '5', '6', '7',
        '8'
    ]

# Generated at 2022-06-29 18:08:48.478900
# Unit test for function bump_version
def test_bump_version():
    current_version = "4.4.4"
    new_version = bump_version(current_version)
    assert new_version == "4.4.5"
    new_version = bump_version(current_version, position=2, pre_release="a")
    assert new_version == "4.4.5a0"
    new_version = bump_version(current_version, position=0)
    assert new_version == "5.0.0"
    current_version = "4.4.4a0"
    new_version = bump_version(current_version)
    assert new_version == "4.4.5"
    new_version = bump_version(current_version, position=2, pre_release="a")
    assert new_version == "4.4.4a1"
    new_

# Generated at 2022-06-29 18:08:56.974702
# Unit test for function bump_version
def test_bump_version():

    def test_data(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None):
        return [
            {
                'args': [version, position, pre_release],
                'return': bump_version(version, position, pre_release)
            }
        ]

    def test_bump_version_valid(
            version: str,
            expected_version: str,
            position: int = 2,
            pre_release: Optional[str] = None):
        new_version = bump_version(version, position, pre_release)
        assert new_version == expected_version


# Generated at 2022-06-29 18:09:08.402189
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', -1) == '1.2.1'
    assert bump_version('1.2.0', -2) == '1.3.0'
    assert bump_version('1.2.0', -3) == '2.0.0'
    assert bump_version('1.2.0', position=0) == '2.0.0'

# Generated at 2022-06-29 18:09:20.429033
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0903,R0201,C0103
    """Unit test for the ``bump_version`` function."""
    from . import basic_unit_test
    from . import unit_test_data
    from . import unit_test_runner
    from . import unit_test_utils

    # Import for __version__
    from . import options

    # Define the target to be tested
    tgt = bump_version
    # Define the parameters to be used during the test

# Generated at 2022-06-29 18:09:33.194372
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', 2, 'a') == '0.0.1a0'
    assert bump_version('0.0.0', 2, 'b') == '0.0.1b0'
    assert bump_version('0.0.1', 2, 'b') == '0.0.2b0'

    assert bump_version('0.1.2a4') == '0.1.2a5'

# Generated at 2022-06-29 18:09:44.033584
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:54.122707
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from .comp_testing import (  # noqa
        assert_compare_exact,
    )
    from .testing import (  # noqa
        run_test_module_by_name,
    )

    run_test_module_by_name(
        name=__name__,
        file=__file__,
        func='test_bump_version',
        func_kwargs={
            ':comp_func': assert_compare_exact,
            ':comp_kwargs': {'is_detail': True},
        },
    )

# Generated at 2022-06-29 18:10:05.217489
# Unit test for function bump_version
def test_bump_version():
    """
    Test results of bump_version.
    """

# Generated at 2022-06-29 18:10:18.168447
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:30.836411
# Unit test for function bump_version
def test_bump_version():
    import os
    import pprint
    import json
    # noinspection PyUnresolvedReferences
    from pprint import pformat
    from tests.test_utils.test_runner import (
        TestSamples,
        run_test
    )

    here = os.path.abspath(os.path.dirname(__file__))
    sample_path = os.path.normpath(os.path.join(here, 'bump_version.json'))
    with open(sample_path, 'rb') as sample_file_obj:
        test_samples: TestSamples = TestSamples.from_json(
            json.load(sample_file_obj)
        )

    for test_sample in test_samples:
        if not test_sample.enabled:
            continue


# Generated at 2022-06-29 18:10:57.588570
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def _build_args(
            version: str,
            position: int,
            prerelease: str = ''
    ) -> Tuple[str, int, str]:
        return version, position, prerelease

    def _do_test(
            args: Tuple[str, int, str],
            expected: str
    ) -> None:
        got = bump_version(*args)
        msg = "bump_version%r returned '%s', not '%s'." % (
            args, got, expected
        )
        assert got == expected, msg


# Generated at 2022-06-29 18:11:08.681398
# Unit test for function bump_version
def test_bump_version():
    def run_bump(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = '',
            error: str = ''
    ) -> None:
        if error:
            try:
                bump_version(version, position, pre_release)  # pylint: disable=W0612
                assert False, "Expected error: %s" % error
            except ValueError as error:
                assert error.args[0] == error
            return
        assert bump_version(version, position, pre_release) == expected

    run_bump('0.0.1', expected='0.0.1')
    run_bump('0.0.1', 0, expected='1.0.0')

# Generated at 2022-06-29 18:11:21.232217
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 3) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3)

# Generated at 2022-06-29 18:11:34.657297
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0') == '1.0.1'
    assert bump_version('1.0-a0') == '1.0-a1'
    assert bump_version('1.0-b0') == '1.0-b1'
    assert bump_version('1.0-a1') == '1.0-a2'
    assert bump_version('1.0-b1') == '1.0-b2'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0') == '0.0.1'
    assert bump_version('0.0-a0') == '0.0-a1'
    assert bump_

# Generated at 2022-06-29 18:11:45.747488
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0alpha') == '0.0.1alpha'
    assert bump_version('0.0.0alpha0') == '0.0.1alpha0'
    assert bump_version('0.0.0alpha1') == '0.0.1alpha2'
    assert bump_version('0.0.0alpha99') == '0.0.1alpha100'
    assert bump_version('0.0.0beta') == '0.0.1beta'
    assert bump_version('0.0.0beta0') == '0.0.1beta0'
    assert bump_version('0.0.0beta1') == '0.0.1beta2'

# Generated at 2022-06-29 18:11:53.369909
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        version='0.1.0',
        position=0,
        pre_release='alpha'
    ) == '1.0.0'

    assert bump_version(
        version='0.1.0',
        position=0
    ) == '1.0.0'

    assert bump_version(
        version='0.1.0',
        position=1
    ) == '0.2.0'

    assert bump_version(
        version='0.1.0',
        position=1,
        pre_release='alpha'
    ) == '0.2a0'

    assert bump_version(
        version='0.1.0',
        position=1,
        pre_release='Alpha'
    ) == '0.2a0'


# Generated at 2022-06-29 18:12:00.075998
# Unit test for function bump_version
def test_bump_version():
    def t(version:str, position:int, pre_release:Optional[str], expected:str):
        assert bump_version(version, position, pre_release) == expected
    a = t
    a("0.1.0", 2, None, "0.1.1")
    a("0.1.0", 2, "alpha", "0.1.1")
    a("0.1.0", 2, "beta", "0.1.1")
    a("0.1.0", 2, "a", "0.1.1")
    a("0.1.0", 2, "b", "0.1.1")
    a("0.1.1", 2, None, "0.1.2")
    a("0.1.1", 2, "alpha", "0.1.2")


# Generated at 2022-06-29 18:12:12.784456
# Unit test for function bump_version
def test_bump_version():
    """
    Check the output version with expected value
    """
    # pylint: disable=unused-variable
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', 3) == '0.0.1'
    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', -2) == '0.1.0'

# Generated at 2022-06-29 18:12:23.613771
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    assert bump_version(version) == '1.0.1'
    assert bump_version(version, 0) == '2.0.0'
    assert bump_version(version, 1) == '1.1.0'
    assert bump_version(version, 2) == '1.0.1'
    assert bump_version(version, -1) == '1.0.1'
    assert bump_version(version, -2) == '1.1.0'
    assert bump_version(version, -3) == '2.0.0'

    version = '1.1.1'
    assert bump_version(version) == '1.1.2'
    assert bump_version(version, 0) == '2.1.1'

# Generated at 2022-06-29 18:12:26.893821
# Unit test for function bump_version
def test_bump_version():
    version_string = "2.0.0"
    position = 1
    pre_release = "a"
    print(bump_version(version_string, position, pre_release))
    
    
#test_bump_version()

# Generated at 2022-06-29 18:12:42.456474
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('1.2.3')
    assert ver == '1.2.4'

    ver = bump_version('1.2.3', 1)
    assert ver == '1.3.0'

    ver = bump_version('1.2.3', 0)
    assert ver == '2.0.0'

    ver = bump_version('1.2.3', 0, 'a')
    assert ver == '2.0.0'

    ver = bump_version('1.2.3', 1, 'a')
    assert ver == '1.3.0'

    ver = bump_version('1.2.3', 2, 'a')
    assert ver == '1.2.4'

    ver = bump_version('1.2.3', -2)

# Generated at 2022-06-29 18:12:47.413799
# Unit test for function bump_version
def test_bump_version():
    from sys import version_info as python_version
    from . import assert_equal
    from . import assert_not_equal
    from . import assert_true
    from . import assert_false
    from . import assert_is
    from . import assert_is_instance
    from . import assert_is_none
    from . import assert_raises
    from . import assert_raise_message

    assert_equal(bump_version('1.2.3a5'), '1.2.4')
    assert_equal(bump_version('1.2.3b5'), '1.2.4')
    assert_equal(bump_version('1.2.3'), '1.2.4')
    assert_equal(bump_version('1.2.3', position=0), '2.0.0')

# Generated at 2022-06-29 18:12:58.636710
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    print()
    print('bump_version')
    print('------------')
    print()

    print('This test is being run from the %s directory.' % os.getcwd())

    print()
    print('Test: No arguments (should be a TypeError)')
    print()

    try:
        # bump_version()
        # Обрабатываем ошибку
        raise

    except (TypeError, ValueError) as err:
        # Проверяем текст ошибки
        assert str(err) == 'bump_version() missing 2 required positional arguments: \'version\' and \'position\''

    print()

# Generated at 2022-06-29 18:13:12.144665
# Unit test for function bump_version
def test_bump_version(): # pragma: no cover
    import sys
    import unitests.util as util

    # Test cases

# Generated at 2022-06-29 18:13:21.406300
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    Run the test with:

        $ python src/version_bump/version_bump.py

    """  # noqa: W291
    version = bump_version('1.0.0')
    assert version == '1.0.1', version
    version = bump_version('1.0.0', position=2)
    assert version == '1.0.1', version
    version = bump_version('1.0.0', position=1)
    assert version == '1.1.0', version
    version = bump_version('1.0.0', position=0)
    assert version == '2.0.0', version
    version = bump_version('1.0.0', position=2, pre_release='b')

# Generated at 2022-06-29 18:13:34.127742
# Unit test for function bump_version
def test_bump_version():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestBumpVersion(unittest.TestCase):
        """Test bump_version()."""

        def _bump_version(
                self,
                version: str,
                position: int = 2,
                pre_release: Optional[str] = None
        ) -> str:
            """Wrapper for the bump_version() function."""
            return bump_version(version, position, pre_release)

        def test_bad_version(self):
            """Test with a bad version number."""
            self.assertRaises(ValueError, self._bump_version, 'abcd')

        def test_bad_position(self):
            """Test with a bad position."""

# Generated at 2022-06-29 18:13:44.801613
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:57.704208
# Unit test for function bump_version
def test_bump_version():
    """
    test for the bump_version function
    """
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0'
    assert bump_version('1.2.3a1', 1, 'alpha') == '1.3.0'
    assert bump_version('1.2.3a1', 1, 'beta') == '1.3.0'
    assert bump_version('1.2.3a1', 2, 'alpha') == '1.2.4a0'
    assert bump_version('1.2.3a1', 2, 'beta') == '1.2.4b0'

# Generated at 2022-06-29 18:14:08.141047
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.2.1') == '3.2.2'
    assert bump_version('3.2.1', 1) == '3.3.0'
    assert bump_version('3.2.1', 1, 'alpha') == '3.3.0a0'
    assert bump_version('3.2.1a0') == '3.2.1a1'
    assert bump_version('3.2.1a0', position=-1) == '3.2.2a0'
    assert bump_version('3.2.1a0', position=-1, pre_release='alpha') == '3.2.2a0'
    assert bump_version('3.2.1a0', position=-2) == '3.3.0a0'

# Generated at 2022-06-29 18:14:15.190094
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_basic(self):
            self.assertEqual(
                bump_version('1.2.3'),
                '1.2.4'
            )

        def test_bump_version_alpha(self):
            self.assertEqual(
                bump_version('1.3.0', pre_release='a'),
                '1.3.0a0'
            )
            self.assertEqual(
                bump_version('1.2.0b0', pre_release='a'),
                '1.2.0a0'
            )