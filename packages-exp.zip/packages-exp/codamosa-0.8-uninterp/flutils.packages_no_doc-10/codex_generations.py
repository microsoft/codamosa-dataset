

# Generated at 2022-06-29 18:06:48.819333
# Unit test for function bump_version
def test_bump_version():
    # Setup
    test = dict()
    test['major'] = dict()
    test['minor'] = dict()
    test['patch'] = dict()
    test['minor']['alpha'] = dict()
    test['minor']['beta'] = dict()
    test['patch']['alpha'] = dict()
    test['patch']['beta'] = dict()
    test['major']['bump'] = dict()
    test['minor']['bump'] = dict()
    test['patch']['bump'] = dict()
    test['minor']['alpha']['bump'] = dict()
    test['minor']['beta']['bump'] = dict()
    test['patch']['alpha']['bump'] = dict()

# Generated at 2022-06-29 18:06:58.332970
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.2.0', 1) == '0.3.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('1.3.2', 3) == '1.3.3'

# Generated at 2022-06-29 18:07:09.996606
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:21.265294
# Unit test for function bump_version
def test_bump_version():
    import time
    import multiprocessing as mp


# Generated at 2022-06-29 18:07:28.266057
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0')
    assert version == '1.0.1'
    version = bump_version('1.0.0', pre_release='a')
    assert version == '1.0.0a0'
    version = bump_version('1.0.0', pre_release='A')
    assert version == '1.0.0a0'
    version = bump_version('1.1.0a0', pre_release='a')
    assert version == '1.1.0a1'
    version = bump_version('1.1.0a0', pre_release='b')
    assert version == '1.1.0b0'
    version = bump_version('1.0.0a0', pre_release='b')

# Generated at 2022-06-29 18:07:40.571666
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'
    assert bump_version('0.0.0', position=-2) == '0.1.0'
    assert bump_version('0.0.0', position=-1) == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=3) == '0.1.0'
    assert bump

# Generated at 2022-06-29 18:07:51.301412
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:57.563363
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2', 0) == '1.0.0'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 2) == '0.1.3'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('0.1.2', 1, 'a') == '0.2.0a0'
    assert bump_version('0.1.2', 1, 'b') == '0.2.0b0'
    assert bump_version('0.1.2a0', 1, 'b') == '0.2.0b0'

# Generated at 2022-06-29 18:08:10.362930
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.0.0'))
    print(bump_version('1.0.0', pre_release='a'))
    print(bump_version('1.2.3.4', pre_release='b'))
    print(bump_version('1.0.0', position=-2, pre_release='b'))
    print(bump_version('0.1.2b2', position=-2, pre_release='a'))
    print(bump_version('1.0.0', pre_release='B'))
    print(bump_version('1.0.0', position=1, pre_release='b'))
    print(bump_version('1.0.0', position=-1, pre_release=None))


# Generated at 2022-06-29 18:08:20.967203
# Unit test for function bump_version
def test_bump_version():
    def _assert_eq(one, two, msg=None):
        if msg is None:
            msg = '%r != %r' % (one, two)
        assert one == two, msg

    # Should work
    _assert_eq(
        bump_version('1.0', 0, None),
        '2.0'
    )
    _assert_eq(
        bump_version('1.0', 1, None),
        '1.1'
    )
    _assert_eq(
        bump_version('1.0', 2, None),
        '1.0.1'
    )
    _assert_eq(
        bump_version('1.0', 3, None),
        '1.1'
    )

# Generated at 2022-06-29 18:08:52.332647
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.0.0', 'patch') == '2.0.1'
    assert bump_version('2.0.0', 'patch', 'a') == '2.0.1a0'
    assert bump_version('2.0.0', 'minor', 'a') == '2.1.0'
    assert bump_version('2.0.0', 'minor', 'b') == '2.1.0b0'
    assert bump_version('2.0.0', 'minor') == '2.1.0'
    assert bump_version('2.0.0', 'minor', 'a') == '2.1.0'

# Generated at 2022-06-29 18:09:06.162329
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.4'
    assert bump_version(version) == '1.0.5'
    assert bump_version(version, position=-1) == '1.0.5'
    assert bump_version(version, position=-2) == '1.1'
    assert bump_version(version, position=-3) == '2'
    assert bump_version(version, position=0) == '2'
    assert bump_version(version, position=1) == '1.1'
    assert bump_version(version, position=2) == '1.0.5'
    assert bump_version(version, position=3) == '1.0.5'
    assert bump_version(version, position=4) == '1.0.5'

    # Test prerelease

# Generated at 2022-06-29 18:09:18.773740
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('3.0.0') == '4.0.0'
    assert bump_version('1.1.0') == '1.2.0'
    assert bump_version('1.2.0') == '1.3.0'
    assert bump_version('1.3.0') == '1.4.0'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.2') == '1.0.3'
    assert bump_version('1.0.3') == '1.0.4'


# Generated at 2022-06-29 18:09:32.556003
# Unit test for function bump_version
def test_bump_version():
    initial_version = "1.2.3"
    expected_version_major = "2.0.0"
    expected_version_minor = "1.3.0"
    expected_version_patch = "1.2.4"
    expected_version_minor_alpha = "1.3a0"
    expected_version_minor_beta = "1.3b0"
    expected_version_patch_alpha = "1.2.4a0"
    expected_version_patch_beta = "1.2.4b0"
    assert bump_version(initial_version, 0) == expected_version_major
    assert bump_version(initial_version, 1) == expected_version_minor
    assert bump_version(initial_version, 2) == expected_version_patch

# Generated at 2022-06-29 18:09:40.038903
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    test_code_coverage: str = bump_version
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '0.1.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', -1) == '0.0.2'
    assert bump_version('0.0.1', -2) == '0.1.0'
    assert bump_version('0.0.1', -3) == '1.0.0'

# Generated at 2022-06-29 18:09:47.266566
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:00.441625
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Unit test for function 'bump_version'"""
    ver = '2.0.0'
    assert bump_version(ver, 0) == '3.0.0'
    assert bump_version(ver, -3) == '3.0.0'
    assert bump_version(ver, 1) == '2.1.0'
    assert bump_version(ver, -2) == '2.1.0'
    assert bump_version(ver, 2) == '2.0.1'
    assert bump_version(ver, -1) == '2.0.1'
    ver = '2.0.0a0'
    assert bump_version(ver, 0) == '3.0.0a0'

# Generated at 2022-06-29 18:10:11.263962
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', position=2, pre_release='alpha') == '0.1.1a0'
    assert bump_version('0.1.0', position=2, pre_release='beta') == '0.1.1b0'
    assert bump_version('0.1.1', position=2, pre_release='alpha') == '0.1.2a0'
    assert bump_version('0.1.1', position=2, pre_release='beta') == '0.1.2b0'
    assert bump_version('0.1.1a0') == '0.1.1a1'

# Generated at 2022-06-29 18:10:24.227533
# Unit test for function bump_version
def test_bump_version():
    import sys
    import tempfile
    import unittest

    class Runner(unittest.TestCase):
        def check_bump_version(
                self,
                version: str,
                position: int = 2,
                pre_release: Optional[str] = None
        ) -> Tuple[StrictVersion, str]:
            print(
                'Test: version: %r, position: %r, pre_release: %r' % (
                    version, position, pre_release
                )
            )
            try:
                old_version = StrictVersion(version)
            except ValueError:
                raise ValueError(
                    "Unable to parse given version number: %r" % (
                        version
                    )
                )
            out = bump_version(version, position, pre_release)

# Generated at 2022-06-29 18:10:30.160259
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:43.244963
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=-1, pre_release='alpha') == '1.2.4a0'

    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=0) == '2.0.0'

# Generated at 2022-06-29 18:10:55.466853
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:07.026527
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0', 0, None) == '1.0.0'
    assert bump_version('0.0.0', 1, None) == '0.1.0'
    assert bump_version('0.0.0', 2, None) == '0.0.1'
    assert bump_version('0.0.0', 0, 'a') == '1.0.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1a0'
    assert bump_version('0.0.0', 2, 'a') == '0.0.1a0'
    assert bump_version('0.0.0', 1, 'b') == '0.1b0'

# Generated at 2022-06-29 18:11:20.661372
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.1.0") == "0.1.1"
    assert bump_version("0.1.0", position=-3) == "1.0.0"
    assert bump_version("1.2.0") == "1.2.1"
    assert bump_version("1.2.0", position=-2) == "2.0.0"
    assert bump_version("1.2.0", position=-1) == "1.3.0"
    assert bump_version("1.2.0", position=0) == "2.0.0"
    assert bump_version("1.2.0", position=1) == "1.3.0"
    assert bump_version("1.2.0", position=2) == "1.2.1"

# Generated at 2022-06-29 18:11:34.045699
# Unit test for function bump_version
def test_bump_version():
    version = '1.3.0rc2'
    # Test for function bump_version with position = 'minor' and
    # pre_release = 'a'
    bump_version(version, position=1, pre_release='a')
    # Test for function bump_version with position = 'minor' and
    # pre_release = 'alpha'
    bump_version(version, position=1, pre_release='alpha')
    # Test for function bump_version with position = 'patch' and
    # pre_release = 'a'
    bump_version(version, position=2, pre_release='a')
    # Test for function bump_version with position = 'patch' and
    # pre_release = 'alpha'
    bump_version(version, position=2, pre_release='alpha')
    # Test for function bump_version

# Generated at 2022-06-29 18:11:41.275984
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:50.701783
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('10.0.0') == '11.0.0'
    assert bump_version('11.1.1') == '11.2.0'
    assert bump_version('11.2.2', 1) == '11.3.0'
    assert bump_version('11.2.2', 1, 'a') == '11.2.2a0'
    assert bump_version('11.2.2a0', 1, 'a') == '11.2.2a1'
    assert bump_version('11.2.2', 1, 'b') == '11.3.0b0'
    assert bump_version('11.2.2a0', 1, 'b') == '11.3.0b0'

# Generated at 2022-06-29 18:12:03.370710
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.3.3') == '3.3.4'
    assert bump_version('3.3.3', -1) == '3.3.4'
    assert bump_version('3.3.3', 0) == '4.0.0'
    assert bump_version('3.3.3', 1) == '3.4.0'
    assert bump_version('3.3.3', 2) == '3.3.4'
    # Pre-release bumps
    assert bump_version('3.3.3', 0, 'a') == '4.0.0'
    assert bump_version('3.3.3', 1, 'a') == '3.4.0a0'

# Generated at 2022-06-29 18:12:15.624773
# Unit test for function bump_version
def test_bump_version():
    def assert_eq(v1, v2):
        assert v1 == v2

    # Test simple version bumps
    assert_eq(bump_version('1.0.0'), '1.0.1')
    assert_eq(bump_version('1.1.0'), '1.1.1')
    assert_eq(bump_version('1.0.1'), '1.0.2')
    assert_eq(bump_version('2.4.5'), '2.4.6')

    # Test pre-release version bumps
    assert_eq(bump_version('1.0.0', 2, 'a'), '1.0.0a0')
    assert_eq(bump_version('1.0.0', 2, 'b'), '1.0.0b0')
    assert_eq

# Generated at 2022-06-29 18:12:25.752172
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', pre_release='alpha') == '0.1.1'
    assert bump_version('0.1.0', pre_release='alpha', position=1) == '0.2.0'
    assert bump_version('0.1.0', pre_release='alpha', position=0) == '1.0.0'
    assert bump_version('0.1.0', pre_release='alpha', position=2) == '0.1.1'
    assert bump_version('0.1.2', pre_release='alpha') == '0.1.3'

# Generated at 2022-06-29 18:12:46.320194
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.2.3') == '1.2.4')
    assert(bump_version('1.2.3-rc1') == '1.2.4')
    assert(bump_version('1.2.3-a1') == '1.2.4')
    assert(bump_version('1.2.3-a1', position=1) == '1.3')
    assert(bump_version('1.2.3-a1', position=1, pre_release='beta') == '1.3.0')
    assert(bump_version('1.2.3-a1', position=1, pre_release='a') == '1.3.0')

# Generated at 2022-06-29 18:12:57.445005
# Unit test for function bump_version
def test_bump_version():
    value = bump_version('1.8.0')
    assert value == '1.9.0'
    value = bump_version('1.8.4')
    assert value == '1.9.0'
    value = bump_version('1.8.4', -1)
    assert value == '1.9.0'
    value = bump_version('1.8.4', 0)
    assert value == '2.0.0'
    value = bump_version('1.8.4', 1)
    assert value == '1.9.0'
    value = bump_version('1.8.4', 2)
    assert value == '1.8.5'
    value = bump_version('1.8.4', -1, 'a')
    assert value == '1.8.5a0'


# Generated at 2022-06-29 18:13:04.406325
# Unit test for function bump_version
def test_bump_version():
    version =  bump_version("0.0.1",1,"a")
    assert version == "1.0.0"

    version =  bump_version("0.6",1,"a")
    assert version == "1.0.0"

    version =  bump_version("0.7.2",1,"a")
    assert version == "1.0.0"

    version =  bump_version("1.17.0",0)
    assert version == "2.0.0"

    version =  bump_version("1.18.0",1,"a")
    assert version == "2.0.0"

    version =  bump_version("1.18.0",1,"b")
    assert version == "2.0.0"


# Generated at 2022-06-29 18:13:09.122002
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0-dev') == '1.0.0'
    assert bump_version('0.2.0') == '1.0.0'
    assert bump_version('0.2.0-dev', 0) == '0.3.0'
    assert bump_version('0.2.0-dev', 1, 'b') == '1.0.0'
    assert bump_version('0.2.0-dev', 1, 'alpha') == '1.0.0'
    assert bump_version('0.2.0-dev', 1, 'test') == '1.0.0'
    assert bump_version('0.2.1') == '1.0.0'
    assert bump_

# Generated at 2022-06-29 18:13:19.280636
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    position = 2
    pre_release = 'a'
    assert bump_version(version, position, pre_release) == '0.0.0a0'
    version = '0.0.0'
    position = 2
    pre_release = 'alpha'
    assert bump_version(version, position, pre_release) == '0.0.0a0'
    version = '0.0.0'
    position = 1
    pre_release = 'a'
    assert bump_version(version, position, pre_release) == '0.0.0a0'
    version = '0.0.0'
    position = 1
    pre_release = 'alpha'
    assert bump_version(version, position, pre_release) == '0.0.0a0'

# Generated at 2022-06-29 18:13:32.197568
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 0, 'a') == '1.0.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1.0'
    assert bump_version('0.0.0', 2, 'a') == '0.0.1a0'
    assert bump_version('0.0.0', 2, 'b') == '0.0.1b0'
   

# Generated at 2022-06-29 18:13:42.932141
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:49.612391
# Unit test for function bump_version
def test_bump_version():

    # patch
    assert '2.3.4' == bump_version('2.3.3')
    assert '2.3.5' == bump_version('2.3.4')
    assert '2.3.6' == bump_version('2.3.5')

    # patch alpha
    assert '2.3.4a0' == bump_version('2.3.4')
    assert '2.3.4a1' == bump_version('2.3.4a0')
    assert '2.3.4a2' == bump_version('2.3.4a1')
    assert '2.3.5a0' == bump_version('2.3.4a2')
    assert '2.3.5a1' == bump_version('2.3.5a0')

# Generated at 2022-06-29 18:14:01.995937
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('6.0.0') == '6.0.1'
    assert bump_version('6.1.0') == '6.1.1'
    assert bump_version('6.1.1') == '6.1.2'
    assert bump_version('6.1.0a0') == '6.1.0a1'
    assert bump_version('6.1.0a1') == '6.1.0a2'
    assert bump_version('6.1.0b0') == '6.1.0b1'
    assert bump_version('6.1.0b1') == '6.1.0b2'
    assert bump_version('6.1.1a0') == '6.1.2a0'

# Generated at 2022-06-29 18:14:11.617124
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    import sys

# Generated at 2022-06-29 18:14:29.806649
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:42.017431
# Unit test for function bump_version
def test_bump_version():
    # Test basic functionality
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('3.2.1') == '3.3.0'
    assert bump_version('3.2.0') == '3.3.0'
    assert bump_version('3.10.0') == '4.0.0'
    assert bump_version('0.1.123') == '0.2.0'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.1') == '0.2.0'
    assert bump_version('0.1.4') == '0.2.0'
    assert bump_

# Generated at 2022-06-29 18:14:49.358457
# Unit test for function bump_version
def test_bump_version():
    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        actual = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        msg = (
            "bump_version('{}', position={}, pre_release='{}') "
            "produced '{}' when it should have produced '{}'."
        )
        msg = msg.format(
            version,
            position,
            pre_release,
            actual,
            expected
        )
        assert actual == expected, msg

    yield _test, '0.0.0', 2, None, '0.0.1'

# Generated at 2022-06-29 18:15:01.250268
# Unit test for function bump_version
def test_bump_version():
    from .examples import (
        _BUMP_VERSION_MINOR_PRE_RELEASE_EXAMPLES,
        _BUMP_VERSION_PATCH_PRE_RELEASE_EXAMPLES,
        _BUMP_VERSION_PRE_RELEASE_MINOR_BUMP_MESSAGE,
        _BUMP_VERSION_PRE_RELEASE_PATCH_BUMP_MESSAGE,
    )
    from .segment_tests import (
        run_bump_version_segment_tests,
        run_bump_version_tests,
    )

    run_bump_version_tests(bump_version)

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-29 18:15:09.898619
# Unit test for function bump_version
def test_bump_version():
    print( bump_version('0.1.0') )
    print( bump_version('0.1.0', 1, 'b') )
    print( bump_version('0.1.0', 1, 'alpha') )
    print( bump_version('0.1.0', 1, 'b') )
    print( bump_version('0.1.0', 1, 'beta') )
    print( bump_version('0.1.0', 1, 'b') )
    print( bump_version('0.1.0', 1, 'beta') )
    print( bump_version('0.1.0', 1, 'b') )
    print( bump_version('0.1.0', 1, 'beta') )
    print( bump_version('0.1.0', 1, 'b') )

# Generated at 2022-06-29 18:15:22.204742
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.2.0', 1) == '1.3'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.1', 0) == '2'
    assert bump_version('1.1', 0, 'a') == '2'
    assert bump_version('1.0.0a1') == '1.0.0a2'

# Generated at 2022-06-29 18:15:31.738530
# Unit test for function bump_version
def test_bump_version():
    """
    Tests the bump_version function.

    Notes:
        Make sure you run the coverage report to ensure that all test cases
        are being covered.

    Args:

    Returns:

    """
    print('TEST CASE')
    print('---------')
    print('Test `bump_version` function')
    print('----------------------------')
    print('\n')

    t1 = 'v0.1.0'
    a1 = (_build_version_info(t1).version,
          _build_version_info(t1).major.num,
          _build_version_info(t1).minor.num,
          _build_version_info(t1).patch.num,
          _build_version_info(t1).pre_pos)

# Generated at 2022-06-29 18:15:44.239380
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0') == '2.0.0'

    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.2.0', 1) == '1.3.0'

    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'


# Generated at 2022-06-29 18:15:48.670334
# Unit test for function bump_version
def test_bump_version():
    # GIVEN
    version = "1.0.0+snapshot"
    position = 0
    pre_release = "a"

    # WHEN
    new_version = bump_version(version, position, pre_release)

    # THEN
    assert new_version == "2.0.0+snapshot"

# Generated at 2022-06-29 18:15:57.535186
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version.
    :return:
    """
    # Test 1: Test bump_version with no parameter
    if bump_version('1.2.3') == '1.2.4':
        print('Test 1: Passed')
    else:
        print('Test 1: Failed')

    # Test 2: Test bump_version with position parameter
    if bump_version('1.2.3', 0) == '2.0.0':
        print('Test 2: Passed')
    else:
        print('Test 2: Failed')

    # Test 3: Test bump_version with negative position parameter
    if bump_version('1.2.3', -1) == '1.3.0':
        print('Test 3: Passed')
    else:
        print('Test 3: Failed')

    # Test 4

# Generated at 2022-06-29 18:16:14.977453
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.2.0') == '0.3.0'
    assert bump_version('0.3.0') == '0.4.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.2') == '0.0.3'
    assert bump_version('0.0.3') == '0.0.4'