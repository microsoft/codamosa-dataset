

# Generated at 2022-06-29 18:06:47.876661
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1') == '1.1.1'
    assert bump_version('1.1', pre_release='a') == '1.1.1a0'
    assert bump_version('1.1a5', pre_release='a') == '1.1a6'
    assert bump_version('1.1b5', pre_release='a') == '1.1a0'
    assert bump_version('1.1b5', pre_release='b') == '1.1b6'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.0', pre_release='a') == '1.1.0a0'
   

# Generated at 2022-06-29 18:06:54.544084
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2', 2) == '1.2.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3b1') == '1.2.4b0'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=-1) == '1.0.1'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:07:05.394149
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:16.947631
# Unit test for function bump_version
def test_bump_version():
    version = '0.2.0'
    assert bump_version(version) == '0.2.1'

    version = '0.2.0b4'
    assert bump_version(version) == '0.2.1b0'
    assert bump_version(version, 2, 'a') == '0.2.1a0'

    version = '0.2.0b4'
    assert bump_version(version, 1) == '0.3.0'

    version = '0.2.0b4'
    assert bump_version(version, -2) == '0.3.0'

    version = '0.2.0b4'
    assert bump_version(version, -1) == '0.2.1'

    version = '0.2.0b4'
    assert bump_

# Generated at 2022-06-29 18:07:26.271556
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert bump_version(version) == '0.0.1'
    version = '0.0.0a0'
    assert bump_version(version, 0, 'alpha') == '1.0.0'
    assert bump_version(version, 0, 'a') == '1.0.0'
    assert bump_version(version, 0, 'beta') == '1.0.0'
    assert bump_version(version, 0, 'b') == '1.0.0'
    assert bump_version(version, 1, 'alpha') == '0.1.0'
    assert bump_version(version, 1, 'a') == '0.1.0'
    assert bump_version(version, 1, 'beta') == '0.1.0'
    assert bump_

# Generated at 2022-06-29 18:07:38.273280
# Unit test for function bump_version
def test_bump_version():
    # Test w/ and w/o a pre-release
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3', pre_release='ALPHA') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='Beta') == '1.2.4b0'

    # Test w/ and w/o a pre-release
    assert bump_version('1.2.0') == '1.2.1'

# Generated at 2022-06-29 18:07:42.686610
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert bump_version(version) == '0.0.1'


if __name__ == '__main__':
    # Unit test for function bump_version
    test_bump_version()

# Generated at 2022-06-29 18:07:52.806915
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0-a0') == '0.0.1'
    assert bump_version('0.0.0-b0') == '0.0.1'
    assert bump_version('0.0.0-alpha') == '0.0.1'
    assert bump_version('0.0.0-beta') == '0.0.1'

    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1-a0') == '0.0.2'
    assert bump_version('0.0.1-b0') == '0.0.2'

# Generated at 2022-06-29 18:08:04.295081
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('foo') == 'foo'
    assert bump_version('foo.bar') == 'foo.bar'
    assert bump_version('foo.bar.42') == 'foo.bar.42'
    assert bump_version('1') == '1'
    assert bump_version('1.0') == '1.0'
    assert bump_version('1.0.0') == '1.0.0'
    assert bump_version('1.0.0', 1) == '1.1'
    assert bump_version('1.0.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0.1') == '1.0.1'
    assert bump_version('1.0.1', 1) == '1.1'

# Generated at 2022-06-29 18:08:13.138875
# Unit test for function bump_version
def test_bump_version():
    print('Unit test started')
    
    # Initialize test variables
    version, position, pre_release = '1.2.3', 2, None
    
    # Test without optional arguments
    out = bump_version(version)
    assert out == '1.2.4', 'Unexpected result: %s' % out

    # Test expected and unexpected type of arguments
    out = bump_version(version, position)
    assert out == '1.2.4', 'Unexpected result: %s' % out
    
    position, pre_release = 0, 'alpha'
    out = bump_version(version, position, pre_release)
    assert out == '2.0.0', 'Unexpected result: %s' % out
    position, pre_release = 3, 'alpha'

# Generated at 2022-06-29 18:08:56.325118
# Unit test for function bump_version
def test_bump_version():
    # test for bump_version
    assert bump_version('1.0.0.a1') == '1.0.0.a2'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.1.b1') == '1.0.2'
    assert bump_version('1.0.1.b1') == '1.0.2'
    assert bump_version('1.0.0.b1', position=0) == '2.0.0'
    assert bump_version('1.0.0.a1', position=0) == '2.0.0'
    assert bump_version('1.0.0.a1', position=0, pre_release='b') == '2.0.0'
    assert bump_version

# Generated at 2022-06-29 18:09:07.772313
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:19.954092
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:32.795370
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212
    assert(bump_version('1.0.0') == '1.0.1')
    assert(bump_version('1.0.0', position=0) == '2.0.0')
    assert(bump_version('1.0.3', position=0) == '2.0.3')
    assert(bump_version('1.0.2', position=1) == '1.1.2')
    assert(bump_version('1.0.2', position=1, pre_release='beta') == '1.1.2b0')
    assert(bump_version('1.0.2', position=1, pre_release='a') == '1.1.2a0')

# Generated at 2022-06-29 18:09:43.714965
# Unit test for function bump_version
def test_bump_version():
    from nose.tools import (
        assert_equal,
        assert_raises
    )

    assert_raises(ValueError, bump_version, '1.2.3', -4)
    assert_raises(ValueError, bump_version, '1.2.3', -3)
    assert_raises(ValueError, bump_version, '1.2.3', -2)
    assert_raises(ValueError, bump_version, '1.2.3', -1)
    assert_equal(bump_version('1.2.3', -3), '1.3.0')
    assert_equal(bump_version('1.2.3', -2), '2.0.0')
    assert_equal(bump_version('1.2.3', -1), '2.0.0')

# Generated at 2022-06-29 18:09:56.303180
# Unit test for function bump_version
def test_bump_version():
    # Test bump_version()
    # noinspection PyUnusedLocal
    def _run_tests(
            bump_version_type: int,
            bump_version_pre: Optional[str],
            bump_version_pos: int,
            versions: List[str],
            expected: List[str]
    ) -> None:
        assert len(versions) == len(expected)
        for pos, version in enumerate(versions):
            out = bump_version(
                version,
                bump_version_pos,
                bump_version_pre
            )
            assert out == expected[pos]


# Generated at 2022-06-29 18:10:06.869190
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:19.270343
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'

    assert bump_version('0.0.0', 3) == '0.0.0a0'
    assert bump_version('0.0.0', 4) == '0.0.0b0'
    assert bump_version('0.0.0', 5) == '0.0.0a0'

    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', -2) == '0.1.0'

# Generated at 2022-06-29 18:10:32.223883
# Unit test for function bump_version
def test_bump_version():
    import inspect
    function_name = inspect.stack()[0][3]
    print(function_name)

    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'

    assert bump_version('0.1.2') == '0.2.0'
    assert bump_version('0.2.0') == '0.3.0'
    assert bump_version('1.2.0') == '1.3.0'
    assert bump_version('1.2.3') == '1.3.0'

    assert bump_version('0.1.2', position=1) == '0.2.0'

# Generated at 2022-06-29 18:10:41.563095
# Unit test for function bump_version
def test_bump_version():
    print('Function bump_version')
    report = []
    report.append('Running unit test, function bump_version')
    print('Running unit test, function bump_version')

    # Test helper function, _build_version_bump_type
    report.append('Running _build_version_bump_type test(s)')
    print('Running _build_version_bump_type test(s)')
    def _test_build_version_bump_type(
            position: int,
            pre_release: Optional[str]
    ) -> None:
        version = '%s.%s.%s' % (position, 0, 0)
        position = _build_version_bump_position(position)

# Generated at 2022-06-29 18:10:58.540214
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('3.0.0') == '4.0.0'

    assert bump_version('0.1.0') == '1.1.0'
    assert bump_version('1.1.0') == '2.1.0'
    assert bump_version('2.1.0') == '3.1.0'
    assert bump_version('3.1.0') == '4.1.0'

    assert bump_version('0.1.1') == '1.1.1'

# Generated at 2022-06-29 18:11:01.088934
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.5.0') == '3.5.1'



# Generated at 2022-06-29 18:11:09.827326
# Unit test for function bump_version
def test_bump_version():
    #PyUnit uses a strange function naming convention
    def assert_equal(x, y):
        assert x == y
    def assert_equal_true(x):
        assert x == True
    def assert_is_none(x):
        assert x is None
    def assert_is_not_none(x):
        assert x is not None
    def assert_raises(x, y):
        assert x == y
    assert_equal(bump_version('1.0.0'), '2.0.0')
    assert_equal(bump_version('1.1.0'), '1.2.0')
    assert_equal(bump_version('1.1.5'), '1.1.6')
    assert_equal(bump_version('1.1.5'), '1.1.6')
    assert_

# Generated at 2022-06-29 18:11:21.462863
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:34.896826
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:45.978682
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0'
    assert bump_version('1.0.0', 1, 'b') == '1.1.0'
    assert bump_version('1.0.0', 1, 'alpha') == '1.1.0'
    assert bump_version('1.0.0', 1, 'beta') == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'

# Generated at 2022-06-29 18:11:53.481214
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3', 1, 'A') == '1.3.0'
    assert bump_version('1.2.3', -2, 'A') == '1.3.0'
    assert bump_version('1.2.3', 1, 'B') == '1.3.0'
    assert bump_

# Generated at 2022-06-29 18:12:00.140301
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:13.016534
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:23.776373
# Unit test for function bump_version
def test_bump_version():
    def verify_result(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        actual = bump_version(version, position, pre_release)
        assert actual == expected, (
            "bump_version(%r, %r, %r) returned (%r), but "
            "(%r) was expected." % (
                version, position, pre_release,
                actual, expected
            )
        )


# Generated at 2022-06-29 18:12:44.442817
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:56.094876
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, '') == '2.0.0'
    assert bump_version('1.0.0', 0, 'a') == '1.0.0'
    assert bump_version('1.0.0', 0, 'alpha') == '1.0.0'
    assert bump_version('1.0.0', 0, 'b') == '1.0.0'
    assert bump_version('1.0.0', 0, 'beta') == '1.0.0'

    assert bump_version('1.0.0', position=1) == '1.1.0'
   

# Generated at 2022-06-29 18:13:03.754859
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', -1) == '0.1.0'
    assert bump_version('0.0.1', -2) == '1.0.0'
    assert bump_version('0.0.1', -3) == '1.0.0'
    assert bump_version('0.0.1', None, 'a') == '0.0.1a0'

# Generated at 2022-06-29 18:13:16.051224
# Unit test for function bump_version
def test_bump_version():
    # Version: 1.0.0
    print('Running test "test_bump_version_1"')
    version = '1.0.0'
    position = 0
    pre_release = None
    results = '2.0.0'
    assert bump_version(version, position, pre_release) == results
    # Version: 1.0.0
    print('Running test "test_bump_version_2"')
    version = '1.0.0'
    position = 0
    pre_release = 'alpha'
    results = '1.0.1a0'
    assert bump_version(version, position, pre_release) == results
    # Version: 1.0.0
    print('Running test "test_bump_version_3"')
    version = '1.0.0'
   

# Generated at 2022-06-29 18:13:25.762993
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', 2) == '0.2.2'
    assert bump_version('0.2.1', 0) == '1.0.0'
    assert bump_version('0.2.1', 1) == '0.3.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.2.1', position=-2) == '0.2.2'
    assert bump_version('0.2.1', position=-1) == '0.3.0'
    assert bump_version('0.2.1', position=-3) == '1.0.0'


# Generated at 2022-06-29 18:13:37.278466
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1', 0) == '2'
    assert bump_version('1', 1) == '1.1'
    assert bump_version('1', 1, 'a') == '1.1a0'
    assert bump_version('1', 1, 'b') == '1.1b0'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0', 1, 'b') == '1.1b0'
    assert bump_version('1.1', 1) == '1.2'
    assert bump_version('1.1', 1, 'a') == '1.2a0'

# Generated at 2022-06-29 18:13:46.923089
# Unit test for function bump_version
def test_bump_version():
    from .test_utils import assert_func_str_str
    f = bump_version
    func_name = 'bump_version'
    assert_func_str_str(f, func_name)

    # basic

# Generated at 2022-06-29 18:14:00.199918
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.3', 2, 'a') == '1.2.4a0'

# Generated at 2022-06-29 18:14:10.427678
# Unit test for function bump_version
def test_bump_version():
    print('Testing function bump_version...', end='')

    # Test against null input
    try:
        bump_version(None)
    except ValueError:
        pass
    else:
        # This should have raised an exception.
        print('\nError: bump_version(None) did not raise the expected '
              'exception.')
        return

    # Test against simple strings
    try:
        bump_version('goober')
    except ValueError:
        pass
    else:
        # This should have raised an exception.
        print('\nError: bump_version(\'goober\') did not raise the expected '
              'exception.')
        return

    # Common test vars
    version = '0.1.2'
    result_alpha = '0.1.2a0'
    result_

# Generated at 2022-06-29 18:14:17.681095
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.1.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('2.0.0', 1) == '2.1.0'
    assert bump_version('2.0.0', 2) == '2.0.1'
    assert bump_version('2.0.0', 3) == '2.0.1'
    assert bump_version('2.0.0', -1) == '2.0.1'

# Generated at 2022-06-29 18:14:37.510396
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3a0') == '1.2.4a0'
    assert bump_version('1.2.3b0') == '1.2.4b0'
    assert bump_version('1.2.3a1') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=1)

# Generated at 2022-06-29 18:14:47.064653
# Unit test for function bump_version
def test_bump_version():
    print('Testing function bump_version')
    print('Testing version: 1.2a2')
    print('    Version bumped by 1 position:      %s' %
          bump_version('1.2a2', 1))
    print('    Version bumped by 2 position:      %s' %
          bump_version('1.2a2', 2))
    print('    Version bumped by 3 position:      %s' %
          bump_version('1.2a2', 3))
    print('    Version bumped by -1 position:     %s' %
          bump_version('1.2a2', -1))
    print('    Version bumped by -2 position:     %s' %
          bump_version('1.2a2', -2))

# Generated at 2022-06-29 18:14:55.062552
# Unit test for function bump_version
def test_bump_version():
    version_number_list = [
        '1.5.5',
        '1.0.0',
        '3.0.0-alpha.1',
        '3.0.0-alpha.0',
        '3.0.0-beta.1',
        '3.0.0-beta.0',
        '3.1.0-alpha.1',
        '3.1.0-beta.0',
        '3.0.1-alpha.1',
        '3.0.1-beta.0',
        '3.0.2',
    ]

# Generated at 2022-06-29 18:15:06.224925
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:16.986896
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """
    Unit test for function bump_version
    """

# Generated at 2022-06-29 18:15:28.821013
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:39.936967
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, 'a') == '2.0.0'
    assert bump_version('1.0.0', 0, 'b') == '2.0.0'
    assert bump_version('1.0.0', 0, 'c') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'

# Generated at 2022-06-29 18:15:50.346186
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', pre_release='a') == '0.1.0a0'
    assert bump_version('0.0.0', pre_release='a', position=1) == '0.1.0a0'
    assert bump_version('0.0.0', pre_release='b', position=1) == '0.1.0b0'
    assert bump_version('0.0.0', pre_release='a', position=2) == '0.0.1a0'
    assert bump_version('0.0.0', pre_release='b', position=2) == '0.0.1b0'

# Generated at 2022-06-29 18:15:58.406173
# Unit test for function bump_version

# Generated at 2022-06-29 18:16:09.318717
# Unit test for function bump_version
def test_bump_version():
    print("Testing function bump_version")
    assert bump_version("0.0.0") == "1.0.0", "bump_version(\"0.0.0\") should be \"1.0.0\""
    assert bump_version("0.0.1") == "1.0.0", "bump_version(\"0.0.1\") should be \"1.0.0\""
    assert bump_version("0.1.0") == "1.0.0", "bump_version(\"0.1.0\") should be \"1.0.0\""
    assert bump_version("1.0.0") == "2.0.0", "bump_version(\"1.0.0\") should be \"2.0.0\""