

# Generated at 2022-06-29 18:06:49.055087
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1') == '2')
    assert(bump_version('1.1') == '1.2')
    assert(bump_version('1.1.1') == '1.1.2')
    assert(bump_version('0.0.0') == '1.0.0')
    assert(bump_version('1.1.1', 0) == '2.0.0')
    assert(bump_version('1.1.1', 1) == '1.2.0')
    assert(bump_version('1.1.1', 2) == '1.1.2')
    assert(bump_version('1.1.1', -1) == '1.1.2')

# Generated at 2022-06-29 18:06:59.000454
# Unit test for function bump_version
def test_bump_version():
    # This is some test code for bump_version(...)
    for version in ('0.3.3', '0.3.1b2', '0.3.1a1', '0.3.0'):
        print('{} -> {}'.format(version, bump_version(version)))
    # Specify a version number and tell bump-version where to bump the
    # version number
    print('0.3.0 -> {}'.format(bump_version('0.3.0', position=-1, pre_release='a')))
    print('0.3.0 -> {}'.format(bump_version('0.3.0', position=-1, pre_release='b')))
    print('0.3.0 -> {}'.format(bump_version('0.3.0', position=-2)))

# Generated at 2022-06-29 18:07:10.455289
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0', 2, None) == '1.2.1'
    assert bump_version('0.1.1', 2, None) == '0.1.2'
    assert bump_version('1.2.3', 2, None) == '1.2.4'
    assert bump_version('1.2.3', 2, 'a') == '1.2.4a0'
    assert bump_version('1.2.3', 2, 'alpha') == '1.2.4a0'
    assert bump_version('1.2.3', 2, 'b') == '1.2.4b0'
    assert bump_version('1.2.3', 2, 'beta') == '1.2.4b0'
    assert bump_version('1.2.3')

# Generated at 2022-06-29 18:07:21.774799
# Unit test for function bump_version
def test_bump_version():
    print('Testing version bumping functionality')

# Generated at 2022-06-29 18:07:24.497615
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    version = '0.1.0'
    expected = '0.1.1'
    # Act
    actual = bump_version(version)
    # Assert
    assert expected == actual

# Generated at 2022-06-29 18:07:35.752546
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the function 'bump_version'."""
    assert bump_version('1.6.0') == '1.6.1'
    assert bump_version('1.6.0', 0) == '2.0.0'
    assert bump_version('1.6.0', 1) == '1.7.0'
    assert bump_version('1.6.0', 2) == '1.6.1'
    assert bump_version('1.6.0', 3) == '1.6.0'
    assert bump_version('1.6.0', 4) == '1.6.0'
    assert bump_version('1.6.0', -5) == '1.7.0'
    assert bump_version('1.6.0', -4) == '1.6.0'


# Generated at 2022-06-29 18:07:47.528878
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:55.784050
# Unit test for function bump_version
def test_bump_version():
    versions = [
        '1.0.0',
        '5.5.5.5',
        '0.0.0',
        '1.2.3a0',
        '1.2.3a1',
        '1.2.3b0',
        '1.2.3b1',
    ]
    expecteds = [
        '1.1.0',
        '5.5.5.6',
        '1.0.0',
        '1.2.4',
        '1.2.3a2',
        '1.2.3a0',
        '1.2.3b2',
    ]
    for version, expected in zip(versions, expecteds):
        result = bump_version(version, position=2)
        assert result == expected

# Generated at 2022-06-29 18:08:09.052536
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:19.152754
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0a0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.0.1a0') == '1.0.0'
    assert bump_version('0.1.1') == '1.0.0'
    assert bump_version('0.1.1a0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0a0') == '2.0.0'
    assert bump_version('1.0.1') == '2.0.0'

# Generated at 2022-06-29 18:08:49.911277
# Unit test for function bump_version
def test_bump_version():
    import sys
    versions: List[str] = [
        '0.1.0', '1.2.0', '1.2.3', '0.1.a0', '0.1.b0', '1.0.a1', '1.0.b1',
        '1.2.a3', '1.2.3.a0', '1.2.3.b1', '1.2.a1.b2', '1.2.a1.b2.c3'
    ]

    for version in versions:
        for position in (0, 1, 2, -1, -2, -3):
            for pre_release in (None, 'a', 'alpha', 'b', 'beta'):
                output = bump_version(version, position, pre_release)

# Generated at 2022-06-29 18:08:57.619179
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', position=1) == '0.3.0'
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', position=1) == '0.3.1'
    assert bump_version('0.2.0', position=0) == '1.0.0'
    assert bump_version('1.2.0', position=0) == '2.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.3'

# Generated at 2022-06-29 18:09:09.360871
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', position=2, pre_release=None), '1.2.4'
    assert bump_version('1.2.3', position=0, pre_release=None), '2.0.0'
    assert bump_version('1.2.3', position=0, pre_release='a'), '1.2.3a0'
    assert bump_version('1.2.3a0', position=0, pre_release='a'), '1.3.0a0'
    assert bump_version('1.2.3a1', position=0, pre_release='a'), '1.3.0a0'
    assert bump_version('1.2.3b0', position=0, pre_release='a'), '1.3.0a0'
    assert bump_version

# Generated at 2022-06-29 18:09:20.699548
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for function bump_version"""
    assert bump_version('0.4') == '0.5'
    assert bump_version('0.4.a.2') == '0.4.a.3'
    assert bump_version('0.4.b.2') == '0.4.b.3'
    assert bump_version('0.4.3') == '0.5'
    assert bump_version('0.4.3.a.2') == '0.4.4'
    assert bump_version('0.4.3.b.2') == '0.4.4'
    assert bump_version('1.0.0') == '1.1'
    assert bump_version('1.0.0.a.2') == '1.0.1'


# Generated at 2022-06-29 18:09:33.476730
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    *New in version 0.3*
    """

    # Test: bump_version('1.2.3') == '1.2.4'
    version = bump_version('1.2.3')
    assert version == '1.2.4'

    # Test: bump_version('1.2.3', 0) == '2.0.0'
    version = bump_version('1.2.3', 0)
    assert version == '2.0.0'

    # Test: bump_version('1.2.3', 1) == '1.3.0'
    version = bump_version('1.2.3', 1)
    assert version == '1.3.0'

    # Test: bump_version('1.2.0', 1) == '1.3

# Generated at 2022-06-29 18:09:44.261378
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version. """

    from pytest import raises

    # Test errors

    with raises(ValueError):
        bump_version(version='1', position=4, pre_release='')

    with raises(ValueError):
        bump_version(version='1', position=1, pre_release='c')

    with raises(ValueError):
        bump_version(version='1', position=0, pre_release='a')

    with raises(ValueError):
        bump_version(version='1', position=-1, pre_release='alpha')

    with raises(ValueError):
        bump_version(version='1', position=-3, pre_release='beta')

    # Test a patch bump with a pre-release bump

    version = '1.2.3'
    position = 2

# Generated at 2022-06-29 18:09:56.983462
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=-1) == '0.0.1'
    assert bump_version('0.0.0', position=-2) == '0.1.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'

    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version

# Generated at 2022-06-29 18:10:07.446890
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=R0914
    # (Too many local variables.)
    def run_bump_version_test(ver: str) -> None:
        """Run bump_version() and test each version."""
        ver_info = _build_version_info(ver)

# Generated at 2022-06-29 18:10:12.756175
# Unit test for function bump_version
def test_bump_version():
    """Unit test to check the function bump_version.

    Args:
        version: The version number to be bumped.
        position (int, optional): The position (starting with zero) of the
            version number component to be increased.  Defaults to: ``2``
        pre_release (str, Optional): A value of ``a`` or ``alpha`` will
            create or increase an alpha version number.  A value of ``b`` or
            ``beta`` will create or increase a beta version number.

    Returns:
        void

    """

    from sys import stdout

    print("\nRunning unit test for function bump_version")

# Generated at 2022-06-29 18:10:22.539222
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.4.0', pre_release='b') == '0.4.0b0'
    assert bump_version('0.4.0', pre_release='b') == '0.4.0b0'
    assert bump_version('0.4.0', pre_release='beta') == '0.4.0b0'
    assert bump_version('0.4.0', pre_release='alpha') == '0.4.0a0'
    assert bump_version('0.4.0', pre_release='Alpha') == '0.4.0a0'

# Generated at 2022-06-29 18:10:32.699836
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3a5') == '1.2.3a6'
    assert bump_version('1.2.3b5') == '1.2.3b6'
    assert bump_version('1.2.3a5', position=2) == '1.2.4'
    assert bump_version('1.2.3a5', position=1) == '1.3.0'
    assert bump_version('1.2.3a5', position=1, pre_release='a') == '1.3.0a0'
    assert bump_version('1.2.3a5', position=1, pre_release='b') == '1.3.0b0'
    assert bump_

# Generated at 2022-06-29 18:10:38.280900
# Unit test for function bump_version
def test_bump_version():
    # Test a major version bump
    version = bump_version(
        version='0.1.0',
        position=0,
        pre_release=None
    )
    assert version == '1.0.0'

    # Test a minor version bump, without a pre_release
    version = bump_version(
        version='0.1.0',
        position=1,
        pre_release=None
    )
    assert version == '0.2.0'

    # Test a patch version bump, without a pre_release
    version = bump_version(
        version='0.1.0',
        position=2,
        pre_release=None
    )
    assert version == '0.1.1'

    # Test a minor version bump, with an alpha pre_release

# Generated at 2022-06-29 18:10:44.660683
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0a0') == '0.0.1a0'
    assert bump_version('0.0.1a1') == '0.0.2a0'
    assert bump_version('0.1.0a0') == '0.1.1a0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('10.0.0') == '10.0.1'
    assert bump_version('0.0.1a1') == '0.0.2a0'
    assert bump_version('0.0.0b1') == '0.0.1b0'

# Generated at 2022-06-29 18:10:56.798758
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the methods in 'bump_version'."""
    # Given, When, Then
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('2.0.0') == '2.0.1'
    assert bump_version('1.0.0', position=1)

# Generated at 2022-06-29 18:11:08.103113
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1', position=0) == '1.0.0'
    assert bump_version('0.1.1', position=1) == '0.2.0'
    assert bump_version('0.1.1', position=-1) == '0.1.2'
    assert bump_version('0.1.1', position=-2) == '0.2.0'
    assert bump_version('0.1.1', position=-3) == '1.0.0'
    assert bump_version('0.1.1', pre_release='alpha') == '0.2.0a0'

# Generated at 2022-06-29 18:11:21.102001
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    import pytest

    # Test invalid version
    invalid_versions = ['1..10', '', 'a', '1.0.1.1']
    for invalid_version in invalid_versions:
        with pytest.raises(ValueError):
            bump_version(invalid_version)

    # Test invalid position
    invalid_positions = [-4, -3, -2, -1, 3, 4]
    for invalid_position in invalid_positions:
        with pytest.raises(ValueError):
            bump_version('1.2.3', invalid_position)

    # Test invalid prerelease
    invalid_prereleases = ['', 'z', '-b', 'b-', 'a b', 'a1', '1b']

# Generated at 2022-06-29 18:11:34.520712
# Unit test for function bump_version
def test_bump_version():
    value = bump_version('2.0.0')
    assert value == '2.0.1'
    value = bump_version('2.0.0', 0)
    assert value == '3.0.0'
    value = bump_version('2.0.0', 1)
    assert value == '2.1.0'
    value = bump_version('2.0.0', pre_release='a')
    assert value == '2.1.0a0'
    value = bump_version('2.0.0', pre_release='b')
    assert value == '2.1.0b0'
    value = bump_version('2.0.0', pre_release='alpha')
    assert value == '2.1.0a0'

# Generated at 2022-06-29 18:11:45.612847
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    from datetime import datetime
    from pathlib import Path

    def write_to_file(path: Path, content: str):
        """
        Write the content to the given file path
        """
        with path.open('w') as fil:
            fil.write(content)

    def assert_version(version: str, expected: str):
        """
        Assert that ``version`` is equal to ``expected``
        """
        out = bump_version(version)
        actual = '%s - %s' % (version, out)
        assert out == expected, actual

    ###################################################################
    # Test the version_bump_type() function.
    ###################################################################

    # noinspection PyUnusedLocal
    expected_str_type: str
   

# Generated at 2022-06-29 18:11:53.296798
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:59.254446
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('0.0.0')
    assert version == '0.0.1'
    version = bump_version('0.0.0', -1)
    assert version == '0.1.0'
    version = bump_version('0.0.0', -2)
    assert version == '1.0.0'


# Generated at 2022-06-29 18:12:18.649203
# Unit test for function bump_version
def test_bump_version():
    """ Tests the `bump_version()` function. """
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

# Generated at 2022-06-29 18:12:27.286670
# Unit test for function bump_version
def test_bump_version():
    # Unit test for bump_version()
    assert bump_version('1.8.0.dev1', 2, 'a') == '1.8.1a0'
    assert bump_version('1.8.0.dev1', 2, 'b') == '1.8.1b0'
    assert bump_version('1.8.0.a1', 2, 'a') == '1.8.0a2'
    assert bump_version('1.8.0.a1', 2, 'b') == '1.8.1b0'
    assert bump_version('1.8.0.b2', 2, 'a') == '1.9.0a0'
    assert bump_version('1.8.0.b2', 2, 'b') == '1.8.0b3'
    assert bump

# Generated at 2022-06-29 18:12:39.542348
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'

    # Make sure that pre-release bumps work.

# Generated at 2022-06-29 18:12:50.550201
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # Setup test cases

# Generated at 2022-06-29 18:13:01.330765
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('0.1.0')
    assert version == '0.1.1'
    version = bump_version('0.1.0-a0')
    assert version == '0.1.1'
    version = bump_version('0.1.0', 1)
    assert version == '0.1.0'
    version = bump_version('0.1.0', 1, 'a')
    assert version == '0.2.0a0'
    version = bump_version('0.1.0', 1, 'alpha')
    assert version == '0.2.0a0'
    version = bump_version('0.1.0', 1, 'b')
    assert version == '0.2.0b0'

# Generated at 2022-06-29 18:13:13.829156
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:22.521835
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version."""
    from .utilities import assert_exception

    def test_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_version: str
    ) -> None:
        """Test the bumping of a given version number.

        Args:
            version (str): The version number to be bumped.
            position (int): The position (starting with zero) of the
                version number component to be increased.
            pre_release (str, optional): A value of ``a`` or ``alpha`` will
                create or increase an alpha version number.  A value of ``b``
                or ``beta`` will create or increase a beta version number.
            expected_version (str): The expected version number after the
                bumping.

        """
        hold: str

# Generated at 2022-06-29 18:13:34.637505
# Unit test for function bump_version
def test_bump_version():
    """Test 'bump_version'."""

    print('\nbump_version')
    pos_max = 2
    version = '0.0.0'
    position = 0
    while position <= pos_max:
        print('\nposition: %s' % (position,))
        print('version: %s' % (version,))
        new_ = bump_version(version, position, None)
        print('None: %s' % (new_,))
        new_ = bump_version(new_, position, 'a')
        print('alpha: %s' % (new_,))
        new_ = bump_version(new_, position, 'b')
        print('beta: %s' % (new_,))
        version = new_
        position += 1

# Generated at 2022-06-29 18:13:45.268850
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

# Generated at 2022-06-29 18:13:58.397422
# Unit test for function bump_version
def test_bump_version():
    """
    >>> test_bump_version()

    """

    # this is a test to make sure that we don't raise an error on None.
    try:
        bump_version('0.0.0')
    except ValueError as e:
        print(e)
        raise Exception('Unexpected ValueError.')

    # this is a test to make sure that we don't raise an error on None.
    try:
        bump_version('0.0.0', pre_release='a')
    except ValueError as e:
        print(e)
        raise Exception('Unexpected ValueError.')

    # this is a test to make sure that we don't raise an error on None.
    try:
        bump_version(None, pre_release='a')
    except ValueError as e:
        print(e)
        raise Exception

# Generated at 2022-06-29 18:14:12.136889
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    :return:
        True if the function passed all the tests, otherwise False.

    :rtype:
        :obj:`bool`

    """
    # Test a major bump
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'

# Generated at 2022-06-29 18:14:17.046989
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    ver_num = bump_version('1.2.0')
    assert ver_num == '1.2.1'

    ver_num = bump_version('1.2.0', 2, 'a')
    assert ver_num == '1.2.0a0'

    ver_num = bump_version('1.2.0', 2, 'b')
    assert ver_num == '1.2.0b0'

# Generated at 2022-06-29 18:14:28.583005
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('0.8.0') == '0.8.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.9') == '1.2.10'

    assert bump_version('0.8.0', 1) == '0.9.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.1', 1) == '1.3.0'
    assert bump_version('1.2.9', 1) == '1.3.0'

    assert bump_version('0.8.0', 0) == '1.0.0'


# Generated at 2022-06-29 18:14:40.876774
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0a0', pre_release='a') == '1.0.0a1'
    assert bump_version('1.0.0a0', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0a0', position=1, pre_release='b') == '1.0.0b0'

# Generated at 2022-06-29 18:14:48.752272
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:51.854278
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    version: str = '1.0.0'
    new_version = bump_version(version)
    assert new_version, ''

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:15:03.993420
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', 0) == '1.0.0'
    assert bump_version('0.2.1', 1) == '0.3.0'
    assert bump_version('0.2.1', 1, 'a') == '0.3.0a0'
    assert bump_version('0.2.1', 1, 'A') == '0.3.0a0'
    assert bump_version('0.2.1', 1, 'Alpha') == '0.3.0a0'
    assert bump_version('0.2.1', 1, 'b') == '0.3.0b0'

# Generated at 2022-06-29 18:15:11.027906
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, 0) == '2.0.0'
    assert bump_version(ver, 1) == '1.3.0'
    assert bump_version(ver, 2) == '1.2.4'
    assert bump_version(ver, -1) == '1.2.4'
    assert bump_version(ver, -2) == '1.3.0'
    assert bump_version(ver, -3) == '2.0.0'
    assert bump_version(ver, 1, 'a') == '1.3.0a0'
    assert bump_version(ver, 2, 'a') == '1.2.4a0'

# Generated at 2022-06-29 18:15:23.949007
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.0") == '1.2.1'
    assert bump_version("1.2.0", 2) == '1.2.1'
    assert bump_version("1.2.0", "patch") == '1.2.1'
    assert bump_version("1.2.0", pre_release="a") == '1.3.0a0'
    assert bump_version("1.2.0a0", 0) == '2.0.0'
    assert bump_version("1.2.0a0", 1) == '1.3.0'
    assert bump_version("1.2.0a0", 2) == '1.3.0a0'
    assert bump_version("1.2.0b0", 0) == '2.0.0'


# Generated at 2022-06-29 18:15:29.140359
# Unit test for function bump_version
def test_bump_version():
    # Test: basic units
    for verstr in (
            '0.0.1',
            '0.1',
            '1.2.3',
            '1.2',
            '1',
            '0.1.2.3',
            '0.1.2',
            '0.1',
            '0',
            '0.0.0.0',
            '0.0.0',
            '0.0',
    ):
        assert bump_version(verstr, 0) == '1.0.0'
        assert bump_version(verstr, 1) == '0.1.0'
        assert bump_version(verstr, 2) == '0.0.1'
        assert bump_version(verstr, -1) == '0.0.1'
        assert bump_version

# Generated at 2022-06-29 18:15:47.813789
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:57.053900
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0121,C0116
    ''' test the bump_version function '''
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'alpha') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0a0', 2, 'alpha') == '1.0.1a0'

# Generated at 2022-06-29 18:16:08.195173
# Unit test for function bump_version

# Generated at 2022-06-29 18:16:16.842899
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0alpha'
    assert bump_version('1.2.3', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.3a0', 1, 'a') == '1.3.0a1'
    assert bump_version('1.2.3a1', 1, 'a') == '1.3.0a2'