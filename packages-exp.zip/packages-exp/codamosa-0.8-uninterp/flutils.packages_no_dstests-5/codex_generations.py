

# Generated at 2022-06-29 18:06:50.938821
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from english_dict import english_dict
    from random import choice
    from string import digits
    from sys import version_info

    VER_STR_REGEX: str = r'^(\d+)\.(\d+)\.(\d+)(.*)$'
    VER_DIGIT_REGEX: str = r'%s(\d+)' % digits
    last_version = None
    last_version_digit = None
    last_version_letter = None


# Generated at 2022-06-29 18:07:00.976609
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from pyapp_ext.testing.assertions import assert_raises
    from pyapp_ext.versioning.version_constants import (  # noqa
        VALID_VERSION_REGEXP,
        VALID_VERSION_REGEXP_STRICT,
    )
    from test_versioning import (
        _build_random_valid_version,
        _build_random_valid_version_strict,
    )

    # Error checking
    assert_raises(
        ValueError,
        bump_version,
        '1.2',
        position=5,
    )
    assert_raises(
        ValueError,
        bump_version,
        '1.2',
        position=3,
    )

    #
    # Major version
    #

# Generated at 2022-06-29 18:07:12.563359
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', position=0, pre_release='a') == '2.0.0a0'
    assert bump_version('1.0.0a0') == '1.0.0a1'
    assert bump_version('1.0.0a0', position=0, pre_release='a') == '2.0.0a0'

# Generated at 2022-06-29 18:07:23.483083
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('2.0.0', '0') == '3.0.0'
    assert bump_version('2.0.0.0', 0) == '3.0.0.0'
    assert bump_version('2.0.0.0', '0') == '3.0.0.0'
    assert bump_version('2.0.0', 'major') == '3.0.0'
    assert bump_version('2.0.0.0', 'major') == '3.0.0.0'
    assert bump_version('2.0.0', 1) == '2.1.0'

# Generated at 2022-06-29 18:07:29.782515
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('0.0.0')
    version_1 = bump_version('0.0.0-dev')
    assert version == '0.0.1'
    assert version_1 == '0.1'
    version_2 = bump_version('0.0.1-dev')
    version_3 = bump_version('0.0.0-a2')
    assert version_2 == '0.1'
    assert version_3 == '0.0.0-a3'


# EOF

# Generated at 2022-06-29 18:07:42.138383
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0613
    # Enable test cases below by deleting "return."
    # return
    def verify(version: str, position: int, prerelease: Optional[str],
               expected: str):
        _ = bump_version(version, position, prerelease)
        assert _ == expected

    yield verify, '0.0.0', 0, None, '1.0.0'
    yield verify, '1.2.3', 0, None, '2.0.0'
    yield verify, '10.20.30', 0, None, '11.0.0'
    yield verify, '0.0.0', 1, None, '0.1.0'
    yield verify, '1.2.3', 1, None, '1.3.0'

# Generated at 2022-06-29 18:07:52.422258
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:03.778928
# Unit test for function bump_version
def test_bump_version():
    """Unit-test for function bump_version."""
    from .test import (
        AssertEqual,
        AssertRaises,
        AssertType,
        AssertVersionBump,
    )

    AssertType(actual=bump_version, expected_arg_types=[str])
    AssertType(
        actual=bump_version,
        expected_kwarg_types={'position': int, 'pre_release': Optional[str]}
    )
    AssertType(actual=bump_version, expected_return_type=str)


# Generated at 2022-06-29 18:08:12.895958
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:22.450947
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:50.359293
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'

# Generated at 2022-06-29 18:09:02.634677
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    ver = '1.2.0'
    assert bump_version(ver) == '1.2.1'         # Patch
    assert bump_version(ver) == '1.2.1'         # Patch
    assert bump_version(ver, 0) == '2.0.0'      # Major
    assert bump_version(ver, 1) == '1.3.0'      # Minor
    assert bump_version(ver, 1, 'a') == '1.3a0' # Minor Alpha
    assert bump_version(ver, 1, 'b') == '1.3b0' # Minor Beta
    assert bump_version(ver, 1, 'b') == '1.3b0' # Minor Beta

# Generated at 2022-06-29 18:09:06.614592
# Unit test for function bump_version
def test_bump_version():
    result = bump_version("1.2.2", 2, "Beta")
    assert result == "1.2.2b0"
    result = bump_version("1.2.2", 1, "Beta")
    assert result == "1.3b0"
    result = bump_version("1.2.1", 1, "Beta")
    assert result == "1.2b0"
    result = bump_version("1.2.0", 1, "Beta")
    assert result == "1.2b0"
    result = bump_version("1.1.0", 1, "Beta")
    assert result == "1.2b0"
    result = bump_version("1.0.0", 1, "Beta")
    assert result == "1.1b0"

# Generated at 2022-06-29 18:09:19.184002
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.2.2', 1) == '0.3.0'
    assert bump_version('0.3.2', 0) == '1.0.0'
    assert bump_version('0.3.2', 0, 'a') == '0.4.0'
    assert bump_version('0.4.2', 0, 'b') == '0.4.0'
    assert bump_version('0.4.2', 1, 'a') == '0.4.0'
    assert bump_version('0.5.2', 1) == '0.5.0'
    assert bump_version('0.6.2', 1, 'a') == '0.6.0'
    assert bump_version

# Generated at 2022-06-29 18:09:32.610042
# Unit test for function bump_version
def test_bump_version():
    # Test for bump_version()
    version = '0.2.0'
    #if bump_version(version, 0, 'a') != '1.0.0':
    #    raise Exception("bump_version('0.2.0', 0, 'a') != '1.0.0'")
    if bump_version(version, 0, 'a') != '1.0.0':
        raise Exception("bump_version('0.2.0', 0, 'a') != '1.0.0'")
    if bump_version(version, 0, 'b') != '1.0.0':
        raise Exception("bump_version('0.2.0', 0, 'b') != '1.0.0'")

# Generated at 2022-06-29 18:09:43.552948
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.3.4') == '2.3.5'
    assert bump_version('2.3.4', 1) == '2.4.0'
    assert bump_version('2.3.4', 2) == '3.0.0'
    assert bump_version('2.3.4', 1, 'b') == '2.4.0b0'
    assert bump_version('2.3.4', 1, 'beta') == '2.4.0b0'
    assert bump_version('2.3.4', 1, 'a') == '2.4.0a0'
    assert bump_version('2.3.4', 1, 'alpha') == '2.4.0a0'

# Generated at 2022-06-29 18:09:56.213792
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', 1) == '0.3.0'
    assert bump_version('0.2.1', 0) == '1.0.0'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 0, 'a') == '2.0.0'
    assert bump_version('1.2.0', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.0', 1, 'b') == '1.3.0b0'

# Generated at 2022-06-29 18:09:59.920850
# Unit test for function bump_version
def test_bump_version():
    from zope.testing import renormalizing

    checker = renormalizing.RENormalizing([
        (re.compile(r'^(.*)$'), r'\1'),
    ])
    return doctest.DocTestSuite(
        checker=checker,
        checker_kwargs={
            'optionflags': doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE,
        },
    )

# Generated at 2022-06-29 18:10:08.926292
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914

    # Test passing a invalid value as the 'version' argument
    def _test_bad_version(
            version: str,
    ) -> None:
        try:
            bump_version(version)
        except ValueError:
            pass
        else:
            raise AssertionError(
                "bump_version('%s') did not raise a ValueError." % version
            )

    _test_bad_version('')
    _test_bad_version(' ')
    _test_bad_version('1')
    _test_bad_version('1.2')
    _test_bad_version('1.2.3.4')

    # Test passing an invalid value as the 'position' argument

# Generated at 2022-06-29 18:10:21.804912
# Unit test for function bump_version
def test_bump_version():
    # This function is duplicated in meta.py and utils/version.py
    def _test_bump_version(
            in_: str,
            out: str,
            position: int,
            pre_release: Optional[str],
    ):
        assert bump_version(in_, position, pre_release) == out
    _test_bump_version('0.9.0', '0.9.1', 2, None)
    _test_bump_version('0.9.0', '0.9.1', -1, None)
    _test_bump_version('0.9.0', '0.9.1', 'patch', None)
    _test_bump_version('0.9.0', '0.9.1', 'patch', 'alpha')
    _test_bump_

# Generated at 2022-06-29 18:10:38.458497
# Unit test for function bump_version
def test_bump_version():
    # Arrange

    # Act
    actual = bump_version('1.2')
    # Assert
    assert actual == '1.3'

    # Arrange

    # Act
    actual = bump_version('1.2', 0)
    # Assert
    assert actual == '2.0'

    # Arrange

    # Act
    actual = bump_version('1.2', 1)
    # Assert
    assert actual == '1.3'

    # Arrange

    # Act
    actual = bump_version('1.2', 2)
    # Assert
    assert actual == '1.2.1'

    # Arrange

    # Act
    actual = bump_version('1.2a5', 1)
    # Assert
    assert actual == '1.2a6'

    # Arrange



# Generated at 2022-06-29 18:10:51.556163
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # Baseline Test
    assert(bump_version('0.1.2.3') == '0.1.3')
    # Major, Minor, Patch
    # Major Bump
    assert(bump_version('0.1.2', 0, None) == '1.0.0')
    assert(bump_version('0.1.2', -3, None) == '1.0.0')
    assert(bump_version('0.1.2', 'major', None) == '1.0.0')
    # Minor Bump
    assert(bump_version('0.1.2', 1, None) == '0.2.0')
    assert(bump_version('0.1.2', -2, None) == '0.2.0')

# Generated at 2022-06-29 18:11:03.769347
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:11.179173
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 2, 'b') == '1.2.1b0'
    assert bump_version('1.2.1a1', 2, 'a') == '1.2.1a2'
    assert bump_version('1.2.1a1', 2, 'b') == '1.2.1b0'
    assert bump_version('1.2.1b3', 2, 'b') == '1.2.1b4'

# Generated at 2022-06-29 18:11:12.058736
# Unit test for function bump_version
def test_bump_version():
    return True

# Generated at 2022-06-29 18:11:24.759800
# Unit test for function bump_version
def test_bump_version():
    print("Unit test for bump_version")
    print("bump_version('3.3.3', position=0) is", bump_version('3.3.3', position=0))
    print("bump_version('3.3.3', position=1) is", bump_version('3.3.3', position=1))
    print("bump_version('3.3.3', position=2) is", bump_version('3.3.3', position=2))
    print("bump_version('3.3.3', position=3) is", bump_version('3.3.3', position=3))
    print("bump_version('3.3.3', position=4) is", bump_version('3.3.3', position=4))

# Generated at 2022-06-29 18:11:37.264702
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0-alpha') == '1.0.1-alpha'
    assert bump_version('1.0.0-alpha.1') == '1.0.1-alpha.1'
    assert bump_version('1.0.0-beta') == '1.0.1-beta'
    assert bump_version('1.0.0-beta.1') == '1.0.1-beta.1'
    assert bump_version('1.0.0-beta.2') == '1.0.1-beta.2'
    assert bump_version('1.0.1') == '1.0.2'

# Generated at 2022-06-29 18:11:47.623220
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from . import utils

    file_path = utils.get_res_path(__file__, 'bump_version.txt')
    for line_no, line in enumerate(utils.lines_from_file(file_path)):
        line_no += 1
        if line.startswith('#'):
            continue
        vals = line.split(' ----> ')
        in_val = vals[0].strip()
        test_expect = vals[1].strip()
        try:
            test_out = bump_version(in_val)
        except Exception:
            raise AssertionError(
                "Line %s: Error while testing version number %r." % (
                    line_no,
                    in_val
                )
            ) from None

# Generated at 2022-06-29 18:11:59.259172
# Unit test for function bump_version
def test_bump_version():
    from version import version as version_
    version = version_()
    assert version == bump_version(version_())

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 5) == '1.2.3'
    assert bump_version('1.2.3', 1) == '2.0.0'
    assert bump_version('1.2.3', 1, 'alpha') == '2.3.0a0'
    assert bump_version('1.2.3', 1, 'beta') == '2.3.0b0'
    assert bump_version('1.2.3a2', 1) == '2.3.0a2'

# Generated at 2022-06-29 18:12:12.149501
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120,R0914,C0301
    def test_func(
            version,
            position,
            pre_release,
            expected
    ):
        # Raise error if they do not match
        assert bump_version(
            version, position, pre_release
        ) == expected

    test_func(
        '0.1.2', 0, None, '1.0.0'
    )
    test_func('0.2.0', 1, None, '0.3.0')
    test_func(
        '0.3.1', 2, None, '0.3.2'
    )
    test_func(
        '0.4.2', 2, 'a', '0.4.3a0'
    )

# Generated at 2022-06-29 18:12:25.087226
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0'
    assert bump_version('1.2.3', 0, 'a') == '1.3a0'
    assert bump_version('1.2.3', 0, 'b') == '1.3b0'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2.3', 1, 'a') == '1.3a0'
    assert bump_version('1.2.3', 1, 'b') == '1.3b0'
    assert bump_version('1.2.3', 2) == '1.2.4'

# Generated at 2022-06-29 18:12:36.449464
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.1.0', position=1) == '1.2.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('2.0.0', position=0) == '3.0.0'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.1', position=-1) == '1.0.2'

# Generated at 2022-06-29 18:12:48.234627
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function :func:`_build_version_info`.

    Tests the :func:`_build_version_info` function.
    """
    from unittest import TestCase
    from unittest.mock import patch

    from . import build_version_info

    # pylint: disable=W0212
    class ThisTest(TestCase):
        """
        Test for function :func:`_build_version_info`.

        Tests the :func:`_build_version_info` function.
        """

        @patch('signal_ocean.build_version_info')
        def test_method(self, build_func):
            """
            Test the :func:`bump_version` function.

            """

# Generated at 2022-06-29 18:12:59.462207
# Unit test for function bump_version
def test_bump_version():
    test_version = '0.0.1'
    test_result = bump_version(test_version)
    if test_result != '0.0.2':
        print('test_bump_version failed')
        exit(1)
    test_version = '0.0.1-alpha0'
    test_result = bump_version(test_version, pre_release='a')
    if test_result != '0.0.2':
        print('test_bump_version failed')
        exit(1)
    test_version = '0.0.1-alpha0'
    test_result = bump_version(test_version, pre_release='alpha')
    if test_result != '0.0.2':
        print('test_bump_version failed')
        exit(1)
    test_version

# Generated at 2022-06-29 18:13:12.282435
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=-3) == '2.0.0'
    assert bump_version('1.2.3', position=-2) == '1.3.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=0, pre_release='a') == '1.2.3'

# Generated at 2022-06-29 18:13:18.832437
# Unit test for function bump_version
def test_bump_version():
    ver_info = _build_version_info("0.0.0")
    print("ver_info: ", ver_info)
    part1 = next(_each_version_part(StrictVersion("0.0.0")))
    print("part1: ", part1)
    part2 = next(_each_version_part(StrictVersion("0.0.0a1")))
    print("part2: ", part2)
    pos = _build_version_bump_position(1)
    print("pos: ", pos)
    type = _build_version_bump_type(pos, None)
    print("type: ", type)
    type = _build_version_bump_type(pos, "alpha")
    print("type: ", type)

# Generated at 2022-06-29 18:13:31.435995
# Unit test for function bump_version
def test_bump_version():
    from sys import modules as _modules
    from types import ModuleType
    from os.path import splitext, basename
    from pprint import pprint
    from json import dumps as json_dumps
    from pathlib import Path

    from typesql import typesql
    from khayyam import VersionInfo

    # noinspection PyUnresolvedReferences
    this_module = ModuleType(splitext(basename(__file__))[0])
    this_module.__dict__.update(locals())
    _modules[__name__] = this_module

    _bump_version_package_name = 'bump_version'
    _bump_version_package_path = Path(__file__).resolve().parent

# Generated at 2022-06-29 18:13:42.204155
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E0401,C0103
    from unittest import TestCase
    from unittest.mock import patch

    import pkg_resources as pkg_resources_lib


# Generated at 2022-06-29 18:13:53.634977
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

# Generated at 2022-06-29 18:14:05.463474
# Unit test for function bump_version
def test_bump_version():
    """Test for func 'bump_version'."""

# Generated at 2022-06-29 18:14:16.024009
# Unit test for function bump_version
def test_bump_version():
    # major
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.1.0') == '1.0.0'
    assert bump_version('0.1.1') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('1.1.0') == '2.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    # minor
    assert bump_version('0.0.0', 1) == '0.1.0'


# Generated at 2022-06-29 18:14:27.853842
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3b4') == '1.2.4'
    assert bump_version('1.2a3') == '1.2.1'
    assert bump_version('1.3.3') == '1.4.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'b') == '1.3.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0'
    assert bump_version('1.3.3b4') == '1.4.0'

# Generated at 2022-06-29 18:14:39.613557
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert bump_version(version) == '0.0.1'
    assert bump_version(version, 0) == '1.0.0'
    assert bump_version(version, 0, 'a') == '1.0.0'
    assert bump_version(version, 1) == '0.1.0'
    assert bump_version(version, 1, 'a') == '0.1a0'
    assert bump_version(version, 2) == '0.0.1'
    assert bump_version(version, 2, 'a') == '0.0a0'
    version = '1.0.0'
    assert bump_version(version) == '1.0.1'
    assert bump_version(version, 0) == '2.0.0'
   

# Generated at 2022-06-29 18:14:48.817133
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:56.069556
# Unit test for function bump_version
def test_bump_version():
    def test(
            version: str,
            position: int = 2,
            pre_release: Union[str, None] = None
    ) -> None:
        print(bump_version(version, position, pre_release))
        print('-------')

    test('0.1.0')
    test('0.2.0')
    test('0.2.1', 2)
    test('0.10.0')
    test('0.11.12')
    test('0.2.0', 1)
    test('0.2.0', pre_release='alpha')
    test('0.1.0', pre_release='beta')
    test('0.0.1')
    test('1.0.0')
    test('1.1.0', 1)

# Generated at 2022-06-29 18:15:07.207789
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 'patch') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 2, None) == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'

# Generated at 2022-06-29 18:15:17.501952
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=unused-import
    from . import get_version
    from . import _test_each_version


# Generated at 2022-06-29 18:15:29.192981
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    This function is called when test_tac_version.py is called on command line.
    """

# Generated at 2022-06-29 18:15:40.581721
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'

# Generated at 2022-06-29 18:15:46.720713
# Unit test for function bump_version
def test_bump_version():
    print("Testing: bump_version")

# Generated at 2022-06-29 18:16:07.685830
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=invalid-name
    """Unit test for function bump_version"""
    version = '0.0.0'
    pos = 2
    pre_release = None
    out = bump_version(version, pos, pre_release)
    assert out == '0.0.1'

    version = '0.0.1'
    out = bump_version(version, pos, pre_release)
    assert out == '0.0.2'

    version = '0.0.1-alpha.1'
    out = bump_version(version, pos, pre_release)
    assert out == '0.0.1-alpha.2'

    version = '0.0.1-beta.1'
    out = bump_version(version, pos, pre_release)

# Generated at 2022-06-29 18:16:16.517631
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0102
    # pylint: disable=C0111
    # pylint: disable=R0201
    # pylint: disable=R0903
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', -3) == '1.0.0'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'