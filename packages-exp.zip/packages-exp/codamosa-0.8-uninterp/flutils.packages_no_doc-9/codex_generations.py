

# Generated at 2022-06-29 18:06:47.965189
# Unit test for function bump_version

# Generated at 2022-06-29 18:06:57.216317
# Unit test for function bump_version
def test_bump_version():
    # Test for function _each_version_part
    print('Testing function _each_version_part:')
    def _test_each_version_part(
            version: str,
            expected: Optional[str] = None,
    ):
        obj = _build_version_info(version)
        print(repr(obj))
        if expected is not None:
            assert str(obj) == expected

    _test_each_version_part('1.0.0a0', '1.0.0a0')
    _test_each_version_part('1.0.0a2.3', '1.0.0a2.3')
    _test_each_version_part('1.0.0a2b0', '1.0.0a2b0')

# Generated at 2022-06-29 18:07:08.776377
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.4.4') == '1.4.5'
    assert bump_version('1.4.4', 0) == '2.0.0'
    assert bump_version('1.4.4', -2) == '1.5.0'
    assert bump_version('1.4.4', 1) == '1.5.0'
    assert bump_version('1.4.4', 2) == '1.4.5'
    assert bump_version('1.4.0', 2) == '1.4.1'
    assert bump_version('1.4.0', 0) == '2.0.0'
    assert bump_version('1.4.4', 1, 'a') == '1.5.0a0'

# Generated at 2022-06-29 18:07:14.989015
# Unit test for function bump_version
def test_bump_version():
    # Test original method
    versions = ['1.2.2', '1.2.2a1', '1.2.2b1', '1.2.1', '1.2.0']
    for version in versions:
        out = bump_version(version)
        print(version, '->', out)

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:07:25.033815
# Unit test for function bump_version
def test_bump_version():
    """Test for the bump_version() Function"""

    assert bump_version('13.4.4') == '13.4.5'
    assert bump_version('13.4.4', -1) == '13.4.5'
    assert bump_version('13.4.4', 1) == '13.5.0'
    assert bump_version('13.4.4', 0) == '14.0.0'
    assert bump_version('13.4.4', -2) == '13.5.0'
    assert bump_version('13.4.0') == '13.4.1'
    assert bump_version('13.4.0', -1) == '13.4.1'
    assert bump_version('13.4.0', 2) == '13.5.0'
    assert bump_

# Generated at 2022-06-29 18:07:36.627513
# Unit test for function bump_version
def test_bump_version():
    print("\nTesting bump_version...")
    from math import sqrt
    from unittest.case import TestCase
    from typing import Union

    class _TestCase(TestCase):
        maxDiff = None
        @staticmethod
        def _get_version_number_parts(version: str) -> Tuple[Union[str, int], ...]:
            ver_obj = StrictVersion(version)
            version: Tuple[int, int, int] = ver_obj.version
            prerelease: Union[Tuple[str, int], None] = ver_obj.prerelease

            parts: List[Union[str, int]] = list(version)

            pre_release_type: str = ''
            pre_release_num: int = -1


# Generated at 2022-06-29 18:07:48.368151
# Unit test for function bump_version
def test_bump_version():
    #pylint: disable=C0116,C0115,W0613
    """
    Verify that the tests pass.
    """
    bump_version('1.2.0-alpha')
    bump_version('1.2.0a0')
    bump_version('1.2-alpha')
    bump_version('1.2a0')
    bump_version('0.2.1-beta')
    bump_version('0.2.1b0')
    bump_version('0.2-beta')
    bump_version('0.2b0')
    # These should all raise exceptions or cause type errors or a value error
    try:
        bump_version('1.2')
    except ValueError:
        pass

# Generated at 2022-06-29 18:07:56.181129
# Unit test for function bump_version
def test_bump_version():
    from os.path import abspath, dirname, join
    here = join(dirname(abspath(__file__)), 'test_bump_version.csv')
    with open(here, 'rb') as f:
        actual = f.read().decode().splitlines()
    expected = []
    for line in actual:
        if '\t' in line:
            expected.append(line.split('\t'))
    for line in expected:
        version, position, pre_release, actual_output = line
        position = int(position)
        pre_release = None
        if pre_release:
            pre_release = cast(str, pre_release)
        output = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert output == actual

# Generated at 2022-06-29 18:08:09.486015
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:20.060790
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', position=-2) == '0.1.1'
    assert bump_version('0.1.0', position=-3) == '0.2.0'
    assert bump_version('0.1.0', position=-4) == '1.0.0'
    assert bump_version('0.1.0', position=0) == '1.0.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.0', position=2) == '0.1.1'


# Generated at 2022-06-29 18:08:55.206375
# Unit test for function bump_version
def test_bump_version():
    def _test_case(
            version: str,
            position: str,
            pre_release: str,
            expected: str
    ):
        got = bump_version(version, int(position), pre_release)
        print('Test case:')
        print('\tversion: %r' % version)
        print('\tposition: %r' % position)
        print('\tpre_release: %r' % pre_release)
        print('\tgot: %r' % got)
        print('\texpected: %r' % expected)
        assert got == expected

    _test_case('1.2.0', '1', '', '1.3.0')
    _test_case('1.2.0', '1', 'a', '1.3.0')

# Generated at 2022-06-29 18:09:06.567261
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:19.141947
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=-1) == '0.0.1'
    assert bump_version('0.0.0', position=-2) == '0.1.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'
    assert bump_version('0.0.0', pre_release='a') == '0.1.0a0'

# Generated at 2022-06-29 18:09:32.608380
# Unit test for function bump_version
def test_bump_version():

    assert(bump_version('1.0.0', 0) == '2.0.0')
    assert(bump_version('1.0.0', 1) == '1.1.0')
    assert(bump_version('1.0.0', 2) == '1.0.1')
    assert(bump_version('1.0.0', -1) == '1.0.1')
    assert(bump_version('1.0.0', -2) == '1.1.0')
    assert(bump_version('1.0.0', -3) == '2.0.0')
    assert(bump_version('1.0.0', 3) == '1.0.1')

# Generated at 2022-06-29 18:09:43.552952
# Unit test for function bump_version
def test_bump_version():
    version = '1.3.3'
    expect = '1.3.3'
    actual = bump_version(version)
    print({'expect': expect, 'actual': actual})

    version = '1.3.3'
    expect = '1.3.3a0'
    actual = bump_version(version, 2, 'alpha')
    print({'expect': expect, 'actual': actual})

    version = '1.3.3'
    expect = '1.4.0'
    actual = bump_version(version, 1)
    print({'expect': expect, 'actual': actual})

    version = '1.3.3'
    expect = '1.4.0'
    actual = bump_version(version, 1, 'a')

# Generated at 2022-06-29 18:09:56.211133
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.2.4', 1) == '1.3.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.0.1a0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'

# Generated at 2022-06-29 18:10:03.225383
# Unit test for function bump_version
def test_bump_version():
    def _verify_bump_version(ver: str, pos: int, pre_release: Optional[str],
                             expected: str) -> bool:
        actual = bump_version(ver, pos, pre_release)
        if actual != expected:
            print('When called with:')
            print('    version: ' + ver)
            print('    position: ' + str(pos))
            print('    pre_release: ' + str(pre_release))
            print('Expected: ' + expected)
            print('But got: ' + actual)
            return False
        return True

    # Test with a simple version number
    assert _verify_bump_version('1.0.0', 0, None, '2.0.0')

# Generated at 2022-06-29 18:10:15.929294
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.2.0', position=0) == '2.0.0'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0', position=2, pre_release='a') == '1.2.1a0'
    assert bump_version('1.2.0', position=2, pre_release='b') == '1.2.1b0'
    assert bump_version('1.2.0', position=2, pre_release='a') == '1.2.1a0'
    assert bump_

# Generated at 2022-06-29 18:10:20.900751
# Unit test for function bump_version
def test_bump_version():
    version = '0.3.0'
    assert bump_version(version, position=-3) == '0.3.1'
    assert bump_version(version, position=-2) == '0.3.1'
    assert bump_version(version, position=-1) == '0.3.1'
    assert bump_version(version, position=0) == '1.0.0'
    assert bump_version(version, position=1) == '1.4.0'
    assert bump_version(version, position=2) == '1.3.1'
    version = '0.3.0a1'
    assert bump_version(version, position=-3) == '0.3.0a2'
    assert bump_version(version, position=-2) == '0.3.0a2'
    assert bump

# Generated at 2022-06-29 18:10:28.116507
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.1.0') == '2.2.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.1.0', 0) == '3.1.0'
    assert bump_version('2.1.0', 1) == '2.2.0'
    assert bump_version('2.1.0', 2) == '2.1.1'
    assert bump_version('2.1.1', 2) == '2.1.2'
    assert bump_version('2.1.0', -1) == '2.1.1'
    assert bump_version('2.1.1', -1) == '2.1.2'

# Generated at 2022-06-29 18:10:46.857467
# Unit test for function bump_version
def test_bump_version():
    def _utest_bump_version(
            version,
            position,
            pre_release,
            expected
    ) -> bool:
        try:
            actual = bump_version(version, position, pre_release)
            assert actual == expected
        except AssertionError as err:
            print(err)
            return False
        return True

    version = '1.2.0'
    position = 2
    pre_release = None
    expected = '1.2.1'
    assert _utest_bump_version(version, position, pre_release, expected)

    version = '1.2.0'
    position = 1
    pre_release = None
    expected = '1.3.0'
    assert _utest_bump_version(version, position, pre_release, expected)

    version

# Generated at 2022-06-29 18:10:58.724994
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.4.4') == '0.4.5'
    assert bump_version('0.4.4', 1) == '0.5.0'
    assert bump_version('0.4.4', 0) == '1.0.0'
    assert bump_version('0.12.0') == '0.12.1'
    assert bump_version('0.12.0', 1) == '0.13.0'
    assert bump_version('0.12.0', 0) == '1.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'

# Generated at 2022-06-29 18:11:08.801000
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:21.234026
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class BumpVersionTestCase(unittest.TestCase):
        def test_major(self):
            version = "1.0.0"
            result = bump_version(version, 0)
            self.assertEqual(result, "2.0.0")

        def test_minor_1(self):
            version = "1.0.0"
            result = bump_version(version, 1)
            self.assertEqual(result, "1.1.0")

        def test_minor_2(self):
            version = "1.0.1"
            result = bump_version(version, 1)
            self.assertEqual(result, "1.1.1")

        def test_minor_3(self):
            version = "1.1.1"
           

# Generated at 2022-06-29 18:11:34.656931
# Unit test for function bump_version
def test_bump_version():
    ver = '1.0.0'
    pos, pre = 2, None
    assert bump_version(ver, pos, pre) == '1.0.1'
    assert bump_version(ver, 1, pre) == '1.1.0'
    assert bump_version(ver, 0, pre) == '2.0.0'
    assert bump_version(ver, -1, pre) == '1.1.0'
    assert bump_version(ver, -2, pre) == '1.0.1'
    assert bump_version(ver, -3, pre) == '1.0.0'

    ver = '1.0.0-a1'
    pos, pre = 2, None
    assert bump_version(ver, pos, pre) == '1.0.1'

# Generated at 2022-06-29 18:11:44.988287
# Unit test for function bump_version
def test_bump_version():
    output = bump_version('1.2.3b0', 1, 'a')
    assert output == '1.2a1'
    output = bump_version('1.2', 0)
    assert output == '2.0.0'
    output = bump_version('1.2', 1)
    assert output == '1.3.0'
    output = bump_version('1.2', 2)
    assert output == '1.2.1'
    output = bump_version('1.2', 2, 'alpha')
    assert output == '1.2.1a0'
    output = bump_version('1.2', 2, 'beta')
    assert output == '1.2.1b0'

test_bump_version()

# Generated at 2022-06-29 18:11:52.961138
# Unit test for function bump_version
def test_bump_version():
    # Test bumping major version
    # Test passing in a bad value for the major version number
    ver = '111.0.0'
    try:
        bump_version(ver)
    except ValueError:
        pass
    else:
        raise AssertionError(
            "Expected 'bump_version' to have thrown an exception for %r." % ver
        )
    # Test passing in a bad value for the major version number
    ver = '111.0.0'
    try:
        bump_version(ver)
    except ValueError:
        pass
    else:
        raise AssertionError(
            "Expected 'bump_version' to have thrown an exception for %r." % ver
        )
    # Test bumping the major version number
    ver = '1.0.0'
    expected_ver

# Generated at 2022-06-29 18:12:05.126490
# Unit test for function bump_version
def test_bump_version():
    # test for normal cases
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, "alpha") == '1.0.1a0'
    assert bump_version('1.0.0', 2, "beta") == '1.0.1b0'

    # test for cases related with pre-release
    assert bump_version('1.0.0a0') == '1.1.0'
    assert bump_version('1.0.0b0') == '1.1.0'

# Generated at 2022-06-29 18:12:17.919939
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.4.0') == '2.0.0'
    assert bump_version('1.4.0', 0) == '2.0.0'
    assert bump_version('1.4.0', 1) == '1.5.0'
    assert bump_version('1.4.0', 2) == '1.4.1'
    assert bump_version('1.4.0', -1) == '1.4.1'
    assert bump_version('1.4.0', -2) == '1.5.0'
    assert bump_version('1.4.0', -3) == '2.0.0'

    assert bump_version('1.4.1') == '1.4.1'

# Generated at 2022-06-29 18:12:23.531895
# Unit test for function bump_version
def test_bump_version():
    from bump_version import bump_version
    
    version = '1.0.0'
    print(version)

    assert bump_version(version) == '1.0.1'
    version = version
    assert bump_version(version, position=1) == '1.1.0'
    version = version
    assert bump_version(version, position=0) == '2.0.0'
    version = version
    assert bump_version(version, position=-1) == '1.0.1'
    version = version
    assert bump_version(version, position=-2) == '1.1.0'
    version = version
    assert bump_version(version, position=-3) == '2.0.0'
    version = version

# Generated at 2022-06-29 18:12:40.153969
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.0'
    assert bump_version('1.1.0') == '1.1.0'
    assert bump_version('1.0.1') == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.1.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.1.0', position=1) == '1.1.0'

# Generated at 2022-06-29 18:12:51.423532
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:01.728190
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0a0', 0, 'alpha') == '1.0.0'
    assert bump_version('0.0.0a0', 0, 'a') == '1.0.0'
    assert bump_version('0.0.0a0', 0, 'beta') == '1.0.0'
    assert bump_version('0.0.0a0', 0, 'b') == '1.0.0'
    assert bump_version('0.0.0a0', 0, None) == '1.0.0'
    assert bump_version('0.0.0a0', 0, '') == '1.0.0'

    assert bump_version('0.0.0a0', 1, 'alpha') == '0.1.0a0'
    assert bump

# Generated at 2022-06-29 18:13:14.328670
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3.dev123') == '1.2.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

# Generated at 2022-06-29 18:13:22.831153
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:35.685276
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:45.872595
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:59.179577
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', 0, pre_release='b')
    assert version == '1.3.0b0'
    version = bump_version('1.2.3a0', 0, pre_release='b')
    assert version == '1.3.0b0'
    version = bump_version('1.2.3', 1, pre_release='b')
    assert version == '1.3.0b0'
    version = bump_version('1.2.3', 1, pre_release='b')
    assert version == '1.3.0b0'
    version = bump_version('1.2.3b0', 0, pre_release='a')
    assert version

# Generated at 2022-06-29 18:14:09.472437
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('2.4.4') == '3.0.0'
    assert bump_version('2.4.4', 2) == '2.4.5'
    assert bump_version('2.4.4', 1) == '2.5.0'
    assert bump_version('2.4.4', 0) == '3.0.0'
    assert bump_version('2.4.4', -1) == '2.5.0'

# Generated at 2022-06-29 18:14:15.894085
# Unit test for function bump_version
def test_bump_version():
    result = bump_version('0.1.2')
    assert result == '0.1.3', "Should be '0.1.3'"
    result = bump_version('0.1.2', 0)
    assert result == '1.0.0', "Should be '1.0.0'"
    result = bump_version('0.1.2', 1)
    assert result == '0.2.0', "Should be '0.2.0'"
    result = bump_version('0.1.2', 2)
    assert result == '0.1.3', "Should be '0.1.3'"
    result = bump_version('0.1.2', -1)
    assert result == '0.1.3', "Should be '0.1.3'"

# Generated at 2022-06-29 18:14:35.503270
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position = 2) == '1.2.4'
    assert bump_version('1.2.3', position = 1) == '1.3'
    assert bump_version('1.2.3', position = 0) == '2'
    assert bump_version('1.2.3', position = -1) == '1.2.4'
    assert bump_version('1.2.3', position = -2) == '1.3'
    assert bump_version('1.2.3', position = -3) == '2'
    assert bump_version('2.0.0') == '2.0.1'

# Generated at 2022-06-29 18:14:46.216986
# Unit test for function bump_version
def test_bump_version():
    # _build_version_bump_position
    with pytest.raises(ValueError):
        _build_version_bump_position(-4)
    with pytest.raises(ValueError):
        _build_version_bump_position(3)

    # _build_version_info
    ver_info = _build_version_info('1.2.3.4')
    assert ver_info.version == '1.2.3.4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

# Generated at 2022-06-29 18:14:54.407786
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:05.548487
# Unit test for function bump_version
def test_bump_version():
    """
    bump_version: test the function
    """

# Generated at 2022-06-29 18:15:15.673605
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:27.464267
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test function
    """
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('2.3.4') == '2.3.5'
    assert bump_version('3.4.0') == '3.4.1'

    assert bump_version('1.0.0', pre_release='a') == '1.0.0a1'
    assert bump_version('1.0.1', pre_release='a') == '1.0.1a1'
    assert bump_version('1.0.0a1') == '1.0.0a2'
    assert bump_version('1.0.1a1', pre_release='a') == '1.0.2a0'

# Generated at 2022-06-29 18:15:34.278733
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:46.307360
# Unit test for function bump_version
def test_bump_version():
    test_version = "2.3.0"
    assert(bump_version(test_version) == "2.3.1")
    assert(bump_version(test_version, 1) == "2.4.0")
    assert(bump_version(test_version, pre_release="a") == "2.3.1a0")
    assert(bump_version(test_version, 0) == "3.0.0")

if __name__ == "__main__":
    test_version = "2.3.0"
    print(bump_version(test_version))
    print(bump_version(test_version, 1))
    print(bump_version(test_version, pre_release="a"))
    print(bump_version(test_version, 0))

# Generated at 2022-06-29 18:15:56.190023
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.3.0'
    assert bump_version('1.2.3', 1, 'a') == '1.3a0'
    assert bump_version('1.2.3', 2, 'a') == '1.3a0'
    assert bump_version('1.1.3', 1, 'a') == '1.2a0'
    assert bump_version('1.1.3', 2, 'a') == '1.2a0'
    assert bump_version('1.1.0', 1, 'a') == '1.2a0'

# Generated at 2022-06-29 18:16:08.073153
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.7.2') == '1.7.3'
    assert bump_version('1.7.2', 2) == '1.7.3'
    assert bump_version('1.7.2', 1) == '1.8.0'
    assert bump_version('1.7.2', 0) == '2.0.0'
    assert bump_version('1.7.0', 0) == '2.0.0'
    assert bump_version('1.7.0', 1) == '1.8.0'
    assert bump_version('1.7.2', 1, 'a') == '1.8.0a0'
    assert bump_version('1.7.2a2') == '1.7.2a3'