

# Generated at 2022-06-29 18:06:46.529283
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', pre_release='a') == '0.0.1a0'
    assert bump_version('0.0.1', position=1, pre_release='a') == '0.1.0a0'
    assert bump_version('0.1a1') == '0.1a2'
    assert bump_version('0.1a1', 1) == '0.1a2'
    assert bump_version('0.1a1', position=1) == '0.1a2'

# Generated at 2022-06-29 18:06:53.959874
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.8.12') == '1.9.0'
    assert bump_version('1.8.12', 1) == '1.9.0'
    assert bump_version('1.8.12', 1, None) == '1.9.0'
    assert bump_version('1.9.12') == '1.10.0'
    assert bump_version('1.9.12a0') == '1.9.12a1'
    assert bump_version('1.9.12a0', 1) == '1.9.12a1'
    assert bump_version('1.9.12a0', 1, 'a') == '1.9.12a1'
    assert bump_version('1.9.12a1') == '1.9.12a2'

# Generated at 2022-06-29 18:07:04.784881
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:16.280253
# Unit test for function bump_version
def test_bump_version():
    version_out = bump_version('0.0.1')
    assert version_out == '0.0.2'
    version_out = bump_version('0.0.1', 1)
    assert version_out == '0.1.0'
    version_out = bump_version('0.0.1', 0)
    assert version_out == '1.0.0'
    version_out = bump_version('0.1.0')
    assert version_out == '0.1.1'
    version_out = bump_version('0.1.1', 1)
    assert version_out == '0.2.0'
    version_out = bump_version('1.1.1', 0)
    assert version_out == '2.0.0'

# Generated at 2022-06-29 18:07:25.910458
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1123
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', -1) == '0.1.0'
    assert bump_version('0.0.1', 0, 'alpha') == '1.0.0'
    assert bump_version('0.0.1', -1, 'alpha') == '0.0.1a0'

# Generated at 2022-06-29 18:07:37.854090
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for bump_version
    """

# Generated at 2022-06-29 18:07:49.564421
# Unit test for function bump_version
def test_bump_version():
    import os
    import logging
    import unittest.mock

    # Create test output folder.
    data_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    output_folder = os.path.join(data_folder, 'test_output')
    if not os.path.exists(data_folder):
        os.mkdir(data_folder)
    if not os.path.exists(output_folder):
        os.mkdir(output_folder)

    # This is a tuple of tuples.  The nested tuples contains the version
    # number passed to bump_version(), the expected output version and
    # the position/pre_release settings.

# Generated at 2022-06-29 18:07:57.137394
# Unit test for function bump_version
def test_bump_version():
    class TestData:
        def __init__(self, bump_version_param, expected):
            self.bump_version_param = bump_version_param
            self.expected = expected


# Generated at 2022-06-29 18:08:10.011613
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3a0') == '1.2.3a1'
    assert bump_version('1.2.3b4') == '1.2.3b5'
    assert bump_version('1.2.3a9') == '1.2.3a10'
    assert bump_version('1.2.3b9') == '1.2.3b10'
    assert bump_version('1.2.3a9', 0) == '1.2.4'
    assert bump_version('1.2.3b4', 0) == '1.2.4'

# Generated at 2022-06-29 18:08:20.634859
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0-b.0') == '1.0.0'
    assert bump_version('0.1.0-b.0') == '0.2.0'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.1', -1) == '0.0.2'
    assert bump_version('0.0.1', -3) == '0.0.2'
    assert bump_version('0.0.0', 1) == '0.0.0'

# Generated at 2022-06-29 18:08:50.489768
# Unit test for function bump_version
def test_bump_version():
    for param_info in (
            ('0.4.4', 1),
            ('0.4.4', 2),
            ('0.4.4', 3),
            ('0.4.4', -1),
            ('0.4.4', -2),
            ('0.4.4', -3),
            ('0.4.4', -4),
            ('0.4.4', -5),
    ):
        ver = bump_version(*param_info)
        assert StrictVersion(ver) > StrictVersion(param_info[0])


# Generated at 2022-06-29 18:09:02.999321
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:15.288567
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.1.0', 1) == '0.1.1'
    assert bump_version('0.1.0', 1, 'a') == '0.1.1'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.1.0', 0) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'

# Generated at 2022-06-29 18:09:22.980729
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:28.676929
# Unit test for function bump_version
def test_bump_version():
    while True:
        ver = input('Enter a version: ')
        if not ver:
            break
        position = int(input('Enter a position: '))
        prerel = input('Enter a prerelease: ')
        print(bump_version(ver, position, prerel))

# Generated at 2022-06-29 18:09:40.600123
# Unit test for function bump_version
def test_bump_version():
    # MAJOR
    assert bump_version('0.0.0', 0, None) == '1.0.0'
    assert bump_version('1.0.0', 0, None) == '2.0.0'
    assert bump_version('1.1.0', 0, None) == '2.0.0'
    assert bump_version('1.0.1', 0, None) == '2.0.0'
    assert bump_version('1.0.0a1', 0, None) == '2.0.0'
    assert bump_version('1.0.0b1', 0, None) == '2.0.0'
    # MINOR
    assert bump_version('0.0.0', 1, None) == '0.1.0'

# Generated at 2022-06-29 18:09:47.531152
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.0") == "1.2.1"
    assert bump_version("1.2.1") == "1.2.2"
    assert bump_version("1.2.1", position=1) == "1.3.0"
    assert bump_version("1.2.1", position=0) == "2.0.0"
    assert bump_version("1.2.0a0") == "1.2.0a1"
    assert bump_version("1.2.0a1") == "1.2.0a2"
    assert bump_version("1.2.0a1", position=0) == "2.0.0a0"
    assert bump_version("1.2.0a1", position=1) == "1.3.0a0"

# Generated at 2022-06-29 18:10:00.619962
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:09.321281
# Unit test for function bump_version
def test_bump_version():
    for version in (
            '0.0.2',
            '0.0.2a0',
            '0.0.2b0',
            '0.1.0',
            '0.1.0a0',
            '0.1.0b0',
            '1.0.0',
            '1.0.0a0',
            '1.0.0b0',
            '1.1.0',
            '1.1.0a0',
            '1.1.0b0',
    ):
        for parts in (1, 2, 3):
            for pre_release in (
                    '',
                    'a',
                    'alpha',
                    'b',
                    'beta',
                    None,
            ):
                if pre_release is None:
                    bump_pre_release

# Generated at 2022-06-29 18:10:22.257722
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:41.354036
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', position=2) == '0.0.2'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', position=0) == '1.0.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.0', position=2) == '0.1.1'

# Generated at 2022-06-29 18:10:54.600923
# Unit test for function bump_version
def test_bump_version():
    r'''Test the bump_version function.'''
    ver = '1.2.3'
    assert bump_version(ver, 0) == '2.0.0'
    assert bump_version(ver, 1) == '1.3.0'
    assert bump_version(ver, 2) == '1.2.4'
    assert bump_version(ver, -1) == '1.2.4'
    assert bump_version(ver, -2) == '1.3.0'
    assert bump_version(ver, -3) == '2.0.0'
    ver = '1.2.3a2'
    assert bump_version(ver, 0) == '2.0.0'
    assert bump_version(ver, 1) == '1.3.0'

# Generated at 2022-06-29 18:11:06.315061
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:19.686318
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:32.357097
# Unit test for function bump_version
def test_bump_version():
    print("Testing bump_version function...")
    # TODO: Test bump_version more completely
    # Test with no pre-release
    v1 = "1.2.3"
    v2 = "1.2.4"
    assert bump_version(v1) == v2
    v1 = "1.2.4"
    v2 = "1.2.5"
    assert bump_version(v1) == v2
    v1 = "1.2.0"
    v2 = "1.3.0"
    assert bump_version(v1) == v2
    v1 = "1.2.0"
    v2 = "1.3.0"
    assert bump_version(v1) == v2
    v1 = "7.2.0"

# Generated at 2022-06-29 18:11:35.364679
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.3.0'))

if __name__ == "__main__":
    test_bump_version()

# Generated at 2022-06-29 18:11:46.355192
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.2.0', position=0) == '2.0.0'

    assert bump_version('1.2.0', position=-1) == '1.2.1'
    assert bump_version('1.2.0', position=-2) == '1.3.0'
    assert bump_version('1.2.0', position=-3) == '2.0.0'

    assert bump_version('1.2.3') == '1.2.4'

# Generated at 2022-06-29 18:11:57.537370
# Unit test for function bump_version
def test_bump_version():
    # Check types
    assert isinstance( bump_version('10.2.2', position=-1), str)
    assert isinstance( bump_version('10.2.2', position=1), str)
    assert isinstance( bump_version('10.2.2', position=2), str)
    assert isinstance( bump_version('10.2.2', position=2, pre_release='a'), str)
    assert isinstance( bump_version('10.2.2', pre_release='a'), str)

    # Check zero padding
    assert bump_version('10.2.2', position=2) == '10.2.3'
    assert bump_version('10.2.2', position=2, pre_release='a') == '10.2.3a0'

# Generated at 2022-06-29 18:12:09.808561
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', 1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', 1, pre_release='b') == '1.3b0'

# Generated at 2022-06-29 18:12:21.587336
# Unit test for function bump_version
def test_bump_version():
    import random
    import string
    import unittest

    from mypy_extensions import NoReturn

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_major(self):
            for major_num in range(0, 8):
                ver = (
                    '%s.4.3' % major_num
                )
                out = bump_version(ver, 0)
                self.assertEqual(out, '%s.0.0' % (major_num + 1))

        def test_bump_version_minor(self):
            for minor_num in range(0, 8):
                ver = (
                    '5.%s.3' % minor_num
                )
                out = bump_version(ver, 1)

# Generated at 2022-06-29 18:12:39.495279
# Unit test for function bump_version
def test_bump_version():
    def bump_test(
            ver_in: str,
            pos: int,
            pre_in: Optional[str],
            ver_out: str
    ) -> None:
        ver_bumped: str = bump_version(ver_in, pos, pre_in)
        try:
            assert ver_bumped == ver_out
            print('Success. Got %r' % ver_bumped)
        except AssertionError:
            print('Failed. Got %r' % ver_bumped)
            raise

    bump_test('1.0.0', 0, None, '2.0.0')
    bump_test('1.0.0', 1, None, '1.1.0')
    bump_test('1.0.0', 2, None, '1.0.1')
    bump_test

# Generated at 2022-06-29 18:12:50.503746
# Unit test for function bump_version
def test_bump_version():

    print('')
    print('BUMP_VERSION:')
    print('=============')

    version = bump_version('1.2.3')
    print(version)

    version = bump_version('1.2.3', pre_release='beta')
    print(version)

    version = bump_version('1.2.3', pre_release='beta')
    print(version)

    version = bump_version('1.2.3', position=1, pre_release='beta')
    print(version)

    version = bump_version('1.2.3-b', position=1, pre_release='beta')
    print(version)

    version = bump_version('1.2.3-beta', position=1, pre_release='beta')
    print(version)


# Generated at 2022-06-29 18:13:01.295993
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from sys import stderr
    from fnmatch import fnmatch

    from .messages import LOGGER

    def _do_test(version: str, position: int, pre_release: str):
        try:
            print('Testing: %s, %r, %r' % (version, position, pre_release))
            out = bump_version(version, position, pre_release)
            print('  Result: %s' % out)
        except Exception as exc:
            if not isinstance(exc, ValueError):
                msg = str(exc)
                LOGGER.error(msg)

    def _check(
            pattern: str,
            version: str,
            position: int,
            pre_release: str
    ) -> bool:
        if pattern == '*':
            return True

# Generated at 2022-06-29 18:13:13.778886
# Unit test for function bump_version
def test_bump_version():
    # Test that the starting point is correct
    ver_info = _build_version_info('2.2.2')

# Generated at 2022-06-29 18:13:22.490719
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0'
    assert bump_version('1.2.3', 0, 'b') == '2.0b'
    assert bump_version('1.2.3', 0, 'a') == '2.0a'
    assert bump_version('1.2.3', 0, 'alpha') == '2.0a'
    assert bump_version('1.2.3', 0, 'beta') == '2.0b'
    assert bump_version('1.2.3', 0, 'A') == '2.0a'
    assert bump_version('1.2.3', 0, 'B') == '2.0b'

# Generated at 2022-06-29 18:13:35.011891
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', position=2, pre_release='a') == '0.0.2a0'
    assert bump_version('0.0.1', position=2, pre_release='b') == '0.0.2b0'
    assert bump_version('0.0.1', position=2, pre_release='alpha') == '0.0.2a0'
    assert bump_version('0.0.1', position=2, pre_release='beta') == '0.0.2b0'

    assert bump_version('0.0.1', position=0, pre_release='b') == '1.0.0'

# Generated at 2022-06-29 18:13:45.512425
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:58.699955
# Unit test for function bump_version
def test_bump_version():
    # 0.0.0 -> 0.0.1
    assert bump_version('0.0.0') == '0.0.1'
    # 1.0.0 -> 1.0.1
    assert bump_version('1.0.0') == '1.0.1'
    # 1.2.3 -> 1.2.4
    assert bump_version('1.2.3') == '1.2.4'
    # 1.0.0-alpha.0 -> 1.0.0-alpha.1
    assert bump_version('1.0.0-alpha.0') == '1.0.0-alpha.1'
    # 1.0.0-beta.0 -> 1.0.0-beta.1

# Generated at 2022-06-29 18:14:09.033012
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:15.665192
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'

    assert bump_version('1.0.0', 0) == '2.0.0'

    assert bump_version('1.0.0', 1) == '1.1.0'

    assert bump_version('1.0.0', 2) == '1.0.1'

    assert bump_version('1.0.0', -1) == '1.0.1'

    assert bump_version('1.0.0', -2) == '1.1.0'

    assert bump_version('1.0.0', -3) == '2.0.0'

    assert bump_version('1.0.0-alpha.1') == '1.0.0-alpha.2'


# Generated at 2022-06-29 18:14:41.682629
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version():')

# Generated at 2022-06-29 18:14:49.186465
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('2.0.0') == '2.0.1'
    assert bump_version('2.1.0') == '2.1.1'
    assert bump_version('0.0.0a0') == '0.0.0a1'
    assert bump_version('0.0.1a1') == '0.0.1a2'

# Generated at 2022-06-29 18:14:57.750927
# Unit test for function bump_version
def test_bump_version():
    version = '5.5.0'
    for postion in ('1', '2', '-1', '-2'):
        for pre_release in {None, 'a', 'alpha', 'b', 'beta'}:
            try:
                new_version = bump_version(version, position=postion,
                                           pre_release=pre_release)
                print(postion, pre_release, new_version)
            except Exception as e:
                print(postion, pre_release, e)

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:15:08.324652
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:11.934998
# Unit test for function bump_version
def test_bump_version():
    # ARRANGE
    expected_result = '0.1.1'
    old_ver = '0.1'
    new_ver_name = bump_version(old_ver)
    # ASSERT
    assert new_ver_name == expected_result

# Generated at 2022-06-29 18:15:24.527719
# Unit test for function bump_version
def test_bump_version():
    # Make sure it's returning the right version number
    assert bump_version('1.2') == '2.0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3a2') == '1.2.3a3'
    assert bump_version('1.2.3b3') == '1.2.3b4'
    assert bump_version('1.2a1') == '1.2a2'

# Generated at 2022-06-29 18:15:32.689504
# Unit test for function bump_version
def test_bump_version():
    """
    >>> test_bump_version()
    0
    """
    from distutils.version import StrictVersion
    from itertools import combinations

    def assert_case(version: str, expected: str):
        res = bump_version(version)
        try:
            assert res == expected
            print(
                '    PASS: bump_version(%r) == %r' % (version, expected)
            )
        except AssertionError:
            print('    FAIL:')
            print('        bump_version(%r)' % version)
            print('        Result:')
            print('            %r' % res)
            print('        Expected:')
            print('            %r' % expected)
            raise

    # Check that the major version always increases

# Generated at 2022-06-29 18:15:45.414356
# Unit test for function bump_version
def test_bump_version():

    # Major
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('10.9.8') == '11.0.0'
    assert bump_version('1.2.3', 0) == '2.0.0'

    # Minor
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.0.0-alpha') == '1.1.0'
    assert bump_version('1.2.3-alpha0') == '1.3.0'
    assert bump_version('1.0.0-beta') == '1.1.0'

# Generated at 2022-06-29 18:15:55.469739
# Unit test for function bump_version
def test_bump_version():
    """
    Tests for function bump_version
    >>> test_bump_version()
    True
    """
    print("Version: ", bump_version("1.0.0"))
    print("Version: ", bump_version("1.0.0", 0, "a"))
    print("Version: ", bump_version("1.0.0", 1, "a"))
    print("Version: ", bump_version("1.0.0", 1, "b"))
    print("Version: ", bump_version("1.0.0", 2, "a"))
    print("Version: ", bump_version("1.0.0", 2, "b"))
    print("Version: ", bump_version("1.0.0", 2))
    print("Version: ", bump_version("1.0.1", 2))

# Generated at 2022-06-29 18:16:07.941494
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3.0'
    version = bump_version('1.2.3', position=0)
    assert version == '2.0.0'
    version = bump_version('1.2a2', position=2, pre_release='a')
    assert version == '1.2a3'
    version = bump_version('1.2a2', position=2, pre_release='b')
    assert version == '1.2b0'
    version = bump_version('1.2a2', position=1, pre_release='a')
    assert version == '1.3a0'
    version = bump_