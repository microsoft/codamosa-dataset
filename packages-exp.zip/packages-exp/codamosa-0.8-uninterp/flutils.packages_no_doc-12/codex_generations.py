

# Generated at 2022-06-29 18:06:48.133323
# Unit test for function bump_version
def test_bump_version():
    for vtype in ('minor', 'patch'):
        print('\n')
        print(
            '--------------------------------------------------------------'
        )
        print('Testing %s method' % vtype)
        print(
            '--------------------------------------------------------------'
        )
        print('\n')
        # Testing (alpha)
        print('Testing alpha')
        print('--------------')
        print('\n')
        # For release version
        print('For release version')
        print('--------------------')
        vnum = bump_version('1.0.0', vtype, 'a')
        print('%s - %s' % ('1.0.0', vnum))
        vnum = bump_version('1.0.2.3', vtype, 'a')

# Generated at 2022-06-29 18:06:57.257656
# Unit test for function bump_version
def test_bump_version():
    version = '1.8.6'
    assert bump_version(version, position=2) == '1.8.7'

    version = '2.1.5'
    assert bump_version(version, position=2) == '2.1.6'

    version = '3.3'
    assert bump_version(version, position=1) == '3.4'

    version = '5.2.2'
    assert bump_version(version, position=0) == '6.0'

    version = '7.3'
    assert bump_version(version, position=1) == '7.4'

    version = '9.3'
    assert bump_version(version, position=2) == '9.3.1'

    version = '10.4'

# Generated at 2022-06-29 18:07:08.821185
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:20.097790
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0') == '2'
    assert bump_version('1.0.0') == '2'
    assert bump_version('1.1.0') == '1.2'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.0', 0) == '2'
    assert bump_version('1.0.0', 0) == '2'
    assert bump_version('1.1.0', 0) == '2'
    assert bump_version('1.1.1', 0) == '2'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.0.0', 1) == '1.1'

# Generated at 2022-06-29 18:07:27.003620
# Unit test for function bump_version
def test_bump_version():
    # bump_version function should return '1.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    # bump_version function should return '1.1'
    assert bump_version('1.0') == '1.1'
    # bump_version function should return '2.0'
    assert bump_version('1.1') == '2.0'
    # bump_version function should return '2.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    # bump_version function should return '2.0.1'
    assert bump_version('1.1.0') == '2.0.1'
    # bump_version function should return '1.0.3'

# Generated at 2022-06-29 18:07:39.021311
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1a0') == '0.0.2a0'
    assert bump_version('0.0.1a0', 2) == '0.0.2a0'
    assert bump_version('0.0.1a0', 2, 'a') == '0.0.2a0'
    assert bump_version('0.0.1a0', 2, 'alpha') == '0.0.2a0'
    assert bump_version('0.0.1a0', 2, 'b') == '0.0.2b0'
    assert bump_version('0.0.1a0', 2, 'beta') == '0.0.2b0'
    assert bump_version('0.0.1a0', 2, None) == '0.0.2'


# Generated at 2022-06-29 18:07:50.489613
# Unit test for function bump_version
def test_bump_version():
    # ###
    args = ('0.0.1', '0.0.2')
    assert bump_version(*args) == args[0]

    # ###
    args = ('0.1.0', '0.2.0')
    assert bump_version(*args) == args[0]

    # ###
    args = ('1.1.1', '2.0.0')
    assert bump_version(*args) == args[0]

    # ###
    args = ('1.1.0', '1.2.0')
    assert bump_version(*args) == args[0]

    # ###
    args = ('1.1.0', '2.0.0')
    assert bump_version(*args) == args[0]

    # ###

# Generated at 2022-06-29 18:08:00.422015
# Unit test for function bump_version
def test_bump_version():
    # Test without pre-release
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', -3) == '1.0.0'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.0', -1) == '0.0.1'

    assert bump_version('0.1.0') == '0.1.1'

# Generated at 2022-06-29 18:08:11.265295
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase, main

    class TestBumpVersion(TestCase):
        def run_bump_version_test(
                self,
                input_version: str,
                output_version: str,
                position: int,
                pre_release: Optional[str] = None
        ) -> None:
            self.assertEqual(
                bump_version(input_version, position, pre_release),
                output_version
            )

        def test_bump_version_1(self):
            self.run_bump_version_test(
                input_version='2.0.0',
                output_version='3.0.0',
                position=-3,
            )


# Generated at 2022-06-29 18:08:21.226634
# Unit test for function bump_version
def test_bump_version():
    # Empty version
    assert bump_version('') == '1.0'
    # Version 1.2.3
    assert bump_version('1.2.3') == '1.2.4'
    # Version 1.2.3a2
    assert bump_version('1.2.3a2') == '1.2.3a3'
    # Version 1.2.3b2
    assert bump_version('1.2.3b2') == '1.2.3b3'
    # Version 1.2.3a2 to minor
    assert bump_version('1.2.3a2', 1) == '1.3a0'
    # Version 1.2.3a2 to alpha

# Generated at 2022-06-29 18:08:54.924520
# Unit test for function bump_version
def test_bump_version():
    # Test bump_version output
    assert bump_version("0.0.0") == "1.0.0"
    assert bump_version("1.0.0") == "2.0.0"
    assert bump_version("2.0.0") == "3.0.0"
    assert bump_version("1.2.3") == "1.3.0"
    assert bump_version("1.2.3", -1) == "1.2.4"
    assert bump_version("1.0.0-alpha.0") == "1.0.0-alpha.1"
    assert bump_version("1.0.0-alpha.0", -2) == "1.0.1-alpha.0"

# Generated at 2022-06-29 18:09:06.566836
# Unit test for function bump_version
def test_bump_version():

    def _ver_str(
            version: str,
            position: int,
            pre_release: Optional[str] = None,
    ) -> Tuple[str, str]:
        return (version, bump_version(version, position, pre_release))


# Generated at 2022-06-29 18:09:19.140896
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint

    do = lambda v: pprint(bump_version(v))

    do('1.0.0')  # Out: '1.0.1'
    do('1.0')  # Out: '1.0.1'
    do('1.0a3')  # Out: '1.0a4'
    do('1.0b2')  # Out: '1.0b3'
    do('1.0b1')  # Out: '1.0b2'
    do('1.2')  # Out: '1.2.1'
    do('1.2.0')  # Out: '1.2.1'
    do('1.2.0b0')  # Out: '1.2.1b0'

# Generated at 2022-06-29 18:09:23.027826
# Unit test for function bump_version
def test_bump_version():
    # This is a stub
    assert bump_version('0.0.0') == '0.0.1'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:09:36.153979
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:45.566867
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:58.891783
# Unit test for function bump_version
def test_bump_version():
    def tester(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = ''
    ) -> None:
        print(version, end=": ")
        out = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        print(out)
        assert out == expected

    tester('3.5.6')
    tester('3.5.6', 3, 'a')
    tester('3.5.6', 3, 'a', '3.5.7a0')
    tester('3.5.6.1', 3, 'a', '3.5.7a0')

# Generated at 2022-06-29 18:10:08.228093
# Unit test for function bump_version
def test_bump_version():
    print("==================")
    try:
        print("bump_version('1.0')")
        bump_version('1.0')
    except ValueError as exc:
        print("Failed")
        print(exc)
    else:
        print("Success")
    print("==================")
    try:
        print("bump_version('1.2.3')")
        bump_version('1.2.3')
    except ValueError as exc:
        print("Failed")
        print(exc)
    else:
        print("Success")
    print("==================")
    try:
        print("bump_version('3.0.11')")
        bump_version('3.0.11')
    except ValueError as exc:
        print("Failed")
        print(exc)

# Generated at 2022-06-29 18:10:19.828800
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:32.745801
# Unit test for function bump_version
def test_bump_version():
    this_version = '0.2.0'
    version = bump_version(this_version)
    assert version == '0.3.0'

    version = bump_version(this_version, 1, 'a')
    assert version == '0.3.0'

    this_version = '0.2.7'
    version = bump_version(this_version, 1, 'b')
    assert version == '0.3.0b0'
    version = bump_version(this_version, 1)
    assert version == '0.3.0'
    version = bump_version(this_version)
    assert version == '0.2.8'
    version = bump_version(this_version, 2)
    assert version == '0.2.8'

# Generated at 2022-06-29 18:10:53.179555
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.0.0a0'
    assert bump_version('1.0.0', 1, 'b') == '1.0.0b0'
    assert bump_version('1.0.0a1', 1, 'a') == '1.0.0a2'

# Generated at 2022-06-29 18:11:05.314225
# Unit test for function bump_version
def test_bump_version():
    from pkg_resources import parse_version
    from pkg_resources import parse_requirements
    from pkg_resources import Requirement

    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0a0') == '1.0.1a0'
    assert bump_version('1.0.0b0') == '1.0.1b0'
    assert bump_version('1.0.0a1') == '1.0.1a1'
    assert bump_version('1.0.0b1') == '1.0.1b1'
    assert bump_version('1.0.0', 0) == '2.0.0'

# Generated at 2022-06-29 18:11:17.972184
# Unit test for function bump_version
def test_bump_version():
    import sys
    import traceback
    from textwrap import dedent
    from os.path import dirname, abspath, join

# Generated at 2022-06-29 18:11:30.407633
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:42.416019
# Unit test for function bump_version
def test_bump_version():
    # Major version
    assert bump_version("1.0.0") == "2.0.0"
    assert bump_version("1.1.0") == "2.0.0"
    assert bump_version("1.1.1") == "2.0.0"
    assert bump_version("1.0.0", position=0) == "2.0.0"
    assert bump_version("1.1.0", position=0) == "2.0.0"
    assert bump_version("1.1.1", position=0) == "2.0.0"
    assert bump_version("1.0.0", position=-3) == "2.0.0"
    assert bump_version("1.1.0", position=-3) == "2.0.0"

# Generated at 2022-06-29 18:11:51.493271
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', 2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='alpha') == '1.2.4a0'
    assert bump_version('1.2.3', 2, pre_release='alpha') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-29 18:12:04.390932
# Unit test for function bump_version
def test_bump_version():
    print("\nUnit test for function 'bump_version':")
    print("- Test case 1: 'bump_version('0.2.3')'")
    print("- Expected: '0.2.4'")
    print("- Actual  : '%s'" % bump_version('0.2.3'))

    print("\n- Test case 1: 'bump_version('1.2.0a2')'")
    print("- Expected: '1.2.0a3'")
    print("- Actual  : '%s'" % bump_version('1.2.0a2'))

    print("\n- Test case 1: 'bump_version('1.2.0a3', pre_release='b')'")

# Generated at 2022-06-29 18:12:17.256277
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises

    # Testing invalid positions
    with raises(ValueError):
        bump_version('0.0.0', position=3)
    with raises(ValueError):
        bump_version('0.0.0', position=-4)

    # ----
    # MAJOR
    # ----
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('1.9.9') == '2.0.0'
    assert bump_version('1.9.9', position=0) == '2.0.0'

    # ------
    # MINOR
    # ------

# Generated at 2022-06-29 18:12:26.532207
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version, 0) == '2.0.0'
    assert bump_version(version, 1) == '1.3.0'
    assert bump_version(version, 2) == '1.2.4'
    assert bump_version(version, -1) == '1.2.4'
    assert bump_version(version, -2) == '1.3.0'
    assert bump_version(version, -3) == '2.0.0'

    version = '1.2.3-alpha.0'
    assert bump_version(version, 0) == '2.0.0'
    assert bump_version(version, 1) == '1.3.0'
    assert bump_version(version, 2) == '1.2.4'

# Generated at 2022-06-29 18:12:38.160602
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0a0') == '1.0.1'
    assert bump_version('1.0.0a1') == '1.0.0a2'
    assert bump_version('1.0.0b0') == '1.0.1'
    assert bump_version('1.0.0b1') == '1.0.0b2'

    # Test position argument
    assert bump_version('1.0.0', position=0) == '2.0.0'

# Generated at 2022-06-29 18:12:55.794324
# Unit test for function bump_version
def test_bump_version():
    def test(
            version_in: str,
            version_out: str,
            version_bump: int,
            pre_release: Union[str, None] = None
    ):
        version = bump_version(
            version_in,
            position=version_bump,
            pre_release=pre_release
        )
        assert version == version_out

    test('1.2.3', '2.0.0', 0)
    test('1.0.0', '1.1.0', 2)
    test('1.0.0', '1.0.1', 4)
    test('1.0.0-alpha1', '1.0.0', -1)
    test('1.0.0-alpha1', '1.1.0-alpha0', -2)

# Generated at 2022-06-29 18:13:06.876255
# Unit test for function bump_version
def test_bump_version():
    # bump_version should bump version number with string input
    assert bump_version('1.0.0a0') == '1.0.0a1'
    assert bump_version('1.0.0a1') == '1.0.0a2'
    assert bump_version('1.0.0a2') == '1.0.0a3'
    assert bump_version('1.0.0b0') == '1.0.0b1'
    assert bump_version('1.0.0b1') == '1.0.0b2'
    assert bump_version('1.0.0b2') == '1.0.0b3'
    assert bump_version('1.0.0') == '1.0.1'

# Generated at 2022-06-29 18:13:17.746482
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:29.437645
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.0') == '1.2.0'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.2.0', position=-3) == '2.0.0'

# Generated at 2022-06-29 18:13:40.005817
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', pre_release='b') == '0.1.0b0'
    assert bump_version('0.1.0b5', pre_release='b') == '0.1.0b6'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.0', 1) == '1.2.0'
    assert bump_version('1.2.0', 1, 'a') == '1.2.0a0'

# Generated at 2022-06-29 18:13:48.480173
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version"""

    def test_it(version: str, position: int, pre_release: Optional[str],
                expected_output: str):
        """Generate and compare test cases"""
        if expected_output is None:
            expected_output = version
        output = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        if output != expected_output:
            msg = "Failed test case: v_{1}_b_{2}_p_{3}"
            msg = msg.format(version, position, pre_release)
            raise AssertionError(msg)

    # Setup test cases

# Generated at 2022-06-29 18:14:01.780152
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:11.424430
# Unit test for function bump_version
def test_bump_version():
    version = "1.2.3"
    assert bump_version(version) == "1.2.4"

    version = "1.2.3"
    assert bump_version(version, position=0) == "2.0.0"

    version = "1.2.3"
    assert bump_version(version, position=1) == "1.3.0"

    version = "0.0.0"
    assert bump_version(version) == "0.0.1"

    version = "0.0.0"
    assert bump_version(version, position=0) == "1.0.0"

    version = "0.0.0"
    assert bump_version(version, position=1) == "0.1.0"

    version = "1.2.3a0"

# Generated at 2022-06-29 18:14:23.477981
# Unit test for function bump_version
def test_bump_version():
    # bump_version(version, position=2, pre_release=None)
    func = bump_version
    # pylint: disable=W0613
    def func_wrapper(args, kwargs):
        return func(*args, **kwargs)


# Generated at 2022-06-29 18:14:34.013828
# Unit test for function bump_version
def test_bump_version():
    tested_version_tuple = ('0.0.1', '0.0.2', '1.0.0', '1.0.1', '1.1.0', '1.1.1alpha0', '1.1.1a0', '1.1.1a1', '1.1.1alpha1', '1.1.1b0', '1.1.1beta0', '1.1.1beta1', '1.1.1beta2', '2.0.0', '2.0.1alpha0', '2.0.1beta0', '2.0.1a0', '2.0.1b0', '2.0.1a1', '2.0.1b1')
    tested_method_name = 'bump_version'

# Generated at 2022-06-29 18:14:54.060902
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:05.264200
# Unit test for function bump_version
def test_bump_version():
    version1 = '0.0.0'
    version2 = '0.0.1'
    version3 = '0.1.0'
    version4 = '0.1.0a0'
    version5 = '0.1.5a0a0'
    version6 = '0.1.5a0'
    version7 = '0.1.5'
    version8 = '0.1.5a'
    version9 = '0.1.5b'
    version10 = '0.1.5a0b0'
    print("version: ", version10)
    print("bump_version(version, 0, None): ", bump_version(version10, 0, None))
    print("bump_version(version, 0): ", bump_version(version10, 0))

# Generated at 2022-06-29 18:15:15.175035
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3a0') == '1.2.3a1'
    assert bump_version('1.2.3b0') == '1.2.3b1'
    assert bump_version('1.2.3b0', 1) == '1.3.0b0'
    assert bump_version('1.2.3b0', 1, 'b') == '1.3.0b0'
    assert bump_version('1.2.3b0', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.3b0', 0) == '2.0.0b0'
    assert bump_version('1.2.3b0', 0, 'b') == '2.0.0b0'
    assert bump_version

# Generated at 2022-06-29 18:15:26.849792
# Unit test for function bump_version
def test_bump_version():
    # "0.0.0"
    assert bump_version("0.0.0") == "0.0.1"

    # "0.0.1"
    assert bump_version("0.0.1") == "0.0.2"

    # "0.0.2"
    assert bump_version("0.0.2") == "0.0.3"

    # "0.1.0"
    assert bump_version("0.1.0") == "0.2.0"

    # "1.0.0"
    assert bump_version("1.0.0") == "2.0.0"

    # "0.0.1-alpha"
    assert bump_version("0.0.1-alpha") == "0.0.2"

    # "0.0.1-

# Generated at 2022-06-29 18:15:31.827442
# Unit test for function bump_version
def test_bump_version():
    for version in ['2.2.4', '2.4', '3.0beta3', '3.0']:
        bump_version_up = bump_version(version)
        bump_version_down = bump_version(version, -1)
        print('%s -> %s' % (version, bump_version_up))
        print('%s -> %s' % (version, bump_version_down))

test_bump_version()

# Generated at 2022-06-29 18:15:44.319670
# Unit test for function bump_version
def test_bump_version():
    # Test basic major/minor/patch/pre-release bumping
    assert bump_version("1.2.0") == "1.2.1"
    assert bump_version("1.2.0", 0) == "2.0.0"
    assert bump_version("1.2.0", 1) == "1.3.0"
    assert bump_version("1.2.0", 2) == "1.2.1"
    assert bump_version("1.2.0", -1) == "1.2.1"
    assert bump_version("1.2.0", -2) == "1.3.0"
    assert bump_version("1.2.0", -3) == "2.0.0"

# Generated at 2022-06-29 18:15:46.082519
# Unit test for function bump_version
def test_bump_version():
    from .test_bump_version import test_bump_version
    test_bump_version()

# Generated at 2022-06-29 18:15:56.071967
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Union[str, None],
            expected: str
    ) -> None:
        out = bump_version(version, position, pre_release)
        assert out == expected, (
            "The following version bump has failed:\n"
            "  Version: %r\n"
            "  Position: %r\n"
            "  Pre-Release: %r\n"
            "  Expected: %r\n"
            "  Got: %r\n" % (version, position, pre_release, out, expected)
        )
    _test_bump_version('1.2.3', 0, None, '2.0.0')

# Generated at 2022-06-29 18:16:07.983445
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1'
    assert bump_version('1.0.0', 2, 'c') == '1.0.1'

    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0.0', 1, 'b') == '1.1b0'

# Generated at 2022-06-29 18:16:16.713507
# Unit test for function bump_version
def test_bump_version():
    assert '2.0.0' == bump_version('1.3.9')
    assert '1.4.0' == bump_version('1.3.9', 1)
    assert '1.4.0' == bump_version('1.4.0', 1)
    assert '1.4.0' == bump_version('1.4.0', 1)
    assert '1.4' == bump_version('1.3.0', 1)
    assert '1.3.10' == bump_version('1.3.9', 2)
    assert '1.3.0a0' == bump_version('1.3.0', 2, 'a')
    assert '1.3.0a1' == bump_version('1.3.0a0', 2, 'a')