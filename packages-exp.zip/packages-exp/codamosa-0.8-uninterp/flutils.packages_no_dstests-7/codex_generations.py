

# Generated at 2022-06-29 18:06:46.529578
# Unit test for function bump_version
def test_bump_version():
    # New Lines
    newline = "\r\n"
    # Output Headers
    header_a = "Output"
    header_b = "Version"
    header_c = "Position"
    header_d = "Pre-Release"
    # Input Headers
    header_e = "Input"
    header_f = "Version"
    header_g = "Position"
    header_h = "Pre-Release"
    # Test Output
    test_output = "Test Results"
    # Test Results
    test_result_pass = "PASS"
    test_result_fail = "FAIL"
    # Test Count
    test_num = 1
    # Result Count
    results_pass = 0
    results_fail = 0

    # Test Data

# Generated at 2022-06-29 18:06:49.479333
# Unit test for function bump_version
def test_bump_version():
    # Bump the version number
    version = '0.3.3'
    # Bump the beta version number
    version = bump_version(version, 2, 'b')
    print(version)


# test_bump_version()

# Generated at 2022-06-29 18:06:59.407984
# Unit test for function bump_version
def test_bump_version():
    """Tests the bump_version function to ensure the correct version number
    is returned for a specific version number, position and pre-release."""

    # Test Type:
    #   Simple bump, 3 positions, normal version numbers
    test_ver = ['1.0.0', '0.1.0', '3.3.3']
    test_pos = [0, 1, 2]
    test_ver_exp = ['2.0.0', '0.2.0', '3.3.4']
    test_type = 'Simple bump, 3 positions, normal version numbers'
    test_type_id = 0
    test_type_count = 9

    # Test Type:
    #   Simple bump, 3 positions, with pre-release numbers

# Generated at 2022-06-29 18:07:10.915221
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:22.133832
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915

    def test_case(source, position, pre_release, expected):
        """Testing bump version."""
        msg = (
            "Calling: bump_version(%r, %r, %r), "
            "expect (%r), got (%r)"
        )
        result = bump_version(
            source,
            position=position,
            pre_release=pre_release
        )
        assert result == expected, msg % (
            source, position, pre_release, expected, result
        )

    test_case('0.0.0', pre_release='a', expected="0.0.0a0")
    test_case('0.0.0', pre_release='alpha', expected="0.0.0a0")

# Generated at 2022-06-29 18:07:32.413641
# Unit test for function bump_version
def test_bump_version():
    from sys import version_info


# Generated at 2022-06-29 18:07:44.642151
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = bump_version('1.1.0')
    assert version == '1.1.1'
    version = bump_version('1.1.0', pre_release='a')
    assert version == '1.1.1a0'
    version = bump_version('1.1.0', pre_release='A')
    assert version == '1.1.1a0'
    version = bump_version('1.1.0', pre_release='alpha')
    assert version == '1.1.1a0'
    version = bump_version('1.1.0', pre_release='Alpha')
    assert version == '1.1.1a0'
    version = bump_version('1.1.0', pre_release='a')

# Generated at 2022-06-29 18:07:54.113240
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:06.977200
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:15.620937
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.1') == '0.2.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('0.0.8b1') == '0.0.8b2'
    assert bump_version('0.0.8a2') == '0.0.8a3'

# Generated at 2022-06-29 18:08:45.304008
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import os

    def _get_test_version(
            position: int,
            pre_release: Union[str, None]
    ) -> str:
        """Helper function used by function
        :func:`test_bump_version`
        """
        data = dict(
            version='test.test',
            position=position,
            pre_release=pre_release
        )
        jsonf_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test-version.json'
        )
        with open(jsonf_path, 'w') as jsonf:
            json.dump(data, jsonf)

        version = bump_version(**data)

# Generated at 2022-06-29 18:08:55.785687
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""

# Generated at 2022-06-29 18:09:07.090773
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version.
    """
    import json
    import os
    import sys
    test_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(test_dir, 'version_number_bump_data.json')) as fp:
        data = json.load(fp)

    for ver in data:
        for bump_object in data[ver]:
            for bump_type in bump_object:
                hold = bump_version(
                    ver,
                    bump_object[bump_type]['position'],
                    bump_object[bump_type]['pre_release']
                )
                # fmt: off

# Generated at 2022-06-29 18:09:19.564379
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the function bump_version."""
    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        ver_info = _build_version_info(version)
        position = _build_version_bump_position(position)
        bump_type = _build_version_bump_type(position, pre_release)
        out = bump_version(version, position, pre_release)
        ver_info_out = _build_version_info(out)

        # Check the position of the bump.
        if bump_type in _BUMP_VERSION_MINORS:
            assert ver_info_out.minor.pos == position

# Generated at 2022-06-29 18:09:32.662597
# Unit test for function bump_version
def test_bump_version():
    def test_bump_version_sub(
            version: str,
            position: int,
            pre_release: Union[str, None],
            expected: str
    ) -> None:
        actual = bump_version(version, position, pre_release)

# Generated at 2022-06-29 18:09:34.598436
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    out = bump_version(version)
    print("The version is: {}".format(out))


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:09:44.793269
# Unit test for function bump_version
def test_bump_version():
    import pytest


# Generated at 2022-06-29 18:09:57.465633
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function bump_version"""
    assert(bump_version('1.0') == '1.1')
    assert(bump_version('1.2') == '1.3')
    assert(bump_version('1.2.3') == '1.2.4')
    assert(bump_version('1.0.0') == '1.1')
    assert(bump_version('1.0.1') == '1.1')
    assert(bump_version('1.0.1', pre_release='a') == '1.1a0')
    assert(bump_version('1.1a2', pre_release='a') == '1.1a3')

# Generated at 2022-06-29 18:10:04.378662
# Unit test for function bump_version
def test_bump_version():
    # Bumping the 'major' version number
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('1.2.3') == '2.0.0'
    # Bumping the 'minor' version number
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'

# Generated at 2022-06-29 18:10:17.378337
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.2.2') == '0.2.3'
    assert bump_version('1.1.1') == '1.1.2'

    assert bump_version('0.0.0', pre_release='a') == '0.0.0.a0'
    assert bump_version('0.0.0', pre_release='b') == '0.0.0.b0'
    assert bump_version('0.0.0.a0', pre_release='a') == '0.0.0.a1'
   

# Generated at 2022-06-29 18:10:32.990273
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from tests import version_test_data
    for version_test in version_test_data.version_test_data:
        for i in range(-3, 3):
            for prerelease in (None, 'alpha', 'beta'):
                if i == 0 and prerelease not in (None, 'alpha', 'beta'):
                    continue
                if i == 1 and prerelease not in (None, 'alpha', 'beta'):
                    continue
                if i == 2 and prerelease is not None:
                    continue
                if (i == -1 or i == -2) and prerelease not in (None, 'alpha'):
                    continue
                if (i == -3) and prerelease not in (None, 'beta'):
                    continue

# Generated at 2022-06-29 18:10:34.230445
# Unit test for function bump_version
def test_bump_version():
    from tests.unit.test_version import test_bump_version
    test_bump_version(bump_version)


# Generated at 2022-06-29 18:10:42.963348
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:55.413405
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Unit test for function bump_version."""
    # pylint: disable=C0301

# Generated at 2022-06-29 18:11:06.983778
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3.0a0'
    assert bump_version('1.2.3', position=0, pre_release='a') == '2.0.0a0'
    assert bump_

# Generated at 2022-06-29 18:11:20.661555
# Unit test for function bump_version
def test_bump_version():
    """Unit-test bump_version()."""

    # noinspection SpellCheckingInspection
    def test_bump_version_helper(
        version: str,
        position: int = 2,
        pre_release: Optional[str] = None
    ) -> None:
        """Unit test function.

        Args:
            version (str): The version number to be bumped.
            position (int, optional): The position (starting with zero) of the
                version number component to be increased.  Defaults to: ``2``
            pre_release (str, Optional): A value of ``a`` or ``alpha`` will
                create or increase an alpha version number.  A value of ``b``
                or ``beta`` will create or increase a beta version number.

        """

# Generated at 2022-06-29 18:11:25.503813
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.1.1', position=1) == '0.2.0'
    assert bump_version('0.1.1', position=-3) == '1.0.1'
    assert bump_version('0.1.1', position=0) == '1.0.1'
    assert bump_version('0.1.0', position=1, pre_release='a') == '0.2.0a0'

# Generated at 2022-06-29 18:11:31.998840
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1.0'
    assert bump_version('0.0.0', 1, 'alpha') == '0.1.0'

# Generated at 2022-06-29 18:11:34.609141
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1') == '0.2'

test_bump_version()

# Generated at 2022-06-29 18:11:45.657414
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    # pylint: disable=R0914
    # pylint: disable=C0116
    # pylint: disable=W0107
    # pylint: disable=C0115
    TEST_VERSION = {
        'version': '2.0.0',
        'major': 2,
        'minor': 0,
        'patch': 0,
    }


# Generated at 2022-06-29 18:11:59.713379
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.0a0') == '0.0.0a1'
    assert bump_version('0.0.0a1') == '0.0.0a2'
    assert bump_version('0.0.0b0') == '0.0.0b1'
    assert bump_version('0.0.0b1') == '0.0.0b2'
    assert bump_version('0.0.1a2') == '0.0.1a3'

# Generated at 2022-06-29 18:12:12.457389
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:22.055404
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from . import base
    from . import util
    from . import test_helper

    # Setup the test_mode argument
    test_mode = test_helper.update_test_mode()

    # Setup arguments
    args: Dict[str, Any] = {
        'version_arg': '0.1.0'
    }

    # Execute the target function
    result = bump_version(
        args['version_arg']
    )

    # assert that no exception was raised
    assert True is True, 'Assertion did not pass'

    # Return the result to the test function
    return result



# Generated at 2022-06-29 18:12:29.261855
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: bump_version')
    print('\tv1.2.3 to v1.2.4:', end=' ')
    print(bump_version('1.2.3', position=2))
    print('\tv1.2.3 to v1.3.3:', end=' ')
    print(bump_version('1.2.3', position=1))
    print('\tv1.2.3-b2 to v1.2.4:', end=' ')
    print(bump_version('1.2.3-b2', position=2))
    print('\tv1.2.3 to v2.2.3:', end=' ')
    print(bump_version('1.2.3', position=0))

# Generated at 2022-06-29 18:12:41.863151
# Unit test for function bump_version
def test_bump_version():
    # Test bump_version with no pre-release
    test_version_increase_no_pre_release = [
        (0, "1.2.3", "2.0.0"),
        (1, "1.2.3", "1.3.0"),
        (2, "1.2.3", "1.2.4"),
        (3, "1.2.3", "1.2.3"),
        (2, "1.2.0", "1.2.1")
    ]
    for case in test_version_increase_no_pre_release:
        case_output = bump_version(case[2], case[0])
        assert case_output == case[1]

# Generated at 2022-06-29 18:12:53.403083
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2, 'a') == '1.2.3a1'
    assert bump_version('1.2.3', 2, 'alpha') == '1.2.3a1'
    assert bump_version('1.2.3', 2, 'b') == '1.2.3b1'
    assert bump_version('1.2.3', 2, 'beta') == '1.2.3b1'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3a5') == '1.2.3a6'

# Generated at 2022-06-29 18:13:02.712464
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function :func:`bump_version`"""
    # noinspection PyUnusedLocal
    def test_inc_none():
        """Raise ValueError if trying to increment a non-existent part of
        a version number.
        """
        from pyt.util.versions import bump_version
        cases = (((0, 0, 2), '0.0.1', ValueError),
                 )
        for ver, pre, expected in cases:
            args: Dict[str, Any] = {'version': ver}
            if pre is not None:
                args['pre_release'] = pre
            # noinspection PyTypeChecker
            with pytest.raises(expected):
                bump_version(**args)

    # noinspection PyUnusedLocal

# Generated at 2022-06-29 18:13:15.413333
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

# Generated at 2022-06-29 18:13:18.434894
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    print('test_bump_version')
    from .utility.test_helper import test_version
    test_version(bump_version)

# pylint: disable=R0915

# Generated at 2022-06-29 18:13:24.922443
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    def _test(version, position, pre_release, expect):
        """Test the given version, position, pre_release and expect."""
        out = bump_version(version, position, pre_release)
        if out != expect:
            raise ValueError(
                "Test failed for: %r, %r, %r - got: %r" % (
                    version, position, pre_release, out
                )
            )
    # bump_version('major')
    _test('0.0.1', 0, '', '1.0.0')
    _test('0.0.0', 0, '', '1.0.0')
    _test('1.0.1', 0, '', '2.0.0')

# Generated at 2022-06-29 18:13:48.051173
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-29 18:14:01.459510
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

    class Uut:
        """Class to test function bump_version."""

        def __init__(self, version, position, pre_release, expected_version):
            """Object initializer.
            :param str version: A version number.
            :param int position: The component of the version number to be
                increased.
            :param str pre_release: The pre-release part of the version number
                to be increased.
            :param str expected_version: The expected increased version number.
            """
            self.version = version
            self.position = position
            self.pre_release = pre_release
            self.expected_version = expected_version

        def test(self):
            """Test reference.
            :return: None
            """

# Generated at 2022-06-29 18:14:11.187310
# Unit test for function bump_version
def test_bump_version():
    print("\n=== Unit test bump_version ===")
    print("Test string: 0.1.0")
    print("Bump type: major (default)")
    print("Expected result: 1.0.0")
    print("Result:", bump_version("0.1.0"))

    print("\nTest string: 0.1.0")
    print("Bump type: minor")
    print("Expected result: 0.2.0")
    print("Result:", bump_version("0.1.0", 1))

    print("\nTest string: 0.1.0")
    print("Bump type: patch")
    print("Expected result: 0.1.1")
    print("Result:", bump_version("0.1.0", 2))


# Generated at 2022-06-29 18:14:16.736609
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=-2) == '1.3.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=0) == '1.2.3'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'

# Generated at 2022-06-29 18:14:28.540483
# Unit test for function bump_version
def test_bump_version():
    func = bump_version
    assert func('0.0.0') == '1.0.0'
    assert func('1.0.0') == '2.0.0'
    assert func('1.1.1') == '1.2.0'
    assert func('1.1.1', 1, 'b') == '1.2.0'
    assert func('1.1.1', 1, 'alpha') == '1.1.1a0'
    assert func('1.1.1', 1, 'beta') == '1.1.1b0'
    assert func('1.1.1', 1, 'a') == '1.1.1a0'
    assert func('1.1.1', 1, 'b') == '1.1.1b0'

# Generated at 2022-06-29 18:14:40.831129
# Unit test for function bump_version
def test_bump_version():

    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            result: str
    ) -> None:
        assert bump_version(
            version,
            position,
            pre_release
        ) == result

    _test_bump_version('1.0.0', 0, None, '2.0.0')
    _test_bump_version('1.5.5', 1, None, '1.6.0')
    _test_bump_version('1.5.0', 1, None, '1.6.0')
    _test_bump_version('1.5.5', -1, None, '1.5.5')

# Generated at 2022-06-29 18:14:49.717250
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:01.713732
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.1', 0, 'a') == '1.0.0'
    assert bump_version('0.2.1', 0, 'alpha') == '1.0.0'
    assert bump_version('0.2.1', 0) == '1.0.0'
    assert bump_version('0.2.1', 0, None) == '1.0.0'
    assert bump_version('0.2.1', 1, 'alpha') == '0.3.0a0'
    assert bump_version('0.2.1', 1, 'a') == '0.3.0a0'
    assert bump_version('0.2.1', 1) == '0.3.0'

# Generated at 2022-06-29 18:15:10.182118
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:22.529268
# Unit test for function bump_version
def test_bump_version():
    ver = '0.1.1'
    out = bump_version(ver)
    assert out == '0.1.2', 'Wrong bump for %r' % ver

    ver = '1.1.0'
    out = bump_version(ver)
    assert out == '1.1.1', 'Wrong bump for %r' % ver

    ver = '1.0.0'
    out = bump_version(ver, 1)
    assert out == '1.1.0', 'Wrong bump for %r' % ver

    ver = '2.0.0b2'
    out = bump_version(ver)
    assert out == '2.0.0b3', 'Wrong bump for %r' % ver

    ver = '3.0.1a1'

# Generated at 2022-06-29 18:15:46.127991
# Unit test for function bump_version
def test_bump_version():

    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.0.1") == "1.0.2"
    assert bump_version("1.0.2") == "1.0.3"
    assert bump_version("0.0.0") == "0.0.1"
    assert bump_version("0.0.1") == "0.0.2"
    assert bump_version("0.0.2") == "0.0.3"
    assert bump_version("0.0.0", 1, "a") == "0.1.0a0"
    assert bump_version("0.0.0", 1, "b") == "0.1.0b0"

# Generated at 2022-06-29 18:15:56.081609
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0'  # Bump minor alpha
    assert bump_version('1.0.0', 1, 'A') == '1.1.0'  # Bump minor alpha
    assert bump_version('1.0.0', 1, 'b') == '1.1.0'  # Bump minor beta
    assert bump_version('1.0.0', 1, 'B') == '1.1.0'  # Bump minor beta
    assert bump_version('1.0.0', 2, 'a') == '1.0.1'  # Bump

# Generated at 2022-06-29 18:16:07.983099
# Unit test for function bump_version
def test_bump_version():
    version = bump_version("1.4.0")
    assert version == "1.4.1"
    version = bump_version("1.4.0", 0)
    assert version == "2.0.0"
    version = bump_version("1.4.0", 0, "a")
    assert version == "2.0.0"
    version = bump_version("1.4.0", 0, "b")
    assert version == "2.0.0"
    version = bump_version("1.4.0", 1)
    assert version == "1.5.0"
    version = bump_version("1.4.0", 1, "a")
    assert version == "1.5.0a0"
    version = bump_version("1.5.0a0", 1, "a")
   