

# Generated at 2022-06-29 18:06:47.920672
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', -1) == '1.2.1'
    assert bump_version('1.2.0', -2) == '1.3.0'
    assert bump_version('1.2.0', -3) == '2.0.0'
    assert bump_version('1.2b1') == '1.2b2'

# Generated at 2022-06-29 18:06:57.216673
# Unit test for function bump_version
def test_bump_version():
    # Test defaults
    assert bump_version('1.2.3') == '1.2.4'

    # Test position number
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.3.0'
    assert bump_version('1.2.3', position=-2) == '2.0.0'

    # Test pre-release
    assert bump_version('1.2.3', pre_release='a') == '1.3.0a0'

# Generated at 2022-06-29 18:07:08.776455
# Unit test for function bump_version
def test_bump_version():
    import pytest
    assert bump_version('v1') == 'v2'
    assert bump_version('v1.2') == 'v1.3'
    assert bump_version('v1.2.3') == 'v1.2.4'
    assert bump_version('v1.2.0') == 'v1.2.1'
    assert bump_version('v1.2.0-a1') == 'v1.2.0-a2'
    assert bump_version('v1.2.0-b1') == 'v1.2.0-b2'
    assert bump_version('v1.2.3-a1') == 'v1.2.3-a2'

# Generated at 2022-06-29 18:07:20.050885
# Unit test for function bump_version
def test_bump_version():
    _version = '0.0.0'
    _bumped = bump_version(_version, 0)
    assert _bumped == '1.0.0'
    _bumped = bump_version(_version, 0, 'b')
    assert _bumped == '1.0.0'
    _bumped = bump_version(_version, 1)
    assert _bumped == '0.1.0'
    _bumped = bump_version(_version, 1, 'b')
    assert _bumped == '0.1.0b0'
    _bumped = bump_version(_version, 2)
    assert _bumped == '0.0.1'
    _bumped = bump_version(_version, 2, 'b')
    assert _bumped == '0.0.1b0'
    _bumped = bump

# Generated at 2022-06-29 18:07:26.842453
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:38.680558
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.3.0') == '0.3.1'
    assert bump_version('0.3.0', pre_release='a') == '0.4.0a0'
    assert bump_version('0.3.0a0') == '0.4.0'
    assert bump_version('0.3.0a0', position=1) == '0.4.0'
    assert bump_version('0.3.0a0', position=1, pre_release='a') == \
        '0.3.0a1'
    assert bump_version('0.3.0', position=1, pre_release='a') == '0.4.0a0'
    assert bump_version('0.3.0a0', position=0) == '1.0.0'
   

# Generated at 2022-06-29 18:07:50.227902
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function
    """
    # assert bump_version('1.5.0.0') == '1.5.0.1'
    # assert bump_version('1.5.0.0', 3) == '1.5.0.1'
    # assert bump_version('1.5.0.0', -1) == '1.5.0.1'
    # assert bump_version('1.5.0.0', -2) == '1.5.1.0'
    # assert bump_version('1.5.0.0', -3) == '1.6.0.0'

    # assert bump_version('1.5.0.0', pre_release='a') == '1.5.0.0a0'
    # assert bump_version('1.5.0.

# Generated at 2022-06-29 18:07:57.057546
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:00.902210
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function."""
    assert bump_version('0.0.0') == '0.0.1'


# Generated at 2022-06-29 18:08:11.443330
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2') == '1.2.0'
    assert bump_version('1.2.3.4') == '1.2.4'

    assert bump_version('0.3') == '0.4'
    assert bump_version('0.3.4') == '0.4'
    assert bump_version('0.3', 1) == '1.0'
    assert bump_version('0.3.4', 1) == '1.1'
    assert bump_version('0.3', 0) == '1.0.0'

# Generated at 2022-06-29 18:08:42.680430
# Unit test for function bump_version
def test_bump_version():
    global _FIND_VERSION_ORDER

    _find_version_order()

    def _do_test(ver, pos, pre, exp):
        """Run a test

        :param ver: The version number to be bumped.
        :param pos: The version number to be bumped.
        :param pre: The prerelease value.
        :param exp: The expected value.
        """
        act_ver = _bump_version(ver, position=pos, pre_release=pre)
        assert act_ver == exp, (
            'Expected: %r Got: %r' % (exp, act_ver)
        )


# Generated at 2022-06-29 18:08:48.923546
# Unit test for function bump_version
def test_bump_version():
    input_dict = {
        'version': '0.9.8',
        'position': 2,
        'pre_release': None,
        'expected': '0.9.9'
    }
    output = bump_version(**input_dict)
    assert output == input_dict['expected']

# Generated at 2022-06-29 18:08:57.129788
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', 0) == '1.0.0'
    assert bump_version('0.2.0', 1) == '0.3.0'
    assert bump_version('0.2.0', 1, 'a') == '0.3.0'
    assert bump_version('0.2.0', 1, 'b') == '0.3.0'
    assert bump_version('0.2.0', 2, 'a') == '0.2.1'
    assert bump_version('0.2.0', 2, 'b') == '0.2.1'
    assert bump_version('0.2.0', -1, 'a') == '0.2.1'
   

# Generated at 2022-06-29 18:09:08.548166
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:20.522292
# Unit test for function bump_version
def test_bump_version():
    version = '0.3.3'
    assert bump_version(version) == '0.3.4'
    assert bump_version(version, 1, 'a') == '0.4.0a0'
    assert bump_version(version, 1, 'alpha') == '0.4.0a0'
    assert bump_version(version, 1, 'b') == '0.4.0b0'
    assert bump_version(version, 1, 'beta') == '0.4.0b0'
    assert bump_version(version, 0) == '1.0.0'
    assert bump_version(version, position=0) == '1.0.0'
    assert bump_version(version, position=1, pre_release='alpha') == '0.4.0a0'

    # Error cases
   

# Generated at 2022-06-29 18:09:33.286164
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    from .testing_utils import build_test_function


# Generated at 2022-06-29 18:09:44.110689
# Unit test for function bump_version
def test_bump_version():
    import sys

    def assert_equal(a, b):
        if a == b:
            return
        raise AssertionError('a=%s b=%s' % (a, b))

# Generated at 2022-06-29 18:09:56.798023
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:07.295904
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('0.0.2')=='0.0.3')
    assert(bump_version('0.0.2',position=1)=='0.1.0')
    assert(bump_version('0.0.2',position=0)=='1.0.0')
    assert(bump_version('0.0.2',position=0,pre_release='A')=='0.1.0')
    assert(bump_version('0.0.2',position=0,pre_release='B')=='0.1.0')
    assert(bump_version('0.0.2',position=1,pre_release='B')=='0.1.0')

# Generated at 2022-06-29 18:10:19.576826
# Unit test for function bump_version
def test_bump_version():                            # nopep8
    """Unit test for function bump_version from module sandbox_utils.bump_version"""

# Generated at 2022-06-29 18:10:38.239240
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    this_module = sys.modules[__name__]
    version_func = getattr(this_module, 'bump_version')
    this_module = sys.modules[__name__]
    version_func = getattr(this_module, 'bump_version')

# Generated at 2022-06-29 18:10:44.639585
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    def _run_test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ):
        actual = bump_version(version, position, pre_release)
        print(
            '{} --> {}'.format(
                version,
                actual
            )
        )
        assert expected == actual

    _run_test('1.2.3', 0, None, '2.0.0')
    _run_test('0.0.0', 0, None, '1.0.0')
    _run_test('0.0.0', 1, None, '0.1.0')
    _run_test('0.0.0', 2, None, '0.0.1')
    _run_test

# Generated at 2022-06-29 18:10:56.797364
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    def _test_version(version: str, position: int, pre_release: str):
        new_ver = bump_version(version, position=position, pre_release=pre_release)
        print('Versions: {!r} -> {!r}'.format(version, new_ver))

    _test_version('2.0.0-a0', 1, 'a')
    _test_version('2.0.0-a0', 2, 'a')
    _test_version('2.0.0-a0', -2, 'a')
    _test_version('2.0.0-a0', -1, 'a')
    _test_version('2.0.0-a0', 0, 'a')

# Generated at 2022-06-29 18:11:08.102980
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('1.0.2') == '1.0.3'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('0.0.0', pre_release='a') == '0.1.0a0'
    assert bump_version('0.0.0', pre_release='b') == '0.1.0b0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0.0'

# Generated at 2022-06-29 18:11:21.102494
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:25.493021
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version
    """
    out = bump_version('0.0.0')
    assert out == '0.0.1'



# pylint:disable=missing-function-docstring

# Generated at 2022-06-29 18:11:38.013654
# Unit test for function bump_version
def test_bump_version():
    """Testing function 'bump_version'."""
    from sys import version_info as py_version

    if py_version < (3, 3):
        from unittest2 import TestCase, main
    else:
        from unittest import TestCase, main

    class TestBumpVersion(TestCase):
        """Extend :class:`unittest.TestCase` for testing function
        'bump_version'."""

        def test_bump_version_00(self):
            """
            Test the function with a valid version.

            """
            self.assertEqual(bump_version('2.2.2'), '2.2.3')

        def test_bump_version_01(self):
            """
            Test the function with an invalid version.

            """
            # noinspection PyTypeChecker,Py

# Generated at 2022-06-29 18:11:48.153954
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version"""
    major = bump_version('0.1.2', position=0)
    assert major == '1.0.0', major
    major = bump_version('1.1.2', position=0)
    assert major == '2.0.0', major

    minor = bump_version('1.1.2', position=1)
    assert minor == '1.2.0', minor

    patch = bump_version('1.1.2', position=2)
    assert patch == '1.1.3', patch

    minor = bump_version('1.1', position=1)
    assert minor == '1.2.0', minor

    minor = bump_version('1.1a0', position=1)
    assert minor == '1.2.0', minor

    minor = bump_

# Generated at 2022-06-29 18:11:54.429982
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""

    def test_one(
            ver,
            pos,
            pre,
            exp
    ):
        """Test one version."""
        val = bump_version(ver, pos, pre)
        if val != exp:
            test_case.fail('%r != %r' % (val, exp))

    test_case = TestCase()
    test_one('0.0.0', 0, None, '1.0.0')
    test_one('0.0.0', 1, None, '0.1.0')
    test_one('0.0.0', 2, None, '0.0.1')
    test_one('2.4.1', -2, None, '2.4.2')

# Generated at 2022-06-29 18:12:05.951735
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function bump_version."""
    assert bump_version(
        version='0.1.0',
        position=2,
        pre_release='alpha'
    ) == '0.1.0a0'
    assert bump_version(
        version='1.2.3',
        position=2,
        pre_release='beta'
    ) == '1.2.3b0'
    assert bump_version(
        version='10.20.30',
        position=2,
        pre_release='alpha'
    ) == '10.20.31a0'
    assert bump_version(
        version='10.20.30',
        position=2,
        pre_release='beta'
    ) == '10.20.31b0'

# Generated at 2022-06-29 18:12:23.825335
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3'
    new_ver = bump_version(ver, 0, 'a')
    assert new_ver == '2.0.0'

    ver = '1.2.3'
    new_ver = bump_version(ver, 0, 'b')
    assert new_ver == '2.0.0'

    ver = '1.2.3'
    new_ver = bump_version(ver, 0)
    assert new_ver == '2.0.0'

    ver = '1.2.3'
    new_ver = bump_version(ver, 0, 'alpha')
    assert new_ver == '2.0.0'

    ver = '1.2.3'
    new_ver = bump_version(ver, 0, 'beta')

# Generated at 2022-06-29 18:12:34.801705
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    from .simple_test_functions import (
        simple_test_function,
        TestFunctionReturn
    )

    from .simple_test_functions import TestValue

    def test_value_to_str(test_value: TestValue) -> str:
        return '%r, position=%r, pre_release=%r' % (
            test_value.version,
            test_value.position,
            test_value.pre_release
        )


# Generated at 2022-06-29 18:12:47.119045
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys
    import pathlib
    import re
    # Check if we're running on Python 3.6+
    if sys.version_info < (3, 6):
        print('Python 3.6+ is required.')
        return
    # Get the location of the unit test script and modify
    # it so we can reach the `tests` directory
    test_dir = pathlib.Path(__file__).absolute()
    test_dir = test_dir.parent.joinpath('tests')
    sys.path.insert(0, str(test_dir))
    from _testing_utils import (  # pylint: disable=E0611,E0401
        run_unit_tests,
        UnitTest,
    )
    # Run the unit tests

# Generated at 2022-06-29 18:12:49.956826
# Unit test for function bump_version
def test_bump_version():
    """Run doc tests for the 'bump_version' function."""
    import doctest
    (
        failed,
        attempted,
    ) = doctest.testmod()
    assert attempted > 0
    assert failed == 0

# Generated at 2022-06-29 18:13:00.882885
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for function bump_version."""
    from sys import version_info as python_version

    print('Python %s.%s.%s' % python_version[:3])
    print('Version: %s' % __version__)

    # Define our test versions and expected results

# Generated at 2022-06-29 18:13:13.268870
# Unit test for function bump_version
def test_bump_version():
    """Run unit test for the ``bump_version()`` function."""
    from pylint_tab import utils

# Generated at 2022-06-29 18:13:22.161313
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0', pre_release='a')
    assert version == '1.0.1a0'
    version = bump_version('1.0.1alpha1', position=-2, pre_release='a')
    assert version == '1.1a0'
    version = bump_version('1.0.0', position=-3, pre_release='b')
    assert version == '1.1b0'
    version = bump_version('1.0.0', position=-3, pre_release='b')
    assert version == '1.1b0'
    version = bump_version('1.0.0', position=-2, pre_release='b')
    assert version == '1.0.1b0'

# Generated at 2022-06-29 18:13:34.780663
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from . import versions_list, versions_list_tuples, _get_version_parts

    for ver, ver_tuple in zip(versions_list, versions_list_tuples):
        parts = _get_version_parts(ver)
        for position in range(0, len(parts)):
            out_ver = bump_version(ver, position)
            assert out_ver > ver
            out_parts = _get_version_parts(out_ver)
            if ver != out_ver:
                assert len(parts) == len(out_parts)
            if position == 0:
                assert (ver_tuple[0] + 1) == out_parts[0]
                assert out_parts[1] == 0
                assert out_parts[2] == 0

# Generated at 2022-06-29 18:13:45.391143
# Unit test for function bump_version
def test_bump_version():
    # Test a pre-release version that does not use the pre-release part
    test = bump_version('0.4.0b2')
    assert test == '0.4.0b3'
    # Test a pre-release version that does not use the pre-release part
    test = bump_version('0.4.0b2', position=2, pre_release='b')
    assert test == '0.4.0b3'
    # Test a regular version
    test = bump_version('0.4.0')
    assert test == '0.4.1'
    # Test a regular version
    test = bump_version('0.4.0', position=2, pre_release=None)
    assert test == '0.4.1'
    # Test a regular version

# Generated at 2022-06-29 18:13:58.555114
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', 2, 'alpha') == '1.2.1a0'
    assert bump_version('1.2.0', 2, 'b') == '1.2.1b0'
    assert bump_version('1.2.2', 2, 'b') == '1.2.3b0'
    assert bump_version('1.2.0.0.0', 1, 'alpha') == '1.3a0'
    assert bump_version('1.2.0.0.0', 1, 'beta') == '1.3b0'

# Generated at 2022-06-29 18:14:28.540626
# Unit test for function bump_version
def test_bump_version():

    # Test the new arguments.
    assert '0.0.1' == bump_version('0.0.0')
    assert '0.0.1' == bump_version('0.0.0', position=2)
    assert '0.0.1' == bump_version('0.0.0', position=2, pre_release=None)
    assert '0.1.0' == bump_version('0.0.0', position=1)
    assert '0.1.0' == bump_version('0.0.0', position=1, pre_release=None)
    assert '0.0.1' == bump_version('0.0.0', position=0)
    assert '0.0.1' == bump_version('0.0.0', position=0, pre_release=None)

# Generated at 2022-06-29 18:14:40.831368
# Unit test for function bump_version
def test_bump_version():
    ver = '1.0.0'
    assert bump_version(ver) == '1.0.1', "bump_version failed."
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4', "bump_version failed."
    ver = '1.2.3'
    assert bump_version(ver, pre_release='a') == '1.2.4a0', "bump_version failed."
    ver = '1.2.3'
    assert bump_version(ver, pre_release='beta') == '1.2.4b0', "bump_version failed."
    ver = '1.2.3a9'
    assert bump_version(ver) == '1.2.4', "bump_version failed."

# Generated at 2022-06-29 18:14:48.724005
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises

    # Test all the alpha and beta functions

# Generated at 2022-06-29 18:14:56.025511
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0a') == '1.1'
    assert bump_version('1.0b') == '1.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0a') == '1.0.1'
    assert bump_version('1.0.0b') == '1.0.1'
    assert bump_version('2.0.0rc') == '2.0.1'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', position=-2) == '1.1'

# Generated at 2022-06-29 18:15:07.167465
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:17.503075
# Unit test for function bump_version
def test_bump_version():
    # Test some basic conditions.
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', position=-1) == '1.1.2'
    assert bump_version('1.0.0', position=-2) == '1.1.0'
    assert bump_version('1.0.0', position=-3) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'

    # Test pre-releases.

# Generated at 2022-06-29 18:15:29.194661
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from random import choice

    from . import _unit_test_functions

    alpha_versions = [
        '',
        '0.0.0a0',
        '0.0.0a1',
        '0.0.0a3',
        '0.0.0b0',
        '0.0.0b1',
        '0.0.0b3',
        '0.0.0.0a0',
        '0.0.0.0a1',
        '0.0.0.0a3',
        '0.0.0.0b0',
        '0.0.0.0b1',
        '0.0.0.0b3',
    ]


# Generated at 2022-06-29 18:15:40.623338
# Unit test for function bump_version
def test_bump_version():
    for version in (
        '1.2.3', '1.2.3.4', '1.2.3a0', '1.2.3a1', '1.2.3a2', '1.2.3a10',
        '1.2.3b0', '1.2.3b1', '1.2.3b2', '1.2.3b10',
    ):
        assert bump_version(version) == '1.2.4'
        assert bump_version(version, 0) == '2.0.0'
        assert bump_version(version, 1) == '1.3.0'
        assert bump_version(version, 2) == '1.2.4'
        assert bump_version(version, 3) == '1.3.0'
        assert bump_version

# Generated at 2022-06-29 18:15:46.795309
# Unit test for function bump_version
def test_bump_version():
    """Run the unit tests for the 'bump_version' module."""
    from sys import version_info

    if version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    def _check(
            version: str,
            position: int,
            release: Optional[str],
            expected: str
    ) -> None:
        """Raise an exception if the unit test for 'bump_version' fails."""
        out = bump_version(version, position, release)
        if out != expected:
            raise ValueError(
                "The value from 'bump_version', %r, does not match "
                "the expected value: %r." % (out, expected)
            )


# Generated at 2022-06-29 18:15:56.603836
# Unit test for function bump_version