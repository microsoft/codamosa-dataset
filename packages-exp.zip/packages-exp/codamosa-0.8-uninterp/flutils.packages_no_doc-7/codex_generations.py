

# Generated at 2022-06-29 18:06:46.343878
# Unit test for function bump_version

# Generated at 2022-06-29 18:06:53.831228
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', 2) == '1.1.2'
    assert bump_version('1.1.1', 2,None) == '1.1.2'
    assert bump_version('1.1.1', 2, 'alpha') == '1.1.2a0'
    assert bump_version('1.1.1', 2, 'a') == '1.1.2a0'
    assert bump_version('1.1.1', 2, 'beta') == '1.1.2b0'
    assert bump_version('1.1.1', 2, 'b') == '1.1.2b0'

# Generated at 2022-06-29 18:07:04.693050
# Unit test for function bump_version
def test_bump_version():
    # Test without any preleases
    version = bump_version('1')
    assert version == '2'
    version = bump_version('1.0')
    assert version == '1.1'
    version = bump_version('1.1.0')
    assert version == '1.1.1'
    version = bump_version('1.0.0')
    assert version == '1.1'
    version = bump_version('1.1.0')
    assert version == '1.1.1'
    version = bump_version('1.1.1')
    assert version == '1.1.2'
    version = bump_version('1.0.0')
    assert version == '1.1'
    version = bump_version('1.0.0', position=0)
    assert version == '2'

# Generated at 2022-06-29 18:07:16.178482
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint

# Generated at 2022-06-29 18:07:25.852082
# Unit test for function bump_version
def test_bump_version():
    # Run tests
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert (bump_version('1.2.3', pre_release='b') == '1.2.4b0')
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('0.2.3') == '0.2.4'

# Generated at 2022-06-29 18:07:37.748629
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase, mock
    from random import sample


# Generated at 2022-06-29 18:07:49.468290
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        '1.2.3',
        position=2,
        pre_release=None
    ) == '1.2.4'
    assert bump_version(
        '1.2.3',
        position=2,
        pre_release='alpha'
    ) == '1.2.4a0'
    assert bump_version(
        '1.2.3',
        position=2,
        pre_release='beta'
    ) == '1.2.4b0'
    assert bump_version(
        '1.2.3',
        position=1,
        pre_release='alpha'
    ) == '1.3.0a0'

# Generated at 2022-06-29 18:07:56.959124
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('1.2.4')
    assert ver == '1.2.5'

    ver = bump_version('1.2.4', pre_release='b')
    assert ver == '1.2.4b0'

    ver = bump_version('1.2.4a2')
    assert ver == '1.2.4a3'

    ver = bump_version('1.2.4a2', pre_release='b')
    assert ver == '1.2.4b0'

    ver = bump_version('1.2.4b1')
    assert ver == '1.2.4b2'

    ver = bump_version('1.2.4b1', pre_release='a')
    assert ver == '1.2.5a0'


# Generated at 2022-06-29 18:08:09.852579
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:20.485602
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.2.3')=='1.2.4')
    assert(bump_version('1.2.0')=='1.2.1')
    assert(bump_version('1.2.0',1)=='1.3.0')
    assert(bump_version('1.2.0',0)=='2.0.0')
    assert(bump_version('1.2.0',0, 'a')=='2.0.0')
    assert(bump_version('1.2.3',0, 'a')=='2.0.0')
    assert(bump_version('1.2.3',0, 'b')=='2.0.0')

# Generated at 2022-06-29 18:08:54.550364
# Unit test for function bump_version
def test_bump_version():
    import unittest
    class TestBumpVersion(unittest.TestCase):

        def _test_one_pos(
                self,
                version: str,
                position: int,
                expected_version: str,
                pre_release: Optional[str] = None
        ) -> None:
            version = bump_version(
                version,
                position=position,
                pre_release=pre_release
            )
            self.assertEqual(
                version,
                expected_version,
                "For position (%s) and pre-release (%r) the expected version "
                "is (%s) but what we got was (%s)." % (
                    position,
                    pre_release,
                    expected_version,
                    version
                )
            )


# Generated at 2022-06-29 18:09:06.432524
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    def _run_test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        return bump_version(
            version,
            position=position,
            pre_release=pre_release
        )

    # Major
    assert _run_test("1.0.0") == "2.0.0"
    assert _run_test("1.0") == "2.0"

    # Minor
    assert _run_test("1.0.0", position=1) == "1.1.0"
    assert _run_test("1.0", position=1) == "1.1"

# Generated at 2022-06-29 18:09:19.012455
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=-2) == '1.3.0'
    assert bump_version('1.2.3', position=-3) == '2.0.0'

    assert bump_version('1.2.0') == '1.2.1'

# Generated at 2022-06-29 18:09:22.979381
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    position = 2
    pre_release = None
    print(bump_version(version, position, pre_release))

test_bump_version()

# Generated at 2022-06-29 18:09:36.101416
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0', pre_release='A') == '1.1.0a0'
    assert bump_version('1.0.0', pre_release='alpha') == '1.1.0a0'
    assert bump_version('1.0.0', pre_release='b') == '1.1.0b0'
    assert bump_version('1.0.0', pre_release='B') == '1.1.0b0'
    assert bump_version('1.0.0', pre_release='beta') == '1.1.0b0'
    assert bump_

# Generated at 2022-06-29 18:09:40.956598
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('2.0.0') == '2.1.0'
    assert bump_version('2.1.0') == '2.1.1'
    print("test bump_version passed.")


# Generated at 2022-06-29 18:09:47.693916
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 1, 'a') == '1.2.3'
    assert bump_version('1.2.3', 1, 'A') == '1.2.3'
    assert bump_version('1.2.3', 1, 'b') == '1.2.3'
    assert bump_version('1.2.3', 1, 'B') == '1.2.3'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0'
    assert bump_version('1.2.3', 1, 'Alpha') == '1.3.0'

# Generated at 2022-06-29 18:10:00.711389
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    def _ut(version: str, position: int, pre_release: str, out: str):
        this_out = bump_version(version, position, pre_release)
        assert this_out == out

    _ut('1.2.3', 2, None, '1.2.4')
    _ut('1.2.0', 2, None, '1.2.1')
    _ut('0.2.3', 1, None, '0.3.0')
    _ut('0.2.3', 0, None, '1.0.0')
    _ut('0.2.3', 2, 'a', '0.2.4a0')
    _ut('0.2.0', 2, 'a', '0.2.1a0')


# Generated at 2022-06-29 18:10:09.372991
# Unit test for function bump_version
def test_bump_version():
    current_version = '1.0.1'
    print(f'Current version is: {current_version}')

    print('Bump patch for the current version')
    res_v = bump_version(current_version, position=2)
    print(f'The result version is: {res_v}')
    assert res_v == '1.0.2'

    print('Bump minor for the current version')
    res_v = bump_version(current_version, position=1)
    print(f'The result version is: {res_v}')
    assert res_v == '1.1.0'

    print('Bump major for the current version')
    res_v = bump_version(current_version, position=0)
    print(f'The result version is: {res_v}')
   

# Generated at 2022-06-29 18:10:22.303929
# Unit test for function bump_version
def test_bump_version():
    ver = '0.0.1'
    out = bump_version(ver, position=2)
    assert out == '0.0.2'

    out = bump_version(ver, position=2, pre_release=None)
    assert out == '0.0.2'

    out = bump_version(ver, position=2, pre_release='alpha')
    assert out == '0.0.2a0'

    out = bump_version(ver, position=2, pre_release='Alpha')
    assert out == '0.0.2a0'

    out = bump_version(ver, position=2, pre_release='ALPHA')
    assert out == '0.0.2a0'

    out = bump_version(ver, position=2, pre_release='a')

# Generated at 2022-06-29 18:10:31.353262
# Unit test for function bump_version
def test_bump_version():
    from bumpversion import main
    from bumpversion import __version__
    main([__file__, '--verbose'])


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:10:41.139537
# Unit test for function bump_version
def test_bump_version():
    assert (bump_version('0.0.0') == '0.0.1')
    assert (bump_version('1.0.0') == '1.0.1')
    assert (bump_version('0.1.0') == '0.1.1')
    assert (bump_version('0.0.1') == '0.0.2')
    assert (bump_version('0.0.0', position=0) == '1.0.0')
    assert (bump_version('0.0.0', position=1) == '0.1.0')
    assert (bump_version('0.0.0', position=2) == '0.0.1')
    assert (bump_version('1.2.3', position=0) == '2.0.0')

# Generated at 2022-06-29 18:10:54.342461
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:06.059627
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    new_version = bump_version(version)
    assert new_version == '0.1.0'
    new_version = bump_version(version, 0)
    assert new_version == '1.0.0'
    new_version = bump_version(version, 1)
    assert new_version == '0.1.0'
    new_version = bump_version(version, 2)
    assert new_version == '0.0.1'
    new_version = bump_version(version, 2, 'a')
    assert new_version == '0.0.1a0'
    new_version = bump_version(version, 1, 'a')
    assert new_version == '0.1.0a0'

# Generated at 2022-06-29 18:11:19.426561
# Unit test for function bump_version
def test_bump_version():
    # Test cases for major
    assert bump_version('1.0.0', 0, 'alpha') == '2.0.0'
    assert bump_version('1.0.0', -3, 'alpha') == '2.0.0'
    assert bump_version('1.0.0', -2, 'alpha') == '2.0.0'
    assert bump_version('1.0.0', -1, 'alpha') == '2.0.0'
    assert bump_version('1.0.0', 0, 'beta') == '2.0.0'
    assert bump_version('1.0.0', -3, 'beta') == '2.0.0'
    assert bump_version('1.0.0', -2, 'beta') == '2.0.0'
    assert bump_version

# Generated at 2022-06-29 18:11:32.136807
# Unit test for function bump_version
def test_bump_version(): 
    assert bump_version(version='0.1.0', position=0) == '1.0.0'

if __name__ == '__main__':
    original_version = '1.2.3'
    current_version = original_version
    while True:
        print('Current version: %s' % current_version)
        prompt = 'Enter a value for "position": '
        new_position = raw_input(prompt)
        if new_position == '':
            break
        prompt = 'Enter a value for "pre_release" (optional): '
        new_prerelease = raw_input(prompt)
        if new_prerelease == '':
            new_prerelease = None

# Generated at 2022-06-29 18:11:43.884979
# Unit test for function bump_version
def test_bump_version():
    # Test that the function fails with types other than a string
    try:
        bump_version(12)
        assert False, "bump_version should fail on integer input"
    except ValueError as e:
        assert str(e) == (
            "Invalid "
            "version '12'. "
            "Must be a string"
        ), "bump_version fails with integer input"
    # Test that the function fails with a string not a version number

# Generated at 2022-06-29 18:11:52.398341
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:04.933862
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.1') == '1.2.2', \
        'Bumping a simple patch number failed.'
    assert bump_version('1.2.0') == '1.2.1', \
        'Bumping a patch number with 0 in the last part failed.'
    assert bump_version('1.2.1', 1) == '1.3.0', \
        'Bumping a simple minor number failed.'
    assert bump_version('1.2.0', 1) == '1.3.0', \
        'Bumping a minor number with 0 in the patch part failed.'
    assert bump_version('1.2.0', 1, 'a') == '1.2.0a0', \
        'Bumping a minor number in the pre-release slot failed.'

# Generated at 2022-06-29 18:12:08.413558
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'

# Generated at 2022-06-29 18:12:28.014765
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0a1', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0b1', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0a1', pre_release='b') == '1.1.0b0'
    assert bump_version('1.0.0b1', pre_release='a') == '1.1.0a0'

# Generated at 2022-06-29 18:12:40.417737
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    result = bump_version(
        version='1.2.3',
        position=2,
        pre_release=None
    )
    assert result == '1.2.4'
    result = bump_version(
        version='1.2.3',
        position=2,
        pre_release='a'
    )
    assert result == '1.2.4a0'
    result = bump_version(
        version='1.2.3',
        position=2,
        pre_release='a'
    )
    assert result == '1.2.4a0'
    result = bump_version(
        version='1.2.3',
        position=2,
        pre_release='alpha'
    )

# Generated at 2022-06-29 18:12:51.655924
# Unit test for function bump_version
def test_bump_version():
    version_start = '0.7.0'
    version_end = bump_version(version_start, 1, 'b')
    assert version_end == '0.7b0', "FAIL: %r" % (version_end,)
    version_end = bump_version(version_start, 2, 'b')
    assert version_end == '0.7.1b0', "FAIL: %r" % (version_end,)
    version_end = bump_version(version_start, 2, 'a')
    assert version_end == '0.7.1a0', "FAIL: %r" % (version_end,)
    version_end = bump_version(version_start, 1, 'a')

# Generated at 2022-06-29 18:13:01.845256
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120,W0612
    assert bump_version('0.0.0') == '1.0'
    assert bump_version('0.0.0', position=1) == '0.1'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0'
    assert bump_version('0.0.0', position=1) == '0.1'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=0) == '1.0'
    assert bump_version('0.0.0', position=1) == '0.1'

# Generated at 2022-06-29 18:13:14.468186
# Unit test for function bump_version
def test_bump_version():
    v1 = "1.10.0"
    v2 = bump_version(v1)
    assert v2 == "1.10.1"

    v1_2 = "1.10.0.a2"
    v2_2 = bump_version(v1_2, pre_release='a')
    assert v2_2 == "1.10.0.a3"

    v1_3 = "1.10.0.b2"
    v2_3 = bump_version(v1_3, pre_release='b')
    assert v2_3 == "1.10.0.b3"

    v1_4 = "1.10.0.a2"
    v2_4 = bump_version(v1_4, pre_release='b')

# Generated at 2022-06-29 18:13:23.205044
# Unit test for function bump_version
def test_bump_version():
    def _helper(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        observed = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert observed == expected

    _helper('0.0.0', '1.0.0')
    _helper('0.0.1', '1.0.0')
    _helper('2.0.0', '3.0.0')
    _helper('1.0.0', '1.1.0')
    _helper('1.0.0', '1.1.0')
    _helper('1.1.0', '1.2.0')
    _

# Generated at 2022-06-29 18:13:36.123754
# Unit test for function bump_version
def test_bump_version():
    # Test major
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.1.1') == '1.0.0'
    assert bump_version('0.9.9') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.4.5') == '3.0.0'
    assert bump_version('3.9.9') == '4.0.0'

    # Test minor
    assert bump_version('0.0.0', 1) == '1.0.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1a0'

# Generated at 2022-06-29 18:13:46.185135
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,R0914
    import subprocess

    def _run_pylint() -> None:
        cmd = ['pylint', '--rcfile', 'pylint.rc', 'bump_version.py']
        print('Running %r' % ' '.join(cmd))
        subprocess.check_call(cmd)

    def _run_pytest() -> None:
        cmd = ['pytest', 'test_bump_version.py']
        print('Running %r' % ' '.join(cmd))
        subprocess.check_call(cmd)

    def _run_black() -> None:
        cmd = ['black', '-l', '79', 'bump_version.py']
        print('Running %r' % ' '.join(cmd))
        subprocess.check_

# Generated at 2022-06-29 18:13:59.451990
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.0.0", pre_release="a") == "1.0.1a0"
    assert bump_version("1.0.0", pre_release="A") == "1.0.1a0"
    assert bump_version("1.0.0", pre_release="alpha") == "1.0.1a0"
    assert bump_version("1.0.0", pre_release="ALPHA") == "1.0.1a0"
    assert bump_version("1.0.0", pre_release="b") == "1.0.1b0"
    assert bump_version("1.0.0", pre_release="B") == "1.0.1b0"

# Generated at 2022-06-29 18:14:09.746116
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.3'
    position = 1
    pre_release = 'alpha'
    expected = '0.1.0'
    assert bump_version(
        version=version,
        position=position,
        pre_release=pre_release
    ) == expected

    version = '1.2.3'
    position = 0
    pre_release = None
    expected = '2'
    assert bump_version(
        version=version,
        position=position
    ) == expected

    version = '1.2.3a4'
    position = 1
    pre_release = None
    expected = '1.3'
    assert bump_version(
        version=version,
        position=position,
        pre_release=pre_release
    ) == expected


# Generated at 2022-06-29 18:14:37.808920
# Unit test for function bump_version
def test_bump_version():
    print("Testing bump_version()...")
    print("\tTest: bump_version()")
    assert(bump_version("1.0.0") == '1.0.1')
    print("\tTest: bump_version(\"1.0.0\")")
    assert(bump_version("1.0.0") == '1.0.1')
    print("\tTest: bump_version(\"1.2.3-beta\")")
    assert(bump_version("1.2.3-beta") == '1.2.4')
    print("\tTest: bump_version(\"1.2.3a3\")")
    assert(bump_version("1.2.3a3") == '1.2.4')

# Generated at 2022-06-29 18:14:47.280549
# Unit test for function bump_version
def test_bump_version():
    import pytest
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', -2) == '1.1.2'
    assert bump_version('1.1.1', -1) == '1.2.0'
    assert bump_version('1.1.1', 0) == '1.1.1'
    assert bump_version('1.1.1', 1) == '1.2.0'
    assert bump_version('1.1.1', 2) == '1.1.2'
    assert bump_version('1.1.1', 3) == '1.1.2'

    assert bump_version('1.1.1', pre_release='alpha') == '1.2.0'

# Generated at 2022-06-29 18:14:55.202771
# Unit test for function bump_version
def test_bump_version():

    actual_output = bump_version('5.9.5')
    expected_output = '5.9.6'
    assert actual_output == expected_output

    actual_output = bump_version('5.9.5', 0)
    expected_output = '6.0.0'
    assert actual_output == expected_output

    actual_output = bump_version('5.9.5', 1)
    expected_output = '5.10.0'
    assert actual_output == expected_output

    actual_output = bump_version('5.9.5', 2)
    expected_output = '5.9.6'
    assert actual_output == expected_output

    actual_output = bump_version('5.9.5', -1)
    expected_output = '5.9.6'
    assert actual_output

# Generated at 2022-06-29 18:15:06.344976
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:17.192574
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1', \
        'Bad version bumping: {}'.format(bump_version('1.0.0'))
    assert bump_version('1.0.0', 2) == '1.0.1', \
        'Bad version bumping: {}'.format(bump_version('1.0.0'))
    assert bump_version('1.0.0', -1) == '1.0.1', \
        'Bad version bumping: {}'.format(bump_version('1.0.0'))
    assert bump_version('1.0.0', 1) == '1.1.0', \
        'Bad version bumping: {}'.format(bump_version('1.0.0'))

# Generated at 2022-06-29 18:15:28.937164
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1a1') == '1.0.1a2'
    assert bump_version('1.0.2') == '1.0.3'
    assert bump_version('1.0.2b2') == '1.0.2b3'
    assert bump_version('1.0.2') == '1.0.3'
    assert bump_version('1.0.2b2') == '1.0.2b3'
    assert bump_version('1.0.3') == '1.0.4'
    assert bump_version('1.0.3a1') == '1.0.4'

# Generated at 2022-06-29 18:15:40.169218
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', -1) == '1.3.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', -2) == '2.0.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

    assert bump_version('1.2.3', 0, 'alpha') == '2.0.0'

# Generated at 2022-06-29 18:15:50.580099
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version("0.0.0") == "1.0.0")
    assert(bump_version("0.0.0", position=1) == "0.1.0")
    assert(bump_version("0.0.0", position=2) == "0.0.1")
    assert(bump_version("0.0.0", position=2, pre_release="a") == "0.0.1a0")
    assert(bump_version("0.0.1", position=2, pre_release="a") == "0.0.2a0")
    assert(bump_version("0.0.1", position=2, pre_release="A") == "0.0.2a0")

# Generated at 2022-06-29 18:15:58.543687
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4'
    assert bump_version('1.2.3', position=2, pre_release='b') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0', position=2, pre_release='a') == '1.2.1'

# Generated at 2022-06-29 18:16:09.480044
# Unit test for function bump_version
def test_bump_version():
    print("\nIn function test_bump_version")
    import pprint as pp