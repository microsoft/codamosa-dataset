

# Generated at 2022-06-29 18:06:45.678110
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version()
    """
    original_version = "1.2.3a2"
    expected_version = "1.2.3a3"
    version_after_bump = bump_version(original_version)
    assert version_after_bump == expected_version
    return

if __name__ == "__main__":
    import sys
    args = sys.argv[1:]
    result = bump_version(*args)
    print("Bumped version: {}".format(result))

# Generated at 2022-06-29 18:06:53.408917
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('0.0.0'))
    print(bump_version('0.0.0', position=0))
    print(bump_version('0.0.0', position=-1))
    print(bump_version('0.0.0', position=-2))
    print(bump_version('0.0.0', position=-3))
    print(bump_version('0.0.0', position=1))
    print(bump_version('0.0.0', position=2))
    print(bump_version('0.0.0', position=3))
    print(bump_version('0.0.0', pre_release='a'))
    print(bump_version('0.0.0', pre_release='alpha'))

# Generated at 2022-06-29 18:07:03.900007
# Unit test for function bump_version
def test_bump_version():
    def verify_bump(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> bool:
        new_ver = bump_version(version, position, pre_release)
        if pre_release is None:
            return StrictVersion(new_ver) > StrictVersion(version)
        new_ver_pre = new_ver.split('-')
        if len(new_ver_pre) != 2:
            return False

# Generated at 2022-06-29 18:07:15.664465
# Unit test for function bump_version
def test_bump_version():
    def test(args, expected):
        print(
            'bump_version({!r}, {!r}, {!r}) == {!r}'.format(
                args[0], args[1], args[2], expected
            )
        )
        assert bump_version(*args) == expected

    test(['1', 1, None], '2.0.0')
    test(['2.0.0', 1, None], '3.0.0')
    test(['1.1.1', 0, None], '2.0.0')
    test(['1.1.1', 0, 'a'], '2.0.0a0')
    test(['1.1.1', 1, 'a'], '1.2.0a0')

# Generated at 2022-06-29 18:07:25.503104
# Unit test for function bump_version
def test_bump_version():
    # Mainly taken from setup.py
    def _compare(
            version: str,
            position: int,
            pre_release: Optional[str],
            expect: str
    ) -> None:
        bump_ver = bump_version(version, position, pre_release)
        msg = "%r != %r" % (bump_ver, expect)
        assert bump_ver == expect, msg

    _compare('2.2.1', -3, None, '3.0.0')
    _compare('2.2.1', -1, None, '2.3.0')
    _compare('2.2.1', 2, None, '2.2.2')
    _compare('2.2.1a', -3, 'a', '3.0.0')

# Generated at 2022-06-29 18:07:37.273847
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E0401
    import unittest

    class UnitTest(unittest.TestCase):
        def test_bump_version(self):
            callable_ = bump_version
            self.assertEqual(callable_('1.1.1'), '1.1.2')
            self.assertEqual(callable_('1.1.1', 0), '2.0.0')
            self.assertEqual(callable_('1.1.1', 1), '1.2.0')
            self.assertEqual(callable_('1.1.1', 2), '1.1.2')
            self.assertEqual(callable_('1.1.1', -1), '1.1.2')

# Generated at 2022-06-29 18:07:49.069281
# Unit test for function bump_version
def test_bump_version():
    # Bump the major version
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('3.1.1') == '4.0.0'
    assert bump_version('3.1.1', position=0) == '4.0.0'
    assert bump_version('3.1.1', position=-3) == '4.0.0'
    assert bump_version('3.1.1', position=-4) == '4.0.0'

    # Bump the minor version
    assert bump_version('0.0.1') == '0.1.0'
    assert bump_version('2.0.0') == '2.1.0'
    assert bump

# Generated at 2022-06-29 18:07:56.570860
# Unit test for function bump_version
def test_bump_version():
    result = bump_version('1.2.3')
    assert result == '1.2.4'
    result = bump_version('1.2.3', 0)
    assert result == '2.0.0'
    result = bump_version('1.2.3', 1)
    assert result == '1.3.0'
    result = bump_version('1.2.3', -1)
    assert result == '1.2.4'
    result = bump_version('1.2.3', -2)
    assert result == '1.3.0'
    result = bump_version('1.2.3', -3)
    assert result == '2.0.0'
    result = bump_version('1.2.3a5', 1)
    assert result == '1.3.0'


# Generated at 2022-06-29 18:08:09.568572
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', -2) == '2.0.0'
    assert bump_version('1.2.3', -1) == '1.3.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'

    assert bump_version('1.2.3a5', 0) == '2.0.0'
    assert bump_version('1.2.3a5', 1) == '1.3.0'
    assert bump_version('1.2.3a5', 1, 'a') == '1.3.0'
    assert bump_

# Generated at 2022-06-29 18:08:20.145147
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', -2) == '2.0.0'

    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', -1) == '1.1.0'

    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -0) == '1.0.1'

    assert bump_version('1.2.0') == '2.0.0'

# Generated at 2022-06-29 18:08:51.520145
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=2, pre_release='alpha') == '1.2.4a0'
    assert bump_version('1.2.3', position=2, pre_release='b') == '1.2.4b0'

# Generated at 2022-06-29 18:08:54.318387
# Unit test for function bump_version
def test_bump_version():
    """Dummy test function."""
    pass

if __name__ == '__main__':
    print('# bump_version(\'1.0.0\')')
    print(bump_version('1.0.0'))

# Generated at 2022-06-29 18:09:06.434261
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.0', 1)
    assert version == '1.3.0'
    version = bump_version('1.2.1', 1)
    assert version == '1.3.0'
    version = bump_version('1.2.0', 1, 'a')
    assert version == '1.2a0'
    version = bump_version('1.2.0', 1, 'alpha')
    assert version == '1.2a0'
    version = bump_version('1.2.0', 1, 'b')
    assert version == '1.2b0'
    version = bump_version('1.2.0', 1, 'beta')
    assert version == '1.2b0'
    version = bump_version('1.2.0', 1, 'a')


# Generated at 2022-06-29 18:09:19.012637
# Unit test for function bump_version
def test_bump_version():
    str_version = "1.2.3"
    int_version = 123
    float_version = 1.23

    # test_v1
    int_position = 0
    str_pre_release: Optional[str] = 'alpha'
    assert bump_version(
        version=str_version,
        position=int_position,
        pre_release=str_pre_release
    ) == "2.0.0"

    # test_v2
    str_pre_release: Optional[str] = 'beta'
    assert bump_version(
        version=str_version,
        position=int_position,
        pre_release=str_pre_release
    ) == "2.0.0"

    # test_v3
    int_position = 0

# Generated at 2022-06-29 18:09:32.556101
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:43.469987
# Unit test for function bump_version
def test_bump_version():
    try:
        bump_version('1.2.3', 2, 'a')
    except ValueError:
        assert False, "bump_version('1.2.3', 2, 'a') should not raise a ValueError"
    try:
        bump_version('1.2.3', 2, 'A')
    except ValueError:
        assert False, "bump_version('1.2.3', 2, 'A') should not raise a ValueError"
    try:
        bump_version('1.2.3', 2, 'b')
    except ValueError:
        assert False, "bump_version('1.2.3', 2, 'b') should not raise a ValueError"

# Generated at 2022-06-29 18:09:56.210925
# Unit test for function bump_version
def test_bump_version():
    """
    Testing the bump_version() function
    """

# Generated at 2022-06-29 18:10:06.788983
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, 'alpha') == '1.1.0'

# Generated at 2022-06-29 18:10:19.181714
# Unit test for function bump_version
def test_bump_version():
    # Test the default functionality
    assert bump_version('0.0.1') == '0.0.2'

    # Test resetting the major number
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=-3) == '1.0.0'

    # Test resetting the minor number
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', position=-2) == '0.1.0'

    # Test bumping the prerelease version
    assert bump_version('0.1.0', position=1, pre_release='a') == '0.1.0a0'

# Generated at 2022-06-29 18:10:32.131512
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 0, 'beta') == '2.0.0b0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.0.1', 1) == '1.1.0'

# Generated at 2022-06-29 18:10:53.228388
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.0', 2) == '1.1.1'
    assert bump_version('1.1.0', 2, 'alpha') == '1.1.1'
    assert bump_version('1.1') == '1.1.1'
    assert bump_version('1.1', 2) == '1.1.1'
    assert bump_version('1.1', 2, 'alpha') == '1.1.1'
    assert bump_version('1.1.0-alpha') == '1.1.1'
    assert bump_version('1.1.0-alpha', 2) == '1.1.1'

# Generated at 2022-06-29 18:11:05.360764
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:18.056910
# Unit test for function bump_version
def test_bump_version():
    _assert_bump_version(
        '1.2.0', 0, '2.0.0',
    )
    _assert_bump_version(
        '1.2.0', 0, '2.0.0', 'a'
    )
    _assert_bump_version(
        '1.2.0', 1, '1.3.0',
    )
    _assert_bump_version(
        '1.2.0', 1, '1.3.0', 'a'
    )
    _assert_bump_version(
        '1.2.0', 2, '1.2.1',
    )
    _assert_bump_version(
        '1.2.0', 2, '1.2.1', 'a'
    )
    _assert_

# Generated at 2022-06-29 18:11:30.518261
# Unit test for function bump_version
def test_bump_version():
    # Major
    assert bump_version('1.2.3') == '2.0.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3', 'major') == '2.0.0'
    # Minor
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', 'minor') == '1.3.0'
    # Patch

# Generated at 2022-06-29 18:11:42.464466
# Unit test for function bump_version
def test_bump_version():
    # Test for version 2.0.1
    # Bump major
    assert bump_version('2.0.1', position=0) == '3.0'
    # Bump minor
    assert bump_version('2.0.1', position=1) == '2.1'
    # Bump patch
    assert bump_version('2.0.1', position=2) == '2.0.2'

    # Test for version 2.0
    # Bump minor
    assert bump_version('2.0', position=1) == '2.1'
    # Bump patch
    assert bump_version('2.0', position=2) == '2.0.1'

    # Test for version 2.0a
    # Bump minor alpha

# Generated at 2022-06-29 18:11:51.528593
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1', 0, None) == '2.0.0'
    assert bump_version('1.1.1', 1, None) == '1.2.0'
    assert bump_version('1.1.1', 2, None) == '1.1.2'
    assert bump_version('1.1.1', -1, None) == '1.1.2'
    assert bump_version('1.1.1', -2, None) == '1.2.0'
    assert bump_version('1.1.1', -3, None) == '2.0.0'

    assert bump_version('1.1.1', -2, 'alpha') == '1.2.0'

# Generated at 2022-06-29 18:11:56.289648
# Unit test for function bump_version
def test_bump_version():
    import os

    os.system("""python -m pytest -v  --cov=. --cov-report=html --cov-report=term tests/test_bump_version.py""")

# Generated at 2022-06-29 18:12:08.682188
# Unit test for function bump_version
def test_bump_version():
    # Test what happens when given bad values for the position parameter
    # pylint: disable=E1101
    try:
        bump_version('1.0.0', -4)
    except ValueError as e:
        assert(str(e) == "The given value for 'position', -4, must be an 'int' "
               "between (-3) and (2).")

    try:
        bump_version('1.0.0', 3)
    except ValueError as e:
        assert(str(e) == "The given value for 'position', 3, must be an 'int' "
               "between (-3) and (2).")


# Generated at 2022-06-29 18:12:20.580935
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=line-too-long

    def _test_version(version: str, pos: int, pre: Optional[str] = None) -> str:
        return bump_version(
            version=version,
            position=pos,
            pre_release=pre
        )

    def _run_version_tests(tests: Dict[str, Any]) -> None:
        for version, test_list in tests.items():
            for test in test_list:
                out = _test_version(
                    version=version,
                    pos=test['pos'],
                    pre=test.get('pre')
                )
                assert out == test['out']
                # We need to keep looping until we've finally bumped
                # all the way through.

# Generated at 2022-06-29 18:12:28.439297
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:47.076055
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_01(self):
            got: str = bump_version('1.2.3.4')
            exp: str = '2.0.0'
            msg: str = (
                '\n\n'
                'EXPECTED:\n%s\n\n'
                'GOT:\n%s\n\n'
            ) % (exp, got)
            self.assertEqual(exp, got, msg)

        def test_bump_version_02(self):
            got: str = bump_version('1.2.3')
            exp: str = '2.0.0'

# Generated at 2022-06-29 18:12:58.259208
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:04.765043
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('4.4.0') == '4.4.1'
    assert bump_version('4.4.1') == '4.4.2'
    assert bump_version('4.4.2') == '4.4.3'
    assert bump_version('4.4.0', position=0) == '5.0.0'
    assert bump_version('4.4.0', position=1) == '4.5.0'
    assert bump_version('4.4.0', position=2) == '4.4.1'
    assert bump_version('4.4.0', position=-1) == '4.4.1'
    assert bump_version('4.4.0', position=-2) == '4.5.0'

# Generated at 2022-06-29 18:13:15.959917
# Unit test for function bump_version
def test_bump_version():
    txt = '''
    |major.minor.patch - 0.1.2
    |major.minor.patch-alpha - 0.1.2a3
    |major.minor.patch-beta - 0.1.2b3
    '''
    for line in txt.split('\n'):
        if not line.strip():
            continue
        line = line.strip()
        stuff, text = line.split(' - ')
        version = StrictVersion(text)
        version = str(version)
        version = bump_version(version)
        version = StrictVersion(version)
        version = str(version)
        print('%-30s -> %s' % (stuff, version))


test_bump_version()

# Generated at 2022-06-29 18:13:24.799157
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('3.0.0') == '4.0.0'
    assert bump_version('4.0.0') == '5.0.0'
    assert bump_version('5.0.0') == '6.0.0'
    assert bump_version('6.0.0') == '7.0.0'
    assert bump_version('7.0.0') == '8.0.0'
    assert bump_version('8.0.0') == '9.0.0'

# Generated at 2022-06-29 18:13:37.142381
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.3', -1))
    print(bump_version('1.2.3', 0))
    print(bump_version('1.2.3', 1))
    print(bump_version('1.2.3', 2))
    print(bump_version('1.2.3', 'a'))
    print(bump_version('1.2.3', 'b'))
    print(bump_version('1.2', 'a'))
    print(bump_version('1.2', 'b'))
    print(bump_version('1.2.3-a1', 0))
    print(bump_version('1.2.3-a1', 1))

# Generated at 2022-06-29 18:13:46.831935
# Unit test for function bump_version
def test_bump_version():
    pre_releases = (None, 'alpha', 'beta')
    positions = range(-3, 3)

# Generated at 2022-06-29 18:14:00.110564
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:10.346196
# Unit test for function bump_version
def test_bump_version():
    # Basic functionality tests
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.3.0a0'
    assert bump_version('1.2.3', pre_release='b') == '1.3.0b0'
    assert bump_version('1.2.3', -1, 'a') == '1.2.4a0'
    assert bump_version('1.2.3', -1, 'b') == '1.2.4b0'
    assert bump_version('1.2.3', 1, 'a') == '2.0.0a0'
    assert bump_version('1.2.3', 1, 'b') == '2.0.0b0'


# Generated at 2022-06-29 18:14:17.589714
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.3.8') == '0.3.9'
    assert bump_version('0.3.8a4') == '0.3.8a5'
    assert bump_version('0.3.8b6') == '0.3.8b7'

    assert bump_version('0.3.0') == '0.4.0'
    assert bump_version('0.3.0a4') == '0.4.0'
    assert bump_version('0.3.0b6') == '0.4.0'

    assert bump_version('0.3.8', 1) == '0.4.0'
    assert bump_version('0.3.8a4', 1) == '0.3.9'

# Generated at 2022-06-29 18:14:42.318585
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0', 1, 'alpha') == '1.1a0'
    assert bump_version('1.0a0', 1, 'alpha') == '1.1a0'
    assert bump_version('1.0a0', 1, 'beta') == '1.1b0'
    assert bump_version('1.0a0', 1) == '1.1'
    assert bump_version('1.0a0', 1, 'none') == '1.1'
    assert bump_version('1.0a0', 0) == '2'
    # Print output
    print(bump_version('1.0a0', 1, 'beta'))
    # B

# Generated at 2022-06-29 18:14:49.516011
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', 1) == '1.2.3'
    assert bump_version('1.2.3.dev1', 1, 'a') == '1.3.0'
    assert bump_version('1.2.3.dev1', 1, 'b') == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3.dev1', 2, 'a') == '1.2.4.dev1'
    assert bump_version('1.2.3.dev1', 2, 'b') == '1.2.4.dev1'
    assert bump_version('1.2.3.dev1', 2, 'a') == '1.2.4.dev1'

# Generated at 2022-06-29 18:14:56.420186
# Unit test for function bump_version
def test_bump_version():
    # From: https://github.com/pandas-dev/pandas/blob/master/pandas/util/testing.py
    def assert_almost_equal(a, b, **kwargs):
        """assert that two items are almost equal"""
        __tracebackhide__ = True
        try:
            np.testing.assert_almost_equal(a, b, **kwargs)
        except AssertionError:
            raise AssertionError('{} != {} within {} places'.format(a, b, kwargs['decimal']))
    # From: https://github.com/pandas-dev/pandas/blob/master/pandas/util/testing.py

# Generated at 2022-06-29 18:15:07.385512
# Unit test for function bump_version
def test_bump_version():
    # Minor releases
    assert '1.0.0' == bump_version('1.0.0')
    assert '1.1.0' == bump_version('1.0.0', position=1)
    assert '2.0.0' == bump_version('1.0.0', position=0)
    assert '1.0.0' == bump_version('1.0.0', position=1, pre_release='alpha')
    assert '1.0.0' == bump_version('1.0.0', position=1, pre_release='beta')
    assert '1.0.0' == bump_version('1.0.0', position=1, pre_release='alp')

# Generated at 2022-06-29 18:15:17.760173
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')

# Generated at 2022-06-29 18:15:29.395849
# Unit test for function bump_version
def test_bump_version():
    ver: str
    ver = bump_version('2.3.4')
    assert ver == '3.0.0', "bump_version('2.3.4') != '3.0.0'"

    ver = bump_version('2.3.4', 0)
    assert ver == '3.0.0', "bump_version('2.3.4', 0) != '3.0.0'"

    ver = bump_version('2.3.4', 1)
    assert ver == '2.4.0', "bump_version('2.3.4', 1) != '2.4.0'"

    ver = bump_version('2.3.4', 2)

# Generated at 2022-06-29 18:15:41.473049
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('4.4.4') == '4.4.5'
    assert bump_version('4.4.4', position=2) == '4.4.5'
    assert bump_version('4.4.4', position=2, pre_release='a') == '4.4.4a0'
    assert bump_version('4.4.4', position=2, pre_release='b') == '4.4.4b0'
    assert bump_version('4.4.4', position=1) == '4.5.0'
    assert bump_version('4.4.4', position=1, pre_release='a') == '4.5.0a0'

# Generated at 2022-06-29 18:15:51.347406
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0', 1, 'a') == '0.2.0'
    assert bump_version('0.1.0', 2, 'a') == '0.1.1a0'
    assert bump_version('0.1.1a1') == '0.1.1a2'
    assert bump_version('0.1.1a1', 2) == '0.1.2a0'
    assert bump_version

# Generated at 2022-06-29 18:15:58.941751
# Unit test for function bump_version
def test_bump_version():
    from nose.tools import (
        assert_equal
    )
    from sys import version_info

    if version_info <= (3, 6):
        return

    assert_equal(bump_version('0.0.0'), '0.0.1')
    assert_equal(bump_version('1.0.0'), '1.1.0')
    assert_equal(bump_version('2.0.0-alpha.0'), '2.0.0-alpha.1')
    assert_equal(bump_version('2.1.0-beta.0'), '2.1.0-beta.1')

    assert_equal(bump_version('0.0.0', -2), '0.1.0')

# Generated at 2022-06-29 18:16:10.018078
# Unit test for function bump_version