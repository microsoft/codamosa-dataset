

# Generated at 2022-06-29 18:06:48.937256
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys

    def run_test(
            desc,
            version,
            position,
            pre_release,
            expected,
            should_pass=True
    ):
        print()
        print(desc)
        print('-' * len(desc))
        try:
            result = bump_version(version, position, pre_release)
            msg = "FAIL (Should Fail) - result: '%s' - expected: '%s'" % (
                result,
                expected
            )
            if result != expected:
                raise Exception(msg)
            if should_pass is False:
                raise Exception(msg)
        except Exception as ex:
            msg = "FAIL - result: '%s' - error: %s" % (result, ex)
            if should_pass is True:
                raise Exception

# Generated at 2022-06-29 18:06:58.816795
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for function bump_version.

    This function uses ``unittest``.

    """
    import unittest

    class BumpVersionTest(unittest.TestCase):
        """
        Tests for function bump_version.

        """
        def test_bump_version(self):

            # Test case 1.
            # Check the version number is updated from 1 to 2, when
            # using default params.
            ret_version = bump_version("1")
            self.assertEqual("2", ret_version)

            # Test case 2.
            # Check the version number patch is updated from 2.1 to 2.1.1,
            # when using default params.
            ret_version = bump_version("2.1")
            self.assertEqual("2.1.1", ret_version)

           

# Generated at 2022-06-29 18:07:10.252305
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:21.521545
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.9.0') == '0.10.0'
    assert bump_version('0.9.0', 1) == '1.0.0'
    assert bump_version('0.10.0') == '0.10.1'
    assert bump_version('0.9.0', 2) == '0.10.0'
    assert bump_version('0.9.0', 3) == '0.9.1'
    assert bump_version('0.9.0', 0) == '1.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', -1) == '2.0.0'

# Generated at 2022-06-29 18:07:28.387945
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

# Generated at 2022-06-29 18:07:40.681008
# Unit test for function bump_version
def test_bump_version():
    """Test ``bump_version``."""
    # pylint: disable=too-many-branches
    import copy
    import random
    import string

    def _build_random_version_parts(
            size=3,
            chars=string.digits
    ) -> List[int]:
        return [int(''.join(random.choice(chars) for _ in range(size)))
                for _ in range(size)]

    def _build_random_version_pre_release() -> Union[str, None]:
        pre = random.choice(('a', 'b', 'alpha', 'beta', None))
        if pre is not None:
            pre = '%s%s' % (
                pre,
                ''.join(random.choice(string.digits) for _ in range(2))
            )
        return

# Generated at 2022-06-29 18:07:51.340540
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.5.0') == '1.5.1')
    assert(bump_version('1.5.0', 2, None) == '1.5.1')
    assert(bump_version('1.5.0', 0) == '2.0.0')
    assert(bump_version('1.5.0', 1) == '1.6.0')
    assert(bump_version('1.5.0', 1, 'b') == '1.6.0')
    assert(bump_version('1.5.0', 1, 'a') == '1.6.0')
    assert(bump_version('1.5.0', 2, 'a') == '1.5.1a0')

# Generated at 2022-06-29 18:08:02.333402
# Unit test for function bump_version
def test_bump_version():
    """Unit test bump version

    *New in version 0.3*

    """
    # pylint: disable=import-outside-toplevel
    from logging import getLogger
    from os import path
    from io import StringIO

    import pkg_resources

    from pytest import raises

    from pytest_wdl.wdl import WDL
    from pytest_wdl.utils import (
        get_pytest_wdl_dir,
        read_file
    )

    log = getLogger(__name__)

    pkg = pkg_resources.get_distribution('pytest-wdl')
    ver = pkg.version
    log.info("Current version: %s", ver)
    bump_api = "0.0.0"

# Generated at 2022-06-29 18:08:12.200846
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.3.3', 0, 'b') == '1.0.0'
    assert bump_version('0.3.3', 0) == '1.0.0'
    assert bump_version('1.3.3') == '1.3.4'
    assert bump_version('0.3.3', 1) == '0.4.0'
    assert bump_version('0.3.3', 1, 'b') == '0.4.0'
    assert bump_version('0.3.3', 1, 'alpha') == '0.4.0'
    assert bump_version('0.3.3', 1, 'a') == '0.4.0'
    assert bump_version('0.3.3', 1, 'beta') == '0.4.0'

# Generated at 2022-06-29 18:08:21.858442
# Unit test for function bump_version
def test_bump_version():
    ''' Unit tests for the bump_version function
    '''
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 2, 'a') == '0.1.1a0'
    assert bump_version('0.1.0', 2, 'b') == '0.1.1b0'
    assert bump_version('0.1.1a0') == '0.1.1a1'
    assert bump_version('0.1.1b0') == '0.1.1b1'
    assert bump_version('0.1.0a0') == '0.1.1a0'
    assert bump_version('0.1.0b0') == '0.1.1b0'

# Generated at 2022-06-29 18:08:39.285517
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.9.0') == '0.10.0'
    assert bump_version('0.10.0') == '0.11.0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.9') == '0.0.10'
    assert bump_version('0.0.10') == '0.0.11'
    assert bump_

# Generated at 2022-06-29 18:08:52.221244
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0-alpha') == '0.0.1'
    assert bump_version('0.0.0-alpha', 0) == '1.0.0'
    assert bump_version('2.0.0-alpha') == '2.0.1'
    assert bump_version('2.0.0-alpha', 1) == '2.1.0'
    assert bump_version('0.0.0-alpha', 2) == '0.0.1'
    assert bump_version('2.0.0-alpha', 3) == '2.0.1'
    assert bump_version('3.0.0-alpha', 4) == '3.1.0'
    assert bump_version('3.0.0-alpha', 5) == '3.0.1'
    assert bump

# Generated at 2022-06-29 18:09:05.966243
# Unit test for function bump_version
def test_bump_version():
    version = '2.9.0'
    position = -3
    pre_release = None
    # noinspection PyTypeChecker
    assert bump_version(version, position, pre_release) == '3.0.0'

    version = '2.9.0'
    position = -2
    pre_release = None
    # noinspection PyTypeChecker
    assert bump_version(version, position, pre_release) == '2.10.0'

    version = '2.9.0'
    position = -1
    pre_release = None
    # noinspection PyTypeChecker
    assert bump_version(version, position, pre_release) == '2.9.1'

    version = '2.9.0'
    position = 0
    pre_release = None
    # noinspection

# Generated at 2022-06-29 18:09:18.562286
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=3) == '0.0.1'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=1, pre_release='a') == '0.1a0'
    assert bump_version('0.0.0', position=1, pre_release='b') == '0.1b0'

# Generated at 2022-06-29 18:09:32.555882
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    assert bump_version('') == '1.0.0'
    assert bump_version('0.2.1') == '0.3.0'
    assert bump_version('0.2.1', 1) == '0.3.0'
    assert bump_version('0.2.1', 2) == '0.2.2'
    assert bump_version('0.2.1', 2, 'a') == '0.2.2'
    assert bump_version('0.2.1', 2, 'alpha') == '0.2.2'
    assert bump_version('0.2.1', 2, 'b') == '0.2.2'
    assert bump_version('0.2.1', 2, 'beta') == '0.2.2'


# Generated at 2022-06-29 18:09:39.982949
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:47.215422
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # Test 1
    old_ver = '1.3.2'
    expect = '1.3.3'
    assert bump_version(old_ver) == expect

    # Test 2
    old_ver = '1.3.2'
    expect = '1.4.0'
    assert bump_version(old_ver, 1) == expect

    # Test 3
    old_ver = '1.3.2'
    expect = '2.0.0'
    assert bump_version(old_ver, 0) == expect

    # Test 4
    old_ver = '1.3.2'
    expect = '1.3.3-b0'
    assert bump_version(old_ver, 2, 'b') == expect

    # Test 5
    old

# Generated at 2022-06-29 18:10:00.439278
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:09.212427
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from os import sys
    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    import pip
    import pkg_resources
    import unittest
    import tests.helper

    if tests.helper.check_for_coverage():
        unittest = tests.helper.coverage_ignore(unittest)

    class Test_bump_version(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None

        def test_bump_version_000(self):
            """Test bump_version() function with a missing 'prerelease'
            argument.
            """
            version = '1.0.0'
            position = 2
            pre_release = None


# Generated at 2022-06-29 18:10:22.117105
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function bump_version.
    """
    # Test for function _build_version_bump_type
    assert _build_version_bump_type(0, 'a') == _BUMP_VERSION_MAJOR
    assert _build_version_bump_type(0, 'A') == _BUMP_VERSION_MAJOR
    assert _build_version_bump_type(0, 'alpha') == _BUMP_VERSION_MAJOR
    assert _build_version_bump_type(0, 'ALPHA') == _BUMP_VERSION_MAJOR
    assert _build_version_bump_type(0, 'b') == _BUMP_VERSION_MAJOR
    assert _build_version_bump_type(0, 'B') == _BUMP_VERSION_MAJOR

# Generated at 2022-06-29 18:10:38.493123
# Unit test for function bump_version
def test_bump_version():
    import pytest  # pylint: disable=W0611,E0401
    from random import choice, randint  # pylint: disable=W0611,E0401
    from os.path import join, dirname  # pylint: disable=W0611,E0401
    from os import listdir  # pylint: disable=W0611,E0401

    fixture_dir = join(dirname(__file__), 'fixtures', 'bump_version')
    files = listdir(fixture_dir)
    parser = lambda x: int(x.split('.')[0])
    files.sort(key=parser)
    choices = {
        0: 'a',
        1: 'alpha',
        2: 'b',
        3: 'beta',
    }


# Generated at 2022-06-29 18:10:51.607224
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.1.0'
    assert bump_version('1.0.0', -2) == '2.0.0'

# Generated at 2022-06-29 18:11:03.822334
# Unit test for function bump_version
def test_bump_version():
    """Test that the bump_version function does what is expected"""
    assert bump_version('0.1.12') == '0.1.13'
    assert bump_version('0.1.12', 1) == '0.2'
    assert bump_version('0.1.12', 1, 'a') == '0.2.0a0'
    assert bump_version('0.1.12a0', 1, 'a') == '0.1.12a1'
    assert bump_version('0.1.12b9', 1, 'b') == '0.1.12b10'
    assert bump_version('0.1.12a9', 1, 'b') == '0.1.13b0'

# Generated at 2022-06-29 18:11:11.199401
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 2) == '0.0.2'

    # Bump the fourth (or the third, zero based) part of the version
    assert bump_version('0.0.1', 3) == '0.0.2'

    # Bump the fourth (or the third, zero based) part of the version
    # This is the same as the above, but it's more clear that it's the
    # fourth (or third) version part that is being bumped

# Generated at 2022-06-29 18:11:23.641480
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 5) == '1.0.0'
    assert bump_version('1.0.0', -3) == '1.0.0'
    assert bump_version('1.0.0', -5) == '1.0.0'

# Generated at 2022-06-29 18:11:36.117845
# Unit test for function bump_version
def test_bump_version():
    """Simplistic unit test for the ``bump_version`` function.

    *New in version 0.3*

    Raises:
        ValueError: if the unit test fails.
    """

# Generated at 2022-06-29 18:11:47.040968
# Unit test for function bump_version
def test_bump_version():

    """Unit test for function bump_version"""

    assert bump_version('0.0.0b0') == '0.0.1b0'

if __name__ == '__main__':
    import argparse

    _PARSER = argparse.ArgumentParser(
        description='Bump a version number.'
    )
    _PARSER.add_argument(
        'version',
        help='The version number to modify.'
    )
    _PARSER.add_argument(
        '-pos',
        '--position',
        dest='position',
        type=int,
        help='The position (starting with zero) of the version number '
        'component to be increased.'
    )

# Generated at 2022-06-29 18:11:59.074741
# Unit test for function bump_version
def test_bump_version():
    """Tests for the :func:`bump_version` function."""
    from binascii import unhexlify
    from datetime import datetime
    from json import loads as json_loads

    from plasoscaffolder.common import version

    # pylint: disable=import-outside-toplevel
    from plasoscaffolder.common.version import bump_version as bump_version_2

    # pylint: disable=protected-access
    # pylint: disable=unsubscriptable-object
    version.__version__ = b'\x30\x2e\x31\x2e\x31\x2e\x32'
    version.__version__ = unhexlify(version.__version__)

# Generated at 2022-06-29 18:12:11.964134
# Unit test for function bump_version
def test_bump_version():
    # Test that function bumps version number correctly
    assert(bump_version('1.2.3') == '1.2.4')
    assert(bump_version('1.2.3', position=1) == '1.3.0')
    assert(bump_version('1.2.3', position=0) == '2.0.0')
    assert(bump_version('1.2.3', position=0, pre_release='a') == '2.0.0')
    assert(bump_version('1.2.3') == bump_version('1.2.3', position=2))
    assert(bump_version('1.2.3', position=1) == bump_version('1.2.3', position=1, pre_release='a'))

# Generated at 2022-06-29 18:12:22.996371
# Unit test for function bump_version
def test_bump_version():
    """Test for function: 'bump_version'.

    This test is only enabled when the module is called directly.

    """
    ver = '1.5.0'
    ver_new = bump_version(ver, position=0)
    assert ver_new == '2.0.0'
    ver_new = bump_version(ver, position=1)
    assert ver_new == '1.6.0'
    ver_new = bump_version(ver, position=2)
    assert ver_new == '1.5.1'
    ver_new = bump_version(ver, position=2, pre_release='alpha')
    assert ver_new == '1.5.1a0'
    ver_new = bump_version(ver, position=2, pre_release='A')

# Generated at 2022-06-29 18:12:43.512813
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E0611,E0401

    assert bump_version('0.6.1') == '0.6.2'
    assert bump_version('0.6.1', 1) == '0.7.0'
    assert bump_version('0.6.1', 0) == '1.0.0'
    assert bump_version('0.6.0', 1) == '0.7.0'
    assert bump_version('0.6.0') == '0.6.1'
    assert bump_version('0.6.0', 0) == '1.0.0'
    assert bump_version('0.6.1', 1, 'a') == '0.7.0a0'

# Generated at 2022-06-29 18:12:55.791896
# Unit test for function bump_version
def test_bump_version():

    test = '0.0.7'
    assert bump_version(test) == '0.0.8'

    test = '2.5.0'
    assert bump_version(test) == '2.5.1'

    test = '3.0.0'
    assert bump_version(test) == '3.0.1'

    test = '3.6.3'
    assert bump_version(test, 0) == '4.0.0'

    test = '4.4.4'
    assert bump_version(test, 1) == '4.5.0'

    test = '4.0.1'
    assert bump_version(test, 1, None) == '4.1.0'

    test = '1.2.3'

# Generated at 2022-06-29 18:13:03.608778
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1', 1) == '0.2.0'
    assert bump_version('0.1.1', 0) == '1.0.0'
    assert bump_version('0.1.1', 2) == '0.1.2'
    assert bump_version('0.1.1', -1) == '0.1.2'
    assert bump_version('0.1.1', -2) == '0.2.0'
    assert bump_version('0.1.1', -3) == '1.0.0'
    assert bump_version('0.1.1', position=0) == '1.0.0'

# Generated at 2022-06-29 18:13:16.005630
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2') == '2.0.0'
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 2, 'a') == '1.2.4'
    assert bump_version('1.2.3', 2, 'alpha') == '1.2.4'
    assert bump_version('1.2.3', 2, 'b') == '1.2.4'
    assert bump_version('1.2.3', 2, 'beta') == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'

# Generated at 2022-06-29 18:13:19.126666
# Unit test for function bump_version
def test_bump_version():
    func = bump_version
    version = '1.0.0'
    result = func(version)
    assert result == '1.0.1', (
        'The version number should have been increased from (%r) to (%r), '
        'but it wasn\'t.  It was (%r) instead.' % (version, '1.0.1', result)
    )



# Generated at 2022-06-29 18:13:31.889425
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0116,C0103
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', 2, None) == '1.0.1'
    assert bump_version('1.0.0', position=2, pre_release=None) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'

# Generated at 2022-06-29 18:13:42.593249
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    version = '0.9.9'
    out = bump_version(version)
    assert out == '1.0.0'

    version = '0.9.9a1'
    out = bump_version(version)
    assert out == '1.0.0', out

    version = '0.9.9a3'
    out = bump_version(version, pre_release='a')
    assert out == '1.0.0a0', out
    out = bump_version(version, pre_release='alpha')
    assert out == '1.0.0a0', out
    out = bump_version(version, pre_release='b')
    assert out == '1.0.0b0', out

# Generated at 2022-06-29 18:13:54.378637
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.
    """
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3a1', position=1) == '1.3.0'
    assert bump_version('1.2.3a1', position=1, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'

# Generated at 2022-06-29 18:14:06.139294
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:14.065622
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:45.373848
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0915
    # pylint: disable=R0912
    # pylint: disable=R0914
    assert bump_version('0.14.0') == '0.14.1'
    assert bump_version('0.14.0', 1) == '0.15.0'
    assert bump_version('0.14.0', 0) == '1.0.0'
    assert bump_version('0.14.0', -1) == '0.14.1'
    assert bump_version('0.14.0', -2) == '0.15.0'
    assert bump_version('0.14.0', -3) == '1.0.0'
    assert bump_version('0.14.0', 15) == '0.14.1'
   

# Generated at 2022-06-29 18:14:54.276390
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function bump_version with various input and expected output.
    This used the `pytest` framework.
    """
    assert bump_version('1') == '2'
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.0.0.0') == '2'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0.0', 0) == '2'
    assert bump_version('1.0.0', 0) == '2'

# Generated at 2022-06-29 18:15:05.548619
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version()"""
    assert bump_version('2.1.1') == '2.1.2'
    assert bump_version('2.1.1', -2) == '2.1.2'
    assert bump_version('2.1.1', -1) == '2.1.2'
    assert bump_version('2.1.1', 0) == '3.0.0'
    assert bump_version('2.1.1', 1) == '2.2.0'
    assert bump_version('2.1.1', 2) == '2.1.2'
    assert bump_version('2.1.1', 2, 'a') == '2.1.1a0'

# Generated at 2022-06-29 18:15:15.674201
# Unit test for function bump_version
def test_bump_version():
    # Test bump_version without a pre-release and without giving a position
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.8') == '0.0.9'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.9.9') == '1.9.10'
    assert bump_version('1.20.1') == '1.20.2'

# Generated at 2022-06-29 18:15:27.463939
# Unit test for function bump_version
def test_bump_version():
    test_version = '3.4.5'
    def test1(version):
        bump_version('3.4.5', position=2, pre_release=None)
        return version
    assert test1('3.4.5') == test_version
    def test2(version):
        bump_version('3.4.5', position=2, pre_release='b')
        return version
    assert test2('3.4.5b') == test_version
    def test3(version):
        bump_version('3.4.5', position=2, pre_release='b')
        return version
    assert test3('3.4.5b') == test_version
    def test4(version):
        bump_version('3.4.5b1', position=2, pre_release='b')
        return

# Generated at 2022-06-29 18:15:30.239226
# Unit test for function bump_version
def test_bump_version():
    test_version = "2.1.0"
    test_position = 2
    test_pre_release = None
    result = bump_version(test_version, test_position, test_pre_release)
    expected = "2.1.1"
    assert result == expected, "Test failed to assert '%s' == '%s'" % (result, expected)



# Generated at 2022-06-29 18:15:42.673747
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0613,C0103
    def _test_helper(
            version: str,
            position: int = 2,
            pre_release: Union[str, None] = None,
            expected: str = '2.0.0'
    ) -> None:
        actual = bump_version(
            version,
            position,
            pre_release
        )
        assert expected == actual

    _test_helper('1.1.1', 0, None, '2.0.0')
    _test_helper('1.1.1', 1, None, '1.2.0')
    _test_helper('1.1.1', 2, None, '1.1.2')

# Generated at 2022-06-29 18:15:52.874896
# Unit test for function bump_version
def test_bump_version():

    print("Testing function bump_version ...")
    print("bump_version('1.2.3') returns:", bump_version('1.2.3'))
    print("bump_version('1.2.3', 2) returns:", bump_version('1.2.3', 2))
    print("bump_version('1.2.3', 3) returns:", bump_version('1.2.3', 3))
    print("bump_version('1.2.3', 4) returns:", bump_version('1.2.3', 4))
    print("bump_version('1.2.3', -1) returns:", bump_version('1.2.3', -1))

# Generated at 2022-06-29 18:16:03.069910
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    position = 2
    pre_release = None
    assert bump_version(version, position, pre_release) == '1.2.4'

    version = '0.2.3'
    position = 0
    pre_release = None
    assert bump_version(version, position, pre_release) == '1.0.0'

    version = '0.2.3'
    position = 1
    pre_release = None
    assert bump_version(version, position, pre_release) == '0.3.0'

    version = '0.2.3'
    position = -1
    pre_release = None
    assert bump_version(version, position, pre_release) == '1.0.0'

    version = '0.2.3'

# Generated at 2022-06-29 18:16:08.621318
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 'alpha') == '1.0.1a0'