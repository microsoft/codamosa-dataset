

# Generated at 2022-06-29 18:06:48.008789
# Unit test for function bump_version

# Generated at 2022-06-29 18:06:57.215347
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

# Generated at 2022-06-29 18:07:08.776659
# Unit test for function bump_version
def test_bump_version():
    # Test Simple Version
    # See https://github.com/chriskiehl/Gooey/issues/883
    assert bump_version('1.0.0') == '1.0.1'
    # Test Alpha
    assert bump_version('1.0.0', pre_release='alpha') == '1.0.0a0'
    assert bump_version('1.0.0a0', pre_release='alpha') == '1.0.0a1'
    assert bump_version('1.0.0a0', pre_release='beta') == '1.0.0b0'
    assert bump_version('1.0.0b0', pre_release='alpha') == '1.0.1a0'
    # Test Beta
    assert bump_version('1.0.0', pre_release='beta')

# Generated at 2022-06-29 18:07:20.051148
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:27.744776
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.0.0', position=1) == '2.1.0'
    assert bump_version('2.0.0', position=1, pre_release='a') == '2.1.0a0'
    assert bump_version('2.0.0', position=2, pre_release='a') == '2.0.1a0'
    assert bump_version('2.0.1a0', position=2, pre_release='a') == '2.0.1a1'

# Generated at 2022-06-29 18:07:38.484461
# Unit test for function bump_version
def test_bump_version():
    version = "3.10.0"
    print("Version: {}, Bump: {}".format(version, bump_version(version)))

    version = "3.10.0a0"
    print("Version: {}, Bump: {}".format(version, bump_version(version)))

    version = "3.10.0a1"
    print("Version: {}, Bump: {}".format(version, bump_version(version)))

    version = "3.10.0b0"
    print("Version: {}, Bump: {}".format(version, bump_version(version)))

    version = "3.10.0b1"
    print("Version: {}, Bump: {}".format(version, bump_version(version)))

# Generated at 2022-06-29 18:07:50.185420
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.3.0') == '1.3.1'
    assert bump_version('1.3.0', position=1) == '1.4.0'
    assert bump_version('1.3.0', position=0) == '2.0.0'
    assert bump_version('1.3.0', position=2) == '1.3.1'
    assert bump_version('1.3.0', position=3) == '1.4.0'
    assert bump_version('1.3.0', position=-3) == '2.0.0'
    assert bump_version('1.3.0', position=-2) == '1.4.0'
    assert bump_version('1.3.0', position=-1) == '1.3.1'
    assert bump

# Generated at 2022-06-29 18:07:58.761650
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'

    assert bump_version('1.0.0', 1, 'a') == '1.1a0'
    assert bump_version('1.0.0', 1, 'b') == '1.1b0'
    assert bump_version('1.0.0a0', 1, 'a') == '1.1a1'
    assert bump_version('1.0.0a0', 1, 'b') == '1.1b0'

# Generated at 2022-06-29 18:08:10.943308
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:21.160523
# Unit test for function bump_version
def test_bump_version():
    version: str = '0.0.0'
    result = bump_version(version)
    assert result == '0.0.1'
    result = bump_version(version, 1)
    assert result == '0.1.0'
    result = bump_version(version, 0)
    assert result == '1.0.0'

    version = '0.0.1'
    result = bump_version(version)
    assert result == '0.0.2'
    result = bump_version(version, 1)
    assert result == '0.1.0'
    result = bump_version(version, 0)
    assert result == '1.0.0'

    version = '0.1.0'
    result = bump_version(version)
    assert result == '0.1.1'
    result

# Generated at 2022-06-29 18:08:46.784746
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.1.0') == '1.0.0'
    assert bump_version('0.1.1') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('1.1.0') == '2.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    assert bump_version('1.2.3') == '2.0.0'

# Generated at 2022-06-29 18:08:54.848459
# Unit test for function bump_version
def test_bump_version():
    # Test for bump_version
    assert bump_version('1.2.3a2') == '1.3a0'
    assert bump_version('1.2.3a2', position=0) == '2.0.0'
    assert bump_version('1.2.3b2') == '1.3b0'
    assert bump_version('1.2.3', pre_release='alpha') == '1.2.4a0'
    assert bump_version('1.2.3', position=-1, pre_release='alpha') == '1.3a0'

test_bump_version()

# Generated at 2022-06-29 18:09:06.476085
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1, 'b') == '1.0.0b0'
    assert bump_version('1.0a0.0', 1, 'b') == '1.0a0b0'
    assert bump_version('1.0a0.0', 1, 'a') == '1.0a1.0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'

# Generated at 2022-06-29 18:09:19.055313
# Unit test for function bump_version
def test_bump_version():
    # Test major version bump
    version = bump_version('1.2.3', 0)
    assert version == '2.0.0'

    # Test major version bump
    version = bump_version('1.2.3', 0, 'a')
    assert version == '2.0.0'

    # Test minor version bump
    version = bump_version('1.2.3', 1)
    assert version == '1.3.0'

    # Test minor version bump
    version = bump_version('1.2.3', 1, 'a')
    assert version == '1.3.0'

    # Test patch version bump
    version = bump_version('1.2.3', 2)
    assert version == '1.2.4'

    # Test patch version bump

# Generated at 2022-06-29 18:09:19.915123
# Unit test for function bump_version
def test_bump_version():
    pass


# Generated at 2022-06-29 18:09:32.753375
# Unit test for function bump_version
def test_bump_version():
    import pytest

    def test_equal(
            version: str,
            position: int,
            pre_release: Union[str, None],
            expected: str
    ) -> None:
        actual = bump_version(version, position, pre_release)
        print("actual: %s" % actual)
        if actual == expected:
            print("pass")
        else:
            print("FAIL")
            print("expected: %s" % expected)
        assert actual == expected

    print("test_empty")
    test_equal("", 0, None, "1.0.0")

    print("test_1")
    test_equal("1.0.0", -3, None, "1.0.0")

    print("test_2")

# Generated at 2022-06-29 18:09:41.978628
# Unit test for function bump_version
def test_bump_version():
    with open('test/data/bump_version.txt') as fr:
        for line in fr:
            line = line.strip()
            if line == '':
                continue

            line = line.strip('------------')
            if line.startswith('#'):
                continue

            assert ' -> ' in line
            v1, v2 = line.split(' -> ')
            assert v1 != v2
            v1 = v1.strip()
            v2 = v2.strip()
            assert v1 != v2
            assert bump_version(v1) == v2
    print('PASSED!')



# Generated at 2022-06-29 18:09:54.388706
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 2, pre_release='alpha') == '1.2.4a0'
    assert bump_version('1.2.3', 1, pre_release='alpha') == '1.3.0'
    assert bump_version('1.2.3', 1, pre_release='beta') == '1.3.0'

    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'

# Generated at 2022-06-29 18:10:05.472934
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:18.232387
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:33.916880
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:40.319637
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.0', -1) == '1.2.1'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.0', -2) == '1.3.0'

# Generated at 2022-06-29 18:10:53.593349
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version function."""

    # Test that string versions are correctly parsed into
    # their numeric components
    def test_parsed_version():
        """Test version parsing."""
        version = _build_version_info('0.2.0')
        assert version.major.txt == '0'
        assert version.minor.txt == '2'
        assert version.patch.txt == ''

        version = _build_version_info('0.2.1')
        assert version.major.txt == '0'
        assert version.minor.txt == '2'
        assert version.patch.txt == '1'

        version = _build_version_info('1.2.0')
        assert version.major.txt == '1'
        assert version.minor.txt == '2'
        assert version

# Generated at 2022-06-29 18:11:05.630473
# Unit test for function bump_version
def test_bump_version():
    # Test Bumping major version
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('3.0.0') == '4.0.0'
    assert bump_version('4.0.0') == '5.0.0'
    assert bump_version('5.0.0') == '6.0.0'
    assert bump_version('6.0.0') == '7.0.0'
    assert bump_version('7.0.0') == '8.0.0'
    assert bump_version('8.0.0') == '9.0.0'

# Generated at 2022-06-29 18:11:18.593841
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:31.241251
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.0', -3) == '1.0.0'
    assert bump_version('0.0.0', 0, 'a') == '1.0.0'
    assert bump_version('0.0.0', 1, 'a') == '0.1.0'

# Generated at 2022-06-29 18:11:43.128617
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    # Test valid parameters
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.0a0') == '0.0.0a1'
    assert bump_version('0.0.a0') == '0.0.a0'
    assert bump_version('0.0.0a1') == '0.0.0a2'
    assert bump_version('0.0.0b0') == '0.0.0b1'
    assert bump_version('0.0.0b1') == '0.0.0b2'

# Generated at 2022-06-29 18:11:51.963634
# Unit test for function bump_version
def test_bump_version():
    import random
    for major_in in range(0, 2):
        for minor_in in range(0, 3):
            for patch_in in range(0, 4):
                for pre_in in range(0, 4):
                    # Build the version string
                    version = '{}.{}.{}'.format(major_in, minor_in, patch_in)
                    if pre_in == 1:
                        version += 'a'
                    elif pre_in == 2:
                        version += 'b'
                    elif pre_in == 3:
                        version += '-RC'
                    # Randomize the bump type, position and prerelease
                    position = random.randint(-3, 2)
                    if random.randint(0, 1) == 1:
                        pre_release = 'a'

# Generated at 2022-06-29 18:12:04.757011
# Unit test for function bump_version
def test_bump_version():
    """
    >>> test_bump_version()
    1
    """
    import doctest
    from os.path import dirname, join, realpath
    from textwrap import dedent
    this_file = realpath(__file__)
    file_dir = dirname(this_file)
    test_file = join(file_dir, 'test_bump_version.rst')
    with open(test_file, 'r') as f:
        test_text = dedent(f.read())

# Generated at 2022-06-29 18:12:17.589182
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:30.606304
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.7.0') == '2.7.1'
    assert bump_version('2.7.0', 1) == '2.8.0'
    assert bump_version('2.7.8', 0) == '3.0.0'
    assert bump_version('2.7.8', 0, 'b') == '3.0.0b0'
    assert bump_version('2.7.8', -2, 'b') == '2.7.8b0'
    assert bump_version('2.7.8', 1, 'a') == '2.7.8a0'
    assert bump_version('2.7.8', 1, 'A') == '2.7.8a0'

# Generated at 2022-06-29 18:12:42.455941
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1', 2, 'a') == '1.1.2a0'
    assert bump_version('1.1.1', 2, 'b') == '1.1.2b0'
    assert bump_version('1.1.1', 2, 'alpha') == '1.1.2a0'
    assert bump_version('1.1.1', 2, 'beta') == '1.1.2b0'
    assert bump_version('1.1.1', 2, 'A') == '1.1.2a0'
    assert bump_version('1.1.1', 2, 'B') == '1.1.2b0'
    assert bump_version('1.1.1', 2, 'ALPHA') == '1.1.2a0'
   

# Generated at 2022-06-29 18:12:47.394468
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', 2, 'beta') == '0.1.3b0'
    assert bump_version('0.1.2', 2, 'b') == '0.1.3b0'
    assert bump_version('0.1.2', 2, 'a') == '0.1.3a0'
    assert bump_version('0.1.2', 2, 'alpha') == '0.1.3a0'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 1, 'beta') == '0.2.0b0'

# Generated at 2022-06-29 18:12:52.864601
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = "0.0.0"
    assert bump_version(version) == "0.0.1"
    assert bump_version(version, 2) == "0.0.1"
    assert bump_version(version, -3) == "0.0.1"
    assert bump_version(version, 2, 'a') == "0.0.1a0"
    assert bump_version(version, 2, 'alpha') == "0.0.1a0"
    assert bump_version(version, 2, 'b') == "0.0.1b0"
    assert bump_version(version, 2, 'beta') == "0.0.1b0"

    version = "0.0.0a0"

# Generated at 2022-06-29 18:13:02.372701
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0'
    assert bump_version('0.1.2') == '0.2'
    assert bump_version('1.0.0') == '2.0'
    assert bump_version('1.1.2') == '1.2'
    assert bump_version('2.1.2') == '2.2'
    assert bump_version('2.1.2-alpha') == '2.1.3'
    assert bump_version('2.1.2-alpha', 1) == '2.2'
    assert bump_version('2.1.2-alpha', 1, 'b') == '2.2-beta'
    assert bump_version('2.1.2-beta', 1, 'b') == '2.2-beta'

# Generated at 2022-06-29 18:13:15.022417
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    new_version = bump_version(version, -1)
    assert new_version == '1.2.4'

    new_version = bump_version(version, -1, 'a')
    assert new_version == '1.2.4a0'
    new_version = bump_version(version, -1, 'b')
    assert new_version == '1.2.4b0'

    version = '1.2.3a0'
    new_version = bump_version(version, -1)
    assert new_version == '1.2.3'

    new_version = bump_version(version, -1, 'a')
    assert new_version == '1.2.3a1'

# Generated at 2022-06-29 18:13:23.287578
# Unit test for function bump_version
def test_bump_version():
    version = "1.7.0"
    bumped = bump_version(version, position=1)
    assert bumped == "1.8.0"

    bumped = bump_version(version, position=2)
    assert bumped == "1.7.1"

    bumped = bump_version(version, position=2, pre_release="alpha")
    assert bumped == "1.7.1a0"

    bumped = bump_version(version, position=1, pre_release="alpha")
    assert bumped == "1.7.0a0"

    bumped = bump_version("1.7.0a0", position=0)
    assert bumped == "2.0.0"

    bumped = bump_version("1.7.0a0", position=1)
    assert bumped == "1.8.0"

    bumped = bump

# Generated at 2022-06-29 18:13:36.235448
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:46.185313
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', 2, 'a') == '0.0.0a0'
    assert bump_version('0.0.0', 2, 'b') == '0.0.0b0'
    assert bump_version('0.0.0', 2, 'A') == '0.0.0a0'
    assert bump_version('0.0.0', 2, 'B') == '0.0.0b0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 0, 'a') == '1.0.0a0'

# Generated at 2022-06-29 18:13:59.451096
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion
    def an_assert(version, position=2, pre_release=None):
        bumped_version = bump_version(version, position, pre_release)
        assert StrictVersion(bumped_version) > StrictVersion(version)
    an_assert("0.0.0")
    an_assert("0.0.0", 0)
    an_assert("0.0.0", 1)
    an_assert("0.0.0", 2)
    an_assert("0.0.0", -1)
    an_assert("0.0.0", -2)
    an_assert("0.0.0", -3)
    an_assert("0.0.0", "a")
    an_assert("0.0.0", "alpha")
    an_

# Generated at 2022-06-29 18:14:10.631073
# Unit test for function bump_version
def test_bump_version():
    # Unit test with default values into the function bump_version
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.3.0') == '1.3.1'
    assert bump_version('0.0.0') == '0.1.0'
    assert bump_version('0.0.0', pre_release="b") == '0.1.0'


# Generated at 2022-06-29 18:14:17.899772
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'

    assert bump_version('1.0.0', -1) == '0.0.1'
    assert bump_version('1.0.0', -2) == '0.1.0'
    assert bump_version('1.0.0', -3) == '1.0.0'

    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'

# Generated at 2022-06-29 18:14:28.832372
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', 0) == '1.0.0'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 2) == '0.1.3'
    assert bump_version('0.1.2', 3) == '0.1.3'
    assert bump_version('0.1.2', 4) == '0.1.3'
    assert bump_version('0.1.2', 5) == '0.1.3'
    assert bump_version('0.1.2', 6) == '0.1.3'

# Generated at 2022-06-29 18:14:41.194507
# Unit test for function bump_version
def test_bump_version():
    if len(sys.argv) > 1:
        print("version: %s" % sys.argv[1])
        print("bump to: %s" % bump_version(sys.argv[1]))
    else:
        print("version: %s" % "0.0.0")
        print("bump to: %s" % bump_version("0.0.0"))

    # Test successful major/minor/patch bump without pre-release
    print("version: %s" % "1.2.0")
    print("bump to: %s" % bump_version("1.2.0", 0))
    print("version: %s" % "1.2.1")
    print("bump to: %s" % bump_version("1.2.1", 1))

# Generated at 2022-06-29 18:14:45.177179
# Unit test for function bump_version
def test_bump_version():
    version: str = '1.0.0'
    bumped_version: str = bump_version(version)
    #noinspection SpellCheckingInspection
    expected_version: str = '1.0.1'
    assert bumped_version == expected_version, \
        'Wrong version: {}'.format(bumped_version)


# Generated at 2022-06-29 18:14:54.171218
# Unit test for function bump_version
def test_bump_version():
    print("testing bump_version... ", end="")

    assert bump_version("1.2.3") == "1.2.4"
    assert bump_version("1.2.3", 1) == "1.3.3"
    assert bump_version("1.2.3", 1, "b") == "1.3.3b0"
    assert bump_version("1.2.3", 1, "b") == "1.3.3b0"
    assert bump_version("1.2.999", -1) == "1.2.999"
    assert bump_version("1.2.999", 0) == "2.0.0"
    assert bump_version("1.2.999", 2) == "1.2.999"

# Generated at 2022-06-29 18:15:00.467203
# Unit test for function bump_version
def test_bump_version():
    """
    Make sure the bump_version output is correct.
    """
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('1.23.456') == '1.23.457'
    assert bump_version('0.23.456') == '0.24.0'
    assert bump_version('0.23.456', 1, 'a') == '0.24.0a0'

# Generated at 2022-06-29 18:15:04.528465
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    bumped_version = bump_version(version)
    print(bumped_version)

# Code for testing function
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:15:11.276323
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version() function.
    """

# Generated at 2022-06-29 18:15:24.042056
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', pre_release='a') == '1.0.1a0'
    assert bump_version('1.0.0', pre_release='a', position=-1) == '1.0.1a0'
    assert bump_version('1.0.1', pre_release='a') == '1.0.1a1'
    assert bump_version('1.0.0', pre_release='b') == '1.0.1b0'
    assert bump_version('1.0.0', pre_release='b', position=-1) == '1.0.1b0'

# Generated at 2022-06-29 18:15:45.814094
# Unit test for function bump_version
def test_bump_version():
    import pytest

    # Test the base case
    assert bump_version('1.2.3') == '1.2.4'

    # Test the rest of the cases for patch

    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.0'
    assert bump_version('1.2.3', -2) == '1.0.0'
    assert bump_version('1.2.3', -3) == '0.0.0'


# Generated at 2022-06-29 18:15:55.833130
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('3.1.2') == '3.1.3'
    assert bump_version('4.5.6') == '4.5.7'
    assert bump_version('1.2.1') == '1.2.2'

    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.1', 0) == '2.0.0'
    assert bump_version('3.1.2', 0) == '4.0.0'  # version bump

# Generated at 2022-06-29 18:16:07.982253
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert bump_version(version) == '0.0.1'
    version = '0.0.123'
    assert bump_version(version) == '0.0.124'
    version = '0.1.0'
    assert bump_version(version) == '0.1.1'
    version = '0.1.1'
    assert bump_version(version) == '0.1.2'
    version = '0.1.123'
    assert bump_version(version) == '0.1.124'
    version = '1.0.0'
    assert bump_version(version) == '1.0.1'
    version = '1.0.1'
    assert bump_version(version) == '1.0.2'

# Generated at 2022-06-29 18:16:16.713699
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from distutils.version import LooseVersion
    from . import __version__

    def test_case(
            version_in: str,
            position: int,
            pre_release: str,
            version_out: str,
    ):
        assert bump_version(
            version_in,
            position,
            pre_release
        ) == version_out

    def test_release_prerelease(version_in: str, version_out: str):
        assert bump_version(version_in) == version_out
