

# Generated at 2022-06-29 18:06:46.895916
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.0.1", 2, None) == "0.0.2"
    assert bump_version("0.0.1", 1, None) == "0.1.0"
    assert bump_version("0.0.1", 0, None) == "1.0.0"

    assert bump_version("0.0.1", 2, "alpha") == "0.0.1a0"
    assert bump_version("0.0.1", 2, "beta") == "0.0.1b0"

    assert bump_version("0.0.1", 2) == "0.0.2"
    assert bump_version("0.0.1", 1) == "0.1.0"
    assert bump_version("0.0.1", 0) == "1.0.0"

# Generated at 2022-06-29 18:06:54.130505
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1') == '0.2'
    assert bump_version('0.1.5') == '0.1.6'
    assert bump_version('0.1.5', position=1) == '0.2'
    assert bump_version('0.1.5', position=0) == '1.0'
    assert bump_version('0.1.5', position=0, pre_release='a') == \
        '1.0a0'
    assert bump_version('0.1.5', position=1, pre_release='a') == \
        '0.2a0'
    assert bump_version('0.1.5', position=1, pre_release='b') == \
        '0.2b0'

# Generated at 2022-06-29 18:07:04.970749
# Unit test for function bump_version
def test_bump_version():
    import unittest


# Generated at 2022-06-29 18:07:16.485420
# Unit test for function bump_version
def test_bump_version():
    # Check if any Exception is raised
    ver_obj = "2.12.0"
    ver = bump_version(ver_obj,0)
    print(ver)
    ver_obj = "2.6.0"
    ver = bump_version(ver_obj,1)
    print(ver)
    ver_obj = "2.6.0"
    ver = bump_version(ver_obj,2)
    print(ver)
    ver_obj = "1.14.0"
    ver = bump_version(ver_obj,2)
    print(ver)
    ver_obj = "1.14.0"
    ver = bump_version(ver_obj,-2)
    print(ver)
    ver_obj = "1.14.0"

# Generated at 2022-06-29 18:07:26.022653
# Unit test for function bump_version
def test_bump_version():
    # Base test
    version = '0.2.0'
    assert bump_version(version) == '0.2.1'

    # Major bump
    version = '0.2.0'
    assert bump_version(version, position=0) == '1.0.0'

    # Minor bump
    version = '0.2.0'
    assert bump_version(version, position=1) == '0.3.0'

    # Patch alpha bump
    version = '0.2.0'
    assert bump_version(version, position=2, pre_release='a') == '0.2.1a0'

    # Patch beta bump
    version = '0.2.0'
    assert bump_version(version, position=2, pre_release='b') == '0.2.1b0'



# Generated at 2022-06-29 18:07:37.957928
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.4', pre_release='A') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='B') == '1.2.4b0'
    assert bump_version('1.2.4b0', pre_release='A') == '1.2.5a0'
    assert bump_version('1.2.4a0', pre_release='A') == '1.2.4a1'
    assert bump_version('1.2.4b0', pre_release='B') == '1.2.4b1'

# Generated at 2022-06-29 18:07:49.708023
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', pre_release='a') == '0.2.2a0'
    assert (
        bump_version('0.2.1', pre_release='a', position=0) == '1.0.0')
    assert bump_version('1.2.1', pre_release='a') == '1.2.2a0'
    assert bump_version('1.2.1', pre_release='a', position=0) == '2.0.0'
    assert bump_version('1.2.1', pre_release='a', position=-1) == '1.3.0'

# Generated at 2022-06-29 18:07:57.457344
# Unit test for function bump_version
def test_bump_version():
    print('Test function bump_version')
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', 0) == '1.0.0'
    assert bump_version('0.2.0', -1) == '0.2.1'
    assert bump_version('0.2.0', 1) == '0.3.0'
    assert bump_version('0.2.0', -2) == '0.3.0'
    assert bump_version('0.2.0', -2, 'a') == '0.3.0a0'
    assert bump_version('0.2.0a0') == '0.2.0a1'

# Generated at 2022-06-29 18:08:10.296986
# Unit test for function bump_version
def test_bump_version():
    """bump_version function needs test.
    """
    # noinspection SpellCheckingInspection

# Generated at 2022-06-29 18:08:20.949449
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -3) == '2.0.0'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', pre_release='alpha') == '1.0.0a0'

# Generated at 2022-06-29 18:08:42.423589
# Unit test for function bump_version
def test_bump_version():
    version = "3.0.0"
    position = 0
    pre_release = None
    expected_value = "4.0.0"
    actual_value = bump_version(version, position, pre_release)

    assert expected_value == actual_value

# Generated at 2022-06-29 18:08:54.202199
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:06.443048
# Unit test for function bump_version
def test_bump_version():
    def _test_case(version: str, position: int, pre_release: str):
        print(
            'bump_version(%r, %r, %r) = %r' % (
                version, position, pre_release,
                bump_version(version, position, pre_release)
            )
        )


# Generated at 2022-06-29 18:09:19.012256
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=no-member
    from operator import attrgetter

    # Test bump_version (without 'pre_release' arg)
    def test_pre_release_is_none(
            ver: str,
            pos: int,
            expt: str
    ) -> None:
        bump = bump_version(ver, pos)
        bump_obj = StrictVersion(bump)
        expt_obj = StrictVersion(expt)
        assert bump_obj == expt_obj

    def test_pre_release_is_not_none(
            ver: str,
            pre: str,
            pos: int,
            expt: str
    ) -> None:
        bump = bump_version(ver, pos, pre)
        bump_obj = StrictVersion(bump)
        expt

# Generated at 2022-06-29 18:09:32.555887
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:43.511913
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.1.0a0', 0) == '2.0.0'
    assert bump_version('2.0.0', 1) == '2.1.0'

# Generated at 2022-06-29 18:09:56.211616
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.0', pre_release='a') == '1.2.1a0'
    assert bump_version('1.2.0', 2, pre_release='a') == '1.2.1a0'
    assert bump_version('1.2.0', 1, pre_release='a') == '1.3.0a0'

# Generated at 2022-06-29 18:10:03.225118
# Unit test for function bump_version
def test_bump_version():
    # Bump major
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.1.0') == '2.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    assert bump_version('1.0.0-alpha.1') == '2.0.0'
    assert bump_version('1.1.0-alpha.1') == '2.0.0'
    assert bump_version('1.1.1-beta.1') == '2.0.0'
    assert bump_version('1.1.1-beta.1', position=0) == '2.0.0'
    # Bump major

# Generated at 2022-06-29 18:10:15.928964
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:28.657221
# Unit test for function bump_version
def test_bump_version():
    # Scenario 1
    print("V1.2.1 --> {0}".format(bump_version("1.2.1")))
    assert bump_version("1.2.1") == "1.2.2"

    # Scenario 2
    print("V1.2.1a0 --> {0}".format(bump_version("1.2.1a0")))
    assert bump_version("1.2.1a0") == "1.2.1a1"

    # Scenario 3
    print("V1.2.1a9 --> {0}".format(bump_version("1.2.1a9")))
    assert bump_version("1.2.1a9") == "1.2.1a10"

    # Scenario 4

# Generated at 2022-06-29 18:10:55.468320
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1a1') == '0.1.2'
    assert bump_version('0.1.1b1') == '0.1.2'
    assert bump_version('0.1.0a1') == '0.1.1'
    assert bump_version('0.1.0b1') == '0.1.1'
    assert bump_version('0.1.0a1', pre_release='a') == '0.1.0a2'
    assert bump_version('0.1.0a1', pre_release='b') == '0.1.0b2'
    assert bump

# Generated at 2022-06-29 18:11:07.026471
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=-1) == '1.2.1'
    assert bump_version('1.2.0', position=-2) == '1.3.0'
    assert bump_version('1.2.0', position=-3) == '2.0.0'
    assert bump_version('1.2.0', position=0) == '2.0.0'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.2.0-a1') == '1.2.1'
    assert bump_

# Generated at 2022-06-29 18:11:20.661404
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.1') == '2.0.2'
    assert bump_version('2.0.1', -2) == '2.0.2'
    assert bump_version('2.0.1', -1) == '2.1.0'
    assert bump_version('2.0.1', -0) == '3.0.0'
    assert bump_version('2.0.1', 0) == '3.0.0'
    assert bump_version('2.0.1', 1) == '2.1.0'
    assert bump_version('2.0.1', 2) == '2.0.2'
    assert bump_version('2.0.1', 3) == '2.0.2'


# Generated at 2022-06-29 18:11:25.503453
# Unit test for function bump_version
def test_bump_version():
    FUNCTION_NAME = 'bump_version'
    VERSION_NAME = '0.12.0'

    EXPECTED_DEFAULT = '0.12.1'
    RESULT_DEFAULT = bump_version(VERSION_NAME)
    assert RESULT_DEFAULT == EXPECTED_DEFAULT, (
        'The function {}() does not return the desired value. '
        '\nEXPECTED: {}\n  RESULT: {}'.format(
            FUNCTION_NAME, EXPECTED_DEFAULT, RESULT_DEFAULT
        )
    )

    EXPECTED_MAJOR = '1.0.0'
    RESULT_MAJOR = bump_version(VERSION_NAME, 0)

# Generated at 2022-06-29 18:11:31.957718
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.0.0') == '1.0.1')
    assert(bump_version('1.0.0', position=-3) == '2.0.0')
    assert(bump_version('1.0.0', position=-2) == '1.1.0')
    assert(bump_version('1.0.0', position=-1) == '1.0.1')
    assert(bump_version('1.0.0', position=0) == '2.0.0')
    assert(bump_version('1.0.0', position=1) == '1.1.0')
    assert(bump_version('1.0.0', position=2) == '1.0.1')

# Generated at 2022-06-29 18:11:43.736638
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2') == '1.2.1'
    assert bump_version('1.2-a0') == '1.2a1'
    assert bump_version('1.2-a') == '1.2a1'
    assert bump_version('1.2.3-a0') == '1.2.3a1'
    assert bump_version('1.2.3-a') == '1.2.3a1'
    assert bump_version('1.2.3-b0') == '1.2.3b1'
    assert bump_version('1.2.3-b') == '1.2.3b1'

    assert bump_version('1.2.3', 0)

# Generated at 2022-06-29 18:11:52.313026
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 0, 'a') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'b') == '1.1.0b0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'

# Generated at 2022-06-29 18:11:56.382443
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0201
    from tests.test_bumpversion import test_bump_version
    test_bump_version(bump_version)

# Generated at 2022-06-29 18:12:02.466201
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:14.871020
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:48.834390
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:00.001176
# Unit test for function bump_version
def test_bump_version():
    from operator import eq
    from dlkit.json_.utilities import string_to_python_date

    def assert_eq(a, b):
        assert eq(a, b), (a, b, 'not equa')

    def assert_true(a):
        assert eq(a, True), (a, 'not equal to True')

    def assert_false(a):
        assert eq(a, False), (a, 'not equal to False')

    def assert_none(a):
        assert eq(a, None), (a, 'not equal to None')

    # String version: 1.2.3-alpha.1
    # Tuple version: (1, 2, 3, 'alpha', 1)
    version = '1.2.3-alpha.1'


# Generated at 2022-06-29 18:13:12.416403
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2') == '0.3'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.1.dev1') == '1.2.2.dev1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2', 0) == '2.2'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1.2', 2) == '1.2.1'
    assert bump_version('1.2', -1) == '1.2.1'

# Generated at 2022-06-29 18:13:21.596924
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:34.139976
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    hold: List[Union[int, str]] = []
    # Should raise an error due to out of range position
    hold.append(False)
    try:
        bump_version('1.0.0', position=-5, pre_release=None)
    except ValueError:
        hold[0] = True
    assert hold[0] is True

    # Bump major version
    assert bump_version('1.0.0', position=0, pre_release=None) == '2.0.0'
    assert bump_version('1.1.1', position=0, pre_release=None) == '2.0.0'
    assert bump_version('0.0.4', position=0, pre_release=None) == '1.0.0'
    assert bump_version

# Generated at 2022-06-29 18:13:39.305475
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', 1) == '1.2.0'
    assert bump_version('1.1.1', 0) == '2.0.0'
    assert bump_version('1.1.1', -1) == '1.1.2'
    assert bump_version('1.1.1', -2) == '1.2.0'

# Generated at 2022-06-29 18:13:48.104224
# Unit test for function bump_version
def test_bump_version():
    # Major bump
    assert bump_version('1.2.0') == '2.0.0'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.0', -3) == '2.0.0'

    # Minor bump (increment)
    assert bump_version('1.2.0') == '1.3.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.0', -2) == '1.3.0'

    # Minor bump (pre-release)
    assert bump_version('1.2.0', 1, 'a') == '1.2a0'

# Generated at 2022-06-29 18:14:01.506059
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function.
    """
    # The first 8 tests are for version number only
    assert bump_version(
        version="0.0.0"
    ) == "0.0.1"

    assert bump_version(
        version="0.0.1"
    ) == "0.0.2"

    assert bump_version(
        version="0.0.1",
        position=0
    ) == "1.0.0"

    assert bump_version(
        version="0.0.1",
        position=1
    ) == "0.1.0"

    assert bump_version(
        version="0.0.1",
        position=-2
    ) == "0.1.0"


# Generated at 2022-06-29 18:14:11.203436
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion

# Generated at 2022-06-29 18:14:14.453946
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'



# Generated at 2022-06-29 18:14:37.159895
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.0.0', 0) == '3.0.0'
    assert bump_version('2.0.0', -3) == '3.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('0.9.9', 1) == '0.10.0'
    assert bump_version('0.9.9', 2) == '0.9.10'
    assert bump_version('1.0.0-alpha') == '1.0.1-alpha.0'
    assert bump_version('1.1.0-alpha.1') == '1.1.0-alpha.2'

# Generated at 2022-06-29 18:14:46.810831
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version"""

    print(bump_version('1.0.0', 1))
    print(bump_version('1.0.0', 1, pre_release='b'))
    print(bump_version('1.1a2.0', 1, pre_release='b'))
    print(bump_version('1.1a1.0', 1, pre_release='b'))
    print(bump_version('1.1a1.1', 1, pre_release='b'))
    print(bump_version('1.1a1.0', 1, pre_release='a'))
    print(bump_version('1.1.0', 1, pre_release='a'))

# Generated at 2022-06-29 18:14:54.865822
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:06.017897
# Unit test for function bump_version
def test_bump_version():
    print("Beginning test_bump_version().")
    # 1. Test normal.
    # 1.1 Test without a pre-release.
    # 1.1.1 Test bump major
    print("1.1 Normal, without pre-release, bumping major")
    assert bump_version("0.1.0") == "1.0.0"
    assert bump_version("0.1.0", position=0) == "1.0.0"
    assert bump_version("0.1.0", position=-3) == "1.0.0"
    # 1.1.2 Test bump minor
    print("1.1 Normal, without pre-release, bumping minor")
    assert bump_version("0.1.0", position=1) == "0.2.0"

# Generated at 2022-06-29 18:15:16.513047
# Unit test for function bump_version
def test_bump_version():
    version = "0.1.0"
    print("Version: ", version, "Version Bumped: ", bump_version(version, 1))
    version = "0.0.0"
    print("Version: ", version, "Version Bumped: ", bump_version(version, 1))
    version = "0.0.0"
    print("Version: ", version, "Version Bumped: ", bump_version(version, 1, "alpha"))
    version = "0.0.0-alpha"
    print("Version: ", version, "Version Bumped: ", bump_version(version, 1, "alpha"))
    version = "0.0.0-alpha.2"
    print("Version: ", version, "Version Bumped: ", bump_version(version, 1, "alpha"))
    version = "0.1.0-alpha.2"

# Generated at 2022-06-29 18:15:28.149678
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:34.604659
# Unit test for function bump_version
def test_bump_version():
    versions = [
        {'major': '1.0.0', 'minor': '1.1.0', 'patch': '1.1.1'},
        {'major': '1.0.2', 'minor': '1.1.2', 'patch': '1.1.3'},
        {'major': '1.4.4', 'minor': '1.5.4', 'patch': '1.5.5'},
        {'major': '1.4.4', 'minor': '1.4.4', 'patch': '1.4.4'}
    ]

    for version in versions:
        assert bump_version(version['major'], 0) == version['major']
        assert bump_version(version['minor'], 1) == version['minor']
        assert bump_

# Generated at 2022-06-29 18:15:46.306358
# Unit test for function bump_version
def test_bump_version():
    def _t1(ver, pos, pre, exp):
        tst = bump_version(ver, position=pos, pre_release=pre)
        assert exp == tst

    # Major, minor, and patch
    _t1('1.2.3', 0, None, '2.0.0')
    _t1('1.2.3', 1, None, '1.3.0')
    _t1('1.2.3', 2, None, '1.2.4')

    # Pre-release
    _t1('0.0.1', 0, 'a', '1.0.0a0')
    _t1('0.0.1', 1, 'a', '0.1.0a0')

# Generated at 2022-06-29 18:15:56.189745
# Unit test for function bump_version
def test_bump_version():
    """
    Tests that bump_version function can accept and change versions
    """
    assert bump_version("0.0.0") == "0.0.1"
    assert bump_version("0.0.0", pre_release="a") == "0.0.1a0"
    assert bump_version("0.0.0", pre_release="b") == "0.0.1b0"
    assert bump_version("0.0.0", pre_release="a") == "0.0.1a0"
    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.0.0", pre_release="a") == "1.0.1a0"

# Generated at 2022-06-29 18:16:08.071577
# Unit test for function bump_version
def test_bump_version():

	def run_test(old_ver, new_ver, pos=2, pre_rel=None):
		assert bump_version(old_ver, position=pos, pre_release=pre_rel) == new_ver

	run_test('0.0.0', '1.0.0')
	run_test('1.0.0', '2.0.0')
	run_test('1.10.0', '2.0.0')
	run_test('1.0.0', '1.1.0', pos=1)
	run_test('1.0.0', '1.1.0', pos=1)
	run_test('1.0.0', '1.0.1', pos=2)