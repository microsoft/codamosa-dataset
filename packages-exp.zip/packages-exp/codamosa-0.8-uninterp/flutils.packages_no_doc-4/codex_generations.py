

# Generated at 2022-06-29 18:06:50.618832
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', pre_release='a') == '0.0.1a0'
    assert bump_version('0.0.1a0', pre_release='a') == '0.0.1a1'
    assert bump_version('0.0.1a0', pre_release='b') == '0.0.1b0'
    assert bump_version('0.0.1b0') == '0.0.2'

# Generated at 2022-06-29 18:07:00.556031
# Unit test for function bump_version
def test_bump_version():
    # Test for major version bump
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('3.0.0') == '4.0.0'
    # Test for minor version bump
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('2.0.0', 1) == '2.1.0'
    assert bump_version('3.0.0', 1) == '3.1.0'
    # Test for patch version bump

# Generated at 2022-06-29 18:07:05.681408
# Unit test for function bump_version
def test_bump_version():
    versions = ['1.0.0', '1.0.0beta']
    for version in versions:
        version_bumped = bump_version(version)
        print("version: {},  version bumped: {}".format(version, version_bumped))


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:07:17.221905
# Unit test for function bump_version
def test_bump_version():
    from tempfile import TemporaryDirectory
    from os.path import exists
    from subprocess import run, check_output
    import pytest
    from shutil import copyfile


# Generated at 2022-06-29 18:07:26.429722
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:38.484166
# Unit test for function bump_version
def test_bump_version():
    print("0.1.0")
    assert bump_version("0.1.0") == "0.2.0"
    assert bump_version("0.1.0", 2) == "0.2.0"

    print("0.1.1")
    assert bump_version("0.1.1") == "0.2.0"
    assert bump_version("0.1.1", 2) == "0.2.0"
    assert bump_version("0.1.1", -1) == "0.1.2"
    assert bump_version("0.1.1", -1, 'a') == "0.1.2a0"
    assert bump_version("0.1.1", -1, 'b') == "0.1.2b0"


# Generated at 2022-06-29 18:07:50.184603
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2b2') == '0.1.3b0'
    assert bump_version('0.1.2b2', pre_release='a') == '0.1.2a3'
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', pre_release='a') == '0.1.2a1'
    assert bump_version('0.1.2b0', pre_release='b') == '0.1.2b1'
    assert bump_version('0.1.2-a2', pre_release='b') == '0.1.2-b0'

# Generated at 2022-06-29 18:07:58.761298
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.3.0'
    assert bump_version('1.2.3', -2) == '2.0.0'
    assert bump_version('1.2.3', -3) == '1.3.0'
    assert bump_version('1.2.0') == '1.2.1'

# Generated at 2022-06-29 18:08:10.943980
# Unit test for function bump_version
def test_bump_version():
    from distutils.version import StrictVersion
    ver_str = '1.2.3'
    ver_obj = StrictVersion(ver_str)

    ver_txt = bump_version(ver_str, 0)
    ver_obj = StrictVersion(ver_txt)
    assert ver_obj.version[0] == 2

    ver_txt = bump_version(ver_str, 1)
    ver_obj = StrictVersion(ver_txt)
    assert ver_obj.version[0] == 1
    assert ver_obj.version[1] == 3

    ver_txt = bump_version(ver_str, 2)
    ver_obj = StrictVersion(ver_txt)
    assert ver_obj.version[0] == 1
    assert ver_obj.version[1] == 2

# Generated at 2022-06-29 18:08:21.159905
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', 2, 'beta') == '1.0.0b0'
    assert bump_version('1.0.0', 2, 'alpha') == '1.0.0a0'
    assert bump_version('1.0.0', 2, 'a') == '1.0.0a0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.0b0'
    assert bump_version('1.0.0', -1) == '1.0'
    assert bump_version('1.0.0', -2) == '1.1'
    assert bump_version('1.0.0', -3) == '2.0'

# Generated at 2022-06-29 18:08:59.038147
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys
    import traceback
    class TestBumpVersion(unittest.TestCase):
        def test_basics(self):
            version = '0.1.0'
            self.assertEqual(bump_version(version), '0.1.1')
            self.assertEqual(bump_version(version, position=2), '0.1.1')
            self.assertEqual(bump_version(version, position=3), '0.1.0')
            self.assertEqual(bump_version(version, position=4), '0.1.0')
            self.assertEqual(bump_version(version, position=5), '0.1.0')

# Generated at 2022-06-29 18:09:11.646325
# Unit test for function bump_version
def test_bump_version():
    import pytest
    fp = 'version_bump'
    res = bump_version('0.0.0')
    assert res == '1.0.0', f'{fp}: Error in assertion 1'

    res = bump_version('1.3.8')
    assert res == '1.3.9', f'{fp}: Error in assertion 2'

    res = bump_version('1.3.8', 3)
    assert res == '1.4.0', f'{fp}: Error in assertion 3'

    res = bump_version('1.3.8a3')
    assert res == '1.3.8a4', f'{fp}: Error in assertion 4'

    res = bump_version('1.3.8b1')

# Generated at 2022-06-29 18:09:21.412423
# Unit test for function bump_version
def test_bump_version():
    version = "0.13.4"
    position = 2
    pre_release = None
    assert bump_version(version, position, pre_release) == "0.13.5"
    version = "0.13.4"
    position = -1
    pre_release = None
    assert bump_version(version, position, pre_release) == "0.14.0"
    version = "0.13.4"
    position = 1
    pre_release = "a"
    assert bump_version(version, position, pre_release) == "0.14.0a0"
    version = "0.13.0a1"
    position = 1
    pre_release = "a"
    assert bump_version(version, position, pre_release) == "0.13.0a2"

# Generated at 2022-06-29 18:09:34.053431
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', position=2, pre_release=None) == '1.0.1'
    assert bump_version('1.0.0', position=1, pre_release=None) == '1.1.0'
    assert bump_version('1.0.0', position=0, pre_release=None) == '2.0.0'
    assert bump_version('1.0.0', position=2, pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0', position=1, pre_release='a') == '1.0a0'
    assert bump_version('1.0.0', position=1, pre_release='b') == '1.0b0'

# Generated at 2022-06-29 18:09:44.667123
# Unit test for function bump_version
def test_bump_version():
    '''
    Test for the function bump_version.
    '''
    # 2.1.5 => 2.1.6
    version = bump_version('2.1.5')
    assert version == '2.1.6'
    # 2.1 => 2.1.1
    version = bump_version('2.1')
    assert version == '2.1.1'
    # 2.1b1 => 2.1b2
    version = bump_version('2.1b1')
    assert version == '2.1b2'
    # 2.1 => 2.2
    version = bump_version('2.1', position=1)
    assert version == '2.2'
    # 2.1.0 => 2.1.1

# Generated at 2022-06-29 18:09:57.370167
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.0') == '2.0'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0a') == '1.0.1a0'
    assert bump_version('1.0a') == '1.0a1'
    assert bump_version('1.0a.0') == '1.0a.1'
    assert bump_version('1.0.1b0') == '1.0.1b1'
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.10.0') == '1.11.0'

# Generated at 2022-06-29 18:10:07.703433
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function bump_version."""
    # Test version 1
    ver = bump_version('1.0.0')
    assert ver == '1.0.1'

    # Test version 2
    ver = bump_version('1.0.0', position=1)
    assert ver == '1.1.0'

    # Test version 3
    ver = bump_version('1.0.0', position=0)
    assert ver == '2.0.0'

    # Test version 4
    ver = bump_version('1.0.0', position=1, pre_release='a')
    assert ver == '1.1.0a0'

    # Test version 5
    ver = bump_version('1.0.0', position=1, pre_release='b')

# Generated at 2022-06-29 18:10:19.622411
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:32.575349
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:38.131298
# Unit test for function bump_version
def test_bump_version():
    # Test bad argument values
    from pytest import raises
    with raises(TypeError):
        bump_version(
            version='',
            position=None,
            pre_release=None,
        )
    with raises(TypeError):
        bump_version(
            version='',
            position=1,
            pre_release=1,
        )
    with raises(TypeError):
        bump_version(
            version='',
            position=1,
            pre_release='a',
        )
    with raises(ValueError):
        bump_version(
            version='',
            position=2,
            pre_release='xyz',
        )
    with raises(ValueError):
        bump_version(
            version='',
            position=-1,
            pre_release='beta',
        )

# Generated at 2022-06-29 18:10:55.312965
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.0', -3) == '1.0.0'

    assert bump_version('0.0.0', 1, 'a') == '0.1a0'

# Generated at 2022-06-29 18:11:06.901997
# Unit test for function bump_version
def test_bump_version():
    def _check(version: str, expect: str):
        result = bump_version(version, position=0)
        assert result == expect, \
            "'%s' + 1: '%s' != '%s'" % (version, result, expect)

    _check('0.0.0', '1.0.0')
    _check('0.0.0a0', '1.0.0')
    _check('0.0.0a1', '1.0.0')
    _check('0.0.0b0', '1.0.0')
    _check('0.0.0b1', '1.0.0')
    _check('0.0.1', '1.0.0')
    _check('0.0.1a0', '1.0.0')
   

# Generated at 2022-06-29 18:11:20.613574
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('0.99.99') == '1.0.0'
    assert bump_version('0.99.99', pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0a0', pre_release='a') == '1.0.0a1'
    assert bump_version('1.0.0a1', pre_release='b') == '1.0.0b0'

# Generated at 2022-06-29 18:11:34.045846
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=C0111
    # pylint: disable=R0912
    # pylint: disable=R0915
    # pylint: disable=R0914
    def test_bump_version_n(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        got = bump_version(version, position, pre_release)
        assert got == expected, "Got: %r, Expected: %r" % (got, expected)

    test_bump_version_n(
        '1.2.3',
        0,
        None,
        '2.0'
    )

# Generated at 2022-06-29 18:11:45.138653
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("2.0.0") == "2.0.1"
    assert bump_version("2.0.0", 2, None) == "2.0.1"
    assert bump_version("2.1.2", 2, None) == "2.1.3"
    assert bump_version("0.0.0", 2, None) == "0.0.1"
    assert bump_version("1.2.3") == "1.2.4"
    assert bump_version("1.2.3", 2, None) == "1.2.4"
    assert bump_version("1.2.3", 1, None) == "1.3.0"
    assert bump_version("1.2.3", 0, None) == "2.0.0"

# Generated at 2022-06-29 18:11:53.040876
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:05.126362
# Unit test for function bump_version
def test_bump_version():
    test_version: str = '1.2.3'
    bumped_version: str = bump_version(test_version)
    assert bumped_version == '1.2.4'
    bumped_version: str = bump_version(test_version, 2)
    assert bumped_version == '1.2.4'
    bumped_version: str = bump_version(test_version, 2, 'a')
    assert bumped_version == '1.2.4'
    bumped_version: str = bump_version(test_version, -1)
    assert bumped_version == '1.2.4'
    bumped_version: str = bump_version(test_version, -1, 'a')
    assert bumped_version == '1.2.4'
    bumped_version: str = bump_version(test_version, -2)

# Generated at 2022-06-29 18:12:17.915429
# Unit test for function bump_version
def test_bump_version():
    from py_make.core.c_call import call_main
    from py_make.core.c_path import Path
    from py_make.core.c_test import (
        do_test_file,
        do_test_string,
        test_file,
    )
    from py_make.modules.module_version import module_path_src
    kwargs = {
        'func_name': 'bump_version',
        'module_file': module_path_src,
        'function_name': 'bump_version',
        'kwargs': {},
    }


# Generated at 2022-06-29 18:12:27.057018
# Unit test for function bump_version
def test_bump_version():
    # Test for argument 'version'
    # Use   assert_raises    to check if ValueError is raised (see pythontutor.com)
    # Use   assert_warns     to check if UserWarning is raised (see pythontutor.com)
    # Use   assert_no_warnings to check that no warning is raised (see pythontutor.com)
    pass

    # Test for argument 'position'
    # Use   assert_raises    to check if ValueError is raised (see pythontutor.com)
    # Use   assert_warns     to check if UserWarning is raised (see pythontutor.com)
    # Use   assert_no_warnings to check that no warning is raised (see pythontutor.com)
    pass

    # Test for argument 'pre_release'
    # Use   assert_

# Generated at 2022-06-29 18:12:39.212973
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:59.285409
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:12.284461
# Unit test for function bump_version
def test_bump_version():
    version = '2.0.0'
    for prerelease in ('', None):
        for position in range(3):
            v = bump_version(version, position, prerelease)
            assert v == '3.0.0'

    for prerelease in ('a', 'alpha'):
        for position in (1, 2):
            v = bump_version(version, position, prerelease)
            assert v == '2.1.0a0'

    for prerelease in ('b', 'beta'):
        for position in (1, 2):
            v = bump_version(version, position, prerelease)
            assert v == '2.1.0b0'

    prerelease = 'alpha'
    for position in (1, 2):
        v = bump_version(version, position, prerelease)

# Generated at 2022-06-29 18:13:20.166448
# Unit test for function bump_version
def test_bump_version():
    # This function was written specifically to test the functionality of the
    # function bump_version in this module. User input is obtained
    # through the console. This function will continue to run and allow the
    # user to input different values until the user presses ^C to exit the
    # application
    try:
        while True:
            version = input("Enter a version (ex. '1.2.3a0'): ")
            position = int(input("Enter the position to bump: "))
            pre_release = input("Enter the prerelease identifier (ex. 'a'): ")
            print(bump_version(version, position, pre_release))
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-29 18:13:33.579531
# Unit test for function bump_version
def test_bump_version():
    # Test for current app version
    assert(bump_version("1.7.3") == "1.7.4")
    assert(bump_version("1.7.3", 0) == "1.8.0")
    assert(bump_version("1.7.3", -2) == "1.7.4")
    assert(bump_version("1.7.3", 1) == "2.0.0")
    assert(bump_version("1.7.3", -1) == "1.8.0")

    assert(bump_version("1.7.3") == "1.7.4")
    assert(bump_version("1.7.3", 0) == "2.0.0")

# Generated at 2022-06-29 18:13:44.292742
# Unit test for function bump_version
def test_bump_version():
    print("\nTesting function bump_version")

# Generated at 2022-06-29 18:13:56.884268
# Unit test for function bump_version
def test_bump_version():
    # Add tests as necessary to test any edge cases, etc.
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1a2') == '1.0.1a3'
    assert bump_version('1.0.1a2', -1) == '1.0.1a3'
    assert bump_version('1.0.1a2', -2) == '1.0.2'
    assert bump_version('1.0.1a2', -3) == '2.0.0'

    assert bump_version('1.0.1a2', 1, 'a') == '1.0.1a3'

# Generated at 2022-06-29 18:14:07.463981
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', pre_release='alpha') == '1.2.3a0'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3a1',1) == '1.3.0a0'
    assert bump_version('1.2.3a1',1, 'beta') == '1.3.0b0'
    assert bump_version('1.2.3a1',1, 'beta') == '1.3.0b0'
    assert bump_version('1.2.3a1',2, 'alpha') == '1.2.4a0'

# Generated at 2022-06-29 18:14:14.816893
# Unit test for function bump_version
def test_bump_version():
    # test for major version
    a = '1.0.0'
    assert bump_version(a) == '2.0.0'
    # test for minor version without prerelease
    a = '1.1.0'
    assert bump_version(a) == '1.2.0'
    # test for minor version with prerelease
    a = '1.1.0a0'
    assert bump_version(a) == '1.1a1'
    a = '1.1.0b0'
    assert bump_version(a) == '1.1b1'
    a = '1.1.0a0'
    assert bump_version(a) == '1.1a1'
    a = '1.1.0a0'

# Generated at 2022-06-29 18:14:26.249558
# Unit test for function bump_version

# Generated at 2022-06-29 18:14:26.863621
# Unit test for function bump_version
def test_bump_version():
    pass

# Generated at 2022-06-29 18:14:49.716463
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:01.704179
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.1'
    assert bump_version('1.5.0') == '1.6.1'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('1.5.0', 1) == '1.6.0'
    assert bump_version('1.5.2', 1) == '1.6.0'
    assert bump_version('1.5.0', 0) == '2.0.0'
    assert bump_version('1.5.2', 0) == '2.0.0'
    assert bump_version('0.0.0', -1) == '0.0.1'

# Generated at 2022-06-29 18:15:10.181618
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:19.630608
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0', 0) == '2.0'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.0', 2) == '1.0.1'
    assert bump_version('1.0', -1) == '1.0.1'
    assert bump_version('1.0', -2) == '1.1'
    assert bump_version('1.0', -3) == '2.0'


if __name__ == '__main__':
    bump_version()

# Generated at 2022-06-29 18:15:29.982150
# Unit test for function bump_version
def test_bump_version():
    # 1. Check version bump for major version
    assert bump_version('3.0.0', 0) == '4.0.0'
    assert bump_version('3.0.0', 0, 'alpha') == '4.0.0'
    assert bump_version('3.0.0', 0, 'beta') == '4.0.0'
    assert bump_version('3.0.0', -3) == '4.0.0'
    assert bump_version('3.0.0', -3, 'alpha') == '4.0.0'
    assert bump_version('3.0.0', -3, 'beta') == '4.0.0'

    # 2. Check version bump for minor version
    assert bump_version('3.0.0', 1) == '3.1.0'
   

# Generated at 2022-06-29 18:15:42.288648
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:52.201513
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(version='1.0.0') == '1.0.1'
    assert bump_version(version='1.0.0', position=2, pre_release='a') == '1.0.1'
    assert bump_version(version='1.0.0', position=2, pre_release='b') == '1.0.1'
    assert bump_version(version='1.1.0', position=2, pre_release='b') == '1.1.1'
    assert bump_version(version='1.1.1', position=2, pre_release='b') == '1.1.1'
    assert bump_version(version='1.0.0', position=2) == '1.0.1'

# Generated at 2022-06-29 18:15:59.391538
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.1a0') == '0.1.2a0'
    assert bump_version('0.1.1a1') == '0.1.1a2'
    assert bump_version('0.1.1b2') == '0.1.1b3'
    assert bump_version('0.1.1b2', 1, None) == '0.2.0'
    assert bump_version('0.1.1b2', 1, 'a') == '0.2.0a0'
    assert bump_version('0.1.1b2', 1, 'b') == '0.2.0b0'

# Generated at 2022-06-29 18:16:10.391122
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase
    from random import choice

    class _Tests(TestCase):
        def test_bump_version(self):
            for ver in ('1.2.3', '0.1.0', '0.0.1', '1.0.0', '0.0.1'):
                ver_info = _build_version_info(ver)
                patch_txt = '%sb%s' % (ver_info.patch.num, ver_info.patch.pre_num)
                minor_txt = '%sb%s' % (ver_info.minor.num, ver_info.minor.pre_num)
                self.assertEqual(ver_info.minor.txt, minor_txt)
                self.assertEqual(ver_info.patch.txt, patch_txt)