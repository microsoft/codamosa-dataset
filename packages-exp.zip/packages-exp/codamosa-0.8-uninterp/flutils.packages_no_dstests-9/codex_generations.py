

# Generated at 2022-06-29 18:06:45.585262
# Unit test for function bump_version
def test_bump_version():
    import sys
    if sys.version_info < (3, 4):
        return
    v1 = '1.2.3'
    v2 = '1.3.0'
    assert bump_version(v1) == v2
    assert bump_version(v1, 1) == v2
    assert bump_version(v1, 'minor') == v2
    v1 = '1.4.4'
    v2 = '1.5.0'
    assert bump_version(v1) == v2
    assert bump_version(v1, 1) == v2
    assert bump_version(v1, 'minor') == v2
    v1 = '3.3.3'
    v2 = '4.0.0'
    assert bump_version(v1) == v2
    assert bump

# Generated at 2022-06-29 18:06:52.898506
# Unit test for function bump_version
def test_bump_version():
    r = bump_version('0.0.0')
    assert r == '0.0.1'
    r = bump_version('0.0.1')
    assert r == '0.0.2'
    r = bump_version('1.0.0')
    assert r == '1.0.1'
    r = bump_version('1.0.1')
    assert r == '1.0.2'
    r = bump_version('1.2.3')
    assert r == '1.2.4'
    r = bump_version('1.0.1', pre_release='a')
    assert r == '1.0.1a0'
    r = bump_version('1.0.1', pre_release='alpha')
    assert r == '1.0.1a0'
   

# Generated at 2022-06-29 18:07:03.411877
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', position=0, pre_release='a') == '1.3.0a0'

# Generated at 2022-06-29 18:07:15.202438
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:25.180402
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.5.0') == '0.5.1'
    assert bump_version('0.5.0', pre_release='a') == '0.5.1a0'
    assert bump_version('0.5.0', pre_release='b') == '0.5.1b0'
    assert bump_version('0.5.0', 1) == '0.6.0'
    assert bump_version('0.5.0', 1, pre_release='a') == '0.6.0a0'
    assert bump_version('0.5.0', 1, pre_release='b') == '0.6.0b0'
    assert bump_version('0.5.0', 0) == '1.0.0'

# Generated at 2022-06-29 18:07:36.849480
# Unit test for function bump_version
def test_bump_version():
    # These are all correct
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '2.0.0'
    assert bump_version('1.0.1', 1, 'a') == '1.1.1'
    assert bump_version('1.0.1', 1, 'alpha') == '1.1.1'

    # These are all cases that are errors

# Generated at 2022-06-29 18:07:48.592843
# Unit test for function bump_version
def test_bump_version():
    from pytest_localserver.http import WSGIServer
    from webtest import TestApp
    import wsgiref.simple_server
    import rgwadmin

    def http_500_app(environ, start_response):
        raise Exception('This is just a test') # noqa

    http_500_server = WSGIServer(application=http_500_app)
    http_500_server.start()

    http_500_url = http_500_server.url_for('/')
    admin = rgwadmin.RGWAdmin(http_500_url, show_log=False)
    application = admin.application
    app = TestApp(application)
    with pytest.raises(wsgiref.simple_server.WSGIServerException):
        app.get('/')

    http_500_

# Generated at 2022-06-29 18:07:56.283597
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises

    def _make_assertion(
            ver_in: str,
            ver_out: str,
            position: int = 2,
            pre_release: Optional[str] = None,
    ) -> None:
        ver_ret = bump_version(
            ver_in,
            position=position,
            pre_release=pre_release,
        )
        assert ver_ret == ver_out

    _make_assertion('1.2.3', '1.2.4')
    _make_assertion('1.2.3', '1.3.0', position=1)
    _make_assertion('1.2.3', '2.0.0', position=0)

# Generated at 2022-06-29 18:08:09.568803
# Unit test for function bump_version
def test_bump_version():
    """Unit tests the function bump_version."""
    assert bump_version('0.9.9') == '1.0.0'
    assert bump_version('0.9.9a0') == '1.0.0'
    assert bump_version('0.9.9b0') == '1.0.0'
    assert bump_version('0.10.0') == '1.0.0'
    assert bump_version('0.10.0a0') == '1.0.0'
    assert bump_version('0.10.0b0') == '1.0.0'
    assert bump_version('0.10.1') == '1.0.0'
    assert bump_version('0.10.1a0') == '1.0.0'

# Generated at 2022-06-29 18:08:20.183368
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.0.1") == "0.0.2"
    assert bump_version("0.0.1", position=2) == "0.0.2"
    assert bump_version("0.0.1", position=-1) == "0.0.2"
    assert bump_version("0.1.0") == "0.2.0"
    assert bump_version("0.1.0", position=1) == "0.2.0"
    assert bump_version("0.1.0", position=-2) == "0.2.0"
    assert bump_version("1.1.1") == "2.0.0"
    assert bump_version("1.1.1", position=0) == "2.0.0"

# Generated at 2022-06-29 18:08:47.131257
# Unit test for function bump_version
def test_bump_version():
    version_input = '1.2.3'
    assert bump_version(version_input) == '1.2.4'

# Generated at 2022-06-29 18:08:56.324976
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.0.0") == "1.0.0"
    assert bump_version("1.0.0") == "2.0.0"
    assert bump_version("1.0.0", position=1) == "1.1.0"
    assert bump_version("1.0.0", position=2) == "1.0.1"
    assert bump_version("1.0.0", position=0) == "1.0.0"
    assert bump_version("1.0.0", position=-1) == "1.0.0"
    assert bump_version("1.0.0", position=-2) == "1.0.0"
    assert bump_version("1.0.0", position=-3) == "1.0.0"

# Generated at 2022-06-29 18:08:56.997046
# Unit test for function bump_version
def test_bump_version():
    pass

# Generated at 2022-06-29 18:09:08.403704
# Unit test for function bump_version
def test_bump_version():
    # Major
    out = bump_version('0.0.1')
    assert out.startswith('1.')
    out = bump_version('1.0.0')
    assert out.startswith('2.')
    out = bump_version('100.0.0')
    assert out.startswith('101.')

    # Minor
    out = bump_version('1.0.0', 1)
    assert out.startswith('1.1.')
    out = bump_version('1.1.1', 1)
    assert out.startswith('1.2.')

    # Patch
    out = bump_version('1.0.0', 2)
    assert out.startswith('1.0.1')
    out = bump_version('1.0.1', 2)

# Generated at 2022-06-29 18:09:20.428380
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:27.682272
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from dlkitframework._version import __version__
    from dlkitframework.utilities import osid_manager
    version = bump_version(__version__)
    assert version == osid_manager.Version('0.4').get_formatted_version_string()
    print(version)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:09:39.826748
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.0') == '1.1'
    assert bump_version('1') == '2'

    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'

    assert bump_version('1.0a1') == '1.0a2'
    assert bump_version('1.0a0') == '1.0a1'

# Generated at 2022-06-29 18:09:47.140072
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    assert '0.1.0' == bump_version('0.0.1')
    assert '0.1.0' == bump_version('0.0.1', 1)
    assert '1.0.0' == bump_version('0.0.0')

    assert '0.0.2' == bump_version('0.0.1', 2)
    assert '0.0.2' == bump_version('0.0.1')
    assert '0.0.2' == bump_version('0.0.1a0', 2)
    assert '0.0.2' == bump_version('0.0.1a0')
    assert '0.0.2' == bump_version('0.0.1b0', 2)

# Generated at 2022-06-29 18:10:00.438961
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:11.262882
# Unit test for function bump_version
def test_bump_version():
    # xfail:
    # print(bump_version('0.0.1', pre_release='a'))
    # print(bump_version('0.0.1', pre_release='b'))
    # print(bump_version('0.1.1', pre_release='a'))
    # print(bump_version('0.1.1', pre_release='b'))
    print(bump_version('1.2.3'))
    print(bump_version('1.2.3', 0))
    print(bump_version('1.2.3', 0, 'a'))
    print(bump_version('1.2.3', 0, 'b'))
    print(bump_version('1.2.3', 1))

# Generated at 2022-06-29 18:10:28.665726
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.2.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('1.4.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('2.0.1') == '3.0.0'
    assert bump_version('2.5.0') == '3.0.0'


# Generated at 2022-06-29 18:10:39.336101
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=global-statement,global-variable-undefined,invalid-name
    global bump_version  # In case this is being run as a unit test
    # noinspection PyUnusedLocal,PyRedeclaration
    def bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        ver_info = _build_version_info(version)
        position = _build_version_bump_position(position)
        bump_type = _build_version_bump_type(position, pre_release)
        # noinspection PyUnusedLocal
        hold: List[Union[int, str]] = []

# Generated at 2022-06-29 18:10:52.858388
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1', 1) == '0.1'
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', -2) == '0.0.2'
    assert bump_version('0.0.1', pre_release='a') == '0.0.1a0'
    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0', pre_release='alpha') == '1.1.0a0'

# Generated at 2022-06-29 18:11:04.966421
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-29 18:11:17.106905
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    # pylint: disable=C0103
    from os import path

    VERSION_INFO_FILE = path.join(
        path.dirname(__file__),
        'VERSION-INFO'
    )
    if path.isfile(VERSION_INFO_FILE) is True:
        with open(VERSION_INFO_FILE, 'r') as ver_info_obj:
            recs = ver_info_obj.readlines()
        exp_version = recs[0].strip()
        cmp_version = bump_version(exp_version, 0, 'a')
        assert cmp_version == '1.1.1'
        cmp_version = bump_version(cmp_version, 0, 'b')

# Generated at 2022-06-29 18:11:29.099559
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1', 1) == '0.2.0'
    assert bump_version('0.10.0', 1) == '0.11.0'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('0.1.1', 0) == '1.0.0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('1.1.1', 0) == '2.0.0'

# Generated at 2022-06-29 18:11:41.437768
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for function bump_version"""

# Generated at 2022-06-29 18:11:50.781523
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    """
    from .linting import check_comparable_version_strings
    # Major version bump
    check_comparable_version_strings(
        bump_version('1.2.3', 0),
        '2.0.0'
    )
    # Minor version bump
    check_comparable_version_strings(
        bump_version('1.2.3', 1),
        '1.3.0'
    )
    # Patch version bump
    check_comparable_version_strings(
        bump_version('1.2.3', 2),
        '1.2.4'
    )
    # Alpha Pre-release version bump

# Generated at 2022-06-29 18:12:03.468848
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '2.1.0'
    assert bump_version('2.0.1') == '2.1.0'
    assert bump_version('2.1.1') == '2.2.0'
    assert bump_version('2.1.1', 0) == '3.0.0'
    assert bump_version('2.1.1', 1) == '2.2.0'
    assert bump_version('2.1.1', 2) == '2.1.2'
    assert bump_version('2.1.1', -1) == '2.1.2'
    assert bump_version('2.1.1', -2) == '2.2.0'

# Generated at 2022-06-29 18:12:15.667078
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function when it receives an invalid input.

    Two cases:
    1. When the input is not a valid version number
    2. When the input is a valid version number but the position or pre_release is not valid

    Raises:
        ValueError: if the given ``version`` is an invalid version number.
        ValueError: if the given ``position`` does not exist.
        ValueError: if the given ``prerelease`` is not in:
            ``a, alpha, b, beta``
        ValueError: if trying to 'major' part, of a version number, to
            a pre-release version.

    """
    # Case 1: When the input is not a valid version number
    invalid_version_num = "2.0.0.2.2"

# Generated at 2022-06-29 18:12:39.963743
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,C0301,C0111
    # r'': Allow hard-coded strings to be over the 88 character line limit
    # pylint: disable=W1401
    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        # noinspection PyUnresolvedReferences
        # pylint: disable=E1120
        return bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )

    def _test_version_info(
            version: str
    ) -> _VersionInfo:
        return _build_version_info(version)


# Generated at 2022-06-29 18:12:51.326723
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""

# Generated at 2022-06-29 18:13:01.652670
# Unit test for function bump_version
def test_bump_version():
    def jump(
        version: str,
        position: int,
        pre_release: Optional[str],
        expected: str
    ) -> None:
        """Make sure the version number is bumped properly."""
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert actual == expected

    jump(version='0.0.0', position=0, pre_release=None, expected='1.0.0')
    jump(version='1.0.0', position=0, pre_release=None, expected='2.0.0')
    jump(version='2.0.0', position=0, pre_release=None, expected='3.0.0')

# Generated at 2022-06-29 18:13:14.228897
# Unit test for function bump_version
def test_bump_version():
    print("Testing function bump_version")
    ver = "0.0.0"
    print("\t Testing version {}".format(ver))
    print("\t\t Major version bump to 1")
    out = bump_version(ver)
    assert out == "1.0.0"

    print("\t Testing version {}".format(ver))
    print("\t\t Minor version bump to 0.1")
    out = bump_version(ver, 1)
    assert out == "0.1.0"

    print("\t Testing version {}".format(ver))
    print("\t\t Patch version bump to 0.0.1")
    out = bump_version(ver, 2)
    assert out == "0.0.1"

    ver = "0.0.1"

# Generated at 2022-06-29 18:13:22.769652
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:35.632595
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version

    """
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('2.1.0', position=2) == '2.1.1'
    assert bump_version('2.1.1', position=0) == '3.0.0'
    assert bump_version('0.1.2', position=1) == '0.2.0'
    assert bump_version('0.1.2', position=1, pre_release='a') == '0.2.0'

# Generated at 2022-06-29 18:13:45.833816
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'."""
    assert ('0.1.1' == bump_version('0.1.0'))
    assert ('0.1.1a1' == bump_version('0.1.0a0'))
    assert ('0.1.1a1' == bump_version('0.1.0a1'))
    assert ('0.1.1a2' == bump_version('0.1.1a1'))
    assert ('0.1.2a1' == bump_version('0.1.1a0'))
    assert ('0.1.0a0' == bump_version('0.1.0', pre_release='a'))
    assert ('0.1.0a1' == bump_version('0.1.0', pre_release='a'))

# Generated at 2022-06-29 18:13:59.131947
# Unit test for function bump_version
def test_bump_version():
    version = '19.11.0'
    position = 2
    pre_release = 'alpha'
    assert bump_version(version, position, pre_release) == '19.11.0a0'
    version = '19.11.0a1'
    assert bump_version(version, position, pre_release) == '19.11.0a2'
    version = '19.11.0'
    pre_release = 'beta'
    assert bump_version(version, position, pre_release) == '19.11.0b0'
    version = '19.11.0b1'
    assert bump_version(version, position, pre_release) == '19.11.0b2'
    version = '19.11.0a2'
    pre_release = 'beta'

# Generated at 2022-06-29 18:14:03.083534
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    position = 2
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert (out == '1.0.1'), 'Function bump_version did not return the expected result'

# Generated at 2022-06-29 18:14:12.424472
# Unit test for function bump_version
def test_bump_version():
    def _run_test(
            ver: str,
            position: int = 0,
            prerelease: Optional[str] = None
    ) -> None:
        current_ver = ver
        end_ver = bump_version(current_ver, position, prerelease)
        print('Current version: %r' % current_ver)
        print('Bumped version: %r' % end_ver)
        print('Bump at position %r' % position)
        if prerelease is None:
            print('Bump pre-release: null')
        else:
            print('Bump pre-release: %r' % prerelease)
        print('\n')

    _run_test('1.1.1')
    _run_test('1.1.1a0')

# Generated at 2022-06-29 18:14:47.028781
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function by running through a bunch
    of versions and bumping each once."""


# Generated at 2022-06-29 18:14:55.036192
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:06.185095
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    *New in version 0.3*
    """
    # pylint: disable=W0212,W0612
    if __name__ == '__main__':
        print('Testing bump_version')
    from random import randint


# Generated at 2022-06-29 18:15:16.938083
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:28.698007
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    import os
    import unittest
    import doctest
    from os.path import dirname as _dirname, join as _join

    # noinspection PyTypeChecker,PyUnresolvedReferences
    import unit_test_helper

    # noinspection PyTypeChecker
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(unit_test_helper))
    suite.addTest(doctest.DocTestSuite(unit_test_helper.unit_test_helper))

    dirname = _dirname(__file__)
    tests_file = _join(dirname, 'tests.txt')
    suite.addTest(doctest.DocFileSuite(tests_file))

   

# Generated at 2022-06-29 18:15:30.460658
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'



# Generated at 2022-06-29 18:15:42.964792
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', a='a') == '1.2a0'
    assert bump_version('1.2.3', a='alpha') == '1.2a0'
    assert bump_version('1.2.3', a='A') == '1.2a0'
    assert bump_version('1.2.3', a='Alpha') == '1.2a0'
    assert bump_version('1.2.3', a='ALPHA') == '1.2a0'
    assert bump_

# Generated at 2022-06-29 18:15:53.137265
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.0', 2) == '1.2.1'
    assert bump_version('1.2.3', 2, 'a') == '1.2.4a0'
    assert bump_version('1.2.3', 2, 'b') == '1.2.4b0'
    assert bump_version('1.2.3', 2, 'alpha') == '1.2.4a0'

# Generated at 2022-06-29 18:15:59.760472
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    #
    # Tests:
    #
    #   1. 0.0.0
    #   2. 1
    #   3. 1.2
    #   4. 1.0
    #   5. 5.1
    #   6. 1.2.3
    #   7. 1.2.0
    #   8. 1.2.2
    #   9. 1.2.0a0
    #   10. 1.2.0a1
    #   11. 1.2.0b0
    #   12. 1.2.0b1
    #   13. 1.2.1a0
    #   14. 1.2.1b0
    #

# Generated at 2022-06-29 18:16:10.811953
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1') == '2'
    assert bump_version('1.10') == '1.11'
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0a0') == '1.0a1'
    assert bump_version('1.1a0') == '1.1a1'
    assert bump_version('1.1a1') == '1.1a2'
    assert bump_version('1.1b1') == '1.1b2'
    assert bump_version('1.1a1') == '1.1a2'
    assert bump_version('1.1b1') == '1.1b2'
    assert bump_version