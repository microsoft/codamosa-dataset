

# Generated at 2022-06-29 18:06:48.254124
# Unit test for function bump_version
def test_bump_version():
    """This function does not return anything useful...
    """

# Generated at 2022-06-29 18:06:57.554659
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0915
    # pylint: disable=R1702
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=2) == '1.2.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('0.0.0')

# Generated at 2022-06-29 18:07:09.201745
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function"""
    # Passing tests
    assert bump_version('1') == '2'
    assert bump_version('1', 0) == '2'
    assert bump_version('1', 0, 'a') == '2a0'
    assert bump_version('1', 0, 'alpha') == '2a0'
    assert bump_version('1', 0, 'b') == '2b0'
    assert bump_version('1', 0, 'beta') == '2b0'
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.0', 1, 'a') == '1.1a0'

# Generated at 2022-06-29 18:07:20.497244
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    print("Testing function bump_version.")
    assert bump_version("0.1.2") == "0.1.3"
    assert bump_version("0.1.2", 2) == "0.1.3"
    assert bump_version("0.1.2", 2, None) == "0.1.3"
    assert bump_version("0.1.2", 1) == "0.2.0"
    assert bump_version("0.1.2", 1, None) == "0.2.0"
    assert bump_version("0.1.2", 0) == "1.0.0"
    assert bump_version("0.1.2", 0, None) == "1.0.0"

# Generated at 2022-06-29 18:07:27.943960
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version."""
    def _assert(
            test_pos: int,
            test_pre: Optional[str],
            ver: str,
            ref: str
    ) -> None:
        assert bump_version(ver, test_pos, test_pre) == ref

    _assert(0, None, '1.2.0', '2.0.0')
    _assert(1, None, '1.2.0', '1.3.0')
    _assert(2, None, '1.2.0', '1.2.1')
    _assert(2, None, '1.2', '1.2.1')
    _assert(2, '', '1.2.0', '1.2.1')

# Generated at 2022-06-29 18:07:40.039815
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'."""
    # Create a list of tests to run.

# Generated at 2022-06-29 18:07:50.962779
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', pre_release='a') == '0.1a0'
    assert bump_version('0.1.0', pre_release='a') == '0.1a0'
    assert bump_version('0.1.0', pre_release='b') == '0.1b0'
    assert bump_version('0.1.0', pre_release='alpha') == '0.1a0'
    assert bump_version('0.1.0', pre_release='beta') == '0.1b0'
    assert bump_version('0.1.0', 1, 'b') == '0.1b0'
    assert bump_version('0.1.0', 1, 'alpha')

# Generated at 2022-06-29 18:08:01.620796
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""


# Generated at 2022-06-29 18:08:11.845633
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('0.0.0', -1) == '0.0.1'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.0.0', -3) == '1.0.0'

    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'
    assert bump_

# Generated at 2022-06-29 18:08:21.624051
# Unit test for function bump_version
def test_bump_version():

    # version without pre-release
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', position=-2) == '1.0.1'
    assert bump_version('1.0.0', position=-1) == '1.1.0'
    assert bump_version('1.0.0', position=-3) == '2.0.0'

    # version with pre-release

# Generated at 2022-06-29 18:08:41.755303
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.7.5") == "1.7.6"


# Generated at 2022-06-29 18:08:53.610273
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.0.0") == "1.0.0"
    assert bump_version("1.0.0") == "2.0.0"
    assert bump_version("2.1.2") == "2.1.3"
    assert bump_version("2.1.2", 1) == "2.2.0"
    assert bump_version("2.1.2", 0) == "3.0.0"
    assert bump_version("2.1.2", pre_release='a') == "2.1.3a0"
    assert bump_version("2.1.3a4", pre_release='a') == "2.1.3a5"
    assert bump_version("2.1.3a4", pre_release='b') == "2.1.3b0"

# Generated at 2022-06-29 18:09:06.350568
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', position=0) == '1.0.0'
    assert bump_version('0.1.0', position=1) == '0.2.0'
    assert bump_version('0.2.0') == '0.2.1'

# Generated at 2022-06-29 18:09:18.965851
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', 2, 'a') == '1.2.3a0'
    assert bump_version('1.2.3', 2, 'a') == '1.2.3a0'
    assert bump_version('1.2.3a0', 2) == '1.2.3a1'
    assert bump_version('1.2.3a0') == '1.2.4'
    assert bump_version('1.2.3b0') == '1.2.4'
    assert bump_version('1.2.3b0') == '1.2.4'
    assert bump_version('1.2.3b0', 2, 'a') == '1.2.3a0'

# Generated at 2022-06-29 18:09:32.564980
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:40.049751
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 0) == '1.0.0'
    assert bump_version('0.1.2', pre_release='a') == '0.1.3a0'
    assert bump_version('0.1.2', pre_release='alpha') == '0.1.3a0'
    assert bump_version('0.1.2', pre_release='b') == '0.1.3b0'
    assert bump_version('0.1.2', pre_release='beta') == '0.1.3b0'

# Generated at 2022-06-29 18:09:50.221125
# Unit test for function bump_version
def test_bump_version():
    # Check that bump_version raises a value error if version is invalid
    def invalidate_version(version):
        try:
            StrictVersion(version)
        except ValueError:
            return True
        else:
            return False

    def bump_version_invalid_version(version):
        try:
            bump_version(version)
        except ValueError:
            return True
        else:
            return False

    assert bump_version_invalid_version('1.2.3') is False
    assert bump_version_invalid_version('1.2') is False
    assert bump_version_invalid_version('1.2.3.4') is False
    assert bump_version_invalid_version('1.2.3.a0') is False


# Generated at 2022-06-29 18:10:02.231160
# Unit test for function bump_version
def test_bump_version():
    version = "0.0.0"
    position = 2
    pre_release = None
    expected = '0.0.1'

    # String version with defaults should bump patch
    actual = bump_version(version, position, pre_release)
    assert actual == expected

    version = "0.0.0"
    position = 1
    pre_release = None
    expected = '0.1.0'

    # String version with defaults should bump minor
    actual = bump_version(version, position, pre_release)
    assert actual == expected

    version = "0.0.0"
    position = 0
    pre_release = None
    expected = '1.0.0'

    # String version with defaults should bump major
    actual = bump_version(version, position, pre_release)
    assert actual == expected

   

# Generated at 2022-06-29 18:10:09.906258
# Unit test for function bump_version
def test_bump_version():
    from os2datascanner.utils.version import VersionInfo
    # noinspection PyUnresolvedReferences
    from tests.utils import assert_error_message

    __ver__ = VersionInfo.version
    assert bump_version(__ver__, -3, 'a') == '0.3.0a0'
    assert bump_version(__ver__, -3, 'b') == '0.3.0b0'
    assert bump_version(__ver__, -2, 'a') == '0.3.2a0'
    assert bump_version(__ver__, -2, 'b') == '0.3.2b0'
    assert bump_version(__ver__, -1, 'a') == '0.3.2a1'

# Generated at 2022-06-29 18:10:10.934091
# Unit test for function bump_version
def test_bump_version():
    bump_version('0.1.1')

# Generated at 2022-06-29 18:10:20.937460
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', position=0) == '2.0.0'
    assert bump_version('1.1.1', position=1) == '1.2.0'
    assert bump_version('1.1.1', position=2) == '1.1.2'

    assert bump_version('1.1.1', position=0, pre_release='a') == '2.0.0'
    assert bump_version(
        '1.1.1', position=1, pre_release='a'
    ) == '1.2.0a0'

# Generated at 2022-06-29 18:10:28.197408
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    All test cases are directly based off the examples in the
    documentation for the function bump_version.

    """

# Generated at 2022-06-29 18:10:38.942307
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""

# Generated at 2022-06-29 18:10:52.442095
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        '1.2.3',
        0
    ) == '2.0.0'
    assert bump_version(
        '1.2.3',
        1
    ) == '1.3.0'
    assert bump_version(
        '1.2.3',
        2
    ) == '1.2.4'
    assert bump_version(
        '1.2.0',
        2
    ) == '1.2.1'
    assert bump_version(
        '1.2.3',
        2,
        'beta'
    ) == '1.2.4b0'
    assert bump_version(
        '1.2.3b0',
        2,
        'beta'
    ) == '1.2.3b1'
   

# Generated at 2022-06-29 18:11:04.568673
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.0', 2, 'b') == '1.0.1b0'
    assert bump_version('1.0.0', 2, 'alpha') == '1.0.1a0'

# Generated at 2022-06-29 18:11:15.922132
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'b') == '1.1.0b0'

# Generated at 2022-06-29 18:11:27.966468
# Unit test for function bump_version
def test_bump_version():
    actual = bump_version('1.0.0')
    assert actual == '1.0.1'
    actual = bump_version('1.0.0-beta')
    assert actual == '1.0.1'
    actual = bump_version('1.0.0-beta-1')
    assert actual == '1.0.1'
    actual = bump_version('1.0.0-beta-2')
    assert actual == '1.0.1'
    actual = bump_version('1.0.0-alpha.1')
    assert actual == '1.0.1'
    actual = bump_version('1.0.2', position=1)
    assert actual == '1.1.0'
    actual = bump_version('1.0.2', position=0)

# Generated at 2022-06-29 18:11:40.316746
# Unit test for function bump_version
def test_bump_version():
    out = bump_version('1.0.0')
    assert out == '1.0.1', out
    out = bump_version('1.0.0', 0)
    assert out == '2.0.0', out
    out = bump_version('1.0.0', 1)
    assert out == '1.1.0', out
    out = bump_version('1.0.0', 2)
    assert out == '1.0.1', out
    out = bump_version('1.0.0', -2)
    assert out == '1.0.1', out
    out = bump_version('1.0.0', -1)
    assert out == '1.1.0', out
    out = bump_version('1.0.0', -3)

# Generated at 2022-06-29 18:11:50.030707
# Unit test for function bump_version
def test_bump_version():
    """ _Bump version, test examples"""
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.2', position=0) == '1.0.0'
    assert bump_version('0.1.2', position=1) == '0.2.0'
    assert bump_version('0.1.3', position=1) == '0.2.0'
    assert bump_version('0.1.2', position=-1) == '0.1.3'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_

# Generated at 2022-06-29 18:12:02.085392
# Unit test for function bump_version
def test_bump_version():
    if bump_version('1.0.0', 0) != '2.0.0':
        raise AssertionError('test_bump_version 1 failed')
    if bump_version('1.0.0') != '1.0.1':
        raise AssertionError('test_bump_version 2 failed')
    if bump_version('1.0.0', 1) != '1.1.0':
        raise AssertionError('test_bump_version 3 failed')
    if bump_version('1.0.0', 1, 'b') != '1.1b0':
        raise AssertionError('test_bump_version 4 failed')

# Generated at 2022-06-29 18:12:21.459292
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.3.3') == '1.3.4'
    try:
        assert bump_version('1.3.3', pre_release='a') == '1.3.3a0'
    except ValueError:
        pass
    assert bump_version('1.3.3', pre_release='alpha') == '1.3.3a0'
    assert bump_version('1.3.3', pre_release='b') == '1.3.3b0'
    assert bump_version('1.3.3', pre_release='beta') == '1.3.3b0'
    assert bump_version('1.3.3', position=1) == '1.4.0'
    assert bump_version('1.3.3') == '1.3.4'

# Generated at 2022-06-29 18:12:28.897241
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'


# Generated at 2022-06-29 18:12:41.454703
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.9.0') == '0.10.0'

    assert bump_version('0.10.0') == '0.11.0'

    assert bump_version('0.11.0') == '0.12.0'

    assert bump_version('0.9.11') == '0.10.0'

    assert bump_version('0.11.11') == '0.12.0'

    assert bump_version('0.0.0', position=0) == '1.0.0'

    assert bump_version('1.0.0', position=0) == '2.0.0'

    assert bump_version('2.0.0', position=0) == '3.0.0'


# Generated at 2022-06-29 18:12:53.019101
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.1', position=0) == '2.0.0'
    assert bump_version('1.0.1', position=1) == '1.1.0'
    assert bump_version('1.0.1', position=2) == '1.0.2'
    assert bump_version('1.1.1-a0', position=1) == '1.2.0'
    assert bump_version('1.1.1-a0', position=2) == '1.1.2'
    assert bump_version('1.1.1-a0', position=2, pre_release='a') == '1.1.1a1'

# Generated at 2022-06-29 18:13:02.488514
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0321,C0301,C0111
    # pylint: disable=R0201,W0613,W0622,R0903
    from typing import Any
    from unittest import TestCase, skipIf, main, TestSuite
    import sys
    has_py3 = sys.version_info[0] == 3

    class Test_bump_version(TestCase):
        # noinspection PyStatementEffect
        """
        Testing the ability to bump the version number of a semantic version
        number string.
        """

        def test_basic_bump_patch(self):
            ver_str = '0.0.0'
            self.assertEqual(bump_version(ver_str), '0.0.1')


# Generated at 2022-06-29 18:13:15.160778
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version`` function."""
    print('Running unit test for function "bump_version"...')
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', position=-3) == '1.0.0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=2) == '0.0.1'
    assert bump_version('0.0.0', position=3) == '0.0.1'

# Generated at 2022-06-29 18:13:23.341639
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 1, 'a') == '0.1a0'
    assert bump_version('0.0.0', 1, 'beta') == '0.1b0'
    assert bump_version('0.0.0', 2, 'alpha') == '0.0a1'
    assert bump_version('0.0.1', 2, 'b') == '0.0b1'

# Generated at 2022-06-29 18:13:36.421207
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version function."""

# Generated at 2022-06-29 18:13:46.328130
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # pylint: disable=R0914
    # Testing for invalid version numbers

# Generated at 2022-06-29 18:13:59.599779
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    import unittest


# Generated at 2022-06-29 18:14:12.494793
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,W0621
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.3') == '1.0.4'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.0', 1) == '1.2.0'
    assert bump_version('1.1.2', 1) == '1.2.2'
    assert bump_version('1.1.0', 0) == '2.0.0'
    assert bump_version('1.1.2', 0) == '2.0.2'
    assert bump_version('1.1.1', -1) == '1.1.2'
    assert bump_

# Generated at 2022-06-29 18:14:20.625824
# Unit test for function bump_version
def test_bump_version():
    # First iteration of test
    ver = bump_version('1.2.3')
    assert ver == '1.2.4', 'Expected %r to be %r.' % (ver, '1.2.4')
    # Second iteration of test
    ver = bump_version('1.2.3a1')
    assert ver == '1.2.3a2', 'Expected %r to be %r.' % (ver, '1.2.3a2')
    # Third iteration of test
    ver = bump_version('1.2.3a0')
    assert ver == '1.2.3a1', 'Expected %r to be %r.' % (ver, '1.2.3a1')
    # Fourth iteration of test
    ver = bump_version('1.2.3b4')

# Generated at 2022-06-29 18:14:31.923516
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('2.0.0', position=-1) == '1.0.0'
    assert bump_version('2.0.0', position=-2) == '0.0.0'
    assert bump_version('4.0.0', position=-3) == '0.0.0'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('0.1.1', position=2) == '0.1.2'
    assert bump_version('1.1.1', position=2) == '1.1.2'

# Generated at 2022-06-29 18:14:43.505657
# Unit test for function bump_version
def test_bump_version():
    # [Type] Basic test
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1', 0, 'alpha') == '1.0.0a0'
    assert bump_version('0.1.1', 1) == '0.2.0'
    assert bump_version('2.0.0', 1, 'alpha') == '2.1.0a0'
    assert bump_version('2.0.0', 2) == '2.0.1'
    assert bump_version('2.0.0', 2, 'alpha') == '2.0.1a0'

# Generated at 2022-06-29 18:14:52.806611
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:04.244691
# Unit test for function bump_version
def test_bump_version():
    import unittest
    class Test(unittest.TestCase):
        def test_bump_version(self):
            def test_method(
                    case_num: int,
                    ver_in: str,
                    position: int,
                    prerelease: Optional[str],
                    ver_out: str
            ) -> None:
                out = bump_version(ver_in, position, prerelease)
                print(' Input: %s' % ver_in)
                print('Output: %s' % out)
                print('Expect: %s\n' % ver_out)
                self.assertEqual(out, ver_out)

            test_method(0, '0.0.0', 0, None, '1.0.0')

# Generated at 2022-06-29 18:15:11.143815
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for bump_version. """
    from sys import version as py_version
    from platform import python_version
    from importlib import import_module
    from os import path

    try:
        # pylint: disable=E0611,E0401
        from importlib.metadata import metadata, version
    except ImportError:
        pass

    def add_item(dictionary, key, value):
        """ Add an item to a dictionary. If a dictionary item exists with the
        given key, append the value to the existing list. """
        if key not in dictionary:
            dictionary[key] = []
        dictionary[key].append(value)

    lib = 'bumpversion'
    python_minor = py_version.split('.')[1]
    is_py36 = py_version.startswith('3.6')

# Generated at 2022-06-29 18:15:23.948934
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0') == '2.0'
    assert bump_version('1.0.0') == '1.1'
    assert bump_version('1.0.9') == '1.1'
    assert bump_version('1.0.0.a1') == '1.1'
    assert bump_version('1.0.0.a1', position=1) == '1.1.0'
    assert bump_version('1.0.0.a1', position=2) == '1.0.1'
    assert bump_version('1.0.a1') == '1.1'
    assert bump_version('1.0.a1', position=1) == '1.1.0'

# Generated at 2022-06-29 18:15:32.358990
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R1401
    class Test:
        def __init__(self, version: str, type: str):
            self.version = version
            self.type = type


# Generated at 2022-06-29 18:15:44.899523
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-29 18:16:16.687639
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    result = bump_version('0.4.0')
    assert result == '0.4.1'

    result = bump_version('0.4.0', 2, 'a')
    assert result == '0.4.1a0'

    # Test position option
    result = bump_version('0.4.0', position=1)
    assert result == '0.5.0'

    result = bump_version(
        '0.4.0',
        position=-2,
        pre_release='a'
    )
    assert result == '0.4.1a0'

    result = bump_version(
        '0.4.0',
        position=-2,
        pre_release='b'
    )