

# Generated at 2022-06-29 18:06:47.505667
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    import unittest

    class BumpVersionTests(unittest.TestCase):
        """Unit test for function bump_version()."""

        def setUp(self):
            # type: () -> None
            """Set up the test."""

        def tearDown(self):
            # type: () -> None
            """Tear down the test."""

        def test_bump_1(self):
            # type: () -> None
            """Test with trivial version numbers."""
            self.assertEqual(bump_version('0.1.0'), '0.1.1')
            self.assertEqual(bump_version('0.1.0', 1), '0.2.0')

# Generated at 2022-06-29 18:06:56.291978
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0', -2) == '1.0.0'
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.10') == '0.0.11'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.1', 2) == '0.0.2'

# Generated at 2022-06-29 18:07:05.688199
# Unit test for function bump_version
def test_bump_version():
    import unittest.mock
    input_file_path = 'version.txt'
    with open(input_file_path, 'r') as file_handler:
        version_number = file_handler.read().replace('\n', '')
    with unittest.mock.patch('builtins.open', unittest.mock.mock_open()):
        bump_version(version_number)
        file_handler = open(input_file_path, 'w')
        file_handler.write(bump_version(version_number))
        file_handler.close()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:07:17.273588
# Unit test for function bump_version
def test_bump_version():
  assert bump_version('0.0.0') == '1.0.0'
  assert bump_version('1.1.1') == '1.1.2'
  assert bump_version('1.1.1', position=1) == '1.2.0'
  assert bump_version('1.1.0', position=1) == '1.2.0'
  assert bump_version('1.1.1', position=1, pre_release='a') == '1.2.0a0'
  assert bump_version('1.1.0', position=1, pre_release='a') == '1.2.0a0'
  assert bump_version('1.1.0a0', position=1, pre_release='a') == '1.2.0a0'

# Generated at 2022-06-29 18:07:23.309775
# Unit test for function bump_version
def test_bump_version():
    import sys

    from lib_pebble_sdk.tests.unittest_tools import check_results
    from lib_pebble_sdk.tests.unittest_tools import get_test_data

    data = get_test_data('bump_version_test_data.txt')
    results = check_results(bump_version, [x.split('|') for x in data])
    sys.exit(results)


# Generated at 2022-06-29 18:07:33.910531
# Unit test for function bump_version
def test_bump_version():
    data = [
        ('0.0.0', ('0.1.0', 1)),
        ('0.1.1', ('0.2.0', 1)),
        ('0.2.1', ('1.0.0', 0)),
        ('1.0.0', ('1.0.1', 2)),
        ('1.0.1', ('1.1.0', 1)),
        ('1.1.1', ('1.1.0a0', 1, 'alpha')),
        ('1.1.0a0', ('1.1.1', 2)),
        ('1.1.1', ('1.1.0b0', 1, 'beta')),
        ('1.1.0b0', ('1.1.1', 2))
    ]

    for ver, ans in data:
        pos = ans

# Generated at 2022-06-29 18:07:45.831972
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from sys import modules
    from unittest.mock import patch
    from unittest import TestCase

    class TestBumpVersion(TestCase):
        def setUp(self):
            self.here = path.abspath(path.dirname(__file__))
            self.here = path.join(self.here, 'tests')
            self.root = path.abspath(path.join(self.here, '..'))
            self.version_file = path.join(self.root, 'VERSION')
            self.mock_version_file = path.join(self.here, 'VERSION')

            self.module = modules[__name__]


# Generated at 2022-06-29 18:07:54.868661
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:07.975254
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version`` function."""

    # Invalid version numbers

# Generated at 2022-06-29 18:08:17.125174
# Unit test for function bump_version
def test_bump_version():
    from os import path, devnull
    from sys import stderr
    from subprocess import check_call
    from tempfile import TemporaryDirectory

    from pkg_resources import parse_version

    from .common import (
        remove_path,
        write_file,
    )

    # noinspection PyUnresolvedReferences,PyPackageRequirements
    from pytest import raises

    dname = path.abspath(path.dirname(__file__))
    dname_parent = path.dirname(dname)

    # List of tuple of (in, version, position, pre_release)

# Generated at 2022-06-29 18:08:55.971482
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=1) == '1.3.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.0', position=1, pre_release='a') == '1.2a0'
   

# Generated at 2022-06-29 18:09:07.287861
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E999,E0611
    from distutils.version import StrictVersion
    import pytest
    # pylint: enable=E999,E0611

    def _test(
            given_ver: str,
            given_pos: int,
            given_prerelease: Optional[str],
            expected_ver: str
    ) -> None:
        ver_info = _build_version_info(given_ver)
        pre_release = _build_version_bump_type(given_pos, given_prerelease)
        if pre_release == _BUMP_VERSION_MAJOR:
            given_pos = ver_info.major.pos
        elif pre_release in _BUMP_VERSION_MINORS:
            given_pos = ver_info.minor.pos

# Generated at 2022-06-29 18:09:19.614465
# Unit test for function bump_version
def test_bump_version():
    # Zero position bump
    assert(bump_version('1.0.0', 0) == '2.0.0')

    # Second position bump
    assert(bump_version('1.0.0', 1) == '1.1.0')

    # Third position bump
    assert(bump_version('1.0.0', 2) == '1.0.1')

    # Third position bump, and second position has a zero
    assert(bump_version('1.0.0', 2) == '1.0.1')

    # Third position bump, and second position has a zero
    assert(bump_version('1.0.1', 2) == '1.0.2')

    # Third position bump, and second position has a zero

# Generated at 2022-06-29 18:09:32.661553
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:40.088511
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0915
    def _test(test_case: Dict[str, Any]) -> None:
        version = bump_version(
            version=test_case['version'],
            position=test_case['position'],
            pre_release=test_case['pre_release']
        )
        assert version == test_case['expected_version']


# Generated at 2022-06-29 18:09:47.289126
# Unit test for function bump_version
def test_bump_version():
    """Print out ``bump_version`` to console."""

# Generated at 2022-06-29 18:10:00.438528
# Unit test for function bump_version
def test_bump_version():
    # Test author: Jason M. Pittman
    # Test date: Wed Apr 6 21:44:26 2016 CST

    import pytest

    # Test: ./bk_lib/bump_version.py::bump_version :: 0
    ret: str = bump_version('1.2.3', 0)
    exp: str = '2.0.0'
    assert ret == exp
    # Test: ./bk_lib/bump_version.py::bump_version :: 1
    ret: str = bump_version('1.2.3')
    exp: str = '1.2.4'
    assert ret == exp
    # Test: ./bk_lib/bump_version.py::bump_version :: 2
    ret: str = bump_version('1.2.3', -1)
    exp: str

# Generated at 2022-06-29 18:10:09.212114
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2a0'
    assert bump_version('1.2.3', pre_release='alpha') == '1.2a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2b0'
    assert bump_version('1.2.3', pre_release='beta') == '1.2b0'
    assert bump_version('1.2.3', 1) == '1.3.0'

# Generated at 2022-06-29 18:10:22.117864
# Unit test for function bump_version
def test_bump_version():
    """Test Version Bumping.

    .. note::

        This function is not meant to be called by the public.
    """

    def assertEqual(a, b):
        if a == b:
            return
        raise AssertionError('%r != %r' % (a, b))

    def _test(test_data):
        for index, test in enumerate(test_data):
            assertEqual(test[0], bump_version(*test[1:3]))


# Generated at 2022-06-29 18:10:30.534378
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    """Unit test module.

    Unit test function for function bump_version.
    """
    import sys
    from .tests import test_bump_version

    print('Python %s on %s' % (sys.version, sys.platform))
    test_bump_version.run_tests()


# The following test code will only be run when this module is run directly.
# It is ignored when the module is imported.
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:10:44.386243
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = '0.1.0'
    assert(bump_version(version) == '0.1.1')
    assert(bump_version(version, position=1) == '0.2.0')
    assert(bump_version(version, position=0) == '1.0.0')
    assert(bump_version(version, position=2, pre_release='a') == '0.1.1a0')
    version = '0.2.5a6'
    assert(bump_version(version) == '0.2.6')
    assert(bump_version(version, position=1) == '0.3.5')
    assert(bump_version(version, position=0) == '1.2.5a6')
   

# Generated at 2022-06-29 18:10:56.555567
# Unit test for function bump_version
def test_bump_version():
    # Unit test for function bump_version
    assert bump_version('1.4.6') == '1.4.7'
    assert bump_version('1.4.6', 0) == '2.0.0'
    assert bump_version('1.4.6', 1) == '1.5.0'
    assert bump_version('1.4.6', 2) == '1.4.7'
    assert bump_version('1.4.6', -1) == '1.4.7'
    assert bump_version('1.4.6', -2) == '1.5.0'
    assert bump_version('1.4.6', -3) == '2.0.0'

    assert bump_version('1.4.6a1') == '1.4.6a2'

# Generated at 2022-06-29 18:11:07.911499
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    # ---------
    # MAJOR
    # ---------
    # Major
    assert bump_version("1.0.0") == "2.0.0"
    assert bump_version("2.0.0") == "3.0.0"
    # Major - Pre-release
    assert bump_version("1.0.0a0") == "2.0.0a0"
    assert bump_version("2.1.2b3") == "3.0.0b0"
    # Major - No minor
    assert bump_version("1") == "2.0.0"
    assert bump_version("2") == "3.0.0"
    # Major - No minor - Pre-release

# Generated at 2022-06-29 18:11:21.058088
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:34.467048
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3a1') == '1.2.4'
    assert bump_version('0.2.3') == '0.2.4'
    assert bump_version('1.0.3') == '1.0.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', position=1) == '1.3.0'

# Generated at 2022-06-29 18:11:45.563570
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:53.272702
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    assert bump_version('0.0.0') == '1.0'
    assert bump_version('0.0.0', 1) == '0.1'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('0.0.0', 0) == '1.0'
    assert bump_version('0.0.0', 1) == '0.1'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('0.0.0', -3) == '1.0'
    assert bump_version('0.0.0', -2) == '0.1'
    assert bump_version('0.0.0', -1)

# Generated at 2022-06-29 18:12:00.016948
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.1', position=0) == '2.0.0'
    assert bump_version('1.0.1', position=1) == '1.1.0'
    assert bump_version('1.0.1', position=-1) == '1.0.1'
    assert bump_version('1.0.1', position=-2) == '1.0.0'
    assert bump_version('1.0.1', position=-3) == '0.0.1'

# Generated at 2022-06-29 18:12:12.741128
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.1', 1) == '0.2.0'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', 1) == '0.3.0'
    assert bump_version('0.2.0', 0) == '1.0.0'

# Generated at 2022-06-29 18:12:23.614349
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'
    assert bump_version('1.0.0', 0, 'a') == '1.0.0a0'

# Generated at 2022-06-29 18:12:34.868812
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function :func:`bump_version`."""

# Generated at 2022-06-29 18:12:47.162243
# Unit test for function bump_version
def test_bump_version():
    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_result: str
    ) -> None:
        """Ensure that the function 'bump_version' works as expected."""
        result = bump_version(
            version=version,
            position=position,
            pre_release=pre_release,
        )
        assert result == expected_result

    _test(
        version='1.0.0',
        position=0,
        pre_release=None,
        expected_result='2.0.0',
    )
    _test(
        version='1.0.0',
        position=1,
        pre_release=None,
        expected_result='1.1.0',
    )

# Generated at 2022-06-29 18:12:58.355142
# Unit test for function bump_version
def test_bump_version():
    from version_compare import version_compare

    version_1 = '0.0.0'
    result_1 = bump_version(version=version_1)
    assert version_compare(result_1, '1.0.0') == 0

    version_2 = '0.1.1'
    result_2 = bump_version(version=version_2)
    assert version_compare(result_2, '0.2.1') == 0

    version_3 = '0.0.1'
    result_3 = bump_version(version=version_3)
    assert version_compare(result_3, '0.1.1') == 0

    version_4 = '0.0.0-b0'
    result_4 = bump_version(version=version_4)
    assert version_comp

# Generated at 2022-06-29 18:13:04.807532
# Unit test for function bump_version
def test_bump_version():
    print('Testing the bump_version')
    class _Test(NamedTuple):
        pos: int
        pre_release: Optional[str]
        ver: str
        out: str


# Generated at 2022-06-29 18:13:06.441414
# Unit test for function bump_version
def test_bump_version():
    import sys
    inp_ver = '1.2.3'
    out_ver = '1.3.0'
    if bump_version(inp_ver) != out_ver:
        sys.exit('ERROR: bump_version')

# Generated at 2022-06-29 18:13:12.693847
# Unit test for function bump_version
def test_bump_version():
    import copy
    import os
    import subprocess
    import sys
    import time
    import unittest

    # unit test: bump_version
    # unit test: bump_version

    curr_path = os.path.dirname(os.path.abspath(__file__))
    for file in os.listdir(curr_path):
        if file.startswith(('.', '_', 'test')):
            continue
        if file.endswith('.py'):
            module_path = os.path.join(curr_path, file)
            module_name = os.path.splitext(file)[0]
            py_version = sys.version_info[:2]
            if py_version < (3, 6):
                module_name = str(module_name)
            exec

# Generated at 2022-06-29 18:13:21.812436
# Unit test for function bump_version
def test_bump_version():
    """
    Run all unit tests in this module
    """
    def test_each():
        """
        Run a test with specific values
        """
        def test_with_values(
                version: str,
                position: int,
                pre_release: Optional[str],
                expected: str
        ) -> None:
            """
            Run test with specific values

            Args:
                version (str): The version number to be bumped.
                position (int): The position (starting with zero) of the
                    version number component to be increased.
                pre_release (str, Optional): A value of ``a`` or ``alpha``
                    will create or increase an alpha version number.  A
                    value of ``b`` or ``beta`` will create or increase a
                    beta version number.
                expected (str): The expected bumped version number.
            """

# Generated at 2022-06-29 18:13:34.355004
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # print('Testing function `bump_version`.')

    def test(
            version: str,
            position: int = 2,
            prerelease: Optional[str] = None
    ) -> None:
        """Print results of testing the bump_version function."""
        result = bump_version(version, position, prerelease)
        print('bump_version(%r, %r, %r) returned %r' % (
            version,
            position,
            prerelease,
            result
        ))

    def run_tests(
            test_list: List[Tuple[str, int, Optional[str], str]]
    ) -> None:
        """Run tests in test list."""
        for args in test_list:
            test(*args)


# Generated at 2022-06-29 18:13:45.016519
# Unit test for function bump_version
def test_bump_version():

    # noinspection PyUnusedLocal
    def check_version(
        version: str,
        expected: str,
        position: int = 2,
        pre_release: Optional[str] = None
    ) -> bool:
        actual = bump_version(version, position, pre_release)
        return actual == expected

    assert check_version('0.1.0', '0.2.0')
    assert check_version('0.1.0', '0.1.1', 2)
    assert check_version('0.1.0', '0.2.0', 1)
    assert check_version('0.1.0', '1.1.0', 0)
    assert check_version('1.1.0', '1.2.0')

# Generated at 2022-06-29 18:13:58.025907
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    func = "bump_version"

# Generated at 2022-06-29 18:14:17.589728
# Unit test for function bump_version
def test_bump_version():
    assert 0

# Generated at 2022-06-29 18:14:28.624517
# Unit test for function bump_version
def test_bump_version():
    from string import digits, ascii_letters
    from pyutil import random_string
    from random import randint
    from random import choice

    def _increase_version(
            version: str,
            position: int,
            prerelease: Optional[str]
    ) -> str:
        ver_info = _build_version_info(version)
        hold: List[Union[int, str]] = []
        if position == 0:
            hold = [ver_info.major.num + 1, 0]
        elif position == 1:
            if ver_info.minor.pre_txt:
                hold = [ver_info.major.num, ver_info.minor.num]
            else:
                hold = [ver_info.major.num, ver_info.minor.num + 1]

# Generated at 2022-06-29 18:14:41.013660
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

# Generated at 2022-06-29 18:14:48.831018
# Unit test for function bump_version
def test_bump_version():
    # Bumping major numbers
    test_vals = [
        ('0.0.0', '1.0'),
        ('1.0.0', '2.0'),
        ('2.0.0', '3.0'),
        ('3.0.0', '4.0'),
        ('4.0.0', '5.0'),
    ]
    for val in test_vals:
        assert bump_version(val[0]) == val[1], val

    # Bumping minor numbers

# Generated at 2022-06-29 18:15:00.513561
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(version='0.0.1') == '0.0.2'
    assert bump_version(version='0.0.1', position=0) == '1.0.1'
    assert bump_version(version='0.0.1', position=0, pre_release='a') == '0.1.0'
    assert bump_version(version='0.0.1', position=1) == '0.1.0'
    assert bump_version(version='0.0.1', position=1, pre_release='a') == '0.0.1'
    assert bump_version(version='0.0.1', position=2, pre_release='a') == '0.0.1'

# Generated at 2022-06-29 18:15:09.519216
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    def test_initial(version: str) -> None:
        print(version)
        print('bump_version(version)')
        print(bump_version(version))
        print('===')

    def test_position(version: str, position: int) -> None:
        print(version)
        print('bump_version(version, %r)' % position)
        print(bump_version(version, position))
        print('===')

    def test_position_pre(version: str, position: int) -> None:
        print(version)
        print('bump_version(version, %r, \'a\')' % position)
        print(bump_version(version, position, 'a'))

# Generated at 2022-06-29 18:15:21.729230
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.0'
    position = 2
    pre_release = ''
    expected_output = '1.2.1'
    output = bump_version(version, position, pre_release)
    assert output == expected_output

    version = '1.2.0'
    position = 2
    pre_release = 'a'
    expected_output = '1.2.1a0'
    output = bump_version(version, position, pre_release)
    assert output == expected_output

    version = '1.2.4'
    position = 2
    pre_release = 'a'
    expected_output = '1.2.5a0'
    output = bump_version(version, position, pre_release)
    assert output == expected_output

    version = '1.2.0'


# Generated at 2022-06-29 18:15:31.409125
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    # This can be created as a self contained module
    # pylint: disable=R0903
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Unit test for bump_version."""

        def test_01(self):
            """Basic test for bump_version."""
            self.assertEqual(
                bump_version('1.0.0', 1),
                '1.1.0'
            )

        def test_02(self):
            """Basic test for bump_version."""
            self.assertEqual(
                bump_version('1.0.0', 0),
                '2.0.0'
            )

        def test_03(self):
            """Basic test for bump_version."""

# Generated at 2022-06-29 18:15:43.910136
# Unit test for function bump_version
def test_bump_version():
    # Helper function to test if the version number is a valid number.
    def _is_valid_version(version:str):
        try:
            StrictVersion(version)
            return True
        except ValueError:
            return False

    # Helper function to test the version being updated correctly.
    def _is_correct(data:Tuple[str, int, str, str, str])->bool:
        # data is:
        # orig_version, position, pre_release, expected_version, test_version:
        try:
            # test_version = bump_version(
            #     version=data[0],
            #     position=data[1],
            #     pre_release=data[2]
            # )
            test_version = bump_version(*data[:3])
        except ValueError:
            test_

# Generated at 2022-06-29 18:15:54.151556
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.0', 1) == '0.3.0'
    assert bump_version('0.2.0', 0) == '1.0.0'
    assert bump_version('0.2.0', 1, 'a') == '0.3.0a0'
    assert bump_version('0.2.0a6', 1, 'a') == '0.3.0a0'
    assert bump_version('0.2.0a6', 2, 'a') == '0.2.1a0'
    assert bump_version('0.2.0a6', 2) == '0.2.1'
    assert bump_version('0.2.0b0', 1, 'a')