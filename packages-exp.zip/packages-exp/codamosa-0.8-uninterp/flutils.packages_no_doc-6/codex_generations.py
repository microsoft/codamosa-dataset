

# Generated at 2022-06-29 18:06:42.691862
# Unit test for function bump_version
def test_bump_version():
    print("Inside test_bump_version")
#    version_str = '1.2.3.4'
#    version_str = bump_version(version_str)
#    print("version_str: %s" % version_str)

test_bump_version()

# Generated at 2022-06-29 18:06:49.210975
# Unit test for function bump_version
def test_bump_version():
    #_test()
    #_test('1.0.0.a0')
    _test('1.2.3.a0')
    _test('1.2.3.a0', 2)
    _test('1.2.3.a0', 2, 'a')
    _test('1.2.3.b0', 2, 'b')
    _test('1.2.3.a0', 2, 'a')
    #_test('1.2.3', 1)



# Generated at 2022-06-29 18:06:59.227972
# Unit test for function bump_version
def test_bump_version():
    version = "1.2.3b4"
    print("Testing 'bump_version' with an example version number,\n"
          "`{0}`\n".format(version))
    print("Major Version Bump:")
    # Major version bump
    print("\t{0}".format(".".join(map(str, bump_version(version, position=0).split(".")))+'\n'))

    # Minor version bump
    print("Minor Version Bump:")
    print("\t{0}".format(".".join(map(str, bump_version(version, position=1).split(".")))+'\n'))

    # Patch version bump
    print("Patch Version Bump:")

# Generated at 2022-06-29 18:07:10.710895
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:21.990074
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.0'
    assert bump_version('1.1.0') == '1.1.0'
    assert bump_version('1.1.1') == '1.1.1'
    assert bump_version('1.0.0a0') == '1.0.0a0'
    assert bump_version('1.0.0b0') == '1.0.0b0'
    assert bump_version('1.0.1a0') == '1.0.1a0'
    assert bump_version('1.0.1b0') == '1.0.1b0'
    assert bump_version('1.0.0a1') == '1.0.0a1'

# Generated at 2022-06-29 18:07:32.076534
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version_ok(
            version: str,
            expected_version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        try:
            bumped = bump_version(version, position, pre_release)
        except Exception as err:  # pylint: disable=W0703
            print('version=%r, position=%r, pre_release=%r' % (
                version, position, pre_release
            ))
            raise err
        assert bumped == expected_version


# Generated at 2022-06-29 18:07:44.324943
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('1.2.3', position = 0) == '2.0.0'
    assert bump_version('1.2.3', position = 1) == '1.3.0'
    assert bump_version('1.2.3', position = 2) == '1.2.4'
    assert bump_version('1.2.3', position = 3) == '1.2.3'
    assert bump_version('1.2.3', position = -1) == '1.2.3'
    assert bump_version('1.2.3', position = -2) == '1.3.0'
    assert bump_version('1.2.3', position = -3) == '2.0.0'


# Generated at 2022-06-29 18:07:53.895784
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:06.646949
# Unit test for function bump_version
def test_bump_version():
    assert (bump_version('2.3.1') == '2.3.2')
    assert (bump_version('2.3') == '2.3.1')
    assert (bump_version('2.3', position=1) == '2.4')
    assert (bump_version('2.3', position=0) == '3')
    assert (bump_version('2.3.1', position=1) == '2.4')
    assert (bump_version('2.3.1', position=1, pre_release='a') == '2.4a0')
    assert (bump_version('2.3.1', position=1, pre_release='b') == '2.4b0')


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:08:13.761568
# Unit test for function bump_version
def test_bump_version():
    # Bumping the 'major' version
    assert bump_version('1.2.3') == '2'
    assert bump_version('1.2.3', 0) == '2'
    assert bump_version('1.2.3', position=0) == '2'
    assert bump_version('1.2.3', -3) == '2'
    assert bump_version('1.2.3', position=-3) == '2'

    # Bumping the 'minor' version
    assert bump_version('1.2.3') == '1.3'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-29 18:08:52.007175
# Unit test for function bump_version
def test_bump_version():
    class Test(NamedTuple):
        input: str
        position: int
        pre_release: str  # Empty string for None.
        expected: str

# Generated at 2022-06-29 18:09:05.601039
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=2, pre_release='a') == '1.0.1a0'
    assert bump_version('1.1.0a0') == '1.1.0a1'
    assert bump_version('1.1.0a1', pre_release='b') == '1.1.0b0'
    assert bump_version('1.1.0b0') == '1.1.0b1'
    assert bump_version('1.1.0b0') == '1.1.0b1'

# Generated at 2022-06-29 18:09:18.069340
# Unit test for function bump_version
def test_bump_version():
    # Base test
    assert bump_version('0.1.0') == '0.1.1'
    # Major test
    assert bump_version('0.1.0', 0) == '1.0.0'
    # Minor test
    assert bump_version('0.1.1', 1) == '0.2.0'
    # Patch test
    assert bump_version('0.1.1', 2) == '0.1.2'
    # Minor 0 test
    assert bump_version('0.1.1', 1, pre_release='a') == '0.2a0'
    # Minor 0 -> 1 test
    assert bump_version('0.1a0', 1, pre_release='a') == '0.2a0'
    # Minor 0 -> 2 test

# Generated at 2022-06-29 18:09:24.160006
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:36.589987
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    version = '0.2.6'

# Generated at 2022-06-29 18:09:43.884531
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'

    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'

# Generated at 2022-06-29 18:09:56.533994
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0', 1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', -1)
    assert version == '1.0.1'
    version = bump_version('1.0.0', 1, 'a')
    assert version == '1.1a0'
    version = bump_version('1.0.0', 1, 'A')
    assert version == '1.1a0'
    version = bump_version('1.0.0', 1, 'Alpha')
    assert version == '1.1a0'
    version = bump_version('1.0.0', 1, 'a')
    assert version == '1.1a0'
    version = bump_version('1.0.0', 1, 'a')

# Generated at 2022-06-29 18:10:07.144628
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.1', pre_release='a') == '1.0.2a0'
    assert bump_version('1.0.1', pre_release='b') == '1.0.2b0'
    assert bump_version('1.0.1a1', pre_release='a') == '1.0.2a0'
    assert bump_version('1.0.1b3', pre_release='b') == '1.0.2b0'
    assert bump_version('1.0.1a1') == '1.0.2'
    assert bump_version('1.0.1a1', 1) == '1.1'
    assert bump_

# Generated at 2022-06-29 18:10:19.488731
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:32.447981
# Unit test for function bump_version
def test_bump_version():
    # Ensure patch gets bumped on normal version number
    ver = bump_version('1.2.3')
    assert ver == '1.2.4'
    # Ensure minor gets bumped if patch is 0
    ver = bump_version('1.2.0')
    assert ver == '1.3.0'
    # Ensure major gets bumped if minor is 0
    ver = bump_version('1.0.3')
    assert ver == '2.0.0'
    # Ensure patch gets bumped on normal prerelease number
    ver = bump_version('1.2.3-a1')
    assert ver == '1.2.3-a2'
    # Ensure minor gets bumped if patch is 0 on prerelease
    ver = bump_version('1.2.0-a1')

# Generated at 2022-06-29 18:10:44.166728
# Unit test for function bump_version
def test_bump_version():
    from colorama import Fore, init
    init()

    def _build_test(
        version: str,
        position: int,
        pre_release: str,
        expected: str,
    ) -> None:
        try:
            actual: str = bump_version(version, position, pre_release)
            assert actual == expected
            print('%sOK%s %s' % (Fore.GREEN, Fore.RESET, version))
        except AssertionError:
            print('%sFAIL%s %s' % (Fore.RED, Fore.RESET, version))

    _build_test('0.1.0', 1, None, '0.2.0')
    _build_test('1.1.0', 1, None, '1.2.0')

# Generated at 2022-06-29 18:10:56.290367
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.9.0-alpha.0") == "1.9.0-alpha.1"
    assert bump_version("1.9.0-alpha.0", 1) == "1.9.0"
    assert bump_version("1.9.0-alpha.0", 1, "beta") == "1.9.0-beta.0"
    assert bump_version("2.0.0-beta.2") == "2.0.0-beta.3"
    assert bump_version("2.0.0-beta.2", 2, "alpha") == "2.0.1-alpha.0"
    assert bump_version("0.0.3") == "0.0.4"

# Generated at 2022-06-29 18:11:07.710469
# Unit test for function bump_version
def test_bump_version():
    print("\nTesting Testing Testing")
    print("\nTesting Testing Testing")
    print("\nTesting Testing Testing")


# Generated at 2022-06-29 18:11:20.911494
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0-alpha') == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=1, pre_release='alpha') == \
        '1.1.0-alpha'
    assert bump_version('1.0.0', position=1, pre_release='beta') == \
        '1.1.0-beta'

# Generated at 2022-06-29 18:11:34.310888
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.7.0') == '0.7.1'
    assert bump_version('0.7.1') == '0.7.2'
    assert bump_version('0.7.0', 1) == '0.8.0'
    assert bump_version('0.7.1', 1) == '0.8.0'
    assert bump_version('0.7.2', 1) == '0.8.0'
    assert bump_version('0.7.0', 0) == '1.0.0'
    assert bump_version('0.7.1', 0) == '1.0.0'
    assert bump_version('0.7.2', 0) == '1.0.0'

# Generated at 2022-06-29 18:11:41.544732
# Unit test for function bump_version
def test_bump_version():
    version = '0.12.0a1'
    result = bump_version(version, pre_release='a')
    assert result == '0.12.0a2'
    result = bump_version(version, position=1, pre_release='a')
    assert result == '0.13.0a0'
    result = bump_version(version, position=1, pre_release='b')
    assert result == '0.12.0b0'
    result = bump_version(version, position=1)
    assert result == '0.13.0'
    result = bump_version(version, position=2)
    assert result == '0.12.1'
    result = bump_version(version, position=0)
    assert result == '1.0.0'

# Generated at 2022-06-29 18:11:50.898118
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=1, pre_release='b') == '1.1.0b0'
    assert bump_version('1.0.0b1') == '1.0.0b2'
    assert bump_version('1.0.0a1') == '1.0.0a2'
    assert bump_version('1.0.0a1', position=1) == '1.1.0a0'
    assert bump_version('1.0.0b1', position=1) == '1.1.0b0'

# Generated at 2022-06-29 18:12:03.578343
# Unit test for function bump_version
def test_bump_version():
    def test(version, position, prerelease, expected, test_name):
        """Test the bump_version() function."""
        actual = bump_version(version, position, prerelease)
        assert actual == expected, (
            f'{test_name} failed: The actual result, {actual}, does not '
            f'equal the expected result, {expected}.'
        )


# Generated at 2022-06-29 18:12:15.796917
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0-a0') == '1.0.0'
    assert bump_version('0.0.0-a1') == '1.0.0'
    assert bump_version('0.0.0-b0') == '1.0.0'
    assert bump_version('0.0.0-b1') == '1.0.0'

    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0-a0') == '1.1.0'
    assert bump_version('1.0.0-a1') == '1.1.0'

# Generated at 2022-06-29 18:12:25.906620
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """ Unit test of function bump_version()
    """
    # Test 1: This function shall not mutate the version info
    version = '0.0.0'
    position = -2
    pre_release = None
    new_version = bump_version(version=version, position=position)
    assert new_version != version
    assert new_version == '0.1.0'
    # Test 2: This function shall not mutate the position info
    version = '0.0.0'
    position = -2
    pre_release = None
    new_version = bump_version(version=version, position=position)
    assert new_version != version
    assert new_version == '0.1.0'
    # Test 3: This function shall not mutate the pre-release info
    version

# Generated at 2022-06-29 18:12:42.457537
# Unit test for function bump_version
def test_bump_version():
    # Testing the default arguments
    assert ('1.2.3' == bump_version('1.2.2'))

    # Testing the major position
    assert ('2.0.0' == bump_version('1.2.3', 0))
    assert ('2.0.0' == bump_version('1.2.3', -3))

    # Testing the minor position, without pre-release
    assert ('1.3.0' == bump_version('1.2.3', 1))
    assert ('1.3.0' == bump_version('1.2.3', -2))

    # Testing the minor position, with pre-release [alpha]
    assert ('1.3.0' == bump_version('1.2.3a0', 1))

# Generated at 2022-06-29 18:12:47.394702
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1.1', position=-1) == '0.1.2'
    assert bump_version('0.1.1', position=-2) == '0.2.0'
    assert bump_version('0.1.1', position=-3) == '1.0.0'
    assert bump_version('0.1.1', position=1) == '0.1.2'
    assert bump_version('0.1.1', position=2) == '0.1.2'
    assert bump_version('0.1.1', position=3) == '0.1.2'
    assert bump_version('0.1.1', position=0) == '1.0.0'
    assert bump

# Generated at 2022-06-29 18:12:58.589929
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:12.146818
# Unit test for function bump_version
def test_bump_version():
    # Test the current version
    version = bump_version('0.2.2.dev3')
    assert version == '0.2.3'
    version = bump_version('0.2.2.dev3', -1)
    assert version == '0.2.3'
    version = bump_version('0.2.2.dev3', 0)
    assert version == '1.0.0'
    version = bump_version('0.2.2.dev3', 1)
    assert version == '0.3.0'
    version = bump_version('0.2.2.dev3', 2)
    assert version == '0.2.3'

    # Test a version that doesn't have a version number in the patch field
    version = bump_version('0.2', -1)

# Generated at 2022-06-29 18:13:18.657176
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('1.1.0') == '2.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('1.0.1') == '2.0.0'
    assert bump_version('2.0.1') == '3.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'

# Generated at 2022-06-29 18:13:31.119033
# Unit test for function bump_version
def test_bump_version():
    try:
        bump_version('0.0.1')
    except Exception as err:
        raise AssertionError(
            'A value of %r for the first argument of bump_version '
            'should not cause an exception of type %r.' % (
                '0.0.1',
                err.__class__.__name__,
            )
        ) from None

    try:
        bump_version('0.0.1', pre_release='a')
    except Exception as err:
        raise AssertionError(
            'A value of %r for the first argument of bump_version '
            'should not cause an exception of type %r.' % (
                '0.0.1',
                err.__class__.__name__,
            )
        ) from None


# Generated at 2022-06-29 18:13:41.887435
# Unit test for function bump_version
def test_bump_version():
    def _assert_version(version, out_version):
        assert bump_version(version) == out_version

    _assert_version('1.0.0', '1.0.0')
    _assert_version('1.0.0.0', '1.0.0')
    _assert_version('1.0.0x', '1.0.0')
    _assert_version('1.0.0.0x', '1.0.0')

    _assert_version('1.0.1', '1.0.1')
    _assert_version('1.0.1x', '1.0.1')
    _assert_version('1.0.1.0x', '1.0.1')
    _assert_version('1.0.1a0', '1.0.1')


# Generated at 2022-06-29 18:13:49.207166
# Unit test for function bump_version
def test_bump_version():
    import random
    import unittest
    random.seed(42)

    class TestVersionBump(unittest.TestCase):
        def setUp(self):
            # List of major, minor, and patch parts of the version string.
            self.major_parts = ['0', '1', '2', '3', '4', '5']
            self.minor_parts = ['0', '1', '2', '3', '4', '5']
            self.patch_parts = ['0', '1', '2', '3', '4', '5']

            # List of pre-release parts of the version string.
            self.pre_release_parts = ['', 'a', 'b']


# Generated at 2022-06-29 18:14:01.910589
# Unit test for function bump_version
def test_bump_version():
    # Test for major
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.1.2', 0) == '2.0.0'
    assert bump_version('1.1.0', 0) == '2.0.0'
    assert bump_version('1.0.0', -3) == '2.0.0'
    assert bump_version('1.1.2', -3) == '2.0.0'
    assert bump_version('1.1.0', -3) == '2.0.0'

    # Test for minor
    assert bump_

# Generated at 2022-06-29 18:14:11.541274
# Unit test for function bump_version
def test_bump_version():
    # Test that a blank string returns a blank string
    assert bump_version('') == ''

    # Test that it only accepts an 'int' between -3 and 2
    with pytest.raises(ValueError):
        bump_version('1.0.0', position=3)

    with pytest.raises(ValueError):
        bump_version('1.0.0', position=-4)

    with pytest.raises(ValueError):
        bump_version('1.0.0', position=-10)

    # Test that it only accepts a pre-release version of 'a' 'alpha' 'b' 'beta'
    with pytest.raises(ValueError):
        bump_version('1.0.0', position=1, pre_release='1')

    with pytest.raises(ValueError):
        bump_

# Generated at 2022-06-29 18:14:23.268324
# Unit test for function bump_version
def test_bump_version():
    print('Test for bump_version:')
    print(bump_version('0.0.0'))

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:14:33.745790
# Unit test for function bump_version
def test_bump_version():
    from sys import getrecursionlimit, setrecursionlimit
    from os import environ
    from time import time

    # pylint: disable=W0703
    # pylint: disable=R0914
    # pylint: disable=R0915
    def _unit_test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ):
        out = bump_version(version, position, pre_release)
        assert out == expected, (
            "The 'bump_version(%r, %r, %r)' function did not return "
            "the expected value, %r. It returned %r instead."
            % (version, position, pre_release, expected, out)
        )

    # Test this function, bump_version
    _unit_test

# Generated at 2022-06-29 18:14:45.179944
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import os

    class TestBumpVersion(unittest.TestCase):
        def _run_assertions(
                self,
                version: str,
                position: int,
                pre_release: str,
                expected: str
        ):
            actual = bump_version(
                version=version,
                position=position,
                pre_release=pre_release
            )
            self.assertEqual(expected, actual)

        def test_000(self):
            version = '1.0.0'
            self._run_assertions(
                version=version,
                position=-3,
                pre_release=None,
                expected='2.0.0'
            )

# Generated at 2022-06-29 18:14:54.170992
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', position=2) == '1.1.2'
    assert bump_version('1.1.1', position=2, pre_release='a') == '1.1.2a0'
    assert bump_version('1.1.1', position=2, pre_release='alpha') == '1.1.2a0'
    assert bump_version('1.1.1', position=2, pre_release='b') == '1.1.2b0'
    assert bump_version('1.1.1', position=2, pre_release='beta') == '1.1.2b0'

# Generated at 2022-06-29 18:15:05.411968
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', 2) == '0.0.1'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'

# Generated at 2022-06-29 18:15:15.444856
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 0, 'a') == '1.0.0'
    assert bump_version('0.0.1', 0, 'b') == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 1, 'a') == '0.1.0a0'
    assert bump_version('0.0.1', 1, 'b') == '0.1.0b0'
    assert bump_version('0.0.1', 2) == '0.0.2'
   

# Generated at 2022-06-29 18:15:27.232914
# Unit test for function bump_version
def test_bump_version():
    print("Test bump_version function")
    # Test standard version bumps
    version = "1.1.1"
    pos = 0
    print("version=", version, "pos=", pos)
    print("Expect 2.0.0")
    print("Got", bump_version(version, pos))
    pos = 1
    print("version=", version, "pos=", pos)
    print("Expect 1.2.0")
    print("Got", bump_version(version, pos))
    pos = 2
    print("version=", version, "pos=", pos)
    print("Expect 1.1.2")
    print("Got", bump_version(version, pos))

    # Test negative position
    version = "1.1.1"
    pos = -3

# Generated at 2022-06-29 18:15:34.169971
# Unit test for function bump_version
def test_bump_version():
    # Bump version number
    version = bump_version('1.0.0')
    assert version == '2.0.0'

    # Bump patch number
    version = bump_version('1.1.1')
    assert version == '1.1.2'

    # Bump minor number
    version = bump_version('1.1.0')
    assert version == '1.2.0'

    # Bump minor number with alpha pre-release
    version = bump_version('1.1.0', pre_release='a')
    assert version == '1.2.0a0'

    # Bump minor number with beta pre-release
    version = bump_version('1.1.0', pre_release='b')
    assert version == '1.2.0b0'

    # Bump patch number with pre

# Generated at 2022-06-29 18:15:46.306258
# Unit test for function bump_version
def test_bump_version():
    """
    Test the :py:func:`bump_version` function.

    """
    test_version_bump_position_numbers = [
        -3,
        -2,
        -1,
        0,
        1,
        2,
        3,
        4,
    ]
    test_version_bump_position_values = [
        -3,
        -2,
        -1,
        0,
        1,
        2,
        2,
        2,
    ]

# Generated at 2022-06-29 18:15:50.833521
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    print("test_bump_version")

    def check(a, b, c):
        """Check values for function bump_version."""
        res = bump_version(a)
        assert res == b, f"Failed: {a} -> {b} got {res}"
        res = bump_version(a, pre_release=c)
        assert res == c, f"Failed: {a} -> {c} got {res}"

    check("1.2.3", "1.2.4", "1.2.4a0")
    check("1.2.3a1", "1.2.3a2", "1.2.3b0")

# Generated at 2022-06-29 18:16:15.957377
# Unit test for function bump_version
def test_bump_version():
    """
    $ pytest bump_version.py
    """
    # noinspection PyUnusedLocal
    position_positive: int = -3
    # noinspection PyUnusedLocal
    bump_type: int = -3
    # noinspection PyUnusedLocal
    pre_release: Optional[str] = None

    version = '1.0.0'
    position = -1  # 'minor'
    pre_release = 'a'
    position_positive = _build_version_bump_position(position)
    bump_type = _build_version_bump_type(position_positive, pre_release)
    assert bump_type == _BUMP_VERSION_MINOR_ALPHA
    bumped_version = bump_version(version, position, pre_release)