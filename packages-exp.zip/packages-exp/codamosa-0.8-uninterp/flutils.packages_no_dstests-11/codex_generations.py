

# Generated at 2022-06-29 18:06:46.203035
# Unit test for function bump_version
def test_bump_version():
    def _do_test(
            ver: str,
            position: int = 2,
            pre_release: Union[str, None] = None
    ) -> str:
        return bump_version(ver, position, pre_release)

    def _do_test_exc(
            ver: str,
            position: int = 2,
            pre_release: Union[str, None] = None
    ) -> None:
        try:
            _do_test(ver, position, pre_release)
        except ValueError:
            return
        raise AssertionError(
            "Bumping version %s with prerelease of %s did not raise a "
            "ValueError." % (ver, pre_release)
        )

    assert _do_test('1.0.0') == '1.0.1'
    assert _do

# Generated at 2022-06-29 18:06:53.758338
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.3a2') == '1.2.3a3'
    assert bump_version('1.2.3b2') == '1.2.3b3'
    assert bump_version('1.2.3a2', 1) == '1.3a0'
    assert bump_version('1.2.3b2', 1) == '1.3b0'
    assert bump_version('1.2.3a2', 1, 'b') == '1.3b0'
    assert bump_version('1.2.3b2', 1, 'a') == '1.3a0'
    assert bump_version('1.0.0') == '1.0.1'

# Generated at 2022-06-29 18:07:04.597129
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("0.0.7") == "0.0.8"
    assert bump_version("0.0.7", 1) == "0.1.0"
    assert bump_version("1.2.3") == "1.2.4"
    assert bump_version("1.2.3", 0) == "2.0.0"
    assert bump_version("10.2.3", 0) == "11.0.0"
    assert bump_version("10.12.13") == "10.12.14"
    assert bump_version("1.2.3", 0, "a") == "2.0.0"
    assert bump_version("1.2.3", 1, "b") == "1.3.0"

# Generated at 2022-06-29 18:07:16.126430
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    def version_should_be(pos, ver, pre, baseline):
        this_pre = None
        if pre:
            this_pre = 'a'
        out = bump_version(ver, pos, this_pre)
        assert out == baseline, (out, baseline)

    # pre
    version_should_be(0, '0.0.0', True, '0.0.0')
    version_should_be(1, '0.0.0', True, '0.1.0')
    version_should_be(2, '0.0.0', True, '0.0.1a0')

    # major
    version_should_be(0, '0.0.0', False, '1.0.0')

# Generated at 2022-06-29 18:07:25.822166
# Unit test for function bump_version
def test_bump_version():
    # Test different bump version types
    version = '0.8.2'
    assert bump_version(version, pre_release='a') == '0.9.0a0'
    assert bump_version(version, pre_release='b') == '0.8.3b0'
    assert bump_version(version, 1, pre_release='b') == '0.9.0b0'
    assert bump_version(version, 1, pre_release='a') == '0.9.0a0'
    assert bump_version(version, pre_release='alpha') == '0.9.0a0'
    assert bump_version(version, pre_release='beta') == '0.8.3b0'
    assert bump_version(version, 1, pre_release='beta') == '0.9.0b0'

# Generated at 2022-06-29 18:07:32.022994
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from .utils import build_docval, getargs, run_test_doctest

    dval = build_docval(bump_version)
    with getargs(dval) as args:
        run_test_doctest(bump_version, args)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:07:44.270027
# Unit test for function bump_version
def test_bump_version():
    """
    Run some unit tests for the :class:`bump_version` function
    """
    assert bump_version('0.0.0.0') == '1.0.0.0'
    assert bump_version('0.0.9.0') == '1.0.0.0'
    assert bump_version('0.9.9.0') == '1.0.0.0'
    assert bump_version('0.0.0.0', 1) == '0.1.0.0'
    assert bump_version('0.0.9.0', 1) == '0.1.0.0'
    assert bump_version('0.9.9.0', 1) == '1.0.0.0'

# Generated at 2022-06-29 18:07:53.859846
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.2.3') == '1.2.4')
    assert(bump_version('1.2.3', 1) == '1.3')
    assert(bump_version('1.2.3', 0) == '2')
    assert(bump_version('1.2.3', -1) == '1.2.4')
    assert(bump_version('1.2.3', -2) == '1.3')
    assert(bump_version('1.2.3', -3) == '2')
    assert(bump_version('1.2.3', 2, 'a') == '1.2.3a0')
    assert(bump_version('1.2.3', 2, 'b') == '1.2.3b0')


# Generated at 2022-06-29 18:08:06.592277
# Unit test for function bump_version
def test_bump_version():
    # Test to ensure that the version major part gets bumped
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('2.9.0', 0) == '3'
    assert bump_version('1.0', 0) == '2'
    # Test to ensure that the version minor part gets bumped when no
    # pre-release version is set
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.0', 1) == '2.0.0'
    # Test to ensure that the version minor part gets bumped when a


# Generated at 2022-06-29 18:08:13.740543
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.3', 2) == '0.0.4'
    assert bump_version('0.1.3', 2) == '0.1.4'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('0.0.3', 1) == '0.1.0'
    assert bump_version('0.1.3', 1) == '0.2.0'
    assert bump_version('0.0.3', 0) == '1.0.0'
    assert bump_version('1.0.3', 0) == '2.0.0'
    assert bump_version('0.0.3', -2) == '0.0.4'

# Generated at 2022-06-29 18:08:49.213660
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:57.281621
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

    assert bump_version('1.2.3', 1, 'a') == '1.3.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0'

# Generated at 2022-06-29 18:09:08.688287
# Unit test for function bump_version
def test_bump_version():
    def _assert(
            version: str,
            position: int,
            pre_release: Optional[str],
            exp_out: str
    ) -> None:
        out = bump_version(version, position, pre_release)
        assert out == exp_out

    _assert(
        '0.2.0',
        -1,
        None,
        '0.2.1'
    )
    _assert(
        '0.2.0',
        -1,
        'a',
        '0.2.1'
    )
    _assert(
        '0.1.0',
        -2,
        None,
        '0.2.0'
    )

# Generated at 2022-06-29 18:09:20.612317
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 1) == '0.1'
    assert bump_version('0.0.1', 2) == '1'
    assert bump_version('0.0.1', 2, 'alpha') == '0.1a0'
    assert bump_version('0.0.1', 1, 'alpha') == '0.1a0'
    assert bump_version('0.0.1', 0, 'alpha') == '1.0.0'
    assert bump_version('0.0.1', 0, 'b') == '1.0.0'
    assert bump_version('0.0.1', 1, 'b') == '0.1b0'

# Generated at 2022-06-29 18:09:33.378790
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120
    # pylint: disable=R0201
    # pylint: disable=R0913
    # pylint: disable=W0612
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, 2) == '1.2.4'
    assert bump_version(version, 3) == '1.2.4'
    assert bump_version(version, 4) == '1.2.4'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version(version, pre_release='alpha') == '1.2.4a0'

# Generated at 2022-06-29 18:09:44.186614
# Unit test for function bump_version
def test_bump_version():
    # Test pre-release version numbers
    assert bump_version('1.0.0b0') == '1.0.0b1'
    assert bump_version('1.0.1a2') == '1.0.1a3'
    assert bump_version('1.0.0a0') == '1.0.0a1'
    assert bump_version('1.0.0a0', 0, 'b') == '1.0.0b0'
    assert bump_version('1.1.0b1') == '1.1.0b2'
    assert bump_version('1.1.1b1') == '1.1.1b2'
    assert bump_version('1.0.0b0', 1) == '1.1.0'

# Generated at 2022-06-29 18:09:56.888867
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:07.365675
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('6.4.6', 2) == '6.4.7'
    assert bump_version('6.4.6', 1) == '6.5.0'
    assert bump_version('6.4.6', 0) == '7.0.0'
    assert bump_version('6.4.6', -1) == '6.4.7'
    assert bump_version('6.4.6', -2) == '6.5.0'
    assert bump_version('6.4.6', -3) == '7.0.0'
    assert bump_version('6.4.6', pre_release='alpha') == '6.5.0a0'
    assert bump_version('6.4.6', pre_release='beta') == '6.5.0b0'


# Generated at 2022-06-29 18:10:19.577110
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:32.532012
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1', 'version 0.0.0 is bumped to 0.0.1'
    assert bump_version('0.0.0a0', 2) == '0.0.1a0', 'version 0.0.0a0 is bumped to 0.0.1a0'
    assert bump_version('0.0.0a0') == '0.0.0a1', 'version 0.0.0a0 is bumped to 0.0.0a1'
    assert bump_version('0.0.0a0', 2, 'b') == '0.0.1b0', 'version 0.0.0a0 is bumped to 0.0.1b0'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:10:43.955890
# Unit test for function bump_version
def test_bump_version():
    original_versions = ["0.0.0", "1.2.0", "1.2.3", "1.2.0a0", "1.2.3a6"]
    expected_bumps_minors = [
        "0.1.0", "2.0.0", "1.3.0", "1.2.0", "1.2.0a1"
    ]
    expected_bumps_patches = [
        "0.0.1", "1.2.1", "1.2.4", "1.2.0a1", "1.2.3a7"
    ]

# Generated at 2022-06-29 18:10:56.099964
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 'a') == '1.0.0a0'
    assert bump_version('1.0.0', 'b') == '1.0.0b0'
    assert bump_version('1.0.0', 0, 'a') == '1.1.0'
    assert bump_version('1.0.0', 0, 'b') == '1.1.0'
    assert bump_version('1.0.0', 0, 'x') == '2.0.0'

# Generated at 2022-06-29 18:11:07.550834
# Unit test for function bump_version
def test_bump_version():
    """Run 'bump_version' unit tests."""
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 1, 'a') == '1.1.0a0'
    assert bump_version('1.0.0', 1, 'alpha') == '1.1.0a0'
    assert bump_version('1.0a0', 1, 'alpha') == '1.1.0a0'
    assert bump_version('1.0b0', 1, 'beta') == '1.1.0b0'

# Generated at 2022-06-29 18:11:20.911042
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2') == '1.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2-a') == '1.2-a1'
    assert bump_version('1.2.3-a') == '1.2.3-a1'
    assert bump_version('1.2-a.3-b') == '1.2-a.3-b1'
    assert bump_version('1.2.3-a.4-b') == '1.2.3-a.4-b1'
    assert bump_version('1.2-a0') == '1.2-a1'
    assert bump_version('1.2.3-a0') == '1.2.3-a1'

# Generated at 2022-06-29 18:11:34.311230
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:45.375626
# Unit test for function bump_version
def test_bump_version():
    from mo_testing.fuzzytestcase import FuzzyTestCase
    from mo_logs.exceptions import Except

    def run_test_case(
            case: Dict[str, Any],
            test_case: FuzzyTestCase
    ) -> None:
        try:
            actual = bump_version(**case)
            test_case.assertEqual(case['result'], actual)
        except Except as e:
            test_case.assertEqual(case['exception'], e.type)


# Generated at 2022-06-29 18:11:53.171084
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:05.169794
# Unit test for function bump_version
def test_bump_version():
    """The unit test for the ``pyutils.version.bump_version()`` function."""
    def normal_bump(
            version: str
    ) -> Tuple[str, str]:
        """Bump a version."""
        pos: int = 2
        while True:
            pre_release: Union[None, str] = None
            bump_type = _build_version_bump_type(pos, pre_release)
            if bump_type in _BUMP_VERSION_PATCHES:
                pos -= 1
                continue
            bump = bump_version(version, pos, pre_release)
            return bump, pre_release

    def alpha_bump(
            version: str
    ) -> Tuple[str, str]:
        """Bump a version to alpha."""
        pos: int = 2
        pre_release

# Generated at 2022-06-29 18:12:17.956611
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    New in version 0.4

    """
    # No assert(s) needed for this one, since an exception will be thrown
    # if the version number is invalid.
    ver_obj = StrictVersion('1.2.3')
    assert ver_obj.version == (1, 2, 3)
    assert ver_obj.prerelease is None
    ver_obj = StrictVersion('1.2.3a0')
    assert ver_obj.version == (1, 2, 3)
    assert ver_obj.prerelease == ('a', 0)

    # The Major bump
    assert bump_version('1.2.3', position=0) == '2.0.0'

# Generated at 2022-06-29 18:12:23.602563
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:39.160890
# Unit test for function bump_version
def test_bump_version():
    """Tests for bump_version."""
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('1.2.3.4') == '1.2.4'
    assert bump_version('1.2.3.4', position=2) == '1.2.4'
    assert bump_version('0.1.2a1') == '0.1.2.a2'
    assert bump_version('0.1.2a1', 2, 'alpha') == '0.1.2.a2'
    assert bump_version('0.1.2a1', 2, 'a') == '0.1.2.a2'

# Generated at 2022-06-29 18:12:42.231726
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    ver: str = bump_version('1.0')
    print(ver)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:12:53.788559
# Unit test for function bump_version
def test_bump_version():

    def _get_ver_info(version) -> _VersionInfo:
        return _build_version_info(
            '%s' % version
        )

    def _it() -> bool:
        # noinspection PyPep8Naming
        def bump_version_pos(
                ver_a: str,
                ver_b: str,
                pos: int,
                pre: str = None
        ) -> bool:
            a = _get_ver_info(ver_a)
            b = _get_ver_info(ver_b)
            _bump_ver = bump_version(ver_a, position=pos, pre_release=pre)
            c = _get_ver_info(_bump_ver)
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-29 18:12:59.677138
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version"""
    import sys
    import xdoctest
    args = sys.argv[1:]
    xdoctest.doctest_module(__file__)
    sys.exit(0)


if __name__ == '__main__':
    """
    CommandLine:
        python -m version_bump.bump_version
    """
    test_bump_version()

# Generated at 2022-06-29 18:13:12.325282
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from version_query import random_version
    # noinspection PyUnresolvedReferences
    from version_query import random_version_seed


# Generated at 2022-06-29 18:13:21.529100
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:34.127683
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 2) == '0.1.1'
    assert bump_version('0.1.0', 2, 'a') == '0.1.1a0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0', 0, 'a') == '0.1.0a0'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 1, 'a') == '0.2.0a0'

# Generated at 2022-06-29 18:13:39.265994
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Test the function bump_version."""
    # pylint: disable=W0621
    # pylint: disable=W0613
    # pylint: disable=W0612
    # pylint: disable=W0105

    def _ok(v1, v2, version, position, pre_release=None):
        out = bump_version(version, position, pre_release)
        if out != v1:
            raise AssertionError
        out = bump_version(version, position)
        if out != v2:
            raise AssertionError

    def _fail(v1, v2, version, position, pre_release=None):
        try:
            bump_version(version, position, pre_release)
        except ValueError:
            pass


# Generated at 2022-06-29 18:13:48.078341
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.1.1', 2) == '2.1.2'
    assert bump_version('2.1.1', 2, 'alpha') == '2.1.1a0'
    assert bump_version('2.1.1', 2, 'a') == '2.1.1a0'
    assert bump_version('2.1.1a1', 2, 'alpha') == '2.1.1a2'
    assert bump_version('2.1.1a1', 2, 'a') == '2.1.1a2'
    assert bump_version('2.1.1a1', 2, 'beta') == '2.1.1b0'
    assert bump_version('2.1.1a1', 2, 'b') == '2.1.1b0'


# Generated at 2022-06-29 18:14:01.459779
# Unit test for function bump_version
def test_bump_version():
    # Note: bump_version returns a string
    assert bump_version('1.9.3') == '1.9.4'
    assert bump_version('1.9.3', 2) == '1.9.4'
    assert bump_version('1.9.3', 2, 'a') == '1.9.4'
    assert bump_version('1.9.3', 2, 'alpha') == '1.9.4'
    assert bump_version('1.9.3', 2, 'b') == '1.9.4'
    assert bump_version('1.9.3', 2, 'beta') == '1.9.4'
    assert bump_version('1.9.3', 1) == '1.10.0'
    assert bump_version('1.9.3', 1, 'a')

# Generated at 2022-06-29 18:14:12.851923
# Unit test for function bump_version
def test_bump_version():
    import os
    from py2store.util import module_member_store, mod_paths_from_name, mod_path
    import py2store.util as _u
    from py2store.util import mod_paths_from_name

    def is_part_in_list(list1, list2):
        # type: (list, list) -> bool
        """Checks if at least one part of list1 is in list2"""
        is_in = False
        for item in list1:
            if item in list2:
                is_in = True
                break
        return is_in

    def check_msg(msg):
        # type: (str) -> bool
        """Raises an error if the value of msg is not one of the error messages expected."""

# Generated at 2022-06-29 18:14:23.556924
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys
    from unittest import TestCase
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from pe_utils import bump_version

# Generated at 2022-06-29 18:14:34.060530
# Unit test for function bump_version
def test_bump_version():
    """
    Run the unit tests for
    :py:func:`~bump_version_number.bump_version`.
    """
    from . import bump_version

    def _check(version, position, pre_release, out):
        return bump_version(version, position, pre_release) == out

    ver_str = '1.5.0'
    assert _check(ver_str, 0, None, '2.0.0')
    assert _check(ver_str, 1, None, '1.6.0')
    assert _check(ver_str, 2, None, '1.5.1')
    assert _check(ver_str, 2, 'a', '1.5.1a0')
    ver_str = '1.6.1a10'

# Generated at 2022-06-29 18:14:45.373670
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('0.1.0', 1) == '0.2.0'
    assert bump_version('0.1.0', 0) == '1.0.0'
    assert bump_version('0.1.0beta1', pre_release='a') == '0.1.0a0'
    assert bump_version('0.1.0a0', pre_release='b') == '0.1.0b0'
    assert bump_version('1.0.0', pre_release='a') == '1.1.0a0'
    assert bump_version('1.0.0a0', pre_release='b') == '1.0.0b0'

# Generated at 2022-06-29 18:14:50.595254
# Unit test for function bump_version
def test_bump_version():
    for version in ('1.2', '0.2.1', '1.2.4', '1.2.4b0', '1.2.4b7', '1.2.4a7'):
        new_ver = bump_version(version)
        yield new_ver
    return


# main
if __name__ == '__main__':
    print(list(test_bump_version()))

# Generated at 2022-06-29 18:14:56.971329
# Unit test for function bump_version
def test_bump_version():
    from semver import (
        bump_major_version,
        bump_minor_version,
        bump_patch_version,
        bump_pre_major_version,
        bump_pre_minor_version,
        bump_pre_patch_version,
    )

    version = '0.0.0'
    my_bump = bump_version(version)
    assert my_bump == '0.0.1'
    assert bump_version(my_bump) == '0.0.2'
    assert bump_version(my_bump, 0) == '1.0.0'
    assert bump_version(my_bump, 1) == '0.1.0'
    assert bump_version(my_bump, pre_release='a') == '0.0.2a0'

# Generated at 2022-06-29 18:15:07.802909
# Unit test for function bump_version
def test_bump_version():
    import sys
    if sys.version_info < (3, 0, 0):
        raise ImportError('Python 3 required.')

    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_1(self) -> None:
            self.assertEqual(bump_version('0.1.1'), '0.1.2')

        def test_2(self) -> None:
            self.assertEqual(bump_version('0.1.1', 1), '0.2.1')

        def test_3(self) -> None:
            self.assertEqual(bump_version('1.2.3'), '1.2.4')


# Generated at 2022-06-29 18:15:19.019264
# Unit test for function bump_version
def test_bump_version():
    """The unit tests for the bump_version function."""
    # When emptying the version number
    version: str = '1.0.0'
    assert bump_version(version) == '2.0.0'
    assert bump_version(version, 0) == '2.0.0'
    assert bump_version(version, 1) == '1.1.0'
    assert bump_version(version, 2) == '1.0.1'

    # When the patch position is not zero
    version = '1.0.10'
    assert bump_version(version) == '1.1.0'
    assert bump_version(version, 0) == '2.0.0'
    assert bump_version(version, 1) == '1.1.0'

# Generated at 2022-06-29 18:15:29.792200
# Unit test for function bump_version
def test_bump_version():
    class TestCase(NamedTuple):
        ver: str
        pos: int
        pre: str
        out: str


# Generated at 2022-06-29 18:15:42.037572
# Unit test for function bump_version
def test_bump_version():
    # Major
    assert bump_version('0.2.1') == '1.0.0'
    assert bump_version('0.2.1', 0) == '1.0.0'
    assert bump_version('0.2.1', -3) == '1.0.0'
    assert bump_version('0.2.1', 1) == '0.3.0'
    assert bump_version('0.2.1', 2) == '0.2.2'
    assert bump_version('0.2.1', -2) == '0.3.0'
    assert bump_version('0.2.1', -1) == '0.2.2'

    # Major alpha
    assert bump_version('0.2.1', 1, 'a') == '0.3.0a0'


# Generated at 2022-06-29 18:15:56.301002
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('X.Y', 0) == '1.0'
    assert bump_version('X.Y', 0, 'alpha') == '1.0'
    assert bump_version('X.Y.Z', 0, 'alpha') == '1.0'
    assert bump_version('X.Y', 0, 'beta') == '1.0'
    assert bump_version('X.Y.Z', 0, 'beta') == '1.0'
    assert bump_version('X.Y.Z', 1) == '0.1.0'
    assert bump_version('X.Y.Z', 1, 'alpha') == '0.0.1a0'
    assert bump_version('X.Y.Z', 1, 'beta') == '0.0.1b0'

# Generated at 2022-06-29 18:16:08.072290
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'."""
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    from pytest import raises

    from semver import VersionInfo

    class Test(TestCase):
        def test_non_strings(self):
            with raises(ValueError):
                bump_version(0)
            with raises(ValueError):
                bump_version(0.0)
            with raises(ValueError):
                bump_version(None)
            with raises(ValueError):
                bump_version(b'0.0')
            with raises(ValueError):
                bump_version(VersionInfo(0, 0, 0))

        def test_invalid_version(self):
            with raises(ValueError):
                bump_version('0.0')
            with raises(ValueError):
                bump_version