

# Generated at 2022-06-29 18:06:48.050856
# Unit test for function bump_version

# Generated at 2022-06-29 18:06:57.215541
# Unit test for function bump_version
def test_bump_version():
    version, position, label = '1.2.0', 2, None
    assert bump_version(version) == '1.2.1'
    assert bump_version(version, 1) == '1.3'
    assert bump_version(version, 1, 'alpha') == '1.3a0'
    assert bump_version('1.2.1', 2, 'alpha') == '1.2.2a0'
    assert bump_version('1.2.1a1', 2, 'alpha') == '1.2.1a2'
    assert bump_version('1.2.0a1', 2, 'beta') == '1.2.1b0'
    assert bump_version('1.2.1a0', 2, 'beta') == '1.2.1b1'

# Generated at 2022-06-29 18:07:08.776026
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.23.4', position=0) == '2.0.0'
    assert bump_version('1.23.4', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version('1.23.4', position=-1) == '1.23.5'
    assert bump_version('1.23.4', position=-1, pre_release='beta') == '1.23.5b0'
    assert bump_version('1.23.4', position=-2) == '1.24.0'
    assert bump_version('1.23.4', position=-2, pre_release='alpha') == '1.24.0a0'

# Generated at 2022-06-29 18:07:13.448316
# Unit test for function bump_version
def test_bump_version():
    # noinspection SpellCheckingInspection
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('0.1') == '0.1.1'
    assert bump_version('0.1', position=2) == '0.1.1'
    assert bump_version('0.1.2', position=2) == '0.1.3'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.2') == '1.0.3'
    assert bump_version('1.0.3') == '1.0.4'

# Generated at 2022-06-29 18:07:24.138867
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        '1.0.0', 1, 'alpha'
    ) == '1.0.0a0'
    assert bump_version(
        '1.0.0a0', 1, 'beta'
    ) == '1.0.0b0'
    assert bump_version(
        '1.0.0a0', 1, 'alpha'
    ) == '1.0.0a1'
    assert bump_version(
        '1.0.0b0', 1, 'beta'
    ) == '1.0.0b1'
    assert bump_version(
        '1.0.0b1', 1, 'alpha'
    ) == '1.1.0a0'

# Generated at 2022-06-29 18:07:35.270975
# Unit test for function bump_version
def test_bump_version():
    version = '1.0.0'
    assert bump_version(version) == '1.0.1'
    version = '1.0.0'
    assert bump_version(version, position=-1) == '1.1.0'
    version = '1.0.0'
    assert bump_version(version, position=-2) == '2.0.0'
    version = '1.0.0'
    assert bump_version(version, position=-3) == '1.0.0'
    version = '1.0.0'
    assert bump_version(version, position=-4) == '1.0.0'
    version = '1.0.0'
    assert bump_version(version, position=0) == '2.0.0'
    version = '1.0.0'


# Generated at 2022-06-29 18:07:47.080432
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.0') == '0.1.0'
    assert bump_version('1.2.3') == '1.2.3'

    assert bump_version('1.2.0b2') == '1.2.0b3'
    assert bump_version('1.2.0b0') == '1.2.0b1'
    assert bump_version('1.2.0a3') == '1.2.0a4'
    assert bump_version('1.2.0a0') == '1.2.0a1'

    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2') == '1.2'

# Generated at 2022-06-29 18:07:55.532704
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0b0') == '1.0.1b0'
    assert bump_version('1.0.1b0') == '1.0.2b0'
    assert bump_version('1.0.0a0') == '1.0.1a0'
    assert bump_version('1.0.1a0') == '1.0.2a0'
    assert bump_version('1.0.0b1') == '1.0.1b1'
    assert bump_version('1.0.1b1') == '1.0.2b1'

# Generated at 2022-06-29 18:08:08.782424
# Unit test for function bump_version
def test_bump_version():
    # Test simple integers
    version1 = '0.0.0'
    version2 = bump_version(version1)
    assert version2 == '0.0.1'

    version1 = '0.0.0'
    version2 = bump_version(version1, position=0)
    assert version2 == '1.0.0'

    version1 = '0.0.0'
    version2 = bump_version(version1, position=1)
    assert version2 == '0.1.0'

    version1 = '0.0.0'
    version2 = bump_version(version1, position=-1)
    assert version2 == '0.0.1'

    version1 = '0.0.0'
    version2 = bump_version(version1, position=-2)

# Generated at 2022-06-29 18:08:18.505714
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.1.0') == '0.2.0'
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', position=1) == '0.2.0'
    assert bump_version('0.1.2', position=0) == '1.0.0'
    assert bump_version('0.1.2', position=-1) == '0.1.3'
    assert bump_version('0.1.2', position=-2) == '0.2.0'
    assert bump_version('0.1.2', position=-3) == '1.0.0'

# Generated at 2022-06-29 18:08:35.918120
# Unit test for function bump_version
def test_bump_version():
    def _test1(in_, pos, pre, out):
        assert bump_version(in_, pos, pre) == out

    _test1('1.0', -1, None, '1.0.1')
    _test1('1.0.2', -1, None, '1.0.3')
    _test1('1.0.2', -2, None, '1.1.0')
    _test1('1.0.2', -3, None, '2.0.0')
    _test1('1.0', -1, 'a', '1.0.1a0')
    _test1('1.0.2', -1, 'a', '1.0.3a0')

# Generated at 2022-06-29 18:08:47.834260
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.0', pre_release='alpha') == '0.0.1a0'
    assert bump_version('0.0.0', position=0) == '1.0.0'
    assert bump_version('0.0.0', position=0, pre_release='beta') == '1.0.0b0'
    assert bump_version('0.0.0', position=1) == '0.1.0'
    assert bump_version('0.0.0', position=1, pre_release='alpha') == '0.1.0a0'
    assert bump_version('0.0.0', position=1, pre_release='beta') == '0.1.0b0'


# Generated at 2022-06-29 18:08:56.694867
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:08.142505
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.1.1') == '3.1.2'
    assert bump_version('3.1.1', 1) == '3.2'
    assert bump_version('3.1.1', 1, 'a') == '3.2a0'
    assert bump_version('3.1.1', 1, 'b') == '3.2b0'
    assert bump_version('3.1.1', -1) == '3.1.2'
    assert bump_version('3.1.1', -2) == '3.2'
    assert bump_version('3.1.1', -2, 'a') == '3.2a0'
    assert bump_version('3.1.1', -2, 'b') == '3.2b0'
    assert bump_version

# Generated at 2022-06-29 18:09:20.216175
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2.3', 0) == '2'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3'
    assert bump_version('1.2.3', -3) == '2'

    assert bump_version('1.2.3') == bump_version('1.2.3', 1)
    assert bump_version('1.2.3', 1) == bump_version('1.2.3', -2)
    assert bump_version('1.2.3', -1) == bump

# Generated at 2022-06-29 18:09:33.095671
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', position=-2) == '1.1.0'
    assert bump_version('1.0.0', position=-3) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=3) == '1.0.1'

    assert bump

# Generated at 2022-06-29 18:09:43.970961
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.3.0'
    assert bump_version('1.2.3', -2) == '2.0.0'
    assert bump_version('1.2.3', -3) == '1.2.4'

    assert bump_version('1.2.0', 1) == '1.3.0'

# Generated at 2022-06-29 18:09:56.620938
# Unit test for function bump_version
def test_bump_version():
    # Example case 1
    version = "1.0.0"
    position = 0
    pre_release = None
    result = bump_version(version, position, pre_release)
    assert result == '2.0.0'

    # Example case 2
    version = "1.0.0"
    position = 0
    pre_release = "b"
    result = bump_version(version, position, pre_release)
    assert result == '2.0.0'

    # Example case 3
    version = "1.0.0"
    position = 1
    pre_release = "b"
    result = bump_version(version, position, pre_release)
    assert result == '1.1.0'

    # Example case 4
    version = "1.0.0"
    position = 1
    pre

# Generated at 2022-06-29 18:10:07.143580
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.2') == '0.0.3'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.2.1') == '0.3.0'
    assert bump_version('0.2.0') == '0.3.0'
    assert bump_version('1.2.0') == '1.3.0'
    assert bump_version('1.2.0', pre_release='a') == '1.2.1a0'
    assert bump_version('1.2.0', pre_release='b') == '1.2.1b0'
    assert bump_version('1.2.0b1', pre_release='b') == '1.2.0b2'
    assert bump_version

# Generated at 2022-06-29 18:10:19.542825
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')
    for v in [
            '0.0.0', '1.0.0', '1.0.0a0', '1.0.0b0', '1.0.0a0',
            '1.0.0a1', '1.0.0a2', '1.0.0b1', '1.0.0b2',
            '1.0.1', '1.0.2', '1.1.0', '1.2.0', '2.0.0']:
        print('Testing bump_version (%s)' % v)
        print('Bumping major')
        v1 = bump_version(v, -3)
        print('Result: %s' % v1)
        print('Bumping minor')

# Generated at 2022-06-29 18:10:30.543216
# Unit test for function bump_version
def test_bump_version():
    # Testing bump_version
    assert bump_version('1.2.4') == '1.2.5'
    assert bump_version('1.2.4', 2, 'alpha') == '1.2.4a0'
    assert bump_version('1.2.4', 2, 'a') == '1.2.4a0'
    assert bump_version('1.2.4', 2, 'beta') == '1.2.4b0'
    assert bump_version('1.2.4', 2, 'b') == '1.2.4b0'
    assert bump_version('1.2.4a0') == '1.2.4a1'
    assert bump_version('1.2.4a1') == '1.2.4a2'

# Generated at 2022-06-29 18:10:40.597139
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    print(bump_version('0.0.1'))
    print(bump_version('0.0.1', position=1))
    print(bump_version('0.0.1', position=0))
    print(bump_version('0.0.1', position=1, pre_release='a'))
    print(bump_version('0.0.1', position=1, pre_release='b'))
    print(bump_version('0.0.1', position=2, pre_release='a'))
    print(bump_version('0.0.1', position=2, pre_release='b'))
    print(bump_version('0.0.1a1'))

# Generated at 2022-06-29 18:10:53.694880
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError if any test case fails.
    """
    # Initialize key variables

# Generated at 2022-06-29 18:11:05.717080
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('0.0.0', 0) == '1.0.0'
    assert bump_version('0.0.0', -3) == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('2.0.0') == '3.0.0'
    assert bump_version('0.0.0', 1) == '0.1.0'
    assert bump_version('0.0.0', -2) == '0.1.0'
    assert bump_version('0.1.0') == '0.2.0'

# Generated at 2022-06-29 18:11:18.737020
# Unit test for function bump_version
def test_bump_version():
    out = bump_version('1.2.3')
    expect = '1.2.4'
    assert out == expect

    out = bump_version('1.0.0')
    expect = '2.0.0'
    assert out == expect

    out = bump_version('10.0.0', position=0)
    expect = '11.0.0'
    assert out == expect

    out = bump_version('10.0.0', position=-3)
    expect = '11.0.0'
    assert out == expect

    out = bump_version('1.0.0', position=-2)
    expect = '1.1.0'
    assert out == expect

    out = bump_version('1.0.0', position=-2, pre_release='b')

# Generated at 2022-06-29 18:11:31.293202
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:43.180480
# Unit test for function bump_version
def test_bump_version():

	# Tests for 1.0.0-beta.2
	#Version 1.0.0-beta.2 plus a minor pre-release bump should yield 1.0.0-beta.3
	assert bump_version("1.0.0-beta.2") == "1.0.0-beta.3", "bump_version failed"
	#Version 1.0.0-beta.2 plus a major bump should yield 2.0.0
	assert bump_version("1.0.0-beta.2", 0) == "2.0.0", "bump_version failed"
	#Version 1.0.0-beta.2 plus a minor bump should yield 1.1.0
	assert bump_version("1.0.0-beta.2", 1) == "1.1.0", "bump_version failed"
	#

# Generated at 2022-06-29 18:11:51.993071
# Unit test for function bump_version
def test_bump_version():
    input = '0.0.1'
    output = '0.0.2'
    assert bump_version(input) == output

    input = '1.0.0'
    output = '2.0.0'
    assert bump_version(input) == output

    input = '1.0.0'
    output = '2.0.0'
    assert bump_version(input, 0) == output

    input = '1.0.0'
    output = '1.1.0'
    assert bump_version(input, 1) == output

    input = '1.0.0'
    output = '1.1.0'
    assert bump_version(input, 1) == output

    input = '1.0.0'
    output = '1.1.0'

# Generated at 2022-06-29 18:12:04.756927
# Unit test for function bump_version
def test_bump_version():
    # Simple test
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1, 'a') == '1.0a0'
    assert bump_version('1.0.0', 1, 'b') == '1.0b0'
    assert bump_version('1.0.0', 1, 'beta') == '1.0b0'
    assert bump_version('1.0.0', 1, 'alpha') == '1.0a0'
    assert bump_version('1.0.0', 1, 'A') == '1.0a0'
    assert bump_version('1.0.0', 1, 'B') == '1.0b0'

    # Pre-release bumping

# Generated at 2022-06-29 18:12:17.589355
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function 'bump_version'.

    Returns
    -------
    None
    """
    from os.path import abspath, dirname, join, pardir

    from mh_utils.version import bump_version

    version_path = abspath(join(dirname(__file__), pardir, 'version.py'))
    print(version_path)

    print('initial version: {}'.format(bump_version('0.0.0')))  # -> '0.0.1'

    print('\npre-release bump')
    print('initial version: {}'.format(bump_version('1.0.0')))  # -> '1.0.0a0'
    print('initial version: {}'.format(bump_version('1.1.0')))  # -> '1.1.

# Generated at 2022-06-29 18:12:29.618893
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.1.0') == '2.0.0'
    assert bump_version('1.1.1') == '2.0.0'
    assert bump_version('1.2.0') == '2.0.0'
    assert bump_version('1.2.1') == '2.0.0'
    assert bump_version('1.2.0a0') == '2.0.0'
    assert bump_version('1.2.1a0') == '2.0.0'
    assert bump_version('1.2.0a1') == '2.0.0'
    assert bump_

# Generated at 2022-06-29 18:12:42.278818
# Unit test for function bump_version
def test_bump_version():
    ver_str = '1.0.0'
    new_ver = bump_version(ver_str)
    assert new_ver == '1.0.1'

    new_ver = bump_version(ver_str, 0)
    assert new_ver == '2.0.0'

    new_ver = bump_version(ver_str, 1)
    assert new_ver == '1.1.0'

    new_ver = bump_version(ver_str, 1, 'alpha')
    assert new_ver == '1.1a0'

    new_ver = bump_version(ver_str, 1, 'Alpha')
    assert new_ver == '1.1a0'

    new_ver = bump_version(ver_str, 1, 'b')
    assert new_ver == '1.1b0'

# Generated at 2022-06-29 18:12:53.835594
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.4.4') == '0.4.5'
    assert bump_version('0.4.4beta') == '0.4.5'
    assert bump_version('0.4.4a0') == '0.4.4a1'
    assert bump_version('0.4.4a1') == '0.4.4a2'
    assert bump_version('0.4.4b0') == '0.4.4b1'
    assert bump_version('0.4.4b9') == '0.4.4b10'
    assert bump_version('0.4.4b', pre_release='a') == '0.4.4b0a0'
    assert bump_version('0.4.4', position=1) == '0.5'
   

# Generated at 2022-06-29 18:13:02.952232
# Unit test for function bump_version
def test_bump_version():
    ver = '3.1.0a1'
    print(ver, '->', bump_version(ver, 0))
    print(ver, '->', bump_version(ver, 1))
    print(ver, '->', bump_version(ver, 2))
    print(ver, '->', bump_version(ver, 3))
    print(ver, '->', bump_version(ver, 4))
    print(ver, '->', bump_version(ver, 5))
    print(ver, '->', bump_version(ver, 6))
    print()

    ver = '2.2.0b1'
    print(ver, '->', bump_version(ver, 0))
    print(ver, '->', bump_version(ver, 1))
    print(ver, '->', bump_version(ver, 2))

# Generated at 2022-06-29 18:13:15.643528
# Unit test for function bump_version
def test_bump_version():
    v1 = bump_version('1.2.3')
    assert v1 == '1.2.4'
    v2 = bump_version('1.2.3', -1)
    assert v2 == '1.2.4'
    v3 = bump_version('1.2.3', -2)
    assert v3 == '1.3.0'
    v4 = bump_version('1.2.3', -3)
    assert v4 == '2.0.0'
    v5 = bump_version('1.2.3', 1)
    assert v5 == '1.3.0'
    v6 = bump_version('1.2.3', 0)
    assert v6 == '2.0.0'

# Generated at 2022-06-29 18:13:23.595905
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0.0'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=-2) == '1.3.0'
    assert bump_version('1.2.3', position=-3) == '2.0.0'
    assert bump_version('1.2.3', pre_release='alpha') == '1.2.4a0'

# Generated at 2022-06-29 18:13:36.664635
# Unit test for function bump_version
def test_bump_version():
    # Test bumping major
    assert bump_version('0.0') == '1.0'  # Test no pre-release
    assert bump_version('1.0.0') == '2.0.0'  # Test no pre-release
    assert bump_version('1.2') == '2.0'  # Test no pre-release
    assert bump_version('1.2.0', position=0) == '2.0.0'  # Test no pre-release

    assert bump_version('1.0.0-a.0') == '2.0.0'  # Test pre-release alpha
    assert bump_version('1.2.3-b.4') == '2.0.0'  # Test pre-release beta
    assert bump_version('1.2.3-b.4', position=0)

# Generated at 2022-06-29 18:13:46.504743
# Unit test for function bump_version

# Generated at 2022-06-29 18:13:59.750821
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3a1')
    assert version == '1.2.3a2'
    version = bump_version('1.2.3a10')
    assert version == '1.2.3a11'
    version = bump_version('1.2.3b1')
    assert version == '1.2.3b2'
    version = bump_version('1.2.3b10')
    assert version == '1.2.3b11'
    version = bump_version('1.2.3', 1, '')
    assert version == '1.2.4'
    version = bump_version('1.2.3', 1)

# Generated at 2022-06-29 18:14:09.992487
# Unit test for function bump_version
def test_bump_version():
    assert bump_version(
        version='0.0.0',
        position=2,
        pre_release=None
    ) == '0.0.1'

    assert bump_version(
        version='0.0.1',
        position=2,
        pre_release=None
    ) == '0.0.2'

    assert bump_version(
        version='0.0.1',
        position=1,
        pre_release=None
    ) == '0.1.0'

    assert bump_version(
        version='0.1.0',
        position=1,
        pre_release=None
    ) == '0.2.0'


# Generated at 2022-06-29 18:14:31.135659
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 0, 'alpha') == '2.0.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0a0'
    assert bump_version('1.2.3', 2, 'alpha') == '1.2.4a0'
    assert bump_version('1.2.3a1') == '1.2.3a2'
    assert bump_version('1.2.3a2', 0) == '2.0.0'


# Generated at 2022-06-29 18:14:42.907148
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('2.2.2', 1, '') == '2.3.0'
    assert bump_version('3.3.3', 1, 'a') == '3.4.0'
    assert bump_version('4.4.4', 1, 'b') == '4.4.0b0'
    assert bump_version('5.5.5', 1, 'A') == '5.6.0a0'
    assert bump_version('5.5.5', 1, 'b') == '5.5.0b0'
    assert bump_version('5.5.5', 1, 'B') == '5.6.0b0'

# Generated at 2022-06-29 18:14:49.830128
# Unit test for function bump_version
def test_bump_version():
    # Test 1
    version = "0.9.9a0"
    position = 2
    pre_release = "a"
    assert(bump_version(version, position, pre_release) == "1.0.0")
    # Test 2
    version = "0.9.9a0"
    position = 2
    pre_release = None
    assert(bump_version(version, position, pre_release) == "0.10.0")
    # Test 3
    version = "0.9.9a0"
    position = 1
    pre_release = "b"
    assert(bump_version(version, position, pre_release) == "0.10.0")
    # Test 4
    version = "0.9.9"
    position = -2
    pre_release = "b"

# Generated at 2022-06-29 18:15:01.792957
# Unit test for function bump_version

# Generated at 2022-06-29 18:15:10.235998
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.0.0") == "1.0.1"
    assert bump_version("1.2.4") == "1.2.5"
    assert bump_version("1.0.0",0) == "2.0.0"
    assert bump_version("1.2.4",0) == "2.0.0"
    assert bump_version("1.2.4",1) == "1.3.0"
    assert bump_version("1.2.4",2) == "1.2.5"
    assert bump_version("1.2.4",-1) == "1.2.5"
    assert bump_version("1.2.4",-2) == "1.3.0"

# Generated at 2022-06-29 18:15:22.574205
# Unit test for function bump_version
def test_bump_version():
    # Test: bump_version(version, position, pre_release)
    assert bump_version('1.2') == '2.0'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1.2', 2) == '1.2.1'
    assert bump_version('1.2', 3) == '2.0'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2', 0) == '2.0'
    assert bump_version('1.2', 0, 'a') == '2.0'
    assert bump_version('1.2.0', 0) == '2.0'
    assert bump_version('1.2.0', 0, 'a') == '2.0'

# Generated at 2022-06-29 18:15:31.975574
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'
    assert bump_version('0.0.1', 2) == '0.0.2'
    assert bump_version('0.0.1', -1) == '0.0.2'
    assert bump_version('0.0.1', -2) == '0.1.0'
    assert bump_version('0.0.1', -3) == '1.0.0'
    assert bump_version('0.1.0') == '0.1.1'

# Generated at 2022-06-29 18:15:44.474477
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2') == '1.3'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1.2', 1) == bump_version('1.2.0')
    assert bump_version('1.2.0') == '1.3'
    assert bump_version('1.2.0', 1) == '1.3'
    assert bump_version('1.2.0', 1) == bump_version('1.2.0')
    assert bump_version('1.2.0', 1) == bump_version('1.2')
    assert bump_version('1.2.0', 1) == bump_version('1.2.0', 1)

# Generated at 2022-06-29 18:15:54.740680
# Unit test for function bump_version
def test_bump_version():
    # Major
    assert bump_version('1.2.3') == '2.0.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', -3) == '2.0.0'
    assert bump_version('1.2.3-alpha2') == '2.0.0'

    # Minor
    assert bump_version('1.2.3') == '1.3.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3-alpha1') == '1.3.0'

# Generated at 2022-06-29 18:15:57.956559
# Unit test for function bump_version
def test_bump_version():
    version = "0.15.0b4"
    position = 2
    pre_release = "b"
    out = bump_version(version=version, position=position, pre_release=pre_release)
    assert out == "0.15.0b5"


if __name__ == "__main__":
    test_bump_version()