

# Generated at 2022-06-29 18:06:46.758128
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2') == '0.3'
    assert bump_version('0.3') == '0.4'
    assert bump_version('0.3.0') == '0.3.1'
    assert bump_version('0.3.1') == '0.3.2'
    assert bump_version('0.3.0b2') == '0.3.1'
    assert bump_version('0.3.1b2') == '0.3.2'
    assert bump_version('0.3.0a2') == '0.3.1'
    assert bump_version('0.3.1a2') == '0.3.2'
    assert bump_version('0.3.0a2', 0) == '1.0.0'

# Generated at 2022-06-29 18:06:54.061023
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version"""

    def _test_value(
            case_num: int,
            given_version: str,
            given_position: int,
            given_pre_release: Optional[str],
            exp_version: str,
    ) -> None:
        msg = (
            'Case %s: Given version: "%s", Given position: %s, '
            'Given pre_release: %s, Expected version: "%s", '
            'Actual version: "%s"' % (
                case_num, given_version, given_position,
                given_pre_release, exp_version, actual_version
            )
        )
        assert exp_version == actual_version, msg


# Generated at 2022-06-29 18:07:04.879987
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:16.383871
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""
    assert bump_version('1.0.0', pre_release='a') == '1.0.0a0'
    assert bump_version('1.0.0a2', pre_release='a') == '1.0.0a3'
    assert bump_version('1.0.0a2', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0b2', pre_release='b') == '1.0.0b3'
    assert bump_version('1.2.0', pre_release='a') == '1.2.0a0'
    assert bump_version('1.2.0a2', pre_release='a') == '1.2.0a3'

# Generated at 2022-06-29 18:07:25.967100
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

    assert bump_version('1.2.0') == '1.2.1'

# Generated at 2022-06-29 18:07:27.830276
# Unit test for function bump_version
def test_bump_version():
    from .unittest_data import bump_version_tests
    bump_version_tests()

# Generated at 2022-06-29 18:07:39.553123
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('0.0.0') == '1.0'
    assert bump_version('1.0.0') == '2.0'
    assert bump_version('1.0.0', position=1) == '1.1'
    assert bump_version('1.0.0', position=2) == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0'
    assert bump_version('1.0.0', position=-3) == '2.0'
    assert bump_version('1.0.0', position=-2) == '1.1'
    assert bump_version('1.0.0', position=-1) == '1.0.1'

# Generated at 2022-06-29 18:07:50.876245
# Unit test for function bump_version
def test_bump_version():
    """
    Run unittest on bump_version function

    Required to run as a pytest
    """
    import pytest
    version = '0.0.0'
    position = 0
    pre_release = 'b'
    assert (bump_version(version, position, pre_release) ==
            '0.0.0b0')
    version = '1.2.3'
    position = 0
    pre_release = 'b'
    assert (bump_version(version, position, pre_release) ==
            '2.0.0b0')
    version = '1.2.3'
    position = 1
    pre_release = 'b'
    assert (bump_version(version, position, pre_release) ==
            '1.3.0b0')

# Generated at 2022-06-29 18:07:53.459970
# Unit test for function bump_version
def test_bump_version():
    version = '0.2.0'
    position = 2
    pre_release = None
    out = '0.2.1'
    assert(bump_version(version, position, pre_release) == out)



# Generated at 2022-06-29 18:08:05.992703
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 0) == '1.0.0'
    assert bump_version('0.1.2', 1, 'alpha') == '0.2.0a0'
    assert bump_version('0.1.2', 2, 'alpha') == '0.1.3a0'
    assert bump_version('0.1.2', 2, 'beta') == '0.1.3b0'
    assert bump_version('0.1.2a0') == '0.1.2a1'

# Generated at 2022-06-29 18:08:29.719577
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3b0', pre_release='b') == '1.2.3b1'
    assert bump_version('1.2.3b0', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', 1, pre_release='b') == '1.3.0b0'

    # Tests for type checking

# Generated at 2022-06-29 18:08:37.913710
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    func_name = 'bump_version'

    # Given

# Generated at 2022-06-29 18:08:50.489455
# Unit test for function bump_version
def test_bump_version():
    # Testing bump_version
    assert bump_version('1.0.0', position=1) == '1.1.0'

    # Testing bad position values
    try:
        bump_version('1.0.0', position=3)
    except ValueError:
        pass

    # Testing bad pre_release values
    try:
        bump_version('1.0.0', pre_release='z')
    except ValueError:
        pass

    # Testing pre_release bumping
    assert bump_version('1.0.0', position=1, pre_release='alpha') == '1.0.0a0'
    assert bump_version('1.0.0', position=1, pre_release='beta') == '1.0.0b0'

# Generated at 2022-06-29 18:08:57.869026
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    def test(
            given_version: Optional[str],
            given_position: Optional[int],
            given_pre_release: Optional[str],
            expected_version: str,
    ) -> None:
        bumped_version = bump_version(
            given_version,
            position=given_position,
            pre_release=given_pre_release
        )

# Generated at 2022-06-29 18:09:10.695693
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from colorama import Fore, Style
    import re
    import sys

    argv = sys.argv

    if len(argv) == 2:
        version = argv[1]
    else:
        version = ''
    if version:
        title = "Testing bump_version with version: {!r}".format(version)
    else:
        title = "Testing bump_version"
    print()
    print(title)
    print("=" * len(title))

    # noinspection SpellCheckingInspection

# Generated at 2022-06-29 18:09:15.486468
# Unit test for function bump_version

# Generated at 2022-06-29 18:09:23.082766
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')
    assert '0.2.2' == bump_version(
        '0.2.1', 1, None
    ), 'No pre-release, minor position, minor part'
    assert '0.2.1' == bump_version(
        '0.2.0', 1, None
    ), 'No pre-release, minor position, patch part'
    assert '0.3.0a0' == bump_version(
        '0.2.0', 1, 'a'
    ), 'Alpha pre-release, minor position, patch part'
    assert '0.3.0b0' == bump_version(
        '0.2.0', 1, 'b'
    ), 'Beta pre-release, minor position, patch part'

# Generated at 2022-06-29 18:09:36.201724
# Unit test for function bump_version
def test_bump_version():
    import textwrap
    from io import StringIO

    from more_itertools import collapse


# Generated at 2022-06-29 18:09:42.768731
# Unit test for function bump_version
def test_bump_version():  # IGNORE:C01103
    def _assert_bump_version(
            version: Union[str, int],
            position: int,
            pre_release: Optional[str],
            expect: str
    ) -> None:
        actual = bump_version(version, position, pre_release)
        assert(actual == expect)

    _assert_bump_version('0.0.1', 0, None, '1.0.0')
    _assert_bump_version('1.0.1', 1, None, '1.1.0')
    _assert_bump_version('1.1.1', 2, None, '1.1.2')
    _assert_bump_version('1.1.1', -1, None, '1.1.2')

# Generated at 2022-06-29 18:09:55.936313
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for the bump_version() function."""
    from os import devnull
    from sys import stderr, stdout
    from pprint import PrettyPrinter
    from tempfile import TemporaryDirectory
    from zipfile import ZipFile

    from cookiecutter.exceptions import FailedHookException
    from cookiecutter.main import cookiecutter

    def _make_tests(
            tests: List[Tuple[str, str, str, Union[str, None]]],
    ) -> None:
        pprint = PrettyPrinter(indent=4, compact=True)
        for test in tests:
            # noinspection PyTypeChecker
            ver_input, ver_output, pos_input, pre_input = test

# Generated at 2022-06-29 18:10:09.184664
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0141
    # pylint: disable=C0103
    # Function: bump_version tests
    v = '1.0.15'
    o = '1.0.16'
    x = bump_version(v)
    print(x)
    assert x == o
    v = '2.0.3'
    o = '2.0.3a0'
    x = bump_version(v, pre_release='a')
    print(x)
    assert x == o
    v = '2.0.3a0'
    o = '2.0.3a1'
    x = bump_version(v, pre_release='a')
    print(x)
    assert x == o
    v = '2.1.4a7'

# Generated at 2022-06-29 18:10:22.118198
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.0.0')
    assert version == '1.0.1'
    version = bump_version('1.0.0', 1)
    assert version == '1.1.0'
    version = bump_version('1.0.0', 0)
    assert version == '2.0.0'

    version = bump_version('1.0.0', position=1, pre_release='beta')
    assert version == '1.1b0'

    version = bump_version('1.2b0', position=1, pre_release='beta')
    assert version == '1.2b1'
    version = bump_version('1.2b0', position=1, pre_release='alpha')
    assert version == '1.3a0'


# Generated at 2022-06-29 18:10:28.770615
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyStatementEffect
    """
    >>> test_bump_version() # doctest: +ELLIPSIS
    ... # doctest: +NORMALIZE_WHITESPACE
    Testing function bump_version():
        ...
        Testing version, '1.2.3a0' on the 'minor' part:
            ...
            OK
        Testing version, '1.2.3a0' on the 'minor' part with 'pre_release' ==
        'alpha':
            ...
            OK
        Testing version, '1.2.3a0' on the 'minor' part with 'pre_release' ==
        'beta':
            ...
            OK
        ...
        OK
    """

# Generated at 2022-06-29 18:10:39.423148
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('3.4.1') == '3.4.2'
    assert bump_version('3.4.1.a1') == '3.4.1.a2'
    assert bump_version('3.4.1.b1') == '3.4.1.b2'
    assert bump_version('3.4.1', 1) == '3.5.0'
    assert bump_version('3.4.1', 1, 'a') == '3.5.0'
    assert bump_version('3.4.1', 1, 'b') == '3.5.0'
    assert bump_version('3.4.0', 1, 'a') == '3.5.0'

# Generated at 2022-06-29 18:10:52.964511
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.1.1') == '0.1.2'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', 1) == '1.2.0'
    assert bump_version('1.1.1', 0) == '2.0.0'
    assert bump_version('1.1.1', 0, pre_release='a') == '2.0.0'
    assert bump_version('1.1.1', 1, pre_release='a') == '1.2.0a0'
    assert bump_version('1.1.1', 1, pre_release='a') == '1.2.0a0'

# Generated at 2022-06-29 18:11:05.059140
# Unit test for function bump_version
def test_bump_version():
    """Test the "bump_version" function."""

# Generated at 2022-06-29 18:11:17.323793
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:29.507428
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -1, 'a') == '1.2.4a0'
    assert bump_version('1.2.3', 1, 'a') == '1.3a0'
    assert bump_version('1.2.3', 1, 'b') == '1.3b0'

# Generated at 2022-06-29 18:11:41.797224
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version()"""
    def _test_bump(old_ver, new_ver, pos, pre=None, should_succeed=True):
        if should_succeed:
            assert bump_version(old_ver, pos, pre) == new_ver
        else:
            try:
                bump_version(old_ver, pos, pre)
            except ValueError:
                pass
            else:
                assert False, 'should have failed.'

    _test_bump('0.0.1', '0.0.2', 2)
    _test_bump('1.0.0', '1.0.1', 2)
    _test_bump('1.0.0a1', '1.0.0a2', 2)

# Generated at 2022-06-29 18:11:51.052445
# Unit test for function bump_version
def test_bump_version():
    from os.path import abspath, dirname, join
    from sys import path
    this_path = abspath(dirname(__file__))
    path.insert(0, this_path)
    from tests.test_build_version_info import test_build_version_info
    from tests.test_each_version_part import test_each_version_part
    from tests.test_version_part import test_version_part
    test_version_part()
    test_each_version_part()
    test_build_version_info()
    version = '0.0.1'
    print('Bump %r minor' % version)
    print('Result: %r' % bump_version(version, 1))
    print('Bump %r minor alpha' % version)

# Generated at 2022-06-29 18:12:01.416782
# Unit test for function bump_version
def test_bump_version():
    # Setup
    version = '1.0.0'
    position = 2
    pre_release = None

    expected_output = '1.1.0'

    # Exercise
    output = bump_version(version, position, pre_release)

    # Verify
    assert output == expected_output, \
        'Expected {} but got {} instead'.format(expected_output, output)

    # Cleanup - none necessary



# Generated at 2022-06-29 18:12:13.895766
# Unit test for function bump_version

# Generated at 2022-06-29 18:12:24.378908
# Unit test for function bump_version
def test_bump_version():
    fmt = '\nVersion: (%s)\nPosition: (%s)\nPre-release: (%s)'
    version = '0.2.6'
    position = 2
    pre_release = None
    print(fmt % (version, position, pre_release))
    print('Result: [%s]' % bump_version(
        version=version,
        position=position,
        pre_release=pre_release
    ))

    version = '0.2.6'
    position = 2
    pre_release = 'a'
    print(fmt % (version, position, pre_release))
    print('Result: [%s]' % bump_version(
        version=version,
        position=position,
        pre_release=pre_release
    ))

    version = '0.2.6'
    position = 2

# Generated at 2022-06-29 18:12:36.093984
# Unit test for function bump_version
def test_bump_version():
    import os
    import unittest


# Generated at 2022-06-29 18:12:48.184183
# Unit test for function bump_version
def test_bump_version():
    """Unit tests."""
    # noinspection PyUnusedLocal
    tester = _build_version_info
    # noinspection PyUnusedLocal
    tester = _build_version_bump_position

    # Exception for invalid version number
    try:
        bump_version('invalid version')
    except ValueError:
        pass

    # Exception for invalid position number
    try:
        bump_version('1.0.0', 4)
    except ValueError:
        pass

    # Exception for bumping major part
    try:
        bump_version('0.0.0', 'a')
    except ValueError:
        pass

    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', 1) == '1.1.0'


# Generated at 2022-06-29 18:12:59.418129
# Unit test for function bump_version
def test_bump_version():
    v = bump_version("1.0.0")
    assert v == "1.0.1"

    v = bump_version("100.100.100")
    assert v == "100.100.101"

    v = bump_version("1.0.0", position=0)
    assert v == "2.0.0"

    v = bump_version("1.0.0", position=1)
    assert v == "1.1.0"

    v = bump_version("1.0.0+build")
    assert v == "1.0.1"

    v = bump_version("1.0.0+build", position=1)
    assert v == "1.1.0"

    v = bump_version("1.0.0-alpha")
    assert v == "1.0.1"

# Generated at 2022-06-29 18:13:11.888246
# Unit test for function bump_version
def test_bump_version():
    import sys
    import os
    import inspect
    import doctest
    py_ver = '%d.%d' % (sys.version_info.major, sys.version_info.minor)
    path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    with open(path + '/Test_bump_version_doc.txt') as test_file:
        text = test_file.read()
        doctest.testmod(optionflags = doctest.ELLIPSIS, verbose = False, extraglobs = {'py_ver': py_ver}, name = 'Test_bump_version_doc.txt', report = False, globs = {'bump_version': bump_version})


# Generated at 2022-06-29 18:13:21.160210
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.0', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=1) == '1.1.0'
    assert bump_version('1.0.1', position=1) == '1.1.0'
    assert bump_version('1.0.1', position=0) == '2.0.0'
    assert bump_version('1.0.0', position=-1) == '1.0.1'
    assert bump_version('1.0.0', position=-2) == '1.1.0'

# Generated at 2022-06-29 18:13:33.966724
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    # Miscellaneous tests
    assert bump_version('0.1.2') == '0.1.3'
    assert bump_version('0.1.2', 0) == '1.0.0'
    assert bump_version('0.1.2', 1) == '0.2.0'
    assert bump_version('0.1.2', 2) == '0.1.3'
    assert bump_version('0.1.2', -1) == '0.1.3'
    assert bump_version('0.1.2', -2) == '0.2.0'
    assert bump_version('0.1.2', -3) == '1.0.0'
    assert bump_version('0.1.0') == '0.1.1'


# Generated at 2022-06-29 18:13:44.619480
# Unit test for function bump_version
def test_bump_version():
    # Test good version
    assert bump_version('0.1.0') == '0.1.1'
    assert bump_version('1.2.0') == '1.2.1'

    # Test bad version
    try:
        bump_version('0.1.0.1')
    except ValueError:
        pass

    assert bump_version('1.2.3', 0, 'a') == '2.0.0'
    assert bump_version('1.2.3', 0, 'b') == '2.0.0'

    assert bump_version('1.2.3', 1, 'a') == '1.3.0a0'
    assert bump_version('1.2.3', 1, 'b') == '1.3.0b0'

# Generated at 2022-06-29 18:13:59.504173
# Unit test for function bump_version
def test_bump_version():
    """Returns a tuple of:

        (*bool*, *str*)

    The ``bool`` is the result of the test.  The ``str`` is the error if the
    test fails, otherwise, it is just this function's name.

    """
    from versioning_tool import __version__
    rtn = bump_version(__version__)
    if rtn == '0.4.0':
        return True, rtn
    return False, rtn  # pragma: no branch



# Generated at 2022-06-29 18:14:09.788078
# Unit test for function bump_version
def test_bump_version():
    def _bump_version(
            version: str,
            position: int,
            pre_release: Optional[str]
    ) -> str:
        return bump_version(version, position=position, pre_release=pre_release)

    def _test(
            current: str,
            position: int,
            pre_release: Optional[str],
            next_: str,
    ) -> None:
        out = _bump_version(current, position, pre_release)
        assert out == next_

    _test('0.0.0', position=2, pre_release=None, next_='0.0.1')
    _test('0.0.0', position=1, pre_release=None, next_='0.1.0')

# Generated at 2022-06-29 18:14:16.449819
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'

# Generated at 2022-06-29 18:14:28.371524
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-branches,too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    """Test bump_version()."""
    from sys import version_info

    if version_info < (3, ):
        print('...\ntest_bump_version() only run for Python 3')
        return

# Generated at 2022-06-29 18:14:40.656254
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.1', 1) == '1.2'
    assert bump_version('1.1', 2) == '1.1.1'
    assert bump_version('1.1', 2, 'a') == '1.1.1a'
    assert bump_version('1.1', 2, 'alpha') == '1.1.1a'
    assert bump_version('1.1', 2, 'b') == '1.1.1b'
    assert bump_version('1.1', 2, 'beta') == '1.1.1b'
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_

# Generated at 2022-06-29 18:14:48.637782
# Unit test for function bump_version
def test_bump_version():
    """This function runs the unit test for this function."""
    # 0.0.0
    assert '0.0.1' == bump_version(version='0.0.0', pre_release='a')
    assert '0.0.1a0' == bump_version(version='0.0.0', pre_release='alpha')
    assert '1.0.0' == bump_version(version='0.0.0', position=0)
    assert '0.1.0' == bump_version(version='0.0.0', position=1)
    assert '0.0.1' == bump_version(version='0.0.0', position=2)
    # 0.0.1
    assert '0.0.2' == bump_version(version='0.0.1', pre_release='a')

# Generated at 2022-06-29 18:14:55.980506
# Unit test for function bump_version
def test_bump_version():
    """mantisshrimp.bump_version Unit Test."""

# Generated at 2022-06-29 18:15:07.129994
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 3) == '1.0.0'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'

# Generated at 2022-06-29 18:15:17.503044
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    expected = '1.0.0'
    assert bump_version(version) == expected
    version = '2.4.30'
    expected = '2.4.31'
    assert bump_version(version) == expected
    version = '2.4.30'
    expected = '3.0.0'
    assert bump_version(version, position=0) == expected
    version = '2.4.30'
    expected = '2.5.0'
    assert bump_version(version, position=1) == expected
    version = '2.4.30'
    expected = '2.4.31'
    assert bump_version(version, position=2) == expected
    version = '2.4.30'
    expected = '2.4.31'


# Generated at 2022-06-29 18:15:22.437421
# Unit test for function bump_version
def test_bump_version():
    """Test the :func:`bump_version` function."""

# Generated at 2022-06-29 18:15:46.466247
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    from types import FunctionType
    from xotl.tools.symbols import UNSET
    from xotl.tools.future.functools import lru_cache

    func: FunctionType = bump_version
    cache: lru_cache[str, str] = lru_cache(8)(lambda x: func(x))
    func = cache

# Generated at 2022-06-29 18:15:56.337844
# Unit test for function bump_version
def test_bump_version():
    def _build_bump_version_test(
            version: str, position: int, prerelease: Optional[str] = None
    ) -> _VersionInfo:
        out = _build_version_info(bump_version(version, position, prerelease))
        print(version, position, prerelease, out)
        return out

    # Version 1.2.3
    test1 = _build_bump_version_test('1.2.3', 0)
    assert test1.major.num == 2
    assert test1.minor.num == 0
    assert test1.patch.num == 0

    test1 = _build_bump_version_test('1.2.3', 1)
    assert test1.major.num == 1
    assert test1.minor.num == 3

# Generated at 2022-06-29 18:16:03.119181
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=E0401
    from bump_version.version import __version__

    version = __version__
    assert version == bump_version(version)


# Make the module executable.

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:16:13.015786
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3'
    for pos in range(-3, 3):
        assert bump_version(ver, position=pos) == '1.2.4'
    ver = '1.2.3a0'
    for pos in range(-3, 3):
        assert bump_version(ver, position=pos) == '1.2.4a0'
    ver = '1.2.3a1'
    for pos in range(-3, 2):
        assert bump_version(ver, position=pos) == '1.2.4a1'
    ver = '1.2.3a1'
    for pre in ['', 'a', 'alpha']:
        assert bump_version(ver, position=2, pre_release=pre) == '1.2.4a0'