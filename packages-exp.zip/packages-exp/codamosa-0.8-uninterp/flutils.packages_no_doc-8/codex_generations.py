

# Generated at 2022-06-29 18:06:48.008568
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.10', position=2) == '1.0.11'
    assert bump_version('1.3.10', position=1) == '1.4.0'
    assert bump_version('1.3.10', position=0) == '2.0.0'
    assert bump_version(
        '1.11.10', position=2, pre_release='a'
    ) == '1.11.11a0'
    assert bump_version(
        '1.11.10a0', position=2, pre_release='a'
    ) == '1.11.10a1'

# Generated at 2022-06-29 18:06:57.216178
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    expected = '1.3.0'
    result = bump_version(version, position=1)
    assert result == expected

    version = '1.2.3'
    expected = '2.0.0'
    result = bump_version(version, position=0)
    assert result == expected

    version = '1.2.3'
    expected = '1.2.4'
    result = bump_version(version, position=2)
    assert result == expected

    version = '1.2.0'
    expected = '1.3.0'
    result = bump_version(version, position=1)
    assert result == expected

    version = '1.2.0'
    expected = '1.3.0'

# Generated at 2022-06-29 18:07:08.776051
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0') == '1'
    assert bump_version('0', position=1) == '1.0'
    assert bump_version('0', position=0) == '1'
    assert bump_version('0', position=0, pre_release='alpha') == '1.0'

    assert bump_version('1.2') == '1.2.1'
    assert bump_version('1.2', position=1) == '1.3'
    assert bump_version('1.2', position=0) == '2'
    assert bump_version('1.2', position=0, pre_release='alpha') == '2.0'
    assert bump_version('1.2', position=1, pre_release='alpha') == '1.2a0'


# Generated at 2022-06-29 18:07:13.405478
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:24.138526
# Unit test for function bump_version

# Generated at 2022-06-29 18:07:35.216914
# Unit test for function bump_version
def test_bump_version():
    assert '1.11.0' == bump_version('1.10.0')
    assert '1.11.1' == bump_version('1.11.0')
    assert '1.11.0' == bump_version('1.10.9', 1)
    assert '1.11.0' == bump_version('1.10.9', 2)
    assert '1.11' == bump_version('1.10.0', 2)
    assert '1.11' == bump_version('1.10.0', 1)
    assert '2' == bump_version('1.10.0', 0)
    assert '1.11.0a0' == bump_version('1.10.0a0', 1)

# Generated at 2022-06-29 18:07:47.027862
# Unit test for function bump_version
def test_bump_version():
    def _handle(ver, pos):
        out = bump_version(ver, position=pos)
        print(out)
        return out


# Generated at 2022-06-29 18:07:55.505057
# Unit test for function bump_version

# Generated at 2022-06-29 18:08:08.783178
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.0.0") == '1.0.1'
    assert bump_version("1.0.0", position = 1) == '1.1.0'
    assert bump_version("1.0.0", position = 0) == '2.0.0'
    assert bump_version("1.0.0", position = -1) == '1.0.0'
    assert bump_version("1.0.0", position = -2) == '1.0.1'
    assert bump_version("1.0.0", position = -3) == '1.1.0'
    assert bump_version("1.0.0", position = -4) == '2.0.0'

# Generated at 2022-06-29 18:08:18.505150
# Unit test for function bump_version
def test_bump_version():
    # No problems
    ver = bump_version('1.2.3')
    assert ver == '1.2.4'

    ver = bump_version('1.2.3', position=2)
    assert ver == '1.2.4'

    ver = bump_version('1.2.3', position=0)
    assert ver == '2.0.0'

    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3.0'

    ver = bump_version('1.2.3', position=1, pre_release='a')
    assert ver == '1.3.0a0'

    ver = bump_version('1.2.3', position=1, pre_release='a')
    assert ver == '1.3.0a0'

    ver

# Generated at 2022-06-29 18:08:34.710479
# Unit test for function bump_version
def test_bump_version():
    print('Testing function `bump_version` ...')
    assert bump_version('0.22.0') == '0.22.1', \
        'Version bumping failed for 0.22.0'
    assert bump_version('0.22.0', position=-3) == '0.23.0', \
        'Version bumping failed for 0.22.0'
    assert bump_version('0.22.0', position=-2) == '0.22.1', \
        'Version bumping failed for 0.22.0'
    assert bump_version('0.22.0', position=-1) == '0.22.1', \
        'Version bumping failed for 0.22.0'

# Generated at 2022-06-29 18:08:45.406664
# Unit test for function bump_version
def test_bump_version():
    # Test case: basic
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1') == '1.1.1'
    assert bump_version('1.1.0.dev1') == '1.1.0'
    assert bump_version('1.1.0.dev2') == '1.1.0'
    assert bump_version('1.1.0.dev') == '1.1.0'
    assert bump_version('1.1.dev') == '1.1'

# Generated at 2022-06-29 18:08:55.820610
# Unit test for function bump_version
def test_bump_version():
    # Major version bump
    major_version = bump_version('4.0.0')
    assert major_version == '5.0.0'

    # Minor version bump
    minor_version = bump_version('0.5.6')
    assert minor_version == '0.6.0'

    # Patch version bump
    patch_version = bump_version('0.0.3')
    assert patch_version == '0.0.4'

    # Major version bump with alpha
    major_version_with_alpha = bump_version('4.0.0', 0, 'a')
    assert major_version_with_alpha == '5.0.0'

    # Minor version bump with alpha
    minor_version_with_alpha = bump_version('0.5.6', 1, 'a')
    assert minor_version_with

# Generated at 2022-06-29 18:09:07.129460
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.0', 1) == '1.3.0'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.0', 0) == '2.0.0'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0a0'
    assert bump_version('1.2.0', 1, 'b') == '1.3.0b0'

# Generated at 2022-06-29 18:09:19.564894
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 0, 'alpha') == '2.0.0'
    assert bump_version('1.2.3', -2, 'alpha') == '1.2.4'
    assert bump_version('1.2.3', -2, 'beta') == '1.2.4'
    assert bump_version('1.2.3', 1, 'alpha') == '1.3.0a0'


# Generated at 2022-06-29 18:09:32.660628
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from pprint import pprint

    def test_one(version: str, pos: int, pre_release: Optional[str],
                 expected: str) -> None:
        output = bump_version(version, pos, pre_release)
        print()
        print('-' * 80)
        print('INPUT:')
        pprint(dict(version=version, pos=pos, pre_release=pre_release))
        print()
        print('OUTPUT:')
        pprint(dict(bumped=output, expected=expected))
        print()
        if output != expected:
            raise AssertionError(
                "bump_version(%r, %r, %r) != %r" %
                (version, pos, pre_release, expected)
            )


# Generated at 2022-06-29 18:09:40.112810
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', 2) == '1.2.4'
    assert bump_version('1.2.3', 2, 'a') == '1.2.3a0'
    assert bump_version('1.2.3', 2, 'b') == '1.2.3b0'
    assert bump_version('1.2.3a0') == '1.2.3a1'
    assert bump_version('1.2.3a0', 2, 'a') == '1.2.3a1'
    assert bump_version('1.2.3a0', 2, 'b') == '1.2.3b0'
    assert bump_version('1.2.3b0')

# Generated at 2022-06-29 18:09:50.329680
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0913
    # pylint: disable=R0914
    # pylint: disable=R0915
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', -1) == '1.2.4'
    assert bump_version('1.2.3', -2) == '1.3.0'
    assert bump_version('1.2.3', -3) == '2.0.0'

    assert bump_version('1.2.3', 0) == '2.0.0'
    assert bump_version('1.2.3', 1) == '1.3.0'
    assert bump_version('1.2.3', 2) == '1.2.4'

   

# Generated at 2022-06-29 18:10:02.328610
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:14.373840
# Unit test for function bump_version
def test_bump_version():
    version_list = [
        '1',
        '1.2',
        '1.2.3',
        '1.2.3a4',
        '1.2.3b4',
        '1.2.0a4',
        '1.2.0b4',
    ]
    for version in version_list:
        for position in range(-3, 3):
            for pre_release in (None, 'a', 'alpha', 'b', 'beta'):
                out = bump_version(version, position, pre_release)
                print('{} {} {} -> {}'.format(version, position, pre_release, out))


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-29 18:10:32.269525
# Unit test for function bump_version

# Generated at 2022-06-29 18:10:38.039185
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    from versioning_file import bump_version

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2', 0) == '2.0.0'
    assert bump_version('1.2', 1) == '1.3.0'
    assert bump_version('1.2', 2) == '1.2.3'

    assert bump_version('1.2.3-alpha.0') == '1.2.3-alpha.1'
    assert bump_version('1.2.3-beta.0') == '1.2.3-beta.1'
    assert bump_version('1.2.3-alpha.0', 'alpha') == '1.2.3-alpha.1'

# Generated at 2022-06-29 18:10:44.528383
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.1.1") == "1.1.2"
    assert bump_version("1.1.1", 1, "a") == "1.1a1"
    assert bump_version("1.1.1", 2, "b") == "1.1b0"
    assert bump_version("1.1a1", 1, "b") == "1.1b0"
    assert bump_version("1.1a1", 2, "b") == "1.2b0"
    assert bump_version("1.1b1", 1, "b") == "1.1b2"
    assert bump_version("1.1b1", 2, "b") == "1.2b0"
    assert bump_version("1.1.1", 0) == "2.0.0"

# Generated at 2022-06-29 18:10:56.698129
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.10.0') == '0.11.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.9.9') == '0.10.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('0.10.0', position=0) == '1.0.0'
    assert bump_version('0.10.0', position=-1) == '0.10.1'
    assert bump_version('0.10.0', position=-2) == '0.11.0'
    assert bump_version('0.10.0', position=-3) == '1.0.0'

# Generated at 2022-06-29 18:11:08.030998
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.1a0') == '0.0.1a1'
    assert bump_version('0.0.1b0') == '0.0.1b1'
    assert bump_version('0.0.1a1') == '0.0.1a2'
    assert bump_version('0.0.1b1') == '0.0.1b2'
    assert bump_version('0.0.1', 0) == '1.0.0'
    assert bump_version('0.0.1', 1) == '0.1.0'

# Generated at 2022-06-29 18:11:21.102428
# Unit test for function bump_version

# Generated at 2022-06-29 18:11:34.520513
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0.dev0') == '1.0.0'
    assert bump_version('0.0.0') == '1.0.0'
    assert bump_version('1.0.0') == '2.0.0'
    assert bump_version('1.2.0') == '2.0.0'
    assert bump_version('0.0.1') == '1.0.0'
    assert bump_version('0.0.1', position=0) == '1.0.0'
    assert bump_version('0.0.1', position=1) == '0.1.0'
    assert bump_version('0.0.1', position=2) == '0.0.1'
    assert bump_version('0.0.1', position=3)

# Generated at 2022-06-29 18:11:41.936097
# Unit test for function bump_version
def test_bump_version():
    """
    Test that the function bump_version works as expected.

    """
    # noinspection PyUnusedLocal
    def check_version(
            old_version: str,
            new_version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> bool:
        assert bump_version(old_version, position, pre_release) == new_version

    def check_exception(
            old_version: str,
            position: int = 1,
            pre_release: Optional[str] = 'a'
    ) -> bool:
        try:
            bump_version(old_version, position, pre_release)
        except ValueError:
            pass

# Generated at 2022-06-29 18:11:51.168256
# Unit test for function bump_version
def test_bump_version():
    assert '1.0.0' == bump_version('1.0.0')
    assert '1.1.0' == bump_version('1.0.0', 1)
    assert '2.0.0' == bump_version('1.0.0', 0)
    assert '1.0.1' == bump_version('1.0.0', 2)
    assert '1.0.1' == bump_version('1.0.0', -1)
    assert '1.0.1' == bump_version('1.0.0', pre_release='beta')
    assert '1.1.0' == bump_version('1.0.0', 1, pre_release='beta')
    assert '2.0.0' == bump_version('1.0.0', 0, pre_release='beta')


# Generated at 2022-06-29 18:12:03.950040
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.6.0') == '1.6.1'
    assert bump_version('1.0.0') == '1.1.0'
    assert bump_version('1.0.0a1', pre_release='a') == '1.0.0a2'
    assert bump_version('1.0.0a2', pre_release='b') == '1.0.0b0'
    assert bump_version('1.0.0b1', pre_release='a') == '1.0.0b1'
    assert bump_version('2.0.0') == '2.1.0'
    assert bump_version('2.0.0', position=0) == '3.0.0'