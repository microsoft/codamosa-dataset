This folder contains the source code for two modified versions of our motivating example, since the original example had usage examples in the docstring.

The folder also includes the user-written tests for this function, which are found in a separate file in the project.


Directory structure:
```
  - ../codamosa-0.8-uninterp:
     - flutils.packages: results on original file
     - flutils.packages_no_doc: results on file w/o docstring
     - flutils.packages_no_dstests: results on file w/o docstring
  - packages.csv: the csv necessary to run `run_in_parallel.sh`
  - packages.py: the original
  - packages_no_doc.py: with all docstring removed
  - packages_no_dstests.py: with only the docstring tests removed
  - test_bump_version.py: the original tests from the flutils project
```
