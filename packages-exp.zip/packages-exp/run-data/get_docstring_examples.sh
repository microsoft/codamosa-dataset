#!/bin/bash
# Run this in the directory that contains codamosa-0.8-uninterp folder for the packages ablation

ls  | sed 's/\(-.*\)//' | grep flutils | uniq | while read module; do echo $module; echo 'docstring-ex-occs,alpha-occs,test-defs,final-cov';  for i in {1..15}; do dir=${module}-$i; tests_with_docstring_eg=$(cat $dir/codex_generations.py | grep -c "bump_version('1.2.2') == '1.2.3'"); bump_version_tests=$(cat $dir/codex_generations.py | grep -c  "def test_bump_version"); cov=$(cat ${dir}/statistics.csv| tail -n 1  | tr -d '"'| awk -F, '{printf "%.3f", $NF}'  ); alpha_occs=$(cat $dir/codex_generations.py| grep -c "'alpha'"); echo $tests_with_docstring_eg, $alpha_occs, $bump_version_tests, $cov; done; done
